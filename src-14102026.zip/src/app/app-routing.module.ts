import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';


import { AuthGuard } from './auth.guard';
import { AppComponent } from './app.component';
import { ChatComponent } from './chat/chat.component';
import { HomeComponent } from './home/home.component';
import { VoicebotComponent } from './voicebot/voicebot.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { SurveyEtbComponent } from './survey-etb/survey-etb.component';
import { SurveyNtbComponent } from './survey-ntb/survey-ntb.component';

const routes: Routes = [
/*   { path: '', component: FeedbackComponent }, */
{ path: 'survey-etb', component: SurveyEtbComponent }, // Existing customer
  { path: 'survey-ntb', component: SurveyNtbComponent }, // Potential customer
  { path: '**', redirectTo: 'survey-ntb' } // optional fallback



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  providers: [AuthGuard],
  exports: [RouterModule]
})
export class AppRoutingModule { }
