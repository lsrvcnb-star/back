import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';


import { DataService } from './data.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { EmptyMsgPipePipe } from './empty-msg-pipe.pipe';


import { SsologinComponent } from './ssologin/ssologin.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ChatComponent } from './chat/chat.component';
import { DraggableBotDirective } from './draggable-bot.directive';
import { HomeComponent } from './home/home.component';
import { VoicebotComponent } from './voicebot/voicebot.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { SurveyEtbComponent } from './survey-etb/survey-etb.component';
import { SurveyNtbComponent } from './survey-ntb/survey-ntb.component';

// import { GenScoreStatusComponent } from './gen-score-status/gen-score-status.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ChatComponent,


    SsologinComponent,
      DraggableBotDirective,
      HomeComponent,
      VoicebotComponent,
      FeedbackComponent,
      SurveyEtbComponent,
      SurveyNtbComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    BrowserAnimationsModule,
    ModalModule.forRoot()
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS, useClass: DataService, multi: true,
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
