import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Download, Loader2, RefreshCw } from "lucide-react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "./ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { downloadPreviousProposal } from "../lib/previous-proposal";

const PAGE_SIZE = 10;

function valueOf(record, keys, fallback = "—") {
    for (const key of keys) {
        const value = record?.[key];
        if (value !== undefined && value !== null && value !== "") return value;
    }
    return fallback;
}

function formatDate(value) {
    if (!value || value === "—") return "—";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function auditIdOf(record) {
    return valueOf(record, ["audit_id", "auditId", "id"], null);
}

export default function PreviousProposalDialog({ open, onOpenChange, proposals, loading, onRefresh }) {
    const [page, setPage] = useState(1);
    const [downloadId, setDownloadId] = useState(null);
    const [downloadError, setDownloadError] = useState("");

    const totalPages = Math.max(1, Math.ceil(proposals.length / PAGE_SIZE));
    const visibleProposals = useMemo(
        () => proposals.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
        [page, proposals]
    );

    useEffect(() => {
        if (open) setPage(1);
    }, [open]);

    useEffect(() => {
        if (page > totalPages) setPage(totalPages);
    }, [page, totalPages]);

    const handleDownload = async (proposal) => {
        const auditId = auditIdOf(proposal);
        if (!auditId) {
            setDownloadError("This proposal does not have a valid audit id.");
            return;
        }

        try {
            setDownloadError("");
            setDownloadId(auditId);
            const { blob, filename } = await downloadPreviousProposal(auditId, proposal);
            const url = URL.createObjectURL(blob);
            const anchor = document.createElement("a");
            anchor.href = url;
            anchor.download = filename;
            document.body.appendChild(anchor);
            anchor.click();
            anchor.remove();
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error("Failed to download previous proposal", error);
            setDownloadError("Unable to download this proposal. Please try again.");
        } finally {
            setDownloadId(null);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="w-[calc(100vw-2rem)] max-w-6xl max-h-[85vh] overflow-hidden flex flex-col">
                <DialogHeader>
                    <DialogTitle className="text-mds-navy text-base">Previous Proposals</DialogTitle>
                    <DialogDescription className="text-xs">
                        Review and download proposal documents exported for your account.
                    </DialogDescription>
                </DialogHeader>

                <div className="flex items-center justify-between gap-3 border-y border-border py-2">
                    <div className="text-xs text-muted-foreground">
                        {loading ? "Loading proposals…" : `${proposals.length} proposal${proposals.length === 1 ? "" : "s"}`}
                    </div>
                    <Button type="button" variant="outline" size="sm" className="gap-2" onClick={onRefresh} disabled={loading}>
                        <RefreshCw className={loading ? "h-3.5 w-3.5 animate-spin" : "h-3.5 w-3.5"} />
                        Refresh
                    </Button>
                </div>

                {downloadError && (
                    <div className="rounded-md border border-mds-danger/30 bg-mds-danger/5 px-3 py-2 text-xs text-mds-danger">
                        {downloadError}
                    </div>
                )}

                <div className="min-h-0 flex-1 overflow-auto rounded-md border border-border">
                    <Table className="text-xs">
                        <TableHeader>
                            <TableRow>
                                <TableHead>Date</TableHead>
                                <TableHead>Proposal / Counterparty</TableHead>
                                <TableHead>Document type</TableHead>
                                <TableHead>Format</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Attachment</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                                        Loading previous proposals…
                                    </TableCell>
                                </TableRow>
                            ) : visibleProposals.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                                        No previous proposals found.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                visibleProposals.map((proposal, index) => {
                                    const auditId = auditIdOf(proposal);
                                    const documentName = valueOf(proposal, ["documentName", "fileName", "filename", "name"]);
                                    const counterparty = valueOf(proposal, ["counterpartyName", "companyName", "bankName", "proposalName", "title"]);
                                    const documentType = valueOf(proposal, ["documentType", "exportType", "type"]);
                                    const formatValue = valueOf(proposal, ["format", "fileType", "mimeType"]);
                                    const status = valueOf(proposal, ["status", "approvalStatus"], "Exported");
                                    const date = valueOf(proposal, ["createdAt", "created_at", "exportedAt", "timestamp", "date"]);

                                    return (
                                        <TableRow key={auditId ?? `${documentName}-${index}`}>
                                            <TableCell className="whitespace-nowrap tabular">{formatDate(date)}</TableCell>
                                            <TableCell>
                                                <div className="font-medium text-mds-navy">{counterparty}</div>
                                                <div className="max-w-[260px] truncate text-[10px] text-muted-foreground" title={documentName}>
                                                    {documentName}
                                                </div>
                                            </TableCell>
                                            <TableCell>{documentType}</TableCell>
                                            <TableCell>{formatValue}</TableCell>
                                            <TableCell><Badge variant="outline" className="text-[10px]">{status}</Badge></TableCell>
                                            <TableCell>
                                                <button
                                                    type="button"
                                                    className="inline-flex items-center gap-1 text-mds-blue hover:underline disabled:cursor-not-allowed disabled:opacity-50"
                                                    onClick={() => handleDownload(proposal)}
                                                    disabled={!auditId || downloadId === auditId}
                                                >
                                                    {downloadId === auditId ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                                                    {downloadId === auditId ? "Downloading…" : "Download"}
                                                </button>
                                            </TableCell>
                                        </TableRow>
                                    );
                                })
                            )}
                        </TableBody>
                    </Table>
                </div>

                <div className="flex items-center justify-between gap-3 pt-1 text-xs text-muted-foreground">
                    <span>
                        {proposals.length ? `Showing ${(page - 1) * PAGE_SIZE + 1}–${Math.min(page * PAGE_SIZE, proposals.length)} of ${proposals.length}` : ""}
                    </span>
                    <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" size="sm" className="h-8 gap-1" onClick={() => setPage((current) => Math.max(1, current - 1))} disabled={page === 1 || loading}>
                            <ChevronLeft className="h-3.5 w-3.5" /> Previous
                        </Button>
                        <span className="tabular">Page {page} of {totalPages}</span>
                        <Button type="button" variant="outline" size="sm" className="h-8 gap-1" onClick={() => setPage((current) => Math.min(totalPages, current + 1))} disabled={page === totalPages || loading}>
                            Next <ChevronRight className="h-3.5 w-3.5" />
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
