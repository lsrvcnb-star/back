# IFV Negotiation Backend

Standalone local Node backend for the negotiation tool.

Endpoints:

- `GET /api/public/market`
- `GET /api/public/counterparty?bank=sbi&symbol=SBIN&rating=AAA`
- `GET /health`

Run from the IFV project root:

```bash
node negotiation-backend/server.mjs
```

The default address is `http://127.0.0.1:3101`.
