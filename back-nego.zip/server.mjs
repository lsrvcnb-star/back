import http from "node:http";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import ts from "typescript";
import * as XLSX from "xlsx";

const PORT = Number(process.env.NEGOTIATION_BACKEND_PORT || 3101);
const HOST = process.env.NEGOTIATION_BACKEND_HOST || "127.0.0.1";
const ROOT = dirname(fileURLToPath(import.meta.url));

async function loadHandler(fileName, exportedFunction, globals = {}) {
  const sourcePath = resolve(ROOT, "src/routes/api/public", fileName);
  let source = await readFile(sourcePath, "utf8");

  source = source.replace(/^import[^;]+;\s*/gm, "");
  const routeStart = source.indexOf("export const Route = createFileRoute");
  if (routeStart >= 0) source = source.slice(0, routeStart);
  source += `\nexport { ${exportedFunction} };\n`;

  const globalPrelude = Object.keys(globals)
    .map((key) => `const ${key} = globalThis.__negotiationGlobals.${key};`)
    .join("\n");
  source = `${globalPrelude}\n${source}`;

  const transpiled = ts.transpileModule(source, {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
      jsx: ts.JsxEmit.ReactJSX,
    },
    fileName,
  }).outputText;

  const moduleUrl = `${pathToFileURL(resolve(ROOT, "server.mjs")).href}?${fileName}`;
  const module = await import(`data:text/javascript;base64,${Buffer.from(transpiled).toString("base64")}`);
  return module[exportedFunction];
}

globalThis.__negotiationGlobals = { XLSX };

const marketHandler = await loadHandler("market.ts", "buildSnapshot", { XLSX });
const counterpartyHandler = await loadHandler("counterparty.ts", "build");

const marketCache = { at: 0, data: null };
const counterpartyCache = new Map();
const MARKET_TTL = 30 * 60 * 1000;
const COUNTERPARTY_TTL = 15 * 60 * 1000;

function json(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  });
  res.end(body);
}

async function handleMarket(res, requestUrl) {
  const now = Date.now();
  const fresh = requestUrl.searchParams.get("fresh") === "1";
  if (!fresh && marketCache.data && now - marketCache.at < MARKET_TTL) {
    return json(res, 200, { ...marketCache.data, cached: true });
  }
  try {
    const data = await marketHandler();
    marketCache.at = now;
    marketCache.data = data;
    return json(res, 200, { ...data, cached: false });
  } catch (error) {
    return json(res, 502, {
      error: error instanceof Error ? error.message : String(error),
      fetchedAt: new Date().toISOString(),
    });
  }
}

async function handleCounterparty(res, requestUrl) {
  const bankId = (requestUrl.searchParams.get("bank") || "").toLowerCase();
  const symbol = requestUrl.searchParams.get("symbol");
  const rating = requestUrl.searchParams.get("rating");
  const fresh = requestUrl.searchParams.get("fresh") === "1";
  const key = `${bankId}:${symbol || ""}:${rating || ""}`;
  const now = Date.now();
  const cached = counterpartyCache.get(key);
  if (!fresh && cached && now - cached.at < COUNTERPARTY_TTL) {
    return json(res, 200, { ...cached.data, cached: true });
  }
  try {
    const data = await counterpartyHandler(bankId, symbol, rating);
    counterpartyCache.set(key, { at: now, data });
    return json(res, 200, { ...data, cached: false });
  } catch (error) {
    return json(res, 502, { error: error instanceof Error ? error.message : String(error) });
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
    });
    return res.end();
  }

  const requestUrl = new URL(req.url || "/", `http://${req.headers.host || `${HOST}:${PORT}`}`);
  if (req.method === "GET" && requestUrl.pathname === "/api/public/market") {
    return handleMarket(res, requestUrl);
  }
  if (req.method === "GET" && requestUrl.pathname === "/api/public/counterparty") {
    return handleCounterparty(res, requestUrl);
  }
  if (req.method === "GET" && requestUrl.pathname === "/health") {
    return json(res, 200, { status: "ok", service: "ifv-negotiation-backend" });
  }
  return json(res, 404, { error: "Not found" });
});

server.listen(PORT, HOST, () => {
  console.log(`Negotiation backend listening at http://${HOST}:${PORT}`);
});
