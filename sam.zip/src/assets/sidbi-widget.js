/* (function () {
  const config = window.MyChatbotConfig || {};
  const iconUrl = config.iconUrl || 'https://dashboardweb.sidbi.in/assets/images/image2.png';
  const chatbotUrl = config.chatbotUrl || 'http://localhost:4200/';
  const position = config.position || 'bottom-right';
  const width = config.width || '450px';
  const height = config.height || '600px';

  const widgetId = 'my-chatbot-widget';
  if (document.getElementById(widgetId)) return;


  const icon = document.createElement('div');
  icon.id = widgetId;
  icon.style.position = 'fixed';
  icon.style.width = '100px';
  icon.style.height = '80px';
  icon.style.backgroundImage = `url(${iconUrl})`;
  icon.style.backgroundSize = 'cover';
  icon.style.zIndex = '9999';
  icon.style.cursor = 'move';



  // Positioning logic
  switch (position) {
    case 'bottom-left':
      icon.style.bottom = '20px';
      icon.style.left = '20px';
      break;
    case 'top-right':
      icon.style.top = '20px';
      icon.style.right = '20px';
      break;
    case 'top-left':
      icon.style.top = '20px';
      icon.style.left = '20px';
      break;
    default: // bottom-right
      icon.style.bottom = '20px';
      icon.style.right = '20px';
  }

  // Make draggable
  icon.onmousedown = function (e) {
    e.preventDefault();
    let shiftX = e.clientX - icon.getBoundingClientRect().left;
    let shiftY = e.clientY - icon.getBoundingClientRect().top;

    function moveAt(pageX, pageY) {
      icon.style.left = pageX - shiftX + 'px';
      icon.style.top = pageY - shiftY + 'px';
      icon.style.right = 'auto';
      icon.style.bottom = 'auto';
    }

    function onMouseMove(e) {
      moveAt(e.pageX, e.pageY);
    }

    document.addEventListener('mousemove', onMouseMove);

    icon.onmouseup = function () {
      document.removeEventListener('mousemove', onMouseMove);
      icon.onmouseup = null;
    };
  };

  icon.ondragstart = () => false;

  // Create modal
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.width = width;
  modal.style.height = height;
  modal.style.background = '#fff';
  modal.style.border = '1px solid #ccc';
  modal.style.zIndex = '9999';
  modal.style.display = 'none';
  modal.style.boxShadow = '0 0 10px rgba(0,0,0,0.3)';
  modal.style.borderRadius = '21px';

  // Modal positioning (same as icon)
  switch (position) {
    case 'bottom-left':
      modal.style.bottom = '80px';
      modal.style.left = '20px';
      break;
    case 'top-right':
      modal.style.top = '80px';
      modal.style.right = '20px';
      break;
    case 'top-left':
      modal.style.top = '80px';
      modal.style.left = '20px';
      break;
    default: // bottom-right
      modal.style.bottom = '30px';
      modal.style.right = '120px';
  }


  // Create close button
  const closeBtn = document.createElement('div');
  closeBtn.innerHTML = '&times;';
  closeBtn.style.position = 'absolute';
  closeBtn.style.top = '5px';
  closeBtn.style.right = '10px';
  closeBtn.style.fontSize = '24px';
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.zIndex = '10000';
  closeBtn.style.color = '#333';

  closeBtn.onclick = () => {
    modal.style.display = 'none';
  };


  const iframe = document.createElement('iframe');
  iframe.src = chatbotUrl;
  iframe.allow = 'microphone';
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = 'none';
  iframe.style.borderRadius = '21px';

  modal.appendChild(closeBtn);
  modal.appendChild(iframe);

  icon.onclick = () => {
    modal.style.display = modal.style.display === 'none' ? 'block' : 'none';
  };

  document.body.appendChild(icon);
  document.body.appendChild(modal);
})();
 */