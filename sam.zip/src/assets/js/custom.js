 $(document).ready(function () { 
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $(this).toggleClass('active');
            });
			
			
			
			// Onclick Show Data
       $('.resume') .hide()
         $('.resume.shows') .show()
         $('nav ul li a[href^="#"]').on('click', function(event) {
	     	  $('nav ul li a[href^="#"]') .removeClass('menuActive')
			  $(this) .addClass('menuActive')
        	$('.resume') .hide()
         var target = $(this).attr('href');
         $('.resume'+target).toggle();

         });

	   
	   
	   //onScroll_HeaderFixd
$(window).scroll(function() {
  var sticky = $('.PScoll'),
    scroll = $(window).scrollTop();
   
  if (scroll >= 40) { 
    sticky.addClass('fixedHeader'); }
  else { 
   sticky.removeClass('fixedHeader');

}
});




//Footer_Slider
$('.schemes').not('.slick-initialized').slick({
  centerMode: true,
  centerPadding: '60px',
  slidesToShow: 5,
  autoplay: true,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 3
      }
    },
    {
      breakpoint: 480,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 1
      }
    }
  ]
});
	   
	   
//Socila_Icons
clicked = true;
        $(".arrow_hs").click(function(){
            if(clicked){
                $(".social_icons").css('right', '-50px');
                $( ".arrow_hs" ).addClass( "show-links" );
                $( ".arrow_hs" ).removeClass( "hide-links" );
                clicked  = false;
            } else {
                $(".social_icons").css('right', '0px');
                $( ".arrow_hs" ).addClass( "hide-links" );
                $( ".arrow_hs" ).removeClass( "show-links" );
                clicked  = true;
            }   
        });
	 



//Card_Onclick
$(function() {    
		 $("#firstdata").click(function(){
		  $(".data_contentfirst").show(500);
		  $(".data_contentsecond").hide(500);
		});

		$("#secondtdata").click(function(){
		  $(".data_contentsecond").show(500);
		  $(".data_contentfirst").hide(500);
		});

  $(".btn.card_btn").click(function(e) {
	e.preventDefault();	  
    $(".btn.card_btn").removeClass('btnhover');
	$(this).addClass('btnhover');
	$(".card").removeClass('insetshadow');
	$(this).parent().parent().addClass('insetshadow');
  });
  
  
});


//After Click_NoAction
$('ul.list-unstyled li a').click(function(e)
   {
    e.preventDefault();
    });
	
	   
  
  });