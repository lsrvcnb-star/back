import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { HttpClient, HttpInterceptor, HttpEvent, HttpRequest, HttpHandler, HttpResponse, HttpUserEvent } from '@angular/common/http';
import { DataService } from '../data.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss', '../../assets/css/navbar.css']
})
export class HomeComponent implements OnInit {
  showChat = false;
  url = 'https://sidbi.in'; // Replace with your desired URL

  htmlContent: any;
  isChatExpanded: boolean = false;
  sessionId: any;
  showFeedback: boolean = false;
  constructor(private sanitizer: DomSanitizer, private http: HttpClient, private dataService: DataService,) { }

  ngOnInit(): void {

    this.dataService.resetSessionId();

    const storedId = localStorage.getItem('session_id');
    this.sessionId = storedId || this.dataService.resetSessionId();
    if (!storedId) localStorage.setItem('session_id', this.sessionId);



    this.checkMicrophonePermission();

    // this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);
    this.http.get('assets/sidbi.html', { responseType: 'text' }).subscribe({
      next: (html: string) => {
        this.htmlContent = this.sanitizer.bypassSecurityTrustHtml(html);



        setTimeout(() => {
          // this.executeScripts();
          // this.includeScript();
          this.handleScriptExecution();
        }, 3000);


      },
      error: (err) => console.log('Not Getting')
    })
  }


  openChat() {
    this.showChat = !this.showChat;

    setTimeout(() => {
      const imageElement = document.querySelector('.draggable-element') as HTMLElement;
      const popupElement = document.querySelector('.chat-popup') as HTMLElement;

      if (imageElement && popupElement) {
        const imageRect = imageElement.getBoundingClientRect();
        const viewportWidth = window.innerWidth;

        const spaceRight = viewportWidth - imageRect.right;
        const spaceLeft = imageRect.left;

        // Align bottom of popup with bottom of image
        const popupHeight = popupElement.offsetHeight;
        const popupBottom = window.innerHeight - imageRect.bottom;

        popupElement.style.bottom = `${popupBottom}px`;

        if (spaceRight >= 420) {
          // Show popup to the right of the image
          popupElement.style.left = `${imageRect.right + 10}px`;
          popupElement.style.right = '';
        } else if (spaceLeft >= 420) {
          // Show popup to the left of the image
          popupElement.style.left = `${imageRect.left - 430}px`;
          popupElement.style.right = '';
        } else {
          // Default to bottom-right if not enough space
          popupElement.style.left = '';
          popupElement.style.right = '10px';
        }
      }
    }, 0);
  }

  openFeedbackChat() {
    this.showFeedback = !this.showFeedback;
  }




  closeChat() {
    this.showChat = false;
  }

    closefeedback() {
    this.showFeedback = false;
  }




  handleScriptExecution() {
    const container = document.querySelector('#html-container');
    if (!container) return;

    const scripts = container.querySelectorAll('script');
    scripts?.forEach(oldScript => {
      const newScript = document.createElement('script');
      if (oldScript.src) {
        newScript.src = oldScript.src;
      } else {
        newScript.textContent = oldScript.textContent;
      }
      document?.body?.appendChild(newScript);
      oldScript.remove();
    });
  }


  includeScript() {
    'use strict';

    // Your code here...
    var my_awesome_script = document.createElement('script');
    my_awesome_script.setAttribute("id", "QChatparams")
    my_awesome_script.setAttribute('src', 'https://main.d2s5a9h9rjxhz3.amplifyapp.com/serve.js?bedrockEngine=true&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhZGRpdGlvbmFsX3NpdGVzIjpbXSwiYm90X3N0YXR1cyI6bnVsbCwiY2hhdGJvdF9sb2dvX3VybCI6bnVsbCwiY2hhdGJvdG5hbWUiOiJTSURCSSBBSSBBc3Npc3QiLCJjcmVhdGVkQXQiOiIyMDI1LTA2LTE3VDA0OjQ0OjIzLjIyOFoiLCJjdXN0b21lciI6IlNJREJJIiwiZG9jcyI6bnVsbCwiZXhwaXJ5X2RhdGV0aW1lIjpudWxsLCJndWFyZHJhaWxzIjoiWW91IGFyZSBhIHBvbGl0ZSBhbmQgaG9uZXN0IGNoYXRib3QsIHdobyByZXNwb25kcyB0byBxdWVyaWVzIHdpdGggZW1wYXRoeS4iLCJpZCI6IjI4OWZhMWRmLWE5Y2UtNDAyYS1hMTlkLTY3NjFmMWVkOGVhZiIsImluaXRpYWxfdGV4dCI6IkhlbGxvLCBJIGFtIFFDaGF0LiBIb3cgY2FuIEkgaGVscCB5b3U_IiwicWNoYXRmb3JtX3N0YXR1cyI6IlN1Ym1pdHRlZCIsInJlcXVlc3Rlcl9lbWFpbCI6ImF2dnlzYXBAZ21haWwuY29tIiwidG9rZW4iOm51bGwsInVwZGF0ZWRBdCI6IjIwMjUtMDYtMTdUMDQ6NDQ6MjMuMjI4WiIsIndlYnNpdGUiOiJodHRwczovL3d3dy5zaWRiaS5pbiIsInJlZ2lvblEiOm51bGwsImFwcGxpY2F0aW9uSWRRIjoiZTIzM2IyYTEtYzBmOC00MGYyLWI5NDAtZTcyOGUxNzk2NjE5IiwiaWF0IjoxNzUwMTM1NDY1LCJleHAiOjE3NTA3NDAyNjV9.E9w_0UYoL3bOiXpkKb9UDlFI4t1Dhj_vjlLtu7E65Bc')
    document.head.appendChild(my_awesome_script);
  }


  checkMicrophonePermission(): Promise<boolean> {
    return navigator.mediaDevices.getUserMedia({ audio: true })
      .then((stream) => {
        // Stop all tracks after getting permission
        stream.getTracks().forEach(track => track.stop());
        console.log("Microphone permission granted");
        return true;
      })
      .catch((err) => {
        console.warn("Microphone permission denied:", err);
        alert("Microphone access is required for voice input. Please allow it in your browser settings.");
        return false;
      });
  }

  resizeChat() {
    this.isChatExpanded = !this.isChatExpanded;

  }

}
