import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'emptyMsgPipe'
})
export class EmptyMsgPipePipe implements PipeTransform {

  transform(msg: string): any {
   if(msg == "" || msg == null){
    msg = "Unable to process the request now. Please try again in sometime."
   }
   return msg;
  }

}
