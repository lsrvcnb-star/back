import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  ChangeDetectorRef
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidatorFn
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { trigger, style, animate, transition } from '@angular/animations';
import {
  FeedbackService,
  ConversationTurn
} from '../feedback.service';
import { catchError, first, of, switchMap, tap } from 'rxjs';
import { EncryptDecryptService } from '../encrypt-decrypt.service';

type QuestionType = 'choice' | 'text';
interface StaticQuestion {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[];
  required?: boolean;
}
interface AnsweredQA {
  question: string;
  answer: string;
  ui_tag?: string;
}

@Component({
  selector: 'app-survey-etb',
  templateUrl: './survey-etb.component.html',
  styleUrls: ['./survey-etb.component.scss'],
  animations: [
    trigger('fadeScale', [
      transition(':enter', [
        style({ opacity: 0, transform: 'scale(0.9)' }),
        animate('500ms ease-out', style({ opacity: 1, transform: 'scale(1)' }))
      ]),
      transition(':leave', [
        animate('400ms ease-in', style({ opacity: 0, transform: 'scale(0.9)' }))
      ])
    ]),
    trigger('expandCollapse', [
      transition(':enter', [
        style({ height: 0, opacity: 0, overflow: 'hidden' }),
        animate('260ms ease-out', style({ height: '*', opacity: 1 }))
      ]),
      transition(':leave', [
        style({ height: '*', opacity: 1, overflow: 'hidden' }),
        animate('220ms ease-in', style({ height: 0, opacity: 0 }))
      ])
    ])
  ]
})
export class SurveyEtbComponent implements OnInit, OnDestroy {
  // Screen flags
  showWelcome = true;
  showFeedbackForm = false;

  // URL params
  userName = '';
  mobile = '';

  // Forms
  answerForm!: FormGroup;

  // Q&A state
  currentQuestion = '';
  currentField = '';
  conversationHistory: ConversationTurn[] = [];
  collectedFeedback: Record<string, string> = {};
  loading = false;

  // Sticky list
  answeredQAList: AnsweredQA[] = [];
  answersExpanded = false;

  // Word count (final textarea)
  wordCount = 0;
  maxWords = 1000;

  // Speech to text
  speechSupported = false;
  isListening = false;
  private recognition: any;

  // Prevent duplicate submit
  private persisted = false;

  // Index & questions
  qIndex = 0;


  // Output/input focus
  @ViewChild('answerInput') answerInputRef!: ElementRef<HTMLInputElement | HTMLTextAreaElement>;

  // Toasts
  toast: { message: string; type: 'success' | 'danger'; timestamp: number } | null = null;
  private toastTimer?: any;

  // Success
  successMessage = '';

  // Existing customer questions
  private existingQuestions: StaticQuestion[] = [
    {
      id: 'loan_experience_comparison',
      text: 'Compared to your previous SIDBI loan(s), how would you rate this loan experience?',
      type: 'choice',
      options: ['Much Better', 'Better', 'Same', 'Worse', 'Much Worse'],
      required: true
    },
    {
      id: 'tat_appraisal_approval_satisfaction',
      text: 'How satisfied are you with the turnaround time for appraisal and approval?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'eligibility_clarity',
      text: 'How clear were the eligibility criteria and application requirements explained to you?',
      type: 'choice',
      options: ['Very Clear', 'Clear', 'Neutral', 'Unclear', 'Very Unclear'],
      required: true
    },
    {
      id: 'sanction_communication',
      text: 'How satisfied were you with the communication and status updates during sanction?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'documentation_ease_comparison',
      text: 'How easy was documentation submission compared to previous loans?',
      type: 'choice',
      options: ['Much Easier', 'Easier', 'Same', 'More Difficult', 'Much More Difficult'],
      required: true
    },
    {
      id: 'disbursement_speed_comparison',
      text: 'How satisfied are you with the speed of disbursement compared to your earlier SIDBI loans?',
      type: 'choice',
      options: ['Much Faster', 'Faster', 'Same', 'Slower', 'Much Slower'],
      required: true
    },
    {
      id: 'digital_process_improvement',
      text: 'How would you rate improvements in SIDBI’s digital processes over time?',
      type: 'choice',
      options: ['Significant Improvement', 'Some Improvement', 'No Change', 'Deteriorated'],
      required: true
    },
    {
      id: 'overall_satisfaction_long_term',
      text: 'Overall, how satisfied are you with SIDBI as your long‑term financial partner?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'final_feedback',
      text: 'Please share suggestions to further improve SIDBI’s services for existing customers.',
      type: 'text',
      required: false
    }
  ];

    staticQuestions: StaticQuestion[] = this.existingQuestions;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private feedbackService: FeedbackService,
    private cdRef: ChangeDetectorRef,
    private encryptDecrypt: EncryptDecryptService
  ) {}

ngOnInit(): void {
  this.initForms();
  this.initSpeech();

  this.route.queryParamMap.pipe(first()).subscribe(async (params) => {
    const rawName = (params.get('name') || '').trim();
    const rawMobile = (params.get('mobile') || '').trim();

    // 1) Enforce encrypted inputs
    const nameLooksEncrypted = this.isProbablyEncrypted(rawName);
    const mobileLooksEncrypted = this.isProbablyEncrypted(rawMobile);

    if (!nameLooksEncrypted || !mobileLooksEncrypted) {
      this.showToast(
        'Invalid link. Please use the secure survey link sent by SIDBI.',
        'danger',
        6000
      );
      return; // stop here
    }

    // 2) Strict decrypt
    let decName = '';
    let decMobile = '';
    try {
      decName = await this.decryptStrict(rawName);
      decMobile = await this.decryptStrict(rawMobile);
    } catch (err) {
      console.error('[decryptStrict] failed:', err);
      this.showToast(
        'Link appears to be tampered or expired. Please open the secure link again.',
        'danger',
        6000
      );
      return; // stop here
    }

    // 3) Validate mobile after decrypt
    if (!/^[6-9]\d{9}$/.test(decMobile)) {
      this.showToast('Invalid mobile number in secure link.', 'danger', 6000);
      return; // stop here
    }

    // 4) Set values and proceed
    this.userName = decName;
    this.mobile = decMobile;

    setTimeout(() => {
      this.showWelcome = false;
      this.startSurvey();
    }, 500);
  });
}


  private isProbablyEncrypted(value: string): boolean {
  if (!value) return false;

  // Normalize once for safety; ignore decoding errors
  let v = value;
  try { v = decodeURIComponent(value); } catch {}

  // Your EncryptDecryptService replaces '+' -> SIDBI, '/' -> SLASHED
  if (v.includes('SIDBI') || v.includes('SLASHED')) return true;

  // Additional heuristics (optional but helpful):
  // - Length: encrypted blobs are typically longer than 16-20 chars
  // - Base64/base64url character set (after removing SIDBI/SLASHED)
  const cleaned = v.replace(/SIDBI/g, '+').replace(/SLASHED/g, '/');

  // Base64-ish chars (len >= 16 as a sanity threshold)
  const base64ish = /^[A-Za-z0-9+/=]+$/.test(cleaned);
  return cleaned.length >= 16 && base64ish;
}

/**
 * Strictly decrypts a value; throws on any failure.
 */
private async decryptStrict(encrypted: string): Promise<string> {
  if (!encrypted) throw new Error('EMPTY_INPUT');

  let normalized = encrypted;
  try { normalized = decodeURIComponent(encrypted); } catch { /* ignore */ }

  // This will throw if invalid/tampered (AES-GCM integrity)
  const plain = await this.encryptDecrypt.decrypt(normalized);
  const trimmed = (plain ?? '').trim();
  if (!trimmed) throw new Error('DECRYPTED_EMPTY');
  return trimmed;
}


async tryDecrypt(value: string): Promise<{ ok: boolean; value: string }> {
  if (!value) return { ok: false, value: '' };

  // Some encoders convert spaces to '+' or encode '='. Decode once at the start.
  // Note: Your EncryptDecryptService already handles SIDBI/SLASHED variants,
  // but here we normalize standard URL encoding.
  let normalized = value;
  try {
    normalized = decodeURIComponent(value);
  } catch {
    // If decoding fails, continue with raw
  }

  try {
    const plain = await this.encryptDecrypt.decrypt(normalized);
    return { ok: true, value: plain };
  } catch {
    // Not encrypted or bad payload; return as-is so we can fallback
    return { ok: false, value };
  }
}

  ngOnDestroy(): void {
    if (this.toastTimer) { clearTimeout(this.toastTimer); }
    if (this.isListening && this.recognition) {
      try { this.recognition.stop(); } catch {}
    }
  }

  // Forms
  private initForms(): void {
    this.answerForm = this.fb.group({
      answer: ['', Validators.required],
      otherText: [''] // not used here, but harmless if you reuse UI snippets
    });
  }

  // Survey start
  private startSurvey(): void {
    this.showFeedbackForm = true;
    this.conversationHistory = [];
    this.collectedFeedback = {};
    this.answeredQAList = [];
    this.qIndex = 0;
    this.setQuestionFromCurrentItem();
  }

  // Current item getters
  get currentItem(): StaticQuestion | undefined {
    return this.staticQuestions[this.qIndex];
  }
  get currentOptions(): string[] {
    return this.currentItem?.options ?? [];
  }

  private setQuestionFromCurrentItem(): void {
    const item = this.currentItem;
    if (!item) {
      this.completeSurvey();
      return;
    }

    this.currentQuestion = item.text;
    this.currentField = item.id;
    this.configureAnswerValidators(item.id, item);
    this.answerForm.reset();

    // Pulse the question element
    this.cdRef.detectChanges();
    const qEl = document.getElementById('question');
    if (qEl) {
      qEl.classList.remove('pulse');
      void (qEl as any).offsetWidth;
      qEl.classList.add('pulse');
    }

    this.focusAnswerAndScroll();
  }

  private configureAnswerValidators(field: string, item?: StaticQuestion): void {
    const ctrl: AbstractControl | null = this.answerForm.get('answer');
    if (!ctrl) return;
    ctrl.clearValidators();

    if (item?.type === 'text' && field === 'final_feedback') {
      ctrl.setValidators([this.maxWordsValidator(this.maxWords)]);
      this.wordCount = 0;
    } else {
      ctrl.setValidators([Validators.required]);
    }
    ctrl.updateValueAndValidity({ emitEvent: false });
  }

  private maxWordsValidator(max: number): ValidatorFn {
    return (control: AbstractControl) => {
      const text = String(control.value ?? '').trim();
      const words = this.splitWords(text);
      return words.length <= max ? null : { maxWords: { requiredMax: max, actual: words.length } };
    };
  }

  private splitWords(text: string): string[] {
    if (!text) return [];
    return text.split(/\s+/).filter(Boolean);
  }

  updateWordCount(text: string): void {
    const words = this.splitWords(text || '');
    this.wordCount = words.length;
    if (this.currentField === 'final_feedback' && this.wordCount > this.maxWords) {
      const clamped = words.slice(0, this.maxWords).join(' ');
      this.answerForm.patchValue({ answer: clamped }, { emitEvent: false });
      this.wordCount = this.maxWords;
      this.answerForm.get('answer')?.markAsTouched();
    }
  }

  submitAnswer(): void {
    if (this.answerForm.invalid || !this.currentItem) return;

    // Stop mic if on
    if (this.isListening && this.recognition) {
      try { this.recognition.stop(); } catch {}
      this.isListening = false;
    }

    let userAnswer = String(this.answerForm.value.answer || '').trim();

    // 1) Sticky list
    this.answeredQAList.push({
      question: this.currentQuestion,
      answer: userAnswer,
      ui_tag: this.currentField
    });

    // 2) Conversation-like history
    this.conversationHistory.push({
      role: 'assistant',
      content: this.currentQuestion,
      ui_tag: this.currentField
    });
    this.conversationHistory.push({ role: 'user', content: userAnswer });

    // 3) Collect flat feedback
    this.collectedFeedback[this.currentField] = userAnswer;

    // 4) Next or complete
    this.qIndex++;
    if (this.qIndex >= this.staticQuestions.length) {
      this.completeSurvey();
    } else {
      this.setQuestionFromCurrentItem();
    }
  }

  private completeSurvey(): void {
    this.successMessage = '🎉 Thank you for your feedback!';
    this.showFeedbackForm = false;
    this.finalizeAndPersistFeedback();
  }

  private focusAnswerAndScroll(): void {
    setTimeout(() => {
      const el = this.answerInputRef?.nativeElement;
      if (el) {
        try { (el as any).focus?.({ preventScroll: true }) || el.focus(); } catch { el.focus(); }
        if (typeof (el as HTMLInputElement).setSelectionRange === 'function') {
          const val = (el as HTMLInputElement).value ?? '';
          (el as HTMLInputElement).setSelectionRange(val.length, val.length);
        }
        try {
          el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
        } catch {
          el.scrollIntoView();
        }
      }
      try {
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
      } catch {
        window.scrollTo(0, document.body.scrollHeight);
      }
    }, 100);
  }

  // Toasts
  showToast(message: string, type: 'success' | 'danger' = 'danger', duration = 4000): void {
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = undefined;
    }
    this.toast = { message, type, timestamp: Date.now() };
    this.toastTimer = setTimeout(() => {
      this.toast = null;
      this.toastTimer = undefined;
    }, duration);
  }
  closeToast(): void {
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = undefined;
    }
    this.toast = null;
  }

  // Speech
  private initSpeech(): void {
    const win = window as any;
    const SR = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SR) {
      this.speechSupported = false;
      return;
    }
    this.speechSupported = true;
    this.recognition = new SR();
    this.recognition.lang = 'en-IN';
    this.recognition.continuous = true;
    this.recognition.interimResults = true;

    this.recognition.onresult = (event: any) => {
      if (this.loading || !this.showFeedbackForm) return;

      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        if (res.isFinal) {
          finalTranscript += res[0].transcript + ' ';
        }
      }
      if (finalTranscript && this.currentField === 'final_feedback') {
        const current = String(this.answerForm.value.answer || '');
        const nextVal = (current + ' ' + finalTranscript).trim();
        this.answerForm.patchValue({ answer: nextVal });
        this.updateWordCount(nextVal);
        this.cdRef.detectChanges();
      }
    };

    this.recognition.onerror = (e: any) => {
      console.error('Speech recognition error:', e);
      this.isListening = false;
      this.showToast('Speech recognition error. Please try again.', 'danger');
      this.cdRef.detectChanges();
    };

    this.recognition.onend = () => {
      this.isListening = false;
      this.cdRef.detectChanges();
    };
  }

  toggleListening(): void {
    if (!this.speechSupported || !this.recognition) return;
    if (this.isListening) {
      try { this.recognition.stop(); } catch {}
      this.isListening = false;
    } else {
      try { this.recognition.start(); }
      catch (e) {
        console.error('recognition.start() failed:', e);
        this.showToast('Unable to start microphone. Check permissions.', 'danger');
        return;
      }
      this.isListening = true;
    }
  }

  toggleAnswers(): void {
    this.answersExpanded = !this.answersExpanded;
  }

  // Persistence
  private finalizeAndPersistFeedback(): void {
    if (this.persisted) return;
    this.persisted = true;

    const sessionPayload: any = {
      mobile_number: this.mobile,
      customer_name: this.userName,
      cust_id: null,
      scheme_name: null,
      scheme_description: null,
      sanction_amount: null,
      disbursed_amount: null,
      user_type: 'EXISTING_CUSTOMER',            // fixed for ETP route
      collected_feedback: this.collectedFeedback
    };

    this.feedbackService
      .createFeedbackSession(sessionPayload)
      .pipe(
        switchMap((sessionResp) => {
          const sessionId = sessionResp?.session_id;
          if (!sessionId) throw new Error('SESSION_ID_MISSING');

          this.setSessionCookie(sessionId);
          const stringifyHistory = JSON.stringify(this.conversationHistory);
          return this.feedbackService.submitFeedbackConversation(sessionId, stringifyHistory);
        }),
        tap((submitResp) => {
          if (submitResp?.session_id) {
            this.setSessionCookie(submitResp.session_id, submitResp.expires_at);
          }
          this.showToast('Feedback Submitted successfully.', 'success');
        }),
        catchError((err) => {
          console.error('[finalizeAndPersistFeedback][ETP] error:', err);
          this.showToast('Feedback submitted, but saving to database failed.', 'danger');
          return of(null);
        })
      )
      .subscribe();
  }

  private setSessionCookie(sessionId: string, expiresAtIso?: string): void {
    const name = 'sidbi_feedback_session';
    const value = encodeURIComponent(sessionId);

    let expires = '';
    if (expiresAtIso) {
      try {
        const d = new Date(expiresAtIso);
        if (!isNaN(d.getTime())) {
          expires = `; expires=${d.toUTCString()}`;
        }
      } catch {}
    }
    if (!expires) {
      const fallback = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      expires = `; expires=${fallback.toUTCString()}`;
    }

    const path = '; path=/';
    const sameSite = '; SameSite=Lax';
    const secure = location.protocol === 'https:' ? '; Secure' : '';
    document.cookie = `${name}=${value}${expires}${path}${sameSite}${secure}`;
  }
}