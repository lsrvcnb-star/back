
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, delay, map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';



export interface CreateSessionRequest {
  mobile_number: string | null;
  customer_name: string | null;
  cust_id: string | null;
  scheme_name: string | null;
  scheme_description: string | null;
  sanction_amount: string | null;
  disbursed_amount: string | null;
  user_type: string | null;
}


export interface CreateSessionResponse {
  session_id: string;
}

export interface SubmitFeedbackRequest {
  session_id: string;
  feedback_conversation: string; // your existing structure
}

export interface SubmitFeedbackResponse {
  status: string;           // e.g., "RECORD INSERTION SUCCESSFULLY"
  session_id: string;
  expires_at?: string;      // ISO timestamp when session id cookie should expire
}



/** A single message/turn in the conversation we maintain locally */
export interface ConversationTurn {
  role: 'assistant' | 'user';
  content: string;
  ui_tag?: string;
}

export interface ProductInformation {
  scheme_name: string;
  scheme_description: string;
  sanction_amount: number;
  disbursed_amount: number;
}

export interface CustomerProfile {
  branch_name: string;
  branch_address: string;
  product_information: ProductInformation[];
}

export interface CustomerContext {
  status: string;            // e.g., 'EXISTING_CUSTOMER'
  mobile: string;
  cust_id: string
  product_information: CustomerProfile;
}

// Request payload sent to QnA service (now carries optional context)
export interface FeedbackRequest {
  user_input: string;
  conversation_history: ConversationTurn[];
  collected_feedback: Record<string, string>;
  context?: CustomerContext;           // include context when available
}

export interface FeedbackResponse {
  action: 'ASK_QUESTION' | 'COMPLETE' | 'END' | string;
  question?: string;
  ui_tag?: string;
  conversation_history: ConversationTurn[];
  collected_feedback: Record<string, string>;
}

/** Send OTP API response */
export interface SendOtpResponse {
  status: string;  // "success" when success
  id: string;      // request id to be used in verify
}

/** Verify OTP normalized result (handles text or JSON responses) */
export type VerifyOtpStatus = 'success' | 'sms not found' | 'expired' | 'unknown';

export interface VerifyOtpResult {
  ok: boolean;               // true when success
  status: VerifyOtpStatus;   // status string (normalized)
  id?: string;               // echo from server if present
  raw?: any;                 // original response text/object (for logging)
}

@Injectable({ providedIn: 'root' })
export class FeedbackService {
  /** Dynamic Q&A Lambda (POST) */
  private readonly qnaApiUrl =
    'https://3tqhnystaviarqo66bparjp74e0vtqio.lambda-url.ap-south-1.on.aws/post';

  /** Bases from environment */
  private readonly sidbiBase = environment.sidbiApiBase;            // e.g., https://apiuat.sidbi.in
  private readonly fileExtractorBase = environment.fileExtractorBase;
  private readonly extractorApiKey = environment.extractorApiKey;

  /** Default JSON headers */
  private readonly jsonHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http: HttpClient) { }

  /* ------------------------ Customer Context ------------------------ */

  getCustomerContext(mobile: string): Observable<CustomerContext> {
    const msisdn = (mobile || '').replace(/\s+/g, '');
    const url = `${this.fileExtractorBase}/mis_api/customer-info?mobile=${encodeURIComponent(msisdn)}`;

    const headers = new HttpHeaders({
      'x-api-key': this.extractorApiKey,
    });

    return this.http.get<CustomerContext>(url, { headers }).pipe(
      tap(ctx => console.log('[getCustomerContext] received:', ctx)),
      catchError(err => {
        console.error('[FeedbackService] getCustomerContext error:', err);
        return throwError(() => err);
      })
    );
  }

  /* ------------------------ Q&A Conversation ------------------------ */

  /** Start conversation: include 'context' when provided */
  startConversation(context?: CustomerContext): Observable<FeedbackResponse> {
    const body: FeedbackRequest = {
      user_input: '',
      conversation_history: [],
      collected_feedback: {},
      context,
    };

    return this.http.post<FeedbackResponse>(this.qnaApiUrl, body, { headers: this.jsonHeaders }).pipe(
      catchError(err => {
        console.error('[FeedbackService] startConversation error:', err);
        return throwError(() => err);
      })
    );
  }

  /** Subsequent answers — payload already includes 'context' from the caller */
  sendAnswer(payload: FeedbackRequest): Observable<FeedbackResponse> {
    return this.http.post<FeedbackResponse>(this.qnaApiUrl, payload, { headers: this.jsonHeaders }).pipe(
      catchError(err => {
        console.error('[FeedbackService] sendAnswer error:', err);
        return throwError(() => err);
      })
    );
  }

  /* ------------------------ OTP: SEND (POST) ------------------------ */
  /**
   * Sends OTP SMS via SIDBI POST API.
   * POST: {sidbiBase}/SENDMAIL/sms/otp/send/visitapp
   * Body: { mobile: "<10-digit>" }
   * Response: { status: "success", id: "<id>" }
   */
  sendOtp(mobile: string): Observable<SendOtpResponse> {
    const msisdn = (mobile || '').replace(/\s+/g, '');
    const url = `${this.sidbiBase}/SENDMAIL/sms/otp/send/visitapp`;
    const body = { mobile: msisdn };

    return this.http.post<SendOtpResponse>(url, body, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }).pipe(
      tap(resp => console.log('[sendOtp] resp:', resp)),
      catchError(err => {
        console.error('[FeedbackService] sendOtp error:', err);
        return throwError(() => err);
      })
    );
  }

  /* ------------------------ OTP: VERIFY (POST) ------------------------ */
  /**
   * Verifies OTP via SIDBI POST API.
   * POST: {sidbiBase}/SENDMAIL/sms/otp/send/verify
   * Body: { mobile: "<10-digit>", otp: "<code>", id: "<request-id>" }
   * Success (text): "SMS queued sucessfully."
   * Failure (JSON): { status: "sms not found" | "expired", id: "<id>" }
   * Returns: normalized VerifyOtpResult
   */
  verifyOtp(mobile: string, otp: string, id: string): Observable<VerifyOtpResult> {
    const url = `${this.sidbiBase}/SENDMAIL/sms/otp/verify`;
    const body = {
      mobile: (mobile || '').replace(/\s+/g, ''),
      otp: (otp || '').trim(),
      id: (id || '').trim(),
    };

    // Ask for text to handle both plain text and JSON gracefully
    return this.http.post(url, body, { responseType: 'text' }).pipe(
      tap(resp => console.log('[verifyOtp] raw:', resp)),
      map((respText: string) => {
        const trimmed = (respText || '').trim();

        // Try JSON parse first (to catch {"status":"expired"} etc.)
        try {
          const parsed = JSON.parse(trimmed);
          const status = String(parsed?.status || '').toLowerCase() as VerifyOtpStatus;

          if (status === 'sms not found') {
            return { ok: false, status: 'sms not found', id: parsed?.id, raw: parsed } as VerifyOtpResult;
          }

          if (status === 'expired') {
            return { ok: false, status: 'expired', id: parsed?.id, raw: parsed } as VerifyOtpResult;
          }
          if (status === 'success') {
            return { ok: true, status: 'success', id: parsed?.id, raw: parsed } as VerifyOtpResult;

          }
          return { ok: false, status: 'unknown', id: parsed?.id, raw: parsed } as VerifyOtpResult;
        } catch {
          // Not JSON — fall back to success text check
          const ok = /SMS queued sucessfully\./i.test(trimmed);
          return {
            ok,
            status: ok ? 'success' : 'unknown',
            raw: trimmed
          } as VerifyOtpResult;
        }
      }),
      catchError(err => {
        console.error('[FeedbackService] verifyOtp error:', err);
        return throwError(() => err);
      })
    );
  }

  /* ------------------------ Optional legacy mocks ------------------------ */

  submitUserDetails(data: { name: string; mobile: string }): Observable<boolean> {
    console.log('User Details Submitted:', data);
    return of(true).pipe(delay(1500));
  }

  generateOtp(): Observable<number> {
    const otp = Math.floor(100000 + Math.random() * 900000);
    return of(otp).pipe(delay(1000));
  }

  submitFeedback(feedback: any): Observable<boolean> {
    console.log('Final Feedback JSON:', feedback);
    return of(true).pipe(delay(1500));
  }




  createFeedbackSession(payload: CreateSessionRequest): Observable<CreateSessionResponse> {
    const url = `${this.fileExtractorBase}/mis_api/create-feedback-session`;
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'x-api-key': this.extractorApiKey,
    });

    return this.http.post<CreateSessionResponse>(url, payload, { headers }).pipe(
      tap(resp => console.log('[createFeedbackSession] resp:', resp)),
      catchError(err => {
        console.error('[FeedbackService] createFeedbackSession error:', err);
        return throwError(() => err);
      })
    );
  }

  // ------------------------ NEW: submit feedback conversation -------------------
  submitFeedbackConversation(sessionId: string, conversation: string): Observable<SubmitFeedbackResponse> {
    const url = `${this.fileExtractorBase}/mis_api/feedback/submit`;
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'x-api-key': this.extractorApiKey,
    });

    const body: SubmitFeedbackRequest = {
      session_id: sessionId,
      feedback_conversation: conversation,
    };

    return this.http.post<SubmitFeedbackResponse>(url, body, { headers }).pipe(
      tap(resp => console.log('[submitFeedbackConversation] resp:', resp)),
      catchError(err => {
        console.error('[FeedbackService] submitFeedbackConversation error:', err);
        return throwError(() => err);
      })
    );
  }

}
