import {
  Component,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter,
  ViewChild,
  ElementRef,
  ChangeDetectorRef
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidatorFn
} from '@angular/forms';
import { trigger, style, animate, transition } from '@angular/animations';
import {
  FeedbackService,
  FeedbackResponse,           // kept for type compatibility (not used for static survey)
  ConversationTurn,
  FeedbackRequest,            // kept for compatibility (not used for static survey)
  CustomerContext
} from '../feedback.service';
import { catchError, map, of, switchMap, tap } from 'rxjs';
import { EncryptDecryptService } from '../encrypt-decrypt.service';

interface AnsweredQA {
  question: string;
  answer: string;
  ui_tag?: string;
}

type QuestionType = 'choice' | 'text';
interface StaticQuestion {
  id: string;       // key for collectedFeedback
  text: string;
  type: QuestionType;
  options?: string[]; // for 'choice'
  required?: boolean;
}

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss'],
  animations: [
    trigger('fadeScale', [
      transition(':enter', [
        style({ opacity: 0, transform: 'scale(0.9)' }),
        animate('500ms ease-out', style({ opacity: 1, transform: 'scale(1)' }))
      ]),
      transition(':leave', [
        animate('400ms ease-in', style({ opacity: 0, transform: 'scale(0.9)' }))
      ])
    ]),
    trigger('slideUp', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(30px)' }),
        animate('500ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ]),
    trigger('expandCollapse', [
      transition(':enter', [
        style({ height: 0, opacity: 0, overflow: 'hidden' }),
        animate('260ms ease-out', style({ height: '*', opacity: 1 }))
      ]),
      transition(':leave', [
        style({ height: '*', opacity: 1, overflow: 'hidden' }),
        animate('220ms ease-in', style({ height: 0, opacity: 0 }))
      ])
    ])
  ]
})
export class FeedbackComponent implements OnInit, OnDestroy {
  // Step flags
  showWelcome = true;
  showUserForm = false;
  showOtpForm = false;
  showFeedbackForm = false;

  // Forms
  userForm!: FormGroup;
  otpForm!: FormGroup;
  answerForm!: FormGroup;

  // Q&A state
  currentQuestion = '';
  currentField = '';
  conversationHistory: ConversationTurn[] = [];
  collectedFeedback: Record<string, string> = {};
  loading = false;
  skipOtp: boolean = true;

  // OTP
  generatedOtp!: number; // kept for compatibility if needed
  userName = '';
  generatedOtpId: string = '';
  otpStatusMessage: string | null = null;

  // Toast state
  toast: { message: string; type: 'success' | 'danger'; timestamp: number } | null = null;
  private toastTimer?: any;

  // Confirm close modal
  confirmCloseOpen = false;

  // Resend OTP state
  canResendOtp = false;
  resendCountdown = 0;
  private resendTimer?: any;

  // Output
  @Output() close = new EventEmitter<void>();

  // For focusing and scroll
  @ViewChild('answerInput') answerInputRef!: ElementRef<HTMLInputElement | HTMLTextAreaElement>;

  // Answered list (sticky)
  answeredQAList: AnsweredQA[] = [];
  answersExpanded: boolean = false;

  customerContext?: CustomerContext;

  // Word count (final textarea)
  wordCount = 0;
  maxWords = 1000;

  // Speech to text
  speechSupported = false;
  isListening = false;
  private recognition: any;

  private persisted = false;

  // Static survey
  qIndex = 0;

  // We will set this array AFTER we know status (POTENTIAL / EXISTING)
  staticQuestions: StaticQuestion[] = [];

  // Potential customer questions (Q1–Q8 choice + Q9 textarea)
  private potentialQuestions: StaticQuestion[] = [
    {
      id: 'awareness_source',
      text: 'How did you first become aware of SIDBI’s loan products?',
      type: 'choice',
      options: [
        'Bank / Financial Institution referral',
        'SIDBI customer referral',
        'SIDBI website',
        'SIDBI official',
        'Industry association',
        'Others'
      ],
      required: true
    },
    {
      id: 'first_interaction_guidance',
      text: 'How satisfied are you with the guidance provided during your first interaction with SIDBI?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'eligibility_clarity',
      text: 'How clear were the eligibility criteria and application requirements explained to you?',
      type: 'choice',
      options: ['Very Clear', 'Clear', 'Neutral', 'Unclear', 'Very Unclear'],
      required: true
    },
    {
      id: 'sanction_communication',
      text: 'How satisfied were you with the communication and status updates during sanction?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'documentation_ease',
      text: 'How easy was it to complete documentation as a first‑time SIDBI borrower?',
      type: 'choice',
      options: ['Very Easy', 'Easy', 'Neutral', 'Difficult', 'Very Difficult'],
      required: true
    },
    {
      id: 'disbursement_timeliness',
      text: 'How satisfied are you with the timeliness of loan disbursement after approval?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'digital_experience',
      text: 'How would you rate your overall digital experience with SIDBI?',
      type: 'choice',
      options: ['Excellent', 'Good', 'Average', 'Poor', 'Very Poor'],
      required: true
    },
    {
      id: 'overall_satisfaction',
      text: 'Overall, how satisfied are you with SIDBI as a first‑time borrower?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'final_feedback',
      text: 'Please share any suggestions to improve onboarding and first‑time borrower experience.',
      type: 'text',
      required: false // optional
    }
  ];

  // Existing customer questions (Q1–Q8 choice + Q9 textarea with different sentence)
  private existingQuestions: StaticQuestion[] = [
    {
      id: 'loan_experience_comparison',
      text: 'Compared to your previous SIDBI loan(s), how would you rate this loan experience?',
      type: 'choice',
      options: ['Much Better', 'Better', 'Same', 'Worse', 'Much Worse'],
      required: true
    },
    {
      id: 'tat_appraisal_approval_satisfaction',
      text: 'How satisfied are you with the turnaround time for appraisal and approval?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'eligibility_clarity',
      text: 'How clear were the eligibility criteria and application requirements explained to you?',
      type: 'choice',
      options: ['Very Clear', 'Clear', 'Neutral', 'Unclear', 'Very Unclear'],
      required: true
    },
    {
      id: 'sanction_communication',
      text: 'How satisfied were you with the communication and status updates during sanction?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'documentation_ease_comparison',
      text: 'How easy was documentation submission compared to previous loans?',
      type: 'choice',
      options: ['Much Easier', 'Easier', 'Same', 'More Difficult', 'Much More Difficult'],
      required: true
    },
    {
      id: 'disbursement_speed_comparison',
      text: 'How satisfied are you with the speed of disbursement compared to your earlier SIDBI loans?',
      type: 'choice',
      options: ['Much Faster', 'Faster', 'Same', 'Slower', 'Much Slower'],
      required: true
    },
    {
      id: 'digital_process_improvement',
      text: 'How would you rate improvements in SIDBI’s digital processes over time?',
      type: 'choice',
      options: ['Significant Improvement', 'Some Improvement', 'No Change', 'Deteriorated'],
      required: true
    },
    {
      id: 'overall_satisfaction_long_term',
      text: 'Overall, how satisfied are you with SIDBI as your long‑term financial partner?',
      type: 'choice',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      required: true
    },
    {
      id: 'final_feedback', // keep same id so final-text logic & validator work identically
      text: 'Please share suggestions to further improve SIDBI’s services for existing customers.',
      type: 'text',
      required: false // optional
    }
  ];

  constructor(
    private fb: FormBuilder,
    private feedbackService: FeedbackService,
    private encryptService: EncryptDecryptService,
    private cdRef: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.generatedOtpId = '';
    this.initForms();

    setTimeout(() => {
      this.showWelcome = false;
      this.showUserForm = true;
    }, 1000);

    this.initSpeech();
   // this.encrypt();
  }

  async encrypt() {
    const encryptedMobileNumber = await this.encryptService.encrypt('9600389196');
    console.log('encrypted mobile Number', encryptedMobileNumber);
  }

  
get isOtpSkipped(): boolean {
  return this.skipOtp;
}


  ngOnDestroy(): void {
    if (this.resendTimer) {
      clearInterval(this.resendTimer);
      this.resendTimer = undefined;
    }
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = undefined;
    }
    if (this.isListening && this.recognition) {
      try { this.recognition.stop(); } catch { }
    }
  }

  // UI actions
  closeChat(): void {
    if (this.showFeedbackForm && !this.successMessage) {
      this.confirmCloseOpen = true;
      return;
    }
    this.close.emit();
  }
  confirmClose(): void {
    this.confirmCloseOpen = false;
    this.close.emit();
  }
  cancelClose(): void {
    this.confirmCloseOpen = false;
  }

  // Forms
  initForms(): void {
    this.userForm = this.fb.group({
      name: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]]
    });

    this.otpForm = this.fb.group({
      otp: ['', [Validators.required, Validators.pattern(/^\d{4}$/)]]
    });

    // 'answer' = choice or text; 'otherText' only for potential Q1 Others
    this.answerForm = this.fb.group({
      answer: ['', Validators.required],
      otherText: ['']
    });

    // Dynamic validation for "Others" (only applies when currentField === 'awareness_source')
    this.answerForm.get('answer')?.valueChanges.subscribe((val) => {
      if (this.currentField === 'awareness_source') {
        const otherCtrl = this.answerForm.get('otherText');
        if (!otherCtrl) return;
        if (val === 'Others') {
          otherCtrl.setValidators([Validators.required, Validators.minLength(2)]);
        } else {
          otherCtrl.clearValidators();
          otherCtrl.setValue('');
        }
        otherCtrl.updateValueAndValidity({ emitEvent: false });
      }
    });
  }

  // User -> OTP
submitUser(): void {
  if (this.userForm.invalid) return;

  this.userName = (this.userForm.value.name || '').trim();
  const mobile = (this.userForm.value.mobile || '').trim();

  // If skipping OTP, jump straight to context -> survey
  if (this.skipOtp) {
    this.loading = true;

    // Hide user form and show feedback form once we are ready
    this.showUserForm = false;

    this.feedbackService.getCustomerContext(mobile).pipe(
      tap((ctx) => {
        console.log('📌 CUSTOMER CONTEXT (OTP skipped):', ctx);
      }),
      catchError((err) => {
        console.error('getCustomerContext failed (OTP skipped):', err);
        this.showToast('Unable to find your profile. Continuing as a new visitor.', 'success');
        return of(undefined); // proceed with POTENTIAL flow
      })
    )
    .subscribe({
      next: (ctx) => {
        if (ctx) this.customerContext = ctx as any;

        const status = (ctx as any)?.status || 'POTENTIAL_CUSTOMER';
        if (status === 'EXISTING_CUSTOMER') {
          this.staticQuestions = this.existingQuestions;
        } else {
          this.staticQuestions = this.potentialQuestions;
        }

        // Start survey immediately
        this.showOtpForm = false;        // ensure
        this.showFeedbackForm = true;    // show the QA view

        // Reset survey state and go
        this.conversationHistory = [];
        this.collectedFeedback = {};
        this.answeredQAList = [];
        this.qIndex = 0;

        this.setQuestionFromCurrentItem();
      },
      error: (err) => {
        console.error('submitUser (OTP skipped) flow error', err);
        this.showToast('Unable to start feedback. Please try again.', 'danger');
        this.showUserForm = true;
      },
      complete: () => {
        this.loading = false;
      }
    });

    return;
  }

  // ORIGINAL OTP FLOW (if you ever turn it back on)
  this.showUserForm = false;
  this.showOtpForm = true;

  this.startResendTimer();

  this.loading = true;
  this.feedbackService.sendOtp(mobile).subscribe({
    next: (res) => {
      if (res.status == 'success') {
        this.showToast('OTP sent successfully.', 'success');
        this.generatedOtpId = res.id;
      }
    },
    error: (err) => {
      console.error('sendOtp failed', err);
      this.showToast('Unable to send OTP. Please try again.', 'danger');
      this.showOtpForm = false;
      this.showUserForm = true;
    },
    complete: () => {
      this.loading = false;
    }
  });
}


  // OTP -> verify -> context -> choose question set -> start survey
  submitOtp(): void {
    if (this.otpForm.invalid) return;

    const mobile = (this.userForm.value.mobile || '').trim();
    const enteredOtp = String(this.otpForm.value.otp || '').trim();
    const id = this.generatedOtpId || '';

    if (!id) {
      this.showToast('Missing OTP request id. Please resend OTP.', 'danger');
      this.otpStatusMessage = 'Missing OTP request id. Please resend OTP.';
      return;
    }

    this.loading = true;
    this.otpStatusMessage = null;

    this.feedbackService
      .verifyOtp(mobile, enteredOtp, id)
      .pipe(
        tap((result) => {
          if (!result.ok) {
            if (result.status === 'sms not found') {
              this.showToast('Invalid OTP. Please check and try again.', 'danger');
              this.otpStatusMessage = 'The OTP you entered is incorrect.';
            } else if (result.status === 'expired') {
              this.showToast('OTP expired. Please request a new OTP.', 'danger');
              this.otpStatusMessage = 'Your OTP has expired. Please resend a new OTP.';
              this.canResendOtp = true;
              if (this.resendTimer) {
                clearInterval(this.resendTimer);
                this.resendTimer = undefined;
              }
            } else {
              this.showToast('Unable to verify OTP. Please try again.', 'danger');
              this.otpStatusMessage = 'Unable to verify OTP. Please try again.';
            }
          }
        }),
        map((result) => {
          if (!result.ok) {
            throw new Error('OTP_INVALID');
          }
          return true;
        }),
        // Call customer context after successful OTP
        switchMap(() =>
          this.feedbackService.getCustomerContext(mobile).pipe(
            tap((ctx) => {
              console.log('📌 CUSTOMER CONTEXT API RESPONSE:', ctx);
            }),
            catchError((err) => {
              console.error('getCustomerContext failed:', err);
              this.showToast('Unable to find your profile. Continuing as a new visitor.', 'success');
              // gracefully continue with POTENTIAL flow
              return of(undefined);
            })
          )
        )
      )
      .subscribe({
        next: (ctx) => {
          if (ctx) this.customerContext = ctx as any;

          const status = (ctx as any)?.status || 'POTENTIAL_CUSTOMER';
          if (status === 'EXISTING_CUSTOMER') {
            this.staticQuestions = this.existingQuestions;
          } else {
            this.staticQuestions = this.potentialQuestions;
          }

          this.startStaticSurvey();
        },
        error: (err) => {
          if (String(err?.message) !== 'OTP_INVALID') {
            console.error('submitOtp flow error', err);
            this.showToast('Unable to start feedback. Please try again.', 'danger');
          }
          this.loading = false;
        },
        complete: () => {
          this.loading = false;
        }
      });
  }

  // Static survey engine
  get currentItem(): StaticQuestion | undefined {
    return this.staticQuestions[this.qIndex];
  }
  get currentOptions(): string[] {
    return this.currentItem?.options ?? [];
  }

  private startStaticSurvey(): void {
    this.showOtpForm = false;
    this.showFeedbackForm = true;

    this.conversationHistory = [];
    this.collectedFeedback = {};
    this.answeredQAList = [];
    this.qIndex = 0;

    this.setQuestionFromCurrentItem();
  }

  private setQuestionFromCurrentItem(): void {
    const item = this.currentItem;
    if (!item) {
      this.completeSurvey();
      return;
    }

    this.currentQuestion = item.text;
    this.currentField = item.id;

    this.configureAnswerValidators(item.id, item);
    this.answerForm.reset();

    // pulse
    this.cdRef.detectChanges();
    const qEl = document.getElementById('question');
    if (qEl) {
      qEl.classList.remove('pulse');
      void (qEl as any).offsetWidth;
      qEl.classList.add('pulse');
    }

    this.focusAnswerAndScroll();
  }

  private configureAnswerValidators(field: string, item?: StaticQuestion): void {
    const ctrl: AbstractControl | null = this.answerForm.get('answer');
    if (!ctrl) return;

    ctrl.clearValidators();

    if (item?.type === 'text' && field === 'final_feedback') {
      // optional text + max words (no required here)
      ctrl.setValidators([this.maxWordsValidator(this.maxWords)]);
      this.wordCount = 0;
    } else {
      // radio choice required
      ctrl.setValidators([Validators.required]);
    }

    ctrl.updateValueAndValidity({ emitEvent: false });
  }

  private maxWordsValidator(max: number): ValidatorFn {
    return (control: AbstractControl) => {
      const text = String(control.value ?? '').trim();
      const words = this.splitWords(text);
      return words.length <= max ? null : { maxWords: { requiredMax: max, actual: words.length } };
    };
  }

  private splitWords(text: string): string[] {
    if (!text) return [];
    return text.split(/\s+/).filter(Boolean);
  }

  updateWordCount(text: string): void {
    const words = this.splitWords(text || '');
    this.wordCount = words.length;
    if (this.currentField === 'final_feedback' && this.wordCount > this.maxWords) {
      const clamped = words.slice(0, this.maxWords).join(' ');
      this.answerForm.patchValue({ answer: clamped }, { emitEvent: false });
      this.wordCount = this.maxWords;
      this.answerForm.get('answer')?.markAsTouched();
    }
  }

  submitAnswer(): void {
    if (this.answerForm.invalid || !this.currentItem) return;

    // Stop mic if on
    if (this.isListening && this.recognition) {
      try { this.recognition.stop(); } catch { }
      this.isListening = false;
    }

    let userAnswer = String(this.answerForm.value.answer || '').trim();

    // Potential Q1 "Others" capture
    if (this.currentField === 'awareness_source' && userAnswer === 'Others') {
      const other = String(this.answerForm.value.otherText || '').trim();
      if (other) {
        userAnswer = `Other: ${other}`;
      }
    }

    // 1) Show in sticky list
    this.answeredQAList.push({
      question: this.currentQuestion,
      answer: userAnswer,
      ui_tag: this.currentField
    });

    // 2) Conversation-like history for persistence
    this.conversationHistory.push({
      role: 'assistant',
      content: this.currentQuestion,
      ui_tag: this.currentField
    });
    this.conversationHistory.push({ role: 'user', content: userAnswer });

    // 3) Collect flat feedback
    this.collectedFeedback[this.currentField] = userAnswer;

    // 4) Next or complete
    this.qIndex++;
    if (this.qIndex >= this.staticQuestions.length) {
      this.completeSurvey();
    } else {
      this.setQuestionFromCurrentItem();
    }
  }

  private completeSurvey(): void {
    this.successMessage = '🎉 Thank you for your feedback!';
    this.showFeedbackForm = false;
    this.finalizeAndPersistFeedback();
  }

  private focusAnswerAndScroll(): void {
    setTimeout(() => {
      const el = this.answerInputRef?.nativeElement;
      if (el) {
        try {
          (el as any).focus?.({ preventScroll: true }) || el.focus();
        } catch {
          el.focus();
        }
        if (typeof (el as HTMLInputElement).setSelectionRange === 'function') {
          const val = (el as HTMLInputElement).value ?? '';
          (el as HTMLInputElement).setSelectionRange(val.length, val.length);
        }
        try {
          el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
        } catch {
          el.scrollIntoView();
        }
      }

      try {
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
      } catch {
        window.scrollTo(0, document.body.scrollHeight);
      }
    }, 100);
  }

  // Toasts
  showToast(message: string, type: 'success' | 'danger' = 'danger', duration = 4000): void {
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = undefined;
    }
    this.toast = { message, type, timestamp: Date.now() };
    this.toastTimer = setTimeout(() => {
      this.toast = null;
      this.toastTimer = undefined;
    }, duration);
  }
  closeToast(): void {
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = undefined;
    }
    this.toast = null;
  }

  // Resend OTP
  startResendTimer(): void {
    this.canResendOtp = false;
    this.resendCountdown = 30;
    if (this.resendTimer) {
      clearInterval(this.resendTimer);
    }
    this.resendTimer = setInterval(() => {
      this.resendCountdown--;
      if (this.resendCountdown <= 0) {
        this.canResendOtp = true;
        clearInterval(this.resendTimer);
        this.resendTimer = undefined;
      }
    }, 1000);
  }

  resendOtp(): void {
    if (!this.canResendOtp) return;

    const mobile = (this.userForm.value.mobile || '').trim();
    this.otpStatusMessage = null;

    this.feedbackService.sendOtp(mobile).subscribe({
      next: (resp) => {
        if (resp?.status?.toLowerCase() === 'success' && resp?.id) {
          this.generatedOtpId = resp.id;
          this.showToast('A new OTP has been sent.', 'success');
        } else {
          this.showToast('Unable to resend OTP. Please try again.', 'danger');
        }
      },
      error: (err) => {
        console.error('Resend sendOtp failed', err);
        this.showToast('Unable to resend OTP. Please try again.', 'danger');
      }
    });

    this.startResendTimer();
  }

  // Speech
  private initSpeech(): void {
    const win = window as any;
    const SR = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SR) {
      this.speechSupported = false;
      return;
    }

    this.speechSupported = true;
    this.recognition = new SR();
    this.recognition.lang = 'en-IN';
    this.recognition.continuous = true;
    this.recognition.interimResults = true;

    this.recognition.onresult = (event: any) => {
      if (this.loading || !this.showFeedbackForm) return;

      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        if (res.isFinal) {
          finalTranscript += res[0].transcript + ' ';
        }
      }
      if (finalTranscript && this.currentField === 'final_feedback') {
        const current = String(this.answerForm.value.answer || '');
        const nextVal = (current + ' ' + finalTranscript).trim();
        this.answerForm.patchValue({ answer: nextVal });
        this.updateWordCount(nextVal);
        this.cdRef.detectChanges();
      }
    };

    this.recognition.onerror = (e: any) => {
      console.error('Speech recognition error:', e);
      this.isListening = false;
      this.showToast('Speech recognition error. Please try again.', 'danger');
      this.cdRef.detectChanges();
    };

    this.recognition.onend = () => {
      this.isListening = false;
      this.cdRef.detectChanges();
    };
  }

  toggleListening(): void {
    if (!this.speechSupported || !this.recognition) return;
    if (this.isListening) {
      try { this.recognition.stop(); } catch { }
      this.isListening = false;
    } else {
      try {
        this.recognition.start();
      } catch (e) {
        console.error('recognition.start() failed:', e);
        this.showToast('Unable to start microphone. Check permissions.', 'danger');
        return;
      }
      this.isListening = true;
    }
  }

  toggleAnswers(): void {
    this.answersExpanded = !this.answersExpanded;
  }

  // Success
  successMessage = '';

  // Persistence
  private finalizeAndPersistFeedback(): void {
    if (this.persisted) return;
    this.persisted = true;

    const mobile = String(this.userForm?.value?.mobile || '').trim();
    const name = String(this.userForm?.value?.name || '').trim();
    const ctx = this.customerContext;

    const profile = ctx?.product_information;
    const pInfo = profile?.[0];

    const userType = ctx?.status;

    const sessionPayload: any = {
      mobile_number: mobile,
      customer_name: name,
      cust_id: ctx?.cust_id ?? null,
      scheme_name: pInfo?.scheme_name ?? null,
      scheme_description: pInfo?.scheme_description ?? null,
      sanction_amount: JSON.stringify(pInfo?.sanction_amount) ?? null,
      disbursed_amount: JSON.stringify(pInfo?.disbursed_amount) ?? null,
      user_type: userType,
      collected_feedback: this.collectedFeedback
    };

    this.feedbackService
      .createFeedbackSession(sessionPayload)
      .pipe(
        switchMap((sessionResp) => {
          const sessionId = sessionResp?.session_id;
          if (!sessionId) {
            throw new Error('SESSION_ID_MISSING');
          }

          this.setSessionCookie(sessionId);

          const stringifyHistory = JSON.stringify(this.conversationHistory);

          // Keep using existing submit method (history). If you extend your API, pass collected_feedback too.
          return this.feedbackService.submitFeedbackConversation(sessionId, stringifyHistory);
        }),
        tap((submitResp) => {
          if (submitResp?.session_id) {
            this.setSessionCookie(submitResp.session_id, submitResp.expires_at);
          }
          this.showToast('Feedback Submitted successfully.', 'success');
        }),
        catchError((err) => {
          console.error('[finalizeAndPersistFeedback] error:', err);
          this.showToast('Feedback submitted, but saving to database failed.', 'danger');
          return of(null);
        })
      )
      .subscribe();
  }

  private setSessionCookie(sessionId: string, expiresAtIso?: string): void {
    const name = 'sidbi_feedback_session';
    const value = encodeURIComponent(sessionId);

    let expires = '';
    if (expiresAtIso) {
      try {
        const d = new Date(expiresAtIso);
        if (!isNaN(d.getTime())) {
          expires = `; expires=${d.toUTCString()}`;
        }
      } catch { }
    }
    if (!expires) {
      const fallback = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      expires = `; expires=${fallback.toUTCString()}`;
    }

    const path = '; path=/';
    const sameSite = '; SameSite=Lax';
    const secure = location.protocol === 'https:' ? '; Secure' : '';

    document.cookie = `${name}=${value}${expires}${path}${sameSite}${secure}`;
  }
}
