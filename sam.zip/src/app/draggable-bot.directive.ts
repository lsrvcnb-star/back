import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appDraggableBot]'
})
export class DraggableBotDirective {
  constructor(private el: ElementRef) {
    this.el.nativeElement.style.position = 'fixed';
    this.el.nativeElement.style.bottom = '20px';
    this.el.nativeElement.style.right = '20px';
    this.el.nativeElement.style.cursor = 'move';
  }

  @HostListener('mousedown', ['$event']) onMouseDown(event: MouseEvent) {
    const element = this.el.nativeElement;
    element.style.zIndex = '1000';

    const shiftX = event.clientX - element.getBoundingClientRect().left;
    const shiftY = event.clientY - element.getBoundingClientRect().top;

    const onMouseMove = (moveEvent: MouseEvent) => {
      element.style.left = moveEvent.pageX - shiftX + 'px';
      element.style.top = moveEvent.pageY - shiftY + 'px';
    };

    document.addEventListener('mousemove', onMouseMove);

    document.addEventListener('mouseup', () => {
      document.removeEventListener('mousemove', onMouseMove);
    }, { once: true });
  }

  @HostListener('dragstart') onDragStart() {
    return false;
  }
}
