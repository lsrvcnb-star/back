import { ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { LoadingService } from './loading.service';
import { delay } from 'rxjs/operators';
import { AccountService } from './account.service';
import { DataService } from './data.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'customerPortal';
  loading: any = false;
  errMsg: any = '';
  spinnerMsg: any = '';
  windows: Window;
  timeout: any;
  logoutTimeout: any;
  timeoutVal: any = 14 * 60 * 1000;
  logoutFlag: any = false;
  listeners: any = {}
  resetFunc: any;
  event_list: any = [
    'mousemove',
    'mousedown',
    'touchstart',
    'click',
    'keypress'
  ]
  private newWindow: Window | null = null;


  constructor(
    private _loading: LoadingService,
    private acct: AccountService,
    private dataService: DataService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
   /*  window.onbeforeunload = function() {
      localStorage.clear();
      return '';
    }; */
   }

  ngOnInit(): void {
    speechSynthesis.cancel();
    
   /*  let appUrl = environment.url + '#/webChat';
    const windowOpened = localStorage.getItem('windowOpened')
    if (!windowOpened) {
      this.newWindow = window.open(appUrl, 'popup', 'width=365, height=610, toolbar=no, location=no,status=no, menubar=no, scrollbars=no, addressbar=no, resizable=no');
      this.cdr.detectChanges();
      localStorage.setItem('windowOpened', 'true');
    } else if (this.newWindow && this.newWindow.closed) {
      this.newWindow = window.open(appUrl, 'popup', 'width=365, height=610, toolbar=no,location=no,status=no,menubar=no,scrollbars=no,addressbar=no,resizable=no');
      this.cdr.detectChanges();
    }

 */


  }

  ngOnDestroy() {
   speechSynthesis.cancel();
  }

}


