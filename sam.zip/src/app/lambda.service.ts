import { Injectable } from '@angular/core';
import { LambdaClient, InvokeCommand } from '@aws-sdk/client-lambda';

@Injectable({
  providedIn: 'root'
})
export class LambdaService {
  private lambdaClient: LambdaClient;

  constructor() {
    this.lambdaClient = new LambdaClient({
      region: 'ap-south-1', // Change to your region
      credentials: {
        // WARNING: Better to use Cognito or temporary credentials
        accessKeyId: 'YOUR_TEMP_ACCESS_KEY',
        secretAccessKey: 'YOUR_TEMP_SECRET_KEY',
        sessionToken: 'YOUR_SESSION_TOKEN' // For temporary credentials
      }
    });
  }

  async invokeLambda(functionName: string, payload: any): Promise<any> {
    try {
      const command = new InvokeCommand({
        FunctionName: functionName,
        Payload: new TextEncoder().encode(JSON.stringify(payload)),
        InvocationType: 'RequestResponse'
      });

      const response = await this.lambdaClient.send(command);

      if (response.Payload) {
        return JSON.parse(new TextDecoder().decode(response.Payload));
      }
      throw new Error('No payload received from Lambda');
    } catch (error) {
      console.error('Lambda invocation error:', error);
      throw error;
    }
  }
}
