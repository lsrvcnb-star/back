import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-voicebot',
  templateUrl: './voicebot.component.html',
  styleUrls: ['./voicebot.component.scss']
})
export class VoicebotComponent implements OnInit {
  aiResponse: string;
  audioUrl: string;

  formData = {
    sessionId: '',
    userId: ''
  };

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
  }

  startVoiceBotStream() {
    const queryParams = {
      sessionId: 'abc123',
      userId: 'user456'
    };

    this.dataService.getVoicebotStream(queryParams).subscribe({
      next: (data) => {
        if (data.text) this.aiResponse = data.text;
        if (data.audioBase64 && data.done) this.playAudioFromBase64(data.audioBase64);
      },
      error: (err) => console.error('Stream error:', err),
      complete: () => console.log('Stream completed')
    });
  }

  playAudioFromBase64(base64Audio: string) {
    const audioBlob = this.base64ToBlob(base64Audio, 'audio/mp3');
    this.audioUrl = URL.createObjectURL(audioBlob); // Used in the template
  }



  base64ToBlob(base64: string, mime: string): Blob {
    const byteCharacters = atob(base64);
    const byteArrays = [];

    for (let i = 0; i < byteCharacters.length; i += 512) {
      const slice = byteCharacters.slice(i, i + 512);
      const byteNumbers = new Array(slice.length);
      for (let j = 0; j < slice.length; j++) {
        byteNumbers[j] = slice.charCodeAt(j);
      }
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    return new Blob(byteArrays, { type: mime });
  }



}
