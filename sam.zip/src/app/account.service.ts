import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(
    private router: Router
  ) { }

  otp_data: any;
  pwd_change: any;
  registerMsg: any;
  egpsEl: any;
  expressEl: any;
  shownEl: any = false;
  showEgps: any = false;
  isGenScoreApplied: any = false;
  isAnnualReviewStatus: any = false;
  isRatingExpired: any = false;
  generateScoreEligibility: any = false;
  isAnnualReviewApplied: any = false;
  showRating: any = false;
  showRatingStatus: any = false;
  showGenScore: any = false;
  showGenScoreStatus: any = false;

  // loan status sidebar option
  egpsStatus: any = false;
  expressStatus: any = false;
  showLoanStatus: any = false;

  login_data: any;

  showEL_sidebar = new BehaviorSubject(false);

  jwtForNotLoggedInUser: any = '';
  
  check_login() {
    let ss: any = JSON.parse(window.sessionStorage.getItem('acctDetails'));
    if (ss) {
      this.egpsEl = ss.egpsEl;
      this.expressEl = ss.expressEl;
      this.showEgps = ss.showEgps;
      this.isGenScoreApplied = ss.isGenScoreApplied;
      this.isAnnualReviewApplied = ss.isAnnualReviewApplied;
      this.isRatingExpired = ss.isRatingExpired;

      this.generateScoreEligibility = ss.generateScoreEligibility;
      this.showLoanStatus = this.expressEl.isLoanInProgress == 'true' 
                          || this.expressEl.isELApplied == 'true'
                          || this.egpsEl.isEGpsApplied == 'true'
                          || this.egpsEl.isEGpsLoanInProgress == 'true';

      this.isAnnualReviewStatus = ss.isAnnualReviewApplied;
    }

    this.login_data = JSON.parse(window.sessionStorage.getItem('acctData'));
    if (!this.login_data && window.location.href.indexOf('feedbackTest') != -1 && window.location.href.indexOf('sso') != -1) {
      this.router.navigate(['login']);
      return false;
    }
    return true;
  }

  deleteLogin() {
    this.otp_data = undefined;
    this.egpsEl = undefined;
    this.expressEl = undefined;
    this.egpsStatus = false;
    this.expressStatus = false;
    this.showLoanStatus = false;
    this.shownEl = false;
    this.showEL_sidebar.next(false);

    window.sessionStorage.removeItem('acctDetails');
    window.sessionStorage.removeItem('acctData');
    this.login_data = undefined;
  }
  
}
