import { Injectable } from '@angular/core';
import { HttpClient, HttpInterceptor, HttpEvent, HttpRequest, HttpHandler, HttpResponse, HttpUserEvent, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { AccountService } from './account.service';
import { LoadingService } from './loading.service';
import { catchError, findIndex, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class DataService implements HttpInterceptor {
  awsURL = 'https://iqzma6ultrufpbv3efk5z4cr6i0zjwyx.lambda-url.ap-south-1.on.aws/'
  private history: string[] = [];
  private sessionId: string;

  constructor(
    private http_client: HttpClient,
    private acct: AccountService,
    private _loading: LoadingService,
    private router: Router,
    private cookieService: CookieService
  ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {


    const storedId = localStorage.getItem('session_id');
    this.sessionId = storedId || this.generateSessionId();
    if (!storedId) {
      localStorage.setItem('session_id', this.sessionId);
    }


    const jwt = window.sessionStorage.getItem("jwt");
    const account = this.acct.otp_data;
    const isLoggedIn = account?.data.jwtToken;
    const url = request.url;


    const white_list: string[] = ["/users/getLoginParams/**",
      "/users/login",
      "/users/getEnterpriseName/**",
      "/users/sendForgotPwdOTP", "/users/verifyOTP", "/users/resendOTP",
      "/users/register", "/users/getLoginParams"];

    const urlKey = url.substring(environment.url.length)
    const isApiUrl = url.startsWith(environment.url);
    if (!white_list.includes(urlKey)) {
      if (isApiUrl && isLoggedIn) {
        request = request.clone({
          setHeaders: { Authorization: `Bearer ${account.data.jwtToken}` }
        });
      }
      else if (!isLoggedIn && this.acct.jwtForNotLoggedInUser == '' && jwt) {
        request = request.clone({
          setHeaders: { Authorization: `Bearer ${JSON.parse(jwt)}` }
        });
      }
    }
    this._loading.setLoading(true, url);
    return next.handle(request)
      .pipe(catchError((err) => {
        if (err.status === 401) {
          window.sessionStorage.clear();
          this.router.navigate(["login"]);
        }
        this._loading.setLoading(false, url);
        throw err;
      }))
      .pipe(map<HttpEvent<any>, any>((evt: HttpUserEvent<any>) => {
        if (evt instanceof HttpResponse) {
          this._loading.setLoading(false, url);
        }
        return evt;
      }));
  }




  streamFromAWS(data: any, language: string, session_id): Observable<any> {
    const chatParam = JSON.stringify({
      
     // target_language: language,
     // inputText: data.input_value,

      prompt: data.input_value,
      session_id: session_id,
      target_language : language

    });

    return this.http_client.post(this.awsURL, chatParam);

  }


  getSessionId(): string {
    return this.sessionId;
  }

  resetSessionId(): void {
    this.sessionId = this.generateSessionId();
    localStorage.setItem('session_id', this.sessionId);
  }


/*    generateSessionId(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  } */

generateSessionId(): string {
  return Array.from({ length: 32 }, () => (Math.floor(Math.random() * 9) + 1).toString()).join('');
}






  addHistory(item: any) {
    this.history = item;
  }

  getHistory(): string[] {
    return this.history;
  }


  get_enterprise_name(data: any) {
    return this.http_client.get(`${environment.url}/users/getEnterpriseName?mobNo=${data.mobNo}&emailId=${data.emailId}`)
  }

  get_captcha() {
    return this.http_client.get(`${environment.url}/users/getCaptcha`)
  }

  login_params() {
    return this.http_client.get(`${environment.url}/users/getLoginParams`)
  }

  login(login_data: any) {
    return this.http_client.post(`${environment.url}/users/login`,
      login_data, { headers: { "Content-Type": "application/json" } })
  }

  account_details(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/getAccountDetails/${cif_no}`)
  }

  fd_details(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/getFDDetails/${cif_no}`)
  }

  get_branch_acct_data(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/getBranchAndAcctData/${cif_no}`)
  }

  getTemplateData() {
    return this.http_client.get(`${environment.url}/oa/getTemplateData`)
  }

  account_list(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/getListOfAccount/${cif_no}`)
  }

  file_upload(form_data: any) {
    return this.http_client.post(`${environment.url}/oa/addFile`, form_data);
  }

  delete_file(form_data: any) {
    return this.http_client.post(`${environment.url}/oa/deleteFile`, form_data);
  }

  submit_files(form_data: any) {
    return this.http_client.post(`${environment.url}/oa/submitFiles`, form_data);
  }

  get_wc_acct_nos(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/getWCAccountNumbers/${cif_no}`)
  }

  get_ss_period(acct_no: any) {
    return this.http_client.get(`${environment.url}/oa/getStockStatementPeriods/${acct_no}`)
  }

  get_alerts(cif_no: any, wc_acct_no: any) {
    return this.http_client.get(`${environment.url}/oa/getAlertData/${cif_no}/${wc_acct_no}`)
  }

  register(data: any) {
    return this.http_client.post(`${environment.url}/users/register`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  verify_otp(data: any) {
    return this.http_client.post(`${environment.url}/users/verifyOTP`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  send_digital_sign_otp(data: any) {
    return this.http_client.post(`${environment.url}/oa/sendDigitalSignOtp`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  verify_digital_sign_otp(data: any) {
    return this.http_client.post(`${environment.url}/oa/verifyDigitalSignOTP`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  verify_login_otp(data: any) {
    return this.http_client.post(`${environment.url}/users/verifyLoginOTP`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  resend_otp(data: any) {
    return this.http_client.post(`${environment.url}/users/resendOTP`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  logout(data: any) {
    return this.http_client.post(`${environment.url}/users/logout`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  change_password(data: any) {
    return this.http_client.post(`${environment.url}/users/changePassword`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  forgot_pwd_otp(data: any) {
    return this.http_client.post(`${environment.url}/users/sendForgotPwdOTP`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  forgot_pwd_submit(data: any) {
    return this.http_client.post(`${environment.url}/users/forgotPasswordSubmit`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  verify_el_eligibility(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/verifyELEligibility/${cif_no}`)
  }

  kyc_eligibility(data: any) {
    return this.http_client.post(`${environment.url}/oa/getKYCEligibilityStatus`, data)
  }

  egpsEligibility(cif_no: any) {
    return this.http_client.get(
      `${environment.url}/oa/verifyEgpsEligibilityStatus/${cif_no}`)
  }

  storeExpressLoanData(data: any) {
    return this.http_client.post(`${environment.url}/oa/storeExpressLoanData`, data)
  }

  storeEgpsLoanData(data: any) {
    return this.http_client.post(`${environment.url}/oa/storeEGpsLoanData`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  storeGenerateScoreData(data: any) {
    return this.http_client.post(`${environment.url}/oa/generateScore`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  fetchOplUri(data: any) {
    return this.http_client.post(`${environment.url}/oa/fetchOplURI`,
      data, { headers: { "Content-Type": "application/json" } })
  }

  fetchExpressLoanData(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/fetchExpressLoanData/${cif_no}`)
  }

  addAuditUploadReport(data: any) {
    return this.http_client.post(`${environment.url}/oa/addAuditUploadReport`, data);
  }

  deleteAuditUploadReport(data: any) {
    return this.http_client.post(`${environment.url}/oa/deleteAuditUploadReport`, data);
  }

  submitAuditUploadReport(data: any) {
    return this.http_client.post(`${environment.url}/oa/submitAuditUploadReport`, data);
  }

  fetchInsuranceData(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/fetchInsuranceData/${cif_no}`);
  }

  addInsuranceRequest(data: any) {
    return this.http_client.post(`${environment.url}/oa/addInsuranceRequest`, data);
  }

  deleteInsuranceRequest(data: any) {
    return this.http_client.post(`${environment.url}/oa/deleteInsuranceRequest`, data);
  }

  saveDisbursementDetails(data: any) {
    return this.http_client.post(`${environment.url}/oa/saveDisbursementDetails`, data);
  }

  removeUndeclaredDisbursementDetails(data: any) {
    return this.http_client.post(`${environment.url}/oa/removeUndeclaredDisbursementDetails`, data);
  }

  deleteDisbursementDetails(data: any) {
    return this.http_client.post(`${environment.url}/oa/deleteDisbursementDetails`, data);
  }

  addDisbursementUploadModule(data: any) {
    return this.http_client.post(`${environment.url}/oa/addDisbursementUploadModule`, data);
  }

  deleteDisbursementUploadModule(data: any) {
    return this.http_client.post(`${environment.url}/oa/deleteDisbursementUploadModule`, data);
  }

  getBeneficiaries(accNo: any) {
    return this.http_client.get(`${environment.url}/oa/getBeneficiaries/${accNo}`);
  }

  getKYCData(cif_no: any) {
    return this.http_client.get(`${environment.url}/oa/getKYCData/${cif_no}`);
  }

  getDocData(data: any) {
    return this.http_client.get(`${environment.url}/oa/getDocData?cifNo=${data.cifNo}&moduleFlag=${data.moduleFlag}&accountNumber=${data.accountNumber}`);
  }

  submitEsign(data: any) {
    return this.http_client.post(`${environment.url}/oa/submitEsign`, data);
  }

  submitFeedback(data: any) {
    return this.http_client.post(`${environment.url}/oa/submitFeedback`, data);
  }

  submitFeedbackTesting(data: any) {
    return this.http_client.post(`${environment.url}/oa/submitFeedbackTesting`, data);
  }

  getAllFeedback(cifId: any) {
    return this.http_client.get(`${environment.url}/oa/getAllFeedback?cifId=${cifId}`);
  }

  getFeedbacksById(feedbackId: any) {
    return this.http_client.get(`${environment.url}/oa/getFeedbackById?feedbackId=${feedbackId}`);
  }

  getFeedbackData(feedbackId: any) {
    return this.http_client.get(`${environment.url}/oa/getFeedbackData?feedbackId=${feedbackId}`);
  }

  submitFeedbackResponse(data: any) {
    return this.http_client.post(`${environment.url}/oa/submitFeedbackResponse`, data);
  }

  getDecryptedValue(data: any) {
    return this.http_client.get(`${environment.url}/oa/getDecryptedValue/${data}`)
  }
  user_valid() {
    return this.http_client.post(environment + 'login-1.0/uservalid', {
      'userName': this.cookieService.get("UserID"),
      'authToken': this.cookieService.get("authToken")
    })
  }
  ssoLogin(login_data: any) {
    return this.http_client.post(environment + "login-1.0/login", {
      "userName": login_data['userName'],
      "password": login_data['password'],
      "capId": login_data['capId'],
      "capText": login_data['capText'],
      "redirectUrl": "http://localhost:8443/"
    });
  }

  ssoLogout() {
    return this.http_client.delete(environment + 'login-1.0/deluser', {
      'body': { 'userName': this.cookieService.get("UserID") }
    })
  }

  captcha() {
    return this.http_client.post(environment + 'login-1.0/getCaptcha', {
      'userName': ''
    })
  }

  getAssistResponse(flowId, data) {
    return this.http_client.post('http://127.0.0.1:7860/api/v1/run/' + flowId, data)
  }

  /*  getAssistResponseFromAWS(data, language) {
     const auth_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhZGRpdGlvbmFsX3NpdGVzIjpbXSwiYm90X3N0YXR1cyI6bnVsbCwiY2hhdGJvdF9sb2dvX3VybCI6bnVsbCwiY2hhdGJvdG5hbWUiOiJTSURCSSBBSSBBc3Npc3QiLCJjcmVhdGVkQXQiOiIyMDI1LTA2LTE3VDA0OjQ0OjIzLjIyOFoiLCJjdXN0b21lciI6IlNJREJJIiwiZG9jcyI6bnVsbCwiZXhwaXJ5X2RhdGV0aW1lIjpudWxsLCJndWFyZHJhaWxzIjoiWW91IGFyZSBhIHBvbGl0ZSBhbmQgaG9uZXN0IGNoYXRib3QsIHdobyByZXNwb25kcyB0byBxdWVyaWVzIHdpdGggZW1wYXRoeS4iLCJpZCI6IjI4OWZhMWRmLWE5Y2UtNDAyYS1hMTlkLTY3NjFmMWVkOGVhZiIsImluaXRpYWxfdGV4dCI6IkhlbGxvLCBJIGFtIFFDaGF0LiBIb3cgY2FuIEkgaGVscCB5b3U_IiwicWNoYXRmb3JtX3N0YXR1cyI6IlN1Ym1pdHRlZCIsInJlcXVlc3Rlcl9lbWFpbCI6ImF2dnlzYXBAZ21haWwuY29tIiwidG9rZW4iOm51bGwsInVwZGF0ZWRBdCI6IjIwMjUtMDYtMTdUMDQ6NDQ6MjMuMjI4WiIsIndlYnNpdGUiOiJodHRwczovL3d3dy5zaWRiaS5pbiIsInJlZ2lvblEiOm51bGwsImFwcGxpY2F0aW9uSWRRIjoiZTIzM2IyYTEtYzBmOC00MGYyLWI5NDAtZTcyOGUxNzk2NjE5IiwiaWF0IjoxNzUwMTM1NDY1LCJleHAiOjE3NTA3NDAyNjV9.E9w_0UYoL3bOiXpkKb9UDlFI4t1Dhj_vjlLtu7E65Bc';
 
 
     const params = new HttpParams()
       .set('chat','{"conversationId":"","parentMessageId":"","userMessage":"About SIDBI","clientToken":"d33645c0-5790-4f7c-bc53-2ad1c8180bf8"}')
         .set('stream', 'true')
         .set('isSpeakerEnabled', 'false')
         .set('translationLanguage', language);
 
     const headers = new HttpHeaders({
       'Content-Type': 'application/json',
       'Authorization': `Bearer ${auth_token}`
     });
 
     return this.http_client.get(this.awsURL, { params, headers });
   }
  */



  getVoicebotStream(params: { [key: string]: string }): Observable<{ text?: string; audioBase64?: string; done?: boolean }> {
    const auth_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhZGRpdGlvbmFsX3NpdGVzIjpbXSwiYm90X3N0YXR1cyI6bnVsbCwiY2hhdGJvdF9sb2dvX3VybCI6bnVsbCwiY2hhdGJvdG5hbWUiOiJTSURCSSBBSSBBc3Npc3QiLCJjcmVhdGVkQXQiOiIyMDI1LTA2LTE3VDA0OjQ0OjIzLjIyOFoiLCJjdXN0b21lciI6IlNJREJJIiwiZG9jcyI6bnVsbCwiZXhwaXJ5X2RhdGV0aW1lIjpudWxsLCJndWFyZHJhaWxzIjoiWW91IGFyZSBhIHBvbGl0ZSBhbmQgaG9uZXN0IGNoYXRib3QsIHdobyByZXNwb25kcyB0byBxdWVyaWVzIHdpdGggZW1wYXRoeS4iLCJpZCI6IjI4OWZhMWRmLWE5Y2UtNDAyYS1hMTlkLTY3NjFmMWVkOGVhZiIsImluaXRpYWxfdGV4dCI6IkhlbGxvLCBJIGFtIFFDaGF0LiBIb3cgY2FuIEkgaGVscCB5b3U_IiwicWNoYXRmb3JtX3N0YXR1cyI6IlN1Ym1pdHRlZCIsInJlcXVlc3Rlcl9lbWFpbCI6ImF2dnlzYXBAZ21haWwuY29tIiwidG9rZW4iOm51bGwsInVwZGF0ZWRBdCI6IjIwMjUtMDYtMTdUMDQ6NDQ6MjMuMjI4WiIsIndlYnNpdGUiOiJodHRwczovL3d3dy5zaWRiaS5pbiIsInJlZ2lvblEiOm51bGwsImFwcGxpY2F0aW9uSWRRIjoiZTIzM2IyYTEtYzBmOC00MGYyLWI5NDAtZTcyOGUxNzk2NjE5IiwiaWF0IjoxNzUwMTM1NDY1LCJleHAiOjE3NTA3NDAyNjV9.E9w_0UYoL3bOiXpkKb9UDlFI4t1Dhj_vjlLtu7E65Bc';
    const chatParam = JSON.stringify({
      conversationId: '',
      parentMessageId: '',
      userMessage: 'About SIDBI',
      clientToken: 'd33645c0-5790-4f7c-bc53-2ad1c8180bf8'
    });
    const fullUrl = `${this.awsURL}?chat=${encodeURIComponent(chatParam)}&stream=true&isSpeakerEnabled=false&translationLanguage=en`;
    ;

    return new Observable(observer => {
      const eventSource = new EventSource(fullUrl);

      let fullText = '';
      let audioChunks: string[] = [];

      eventSource.onmessage = (event) => {
        const data = event.data;

        if (data.startsWith('[START]') || data.startsWith('[COMPLETE]')) return;
        if (data.startsWith('[AUDIO]')) return;

        if (data.startsWith('data:')) {
          const content = data.replace('data:', '').trim();

          if (content.startsWith('//Nkx')) {
            audioChunks.push(content);
          } else {
            fullText += content + ' ';
            observer.next({ text: fullText.trim() });
          }
        }

        if (data.startsWith('[END]')) {
          const audioBase64 = audioChunks.join('');
          observer.next({ text: fullText.trim(), audioBase64, done: true });
          observer.complete();
          eventSource.close();
        }
      };

      eventSource.onerror = (error) => {
        observer.error(error);
        eventSource.close();
      };
    });
  }



}
