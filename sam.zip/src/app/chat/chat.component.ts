import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Output,
  ViewChild,
} from '@angular/core';
import { DataService } from '../data.service';
import { DomSanitizer } from '@angular/platform-browser';

declare var webkitSpeechRecognition: any;

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],
})
export class ChatComponent {
  @ViewChild('endOfChat') endOfChat: ElementRef;
  @Output() close = new EventEmitter<void>();
  @Output() runScripts = new EventEmitter<void>();
  @Output() onClickOfResize = new EventEmitter<void>();

  chatHistory: any[] = [];
  userInput = '';
  enableLoader = false;
  isListening = false;
  isEnableSpeakerBtn = false;
  speakingIndicator = false;
  tempMicTTS = false;

  dropdownOpen = false;

  recognition: any;
  selectedOption: string = 'en';
  selectedVoiceLang: string = 'en-US';

  languages = [
    { language: 'English', code: 'en' },
    { language: 'Hindi', code: 'hi' },
    { language: 'Tamil', code: 'ta' },
    { language: 'Telugu', code: 'te' },
    { language: 'Bengali', code: 'bn' },
    { language: 'Gujarati', code: 'gu' },
    { language: 'Kannada', code: 'kn' },
    { language: 'Malayalam', code: 'ml' },
    { language: 'Marathi', code: 'mr' },
    { language: 'Punjabi', code: 'pa' },
    { language: 'Urdu', code: 'ur' },
    { language: 'Sinhala', code: 'si' },
  ];
  isWindowResize: boolean = false;
  isChromeBrowser: boolean = false;
  storedSessionId: string;

  constructor(
    private dataService: DataService,
    private cdRef: ChangeDetectorRef,
    private sanitizer: DomSanitizer
  ) {

    const isWindows = navigator.userAgent.includes('Windows');
    const isEdge = navigator.userAgent.includes('Edg');
    const isSpeechAvailable =
      'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;

    if (isWindows && isEdge && isSpeechAvailable) {
      console.log('🎤 Mic recognition should work in Edge on this Windows system');
    } else {
      console.warn('❌ Voice recognition not supported. Recommend using Chrome.');
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }
    this.recognition = new SpeechRecognition();

    this.recognition.lang = 'en-US';
    this.recognition.interimResults = false;
    this.recognition.maxAlternatives = 1;

    this.recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      switch (event.error) {
        case 'no-speech':
          alert('No speech detected. Please try again.');
          break;
        case 'audio-capture':
          alert('Microphone not found. Please check your mic settings.');
          break;
        case 'not-allowed':
          alert('Microphone access denied. Please allow microphone permissions.');
          break;
        default:
          alert('Speech recognition error. Please try again.');
      }
      this.isListening = false;
      this.cdRef.detectChanges();
    };


    this.recognition.onend = () => {

      setTimeout(() => {
        this.isListening = false;
        this.cdRef.detectChanges();
      }, 500);

    };
  }

  ngOnInit() {


    // speechSynthesis.onvoiceschanged = () => {
    const voices = speechSynthesis.getVoices();
    console.log('Available voices:', voices);
    // };

    this.storedSessionId = localStorage.getItem('session_id');

    const ua = navigator.userAgent;
    const isChrome = /Chrome/.test(ua) && /Google Inc/.test(navigator.vendor) && !/Edg/.test(ua);
    this.isChromeBrowser = isChrome;


    const history = this.dataService.getHistory();
    if (history?.length) {
      this.chatHistory = history;
      this.scrollBottom();
    } else {
      this.enableLoader = true;
      setTimeout(() => {

        const now = new Date();
        const botMsg = {
          id: this.chatHistory.length + 1,
          user: 'Assist',
          chatText: this.sanitizer.bypassSecurityTrustHtml('Hello! I\'m your virtual assistant. How may I assist you today?'),
          timestamp: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
        };
        this.chatHistory.push(botMsg);
        this.scrollBottom();
        this.enableLoader = false;
        this.speakLastResponse(false)
      }, 2000)
    }
  }

  ngOnDestroy() {
    localStorage.removeItem('windowOpened');
    this.dataService.addHistory(this.chatHistory);
    if (speechSynthesis.speaking) speechSynthesis.cancel();
  }

  closeChat() {
    this.close.emit();
    if (speechSynthesis.speaking) speechSynthesis.cancel();
  }

  startListening(event: Event) {
    if (speechSynthesis.speaking) speechSynthesis.cancel();
    if (!this.isListening) {
      this.recognition.start();
      this.isListening = true;

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        this.userInput = transcript;
        this.tempMicTTS = true;
        this.submitResponse(event);
        this.isListening = false;
      };
    } else {
      this.recognition.stop();
      this.isListening = false;
    }
  }


  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  submitResponse(event: Event) {
    const response = this.userInput.trim();
    if (!response) return;

    const now = new Date();
    const userMsg = {
      id: this.chatHistory.length + 1,
      user: 'UserName',
      chatText: response.replace(/\n/g, '<br>'),
      timestamp: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
    };
    this.chatHistory.push(userMsg);
    this.scrollBottom();

    this.enableLoader = true;
    this.userInput = '';
    this.cdRef.detectChanges();

    const reqObject = {
      input_value: response,
      output_type: 'chat',
      input_type: 'chat',
    };

    this.dataService.streamFromAWS(reqObject, this.selectedOption, this.storedSessionId).subscribe(
      (res: any) => {



        try {
  // Convert newlines to <br> and escape backslashes
  const replaceNewLine = res?.['response']
    .replace(/(\n\s*)+/g, '<br>')
    .replace(/\n/g, '<br>')
    .replace(/\\n/g, '<br>');

  // Convert plain URLs to clickable links
  const urlRegex = /(https?:\/\/[^\s<]+)/g;
const convertUrlsToLinks = (text: string): string => {
  return text.replace(urlRegex, (url) => {
    return `<a href="#" onclick="window.open('${url}', '_blank')" style="color: blue; text-decoration: underline;">${url}</a>`;
  });
};


  const withLinks = convertUrlsToLinks(replaceNewLine);
  const final = withLinks.replace(/\\/g, '');

  const disclaimerRegex = /(?:&\s?#)?Disclaimer:/i;
  const match = final.match(disclaimerRegex);
  let end = '';
  let extrime = '';

  const allCitations = res?.citations || [];
  const seenUris = new Set();
  const filteredCitations: any[] = [];

  const normalizeDomain = (url: string): string => {
    const parsed = new URL(url);
    let domain = parsed.hostname.replace(/^www\./, '');
    return `${domain}${parsed.pathname}`;
  };

  const uniqueCitations = allCitations.filter((citation: any) => {
    if (citation.uri !== 'N/A') {
      const normalized = normalizeDomain(citation.uri);
      if (seenUris.has(normalized)) return false;
      seenUris.add(normalized);
      return true;
    }
    return false;
  });

  for (const citation of uniqueCitations) {
    const url = citation.uri;
    const parsed = new URL(url);
    const domain = parsed.hostname.replace(/^www\./, '');
    const path = parsed.pathname;

    if (domain === 'sidbi.in') {
      if (path.includes('/en/')) {
        filteredCitations.push(citation);
      }
    } else {
      filteredCitations.push(citation);
    }
  }

  // Build citation HTML
  let citationHtml = `<div style="font-weight: bold">Sources: </div><div><a href="${res.reference_uri}" target="_blank">${res.reference_uri}</a></div>`;

  if (match && match.index !== undefined) {
    const disclaimerStart = match.index;
    const beforeDisclaimer = final.substring(0, disclaimerStart);
    const disclaimerText = final.substring(disclaimerStart + match[0].length);
    end = `${beforeDisclaimer}<br><span style="font-size: smaller;"><strong>Disclaimer:</strong>${disclaimerText}</span>${citationHtml}`;
    extrime = end.replace(/(\n\s*)+/g, '');
  } else {
    extrime = `${final}`;
  }

  const now = new Date();
  
console.log('Rendered HTML:', extrime);

  let responseObj = {
    id: this.chatHistory.length + 1,
    user: 'Assist',
    chatText: this.sanitizer.bypassSecurityTrustHtml(extrime),
    timestamp: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
  };

  this.chatHistory.push(responseObj);
  this.scrollBottom();
  this.enableLoader = false;
  if (this.isEnableSpeakerBtn || this.tempMicTTS) {
    this.speakLastResponse(this.tempMicTTS);
  }

  this.cdRef.detectChanges();
  setTimeout(() => this.runScripts.emit(), 1000);

} catch (e) {
  console.warn('Invalid JSON:', e);
}


      },
      () => {
        const errorMsg = {
          id: this.chatHistory.length + 1,
          user: 'Assist',
          chatText: 'Sorry, Something went Wrong',
          timestamp: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
        };
        this.chatHistory.push(errorMsg);
        this.scrollBottom();
        this.enableLoader = false;
        this.cdRef.detectChanges();
      }
    );
  }

  speakLastResponse(isMicTriggered = false) {
    const last = [...this.chatHistory].reverse().find(m => m.user === 'Assist');
    if (!last) return;

    const plainText = this.stripHtmlTags(last.chatText);
    const utterance = new SpeechSynthesisUtterance(plainText);
    utterance.lang = this.mapLangCode(this.selectedOption);

    this.speakingIndicator = true;
    this.cdRef.detectChanges();

    utterance.onend = () => {
      this.speakingIndicator = false;

      // If speaker was OFF but user used mic — turn off again
      if (isMicTriggered && !this.isEnableSpeakerBtn) {
        this.tempMicTTS = false;
      }

      this.cdRef.detectChanges();
    };

    utterance.onerror = () => {
      this.speakingIndicator = false;
      this.cdRef.detectChanges();
    };

    speechSynthesis.speak(utterance);
  }

  onClickSpeaker() {
    this.isEnableSpeakerBtn = !this.isEnableSpeakerBtn;
    if (speechSynthesis.speaking) speechSynthesis.cancel();
    else if (this.isEnableSpeakerBtn) this.speakLastResponse();
  }

  scrollBottom() {
    setTimeout(() => {
      if (this.endOfChat) this.endOfChat.nativeElement.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }

  onDropdownChange(event: any) {
    this.dropdownOpen = false;
    this.selectedOption = event;
  }

  stripHtmlTags(html: any): string {
    let rawText = '';

    if (typeof html === 'string') {
      rawText = html;
    } else if (html?.changingThisBreaksApplicationSecurity) {
      rawText = html.changingThisBreaksApplicationSecurity;
    } else {
      return '';
    }


    // Replace real HTML Sources section with a placeholder
    rawText = rawText.replace(/<div[^>]*>Sources:\s*<\/div>[\s\S]*?(<div[^>]*>.*?<\/div>)+/gi, ' For more details, please check the source section.');


    // Remove all remaining HTML tags
    return rawText.replace(/<[^>]*>/g, '');
  }


  mapLangCode(code: string): string {
    const langMap: { [key: string]: string } = {
      en: 'en-US', hi: 'hi-IN', ta: 'ta-IN', te: 'te-IN',
      bn: 'bn-IN', gu: 'gu-IN', kn: 'kn-IN', ml: 'ml-IN',
      mr: 'mr-IN', pa: 'pa-IN', ur: 'ur-IN', si: 'si-LK',
    };
    return langMap[code] || 'en-US';
  }

  convertTextToHtmlLists(text: string): string {
    const numberedRegex = /(\d+\.\s.*?)(?=\d+\.\s|$)/gs;
    const numberedMatches = text.match(numberedRegex);
    if (numberedMatches?.length > 1) {
      let olHtml = '<ol>';
      numberedMatches.forEach(i => olHtml += `<li>${i.replace(/^\d+\.\s/, '').trim()}</li>`);
      olHtml += '</ol>';
      text = text.replace(numberedMatches.join(''), olHtml);
    }

    const bulletRegex = /([•*-]\s.*?)(?=[•*-]\s|$)/gs;
    const bulletMatches = text.match(bulletRegex);
    if (bulletMatches?.length > 1) {
      let ulHtml = '<ul>';
      bulletMatches.forEach(i => ulHtml += `<li>${i.replace(/^[•*-]\s/, '').trim()}</li>`);
      ulHtml += '</ul>';
      text = text.replace(bulletMatches.join(''), ulHtml);
    }

    return text;
  }

  resize() {
    this.isWindowResize = !this.isWindowResize;
    this.scrollBottom();
    this.onClickOfResize.emit();

  }
}




