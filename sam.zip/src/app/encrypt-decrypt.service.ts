import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class EncryptDecryptService {
  private secretKey = 'nauxwmoaxcsknlwbjrlftciy';

  private async getKey(): Promise<CryptoKey> {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(this.secretKey);
    const hash = await crypto.subtle.digest('SHA-256', keyData);
    const aesKey = hash.slice(0, 16); // AES-128
    return crypto.subtle.importKey('raw', aesKey, { name: 'AES-GCM' }, false, [
      'encrypt',
      'decrypt',
    ]);
  }

  async encrypt(plainText: string): Promise<string> {
    const key = await this.getKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const data = encoder.encode(plainText);

    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );

    const combined = new Uint8Array(iv.length + encrypted.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(encrypted), iv.length);

    const base64 = btoa(String.fromCharCode(...combined));
    return base64.replace(/\+/g, 'SIDBI').replace(/\//g, 'SLASHED');
  }

  async decrypt(encryptedText: string): Promise<string> {
    const key = await this.getKey();
    const normalized = encryptedText
      .replace(/SIDBI/g, '+')
      .replace(/SLASHED/g, '/');
    const combined = Uint8Array.from(atob(normalized), (c) => c.charCodeAt(0));

    const iv = combined.slice(0, 12);
    const data = combined.slice(12);

    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );
    const decoder = new TextDecoder();
    return decoder.decode(decrypted);
  }
}