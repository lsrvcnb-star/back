import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { DataService } from '../data.service';
import { SHA256 } from 'crypto-js';
import { Router } from '@angular/router';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  login_params_data: any;

  domState: any = {
    displayErr: false,
    errorText: 'Something went wrong!',
    errMsgClasses: ['login_msg', 'error_login'],
    loginErrText: '',
    regErrMsg: '',
    nameOptions: []
  }
  force_login_modal_key: boolean = false;
  form: { loginId: string; password: string; userCaptcha: string; systemCaptcha: any; encriptPassFirst: any; encriptPassSecond: any; forceLogin: boolean; };

  constructor(
    private DataService: DataService,
    private router: Router,
    private acct: AccountService,
  ) { }

  ngOnInit(): void {
    let z: any = document.body.style;
    z.zoom = 1;
    
    if (window.sessionStorage.getItem('acctData') != null) this.router.navigate(["accountDetails"]);

    if (this.acct.pwd_change != undefined) {
      setTimeout(() => {
        this.domState.errorText = this.acct.pwd_change;
        this.domState.errMsgClasses = ['login_msg'];
        this.domState.displayErr = true;
      }, 0)
    }

    if (this.acct.registerMsg != undefined) {
      setTimeout(() => {
        this.domState.errorText = this.acct.registerMsg;
        this.domState.errMsgClasses = ['login_msg'];
        this.domState.displayErr = true;
      }, 0)
    }

    this.login_params();
  }

  @HostListener('unloaded')
  ngOnDestroy(): void {
    this.acct.pwd_change = undefined;
    this.acct.registerMsg = undefined;
  }

  validateEmail(e: any) {
    let filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9_\-\.])+\.)+([a-zA-Z0-9_\-\.]{2,4})+$/;
    if (!filter.test(e)) {
      let el = document.getElementById("emailId")! as HTMLInputElement
    	el.value = "";
      document.getElementById("emailError2")!.style.display = "block";
    	el.focus;
    	return false;
    }
    document.getElementById("emailError2")!.style.display = "none";
    return true;
  }

  checkUser(e: any) {
    let email = (document.getElementById("emailId") as any).value;
    if (this.validateEmail(email)) {
      let mobNo = document.getElementById("mobNo")! as HTMLInputElement;
      
      // clear enterprise name dropdown data
      this.domState.nameOptions = [];
      this.domState.regErrMsg = '';

      this.DataService.get_enterprise_name({
        "mobNo": mobNo.value,
        "emailId": email
      }).subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.domState.regErrMsg = '';
          this.domState.nameOptions = data.data;
        } else if (data.statusCode == 400) {
          if (data.errorMap) {
            this.domState.regErrMsg = data.errorMap.mobNo;
          } else if (data.message) {
            this.domState.regErrMsg = data.message;
          }
        }
      }, (error: any) => {
        if (error.errorMap) {
          this.domState.regErrMsg = error.errorMap.mobNo;
        } else if (error.message) {
          this.domState.regErrMsg = error.error.message;
        }
      })
      return true;
    } 
    return false;
  }

  Register(e: any, form: any) {
    let value = form;
    
    if (value == 'Register') {
      let firstName = (document.getElementById("firstName") as HTMLSelectElement).value;
      if (firstName.trim() == '') {
        this.domState.regErrMsg = 
        "Account not eligible for registration. Please contact bank or Relationship Manager.";
				document.getElementById("firstName")!.focus();
				return false;
      }
      else if (firstName == 'Enterprise Name') {
        this.domState.regErrMsg = 
        "please select the enterprise name.";
				document.getElementById("firstName")!.focus();
				return false;
      }
    
      let emailId = (document.getElementById("emailId")! as HTMLInputElement).value; 
      let atposition = emailId.indexOf("@");  
      let dotposition = emailId.lastIndexOf("."); 
      if(emailId.trim() == ''){
        this.domState.regErrMsg = "Please Enter Email Id...";
        document.getElementById("emailId")!.focus();
        return false;
      }
        
      if (atposition < 1 || dotposition < atposition + 2 || dotposition + 2 >= emailId.length){  
        this.domState.regErrMsg = "Please enter a valid e-mail address";  
        return false;  
      }  
        
      let mobNo = (document.getElementById("mobNo")! as HTMLInputElement).value; 			
      if(mobNo.trim() == ''){
        this.domState.regErrMsg = "Please Enter Mobile No ...";
        document.getElementById("mobNo")!.focus();
        return false;
      }
      let n = mobNo.length;
      if (n < 10 || n > 10) {
        this.domState.regErrMsg = "Mobile No. is not valid, Please Enter 10 Digit Mobile No.";
        document.getElementById("mobNo")!.focus();
        return false;
      }
        
      let password = (document.getElementById("regPassword")! as HTMLInputElement).value; 
      if(password.trim() == ''){
        this.domState.regErrMsg = "Please Enter Password...";
        document.getElementById("regPassword")!.focus();
        return false;
      }
        
      let conPassword = (document.getElementById("conPassword")! as HTMLInputElement).value; 
      if(conPassword.trim() == ''){
        this.domState.regErrMsg = "Please Enter Confirm Password...";
        document.getElementById("conPassword")!.focus();
        return false;
      }
        
      if(password.trim() != conPassword.trim()){
        this.domState.regErrMsg = `Password and Confirm Password does not match...`;		
        return false;
      }
      if(conPassword.length <8){
        this.domState.regErrMsg = 
        `Your password should be of minimum eight 
        characters with at least one alphabet, one numeric and one special character`;
        return false;
      }
      let letters =  ".*[A-Za-z].*";
      if(!conPassword.match(letters)) {
        this.domState.regErrMsg = 
        `Your password should be of minimum eight 
        characters with at least one alphabet, one numeric and one special character`;
        return false;
      }
      let number =  ".*[0-9].*";
      if(!conPassword.match(number)) {
        this.domState.regErrMsg = 
        `Your password should be of minimum eight 
        characters with at least one alphabet, one numeric and one special character`;
        return false;
      }
      let specialChar =  ".*[!@#$%&*()_+=|<>?{}\\[\\]~-].*";
      if(!conPassword.match(specialChar)) {
        this.domState.regErrMsg = 
        `Your password should be of minimum eight 
        characters with at least one alphabet, one numeric and one special character`;
        return false;
      }

      let passwordVal = (document.getElementById("conPassword")! as HTMLInputElement).value;
      passwordVal = SHA256(passwordVal).toString();
      let newString1 = this.login_params_data.encriptPassFirst;
      let newString2 = this.login_params_data.encriptPassSecond;
      passwordVal = this.randomString(10) + newString2 + passwordVal + 
                    newString1 + this.randomString(12);
      (document.getElementById("passwordVal")! as HTMLInputElement).value = "";
      
      let ent_cif;
      for (let i = 0; i < this.domState.nameOptions.length; i++) {
        if (this.domState.nameOptions[i].ENTERPRISENAME == firstName)
          ent_cif = this.domState.nameOptions[i].CIFID;
      }

      let register_json: any = {
        userName: `${ent_cif} ${firstName}`,
        confirmPassword: passwordVal,
        encriptPassFirst: this.login_params_data.encriptPassFirst,
        encriptPassSecond: this.login_params_data.encriptPassSecond,
        mobNo: mobNo,
        regPassword: passwordVal,
        emailId: emailId
      }

      this.domState.regErrMsg = '';
      let register_json1 = JSON.stringify(register_json)
      this.DataService.register(register_json1).subscribe((data: any) => {
        if (data.statusCode == 200) {
          if (data.customValues && data.customValues.otpStatus == 'true') {
            this.acct.otp_data = {
            otp_type: 'registration',
            data: data,
            email: emailId
          }
          this.acct.jwtForNotLoggedInUser = data.data;
          this.router.navigate(["otp"]);
          } else {
            this.domState.regErrMsg = data.message;
          }
        } else {
          this.domState.regErrMsg = data.message
        }
        
      })

      return false;
    }
    return false;
  }

  togglePane(letForm: any) {
    this.domState.displayErr = false;
    const reg = document.getElementById("Registration")!;
    const log = document.getElementById("Login")!;
    const reg_tog = document.getElementById('toggle-reg')!;
    const log_tog = document.getElementById('toggle-login')!;

    if (letForm == 'home') {		
      reg.style.display = "none";
      reg_tog.classList.remove('active');
      log.style.display = "block";
      log_tog.classList.add('active');
      
    } else {		
      reg.style.display = "block";
      reg_tog.classList.add('active');
      log.style.display = "none";
      log_tog.classList.remove('active');
    }
  }

  isValidEmail(e: any) {
    
    const pattern = new RegExp("^[a-zA-Z0-9_@.-]+$");
    let inputId = e.target.id;
    if (e.target.value && !pattern.test(e.target.value)) {
      let emailInput = document.getElementById(inputId)! as HTMLInputElement
      emailInput.value = '';
      emailInput.focus;
      return false;
    }
    return true;
  }

  login() {
    if(this.form == undefined){
      let userNameVal = (document.getElementById("userNameVal")! as HTMLInputElement).value; 
    if(userNameVal.trim() == ''){
      this.domState.loginErrText = "Please Enter User Name...";
      document.getElementById("userNameVal")!.focus();
      return false;
    }
    
    let passwordVal = (document.getElementById("passwordVal")! as HTMLInputElement).value; 
    if(passwordVal.trim() == ''){
      this.domState.loginErrText = "Please Enter Password...";
      document.getElementById("passwordVal")!.focus();
      return false;
    }
	
    let capVal = (document.getElementById("j_captcha_response")! as HTMLInputElement).value;
    if(capVal == ''){
      alert("Captcha required!!");
      document.getElementById("j_captcha_response")!.focus();
      return false;
    }
	
    passwordVal = SHA256(passwordVal).toString();
    let newString1 = this.login_params_data.encriptPassFirst;
    let newString2 = this.login_params_data.encriptPassSecond;
    passwordVal = this.randomString(10) + newString2 + 
                  passwordVal + newString1 + this.randomString(12);
    this.form = {
        loginId: userNameVal,
        password: passwordVal,
        userCaptcha: capVal,
        systemCaptcha: this.login_params_data.systemCaptcha,
        encriptPassFirst: this.login_params_data.encriptPassFirst,
        encriptPassSecond: this.login_params_data.encriptPassSecond,
        forceLogin: false
      }
    }

    this.domState.displayErr = false;
    this.DataService.login(this.form).subscribe((data: any) => {
      if (data.statusCode == 200) {
        data = data.data;
        if (data.jwtToken) {
          this.acct.otp_data = {
            otp_type: 'login',
            data: data
          }
          if(data.passwordExpInDays <= 7 &&  data.passwordExpInDays >0){
            document.getElementById("dayLeft")!.innerHTML = ` Please Reset your password within ${data.passwordExpInDays} days.`;
            document.getElementById('resetPaswordPopup')!.click();
            this.router.navigate(["otp"]);
          }
          else if(data.passwordExpInDays == 0){
            document.getElementById("dayLeft")!.innerHTML = ` Please Reset your password today.`;
            document.getElementById('resetPaswordPopup')!.click();
            this.router.navigate(["forgotPassword"])
          }
          else{
            this.router.navigate(["otp"]);
          }    
      }
      } else {
        this.domState.errorText = data.message;
        if(this.domState.errorText == 'Your last session is either currently active or closed abnormally, Do you want to login?'){
          document.getElementById('forceLoginPopup')!.click();
          this.domState.errMsgClasses = ['login_msg', 'error_login']
          this.domState.displayErr = false; 
        }
        else{
          this.domState.errMsgClasses = ['login_msg', 'error_login']
          this.domState.displayErr = true;
          this.form = null;
        }
        this.clearFields();
      }
    }, (error: any) => {
      this.domState.errorText = error.error.message;
      this.domState.errMsgClasses = ['login_msg', 'error_login']
      this.domState.displayErr = true;
      this.form = null;
      this.clearFields();
    })
    return false;
  }

  navigate_force_login(e: any) {
    document.getElementById('forceLoginPopup')!.click();
    if(e.target.attributes.id.nodeValue == 'ok'){
      this.form.forceLogin = true;
      this.login();
      this.form = undefined;
    }
  }

  clearFields(){
    (document.getElementById("userNameVal")! as HTMLInputElement).value = "";
    (document.getElementById("passwordVal")! as HTMLInputElement).value = "";
    (document.getElementById("j_captcha_response")! as HTMLInputElement).value ="";
    this.login_params();
  }

  refresh_captcha() {
    let d = new Date();	
    document.getElementById("captchaImage")!.setAttribute("src", "Captcha.jpg?" + d.getTime());
  }

  randomString(length: number) {
    let chars = '0123456789abcdefghijklmnopqrstuvwxyz';
    let result = '';
    for (let i = length; i > 0; --i) {
    	result += chars[Math.floor(Math.random() * chars.length)];
    }
    return result;
  }

  forgot_pwd() {
    this.router.navigate(['forgotPassword']);
  }


  // New

  login_params() {
    // this.domState.displayErr = false;
    this.DataService.login_params().subscribe((data: any) => {
      if (data.statusCode == 200) {
        this.login_params_data = data.data;
        let captcha = document.getElementById('captcha') as HTMLCanvasElement;

        // draw captcha
        let ctx = captcha.getContext('2d');
        ctx!.resetTransform();
        ctx!.clearRect(0, 0, captcha.width, captcha.height);
        let font_size = "30";
        ctx!.textAlign = 'center';
        ctx!.textBaseline = 'middle';
        ctx!.font = `${font_size}px serif`;
        let min = 0;
        let max = 10;
        let angle = Math.random() * (max - min) + min;
        angle *= Math.round(Math.random()) ? 1 : -1;
        angle = angle * Math.PI / 180;
        ctx!.resetTransform();
        ctx!.transform(1, 0, Math.tan(-100), 1, 0, 0);
        ctx!.fillText(this.login_params_data.systemCaptcha, 65, 25, 200);  
      } else {
        this.domState.errorText = data.message;
        this.domState.errMsgClasses = ['login_msg', 'error_login']
        this.domState.displayErr = true;
      }
    }, (error: any) => {
      this.domState.errorText = error.error.message;
      this.domState.errMsgClasses = ['login_msg', 'error_login']
      this.domState.displayErr = true;
    })
  }

}
