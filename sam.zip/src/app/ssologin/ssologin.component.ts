import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CookieService } from 'ngx-cookie-service';
import { DataService } from '../data.service';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';


@Component({
  templateUrl: 'ssologin.component.html',
  styleUrls: ['ssologin.component.scss']
})
export class SsologinComponent implements OnInit {
    feedbackId: string = '';
    form: FormGroup;
    loading = false;
    submitted = false;
    loginError = false;
    returnUrl: string;
    errormessage:string;
    redirectTo:string;
    cookieFound:boolean = false;
    captcha_data: any;
    constructor( 
        private http:HttpClient,     
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private dataService: DataService,
        private _snackBar: MatSnackBar,
        private cookieservice:CookieService,
        private actRoute: ActivatedRoute
        
    ) { }
  
    ngOnInit() {
      this.feedbackId = this.actRoute.snapshot.paramMap.get('feedbackId');
      this.form = this.formBuilder.group({
        username: ['', Validators.required],
        password: ['', Validators.required],
        captcha: ['', Validators.required]
    });
    this.captcha_load();
     
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        this.submitted = true;        
        if (this.form.invalid) {
            return;
        }

        this.loading = true;
        let login_data = {
          'userName': this.f['username'].value,
          'password': btoa(this.f['password'].value),
          'capText': this.f['captcha'].value,
          'capId': this.captcha_data.capId
        }
        this.dataService.ssoLogin(login_data)
        .subscribe((data:any) => {        
          if(data && data.apiResponse){
                  if( data.apiResponse == "Auth Success" || 
                      data.apiResponse == 'User Already Logged In')
                  { 
                    
                    this.loginError = false;
                    this.loading = false;
                    let dateTime = new Date();
                    dateTime.setHours(dateTime.getHours() + 8); 
                    this.cookieservice.set("UserID", 
                                            this.f['username'].value, 
                                            {path: '/', expires:dateTime, 
                                            domain: 'sidbi.in'});
                    this.cookieservice.set("authToken", 
                                            data["authToken"],
                                            {path: '/', expires:dateTime, 
                                            domain: 'sidbi.in'});                    
                   this.router.navigate(['/feedbackTest/'+this.feedbackId]);
           
                  }
                  else if(data.apiResponse.indexOf("49") != -1){
                    this.captcha_load();
                    this.loading = false;
                    this._snackBar.open("Authentication Failed. Username or Password incorrect.", "Close", {
                      duration: 10000
                    });
                  }
                  else if(data.apiResponse.indexOf("775") != -1){
                    this.captcha_load();
                    this.loading = false;
                    this._snackBar.open("Authentication Failed. User locked out. Please contact your system adminitstrator.", "Close", {
                      duration: 10000
                    });
                  }
                  else if(data.apiResponse.indexOf("532") != -1){
                    this.captcha_load();
                    this.loading = false;
                    this._snackBar.open("Authentication Failed. User Password expired. Please contact your system adminitstrator.", "Close", {
                      duration: 10000
                    });
                  }
                  else if(data.apiResponse.indexOf("533") != -1){
                    this.captcha_load();
                    this.loading = false;
                    this._snackBar.open("Authentication Failed. User account is disabled. Please contact your system adminitstrator.", "Close", {
                      duration: 10000
                    });
                  }
                  else if(data.apiResponse.indexOf("525") != -1){
                    this.captcha_load();
                    this.loading = false;
                    this._snackBar.open("Authentication Failed. User not found. Please contact your system adminitstrator.", "Close", {
                      duration: 10000
                    });
                  }
                  else if (data.apiResponse == 'Invalid Captcha') {
                    this.captcha_load();
                    this.loading = false;
                        this._snackBar.open("Invalid Captcha", "Close", {
                          duration: 10000
                        });
                  }
                  // else if(data.apiResponse == 'User Already Logged In'){
                  //   this.loading = false;
                  //       this._snackBar.open("You have alredy logged in to Single-sign-on in a different session. Please logout and retry!!", "Close", {
                  //         duration: 10000
                  //       });
                  // }
                  else if(data.apiResponse == "Auth Failed") {
                    this.captcha_load();
                    this.loading = false;
                    this._snackBar.open("Authentication Failed. Username or Password incorrect.", "Close", {
                      duration: 10000
                    });
                  } 
                  else{
                    this.captcha_load();
                    this.loading = false;
                    this._snackBar.open("Something went wrong. Please retry after sometime.", "Close", {
                      duration: 10000
                    });
                  }
                }  
                },
                error => {
                    if(error.error.apiResponse == "Auth Failed") {
                      this.loading = false;
                      this.captcha_load();
                      this._snackBar.open("Authentication Failed. Username or Password incorrect.", "Close", {
                        duration: 10000
                      });
                    }    
                    else{
                      this.loading = false;
                      this.captcha_load();
                      this._snackBar.open("Something went wrong. Please retry after sometime.", "Close", {
                        duration: 10000
                      });
                    }
                });
    }

    captcha_load() {
      let captcha = document.getElementById('captcha') as HTMLCanvasElement;
      let ctx = captcha.getContext('2d');
      ctx.resetTransform();
      ctx.clearRect(0, 0, captcha.width, captcha.height);
      this.dataService.captcha().subscribe((data: any) => {
        this.captcha_data = data;
        let font_size = "25";
        ctx.font = `${font_size}px serif`;

        let min = 0;
        let max = 10;
        let angle = Math.random() * (max - min) + min;
        angle *= Math.round(Math.random()) ? 1 : -1;
        angle = angle * Math.PI / 180;
        ctx.resetTransform();
        ctx.transform(1, 0, Math.tan(angle), 1, 0, 0);
        ctx.fillText(data.capText, 15, 35);
      })
    }
}