import {
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef
} from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ValidatorFn,
  Validators
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { animate, style, transition, trigger } from '@angular/animations';
import { catchError, first, of, switchMap, tap } from 'rxjs';
import { FeedbackService, ConversationTurn } from '../feedback.service';
import { EncryptDecryptService } from '../encrypt-decrypt.service';

type QuestionType = 'choice' | 'text' | 'matrix';

interface StaticQuestion {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[];
  factors?: string[];
  required?: boolean;
}

interface AnsweredQA {
  question: string;
  answer: string;
  ui_tag?: string;
}

@Component({
  selector: 'app-survey-standard',
  templateUrl: './survey-standard.component.html',
  styleUrls: ['./survey-standard.component.scss'],
  animations: [
    trigger('fadeScale', [
      transition(':enter', [style({ opacity: 0, transform: 'scale(0.9)' }), animate('500ms ease-out', style({ opacity: 1, transform: 'scale(1)' }))]),
      transition(':leave', [animate('400ms ease-in', style({ opacity: 0, transform: 'scale(0.9)' }))])
    ]),
    trigger('expandCollapse', [
      transition(':enter', [style({ height: 0, opacity: 0, overflow: 'hidden' }), animate('260ms ease-out', style({ height: '*', opacity: 1 }))]),
      transition(':leave', [style({ height: '*', opacity: 1, overflow: 'hidden' }), animate('220ms ease-in', style({ height: 0, opacity: 0 }))])
    ])
  ]
})
export class SurveyStandardComponent implements OnInit, OnDestroy {
  showWelcome = true;
  showFeedbackForm = false;
  userName = '';
  mobile = '';
  answerForm!: FormGroup;
  currentQuestion = '';
  currentField = '';
  conversationHistory: ConversationTurn[] = [];
  collectedFeedback: Record<string, string> = {};
  answeredQAList: AnsweredQA[] = [];
  answersExpanded = false;
  loading = false;
  qIndex = 0;
  successMessage = '';
  toast: { message: string; type: 'success' | 'danger'; timestamp: number } | null = null;
  private toastTimer?: any;
  private persisted = false;
  private recognition: any;
  speechSupported = false;
  isListening = false;
  wordCount = 0;
  maxWords = 1000;
  matrixAnswers: Record<string, string> = {};

  @ViewChild('answerInput') answerInputRef!: ElementRef<HTMLInputElement | HTMLTextAreaElement>;

  private readonly ratingImportance = [
    'Speed of Service',
    'Simplified and Easy Application Process',
    'Dedicated Relationship Manager',
    'Interest Rate',
    'Availability of all financial needs under one roof',
    'Timely Disbursal of loan',
    'Security including collateral requirement'
  ];

  private readonly surveyQuestions: StaticQuestion[] = [
    { id: 'customer_code_or_loan_account_number', text: 'Customer Code / Loan Account Number', type: 'text', required: true },
    {
      id: 'awareness_source',
      text: 'How did you come to know about SIDBI?',
      type: 'choice',
      options: ['Internet', 'Through another SIDBI Customer', 'Industry Association', 'Machinery Supplier / OEM', 'Advertisement', 'Website', 'Other'],
      required: true
    },
    { id: 'sole_banker', text: 'Is SIDBI your sole banker?', type: 'choice', options: ['Yes', 'No'], required: true },
    { id: 'information_exchange_guidance', text: 'Please rate your experience with information exchange and the quality of advice / guidance from SIDBI officials.', type: 'choice', options: ['Excellent', 'Very Good', 'Good', 'Fair', 'Poor'], required: true },
    { id: 'official_behavior', text: 'Please rate the behavior of SIDBI officials.', type: 'choice', options: ['Excellent', 'Very Good', 'Good', 'Fair', 'Poor'], required: true },
    { id: 'branch_infrastructure', text: 'Please rate SIDBI’s present branch infrastructure in terms of ambience, facilities and your comfort.', type: 'choice', options: ['Excellent', 'Very Good', 'Good', 'Fair', 'Poor'], required: true },
    { id: 'business_growth', text: 'Do you think SIDBI’s association has led to growth of your business?', type: 'choice', options: ['Positive', 'Yes', 'Maybe', 'Not Sure'], required: true },
    { id: 'public_sector_comparison', text: 'How far ahead or behind is SIDBI over Public Sector Banks?', type: 'choice', options: ['Much Better', 'Better', 'At Par', 'Below Average', 'Poor'], required: true },
    { id: 'private_sector_comparison', text: 'How far ahead or behind is SIDBI over Private Sector Banks?', type: 'choice', options: ['Much Better', 'Better', 'At Par', 'Below Average', 'Poor'], required: true },
    { id: 'future_financial_needs', text: 'Will you approach SIDBI for your future financial needs?', type: 'choice', options: ['Yes', 'No'], required: true },
    { id: 'other_lender_reason', text: 'If no, please provide reasons for preferring another lender over SIDBI.', type: 'text', required: false },
    { id: 'lending_partner_importance', text: 'Rate the following factors which are important when selecting a lending partner on a scale of 1 to 5.', type: 'matrix', factors: this.ratingImportance, options: ['1 - Not Important', '2 - Somewhat Important', '3 - Important', '4 - Very Important', '5 - Critically Important'], required: true },
    { id: 'sidbi_factor_rating', text: 'Please rate SIDBI on all these factors on a scale of 1 to 5.', type: 'matrix', factors: this.ratingImportance, options: ['1 - Poor', '2 - Average', '3 - Good', '4 - Very Good', '5 - Excellent'], required: true },
    { id: 'referral_likelihood', text: 'What is the likelihood of you referring a client to SIDBI?', type: 'choice', options: ['Certainly', 'Very Likely', 'Maybe', 'Less Likely', 'Not at all Likely'], required: true },
    { id: 'overall_service_experience', text: 'Your experience with the overall service of the bank.', type: 'choice', options: ['Excellent', 'Very Good', 'Good', 'Fair', 'Poor'], required: true }
  ];

  staticQuestions = this.surveyQuestions;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private feedbackService: FeedbackService,
    private cdRef: ChangeDetectorRef,
    private encryptDecrypt: EncryptDecryptService
  ) {}

  ngOnInit(): void {
    this.answerForm = this.fb.group({ answer: [''], otherText: [''] });
    this.initSpeech();
    this.route.queryParamMap.pipe(first()).subscribe(async params => {
      const rawName = (params.get('name') || '').trim();
      const rawMobile = (params.get('mobile') || '').trim();
      if (!this.isProbablyEncrypted(rawName) || !this.isProbablyEncrypted(rawMobile)) {
        this.showToast('Invalid link. Please use the secure survey link sent by SIDBI.', 'danger', 6000);
        return;
      }
      try {
        this.userName = await this.decryptStrict(rawName);
        this.mobile = await this.decryptStrict(rawMobile);
      } catch {
        this.showToast('Link appears to be tampered or expired. Please open the secure link again.', 'danger', 6000);
        return;
      }
      if (!/^[6-9]\d{9}$/.test(this.mobile)) {
        this.showToast('Invalid mobile number in secure link.', 'danger', 6000);
        return;
      }
      setTimeout(() => { this.showWelcome = false; this.startSurvey(); }, 500);
    });
  }

  ngOnDestroy(): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    if (this.isListening && this.recognition) { try { this.recognition.stop(); } catch {} }
  }

  get currentItem(): StaticQuestion | undefined { return this.staticQuestions[this.qIndex]; }
  get currentOptions(): string[] { return this.currentItem?.options || []; }
  get currentFactors(): string[] { return this.currentItem?.factors || []; }
  get isMatrix(): boolean { return this.currentItem?.type === 'matrix'; }

  private isProbablyEncrypted(value: string): boolean {
    if (!value) return false;
    let v = value;
    try { v = decodeURIComponent(value); } catch {}
    if (v.includes('SIDBI') || v.includes('SLASHED')) return true;
    const cleaned = v.replace(/SIDBI/g, '+').replace(/SLASHED/g, '/');
    return cleaned.length >= 16 && /^[A-Za-z0-9+/=]+$/.test(cleaned);
  }

  private async decryptStrict(value: string): Promise<string> {
    const normalized = (() => { try { return decodeURIComponent(value); } catch { return value; } })();
    const result = (await this.encryptDecrypt.decrypt(normalized) || '').trim();
    if (!result) throw new Error('DECRYPTED_EMPTY');
    return result;
  }

  private startSurvey(): void {
    this.showFeedbackForm = true;
    this.answeredQAList = [];
    this.conversationHistory = [];
    this.collectedFeedback = {};
    this.qIndex = 0;
    this.setQuestionFromCurrentItem();
  }

  private setQuestionFromCurrentItem(): void {
    const item = this.currentItem;
    if (!item) { this.completeSurvey(); return; }
    this.currentQuestion = item.text;
    this.currentField = item.id;
    this.matrixAnswers = {};
    this.answerForm.reset({ answer: '', otherText: '' });
    const control = this.answerForm.get('answer');
    control?.setValidators(item.type === 'matrix' || item.required ? Validators.required : []);
    control?.updateValueAndValidity({ emitEvent: false });
    this.wordCount = 0;
    this.cdRef.detectChanges();
    this.focusAnswerAndScroll();
  }

  answerMatrix(factor: string, value: string): void {
    this.matrixAnswers[factor] = value;
    this.answerForm.get('answer')?.setValue(JSON.stringify(this.matrixAnswers));
    this.answerForm.get('answer')?.markAsDirty();
    this.answerForm.get('answer')?.updateValueAndValidity();
  }

  isMatrixComplete(): boolean { return this.currentFactors.every(factor => !!this.matrixAnswers[factor]); }

  submitAnswer(): void {
    if (!this.currentItem) return;
    if (this.isMatrix && !this.isMatrixComplete()) {
      this.showToast('Please rate every factor before continuing.', 'danger');
      return;
    }
    const control = this.answerForm.get('answer');
    if (this.currentItem.required && control?.invalid) { control.markAsTouched(); return; }
    let userAnswer = String(control?.value || '').trim();
    if (this.isMatrix) userAnswer = JSON.stringify(this.matrixAnswers);
    if (this.currentField === 'awareness_source' && userAnswer === 'Other') {
      const other = String(this.answerForm.value.otherText || '').trim();
      if (other) userAnswer = `Other: ${other}`;
      else { this.showToast('Please specify the other source.', 'danger'); return; }
    }
    this.answeredQAList.push({ question: this.currentQuestion, answer: userAnswer, ui_tag: this.currentField });
    this.conversationHistory.push({ role: 'assistant', content: this.currentQuestion, ui_tag: this.currentField });
    this.conversationHistory.push({ role: 'user', content: userAnswer });
    this.collectedFeedback[this.currentField] = userAnswer;
    this.qIndex++;
    this.qIndex >= this.staticQuestions.length ? this.completeSurvey() : this.setQuestionFromCurrentItem();
  }

  updateWordCount(text: string): void { this.wordCount = String(text || '').trim() ? String(text).trim().split(/\s+/).length : 0; }

  private completeSurvey(): void {
    this.successMessage = '🎉 Thank you for your feedback!';
    this.showFeedbackForm = false;
    this.finalizeAndPersistFeedback();
  }

  private focusAnswerAndScroll(): void {
    setTimeout(() => {
      const el = this.answerInputRef?.nativeElement;
      if (el) { try { el.focus({ preventScroll: true }); } catch { el.focus(); } }
      try { window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }); } catch { window.scrollTo(0, document.body.scrollHeight); }
    }, 100);
  }

  toggleAnswers(): void { this.answersExpanded = !this.answersExpanded; }
  closeToast(): void { if (this.toastTimer) clearTimeout(this.toastTimer); this.toast = null; }
  showToast(message: string, type: 'success' | 'danger' = 'danger', duration = 4000): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toast = { message, type, timestamp: Date.now() };
    this.toastTimer = setTimeout(() => this.toast = null, duration);
  }

  private initSpeech(): void {
    const win = window as any;
    const SR = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SR) return;
    this.speechSupported = true;
    this.recognition = new SR();
    this.recognition.lang = 'en-IN';
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.onresult = (event: any) => {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) if (event.results[i].isFinal) transcript += event.results[i][0].transcript + ' ';
      if (transcript && this.currentItem?.type === 'text') {
        const answer = `${this.answerForm.value.answer || ''} ${transcript}`.trim();
        this.answerForm.patchValue({ answer });
        this.updateWordCount(answer);
        this.cdRef.detectChanges();
      }
    };
    this.recognition.onend = () => { this.isListening = false; this.cdRef.detectChanges(); };
    this.recognition.onerror = () => { this.isListening = false; this.showToast('Speech recognition error. Please try again.'); };
  }

  toggleListening(): void {
    if (!this.recognition) return;
    if (this.isListening) { try { this.recognition.stop(); } catch {} this.isListening = false; }
    else { try { this.recognition.start(); this.isListening = true; } catch { this.showToast('Unable to start microphone. Check permissions.'); } }
  }

  private finalizeAndPersistFeedback(): void {
    if (this.persisted) return;
    this.persisted = true;
    const payload = {
      mobile_number: this.mobile,
      customer_name: this.userName,
      cust_id: null,
      scheme_name: null,
      scheme_description: null,
      sanction_amount: null,
      disbursed_amount: null,
      user_type: 'STANDARD_CUSTOMER_SURVEY',
      collected_feedback: this.collectedFeedback
    };
      this.feedbackService.createFeedbackSession(payload).pipe(
      switchMap(sessionResp => {
        const sessionId = sessionResp?.session_id;
        if (!sessionId) throw new Error('SESSION_ID_MISSING');
        this.setSessionCookie(sessionId);
        return this.feedbackService.submitFeedbackConversation(sessionId, JSON.stringify(this.conversationHistory));
      }),
      tap(submitResp => {
        if (submitResp?.session_id) this.setSessionCookie(submitResp.session_id, submitResp.expires_at);
        this.showToast('Feedback Submitted successfully.', 'success');
      }),
      catchError(err => { console.error('[finalizeAndPersistFeedback][STANDARD] error:', err); this.showToast('Feedback submitted, but saving to database failed.'); return of(null); })
    ).subscribe();
  }

  private setSessionCookie(sessionId: string, expiresAtIso?: string): void {
    const value = encodeURIComponent(sessionId);
    const expiry = expiresAtIso && !isNaN(new Date(expiresAtIso).getTime())
      ? new Date(expiresAtIso).toUTCString()
      : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toUTCString();
    const secure = location.protocol === 'https:' ? '; Secure' : '';
    document.cookie = `sidbi_feedback_session=${value}; expires=${expiry}; path=/; SameSite=Lax${secure}`;
  }
}
