import { formatDate } from '@angular/common';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilityServiceService {

  constructor() { }

  customDateFormatter(date) {
    const dateFormat = 'dd MMM YYYY';
    return formatDate(date, 'dd MMM YYYY', 'en_US');
  }
}
