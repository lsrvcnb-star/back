import { EmptyMsgPipePipe } from './empty-msg-pipe.pipe';

describe('EmptyMsgPipePipe', () => {
  it('create an instance', () => {
    const pipe = new EmptyMsgPipePipe();
    expect(pipe).toBeTruthy();
  });
});
