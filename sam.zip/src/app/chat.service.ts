import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ChatService {

  newChatData = [{
    "Main Menu":[
                {text:"Download AOD", href:"#", icon:"assets/botAssets/aod_icon.png" },
                {text:"Download DA", href:"#", icon:"assets/botAssets/da_icon.png"},
                {text:"Raise a Service Request", href:"/serviceRequest", icon:"assets/botAssets/service_request.png"},
                {text:"More Options..", href:"javascript:void(0)", icon:"assets/botAssets/more_actions.png"}],

    "More Options..":[
                {text:"Upload/Download Documents", href:"javascript:void(0)", icon:"assets/botAssets/upload_document.png" },
                {text:"E-Sign Documents", href:"/esign", icon:"assets/botAssets/e-sign.png"},
                {text:"View your alerts", href:"/alerts", icon:"assets/botAssets/alert.png"},
                {text:"Know Your RM", href:"javascript:void(0)", icon:"assets/botAssets/relationship_manager.png"},
                {text:"More Options...", href:"javascript:void(0)", icon:"assets/botAssets/more_actions.png"}],

    "Upload/Download Documents":[
                {text:"Upload Audit Report", href:"/auditReport", icon:"assets/botAssets/audit_report.png" },
                {text:"Upload Insurance", href:"/insurance", icon:"assets/botAssets/insurance.png" },
                {text:"Upload Disbursement", href:"/disbursement", icon:"assets/botAssets/disbursement.png"},
                {text:"Upload Others", href:"/download", icon:"assets/botAssets/upload_document.png" },
                {text:"More Options..", href:"javascript:void(0)", icon:"assets/botAssets/more_actions.png"}],

    "More Options...":[
                {text:"Apply New Loan", href:"https://onlineloanappl.sidbi.in/OnlineApplication/", icon:"assets/botAssets/apply_loan.png"},
                {text:"Know All Loan Schemes", href:"https://sidbi.in/en/products", icon:"assets/botAssets/loan_schemes.png"},
                {text:"Suggestions & Feedback", href:"/feedback", icon:"assets/botAssets/comment.png"},
                {text:"Change Password", href:"/changePwd", icon:"assets/botAssets/change_password.png"},
                {text:"Main Menu", href:"javascript:void(0)", icon:"assets/botAssets/main_menu.png"}]
  }]

  constructor() { }

  getBotAnswer(userInput:any){

    if(this.newChatData[0][userInput] !== undefined){
      return this.newChatData[0][userInput];  
    }
    else return "Sorry..you can only navigate by clicking the messages.";
  }
 
}


