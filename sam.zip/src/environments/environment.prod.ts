export const environment = {
  production: true,
  url: "https://dashboardweb.sidbi.in/",
  sidbiApiBase: 'https://apiuat.sidbi.in',
  //fileExtractorBase: 'https://file-extractordev.sidbi.in',
  fileExtractorBase: 'https://sidbi4u.sidbi.in',
  ssourl: "https://sso.sidbi.in:8443/",
  extractorApiKey: 'sampleapikey',
  aesSecretkey: 'PTdbACnygKIqTP5+WhsRCiVq8DeKyWNVfQx2vo9T9eQ='
};
