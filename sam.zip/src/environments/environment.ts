// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,



  url: "http://localhost:4200/",
  sidbiApiBase: 'https://apiuat.sidbi.in',
  //fileExtractorBase: 'https://file-extractordev.sidbi.in',
  fileExtractorBase: 'https://sidbi4u.sidbi.in',
  extractorApiKey: 'sampleapikey',
  aesSecretkey:'PTdbACnygKIqTP5+WhsRCiVq8DeKyWNVfQx2vo9T9eQ='


};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
