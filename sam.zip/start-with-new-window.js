
/* const { exec } = require('child_process');
const opn = require('open');


// Start the Angular development server
const ngServe = exec('ng serve');

ngServe.stdout.on('data', (data) => {
  console.log(data);
  // Check if the Angular app is compiled successfully and listening on the port
  if (data.includes('Listening on')) {
    // Open the application in a new browser window
    opn('http://localhost:4200', { app: ['chrome', '--new-window'] });
  }
});
ngServe.stderr.on('data', (data) => {
  console.error(`Error: ${data}`);
}); */
