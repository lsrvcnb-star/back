#!/bin/sh
"C:\Program Files\Google\Chrome\Application\chrome.exe" --new-window "http://localhost:4200"
