import { useEffect } from "react";
import { Container, Row } from "react-bootstrap";
import NegotiationDashboard from "negotiation-runtime/NegotiationDashboard.jsx";
import "assets/css/negotiation.css";

// Same page shell as Reports / Proposals / Minutes: Container > ds_wrap > h5 title.
export default function NegotiationTool() {
  useEffect(() => {
    // Radix portals render into <body>; scope the design tokens there too.
    document.body.classList.add("neg-portal-scope");
    return () => document.body.classList.remove("neg-portal-scope");
  }, []);

  return (
    <div>
      <Container fluid>
        <Row>
          <div className="col-md-12 p-0">
            <div className="ds_wrap negotiation-page-shell">
              <h5>Pricing Negotiation Dashboard</h5>
              <div className="m-2 mb-4">
                <div className="ifv-negotiation-tool">
                  <NegotiationDashboard />
                </div>
              </div>
            </div>
          </div>
        </Row>
      </Container>
    </div>
  );
}
