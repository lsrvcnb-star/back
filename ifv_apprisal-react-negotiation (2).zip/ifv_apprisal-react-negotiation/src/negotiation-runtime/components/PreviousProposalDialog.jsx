import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Download, FileText, Loader2, RefreshCw } from "lucide-react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "./ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { downloadPreviousProposal } from "../lib/previous-proposal";

const PAGE_SIZE = 10;

function valueOf(record, keys, fallback = "—") {
    for (const key of keys) {
        const value = record?.[key];
        if (value !== undefined && value !== null && value !== "") return value;
    }
    return fallback;
}

function formatDate(value) {
    if (!value || value === "—") return "—";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function auditIdOf(record) {
    return valueOf(record, ["audit_id", "auditId", "id"], null);
}

function normalized(value) {
    return String(value ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function belongsToBank(record, bankName) {
    const bank = normalized(bankName);
    if (!bank) return true;
    const searchableText = normalized(valueOf(record, [
        "counterpartyName",
        "companyName",
        "bankName",
        "proposalName",
        "title",
        "documentName",
        "fileName",
        "filename",
    ], ""));
    return searchableText.includes(bank);
}

export default function PreviousProposalDialog({ open, onOpenChange, proposals, loading, onRefresh, bankName }) {
    const [page, setPage] = useState(1);
    const [downloadId, setDownloadId] = useState(null);
    const [downloadError, setDownloadError] = useState("");

    const bankProposals = useMemo(
        () => (proposals ?? []).filter(proposal => belongsToBank(proposal, bankName)),
        [bankName, proposals]
    );
    const totalPages = Math.max(1, Math.ceil(bankProposals.length / PAGE_SIZE));
    const visibleProposals = useMemo(
        () => bankProposals.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
        [bankProposals, page]
    );

    useEffect(() => {
        if (open) setPage(1);
    }, [open]);

    useEffect(() => {
        if (page > totalPages) setPage(totalPages);
    }, [page, totalPages]);

    const handleDownload = async (proposal) => {
        const auditId = auditIdOf(proposal);
        if (!auditId) {
            setDownloadError("This proposal does not have a valid audit id.");
            return;
        }

        try {
            setDownloadError("");
            setDownloadId(auditId);
            const { blob, filename } = await downloadPreviousProposal(auditId, proposal);
            const url = URL.createObjectURL(blob);
            const anchor = document.createElement("a");
            anchor.href = url;
            anchor.download = filename;
            document.body.appendChild(anchor);
            anchor.click();
            anchor.remove();
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error("Failed to download previous proposal", error);
            setDownloadError("Unable to download this proposal. Please try again.");
        } finally {
            setDownloadId(null);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="neg-dialog neg-previous-proposals z-[9999] w-[95vw] max-w-7xl h-[88vh] overflow-hidden flex flex-col p-0">
                <DialogHeader className="mx-0 mt-0 rounded-none border-b border-border bg-[#6594b126] px-4 py-3">
                    <div className="flex items-center justify-between">
                        <DialogTitle className="flex items-center gap-2 text-base text-mds-navy">
                            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-mds-blue/10 text-mds-blue">
                                <FileText className="h-4 w-4" />
                            </span>
                            Previous Negotiations
                        </DialogTitle>

                        <div className="flex items-center pt-4 gap-3">
                            <div className="flex items-center gap-2 text-xs text-primary-foreground">
                                <span className="font-semibold text-mds-navy">
                                    Proposal History
                                </span>

                                <span className="rounded-full bg-secondary px-2 py-0.5">
                                    {loading
                                        ? "Loading..."
                                        : `${bankProposals.length} Record${bankProposals.length === 1 ? "" : "s"}`}
                                </span>
                            </div>

                            <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                className="h-8 gap-2"
                                onClick={onRefresh}
                                disabled={loading}
                            >
                                <RefreshCw
                                    className={
                                        loading
                                            ? "h-3.5 w-3.5 animate-spin"
                                            : "h-3.5 w-3.5"
                                    }
                                />
                                Refresh
                            </Button>
                        </div>
                    </div>
                </DialogHeader>

                {downloadError && (
                    <div className="mx-4 mt-2 rounded-md border-[1px] border-mds-danger/30 bg-mds-danger/5 px-3 py-2 text-xs text-mds-danger">
                        {downloadError}
                    </div>
                )}

                <div className="flex-1 overflow-auto px-4 py-2">
                    <div className="overflow-hidden rounded-md border-[1px] bg-white">
                        <Table className="text-xs">
                            <TableHeader className="sticky top-0 z-10 bg-[#D7E9F7]">
                                <TableRow>
                                    <TableHead className="h-9 px-3 text-[10px] uppercase tracking-wide text-primary-foreground">
                                        Date
                                    </TableHead>
                                    <TableHead className="h-9 px-3 text-[10px] uppercase tracking-wide text-primary-foreground">
                                        Proposal / Counterparty
                                    </TableHead>
                                    <TableHead className="h-9 px-3 text-[10px] uppercase tracking-wide text-primary-foreground">
                                        Document Type
                                    </TableHead>
                                    <TableHead className="h-9 px-3 text-[10px] uppercase tracking-wide text-primary-foreground">
                                        Format
                                    </TableHead>
                                    <TableHead className="h-9 px-3 text-[10px] uppercase tracking-wide text-primary-foreground">
                                        Status
                                    </TableHead>
                                    <TableHead className="h-9 px-3 text-[10px] uppercase tracking-wide text-primary-foreground">
                                        Attachment
                                    </TableHead>
                                </TableRow>
                            </TableHeader>

                            <TableBody>
                                {loading ? (
                                    [1, 2, 3].map((row) => (
                                        <TableRow key={row} className="animate-pulse">
                                            {[1, 2, 3, 4, 5, 6].map((cell) => (
                                                <TableCell key={cell} className="px-3 py-2">
                                                    <span className="block h-3 rounded bg-secondary" />
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    ))
                                ) : visibleProposals.length === 0 ? (
                                    <TableRow>
                                        <TableCell
                                            colSpan={6}
                                            className="h-40 text-center text-muted-foreground"
                                        >
                                            <div className="flex flex-col items-center gap-2">
                                                <FileText className="h-8 w-8 text-muted-foreground/40" />
                                                <span className="font-medium text-mds-navy">
                                                    No Previous Proposals Found
                                                </span>
                                                <span className="text-[11px]">
                                                    Exported proposal documents will
                                                    appear here.
                                                </span>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    visibleProposals.map((proposal, index) => {
                                        const auditId = auditIdOf(proposal);

                                        const documentName = valueOf(
                                            proposal,
                                            [
                                                "documentName",
                                                "fileName",
                                                "filename",
                                                "name",
                                            ]
                                        );

                                        const counterparty = valueOf(
                                            proposal,
                                            [
                                                "counterpartyName",
                                                "companyName",
                                                "bankName",
                                                "proposalName",
                                                "title",
                                            ]
                                        );

                                        const documentType = valueOf(
                                            proposal,
                                            ["documentType", "exportType", "type"]
                                        );

                                        const formatValue = valueOf(
                                            proposal,
                                            ["warPercentage", "fileType", "mimeType"]
                                        );

                                        const status = valueOf(
                                            proposal,
                                            ["status", "approvalStatus"],
                                            "Exported"
                                        );

                                        const date = valueOf(
                                            proposal,
                                            [
                                                "createdAt",
                                                "created_at",
                                                "exportedAt",
                                                "timestamp",
                                                "date",
                                            ]
                                        );

                                        return (
                                            <TableRow
                                                key={
                                                    auditId ??
                                                    `${documentName}-${index}`
                                                }
                                                className="hover:bg-mds-blue/[0.03]"
                                            >
                                                <TableCell className="whitespace-nowrap px-3 py-2 text-muted-foreground">
                                                    {formatDate(date)}
                                                </TableCell>

                                                <TableCell className="px-3 py-2">
                                                    <div className="font-medium text-mds-navy">
                                                        {counterparty}
                                                    </div>

                                                    <div
                                                        className="max-w-[300px] truncate text-[10px] text-muted-foreground"
                                                        title={documentName}
                                                    >
                                                        {documentName}
                                                    </div>
                                                </TableCell>

                                                <TableCell className="px-3 py-2 text-muted-foreground">
                                                    {documentType}
                                                </TableCell>

                                                <TableCell className="px-3 py-2">
                                                    <span className="rounded text-white bg-mds-blue px-2 py-1 text-[10px] font-semibold uppercase">
                                                        {formatValue}
                                                    </span>
                                                </TableCell>

                                                <TableCell className="px-3 py-2">
                                                    <Badge
                                                        variant="outline"
                                                        className="border-mds-success/30 bg-mds-success/5 text-[10px] text-mds-success"
                                                    >
                                                        {status}
                                                    </Badge>
                                                </TableCell>

                                                <TableCell className="px-3 py-2">
                                                    <button
                                                        type="button"
                                                        className="inline-flex items-center gap-1 text-mds-blue hover:underline disabled:opacity-50"
                                                        onClick={() =>
                                                            handleDownload(proposal)
                                                        }
                                                        disabled={
                                                            !auditId ||
                                                            downloadId === auditId
                                                        }
                                                    >
                                                        {downloadId === auditId ? (
                                                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                                        ) : (
                                                            <Download className="h-3.5 w-3.5" />
                                                        )}

                                                        {downloadId === auditId
                                                            ? "Downloading..."
                                                            : "Download"}
                                                    </button>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    })
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </div>

                <div className="flex items-center justify-between border-t border-border bg-secondary/20 px-4 py-2 text-xs text-muted-foreground">
                    <span>
                        {bankProposals.length
                            ? `Showing ${(page - 1) * PAGE_SIZE + 1}-${Math.min(
                                page * PAGE_SIZE,
                                bankProposals.length
                            )} of ${bankProposals.length}`
                            : ""}
                    </span>

                    <div className="flex items-center gap-2">
                        <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-8 gap-1"
                            onClick={() =>
                                setPage((current) => Math.max(1, current - 1))
                            }
                            disabled={page === 1 || loading}
                        >
                            <ChevronLeft className="h-3.5 w-3.5" />
                            Previous
                        </Button>

                        <span>
                            Page {page} of {totalPages}
                        </span>

                        <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-8 gap-1"
                            onClick={() =>
                                setPage((current) =>
                                    Math.min(totalPages, current + 1)
                                )
                            }
                            disabled={page === totalPages || loading}
                        >
                            Next
                            <ChevronRight className="h-3.5 w-3.5" />
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
