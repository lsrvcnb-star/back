// Colors resolve from rgb triplets so Tailwind opacity modifiers (bg-primary/10) work.
const c = (n) => `rgb(var(--${n}-rgb) / <alpha-value>)`;

module.exports = {
  content: ["./src/negotiation-runtime/**/*.{js,jsx}"],
  corePlugins: { preflight: false },
  // supplies animate-in / fade-in-0 / zoom-in-95 / slide-in-from-* used by the
  // Radix popup components (they are Tailwind v4 classes with no v3 core equivalent)
  plugins: [require("tailwindcss-animate")],
  theme: {
    extend: {
      colors: {
        "background": c("background"),
        "foreground": c("foreground"),
        "card": c("card"),
        "card-foreground": c("card-foreground"),
        "popover": c("popover"),
        "popover-foreground": c("popover-foreground"),
        "primary": c("primary"),
        "primary-foreground": c("primary-foreground"),
        "secondary": c("secondary"),
        "secondary-foreground": c("secondary-foreground"),
        "muted": c("muted"),
        "muted-foreground": c("muted-foreground"),
        "accent": c("accent"),
        "accent-foreground": c("accent-foreground"),
        "destructive": c("destructive"),
        "destructive-foreground": c("destructive-foreground"),
        "border": c("border"),
        "input": c("input"),
        "ring": c("ring"),
        "mds-blue": c("mds-blue"),
        "mds-blue-hover": c("mds-blue-hover"),
        "mds-navy": c("mds-navy"),
        "mds-success": c("mds-success"),
        "mds-warning": c("mds-warning"),
        "mds-danger": c("mds-danger"),
        "mds-neutral": c("mds-neutral"),
        "mds-surface": c("mds-surface"),
        "mds-purple": c("mds-purple"),
        "mds-purple-light": c("mds-purple-light"),
        "mds-sky": c("mds-sky"),
      },
      fontFamily: {
        sans: ["Tahoma", "Arial", "sans-serif"],
      },
      borderRadius: {
        sm: "3px",
        md: "4px",
        lg: "5px",
        xl: "8px",
      },
    },
  },
};
