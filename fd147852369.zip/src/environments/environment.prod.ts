// environment.prod.ts (Production)
export const environment = {
  production: true,
  uat: false,
  url: 'https://fdappl.sidbi.in/SIDBIFD',
  envName: 'prod',
  remitterAccNo: '923020033607867'
};
