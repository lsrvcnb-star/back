// environment.uat.ts (UAT)
export const environment = {
  production: false,
  uat: true,
  url: 'https://fdapplui.sidbi.in/SIDBIFD',
  envName: 'uat',
  remitterAccNo: '923020033607867'
};
