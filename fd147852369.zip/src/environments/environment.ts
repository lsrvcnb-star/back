export const environment = {
  production: false,
  uat: false,
  url: 'https://fdapplui.sidbi.in/SIDBIFD',
  envName: 'dev',
  remitterAccNo: '923020033607867'
};
