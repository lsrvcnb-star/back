export const environment = {
  production: false,
  uat: false,
  url: 'https://fdapplui.sidbi.in/SIDBIFD',
  // url: 'http://localhost:8182/SIDBIFD',
  envName: 'dev',
  remitterAccNo: '923020033607867'
};
