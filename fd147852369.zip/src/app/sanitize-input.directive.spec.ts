import { SanitizeInputDirective } from './sanitize-input.directive';

describe('SanitizeInputDirective', () => {
  it('should create an instance', () => {
    const directive = new SanitizeInputDirective();
    expect(directive).toBeTruthy();
  });
});
