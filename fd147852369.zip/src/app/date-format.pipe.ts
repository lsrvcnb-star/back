import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateFormat',
  standalone: true
})
export class DateFormatPipe implements PipeTransform {

  transform(value: string): string {
    if (!value) return value;
    const dateParts = value.split('-');
    if (dateParts.length !== 3) return value;
    // Convert from 'dd-MM-yyyy' to 'yyyy-MM-dd'
    return `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`;
  }
}
