import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appSanitizeInput]',
  standalone: true
})
export class SanitizeInputDirective {
  constructor(private control: NgControl) {}

  @HostListener('input', ['$event'])
  onInput(event: Event): void {
    const input = (event.target as HTMLInputElement).value;

    // Step 1: Remove HTML entities like &lt;, &gt;
    let sanitized = input.replace(/&lt;|&gt;/gi, '');

    // Step 2: Remove specific characters: < > / { }
    sanitized = sanitized.replace(/[<>\/{}]/g, '');

    if (sanitized !== input) {
      this.control.control?.setValue(sanitized);
    }
  }
}
