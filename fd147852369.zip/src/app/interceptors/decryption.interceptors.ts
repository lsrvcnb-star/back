import { inject } from '@angular/core';
import {
  HttpHandlerFn,
  HttpInterceptorFn,
  HttpRequest,
  HttpEvent,
  HttpResponse,
} from '@angular/common/http';
import { Observable, map } from 'rxjs';
import * as forge from 'node-forge';
import { privateKeyPem } from '../config';
import { HybridEncryptor } from '../Services/HybridEncryptor';
export const DecryptionInterceptorFn: HttpInterceptorFn = (
  req: HttpRequest<any>,
  next: HttpHandlerFn
 ): Observable<HttpEvent<any>> => {
  const hybridEncryptor = inject(HybridEncryptor);

  return next(req).pipe(
    map((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse && isEncryptedResponse(event.body)) {
        try {
          const decrypted = decryptHybridData(event.body, hybridEncryptor);
        //  console.log("",decrypted)
          return event.clone({ body: decrypted });
        } catch (err) {
          console.error('Failed to decrypt response:', err);
        }
      }
      return event;
    })
  );
};

function isEncryptedResponse(body: any): boolean {
  return body && body.encryptedKey && body.encryptedData && body.iv;
}

function decryptHybridData(
  response: { encryptedKey: string; encryptedData: string; iv: string },
  hybridEncryptor: HybridEncryptor
): any {
  const keyBytes = forge.util.decode64(response.encryptedKey);
  const dataBytes = forge.util.decode64(response.encryptedData);
  const ivBytes = forge.util.decode64(response.iv);

  const privateKey = forge.pki.privateKeyFromPem(privateKeyPem);
  const aesKey = privateKey.decrypt(keyBytes, 'RSA-OAEP', {
    md: forge.md.sha256.create(),
    mgf1: { md: forge.md.sha256.create() },
    label: null,
  });

  const decipher = forge.cipher.createDecipher('AES-CBC', aesKey);
  decipher.start({ iv: ivBytes });
  decipher.update(forge.util.createBuffer(dataBytes));

  if (!decipher.finish()) {
    throw new Error('AES decryption failed');
  }

  return JSON.parse(decipher.output.toString());
}
