import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashbordComponent } from './components/dashbord/dashbord.component';
import { HomeComponent } from './components/home/home.component';
import { CreateComponent } from './components/create/create.component';
import { FdapplicationComponent } from './components/fdapplication/fdapplication.component';
import { PreClosureFdComponent } from './components/pre-closure-fd/pre-closure-fd.component';
import { PreClosureFormComponent } from './components/pre-closure-form/pre-closure-form.component';
import { AuthGuard } from '../../service/authGuard';
import { ManageFDAppComponent } from '../../manage-fdapp/manage-fdapp.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { NomineeComponent } from './components/nominee/nominee.component';
import { PreclosureComponent } from './components/preclosure/preclosure.component';
import { FdFormDownloadComponent } from './components/fd-form-download/fd-form-download.component';
import { EnquiryComponent } from './components/enquiry/enquiry.component';
import { FdForm121Component } from './components/fd-form121/fd-form121.component';

const routes: Routes = [
  {
    path: '',
    component: DashbordComponent,
    data: {
      seo: {
        title: 'SIDBI FD Dashboard | Secure Fixed Deposit Services',
        description: 'Access secure SIDBI Fixed Deposit services including FD creation, application tracking, nominee details, account details and pre-closure requests.',
        keywords: 'SIDBI FD dashboard, fixed deposit services, SIDBI FD application, FD account details, SIDBI FD pre-closure',
        canonicalPath: '/dashboard',
        robots: 'noindex, nofollow',
      },
    },
    children: [
      {
        path: 'home',
        component: HomeComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Home | Fixed Deposit Online Services',
            description: 'View SIDBI Fixed Deposit services and continue secure online FD onboarding, KYC verification and application management.',
            keywords: 'SIDBI FD home, online FD services, fixed deposit onboarding, SIDBI FD KYC',
            canonicalPath: '/dashboard/home',
            robots: 'noindex, nofollow',
          },
        },
      },
      /* { path: 'createFD', component: FixedDepositComponent,  }, */
      {
        path: 'createFD',
        component: CreateComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'Create SIDBI Fixed Deposit | Online FD Application',
            description: 'Create a SIDBI Fixed Deposit application online with depositor details, tenure selection, nominee information and secure submission.',
            keywords: 'create SIDBI FD, online FD application, SIDBI fixed deposit form, FD depositor details, SIDBI FD nominee',
            canonicalPath: '/dashboard/createFD',
            robots: 'noindex, nofollow',
          },
        },
      },
      {
        path: 'manage/:entryId',
        component: CreateComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'Manage SIDBI FD Application | Fixed Deposit Details',
            description: 'Review and manage a SIDBI Fixed Deposit application with depositor, tenure, nominee and account information.',
            keywords: 'manage SIDBI FD application, fixed deposit details, SIDBI FD edit, FD application status',
            canonicalPath: '/dashboard/manage',
            robots: 'noindex, nofollow',
          },
        },
      },
      {
        path: 'accountDetails',
        component: AccountDetailsComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Account Details | Fixed Deposit Bank Information',
            description: 'Manage account and bank information linked to SIDBI Fixed Deposit services through the secure portal.',
            keywords: 'SIDBI FD account details, fixed deposit bank account, FD bank information, SIDBI account verification',
            canonicalPath: '/dashboard/accountDetails',
            robots: 'noindex, nofollow',
          },
        },
      },
     /* { path: 'fdApplication', component: FdapplicationComponent, }, */
      {
        path: 'fdApplication',
        component: ManageFDAppComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Applications | Track Fixed Deposit Requests',
            description: 'Track and manage SIDBI Fixed Deposit applications, submission status and related online FD service requests.',
            keywords: 'SIDBI FD applications, FD application tracking, fixed deposit request status, manage FD application',
            canonicalPath: '/dashboard/fdApplication',
            robots: 'noindex, nofollow',
          },
        },
      },
      {
        path: 'nominee',
        component: NomineeComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Nominee Details | Fixed Deposit Nomination',
            description: 'Add and manage nominee details for SIDBI Fixed Deposit applications through the secure online portal.',
            keywords: 'SIDBI FD nominee, fixed deposit nominee details, FD nomination, SIDBI nominee update',
            canonicalPath: '/dashboard/nominee',
            robots: 'noindex, nofollow',
          },
        },
      },
      {
        path: 'preClosureFd',
        component: PreclosureComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Pre-Closure | Fixed Deposit Closure Request',
            description: 'Submit and manage SIDBI Fixed Deposit pre-closure requests securely online.',
            keywords: 'SIDBI FD pre-closure, fixed deposit closure request, FD premature closure, SIDBI FD closure',
            canonicalPath: '/dashboard/preClosureFd',
            robots: 'noindex, nofollow',
          },
        },
      },
      {
        path: 'fdForm',
        component: FdForm121Component,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Forms | Download Fixed Deposit Documents',
            description: 'Download SIDBI Fixed Deposit forms, user guides, terms and related FD service documents.',
            keywords: 'SIDBI FD forms, fixed deposit form download, SIDBI FD documents, FD user guide, SIDBI FD terms',
            canonicalPath: '/dashboard/fdForm',
            robots: 'noindex, nofollow',
          },
        },
      },
      {
        path: 'enquiry',
        component: EnquiryComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Customer Inquiries | Grievance and Support',
            description: 'Submit customer inquiries, grievances and support requests for SIDBI Fixed Deposit services.',
            keywords: 'SIDBI FD inquiry, grievance, customer support, FD help',
            canonicalPath: '/dashboard/enquiry',
            robots: 'noindex, nofollow',
          },
        },
      },
      /* { path: 'preClosureFd', component: PreClosureFdComponent,}, */
      {
        path: 'preClosureFd/preClosureForm/:strFdrNo',
        component: PreClosureFormComponent,
        canActivate:[AuthGuard],
        data: {
          seo: {
            title: 'SIDBI FD Pre-Closure Form | Fixed Deposit Closure Details',
            description: 'Complete SIDBI Fixed Deposit pre-closure form details securely online.',
            keywords: 'SIDBI FD pre-closure form, fixed deposit closure form, SIDBI FDR closure, FD closure details',
            canonicalPath: '/dashboard/preClosureFd/preClosureForm',
            robots: 'noindex, nofollow',
          },
        },
      },
      // { path: 'fdApplication/editFD', component: EditFDComponent,canActivate:[AuthGuard] },
      // { path: 'fdApplication/viewFD', component: ViewFDComponent, canActivate:[AuthGuard]},
      { path: '', redirectTo: 'home', pathMatch: 'full' }, // Redirects should not have canActivate
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
