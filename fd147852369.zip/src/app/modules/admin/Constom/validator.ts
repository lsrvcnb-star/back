import { AbstractControl, ValidatorFn, FormGroup,ValidationErrors } from '@angular/forms';
import { HostListener } from '@angular/core';

 

export class CustomValidator {
     // Password complexity validator
    static passwordPattern(control: AbstractControl): { [key: string]: boolean } | null {
      const password = control.value;
      if (!password) return null;
         // Password must contain at least one uppercase letter, one number, and one special character
      const hasUpperCase = /[A-Z]/.test(password);
      const hasNumber = /\d/.test(password);
      const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
   
      if (hasUpperCase && hasNumber && hasSpecialChar) {
        return null; // Valid password
      } else {
        return { passwordPattern: true }; // Invalid password
      }
    }


   
    // Password match validator
       static passwordMatch(passwordField: string, confirmPasswordField: string): ValidatorFn {
        return (formGroup: AbstractControl): { [key: string]: boolean } | null => {
        const passwordControl = formGroup.get(passwordField);
        const confirmPasswordControl = formGroup.get(confirmPasswordField);
       if (!passwordControl || !confirmPasswordControl) return null;
           // Only set the error if both fields are touched or dirty
        if (confirmPasswordControl.errors && !confirmPasswordControl.errors['passwordMismatch']) {
          return null;
        }
   
        // Check if the password fields match
        if (passwordControl.value !== confirmPasswordControl.value) {
          confirmPasswordControl.setErrors({ passwordMismatch: true });
          return { passwordMismatch: true };
        } else {
          confirmPasswordControl.setErrors(null);
          return null;
        }
      };
    }
   
    // Mobile number validator (10-digit numbers only)
    static mobilePattern(control: AbstractControl): { [key: string]: boolean } | null {
      const mobileNumber = control.value;
      const valid = /^[0-9]{10}$/.test(mobileNumber);
      return valid ? null : { mobilePattern: true };
    }
   
    // OTP validator (6-digit numbers only)
    static otpPattern(control: AbstractControl): { [key: string]: boolean } | null {
      const otp = control.value;
      const valid = /^[0-9]{6}$/.test(otp);
      return valid ? null : { otpPattern: true };
    }
   
    // Captcha validator (4-digit numbers only)
    static captchaPattern(control: AbstractControl): { [key: string]: boolean } | null {
      const captcha = control.value;
      const valid = /^[0-9]{4}$/.test(captcha);
      return valid ? null : { captchaPattern: true };
    }

   

    public OnlyNumbervalidator(event: any) {
      const pattern = /^[0-9]*$/; // Only numbers
      if (!pattern.test(event.target.value)) {
        event.target.value = event.target.value.replace(/[^0-9]/g, ""); // Replace non-numeric characters
      }
    }


    public FloatValue(event: any) {
      const pattern = /^[+-]?\d*(\.\d*)?$/; // Only numbers
      const input = event.target.value;
      if (!pattern.test(input)) {
        event.target.value = input.replace(/[^0-9.+-]/g, ""); // Replace non-numeric characters
      }
    }

    public CharacterSpaceValidator(event: any) {
       // Regular expression to allow only alphabetic characters and spaces
      const pattern = /^[a-zA-Z ]*$/;
      const input = event.target.value;
     
      // Check if the input matches the pattern
      if (!pattern.test(input)) {
        // Remove invalid characters
        event.target.value = input.replace(/[^a-zA-Z ]/g, ""); // Remove everything except letters and spaces
      }
    }
  public toUpperCase(event: any): void {
  const input = event.target;
  input.value = input.value.toUpperCase();
  }





    public emailvalidator(event: any) {
      const pattern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/; // Only numbers
      const input = event.target.value;
      if (!pattern.test(input)) {
        event.target.value = input.replace(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g, "");
      }
    }
    
    public characterSpaceNumberValidator(event: any) {
      // Regular expression to allow only alphanumeric characters and spaces
      const pattern = /^[A-Za-z0-9 ]*$/;
      const input = event.target.value;
     
      // Check if the input matches the pattern
      if (!pattern.test(input)) {
        // Remove invalid characters
        event.target.value = input.replace(/[^A-Za-z0-9 ]/g, "");
      }
    }
  
    public ifsCodevalidator(event: any): void {
      const pattern = /^[A-Za-z]{4}[0-9]{6,7}$/; // Pattern to match IFSC code (4 letters followed by 6-7 digits)
       let value = event.target.value;
       // If the value doesn't match the pattern, fix it by removing invalid characters
      if (!pattern.test(value)) {
        // Remove non-alphanumeric characters
    event.target.value = value.replace(/[^A-Za-z0-9]/g, '');
      }
    }


    futureDateValidator(): ValidatorFn {
      return (control: AbstractControl): { [key: string]: any } | null => {
        const inputDate = new Date(control.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return inputDate > today ? { futureDate: true } : null;
      };
    }

    public AddressValidator(event: any) {
      // Regular expression to allow typical address characters
      const pattern = /^[a-zA-Z0-9\s,.\-\/#]*$/;
      const input = event.target.value;
      // Check if the input matches the pattern
      if (!pattern.test(input)) {
        // Remove invalid characters
        event.target.value = input.replace(/[^a-zA-Z0-9\s,.\-\/#]/g, "");
      }
    }


 
preventSpecialChars(event: KeyboardEvent): void {
  const char = String.fromCharCode(event.keyCode || event.which);
  const unsafePattern = /[^a-zA-Z0-9 _.\-]/;
   if (unsafePattern.test(char)) {
    event.preventDefault();
  }
}

 
// Prevent paste of unwanted characters entirely
public preventPaste(event: ClipboardEvent): void {
  const pasteText = event.clipboardData?.getData('text') || '';
  const unsafePattern = /[^a-zA-Z0-9 _.\-]/g;
  if (unsafePattern.test(pasteText)) {
    event.preventDefault();
    console.warn("Paste blocked due to unsafe characters.");
  }
}

public generateUniqueReqId(): string {
  const ts = Date.now(); // milliseconds
  const rand7 = Math.floor(Math.random() * 9000000) + 1000000;
  return `${ts}-${rand7}`; // உதா: 1733809105123-4829137
}



 }