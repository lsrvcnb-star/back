import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { NavbarComponent } from '../navbar/navbar.component';
import { FooterComponent } from '../footer/footer.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { CreateComponent } from "../create/create.component";

 
@Component({
  selector: 'app-dashbord',
  standalone: true,
  imports: [
    NavbarComponent,
    FooterComponent,
    SidebarComponent,
    RouterModule,

],
  templateUrl: './dashbord.component.html',
  styleUrls: ['./dashbord.component.scss']  // Corrected to plural 'styleUrls'
})
export class DashbordComponent { }
 
