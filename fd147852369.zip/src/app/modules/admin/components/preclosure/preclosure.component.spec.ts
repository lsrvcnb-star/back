import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreclosureComponent } from './preclosure.component';

describe('PreclosureComponent', () => {
  let component: PreclosureComponent;
  let fixture: ComponentFixture<PreclosureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreclosureComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreclosureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
