import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../../service/api.service';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { CookieService } from 'ngx-cookie-service';
import { AuthService } from '../../../../service/auth.service';
import { FdCacheService } from '../../../../service/fd-cache.service';

@Component({
  selector: 'app-preclosure',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './preclosure.component.html',
  styleUrls: ['./preclosure.component.scss'],
})
export class PreclosureComponent implements OnInit {
  fdData: any[] = [];
  PreCloseData: any[] = [];
  cifId: any;
  globalFilter: string = '';
  showModal: boolean = false;
  selectedFD: any = null;
  selectedIndex: number = -1;
  closureReason: string = '';
  fdErrorMessage: string = '';
  fdEmptyMessage: string = '';
  today: Date = new Date();
  showPrematureAlert: boolean = false;
  showReasonAlert: boolean = false;
  showSuccessAlert: boolean = false;
  preClosefdData: any;
  constructor(
    private apiService: ApiService,
    private hybridEncryptor: HybridEncryptor,
    private cookieService: CookieService,
    private authService: AuthService,
    private fdCacheService: FdCacheService
  ) {}

  ngOnInit(): void {
    const fdUserId = this.authService.getResponseValueByKey('fdUserEmail');
    // const fdUserId =
    //   this.authService.getResponseValueByKey('fdUserEmail') || 'info_karthika@sidbi.in';
    if (fdUserId) {
      this.fdCacheService
        .getUserDetails(fdUserId)
        .subscribe({
          next: (response: any) => {
            const fdEntryListReq = {
              cif: response['custCifId'],
              fdUserPan: response['fdUserPan'],
              // fdUserPan: 'CJSPA3510J',
            };
            this.fetchFdEntryListDetails(fdEntryListReq);
          },
          error: (err) => {
            console.error('Error fetching User details:', err);
            this.fdErrorMessage =
              '⚠️ The server is currently busy. Please try again shortly';
          },
        });
    }

    //  this.getFdEntryListDetailsPreclosureFD();
  }

  fetchFdEntryListDetails(req: any): void {
    this.apiService
      .getFdEntryListDetails(
        this.hybridEncryptor.encrypted(JSON.stringify(req))
      )
      .subscribe({
        next: (response: any[]) => {
          if (!response || response.length === 0) {
            this.fdEmptyMessage =
              'There are no FDs created for this account. Kindly continue to create a new FD.';
            this.fdData = [];
            return;
          }

          this.fdData = response
            .filter((entry: any) => entry.saveFlag === '05')
            .map((entry: any, index: number) => {
              const principal = parseFloat(entry.amount ?? '0');
              const rate = parseFloat(entry.intRate ?? '0');
              const tenureMonths = parseFloat(entry.period ?? '0');
              const tenureYears = tenureMonths / 12;

              const interestEarned = principal * (rate / 100) * tenureYears;
              const calculatedMaturityAmount = principal + interestEarned;

              let calculatedMaturityDate = '';
              let rawMaturityDate: Date | null = null;

              if (entry.entryDt) {
                const startDate = new Date(entry.entryDt);
                startDate.setMonth(startDate.getMonth() + tenureMonths);
                calculatedMaturityDate = startDate.toLocaleDateString();
                rawMaturityDate = startDate;
              }

              return {
                // no: entry.sno ?? index + 1,
                no: index + 1,
                scheme: entry.schemeCd ?? '',
                depositedAmount: entry.amount ?? '',
                maturityAmount:
                  entry.fdrMaturityAmt && entry.fdrMaturityAmt !== 'null'
                    ? parseFloat(entry.fdrMaturityDate) //fdrMaturityAmt
                    : calculatedMaturityAmount,
                maturityDate:
                  entry.fdrMaturityDate && entry.fdrMaturityDate !== 'null'
                    ? new Date(entry.fdrMaturityAmt).toLocaleDateString()
                    : calculatedMaturityDate,
                interestRate: entry.intRate ? `${entry.intRate} %` : '',
                autoRenewal: entry.autoRenewFlag ?? '',
                status: entry.fdappStatus ?? '',
                preclosureInitiated: false,

                details: {
                  strFdrNo: entry.strFdrNo ?? '',

                  startDate: entry.entryDt
                    ? new Date(entry.entryDt).toLocaleDateString()
                    : '',
                  depositAmount: entry.amount ?? '',
                  period: entry.period ?? '',
                  type: entry.schemeCd ?? '',
                  repaymentAccount: entry.custAccNum ?? '',
                  branchCd: entry.branchCd ?? '',
                  nom1Name: entry.nom1Name ?? '',
                  nom2Name: entry.nom2Name ?? '',
                  nom3Name: entry.nom3Name ?? '',
                  rawMaturityDate: rawMaturityDate,
                },
              };
            });

          this.fdErrorMessage = '';
          this.fdEmptyMessage = '';
        },
        error: (err) => {
          console.error('Error fetching FD details:', err);
          this.fdErrorMessage =
            '⚠️ The server is currently busy. Please try again shortly';
          this.fdData = [];
        },
      });
  }

  getFdEntryListDetailsPreclosureFD(): void {
    const data1 = {
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
      newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
      entryId: this.authService.getResponseValueByKey('entryId'),
      // cif : this.authService.getResponseValueByKey("cif"),
      cif: this.authService.getResponseValueByKey('custCifId'),
    };
    this.apiService
      .userFdDetailsView(this.hybridEncryptor.encrypted(JSON.stringify(data1)))
      .subscribe({
        next: (response: any) => {
          // alert ("preclosureFD data"+response);
          if (response) {
            this.cifId = response.cif;
          }
        },
      });

    const data = {
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
    };
    this.apiService
      .getFdPrecloserDashboard(
        this.hybridEncryptor.encrypted(JSON.stringify(data))
      )
      .subscribe({
        next: (response: any[]) => {
          if (!response || response.length === 0) {
            this.fdEmptyMessage =
              'There are no FDs created for this account. Kindly continue to create a new FD.';
            this.fdData = [];
            return;
          }
          this.fdData = response.map((entry: any, index: number) => {
            const principal = parseFloat(entry.amount ?? '0');
            const rate = parseFloat(entry.intRate ?? '0');
            const tenureMonths = parseFloat(entry.period ?? '0');
            const tenureYears = tenureMonths / 12;
            const interestEarned = principal * (rate / 100) * tenureYears;
            const calculatedMaturityAmount = principal + interestEarned;
            let calculatedMaturityDate = '';
            let rawMaturityDate: Date | null = null;
            if (entry.entryDt) {
              const startDate = new Date(entry.entryDt);
              startDate.setMonth(startDate.getMonth() + tenureMonths);
              calculatedMaturityDate = startDate.toLocaleDateString();
              rawMaturityDate = startDate;
            }
            return {
              no: entry.sno ?? index + 1,
              scheme: entry.schemeCd ?? '',
              depositedAmount: entry.amount ?? '',
              maturityAmount:
                entry.fdrMaturityAmt && entry.fdrMaturityAmt !== 'null'
                  ? parseFloat(entry.fdrMaturityAmt)
                  : calculatedMaturityAmount,
              maturityDate:
                entry.fdrMaturityDate && entry.fdrMaturityDate !== 'null'
                  ? new Date(entry.fdrMaturityDate).toLocaleDateString()
                  : calculatedMaturityDate,
              interestRate: entry.intRate ? `${entry.intRate} %` : '',
              autoRenewal: entry.autoRenewFlag ?? '',
              status: entry.fdappStatus ?? '',
              strFdrNo: entry.strFdrNo ?? '',
              preclosureInitiated: false,
              details: {
                startDate: entry.entryDt
                  ? new Date(entry.entryDt).toLocaleDateString()
                  : '',
                depositAmount: entry.amount ?? '',
                period: entry.period ?? '',
                type: entry.schemeCd ?? '',
                repaymentAccount: entry.custAccNum ?? '',
                branchCd: entry.branchCd ?? '',
                nom1Name: entry.nom1Name ?? '',
                nom2Name: entry.nom2Name ?? '',
                nom3Name: entry.nom3Name ?? '',
                rawMaturityDate: rawMaturityDate,
              },
            };
          });
          this.fdErrorMessage = '';
          this.fdEmptyMessage = '';
        },
        error: (err) => {
          console.error('Error fetching FD details:', err);
          this.fdErrorMessage =
            '⚠️ The server is currently busy. Please try again shortly';
          this.fdData = [];
        },
      });
  }

  filteredAndSortedData(): any[] {
    if (!this.globalFilter.trim()) return this.fdData;
    const filter = this.globalFilter.toLowerCase();
    return this.fdData.filter(
      (fd) =>
        fd.scheme.toLowerCase().includes(filter) ||
        fd.no.toString().includes(filter)
    );
  }

  openModal(fd: any, index: number): void {
    const data1 = {
      strFdrNo: fd.details.strFdrNo,
    };
    this.apiService
      .getPreclosureRequestDetails(
        this.hybridEncryptor.encrypted(JSON.stringify(data1))
      )
      .subscribe({
        next: (response: any[]) => {
          if (!response || response.length === 0) {
            this.PreCloseData = [];
            return;
          } else {
            this.PreCloseData = response;
            this.selectedFD = fd;
            this.selectedFD['ResonofPreClose'] = this.getreason(
              response[0]['strPreClosureReasonCD']
            );
            this.selectedFD['PreCloseReMark'] = response[0]['strPreClosureRemarks']
            const isoDate = response[0]['strPreClosureReqDt'];
            const dateObj = new Date(isoDate);
            // Format the date as DD-MM-YYYY
            const formattedDate = dateObj.toLocaleDateString('en-GB'); 
            const finalDate = formattedDate.replace(/\//g, '/'); 
            this.selectedFD['PreCloseinitiatedDate'] = finalDate;
             this.selectedFD['PreCloseStatus'] = this.getStatusDetails(
              response[0]['chrPreClosureStatus']
            );
     
            return;
          }
        },
      });
    // this.selectedFD = fd;
    this.selectedIndex = index;
    this.closureReason = '';
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
    this.selectedFD = null;
    this.selectedIndex = -1;
    this.closureReason = '';
  }

  precloseFD(): void {
    const maturityDate = this.selectedFD.details.rawMaturityDate;
    if (!maturityDate) return;
    const diffInMs = maturityDate.getTime() - this.today.getTime();
    const diffInDays = Math.ceil(diffInMs / (1000 * 60 * 60 * 24));
    if (diffInDays <= 5) {
      this.showPrematureAlert = true;
      setTimeout(() => (this.showPrematureAlert = false), 3000);
      return;
    }

    if (!this.closureReason.trim()) {
      this.showReasonAlert = true;
      setTimeout(() => (this.showReasonAlert = false), 3000);
      return;
    }

    // Simulate success
    this.fdData[this.selectedIndex].preclosureInitiated = true;
    this.showSuccessAlert = true;
    setTimeout(() => {
      this.showSuccessAlert = false;
      this.closeModal();
    }, 3000);
  }

  getreason(reasonCode: string) {
    let result = '';
    if (reasonCode == 'E') {
      result = 'EDUCATIONAL EXPENSES';
    }else if(reasonCode == 'M'){
      result = 'MEDICAL EXIGENCIES';
    }else if(reasonCode == 'D'){
     result = 'DEATH';
    }else if(reasonCode == 'O'){
       result = 'OTHERS';
    }
    return result;
  }

 getStatusDetails(StatusCode: String){
   let result = '';
   if (StatusCode == '01') {
      result = 'INITIATED';
    }else if(StatusCode == '02'){
      result = 'PROCESS';
    }else if(StatusCode == '05'){
     result = 'CLOSED';
    }
    return result;
 }


}
