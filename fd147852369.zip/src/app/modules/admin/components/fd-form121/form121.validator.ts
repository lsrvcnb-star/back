import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class Form121Validator {
  static pan(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '').trim().toUpperCase();
      return /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(value) ? null : { invalidPan: true };
    };
  }

  static optionalPan(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!String(control.value || '').trim()) return null;
      return Form121Validator.pan()(control);
    };
  }

  static tan(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '').trim().toUpperCase();
      return /^[A-Z]{4}[0-9]{5}[A-Z]$/.test(value) ? null : { invalidTan: true };
    };
  }

  static optionalTan(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!String(control.value || '').trim()) return null;
      return Form121Validator.tan()(control);
    };
  }

  static mobile(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null =>
      /^[6-9][0-9]{9}$/.test(String(control.value || '')) ? null : { invalidMobile: true };
  }

  static optionalMobile(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null =>
      !String(control.value || '').trim() ? null : Form121Validator.mobile()(control);
  }

  static countryCode(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null =>
      /^\+\d{1,4}$/.test(String(control.value || '')) ? null : { invalidCountryCode: true };
  }

  static amount(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (control.value === null || control.value === '') return null;
      const value = Number(control.value);
      return Number.isFinite(value) && value >= 0 ? null : { invalidAmount: true };
    };
  }

  static taxYear(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '').trim();
      if (!value) return null;

      const match = /^(\d{4})-(\d{2})$/.exec(value);
      if (!match) return { invalidTaxYear: true };

      const startYear = Number(match[1]);
      const endYear = Number(match[2]);
      return endYear === (startYear + 1) % 100 ? null : { invalidTaxYear: true };
    };
  }

  static acknowledgementNumber(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '').trim();
      return value === '' || /^[A-Za-z0-9\-/]{8,30}$/.test(value)
        ? null
        : { invalidAcknowledgementNumber: true };
    };
  }
}
