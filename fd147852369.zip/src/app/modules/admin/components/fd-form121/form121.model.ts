export interface PreviousItrDetail {
  serialNo: number;
  taxYear: string;
  acknowledgementNumber: string;
  returnIncome: number | null;
}

export interface Form121Model {
  submissionId?: number | string;
  fduserRegId: string;
  place: string;
  status: 'SAVED' | 'SUBMITTED';
  form121: {
  declerationId?: number | string;
  name: string;
  address: string;
  pan: string;
  declarantStatus: string;
  residentialStatus: string;
  seniorCitizen: 'Y' | 'N';
  emailId: string;
  countryCode: string;
  contactNumber: string;
  taxYear: string;
  natureOfIncome: string;
  estimatedIncomeForDeclaration: number | null;
  previousForm121Filed?: 'Y' | 'N';
  previousForm121Count: number;
  previousForm121AggregateIncome: number | null;
  currentAggregateIncome: number | null;
  estimatedTotalIncome: number | null;
  previousItrDetails: PreviousItrDetail[];
  };
}
