import { CommonModule } from '@angular/common';
import { Component, OnInit, Optional } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { AuthService } from '../../../../service/auth.service';
import { FdCacheService } from '../../../../service/fd-cache.service';
import { ApiService } from '../../../../service/api.service';
import { Form121Validator } from './form121.validator';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { jsPDF } from 'jspdf';
declare var bootstrap: any;

@Component({
  selector: 'app-fd-form121',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './fd-form121.component.html',
  styleUrls: ['./fd-form121.component.scss'],
})
export class FdForm121Component implements OnInit {
  form121: FormGroup;
  isLoading = false;
  autoFilled = false;
  submitted = false;
  isSubmitting = false;
  loadError = '';
  submitError = '';
  submitSuccess = '';
  missingAutoFields: string[] = [];
  private seniorCitizenAutoFilled = false;
  submissionId: number | string | null = null;
  declarationId: number | string | null = null;
  formStatus: 'SAVED' | 'SUBMITTED' | '' = '';
  isFormLocked = false;
  private existingFormLoadStarted = false;
  private existingFormLoaded = false;
  private isDraftMode = false;
  private fduserRegId = '';
  readonly today = new Date().toISOString().slice(0, 10);
  readonly currentTaxYear = this.getTaxYear(new Date());
  public hybridEncryptor!: HybridEncryptor;

  modalMessage = '';

  modalType: 'success' | 'error' = 'success';
  isModal = false;
  hasValidCif = true;

  formHistory: any[] = [];
  showFormList = true;
  private historyLoaded = false;
  openedFromHistory = false;
  customerName = '';


  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private fdCacheService: FdCacheService,
    private apiService: ApiService,
    @Optional() private activeModal: NgbActiveModal | null,
  ) {
    this.isModal = !!this.activeModal;
    this.form121 = this.fb.group({
      place: ['', Validators.required],
      name: ['', [Validators.required, Validators.maxLength(100)]],
      address: ['', Validators.required],
      pan: ['', [Validators.required, Form121Validator.pan()]],
      declarantStatus: ['Individual', Validators.required],
      residentialStatus: ['Resident', Validators.required],
      seniorCitizen: ['N', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      countryCode: ['+91', [Validators.required, Form121Validator.countryCode()]],
      contactNumber: ['', [Validators.required, Form121Validator.mobile()]],
      taxYear: [this.currentTaxYear, Validators.required],
      natureOfIncome: ['Interest on securities / deposits', Validators.required],
      estimatedIncomeForDeclaration: [null, [Validators.required, Form121Validator.amount()]],
      previousForm121Filed: ['N', Validators.required],
      previousForm121Count: [0, [Validators.required, Validators.min(0)]],
      previousForm121AggregateIncome: [0, [Validators.required, Form121Validator.amount()]],
      currentAggregateIncome: [0, [Validators.required, Form121Validator.amount()]],
      estimatedTotalIncome: [null, [Validators.required, Form121Validator.amount()]],
      previousItrDetails: this.fb.array([this.createItrRow(), this.createItrRow()]),
      declarationDate: [this.today, Validators.required],
      declarantName: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.populateFromAuthenticatedUser();
    this.hybridEncryptor = new HybridEncryptor();
    this.form121.get('previousForm121Filed')?.valueChanges.subscribe((value) => {
      this.updatePreviousItrValidators(value);
    });
    this.updatePreviousItrValidators(this.form121.get('previousForm121Filed')?.value);
  }

  get f() {
    return this.form121.controls;
  }

  get previousItrDetails(): FormArray {
    return this.form121.get('previousItrDetails') as FormArray;
  }

  createItrRow(): FormGroup {
    return this.fb.group({
      itrid: [null],
      taxYear: ['', Form121Validator.taxYear()],
      acknowledgementNumber: ['', Form121Validator.acknowledgementNumber()],
      returnIncome: [null, Form121Validator.amount()],
    });
  }

  private loadFormHistory(): void {

    const fduserRegId = this.getFdUserRegId();

    if (!fduserRegId) {
      return;
    }

    this.apiService.getForm121SubmissionsAll(fduserRegId)
      .subscribe({
        next: (response) => {

          const records = this.normalizeRecords(response);

          // No records => Open blank form directly
          if (!records.length) {
            this.formHistory = [];
            this.showFormList = false;
            return;
          }

          const latestSaved = this.findLatest(
            records,
            r => r.status === 'SAVED'
          );

          const latestSubmitted = this.findLatest(
            records,
            r => r.status === 'SUBMITTED'
          );

          // Draft Exists
          if (latestSaved) {

            this.formHistory = records
              .map(item => ({
                submissionId: item.submissionId,
                declarationId: item.form121?.declerationId,
                taxYear: item.form121?.taxYear,
                dateOfSubmit: item.dateOfSubmit,
                status:
                  item.status === 'SAVED'
                    ? 'Current Form'
                    : 'SUBMITTED',
                canOpen:
                  item.submissionId === latestSaved.submissionId,
                record: item
              }))
              .sort((a, b) => {

                if (a.status === 'Current Form') {
                  return -1;
                }

                if (b.status === 'Current Form') {
                  return 1;
                }

                return (
                  new Date(b.dateOfSubmit).getTime() -
                  new Date(a.dateOfSubmit).getTime()
                );
              });

            this.showFormList = true;
            return;
          }

          // All records are submitted
          this.formHistory = records
            .map(item => ({
              submissionId: item.submissionId,
              declarationId: item.form121?.declerationId,
              taxYear: item.form121?.taxYear,
              dateOfSubmit: item.dateOfSubmit,
              status: 'SUBMITTED',
              canOpen:
                item.submissionId === latestSubmitted?.submissionId,
              record: item
            }))
            .sort((a, b) =>
              new Date(b.dateOfSubmit).getTime() -
              new Date(a.dateOfSubmit).getTime()
            );

          this.showFormList = true;
        },
        error: () => {
          this.formHistory = [];
          this.showFormList = false;
        }
      });
  }
  addItrRow(): void {
    this.previousItrDetails.push(this.createItrRow());
    this.updatePreviousItrValidators(this.form121.get('previousForm121Filed')?.value);
  }

  removeItrRow(index: number): void {
    if (this.previousItrDetails.length > 1) this.previousItrDetails.removeAt(index);
  }

  validateItrAcknowledgements(): boolean {
    const acknowledgementControls = this.previousItrDetails.controls.map(
      (row) => row.get('acknowledgementNumber')
    );
    const occurrences = new Map<string, number>();

    acknowledgementControls.forEach((control) => {
      const value = String(control?.value ?? '').trim().toLowerCase();
      if (value) occurrences.set(value, (occurrences.get(value) ?? 0) + 1);
    });

    let isUnique = true;
    acknowledgementControls.forEach((control) => {
      if (!control) return;

      const value = String(control.value ?? '').trim().toLowerCase();
      const errors = { ...(control.errors ?? {}) };
      delete errors['duplicateAcknowledgementNumber'];

      if (value && (occurrences.get(value) ?? 0) > 1) {
        errors['duplicateAcknowledgementNumber'] = true;
        isUnique = false;
      }

      control.setErrors(Object.keys(errors).length ? errors : null);
    });

    return isUnique;
  }

  saveDraft(): void {
    this.submitForm('SAVED');
  }

  previewPdf(): void {
    const pdf = this.createFormPdf();
    const pdfUrl = pdf.output('bloburl').toString();
    const previewWindow = window.open(pdfUrl, '_blank', 'noopener,noreferrer');

    if (!previewWindow) {
      this.submitError = 'Please allow pop-ups to preview the Form 121 PDF.';
    }
  }

  isPartAValid(): boolean {
    this.refreshMissingAutoFields();
    const acknowledgementNumbersUnique = this.validateItrAcknowledgements();

    const names = [
      'place', 'name', 'address', 'pan', 'declarantStatus', 'residentialStatus',
      'seniorCitizen', 'emailId', 'countryCode', 'contactNumber', 'taxYear',
      'natureOfIncome', 'estimatedIncomeForDeclaration', 'previousForm121Count',
      'previousForm121Filed', 'previousForm121AggregateIncome', 'currentAggregateIncome',
      'estimatedTotalIncome', 'declarationDate', 'declarantName',
    ];

    names.forEach(name => this.form121.get(name)?.markAsTouched());
    this.previousItrDetails.controls.forEach(row => row.markAllAsTouched());

    // Debug invalid controls
    names.forEach(name => {
      const control = this.form121.get(name);

      if (control?.invalid) {
        console.log(`Invalid Field: ${name}`, control.errors);
      }
    });

    // Ignore disabled controls during validity check
    const allEnabledControlsValid = names.every(name => {
      const control = this.form121.get(name);
      return control?.disabled || control?.valid;
    });

    return (
      this.missingAutoFields.length === 0 &&
      acknowledgementNumbersUnique &&
      allEnabledControlsValid &&
      this.previousItrDetails.valid
    );
  }

  submitForm(status: 'SAVED' | 'SUBMITTED' = 'SUBMITTED'): void {
    this.submitted = true;
    this.submitError = '';
    this.submitSuccess = '';
    this.missingAutoFields = [];
    if (status === 'SUBMITTED' && !this.isPartAValid()) {
      return;
    }

    const fduserRegId = this.getFdUserRegId();
    if (!fduserRegId) {
      this.submitError = 'User registration details could not be found. Please log in again.';
      return;
    }

    this.isSubmitting = true;
    const value = this.form121.getRawValue();
    const filledForm = status === 'SUBMITTED'
      ? this.createFormPdf().output('datauristring').split(',')[1]
      : null;

    const updateDraft = this.isDraftMode;
    const payload = {
      ...(updateDraft && this.submissionId !== null ? { submissionId: this.submissionId } : {}),
      fduserRegId,
      place: value.place,
      status,
      filledForm,
      form121: {
        ...(updateDraft && this.declarationId !== null ? { declerationId: this.declarationId } : {}),
        name: value.name,
        address: value.address,
        pan: value.pan.toUpperCase(),
        declarantStatus: value.declarantStatus,
        residentialStatus: value.residentialStatus,
        seniorCitizen: value.seniorCitizen,
        emailId: value.emailId,
        countryCode: String(value.countryCode).replace(/^\+/, ''),
        contactNumber: value.contactNumber,
        taxYear: value.taxYear,
        natureOfIncome: value.natureOfIncome,
        estimatedIncomeForDeclaration: value.estimatedIncomeForDeclaration,
        previousForm121Count: value.previousForm121Filed === 'Y' ? value.previousForm121Count : 0,
        previousForm121AggregateIncome: value.previousForm121Filed === 'Y'
          ? value.previousForm121AggregateIncome
          : 0,
        currentAggregateIncome: value.currentAggregateIncome,
        estimatedTotalIncome: value.estimatedTotalIncome,
        previousItrDetails: value.previousItrDetails
          .filter((row: any) => row.taxYear || row.acknowledgementNumber || row.returnIncome !== null)
          .map((row: any, index: number) => ({
            ...(updateDraft && row.itrid !== null && row.itrid !== undefined && row.itrid !== ''
              ? { itrid: row.itrid }
              : {}),
            serialNo: index + 1,
            taxYear: row.taxYear,
            acknowledgementNumber: row.acknowledgementNumber,
            returnIncome: row.returnIncome,
          })),
      },
    }; const encryptedForm121 = this.hybridEncryptor.encrypted(JSON.stringify(payload));

    this.apiService.submitForm121(encryptedForm121).subscribe({
      next: (res) => {
        this.isSubmitting = false;
        console.log(res)
        const message =
          status === 'SAVED'
            ? 'Form 121 saved as draft.'
            : 'Form 121 submitted successfully.';

        if (status === 'SUBMITTED') {
          this.submissionId = null;
          this.declarationId = null;
          this.isDraftMode = false;
          this.setFormMode('');
        } else {
          this.setFormMode(status);
        }
        this.showModal(message, 'success');
        this.loadFormHistory();
      },

      error: (error) => {
        this.isSubmitting = false;

        this.showModal(
          error?.error?.message ||
          'Form 121 submission failed. Please try again.',
          'error'
        );
      },
    });
  }

  private createFormPdf(): jsPDF {
    const pdf = new jsPDF({ unit: 'pt', format: 'a4' });
    const value = this.form121.getRawValue();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 42;
    const contentWidth = pageWidth - margin * 2;
    const labelWidth = Math.round(contentWidth * 0.42);
    const valueWidth = contentWidth - labelWidth;
    let y = margin;

    const addPageIfNeeded = (requiredHeight: number): void => {
      if (y + requiredHeight <= pageHeight - margin) return;
      pdf.addPage();
      y = margin;
    };

    const labelColor: [number, number, number] = [26, 46, 64];
    const borderColor: [number, number, number] = [43, 57, 70];
    const headerBg: [number, number, number] = [240, 243, 246];
    const sectionBg: [number, number, number] = [232, 237, 242];
    const sectionBorder: [number, number, number] = [37, 49, 59];

    const getTextLines = (text: string, width: number, size: number): string[] => {
      pdf.setFontSize(size);
      return pdf.splitTextToSize(String(text || ''), width) as string[];
    };

    const drawRowBorder = (top: number, height: number): void => {
      pdf.setDrawColor(...borderColor);
      pdf.setLineWidth(0.8);
      pdf.rect(margin, top, contentWidth, height);
    };

    const addSectionRow = (label: string, fieldValue: unknown): void => {
      const raw = fieldValue === null || fieldValue === undefined || fieldValue === '' ? '' : String(fieldValue);
      const labelLines = pdf.splitTextToSize(String(label), labelWidth - 14) as string[];
      const valLines = pdf.splitTextToSize(raw, valueWidth - 10) as string[];
      const rowHeight = Math.max(24, Math.max(labelLines.length, valLines.length) * 10.5 + 7);
      addPageIfNeeded(rowHeight);
      drawRowBorder(y, rowHeight);

      pdf.setFillColor(240, 243, 246);
      pdf.rect(margin, y, labelWidth, rowHeight, 'F');
      pdf.setDrawColor(...borderColor);
      pdf.setLineWidth(0.8);
      pdf.line(margin + labelWidth, y, margin + labelWidth, y + rowHeight);

      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8.5);
      pdf.setTextColor(...labelColor);
      let ly = y + 13;
      labelLines.forEach((line) => {
        pdf.text(line, margin + 7, ly);
        ly += 10.5;
      });

      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(9);
      pdf.setTextColor(28, 43, 56);
      let vy = y + 13;
      valLines.forEach((line) => {
        pdf.text(line, margin + labelWidth + 7, vy);
        vy += 10.5;
      });

      y += rowHeight;
    };

    const addSectionTitle = (title: string): void => {
      const height = 24;
      addPageIfNeeded(height);
      drawRowBorder(y, height);
      pdf.setFillColor(...sectionBg);
      pdf.rect(margin, y, contentWidth, height, 'F');
      pdf.setDrawColor(...sectionBorder);
      pdf.setLineWidth(0.8);
      pdf.rect(margin, y, contentWidth, height);
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(12);
      pdf.setTextColor(20, 46, 69);
      pdf.text(title, pageWidth / 2, y + 16, { align: 'center' });
      pdf.setTextColor(0, 0, 0);
      y += height;
    };

    const addWrappedText = (text: string, options?: { bold?: boolean; size?: number }): void => {
      const lines = getTextLines(text, contentWidth - 16, options?.size ?? 9);
      const blockHeight = lines.length * 12 + 10;
      addPageIfNeeded(blockHeight);
      drawRowBorder(y, blockHeight);
      pdf.setFont('helvetica', options?.bold ? 'bold' : 'normal');
      pdf.setFontSize(options?.size ?? 9);
      pdf.setTextColor(26, 46, 64);
      let ty = y + 16;
      lines.forEach((line) => {
        pdf.text(line, margin + 8, ty);
        ty += 12;
      });
      pdf.setTextColor(0, 0, 0);
      y += blockHeight;
    };

    const addHeader = (): void => {
      pdf.setTextColor(23, 63, 103);
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(20);
      pdf.text('FORM NO. 121', pageWidth / 2, y, { align: 'center' });
      y += 16;
      pdf.setFontSize(9);
      pdf.setTextColor(101, 120, 129);
      pdf.text('[See rule 211]', pageWidth / 2, y, { align: 'center' });
      y += 14;
      pdf.setFontSize(12);
      pdf.setTextColor(23, 63, 103);
      pdf.text('Declaration for receipt of certain incomes without deduction of tax', pageWidth / 2, y, { align: 'center' });
      y += 20;
      pdf.setTextColor(0, 0, 0);
    };

    addHeader();
    addSectionTitle('PART A');
    addWrappedText('To be filled by the person for receipt of certain incomes without deduction of tax', { bold: false, size: 9 });
    addSectionRow('1. Name', value.name);
    addSectionRow('2. Address', value.address);
    addSectionRow('3. Permanent Account Number', value.pan);
    addSectionRow('4. Status', value.declarantStatus);
    addSectionRow('5. Residential status', value.residentialStatus);
    addSectionRow('5(a). Resident individual aged 60 or more during the tax year?', value.seniorCitizen === 'Y' ? 'Yes' : 'No');
    addSectionRow('6. Email id', value.emailId);
    addSectionRow('7. Contact number', `${value.countryCode || ''} ${value.contactNumber || ''}`.trim());
    addSectionRow('8. Tax Year', value.taxYear);

    addSectionTitle('Details of income');
    addSectionRow('9. Nature of income', value.natureOfIncome);
    addSectionRow('10. Estimated income for which declaration is made', value.estimatedIncomeForDeclaration);
    addSectionRow('11. Form No. 121 filed earlier during this tax year', value.previousForm121Filed === 'Y' ? 'Yes' : 'No');
    if (value.previousForm121Filed === 'Y') {
      addSectionRow('Total number of earlier forms', value.previousForm121Count);
      addSectionRow('Previous aggregate amount', value.previousForm121AggregateIncome);
    }
    addSectionRow('12. Aggregate amount of income for which declaration is made during the tax year', value.currentAggregateIncome);
    addSectionRow('13. Estimated total income of the tax year including income in column 12', value.estimatedTotalIncome);

    addSectionTitle('14. Details of the ITR filed for previous two tax years');
    const itrRows: any[] = value.previousItrDetails || [];
    const itrCols = [
      { label: 'Sl. No.', width: Math.round(contentWidth * 0.13) },
      { label: 'Tax Year', width: Math.round(contentWidth * 0.25) },
      { label: 'Acknowledgment Number', width: Math.round(contentWidth * 0.36) },
      { label: 'Return Income (₹)', width: Math.round(contentWidth * 0.26) },
    ];
    const itrHeaderBg: [number, number, number] = [240, 243, 246];
    const itrBorder: [number, number, number] = [43, 57, 70];
    const itrRowHeight = 22;

    pdf.setFillColor(...itrHeaderBg);
    pdf.rect(margin, y, contentWidth, itrRowHeight, 'F');
    pdf.setDrawColor(...itrBorder);
    pdf.setLineWidth(0.8);
    pdf.rect(margin, y, contentWidth, itrRowHeight);
    let hx = margin;
    itrCols.forEach((col, ci) => {
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8.5);
      pdf.setTextColor(26, 46, 64);
      pdf.text(col.label, hx + col.width / 2, y + itrRowHeight / 2 + 3, { align: 'center' });
      if (ci < itrCols.length - 1) {
        pdf.setDrawColor(...itrBorder);
        pdf.setLineWidth(0.8);
        pdf.line(hx + col.width, y, hx + col.width, y + itrRowHeight);
      }
      hx += col.width;
    });
    y += itrRowHeight;

    if (!itrRows.length) {
      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(9);
      pdf.setTextColor(28, 43, 56);
      addPageIfNeeded(itrRowHeight);
      pdf.setDrawColor(...itrBorder);
      pdf.setLineWidth(0.8);
      pdf.rect(margin, y, contentWidth, itrRowHeight);
      pdf.text('Not applicable', margin + 8, y + itrRowHeight / 2 + 3);
      y += itrRowHeight;
    } else {
      itrRows.forEach((row, index) => {
        const rHeight = Math.max(itrRowHeight, 15);
        addPageIfNeeded(rHeight);
        pdf.setDrawColor(...itrBorder);
        pdf.setLineWidth(0.8);
        pdf.rect(margin, y, contentWidth, rHeight);
        let x = margin;
        itrCols.forEach((col, ci) => {
          const val = ci === 0 ? String(index + 1) :
            ci === 1 ? String(row.taxYear || '') :
              ci === 2 ? String(row.acknowledgementNumber || '') :
                (row.returnIncome === null || row.returnIncome === undefined || row.returnIncome === '' ? '' : String(row.returnIncome));
          pdf.setFont('helvetica', 'normal');
          pdf.setFontSize(9);
          pdf.setTextColor(28, 43, 56);
          pdf.text(val, x + 5, y + rHeight / 2 + 3);
          if (ci < itrCols.length - 1) {
            pdf.setDrawColor(...itrBorder);
            pdf.setLineWidth(0.8);
            pdf.line(x + col.width, y, x + col.width, y + rHeight);
          }
          x += col.width;
        });
        y += rHeight;
      });
    }

    pdf.addPage();
    y = margin;
    addSectionTitle('DECLARATION');
    const declPoints = [
      'To the best of my knowledge and belief what is stated above is correct, complete and is truly stated;',
      'The incomes referred to in this form are not includible in the total income of any other person under sections 96 to 99 of the Act;',
      `Tax on my estimated total income as referred to in column 13 of Part A, including the income referred to in column 12 of Part A, for tax year ${value.taxYear || '-'} will be nil;`,
      `My income as referred to in column 12 of Part A does not exceed the maximum amount not chargeable to tax for tax year ${value.taxYear || '-'};`,
      'In case this declaration is found to be false, I shall be liable to prosecution/penalty under the Act.',
    ];
    const declState = this.renderDeclarationBlock(pdf, {
      margin,
      contentWidth,
      pageHeight,
      yState: { value: y },
      intro: `I, ${value.declarantName || '-'}, having Permanent Account Number ${value.pan || '-'}, do hereby declare that:`,
      points: declPoints,
      lineHeight: 12,
    });
    y = declState.yState.value;

    addSectionRow('Place', value.place);
    addSectionRow('Date', value.declarationDate);
    addSectionRow('Name', value.declarantName);
    addWrappedText('Signature of the Declarant', { bold: true, size: 9 });

    return pdf;
  }

  private renderDeclarationBlock(
    pdf: jsPDF,
    opts: {
      margin: number;
      contentWidth: number;
      pageHeight: number;
      yState: { value: number };
      intro: string;
      points: string[];
      lineHeight: number;
    }
  ): { yState: { value: number } } {
    const { margin, contentWidth, pageHeight, yState, intro, points, lineHeight } = opts;
    const pad = 12;
    const textWidth = contentWidth - pad * 2;
    const borderColor: [number, number, number] = [43, 57, 70];
    let y = yState.value;

    const textLines = (text: string, size: number): string[] => {
      pdf.setFontSize(size);
      return pdf.splitTextToSize(text, textWidth) as string[];
    };

    const pointLines = points
      .map((point) => pdf.splitTextToSize(point, textWidth - 14) as string[])
      .reduce<string[]>((acc, arr) => acc.concat(arr), []);
    const totalLines = (intro ? textLines(intro, 9).length : 0) + pointLines.length;
    const blockHeight = totalLines * lineHeight + pad * 2;

    if (y + blockHeight > pageHeight - margin) {
      pdf.addPage();
      y = margin;
    }

    pdf.setDrawColor(...borderColor);
    pdf.setLineWidth(0.8);
    pdf.rect(margin, y, contentWidth, blockHeight);

    let ty = y + pad + 9;
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(9);
    pdf.setTextColor(26, 46, 64);

    if (intro) {
      textLines(intro, 9).forEach((line) => {
        pdf.text(line, margin + pad, ty);
        ty += lineHeight;
      });
      points.forEach((point) => {
        const wrapped = pdf.splitTextToSize(point, textWidth - 14) as string[];
        const firstY = ty;
        wrapped.forEach((line, idx) => {
          pdf.text(line, margin + pad + 14, ty);
          ty += lineHeight;
        });
        pdf.text('•', margin + pad + 4, firstY);
      });
    }

    pdf.setTextColor(0, 0, 0);
    yState.value = y + blockHeight + 12;
    return { yState };
  }

  closeForm121Window(): void {
    this.activeModal?.close({ status: this.formStatus });
  }

  print(): void {
    window.print();
  }

  reset(): void {
    this.form121.reset({
      place: '',
      declarantStatus: 'Individual',
      residentialStatus: 'Resident',
      seniorCitizen: 'N',
      countryCode: '+91',
      taxYear: this.currentTaxYear,
      natureOfIncome: 'Interest on securities / deposits',
      previousForm121Filed: 'N',
      previousForm121Count: 0,
      previousForm121AggregateIncome: 0,
      currentAggregateIncome: 0,
      declarationDate: this.today,
      declarantName: '',
    });
    while (this.previousItrDetails.length) this.previousItrDetails.removeAt(0);
    this.previousItrDetails.push(this.createItrRow());
    this.previousItrDetails.push(this.createItrRow());
    this.updatePreviousItrValidators('N');
    this.submitted = false;
    this.submitError = '';
    this.submitSuccess = '';
    this.missingAutoFields = [];
    this.seniorCitizenAutoFilled = false;
    this.submissionId = null;
    this.declarationId = null;
    this.isDraftMode = false;
    this.formStatus = '';
  }

  private getFdUserRegId(): string {
    return this.firstValue(
      this.fduserRegId,
      this.authService.getResponseValueByKey('fduserRegId'),
      this.authService.getResponseValueByKey('fdUserRegId'),
      this.authService.getResponseValueByKey('newFdRegId'),
    );
  }

  private loadExistingForm(): void {
    const fduserRegId = this.getFdUserRegId();
    if (!fduserRegId || this.existingFormLoadStarted) return;

    this.existingFormLoadStarted = true;
    this.apiService.getForm121ByUser(fduserRegId).subscribe({
      next: (response) => this.applyExistingForm(response),
      error: (error) => {
        this.existingFormLoadStarted = false;
        if (error?.status !== 404) {
          this.loadError = 'Existing Form 121 details could not be loaded.';
        }
      },
    });
  }

  private applyExistingForm(response: any): void {
    const records = this.normalizeRecords(response);

    if (!records.length) {
      this.setFormMode('');
      return;
    }

    this.existingFormLoaded = true;

    const latestSaved = this.findLatest(records, (r) => r.status === 'SAVED');



    const record = latestSaved || this.findLatest(records, (r) => r.status === 'SUBMITTED');
    if (!record) {
      this.setFormMode('');
      return;
    }



    const isSavedMode = !!latestSaved;
    this.isDraftMode = isSavedMode;
    this.formStatus = isSavedMode
      ? 'SAVED'
      : 'SUBMITTED';

    if (isSavedMode) {
      this.submissionId = record.submissionId ?? null;
      this.declarationId = record.form121?.declerationId ?? null;
    } else {
      this.submissionId = null;
      this.declarationId = null;
    }

    const savedForm = record.form121 || {};
    const previousItrDetails = Array.isArray(savedForm.previousItrDetails)
      ? savedForm.previousItrDetails
      : [];

    this.form121.patchValue({
      place: record.place || '',
      name: savedForm.name || '',
      address: savedForm.address || '',
      pan: String(savedForm.pan || '').toUpperCase(),
      declarantStatus: savedForm.declarantStatus || 'Individual',
      residentialStatus: savedForm.residentialStatus || 'Resident',
      seniorCitizen: savedForm.seniorCitizen || 'N',
      emailId: savedForm.emailId || '',
      countryCode: savedForm.countryCode ? `+${String(savedForm.countryCode).replace(/^\+/, '')}` : '+91',
      contactNumber: savedForm.contactNumber || '',
      taxYear: savedForm.taxYear || '',
      natureOfIncome: savedForm.natureOfIncome || '',
      estimatedIncomeForDeclaration: savedForm.estimatedIncomeForDeclaration ?? null,
      previousForm121Filed: savedForm.previousForm121Count > 0 || previousItrDetails.length > 0 ? 'Y' : 'N',
      previousForm121Count: savedForm.previousForm121Count ?? 0,
      previousForm121AggregateIncome: savedForm.previousForm121AggregateIncome ?? 0,
      currentAggregateIncome: savedForm.currentAggregateIncome ?? 0,
      estimatedTotalIncome: savedForm.estimatedTotalIncome ?? null,
      declarationDate: this.form121.get('declarationDate')?.value || this.today,
      declarantName: savedForm.name || '',
    }, { emitEvent: false });

    while (this.previousItrDetails.length) this.previousItrDetails.removeAt(0);
    previousItrDetails.forEach((row: any) => {
      this.previousItrDetails.push(this.fb.group({
        itrid: [isSavedMode ? (row.itrid ?? null) : null],
        taxYear: [row.taxYear || '', Form121Validator.taxYear()],
        acknowledgementNumber: [row.acknowledgementNumber || '', Form121Validator.acknowledgementNumber()],
        returnIncome: [row.returnIncome ?? null, Form121Validator.amount()],
      }));
    });
    if (!this.previousItrDetails.length) {
      this.previousItrDetails.push(this.createItrRow());
      this.previousItrDetails.push(this.createItrRow());
    }

    this.seniorCitizenAutoFilled = true;
    this.updatePreviousItrValidators(this.form121.get('previousForm121Filed')?.value);
    this.setFormMode(this.formStatus);
    this.refreshMissingAutoFields();
  }

  private normalizeRecords(response: any): any[] {
    let records: any[] = [];
    if (Array.isArray(response)) {
      records = response;
    } else if (Array.isArray(response?.data)) {
      records = response.data;
    } else if (response?.data) {
      records = [response.data];
    } else if (response) {
      records = [response];
    }
    return records.filter((r) => r && r.status);
  }

  private findLatest(records: any[], predicate: (r: any) => boolean): any | null {
    const matches = records.filter(predicate);
    if (!matches.length) return null;
    return matches.reduce((latest, current) => {
      const latestTime = new Date(latest.dateOfSubmit || latest.submittedAt || latest.createdAt || latest.updatedAt || 0).getTime();
      const currentTime = new Date(current.dateOfSubmit || current.submittedAt || current.createdAt || current.updatedAt || 0).getTime();
      return currentTime > latestTime ? current : latest;
    });
  }

  private setFormMode(status: 'SAVED' | 'SUBMITTED' | ''): void {
    this.formStatus = status;
    this.isFormLocked = false;

    this.form121.enable({ emitEvent: false });
    [
      'place', 'name', 'address', 'pan', 'residentialStatus', 'seniorCitizen',
      'emailId', 'countryCode', 'contactNumber', 'taxYear', 'declarationDate',
      'declarantName',
    ].forEach((field) => this.form121.get(field)?.disable({ emitEvent: false }));

    this.updatePreviousItrValidators(this.form121.get('previousForm121Filed')?.value);
  }

  private updatePreviousItrValidators(previousForm121Filed: string): void {
    const required = previousForm121Filed === 'Y';
    const previousCount = this.form121.get('previousForm121Count');
    const previousAggregate = this.form121.get('previousForm121AggregateIncome');

    previousCount?.setValidators([Validators.required, Validators.min(1)]);
    previousAggregate?.setValidators([Validators.required, Form121Validator.amount()]);

    if (required) {
      previousCount?.enable({ emitEvent: false });
      previousAggregate?.enable({ emitEvent: false });
    } else {
      previousCount?.setValue(0, { emitEvent: false });
      previousAggregate?.setValue(0, { emitEvent: false });
      previousCount?.disable({ emitEvent: false });
      previousAggregate?.disable({ emitEvent: false });
    }

    previousCount?.updateValueAndValidity({ emitEvent: false });
    previousAggregate?.updateValueAndValidity({ emitEvent: false });

    this.previousItrDetails.controls.forEach((row) => {
      const taxYear = row.get('taxYear');
      const acknowledgementNumber = row.get('acknowledgementNumber');
      const returnIncome = row.get('returnIncome');

      taxYear?.setValidators([Form121Validator.taxYear()]);
      acknowledgementNumber?.setValidators([Form121Validator.acknowledgementNumber()]);
      returnIncome?.setValidators([Form121Validator.amount()]);

      row.enable({ emitEvent: false });

      taxYear?.updateValueAndValidity({ emitEvent: false });
      acknowledgementNumber?.updateValueAndValidity({ emitEvent: false });
      returnIncome?.updateValueAndValidity({ emitEvent: false });
    });
  }

  private refreshMissingAutoFields(): void {
    const autoFields: Array<[string, string]> = [
      ['name', 'Name'],
      ['address', 'Address'],
      ['pan', 'PAN'],
      ['residentialStatus', 'Residential status'],
      ['emailId', 'Email'],
      ['countryCode', 'Country code'],
      ['contactNumber', 'Contact number'],
      ['taxYear', 'Tax year'],
      ['place', 'Application place'],
      ['declarationDate', 'Declaration date'],
      ['declarantName', 'Declarant name'],
    ];

    this.missingAutoFields = autoFields
      .filter(([controlName]) => {
        const control = this.form121.get(controlName);
        return !String(control?.value ?? '').trim() || control?.invalid;
      })
      .map(([, label]) => label);

    if (!this.seniorCitizenAutoFilled) {
      this.missingAutoFields.push('Senior-citizen status');
    }
  }

  private populateFromAuthenticatedUser(): void {
    const fdUserId = this.authService.getResponseValueByKey('fdUserId')
      || this.authService.getResponseValueByKey('fdUserEmail');
    if (!fdUserId) return;

    this.isLoading = true;
    this.loadError = '';
    this.fdCacheService.getUserDetails(fdUserId).subscribe({
      next: (user) => {
        console.log('from form 121', user);
        // user.custCifId = "02323"
        user.cif = "02323"
        const cifValue = user?.cif || user?.custCifId;

        this.hasValidCif =
          cifValue !== null &&
          cifValue !== undefined &&
          cifValue !== '';

        if (this.hasValidCif) {
          this.applyUserDetails(user);
        } else {
          this.form121.disable({ emitEvent: false });
        }
      },
      error: () => {
        this.isLoading = false;
        this.loadError =
          'Saved profile details could not be loaded. Please enter the fields manually.';
      },
      complete: () => (this.isLoading = false),
    });

    this.fdCacheService.getUserFullDetails(fdUserId).subscribe({
      next: (details) => this.applyUserDetails(details),
      error: () => undefined,
    });
  }

  private applyUserDetails(source: any): void {
    if (!source) return;
    const session = (key: string) => this.authService.getResponseValueByKey(key) || '';
    const name = this.firstValue(source.fdUserName, source.firDepoName, source.shortName, session('fdUserName'));
    this.customerName = name;
    const pan = this.firstValue(source.fdUserPan, source.panNo, session('fdUserPan')).toUpperCase();
    const address = this.firstValue(source.address, this.joinAddress(source));
    const email = this.firstValue(source.email, source.fdUserEmail, session('fdUserEmail'));
    const mobile = this.onlyDigits(this.firstValue(source.mobNum, source.fdUserMobile, session('fdUserMobile')));
    const countryCode = this.firstValue(source.countryCode, source.mobileCountryCode, session('countryCode'), '+91');
    const residentialStatus = this.firstValue(
      source.residentialStatus,
      source.residentStatus,
      session('residentialStatus'),
      'Resident',
    );
    const dob = this.formatDate(source.dob);
    const place = this.firstValue(
      source.place,
      source.city,
      source.state,
      source.fdBranch,
      source.kycBranchName,
      session('place'),
      session('city'),
      session('kycBranchName'),
    );
    const taxYear = this.firstValue(
      source.taxYear,
      source.financialYear,
      source.taxYearOfDeclaration,
      session('taxYear'),
      this.currentTaxYear,
    );
    const declarationDate = this.formatDate(
      this.firstValue(source.applicationDate, source.declarationDate, source.createdDate),
    ) || this.today;
    this.fduserRegId = this.firstValue(
      source.fduserRegId,
      source.fdUserRegId,
      source.newFdRegId,
      this.fduserRegId,
    );
    if (!this.historyLoaded) {
      this.historyLoaded = true;
      this.loadFormHistory();
    }



    this.form121.patchValue({
      name,
      address,
      pan,
      emailId: email,
      contactNumber: mobile,
      countryCode: countryCode.startsWith('+') ? countryCode : `+${countryCode}`,
      residentialStatus,
      place,
      declarantName: name,
      taxYear,
      declarationDate,
    }, { emitEvent: false });

    if (dob) {
      const age = this.calculateAge(dob);
      this.form121.patchValue({ seniorCitizen: age >= 60 ? 'Y' : 'N' }, { emitEvent: false });
      this.seniorCitizenAutoFilled = true;
    } else if (source.seniorCitizen === 'Y' || source.seniorCitizen === 'N') {
      this.form121.patchValue({ seniorCitizen: source.seniorCitizen }, { emitEvent: false });
      this.seniorCitizenAutoFilled = true;
    }
    this.autoFilled = Boolean(name || pan || email || mobile || address);
    this.refreshMissingAutoFields();
  }

  private joinAddress(source: any): string {
    return [source.line1, source.line2, source.address1, source.address2, source.city, source.state, source.pinCode]
      .filter((part) => part !== null && part !== undefined && String(part).trim())
      .map((part) => String(part).trim())
      .join(', ');
  }

  private firstValue(...values: any[]): string {
    return values.find((value) => value !== null && value !== undefined && String(value).trim())?.toString().trim() || '';
  }

  private onlyDigits(value: string): string {
    return value.replace(/\D/g, '').slice(-10);
  }

  private formatDate(value: any): string {
    if (!value) return '';
    const parts = String(value).replace(/\//g, '-').split('-');
    if (parts.length !== 3) return '';
    if (parts[0].length === 4) return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
    return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
  }

  private calculateAge(date: string): number {
    const dob = new Date(`${date}T00:00:00`);
    const now = new Date();
    let age = now.getFullYear() - dob.getFullYear();
    const beforeBirthday = now.getMonth() < dob.getMonth()
      || (now.getMonth() === dob.getMonth() && now.getDate() < dob.getDate());
    if (beforeBirthday) age--;
    return age;
  }

  private getTaxYear(date: Date): string {
    const startYear = date.getMonth() >= 3 ? date.getFullYear() : date.getFullYear() - 1;
    return `${startYear}-${String(startYear + 1).slice(-2)}`;
  }

  private showModal(
    message: string,
    type: 'success' | 'error'
  ): void {
    this.modalMessage = message;
    this.modalType = type;

    const modalElement = document.getElementById('form121ResultModal');

    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }


  openExistingForm(record: any): void {
    this.openedFromHistory = true;
    this.showFormList = false;
    this.applyExistingForm([record]);
  }

  downloadFormPdf(record: any): void {

    const savedState = this.form121.getRawValue();
    const savedStatus = this.formStatus;

    this.applyExistingForm([record]);

    setTimeout(() => {

      const pdf = this.createFormPdf();

      const customerName =
        (this.customerName || 'Customer')
          .replace(/[^a-zA-Z0-9 ]/g, '')
          .trim()
          .replace(/\s+/g, '_');

      const financialYear =
        record?.form121?.taxYear ||
        'NA';

      const fileName =
        `Form121_${customerName}_${financialYear}.pdf`;

      pdf.save(fileName);

      this.form121.patchValue(savedState, {
        emitEvent: false
      });

      this.formStatus = savedStatus;

    }, 100);

  }

}
