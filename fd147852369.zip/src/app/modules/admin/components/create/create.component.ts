import { AfterViewInit, ChangeDetectorRef, Component, computed, inject, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ApiService } from '../../../../service/api.service';
import { CookieService } from 'ngx-cookie-service';
import { catchError, filter, finalize, firstValueFrom, map, Observable, of, Subject, Subscription, switchMap, takeUntil, tap } from 'rxjs';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
import { CustomValidator } from '../../Constom/validator';
import { AuthService } from '../../../../service/auth.service';
import { NgxSpinnerModule } from "ngx-spinner";
import { NgxSpinnerService } from "ngx-spinner"
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { HostListener } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { NotificationService } from '../../../../service/notification.service';
import { SanitizeInputDirective } from '../../../../sanitize-input.directive';
import { clippingParents, left } from '@popperjs/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Modal, Tooltip } from 'bootstrap';
import { FdForm121Component } from '../fd-form121/fd-form121.component';




@Component({
  selector: 'app-create',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule, NgxSpinnerModule,
    ToastrModule, SanitizeInputDirective, RouterModule],
  templateUrl: './create.component.html',
  styleUrl: './create.component.scss',
  providers: [NotificationService]
})

export class CreateComponent implements OnInit, AfterViewInit, OnDestroy {

  public FDUserName!: string;

  fdStartDate = new Date();   // FD start date
  maturityDate!: Date;       // calculated maturity date
  maturityDateDisplay = '';  // formatted string for UI

  Usedrinfo!: FormGroup;
  shortNamevalue!: any;
  strButton: any;
  disable = true;
  responseUser!: any;
  interestPayout: string = 'maturity';
  todayDate = new Date().toISOString().split('T')[0];
  tenureOption: string = '';

  nonCumulativeQuarterlyRate: number = 0;
  nonCumulativeQuarterlyPayout: number = 0;
  nonCumulativeYearlyRate: number = 0;
  nonCumulativeYearlyPayout: number = 0;

  dobIsMissing: boolean = false;

  // Custom tenure values
  customYear: number | null = null;
  customMonth: number | null = null;
  customDay: number | null = null;

  tenure: number = 18;
  interestRate: number = 0;
  interestEarned: number = 0;
  maturityAmount: any = 0;
  minDate = '1900-01-01';
  kycbranchName: any = []
  schemeList = [, Validators.required];
  createFDForm!: FormGroup;
  depositAmount: number = 0;
  public subtypeLists: any;
  public hybridEncryptor!: HybridEncryptor;
  customValidator: CustomValidator = new CustomValidator();
  nom1ChkControl = new FormControl(false);
  nom2ChkControl = new FormControl(false);
  nom3ChkControl = new FormControl(false);
  autoRenewError: string | null = null;
  FdmaxAmt!: any;
  isSubmitting: boolean = false;
  isAddjointHolderSubmitting: boolean = false;
  FDrNo!: any;
  verfyButtonbooleanVal: boolean = false;

  isSelectDisabled: boolean = false;
  citizenType: string = 'general';

  nomineeForm!: FormGroup;
  nominees: any[] = [];


  branchSearch: string = '';
  filteredBranches: string[] = [];
  selectedBranch: string = '';
  showDropdown: boolean = false;
  hasClickedTerms: boolean = false;
  showNomineeForm = false;
  nomineeModalList: any[] = [];

  /*   nomineeModalList = [
      { name: 'John Doe', depositorRelationship: 'Brother', percentage: 40 },
      { name: 'Jane Smith', depositorRelationship: 'Mother', percentage: 60 }
    ]; */

  submitted = false;
  saveTempCreateFDData: any = {};
  paymentQueryParams: any;
  paymentGateewayDone: boolean = false;
  saveTempCreateNomineeData: any;
  isEmpValidated: boolean = false;
  isAgentVerified: boolean = false;

  selectedNominee: any = null;
  showPercentageInput: boolean = false;
  percentageInput: number = 0;
  bankDetails: any = {};
  totalPercentage: number = 0;
  today: any;
  filteredSubtypeLists: string[] = [];
  branchName: any = '';
  bank_NAME: any = '';
  BANKACC_NO: any = '';
  BANKIFSC_CODE: any = '';
  invCatHoldTypCdList: any;
  @ViewChild('jointModal') jointModal!: TemplateRef<any>;
  @ViewChild('interestRateModal') interestRateModal!: TemplateRef<any>;
  @ViewChild('confirmModal') confirmModal!: TemplateRef<any>;
  showForm = false;
  jointHolders: any[] = [];
  mainFDTable: any[] = [];
  guardianList: any = [];

  /* agent code */

  @ViewChild('agentConfirmModal')
  agentConfirmModal!: TemplateRef<any>;

  fetchedAgentCode: string = '';
  fetchedAgentName: string = '';

  private pendingAgentCode: string = '';
  private agentModalRef: NgbModalRef | null = null;

  panForm = new FormGroup({
    panName: new FormControl('', Validators.required),
    panNumber: new FormControl('', [Validators.required, Validators.pattern(/[A-Z]{5}[0-9]{4}[A-Z]{1}/)]),
    panDOB: new FormControl('', Validators.required),
    kycbranchName: new FormControl('', Validators.required),
    isPEP: new FormControl('No',),
    relationship: new FormControl('', Validators.required),
    mobileNumber: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]),
    emailId: new FormControl([Validators.required, Validators.email])
    /*  guardianName: new FormControl({ value: null, disabled: true }) */

  });

  maxAttempts = 3;
  panAttemptCount = 0;
  panDisabled = false;
  panAttemptMsg!: string;

  aadhaarForm = new FormGroup({
    aadhaarNumber: new FormControl('', [Validators.required, Validators.pattern(/^\d{12}$/)]),
    aadhaarOTP: new FormControl('')
  });

  aadhaarSubmitted: boolean = false;
  panSubmitted: boolean = false;

  sendOTPbtn: boolean = false;
  enableOtpSendmsg: boolean = false;
  finalObjectJointHolder: any = {};
  isMinor: boolean = false;
  enableGurdianErrorMsg: boolean = false;
  enableRelationshipErrorMsg: boolean = false;
  saveTempJointHolderData: any;
  vkycConfirmationAccepted: boolean = false;
  vkycLinkFetchError: boolean = false;
  vkycInitiated: boolean = false;
  isSelectedBelowOneLaks!: string;
  isVkycCompleted: boolean = false;
  proceedWithoutVkycChecked: boolean = false;
  vkycURL: string = '';
  vkycForm!: FormGroup;
  selectedHolder: any = null;
  showVkycPopup: boolean = false;

  // Guardian-specific forms and flags
  guardianPanForm!: FormGroup;
  guardianAadhaarForm!: FormGroup
  guardianVkycForm!: FormGroup

  guardianPanSubmitted = false;
  guardianAadhaarSubmitted = false;
  guardianEnableOtpSentMsg = false;
  guardianVkycConfirmationAccepted = false;
  guardianVkycLinkFetchError = false;
  guardianIsVkycCompleted = false;
  guardianProceedWithoutVkycChecked = false;
  guardianVkycURL: string = '';
  finalObjectJointHolderGuardian: any = {};
  enableGuardianSection: boolean = false;
  holder: any;
  maxDate: string;
  isSaving: boolean = false;

  isForm121Submitted: boolean =  false;

  // --- Customer Journey Progress Tracker ---
  journeySteps = [
    { label: 'Account Details', percentage: 20 },
    { label: 'KYC Verification', percentage: 40 },
    { label: 'Bank Details', percentage: 60 },
    { label: 'Payment Details', percentage: 80 },
    { label: 'Final Submission', percentage: 100 }
  ];
  currentJourneyStep: number = 0;
  enablefileForm121: boolean = false;

  get journeyProgressPercent(): number {
    if (this.currentJourneyStep < 0 || this.currentJourneyStep >= this.journeySteps.length) {
      return 0;
    }
    return this.journeySteps[this.currentJourneyStep].percentage;
  }

  get journeyBarWidth(): number {
    const totalSteps = this.journeySteps.length;
    if (totalSteps <= 1) return 100;
    return (this.currentJourneyStep / (totalSteps - 1)) * 100;
  }

  get completedSteps(): number {
    return this.currentJourneyStep;
  }

  get totalSteps(): number {
    return this.journeySteps.length;
  }

  /** Call this from TS to update stage easily */
  setJourneyStep(step: number): void {
    if (step >= 0 && step < this.journeySteps.length) {
      this.currentJourneyStep = step;
    }
  }

  isStepCompleted(index: number): boolean {
    return index <= this.currentJourneyStep;
  }
  isCurrentStep(index: number): boolean {
    return index == this.currentJourneyStep + 1;
  }
  isStepLocked(index: number): boolean {
    return index > this.currentJourneyStep + 1;
  }


  getStepIcon(index: number): string {
    if (this.isStepCompleted(index)) return 'fa-check';
    if (this.isCurrentStep(index)) return '';
    return 'fa-lock';
  }

  private destroy$ = new Subject<void>();
  draftFDrNo: string | null = '';
  maturityAmountRaw: number = 0;
  depositAmountDisplay: string = '';
  schemeCdToolTip: string = 'Interest is received every quarter (3 months).';
  nonCumulative: string = '<strong>Non cumulative FD:</strong>  Interest is paid out periodically (monthly/quarterly/annually) instead of being reinvested.';
  brokerDetails: any;
  selectedAgentCode: any = "0";
  confirmTitle = 'Confirmation';
  confirmMessage = '';
  confirmAcceptLabel = 'Yes';
  confirmRejectLabel = 'No';
  private confirmAcceptAction: (() => void) | null = null;
  private confirmRejectAction: (() => void) | null = null;
  private confirmModalRef: NgbModalRef | null = null;

  // Joint holder Aadhaar OTP
  aadhaarOtpSent: boolean = false;
  canResendAadhaarOtp: boolean = false;
  aadhaarResendTimer: number = 60;
  private aadhaarResendInterval: any;

  // Guardian Aadhaar OTP
  guardianAadhaarOtpSent: boolean = false;
  canResendGuardianAadhaarOtp: boolean = false;
  guardianAadhaarResendTimer: number = 60;
  private guardianAadhaarResendInterval: any;

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private CookieService: CookieService,
    private authService: AuthService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private cdChanges: ChangeDetectorRef,
    private route: ActivatedRoute,
    private notify: NotificationService,
    private modalService: NgbModal,


  ) {

    this.vkycForm = this.fb.group({
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      emailId: ['', [Validators.required, Validators.email]]
    });



    const today = new Date();
    today.setDate(today.getDate() - 1); // Set to yesterday
    this.maxDate = today.toISOString().split('T')[0];


    // Guardian-specific forms and flags
    this.guardianPanForm = new FormGroup({
      panName: new FormControl('', Validators.required),
      panNumber: new FormControl('', [Validators.required, Validators.pattern(/[A-Z]{5}[0-9]{4}[A-Z]{1}/)]),
      panDOB: new FormControl('', Validators.required),
      kycbranchName: new FormControl('', Validators.required),
      relationship: new FormControl('', Validators.required),
    });

    this.guardianAadhaarForm = new FormGroup({
      aadhaarNumber: new FormControl('', [Validators.required, Validators.pattern(/^\d{12}$/)]),
      aadhaarOTP: new FormControl('', [Validators.minLength(4), Validators.maxLength(8)]),
    });

    this.guardianVkycForm = this.fb.group({
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      emailId: ['', [Validators.required, Validators.email]],
    });
  }
  subscription: Subscription = new Subscription();

  @HostListener('paste', ['$event'])
  handlePaste(event: ClipboardEvent) {
    const pasted = event.clipboardData?.getData('text') || '';
    const unsafePattern = /[^a-zA-Z0-9 _.-]/;

    if (unsafePattern.test(pasted)) {
      event.preventDefault();

    }
  }

  ngOnInit(): void {

    this.dobIsMissing = false;
    this.enablefileForm121 = false;


    this.draftFDrNo = null;
    this.enableGuardianSection = false;
    this.panForm.get('panDOB')?.valueChanges.subscribe((dob: any) => {
      this.isMinor = false;
      this.toggleGuardianField(dob);
    });



    const now = new Date();
    this.today = now.toISOString().split('T')[0]; // Format: YYYY-MM-DD


    this.paymentGateewayDone = false;
    this.hasClickedTerms = false;
    this.isEmpValidated = false;

    this.route.queryParams.subscribe(queryParams => {
      this.paymentQueryParams = queryParams;

    });


    this.hybridEncryptor = new HybridEncryptor();
    if (this.CookieService.get('paymentDetailsW')) {
      const val = this.CookieService.get('paymentDetailsW');
      let jsonV = JSON.parse(val);
      let myRes = { encryptedKey: jsonV.encryptedKey, encryptedData: jsonV.encryptedData, iv: jsonV.iv }
      let decrypt = this.hybridEncryptor.newdecryptHybridData(myRes, this.hybridEncryptor)

      this.saveTempCreateFDData = decrypt;
      this.getUserBankDetails();


    }

    if (this.CookieService.get('mainNominees')) {
      const val = this.CookieService.get('mainNominees');
      let jsonV = JSON.parse(val);
      let myRes = { encryptedKey: jsonV.encryptedKey, encryptedData: jsonV.encryptedData, iv: jsonV.iv }
      let decrypt = this.hybridEncryptor.newdecryptHybridData(myRes, this.hybridEncryptor)

      this.saveTempCreateNomineeData = this.objectToArray(decrypt);
      console.log('>>>>>>>>saveTempCreateNomineeData', this.saveTempCreateNomineeData)

    }


    if (this.CookieService.get('mainJointHolders')) {
      const val = this.CookieService.get('mainJointHolders');
      let jsonV = JSON.parse(val);
      let myRes = { encryptedKey: jsonV.encryptedKey, encryptedData: jsonV.encryptedData, iv: jsonV.iv }
      let decrypt = this.hybridEncryptor.newdecryptHybridData(myRes, this.hybridEncryptor)

      this.saveTempJointHolderData = this.objectToArray(decrypt);
      console.log('>>>>>>>>saveTempCreateJointHolderData', this.saveTempJointHolderData)

    }


    this.filteredBranches = this.kycbranchName;
    // // this.spinner.show();
    // setTimeout(() => {
    //   //this.spinner.hide();
    // }, 1000)





    this.createFDForm = this.fb.group({

      cifCd: [''],
      nom1GuardAddr: [''],
      nom1RelWGuard: [''],
      state: [''],
      pinCode: [''],
      occupation: [''],
      dob: [''],
      gender: [''],
      mobNum: [''],
      emailId: [''],
      city: [''],
      panNo: [''],

      fdUserEmail: [''],
      branchCd: ['', Validators.required],

      schemeCd: ['QUARTERLY COMPOUNDING', Validators.required,],
      customYear: [1],
      customMonth: [0],
      customDay: [0],
      tenureType: ['1'],

      agentCode: [
        0,
        [

          Validators.pattern('^[0-9]+$')
        ]
      ],

      fdUserMobile: [''],
      period: ['', Validators.required,],
      catSubTypCd: ['', Validators.required],
      intRate: ['', Validators.required],
      amount: ['',
        [
          Validators.required,
          Validators.min(10000),
          Validators.pattern(/^\d+000$/)  // multiples of 1000
        ]
      ],
      autoRenewFlag: ['N', Validators.required],
      taxExemptFlag: ['Y', Validators.required],
      invCategory: ['',],/*  */
      invCatHoldTypCd: ['',],/*  */
      shortName: [''],
      nriFlag: ['',],
      custBankName: ['',],
      custBranch: ['',],
      payeeName: ['',],
      custAccType: ['',],/*  */
      custAccNum: ['', [, Validators.pattern(/^[0-9]{9,18}$/)]],/*  */
      custIfsc: ['',],
      mopCd: ['PG', Validators.required],
      neftNum: [{ value: '', disabled: false }, Validators.required],
      neftDt: [{ value: '', disabled: false }, Validators.required],
      // neftDop:['',Validators.required],
      saveFlag: [''],
      empCode: ['',],
      strButton: [''],
      custCode: [''],
      entryId: [''],
      vkycFlag: [''],
      ckycFlag: [''],
      fdUserId: [''],
      newFdRegId: [''],
      empStatus: [''],
      jointHolName: [''],
      depositorType: ['SOLE'],
      depositorIs: [null],
      autoRenewType: [{ value: null, disabled: false }] // P or B

    }, { validators: [this.tenureValidator()] });





    this.nomineeForm = this.fb.group({
      name: ['', Validators.required],
      dob: ['', Validators.required],
      address: ['', Validators.required],
      ownerPercentage: ['',],
      relationship: ['', Validators.required]
    });


    if (this.paymentQueryParams?.razorpay_payment_link_status) {
      this.paymentGateewayDone = true;
      this.createFDForm.get('mopCd')?.setValue('PG')
      this.createFDForm.get('mopCd')?.disable();
      this.updateJourneyStep();

      const cookieData = this.CookieService.get('paymentDetailsW');
      if (cookieData && this.saveTempCreateFDData) {
        try {
          // const parsedData = JSON.parse(cookieData);
          Object.keys(this.saveTempCreateFDData).forEach(key => {
            if (this.createFDForm.contains(key)) {
              if (key == 'autoRenewFlag') {

                if (this.saveTempCreateFDData[key] != 'N') {
                  this.createFDForm.get('autoRenewFlag')?.setValue('Y')
                }

              } else if (key == 'agentCode') {
                this.createFDForm.get('agentCode')?.setValue(this.saveTempCreateFDData[key]);
                this.selectedAgentCode = this.saveTempCreateFDData[key];
                if (this.selectedAgentCode != "0") {
                  this.verifyAgentCode();

                }
              } else {

                this.createFDForm.get(key)?.setValue(this.saveTempCreateFDData[key]);
              }
            }
            if (key == 'entryId') {
              this.draftFDrNo = this.saveTempCreateFDData[key];
              this.FDrNo = this.saveTempCreateFDData[key];
            }

            if (key == 'isAgentVerified') {

              this.isAgentVerified = this.saveTempCreateFDData[key]
            }

            if (key == 'autoRenewType') {
              this.createFDForm.get('autoRenewType')?.setValue(this.saveTempCreateFDData[key]);
              this.cdChanges.detectChanges();
            }




          });
          this.getTenureDetails(this.saveTempCreateFDData['period'])
          this.selectBranch(this.createFDForm.get('branchCd')?.value);
          if (this.saveTempCreateFDData['empCodeValidated']) {
            this.isEmpValidated = this.saveTempCreateFDData['empCodeValidated']
            this.createFDForm.get('empCode')?.disable();
            this.cdChanges.detectChanges();
          } else {

          }
        } catch (err) {
          console.error('Cookie parse error:', err);
        }

        this.updateReturns();


      }

      const cookieNominee = this.CookieService.get('mainNominees');
      if (cookieNominee && this.saveTempCreateNomineeData.length > 0) {
        this.nominees = this.saveTempCreateNomineeData;
        this.totalPercentage = this.nominees.reduce((sum, nominee) => sum + JSON.parse(nominee.ownerPercentage), 0);

      }

      const cookieJointHolder = this.CookieService.get('mainJointHolders');
      if (cookieJointHolder && this.saveTempJointHolderData.length > 0) {
        this.mainFDTable = this.saveTempJointHolderData;

      }

      this.getPaymentStatusDetails(this.paymentQueryParams);
    }








    this.nom2ChkControl.valueChanges.subscribe(() => this.toggleNomineeFields(2));
    this.nom3ChkControl.valueChanges.subscribe(() => this.toggleNomineeFields(3));
    this.nriFlagDefaultValue();
    this.userFdDetailsView();
    this.branchList();
    this.getDropdownList();
    this.stafselection();
    this.onAutoRenewChange();
    this.getfdrNumber();


    this.createFDForm.get('customYear')?.valueChanges.subscribe(() => {
      if (this.createFDForm.get('customYear')?.value == 5) {

        this.createFDForm.get('customMonth')?.setValue(0);
      }
      this.updateReturns();

    });
    this.createFDForm.get('customMonth')?.valueChanges.subscribe(() => this.updateReturns());
    this.createFDForm.get('customDay')?.valueChanges.subscribe(() => this.updateReturns());

    this.getUserBankDetails();
    this.getBankDetails();
    this.getHoldGuardDetails();

    this.createFDForm.get('depositorType')?.valueChanges.subscribe(value => {
      const invCatHoldControl = this.createFDForm.get('invCatHoldTypCd');

      if (value === 'JOINT') {
        invCatHoldControl?.setValidators([Validators.required]);
        invCatHoldControl?.reset();

      } else {
        invCatHoldControl?.clearValidators();
      }

      invCatHoldControl?.updateValueAndValidity();
    });




    this.route.paramMap
      .pipe(
        map(params => params.get('entryId')),
        tap(id => {
          this.draftFDrNo = id;
          this.FDrNo = id;
        }),
        // Only call API when we’re in "manage" mode with a valid id
        filter((id): id is string => !!id),
        tap(() => (this.spinner.show())),
        switchMap((id) => {
          const fdUserId = this.authService.getResponseValueByKey('fdUserEmail') || ''
          const jointHolderReq = {
            entryId: id,
            fdUserId: fdUserId,
            cif: this.createFDForm.get('cifCd')?.value,
          }
          const payload = this.hybridEncryptor.encrypted(JSON.stringify(jointHolderReq));
          return this.apiService.getFDJointHoldersDetails(payload).pipe(
            catchError(err => {
              console.error('Failed to fetch joint holders', err);
              // surface a user-friendly message (toast/snackbar) if you use one
              return of(null);
            }),
            finalize(() => (this.spinner.hide()))
          );
        }),
        takeUntil(this.destroy$)
      )
      .subscribe((resp) => {
        // Adjust this mapping based on your actual API response shape
        // e.g., resp?.data?.jointHolders, resp?.result, etc.
        if (resp) {
          /* this.jointHolders = Array.isArray(resp)
            ? resp
            : (resp?.data ?? resp?.result ?? []); */
          console.log(resp);

          this.filterRequiredData$(resp).subscribe(filterValue => {
            console.log('Final object:', filterValue);
            this.applyDraftFDentry(filterValue);
            this.updateReturns();
            this.CookieService.delete('paymentDetailsW');
            this.CookieService.delete('paymentReqId');
            this.CookieService.delete('mainNominees');
            this.CookieService.delete('mainJointHolders');
            // use finalObj here (navigate / submit / store)
          });


          // If you’re prefilling a form:
          // this.form.patchValue(...)
        }
      });



    this.createFDForm.get('schemeCd')?.valueChanges.subscribe((val) => {
      if (val == 'ANNUAL INCOME') {
        this.schemeCdToolTip = 'Interest is paid once a year directly to your account.'

      } else if (val == 'QUARTERLY INCOME') {
        this.schemeCdToolTip = 'Interest is paid to you every 3 months and not reinvested.'

      } else if (val == 'QCAP') {
        this.schemeCdToolTip = 'Interest is compounded every quarter but paid out once a year.'

      } else if (val == 'QUARTERLY COMPOUNDING') {
        this.schemeCdToolTip = 'Interest is received every quarter (3 months).'
      }
    })

    this.createFDForm.get("taxExemptFlag")?.valueChanges.subscribe((res) => {
      if(res == 'Y' && this.isForm121Submitted == false){         
         this.enablefileForm121 = true;
      }
    })

    this.updateJourneyStep();

  }


  applyDraftFDentry(resValue: any) {
    if (resValue) {
      try {
        const parsedData: any = resValue;
        Object.keys(parsedData).forEach(key => {
          if (this.createFDForm.contains(key)) {
            if (key == 'autoRenewFlag') {
              const flag = parsedData[key] != 'N' ? 'Y' : 'N';
              this.createFDForm.get(key)?.setValue(flag);
              this.createFDForm.get('autoRenewType')?.setValue(parsedData[key])
            } else if (key == 'invCatHoldTypCd') {
              const holdYype = parsedData[key] != null ? 'JOINT' : 'SOLE';
              this.createFDForm.get('depositorType')?.setValue(holdYype);

              this.createFDForm.get(key)?.setValue(parsedData[key]);

            } else if (key == 'taxExemptFlag') {
              const flag = parsedData[key] == 'YES' ? 'Y' : 'N';
              this.createFDForm.get(key)?.setValue(flag)
            } else if (key == 'agentCode') {
              this.createFDForm.get(key)?.setValue(parsedData[key])
              this.isAgentVerified = parsedData[key] != '0' ? true : false;
              if (this.isAgentVerified) {
                this.selectedAgentCode = parsedData[key];
                if (this.selectedAgentCode != "0") {

                  this.verifyAgentCode();
                }
              }
            }
            else {

              this.createFDForm.get(key)?.setValue(parsedData[key]);
            }
          } else {
            if (key == 'nomiees') {
              this.nominees = parsedData['nomiees'];
              this.totalPercentage = this.nominees.reduce((sum, nominee) => sum + JSON.parse(nominee.ownerPercentage), 0);
            } else if (key == 'fdPgStatus' && parsedData['fdPgStatus'] == 'paid') {
              this.createFDForm.get('amount')?.disable();
              const today = new Date();
              const formattedDate = today.toISOString().split('T')[0]; // 'yyyy-MM-dd'
              const req = { reqId: this.draftFDrNo };
              const encrypt = this.hybridEncryptor.encrypted(JSON.stringify(req))
              this.spinner.show();
              this.apiService.getStatusForPayment(encrypt).subscribe((res) => {
                console.log('payment api res Draft', res);
                this.spinner.hide();
                this.createFDForm.get('neftNum')?.setValue(res?.paymentUtrNo);
                this.createFDForm.get('neftDt')?.setValue(formattedDate);
                this.createFDForm.get('neftNum')?.disable();
                this.createFDForm.get('neftDt')?.disable();
                for (const field in this.createFDForm.controls) {
                  const control = this.createFDForm.get(field);
                  if (control && control.invalid) {
                    console.log(`Field '${field}' is invalid`);
                    console.log(control.errors); // Shows specific validation errors
                  }
                }

              }, (error) => {
                this.spinner.hide();
                this.notify.warning('Apologies for the inconvenience. Please contact our Support Team at fd@sidbi.in for assistance.', 'Warning');
              })
              this.paymentGateewayDone = true;
              this.updateJourneyStep();
            }

          }
        });
        this.getTenureDetails(parsedData['period']);
        this.cdChanges.detectChanges();
        this.selectBranch(this.createFDForm.get('branchCd')?.value);
        if (parsedData['empCodeValidated']) {
          this.isEmpValidated = parsedData['empCodeValidated']
          this.createFDForm.get('empCode')?.disable();

        } else {

        }

      } catch (err) {
        console.error('Cookie parse error:', err);
      }

      this.updateReturns();
    }
  }




  filterRequiredData$(entry: any): Observable<any> {
    const fdId = entry?.entryId;
    const nomineeReq = { fdId };

    return this.apiService.getFdNomineeDetails(
      this.hybridEncryptor.encrypted(JSON.stringify(nomineeReq))
    ).pipe(
      map((res) => ({

        entryId: entry?.entryId,
        cifCd: entry?.cif,
        branchCd: entry?.fdBranch,
        schemeCd: entry?.fdScheme,
        period: entry?.fdPeriod,
        catSubTypCd: entry?.catSubTypCd,
        intRate: entry?.intRate,
        amount: entry?.fdAmount,
        empCode: entry?.empCode,
        taxExemptFlag: entry?.taxExempt,
        mopCd: entry?.mop,
        neftNum: entry?.neftNum,
        neftDt: entry?.neftDt,
        wudUserId: this.authService.getResponseValueByKey('fdUserId'),
        autoRenewFlag: entry?.fdAutoRenew,
        invCatHoldTypCd: entry?.invCatHoldType,
        nomiees: res, // ✅ actual API data
        jointHoldersList: this.findHolderAndGuaridan(entry),
        ...entry
      }))
    );
  }




  findHolderAndGuaridan(list: any): any[] {

    const userPan = this.createFDForm.get("panNo")?.value;
    let gurndian: any[] = [];
    if (list?.fdJointHoldDetails?.length > 0) {
      const allHolders = list?.fdJointHoldDetails || [];

      const jointHolders = allHolders.filter((val: any) => val.guardFlag === 'N');
      const guardians = allHolders.filter((val: any) => val.guardFlag === 'Y');

      // Initialize guardianList
      this.guardianList = [];

      this.mainFDTable = jointHolders.map((holder: any) => {
        const guardian = guardians.find((g: any) => g.jointGuardMapFlag === holder.pan);
        const holderWithGuardianFlag = guardian ? { ...holder, hasGuardian: true } : holder;

        // Remove matched guardian from guardians list to avoid duplication
        if (guardian) {
          // Optional: remove matched guardian from the list
          guardians.splice(guardians.indexOf(guardian), 1);
          return [holderWithGuardianFlag, { ...guardian, isGuardian: true }];
        } else {
          return [holderWithGuardianFlag];
        }
      }).flat();
      this.guardianList = guardians.filter((res: any) => res.jointGuardMapFlag == userPan);
      console.log(this.guardianList, this.mainFDTable)


    }

    return this.mainFDTable;
  }

  toggleGuardianField(dob: string) {
    if (!dob) return;

    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age < 18) {

      this.notify.warning('Minor can not add as Joint holder please reach out nearest SIDBI branch', 'Alert')
      this.panForm.reset();
      return

      // this.panForm.get('guardianName')?.enable();

      //  this.isMinor = true;
      /*  this.finalObjectJointHolderGuardian = {
 
         pan: null,
         name: null,
         dob: null,
         guardFlag: 'N',
         panVerifyFlag: null,
         kycBranchCd: null,
         userId: null,
         relationship: null,
         aadharNo: null,
         postalCode: '',
         newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
         aadharFlag: null,
         isPEP: null,
         mobileNo: null,
         vkycFlag: null,
         vkycUrl: null,
         jointGuardMapFlag: null
 
 
       }; */
    } else {
      // this.panForm.get('guardianName')?.disable();
      this.isMinor = false;
      this.finalObjectJointHolderGuardian = {

        pan: null,
        name: null,
        dob: null,
        guardFlag: 'Y',
        panVerifyFlag: null,
        kycBranchCd: null,
        userId: null,
        relationship: null,
        aadharNo: null,
        postalCode: '',
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        aadharFlag: null,
        isPEP: null,
        mobileNo: null,
        vkycFlag: null,
        vkycUrl: null,
        jointGuardMapFlag: null


      };
    }
  }


  ngAfterViewInit(): void {
    /*     if (this.paymentQueryParams?.razorpay_payment_link_status) {
          this.spinner.show();
          this.getPaymentStatusDetails(this.paymentQueryParams); 
        } */
  }

  objectToArray(nomineeObj: any): any[] {
    return Object.values(nomineeObj);
  }

  private stripHtml(content: string): string {
    return content
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/p>/gi, '\n')
      .replace(/<[^>]*>/g, '')
      .replace(/\n{2,}/g, '\n')
      .trim();
  }

  private confirmAction(
    message: string,
    onAccept: () => void,
    onReject?: () => void,
    header?: string
  ): void {
    this.confirmTitle = header || 'Confirmation';
    this.confirmMessage = message;
    this.confirmAcceptLabel = 'Yes';
    this.confirmRejectLabel = 'No';
    this.confirmAcceptAction = onAccept;
    this.confirmRejectAction = onReject || null;
    this.confirmModalRef = this.modalService.open(this.confirmModal, {
      centered: true,
      backdrop: 'static',
      keyboard: false,
    });
    this.confirmModalRef.result.finally(() => {
      this.confirmModalRef = null;
    });
  }

  onConfirmAccept(): void {
    this.confirmModalRef?.close();
    const action = this.confirmAcceptAction;
    this.resetConfirmState();
    action?.();
  }

  onConfirmReject(): void {
    this.confirmModalRef?.dismiss();
    const action = this.confirmRejectAction;
    this.resetConfirmState();
    action?.();
  }

  private resetConfirmState(): void {
    this.confirmTitle = 'Confirmation';
    this.confirmMessage = '';
    this.confirmAcceptLabel = 'Yes';
    this.confirmRejectLabel = 'No';
    this.confirmAcceptAction = null;
    this.confirmRejectAction = null;
  }


  getUserBankDetails(): void {
    const data = {
      fdRegId: this.authService.getResponseValueByKey('newFdRegId'),
    };
    const encryptedPayload = this.hybridEncryptor.encrypted(
      JSON.stringify(data)
    );
    this.subscription.add(
      this.apiService.getbankDetails(encryptedPayload).subscribe({
        next: (response: any) => {
          if (response && response.length > 0) {
            const bankDetails = response[0];

            this.bankDetails = {
              custAccType: bankDetails.custAccType?.toLowerCase(), // Ensure it matches the dropdown value
              custBankName: bankDetails.custBankName,
              custBranch: bankDetails.custBranch,
              payeeName: bankDetails.payeeName,
              custAccNum: bankDetails.custAccNum,
              custIfsc: bankDetails.custIfsc,
            };
            this.updateJourneyStep();
            if (this.bankDetails.custAccNum == null || this.bankDetails.custAccNum === '') {
              this.confirmAction(
                `Ensure bank details before FD submission. <br> Would you like to redirect bank details section `,
                () => this.router.navigate(['/dashboard/accountDetails']),
                () => console.log('Cancel'),
                'Bank Details'
              );
            }

          } else {
            if (response.length == 0) {
              this.confirmAction(
                `Ensure bank details before FD submission. <br> Would you like to redirect bank details section `,
                () => this.router.navigate(['/dashboard/accountDetails']),
                () => console.log('Cancel'),
                'Bank Details'
              );
            }
          }
        },
        error: (err) => {
          console.error('Error fetching bank details:', err);
        },
      })
    );
  }


  getBankDetails(): void {
    this.kycbranchName = this.authService.getResponseValueByKey('kycBranchName');
    let data = {
      kycBranchName: this.kycbranchName,
    };
    this.subscription.add(
      this.apiService
        .getBankDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response) {
              this.bank_NAME = response.split(',')[0];
              this.BANKACC_NO = response.split(',')[1];
              this.BANKIFSC_CODE = response.split(',')[2];

            }
          },
        })
    );
  }

  tenureValidator(): ValidatorFn {
    return (form: AbstractControl): ValidationErrors | null => {
      const tenureType = form.get('tenureType')?.value;
      if (tenureType !== 'custom') return null; // only validate when custom



      const year = +(form.get('customYear')?.value ?? 0);
      const month = +(form.get('customMonth')?.value ?? 0);
      const day = +(form.get('customDay')?.value ?? 0);

      const totalMonths = year * 12 + month;

      // --- Rule 3: Minimum 6 months ---
      if (totalMonths < 6) {
        return { minTenureNotMet: true };
      }

      // --- Rule 1: Max 60 months allowed ---
      // If totalMonths exceeds 60 → invalid
      if (totalMonths > 60) {
        return { maxTenureExceeded: true };
      }

      // If exactly 60 months, days must be zero
      if (totalMonths === 60 && day > 0) {
        return { maxTenureExceeded: true };
      }

      // --- Rule 2: If exactly 5 years, months and days must be 0 ---
      if (year === 5 && (month > 0 || day > 0)) {
        return { invalidFiveYearSelection: true };
      }

      return null;
    };
  }






  termsClicked() {
    this.hasClickedTerms = true;
    this.updateJourneyStep();
  }



  getPaymentStatusDetails(params: any) {
    this.spinner.show();
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0]; // 'yyyy-MM-dd'

    if (params?.razorpay_payment_link_status && this.CookieService.get('paymentReqId')) {
      this.spinner.show();
      const req = { reqId: this.FDrNo };
      const encrypt = this.hybridEncryptor.encrypted(JSON.stringify(req))
      this.apiService.getStatusForPayment(encrypt).subscribe((res) => {
        this.spinner.hide();
        this.createFDForm.get('neftNum')?.setValue(res?.paymentUtrNo);
        this.createFDForm.get('neftDt')?.setValue(formattedDate);
        this.createFDForm.get('neftNum')?.disable();
        this.createFDForm.get('neftDt')?.disable();
        this.createFDForm.get('amount')?.disable();

      }, (error) => {
        this.spinner.hide();
        this.notify.warning('Apologies for the inconvenience. Please contact our Support Team at fd@sidbi.in for assistance.', 'Warning');
      })
    }

  }
  getTenureDetails(period: number): any {
    const roundedPeriod = Math.round(period * 100) / 100;

    if (roundedPeriod === 12) {
      return this.createFDForm.get('tenureType')?.setValue('1');


    }

    if (roundedPeriod === 36) {
      return this.createFDForm.get('tenureType')?.setValue('3');
    }

    // Approximate conversion for custom
    const totalDays = Math.round(period * 30.44); // average days per month
    const years = Math.floor(totalDays / 365);
    const remainingDays = totalDays % 365;
    const months = Math.floor(remainingDays / 30.44);
    const days = Math.round(remainingDays % 30.44);

    this.createFDForm.get('tenureType')?.setValue('custom')
    this.createFDForm.get('customYear')?.setValue(years);
    this.createFDForm.get('customMonth')?.setValue(months);
    this.createFDForm.get('customDay')?.setValue(days);

  }



  filterBranches(event: any) {
    const search = event.target.value.toLowerCase();

    // Reset selected value if user starts typing again
    this.selectedBranch = '';
    this.createFDForm.controls['branchCd'].setValue('');

    this.filteredBranches = this.kycbranchName.filter(
      (branch: string) =>
        branch.toLowerCase().includes(search) &&
        branch.toUpperCase() !== 'MUMBAI-BKC'
    );
  }

  selectBranch(branch: string) {
    this.selectedBranch = branch;
    this.branchSearch = branch;
    this.showDropdown = false;

    // Only selected branch gets stored in form
    this.createFDForm.controls['branchCd'].setValue(branch);

    // Mark control as touched
    this.createFDForm.controls['branchCd'].markAsTouched();
  }


  /*   addNominee(): void {
      if (this.nomineeForm.valid) {
        const newPercentage = this.nomineeForm.value.percentage;
        const totalPercentage = this.nominees.reduce((sum, nominee) => sum + nominee.percentage, 0);
  
        if (totalPercentage + newPercentage > 100) {
          alert('Total proportionate percentage cannot exceed 100%. Cannot add more nominees.');
          return;
        }
  
        this.nominees.push(this.nomineeForm.value);
        this.nomineeForm.reset();
      } else {
        this.nomineeForm.markAllAsTouched();
      }
    } */

  async submitModalForm(): Promise<void> {
    if (this.isSaving) return; // Prevent multiple clicks
    this.submitted = true;
    if (this.nomineeForm.valid) {
      this.isSaving = true; // Disable button
      const newNominee = this.nomineeForm.value;
      const primaryshortName = this.authService.getResponseValueByKey('fdUserName') || '';
      const dob = await this.userDetailsView();
      const totalPercentage = this.nominees.reduce((sum, nominee) => sum + nominee.percentage, 0) + newNominee.percentage;
      if (totalPercentage > 100) {
        this.notify.warning('Total percentage cannot exceed 100%', 'Warning');
        this.isSaving = false;
        return;
      }

      const nomineeName = this.nomineeForm.get('name')?.value || '';
      const nomineeDob = this.nomineeForm.get('dob')?.value;

      if (primaryshortName.toLowerCase() === nomineeName.toLowerCase() && dob === nomineeDob) {
        this.notify.warning('Primary depositor cannot be added as a nominee');
        this.isSaving = false;
        return;
      }

      const isDuplicate = this.nomineeModalList.some(nominee => {
        const nomineeDate = new Date(nominee.dob).toISOString().split('T')[0];
        const formDate = new Date(nomineeDob).toISOString().split('T')[0];
        return nominee.name?.toLowerCase() === nomineeName.toLowerCase() && nomineeDate === formDate;
      });

      if (isDuplicate) {
        this.notify.warning('Duplicate nominee found with same name and date of birth', 'Warning');
        this.isSaving = false;
        return;
      }

      let newFdRegId = this.createFDForm.get('newFdRegId')?.value;
      const reqData = {
        fdRegId: newFdRegId,
        name: nomineeName,
        dob: nomineeDob,
        address: this.nomineeForm.get('address')?.value,
        relationship: this.nomineeForm.get('relationship')?.value
      };

      this.subscription.add(
        this.apiService.saveNomineeDetails(this.hybridEncryptor.encrypted(JSON.stringify(reqData))).subscribe({
          next: (res: any) => {
            this.getNomineeDetails();
            this.nomineeForm.reset();
            this.showNomineeForm = false;
            this.notify.success(res?.message, 'Add Nominee');
            this.isSaving = false; // Re-enable button
          },
          error: () => {
            this.isSaving = false; // Re-enable button on error
          }
        })
      );
    } else {
      this.nomineeForm.markAllAsTouched();
    }
  }

  async userDetailsView(): Promise<string | null> {
    const data = {
      newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
    };
    try {
      const response = await this.apiService
        .userDetailsView(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .toPromise();

      if (response?.dob) {
        const [day, month, year] = response.dob.split(/[/\-]/);
        const formattedDate = `${year}-${month}-${day}`; // e.g., '1999-05-20'
        return formattedDate;
      }
      return null; // dob not found
    } catch (err) {
      console.error('An error occurred:', err);
      return null;
    }
  }




  addToMainList(nominee: any): void {
    if (nominee.ownerPercentage != '0') {

    }
    const totalPercentage = this.nominees.reduce((sum, n) => sum + JSON.parse(n.ownerPercentage), 0) + JSON.parse(nominee.ownerPercentage);

    if (totalPercentage > 100) {

      this.notify.warning('Total percentage cannot exceed 100%', 'Warning', 'toast-bottom-center');

      return;
    }

    this.nominees.push(nominee);
  }


  getNomineeDetails() {
    let newFdRegId = this.createFDForm.get('newFdRegId')?.value;
    const reqData = {
      "fdRegId": newFdRegId
    }

    this.subscription.add(
      this.apiService.getNomineeDetails(this.hybridEncryptor.encrypted(JSON.stringify(reqData))).subscribe((res: any) => {
        this.nomineeModalList = res;
      })
    );
  }

  triggerPercentageInput(nominee: any): void {
    this.selectedNominee = nominee;
    this.showPercentageInput = true;
  }



  openPercentageModal(nominee: any): void {
    const primaryName = this.createFDForm.get('shortName')?.value;
    const primaryDobRaw = this.createFDForm.get('dob')?.value; // e.g., "20/05/1999"

    // Convert primary DOB from "dd/mm/yyyy" to "yyyy-MM-dd"
    const [pDay, pMonth, pYear] = primaryDobRaw.split('/');
    const primaryDob = `${pYear}-${pMonth}-${pDay}`;

    // Convert nominee DOB from ISO to "yyyy-MM-dd"
    const nomineeDob = new Date(nominee.dob).toISOString().split('T')[0];

    // Check if nominee matches primary applicant
    if (nominee.name === primaryName && nomineeDob === primaryDob) {
      // console.log('Nominee is same as primary applicant. Modal will not open.');
      this.notify.warning('Self-nomination is not allowed for fixed deposits.', 'Alert')
      return;
    }

    // Check if nominee already exists in guardian list
    const isDuplicate = this.guardianList.some((guardian: any) => {
      const [gDay, gMonth, gYear] = guardian.dob.split('-'); // "dd-mm-yyyy"
      const guardianDob = `${gYear}-${gMonth}-${gDay}`;

      return guardian.name === nominee.name && guardianDob === nomineeDob;
    });

    if (isDuplicate) {
      // console.log('Primary guardian can not allowed as nominee in this fixed deposit');
      this.notify.warning('The primary guardian is not eligible to be a nominee for this FD.', 'Alert')
      return;
    }

    // Open modal programmatically
    this.selectedNominee = nominee;
    this.percentageInput = 0;
    this.showPercentageInput = true;
  }

  confirmAddNominee(): void {
    const nominee = { ...this.selectedNominee, ownerPercentage: this.percentageInput };

    this.totalPercentage = this.nominees.reduce((sum, n) => sum + JSON.parse(n.ownerPercentage), 0) + this.percentageInput;

    if (this.totalPercentage > 100) {
      this.notify.warning('Total percentage cannot exceed 100%', 'Warning', 'toast-bottom-center');
      return;
    }

    if (this.nominees.length < 3) {
      this.nominees.push(nominee);

    } else {
      this.notify.warning('Maximum of 3 Nominees can be added.');
    }

    this.selectedNominee = null;
    this.percentageInput = 0;
    this.showPercentageInput = false;
  }




  isNomineeAlreadyAdded(nominee: any): boolean {
    return this.nominees.some(
      n => n.name === nominee.name && n.depositorRelationship === nominee.depositorRelationship
    );
  }

  removeFromMainList(nominee: any): void {
    this.nominees = this.nominees.filter(n =>
      !(n.name === nominee.name && n.depositorRelationship === nominee.depositorRelationship)
    );
  }




  toggleNomineeFields(nominee: number): void {
    const fields =
      nominee === 2
        ? ['nom2Name', 'nom2Dob', 'nom2Addr', 'nom2Prop', 'nom2RelWDepo', 'nom2GuardName', 'nom2GuardAddr', 'nom2RelWGuard']

        : ['nom3Name', 'nom3Dob', 'nom3Addr', 'nom3Prop', 'nom3RelWDepo', 'nom3GuardName', 'nom3GuardAddr', 'nom3RelWGuard']
    fields.forEach((field) => {
      const control = this.createFDForm.get(field);
      if (nominee === 2 && this.nom2ChkControl.value) {
        control?.enable();
      } else if (nominee === 3 && this.nom3ChkControl.value) {

        control?.enable();

      } else {
        control?.disable();
        control?.reset(); // Reset field value if disabled
      }
    });
  }







  get branchCd() {
    return this.createFDForm.get('branchCd');
  }


  get cifCd() {
    return this.createFDForm.get('cifCd');
  }

  get schemeCd() {
    return this.createFDForm.get('schemeCd');
  }

  get amount() {
    return this.createFDForm.get('amount');
  }

  get catSubTypCd() {
    return this.createFDForm.get('catSubTypCd');
  }

  get empCode() {
    return this.createFDForm.get('empCode');
  }

  get period() {
    return this.createFDForm.get('period');
  }

  get intRate() {
    return this.createFDForm.get('intRate');
  }

  get autoRenewFlag() {
    return this.createFDForm.get('autoRenewFlag');
  }


  get taxExemptFlag() {
    return this.createFDForm.get('taxExemptFlag');
  }

  get invCategory() {
    return this.createFDForm.get('invCategory');
  }

  get invCatHoldTypCd() {
    return this.createFDForm.get('invCatHoldTypCd');
  }

  get nriFlag() {
    return this.createFDForm.get('nriFlag');
  }

  get nom1Name() {
    return this.createFDForm.get('nom1Name');
  }


  get nom1Dob() {
    return this.createFDForm.get('nom1Dob');
  }

  get nom1Addr() {
    return this.createFDForm.get('nom1Addr');
  }

  get nom1Prop() {
    return this.createFDForm.get('nom1Prop');
  }


  get nom1RelWDepo() {
    return this.createFDForm.get('nom1RelWDepo');
  }

  get nom2Name() {
    return this.createFDForm.get('nom2Name');
  }

  get nom2Dob() {
    return this.createFDForm.get('nom2Dob');
  }

  get nom2Addr() {
    return this.createFDForm.get('nom2Addr');
  }

  get nom2Prop() {
    return this.createFDForm.get('nom2Prop');
  }

  get nom2RelWDepo() {
    return this.createFDForm.get('nom2RelWDepo');
  } //start
  get custBankName() {
    return this.createFDForm.get('custBankName');
  }

  get custBranch() {
    return this.createFDForm.get('custBranch');
  }

  get payeeName() {
    return this.createFDForm.get('payeeName');
  }

  get custAccType() {
    return this.createFDForm.get('custAccType');
  }

  get custAccNum() {
    return this.createFDForm.get('custAccNum');
  }

  get custIfsc() {
    return this.createFDForm.get('custIfsc');
  }

  get mopCd() {
    return this.createFDForm.get('mopCd');
  }

  get neftNum() {
    return this.createFDForm.get('neftNum');
  }

  get neftDt() {
    return this.createFDForm.get('neftDt');
  }

  get nom3Name() {
    return this.createFDForm.get('nom3Name');
  }
  get nom3Dob() {
    return this.createFDForm.get('nom3Dob');
  }

  get nom3Addr() {
    return this.createFDForm.get('nom3Addr');
  }

  get nom3Prop() {
    return this.createFDForm.get('nom3Prop');
  }

  get nom3RelWDepo() {
    return this.createFDForm.get('nom3RelWDepo');
  }

  get form() {
    return this.createFDForm.value;
  }



  numberOnly(event: any) {
    this.customValidator.OnlyNumbervalidator(event);
  }


  CharacterSpacevalidator(event: any) {
    this.customValidator.CharacterSpaceValidator(event);
  }


  characterSpaceNumberValidator(event: any) {
    this.customValidator.characterSpaceNumberValidator(event);
  }


  futureDateValidator() {
    this.customValidator.futureDateValidator();
  }


  onAutoRenewChange() {
    const autoRenewFlag = this.createFDForm.get('autoRenewFlag')?.value;
    if (autoRenewFlag === 'Y') {
      this.updateReturns();
      if (this.saveTempCreateFDData['autoRenewType']) {

        this.createFDForm.get("autoRenewType")?.setValue(this.saveTempCreateFDData['autoRenewType']);
      } else {

        this.createFDForm.get("autoRenewType")?.setValue(null);
      }
      // this.autoRenewError = "Dear customer, if you need automatic renewal, kindly visit the branch office.";
      // Reset the value to "N" to enforce selection of "No"
      // this.createFDForm.get('autoRenewFlag')?.setValue('N');
    } else {
      this.autoRenewError = null; // Clear error when "No" is selected
    }
  }





  stafselection() {
    const custCat = this.createFDForm.get('catSubTypCd')?.value;
    if (custCat === 'STAFF' || custCat === 'STAFF + SENIOR CITIZEN') {
      this.createFDForm.get('empCode')?.enable();

      setTimeout(() => {
        const element = document.querySelector('[formControlName="empCode"]') as HTMLElement;
        element?.focus();
      }, 0);

    } else {

      this.createFDForm.get('empCode')?.disable();
      this.createFDForm.get('empCode')?.setValue('');


    }
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();

    this.clearAadhaarResendTimer();
    this.clearGuardianAadhaarResendTimer();

    this.destroy$.next();
    this.destroy$.complete();


  }



  get isManageMode(): boolean {
    return !!this.FDrNo;
  }

  validatePeriod() {
    const v = this.createFDForm.get('period')?.value;
    const cif = this.createFDForm.get('cifCd')?.value;

    if (cif == '' || cif == null) {
      if ((v != 12) || (v == null) || (v == "") || (v == 0)) {
        alert("It is mandatory to have a 12-month period.");
        this.createFDForm.get('period')?.setValue('12');
      }
    } else {
      if ((v < 12) || (v > 60)) {
        alert("The period must be between 12 and 60");
        // document.getElementById("fdPeriod").focus();
        this.createFDForm.get('period')?.setValue('');
      }
    }
  }


  nriFlagDefaultValue() {
    this.createFDForm.get('nriFlag')?.setValue('N');

  }


  OnchangesNriValue() {
    const nriFlag = this.createFDForm.get('nriFlag')?.value;
    if (nriFlag === 'Y') {
      this.createFDForm.get('nriFlag')?.setValue('N');
    }
    this.createFDForm.get('nriFlag')?.setValue('N');
  }


  FloatValue(event: any) {
    this.customValidator.FloatValue(event);
    this.maturityAmount = event.target.value
  }


  ifsCodevalidator(event: any): void {
    this.customValidator.ifsCodevalidator(event); // Call the custom validator from the service
  }

  AddressValidator(event: any) {
    this.customValidator.AddressValidator(event);
  }

  branchList(): void {
    this.subscription.add(
      this.apiService.branchList().subscribe({
        next: (response: any) => {
          this.kycbranchName = response;
        }
      })
    );
  }
  getDropdownList(): void {
    this.subscription.add(
      this.apiService.getDropdownList().subscribe({
        next: (response: any) => {
          console.log('dropdownlist', response)
          this.schemeList = response.schemeList;
          this.subtypeLists = response?.subtypeList;
          this.invCatHoldTypCdList = response?.htmTypeList.filter((item: any) => item != 'SOLE DEPOSITOR');
        }
      })
    );
  }
  userFdDetailsView(): void {
    const data = {
      fdUserId: this.authService.getResponseValueByKey("fdUserId"),
      newFdRegId: this.authService.getResponseValueByKey("newFdRegId"),
      entryId: this.authService.getResponseValueByKey("entryId"),
      cif: this.authService.getResponseValueByKey("cif"),
      kycBranchName: this.authService.getResponseValueByKey(""),
    }

    this.subscription.add(
      this.apiService.userFdDetailsView(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe({
        next: (response: any) => {
          if (response) {
            console.log('userFdDetailsView', response);
            this.responseUser = response;
            this.shortNamevalue = response.shortName;
            this.createFDForm.get('longName')?.setValue(response.firDepoName)
            this.createFDForm.get('shortName')?.setValue(response.shortName);
            this.createFDForm.get('cifCd')?.setValue(response.cif);
            this.createFDForm.get('panNo')?.setValue(response.panNo);
            this.createFDForm.get('address')?.setValue(response.address);
            this.createFDForm.get('city')?.setValue(response.city);
            this.createFDForm.get('state')?.setValue(response.state);
            this.createFDForm.get('pinCode')?.setValue(response.pinCode);
            this.createFDForm.get('occupation')?.setValue(response.occupation);
            this.createFDForm.get('dob')?.setValue(response.dob);
            this.createFDForm.get('gender')?.setValue(response.gender);
            this.createFDForm.get('mobNum')?.setValue(response.mobNum);
            this.createFDForm.get('emailId')?.setValue(response.email);
            this.createFDForm.get('custCode')?.setValue(response.custCode);
            this.createFDForm.get('vkycFlag')?.setValue(response.vkycFlag);
            this.createFDForm.get('fdUserId')?.setValue(response.fdUserId);

            this.createFDForm.get('fdUserEmail')?.setValue(response.fdUserEmail);
            this.createFDForm.get('fdUserMobile')?.setValue(response.fdUserMobile);
            this.createFDForm.get('newFdRegId')?.setValue(response.newFdRegId);
            this.createFDForm.get('empStatus')?.setValue(response.empStatus);
            if (this.createFDForm.get('dob')?.value == null || this.createFDForm.get('dob')?.value == '') {
              this.dobIsMissing = true;
            }

            this.cdChanges.detectChanges();
            this.getNomineeDetails();
            this.makeDefaultValues(response);
            this.OnChangeofDepositorIs();
            this.updateJourneyStep();
            this.loadExistingForm();

          }
        }
      })
    );
  }

  /*   payeeNameCheck() {
      const shortName = this.createFDForm.get('shortName')?.value;
      const payeeName = this.createFDForm.get('payeeName')?.value;
      if (shortName && payeeName) {
        if (payeeName !== shortName) {
          alert("Depositor name & Payee name are different! Are you sure want to continue!");
          setTimeout(() => {
            const element = document.querySelector('[formControlName="payeeName"]') as HTMLElement;
            element?.focus();
          }, 0);
        }
      }
    } */




  private loadExistingForm(): void {
    const fduserRegId = this.createFDForm.get('newFdRegId')?.value
    if (!fduserRegId ) {
      this.isForm121Submitted = false
      return;
    }

    this.apiService.getForm121ByUser(fduserRegId).subscribe({
      next: (response) => {
        console.log('121',  response);
        if(response.length >= 1){
          const status = response[0].status
          this.isForm121Submitted = status == 'SUBMITTED' ? true : false;
        } else {
           this.isForm121Submitted = false;
        }
      },
      error: (error) => {
        this.isForm121Submitted = false;
        if (error?.status !== 404) {
          console.error(error)
        }
      },
    });
  }

  onChangeofinvCatHoldTypCd(eve: Event) {
    if (this.createFDForm.get('invCatHoldTypCd')?.value == 'SOLE DEPOSITOR') {
      this.createFDForm.get('jointHolName')?.setValue('')
    }

  }

  makeDefaultValues(res: any) {
    setTimeout(() => {

      const empStatus = res?.empStatus === 'Y';
      const dobStrRaw = (res?.dob ?? '');
      const dobStr =
        typeof dobStrRaw === 'string'
          ? dobStrRaw.trim()
          : String(dobStrRaw).trim();

      const isDobMissing = !dobStr || dobStr.toLowerCase() === 'null';

      // --- Missing DOB cases ---
      if (isDobMissing) {
        if (empStatus) {
          // Case 1: empStatus = 'Y' and no DOB -> STAFF
          this.filteredSubtypeLists = this.subtypeLists.filter(
            (item: any) => item === 'STAFF'
          );
          this.createFDForm.get('catSubTypCd')?.setValue('STAFF', {
            emitEvent: false,
          });
        } else {
          // Case 2: empStatus != 'Y' and no DOB -> GENERAL
          this.filteredSubtypeLists = this.subtypeLists.filter(
            (item: any) => item === 'GENERAL'
          );
          this.createFDForm.get('catSubTypCd')?.setValue('GENERAL', {
            emitEvent: false,
          });
        }

        this.createFDForm.get('depositorIs')?.setValue('Major', {
          emitEvent: false,
        });

        this.updateReturns();
        return;
      }

      // Supports both dd/MM/yyyy and dd-MM-yyyy
      const [day, month, year] = dobStr.split(/[-/]/);
      const dob = new Date(Number(year), Number(month) - 1, Number(day));
      const today = new Date();

      let age = today.getFullYear() - dob.getFullYear();
      const hasBirthdayPassed =
        today.getMonth() > dob.getMonth() ||
        (today.getMonth() === dob.getMonth() &&
          today.getDate() >= dob.getDate());

      if (!hasBirthdayPassed) {
        age--;
      }

      const isSenior = age >= 60;

      if (empStatus) {
        // STAFF or STAFF + SENIOR CITIZEN
        this.filteredSubtypeLists = this.subtypeLists.filter((item: any) =>
          isSenior
            ? item === 'STAFF + SENIOR CITIZEN'
            : item === 'STAFF'
        );

        this.createFDForm.get('catSubTypCd')?.setValue(
          isSenior ? 'STAFF + SENIOR CITIZEN' : 'STAFF',
          { emitEvent: false }
        );
      } else {
        // GENERAL or SENIOR CITIZEN
        this.filteredSubtypeLists = this.subtypeLists.filter((item: any) =>
          isSenior
            ? item === 'SENIOR CITIZEN'
            : item === 'GENERAL'
        );

        this.createFDForm.get('catSubTypCd')?.setValue(
          isSenior ? 'SENIOR CITIZEN' : 'GENERAL',
          { emitEvent: false }
        );
      }

      this.updateReturns();
    }, 1000);
  }



  selInvCatFunc() {
    var x = this.createFDForm.get('invCategory')?.value;
    if (x == 'Joint') {
      this.notify.warning(
        'Must provide more than one nominee. Also, for the 2nd depositor, please submit KYC documents to the BO.',
        'Nominee & KYC Warning', 'toast-top-right'
      );

    }
  }

  validateAmountNew() {
    const amount = this.createFDForm.get('amount')?.value;
    const panNo = this.createFDForm.get('panNo')?.value;
    const vkycFlag = this.createFDForm.get('vkycFlag')?.value;
    const ckycFlag = this.createFDForm.get('ckycFlag')?.value;

    this.FdmaxAmt = '';

    // -------------------- BASIC VALIDATION --------------------
    if (!amount || amount % 1000 !== 0 || amount < 10000) {
      if (!amount) {
        this.notify.warning('FD amount is required.', 'Info');
      } else if (amount % 1000 !== 0) {
        this.notify.warning('FD amount must be multiple of 1000', 'Info');
      } else {
        this.notify.warning('FD amount can\'t be less than ₹10,000', 'Info');
      }
      this.createFDForm.get('amount')?.setValue(0);
      return;
    }

    const fdUserIDData = this.authService.getResponseValueByKey('fdUserId');
    if (!fdUserIDData) {
      this.notify.error('Apologies for the inconvenience. Please contact our Support Team at fd@sidbi.in for assistance.');
      setTimeout(() => this.router.navigate(['/login']), 1000);
      return;
    }

    const data = { fdUserPan: panNo };

    this.subscription.add(
      this.apiService
        .getpanEKYCMode(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            const statusMsg = response?.statusMsg;
            const statusCode = response?.statusCode;

            const isBiometricVerified = statusMsg === 'BIOMETRIC';

            /**
             * ✅ FINAL VERIFICATION FLAG
             * VKYC completed OR CKYC = Y OR Biometric
             */
            const isFullyVerified =
              isBiometricVerified || vkycFlag === '1' || ckycFlag === 'Y';

            // ✅ If fully verified => NO LIMIT
            if (isFullyVerified) {
              return;
            }

            // -------------------- VKYC IN PROGRESS --------------------
            if (vkycFlag === '0') {
              const totalAmountExist = parseInt(statusMsg, 10);
              const remainingLimit = 100000 - totalAmountExist;

              if (totalAmountExist < 100000 && amount > remainingLimit) {
                this.confirmAction(
                  `
                <p class="vkyc-dialog-message">
                  Your VKYC process is currently <strong>incomplete</strong>.<br>
                  Please complete VKYC to continue investing above ₹1,00,000.
                </p>
                `,
                  () => {
                    this.doVkycProcess();
                    this.createFDForm.get('amount')?.setValue(0);
                  },
                  () => {
                    if (remainingLimit > 0) {
                      this.createFDForm.get('amount')?.setValue(remainingLimit);
                      this.FdmaxAmt = `FD creation available limit is ₹${remainingLimit} only.`;
                    } else {
                      this.notify.warning('FD creation limit exceeded.', 'Info');
                      this.updateReturns();
                    }
                  },
                  'VKYC Incomplete'
                );

                this.updateReturns();
              }
              return;
            }

            // -------------------- VKYC NOT DONE (NULL) --------------------
            if (vkycFlag == null && (ckycFlag == 'N' || ckycFlag == null)) {
              const totalAmountExist = parseInt(statusMsg, 10);
              const remainingLimit = 100000 - totalAmountExist;

              if (amount > remainingLimit) {
                this.confirmAction(
                  'VKYC is required to proceed with FD creation above ₹1,00,000. Do you want to complete VKYC now?',
                  () => {
                    this.doVkycProcess();
                    this.createFDForm.get('amount')?.setValue(0);
                  },
                  () => {
                    if (remainingLimit > 0) {
                      this.createFDForm.get('amount')?.setValue(remainingLimit);
                      this.FdmaxAmt = `FD creation available limit is ₹${remainingLimit} only.`;
                    } else {
                      this.notify.warning('FD creation limit exceeded.', 'Info');
                    }
                  },
                  'VKYC Required'
                );
              }
            }
          },
          error: (error) => {
            console.error('API error:', error);
            this.notify.error('Apologies for the inconvenience. Please contact our Support Team at fd@sidbi.in for assistance.');
            this.createFDForm.get('amount')?.setValue(null);
          }
        })
    );
  }





  doVkycProcess() {


    // let data = {
    //   name: 'Karthik ',
    //   namePrintedInPan: 'Karthik ARIYANNAN',
    //   dob: '20-05-1999',
    //   pan: 'CJSPA3510J',
    //   panValidation: 'false',
    //   email: 'info_karthika@sidbi.in',
    //   mobile: '9976652374',
    // };

    const vkycPan = this.createFDForm.get('panNo')?.value;
    const vkycDob = this.createFDForm.get('dob')?.value;

    const isEmpty = (v: any) =>
      v == null || (typeof v === 'string' && v.trim() === '');

    if (isEmpty(vkycPan) || isEmpty(vkycDob)) {
      this.notify.warning('Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.', 'Info');
      return;
    }
    if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
      this.notify.warning('Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.', 'Info');
      return;
    }
    if (isEmpty(vkycPan)) {
      this.notify.warning('Unable to proceed with VKYC as your PAN is not updated in our records.', 'Info');
      return;
    }
    if (isEmpty(vkycDob)) {
      this.notify.warning('Unable to proceed with VKYC as your Date of Birth is not updated in our records.', 'Info');
      return;
    }

    let data = {
      name: this.createFDForm.get('shortName')?.value,
      namePrintedInPan: this.createFDForm.get('shortName')?.value,
      dob: this.createFDForm.get('dob')?.value?.replace(/\//g, '-'),
      pan: this.createFDForm.get('panNo')?.value,
      panValidation: 'false',
      email: this.createFDForm.get('fdUserId')?.value,
      mobile: this.createFDForm.get('mobNum')?.value,
    };
    this.subscription.add(
      this.apiService
        .doVkycProcessService(
          this.hybridEncryptor.encrypted(JSON.stringify(data))
        )
        .subscribe({
          next: (response: any) => {
            if (response.statusCode == 1002) {
              // Access the vkycURL
              const formated = JSON.parse(response.message);
              const vkycURL = formated.vkycURL;
              // Desired dimensions
              const width = 500;
              const height = 500;
              // Calculate center position
              const left = Math.floor((window.screen.width - width) / 2);
              const top = Math.floor((window.screen.height - height) / 2);
              // Open centered window
              const features = `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`;
              window.open(vkycURL, '_blank');
            } else {

            }
          },
          error: (err) => {
            console.log('An error occurred something went wrong ' + err);
          },
        })
    );

  }

  propAmtCheck() {
    var prop1Amt = Number(this.createFDForm.get('nom1Prop')?.value);
    var prop2Amt = Number(this.createFDForm.get('nom2Prop')?.value);
    var prop3Amt = Number(this.createFDForm.get('nom3Prop')?.value);
    var percentage = prop1Amt + prop2Amt + prop3Amt;
    if (prop1Amt == 0) {
      this.notify.warning('Please provide a proportionate percentage.', 'Info')

    }
    else if (percentage > 100.00) {
      this.notify.warning('The proportional percentage is more than 100. Please check and enter a valid amount.', 'Info')

      this.createFDForm.get('nom1Prop')?.setValue('');
      this.createFDForm.get('nom2Prop')?.setValue('');
      this.createFDForm.get('nom3Prop')?.setValue('');

    }
    else if (percentage != 100.00) {
      this.notify.warning('The proportionate percentage is not equal to 100 %', 'Info')

    }
  }

  calcInt(): void {
    var Scheme = this.createFDForm.get('schemeCd')?.value;
    var Amount = this.createFDForm.get('amount')?.value;
    var custCat = this.createFDForm.get('catSubTypCd')?.value;
    if (Scheme == "" || Scheme == null) {

      this.notify.info('It is necessary to choose a schema.', 'Info')
      setTimeout(() => {
        const element = document.querySelector('[formControlName="schemeCd"]') as HTMLElement;
        element?.focus();
      }, 0);
    } else if (Amount == '' || Amount == null) {
      // this.notify.info('FD amount is required')
      setTimeout(() => {
        const element = document.querySelector('[formControlName="amount"]') as HTMLElement;
        element?.focus();
      }, 0);
    } else if (custCat == "" || custCat == null) {
      this.notify.info('It is necessary to select a category')
      setTimeout(() => {
        const element = document.querySelector('[formControlName="catSubTypCd"]') as HTMLElement;
        element?.focus();
      }, 0);
    } else {
      const schemeCd = this.createFDForm.get('schemeCd')?.value;
      const amount = this.createFDForm.get('amount')?.value;
      const catSubTypCd = this.createFDForm.get('catSubTypCd')?.value;
      const fdPeriod = this.createFDForm.get('period')?.value;
      const data = {
        fdScheme: schemeCd,
        fdAmount: amount,
        custCat: catSubTypCd,
        fdPeriod: fdPeriod
      }
      this.subscription.add(
        this.apiService.intCalc(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe({
          next: (response: any) => {
            const formattedResponse = response.replace(/['"]+/g, '');
            this.createFDForm.get('intRate')?.setValue(formattedResponse);
          }
        })
      );
    }
  }

  calcIntOne(): void {
    const schemeCd = '0';
    const amount = this.createFDForm.get('amount')?.value;
    const catSubTypCd = this.createFDForm.get('catSubTypCd')?.value;
    const fdPeriod = this.createFDForm.get('period')?.value;
    if (catSubTypCd == 'SENIOR CITIZEN' || catSubTypCd == 'STAFF + SENIOR CITIZEN') {
      this.citizenType = 'senior';
    } else if (catSubTypCd == 'STAFF') {
      this.citizenType = 'staff';
    }

    this.updateReturns();
    const data = {
      fdScheme: schemeCd,
      fdAmount: amount,
      custCat: catSubTypCd,
      fdPeriod: fdPeriod
    }
    this.subscription.add(
      this.apiService.intCalc(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe({
        next: (response: any) => {
          const formattedResponse = response.replace(/['"]+/g, '');
          this.createFDForm.get('intRate')?.setValue(formattedResponse);
        }
      })
    );
  }




  getfdrNumber() {
    this.subscription.add(
      this.apiService.getfdrNumber().subscribe({
        next: (response: any) => {
          if (response) {
            if (this.draftFDrNo) {
              this.FDrNo = this.draftFDrNo;
            } else {
              this.FDrNo = response;
            }

          }
        },
        error: (err) => {
          console.log("pennydropCheckAccountNumber error", err);
          // alert("An error occurred in Account Number Verification. Please try again.");
        }
      })
    );
  }

  submitCreateFDForm(action: String) {
    this.spinner.show();
    this.createFDForm.get('amount')?.enable();
    if (this.createFDForm.valid) {
      if (this.hasClickedTerms) {
        if (this.createFDForm.get('amount')?.value < 10000) {
          this.notify.warning('Please update the valid Amount', 'Alert');
          this.createFDForm.get('amount')?.reset();
          this.createFDForm.get('amount')?.markAllAsTouched();
          this.spinner.hide();
          return
        }
        if (this.nominees.length > 0 && this.totalPercentage != 100) {
          this.notify.warning('Ensure nominee is added with 100% share prior to submitting the Fixed Deposit.', 'Alert');
          this.spinner.hide();
          return
        }

        if (this.createFDForm.get('depositorType')?.value == 'JOINT' && this.mainFDTable.length == 0) {
          this.notify.warning('Please update the Joint Holder Details', 'Warning');
          this.spinner.hide();
          return;
        }

        if (this.bankDetails.custAccNum == null || this.bankDetails.custAccNum === '') {
          this.notify.warning('Please update your bank information in Personal Details Section to create FD', 'Alert');
          this.spinner.hide();
          return;
        }


        const custCat = this.createFDForm.get('catSubTypCd')?.value;
        if (this.createFDForm.get('mopCd')?.value == 'PG' && !this.paymentGateewayDone) {
          this.notify.warning('Please Complete the Payment', 'Alert');
          this.spinner.hide();
          return
        }

        /* if ((custCat === 'STAFF' || custCat === 'STAFF + SENIOR CITIZEN') && !this.isEmpValidated) {
          this.notify.warning('Please Verify your Employee Code', 'Alert');
          return
        } */

        if (this.isSubmitting) return;  // Prevent double-click
        this.isSubmitting = true;
        this.strButton = action;
        this.createFDForm.value['strButton'] = action;
        this.createFDForm.value['wudUserId'] = this.authService.getResponseValueByKey("fdUserId");
        this.createFDForm.value['entryId'] = this.FDrNo;
        const filteredNominees = this.nominees.map(nominee => ({
          userId: nominee.userId,
          ownerPercentage: nominee.ownerPercentage,
          fdRegId: nominee.fdRegId
        }));

        if (this.createFDForm.get('mopCd')?.value == 'PG') {
          if (this.saveTempCreateFDData?.entryId) {

            this.FDrNo = this.saveTempCreateFDData?.entryId
          }

        }



        const simplifiedHoldDetails = this.mainFDTable.map(item => ({
          pan: item.pan,
          holdId: item.holdId,
          newRegId: item.newRegId,
          fdId: this.FDrNo,
        }));



        const guardianDetails = this.guardianList.map((item: any) => ({
          pan: item.pan,
          holdId: item.holdId,
          newRegId: item.newRegId,
          fdId: this.FDrNo,
          isGuardian: true
        }));



        let formData = {
          amount: this.createFDForm.get('amount')?.value,
          period: this.createFDForm.get('period')?.value,
          schemeCd: this.createFDForm.get('schemeCd')?.value,
          catSubTypCd: this.createFDForm.get('catSubTypCd')?.value,
          taxExemptFlag: this.createFDForm.get('taxExemptFlag')?.value,
          empCode: this.createFDForm.get('empCode')?.value,
          mopCd: this.createFDForm.get('mopCd')?.value,
          neftNum: this.createFDForm.get('neftNum')?.value,
          neftDt: this.createFDForm.get('neftDt')?.value,
          wudUserId: this.authService.getResponseValueByKey("fdUserId"),
          entryId: this.FDrNo,
          branchCd: this.createFDForm.get('branchCd')?.value,
          cifCd: this.createFDForm.get('cifCd')?.value,
          intRate: this.createFDForm.get('intRate')?.value,
          agentCode: this.isAgentVerified ? this.createFDForm.get('agentCode')?.value : "0",
          nomiees: filteredNominees,
          autoRenewFlag: this.createFDForm.get('autoRenewFlag')?.value == 'Y' ? this.createFDForm.get('autoRenewType')?.value : 'N',
          invCatHoldTypCd: this.createFDForm.get('invCatHoldTypCd')?.value,
          // holdDetails: simplifiedHoldDetails,
          // holdDetails: [...simplifiedHoldDetails, ...guardianDetails],

          holdDetails: guardianDetails.length > 0
            ? [...simplifiedHoldDetails, ...guardianDetails]
            : simplifiedHoldDetails,


          saveFlag: '02',
          ...{
            custAccType: this.bankDetails.custAccType?.toLowerCase() || null,
            custBankName: this.bankDetails.custBankName || null,
            custBranch: this.bankDetails.custBranch || null,
            payeeName: this.bankDetails.payeeName || null,
            custAccNum: this.bankDetails.custAccNum || null,
            custIfsc: this.bankDetails.custIfsc || null,
          }

        }
        // this.router.navigate(['dashboard/fdApplication']);
        this.subscription.add(

          this.apiService.saveFdCreationDetails(this.hybridEncryptor.encrypted(JSON.stringify(formData))).subscribe({
            next: (response: any) => {
              if (response.statusCode == '1002') {
                this.notify.success(response.statusMsg);
                // location.reload();
                this.spinner.hide();
                this.CookieService.delete('paymentDetailsW');
                this.CookieService.delete('paymentReqId');
                this.CookieService.delete('mainNominees');
                this.CookieService.delete('mainJointHolders');
                this.router.navigate(['dashboard/fdApplication']);
              } else if (response.statusCode == '1008') {
                this.spinner.hide();
                this.notify.error("FD application has not been submitted. Kindly check or visit the branch.", "Error")
                this.router.navigate(['/dashboard/createFD'])
              }
              this.isSubmitting = false;  // Re-enable button after response
            }, error: (err) => {
              this.spinner.hide();
              this.isSubmitting = false;  // Also re-enable button on error
              console.error("Submission error", err);
              this.notify.error("An error occurred. Please try again.");
            }



          })
        );
      } else {
        this.spinner.hide();
        this.notify.info('Please check the Terms and Condions link and Proceed')
      }


    } else {
      for (const field in this.createFDForm.controls) {
        const control = this.createFDForm.get(field);
        if (control && control.invalid) {
          console.log(`Field '${field}' is invalid`);
          console.log(control.errors); // Shows specific validation errors
        }
      }

    }


  }




  pennydropCheckAccountNumber() {
    const data = {
      username: '289af78e-b02b-4952-b32d-710751e73826',
      password: '078841d1-9401-4724-a353-5403396f1522'
    };

    this.subscription.add(
      this.apiService.pennydropCheckAccountNumber(data).subscribe({
        next: (response: any) => {
          if (response.statusCode === '1000' && response.payload?.statusCode === '2000') {
            const token = response.payload.token;

            const requestData = {
              reqId: this.FDrNo,
              remitterAcc: this.CookieService.get("remitterAcc"),
              beneAccNum: this.custAccNum?.value,
              beneIFSC: this.custIfsc?.value
            };

            this.apiService.pennyDropRequest(requestData, `Bearer ${token}`).subscribe({
              next: (res: any) => {

                const statusCode = res.statusCode || res["statusCode:"];
                const payload = res.payload || res["payload "] || {};
                const dataBlock = payload.data;
                if (statusCode === "1000" && dataBlock) {
                  const requestId = dataBlock
                  alert("Please wait while we verify your account.")
                  this.spinner.show();
                  setTimeout(() => {
                    this.spinner.hide();
                    this.apiService.pennydropCheckAccountNumber(data).subscribe({
                      next: (tokenResp: any) => {
                        if (tokenResp.statusCode === '1000' && tokenResp.payload?.statusCode === '2000') {
                          const statusToken = tokenResp.payload.token;
                          const statusRequest = { reqId: requestId };
                          this.apiService.getPennyDropStatus(statusRequest, statusToken).subscribe({
                            next: (statusResponse: any) => {
                              if (statusResponse.statusCode === '1000' && statusResponse.payload) {
                                const payload = statusResponse.payload;
                                const status = payload.statusCode;
                                const message = payload.message;
                                let data = payload.data;
                                //  const payeeName = this.createFDForm.get('payeeName')?.value;
                                //  data = "JAGANATHAN S";
                                if (status === '02') {
                                  //  if (payeeName.toUpperCase() === data.toUpperCase()) {
                                  if (data.toUpperCase() === data.toUpperCase()) {
                                    this.verfyButtonbooleanVal = true;
                                    alert(`Beneficiary account details have been successfully verified.`);
                                    this.isSelectDisabled = true;
                                  } else {
                                    alert(`Beneficiary account name is mismatched. Please try again.`);
                                  }

                                } else if (status === '03') {
                                  alert(` Failure\nReason: ${data}`);
                                } else if (status === '05') {
                                  alert(`Take a few more seconds to verify; try again`);
                                } else {
                                  alert(` Unexpected response\nStatus Code: ${statusResponse.statusCode}\nMessage: ${statusResponse.statusMsg}`);
                                }
                              }

                            },
                            error: (err) => {
                              console.error(" Error in getPennyDropStatus", err);
                              alert("Failed to retrieve penny drop status.");
                            }
                          });
                        } else {
                          alert(" Token generation failed for status check.");
                        }
                      },
                      error: (err) => {
                        console.error(" Error generating token for status check", err);
                        alert("Token generation error before status check.");
                      }
                    });
                  }, 40000)
                } else {
                  alert(" failed or response malformed.");
                }
              },
              error: (err) => {
                console.error(" Error in pennyDropRequest", err);
                alert("Error during Account verification or verification data is empty");
              }
            });

          } else if (response.statusCode === '1008') {
            alert(" Invalid credentials.");
          } else {
            alert(" Unexpected token generation status: " + response.statusCode);
          }
        },
        error: (err) => {
          console.error(" Error in pennydropCheckAccountNumber", err);
          alert("Error during account verification.");
        }
      })
    );
  }



  onPaymentModeChange(event: Event): void {
    this.showDropdown = false;

    if (this.createFDForm.get('amount')?.invalid || this.createFDForm.get('tenureType')?.invalid || this.createFDForm.get('schemeCd')?.invalid
      || this.createFDForm.get('branchCd')?.invalid) {
      this.notify.warning('Please fill the all mandatory fields', 'Warning');
      this.createFDForm.get('amount')?.markAsTouched();
      this.createFDForm.get('tenureType')?.markAsTouched();
      this.createFDForm.get('schemeCd')?.markAsTouched();
      this.createFDForm.get('branchCd')?.markAsTouched();
      this.createFDForm.get('taxExemptFlag')?.markAsTouched();
      return;
    }

    if (this.createFDForm.get('amount')?.value < 10000) {
      this.notify.warning('Please update the valid Amount', 'Alert');
      this.createFDForm.get('amount')?.reset();
      this.createFDForm.get('amount')?.markAllAsTouched();
      return
    }

    // check the bank details for payment gateway

    if (this.bankDetails.custAccNum == null || this.bankDetails.custAccNum === '') {
      this.notify.warning('Please update your bank details to create FD', 'Alert');
      return;
    }

    const allowedInvalid = new Set(['neftNum', 'neftDt']);

    const otherInvalidFields = Object.keys(this.createFDForm.controls).filter(field => {
      const control = this.createFDForm.get(field);
      return control && control.invalid && !allowedInvalid.has(field);
    });

    this.spinner.show();
    const selectedValue = (event.target as HTMLSelectElement).value;
    if (this.createFDForm.get('mopCd')?.value === 'PG' && otherInvalidFields.length == 0) {
      const schemeCd = this.createFDForm.get('schemeCd')?.value;
      const shortName = this.createFDForm.get('shortName')?.value;
      const amount = this.createFDForm.get('amount')?.value;
      const mobNum = this.createFDForm.get('mobNum')?.value;
      const emailId = this.createFDForm.get('emailId')?.value;
      const newFdRegId = this.authService.getResponseValueByKey("newFdRegId");
      const bankAcctNo = this.createFDForm.get('custAccNum')?.value;
      const custIfsc = this.createFDForm.get('custIfsc')?.value;
      const data = {
        amount: amount,
        name: shortName,
        contact: mobNum,
        email: emailId,
        fdEntryId: this.FDrNo,
        fdRegId: newFdRegId,
        custBankAcctNo: bankAcctNo,
        custIfscCode: custIfsc,

      }

      this.saveTempCreateFDData = {
        entryId: this.FDrNo,
        cifCd: this.createFDForm.get('cifCd')?.value,
        branchCd: this.createFDForm.get('branchCd')?.value,
        schemeCd: schemeCd,
        period: this.createFDForm.get('period')?.value,
        catSubTypCd: this.createFDForm.get('catSubTypCd')?.value,
        intRate: this.createFDForm.get('intRate')?.value,
        amount: amount,
        empCode: this.createFDForm.get('empCode')?.value,
        taxExemptFlag: this.createFDForm.get('taxExemptFlag')?.value,
        mopCd: this.createFDForm.get('mopCd')?.value,
        neftNum: this.createFDForm.get('neftNum')?.value,
        neftDt: this.createFDForm.get('neftDt')?.value,
        saveFlag: '01',
        wudUserId: this.authService.getResponseValueByKey("fdUserId"),
        autoRenewFlag: this.createFDForm.get("autoRenewFlag")?.value,
        autoRenewType: this.createFDForm.get('autoRenewType')?.value,
        empCodeValidated: this.isEmpValidated,
        agentCode: this.isAgentVerified ? this.createFDForm.get('agentCode')?.value : "0",
        isAgentVerified: this.isAgentVerified,
        invCatHoldTypCd: this.createFDForm.get('invCatHoldTypCd')?.value,
        nomiees: this.convertArrayToObject(),
        holdDetails: this.convertHoldArrayToObject(),
        depositorType: this.createFDForm.get('depositorType')?.value,

      }

      let encrypt = this.hybridEncryptor.encrypted(JSON.stringify(this.saveTempCreateFDData));
      let convertNomineeAsObject = this.convertArrayToObject();
      let nomineeEncrypted: any = this.hybridEncryptor.encrypted(JSON.stringify(convertNomineeAsObject));

      let convertedJointHolderAsObject = this.convertHoldArrayToObject();
      let jointHolderEncrypted: any = this.hybridEncryptor.encrypted(JSON.stringify(convertedJointHolderAsObject))

      // window.open('http://localhost:4200/dashboard/createFD', '_self');

      this.subscription.add(
        this.apiService.PaymentGatwaylinkGeneration(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe({
          next: (response: any) => {
            if (response.status == 'created') {
              this.submitDraftCreateFDForm();
              this.CookieService.delete('paymentDetailsW');
              this.CookieService.delete('paymentReqId');
              this.CookieService.delete('mainNominees');
              this.CookieService.delete('mainJointHolders');
              this.notify.info("Please wait while you redirect to the payment page");
              this.CookieService.set('paymentDetailsW', JSON.stringify(encrypt));
              this.CookieService.set('paymentReqId', response.reqId);
              this.CookieService.set('mainNominees', JSON.stringify(nomineeEncrypted));
              this.CookieService.set('mainJointHolders', JSON.stringify(jointHolderEncrypted));
              this.spinner.hide();
              window.open(response.paymentLink, '_self');

              // reload after 1 second (adjust if needed) 
            } else if (response.status == 'failed') {
              this.spinner.hide();
              this.CookieService.delete('paymentDetailsW');
              this.CookieService.delete('paymentReqId');
              this.CookieService.delete('mainNominees');
              this.CookieService.delete('mainJointHolders');

              this.notify.warning("FD application has not been submitted. Kindly check or visit the branch.1");
            } else if (response.status == 'failure' && response?.errorStatus == "amount exceeds maximum amount allowed.") {
              this.spinner.hide();
              const msgContent: any = "Investment Amount Exceeds the allowed Limit via Payment Gateway";
              this.notify.warning(msgContent);

            } else {
              this.spinner.hide();
              this.notify.warning("Apologies for the inconvenience. Please contact our Support Team at fd@sidbi.in for assistance.");
            }
            this.isSubmitting = false;  // Re-enable button after response
          }, error: (err) => {
            this.spinner.hide();
            this.isSubmitting = false;  // Also re-enable button on error
            console.error("Submission error", err);
            this.notify.error("An error occurred. Please try again.");
          }
        })
      );


    } else if (this.createFDForm.get('mopCd')?.value === 'PG' && otherInvalidFields.length > 0) {
      this.spinner.hide();
      for (const field in this.createFDForm.controls) {
        const control = this.createFDForm.get(field);
        if (control && control.invalid) {
          console.log(`Field '${otherInvalidFields}' is invalid`);
          console.log(control.errors); // Shows specific validation errors
          control.markAsTouched();
        }
      }
    } else {
      this.spinner.hide();
    }
  }


  submitDraftCreateFDForm() {


    const allowedInvalid = new Set(['neftNum', 'neftDt']);

    const otherInvalidFields = Object.keys(this.createFDForm.controls).filter(field => {
      const control = this.createFDForm.get(field);
      return control && control.invalid && !allowedInvalid.has(field);
    });

    if (otherInvalidFields.length === 0) {

      if (this.createFDForm.get('amount')?.value < 10000) {
        this.notify.warning('Please update the valid Amount', 'Alert');
        this.createFDForm.get('amount')?.reset();
        this.createFDForm.get('amount')?.markAllAsTouched();
        return
      }
      if (this.nominees.length > 0 && this.totalPercentage != 100) {
        this.notify.warning('Ensure nominee is added with 100% share prior to submitting the Fixed Deposit.', 'Alert');
        return
      }

      if (this.createFDForm.get('depositorType')?.value == 'JOINT' && this.mainFDTable.length == 0) {
        this.notify.warning('Please update the Joint Holder Details', 'Warning');
        return;
      }

      if (this.bankDetails.custAccNum == null || this.bankDetails.custAccNum === '') {
        this.notify.warning('Please update your bank information in Personal Details Section to create FD', 'Alert');
        return;
      }


      /* const custCat = this.createFDForm.get('catSubTypCd')?.value;
      if (this.createFDForm.get('mopCd')?.value == 'PG' && !this.paymentGateewayDone) {
        this.notify.warning('Please Complete the Payment', 'Alert');
        return
      }    */


      this.createFDForm.value['wudUserId'] = this.authService.getResponseValueByKey("fdUserId");
      this.createFDForm.value['entryId'] = this.FDrNo;
      const filteredNominees = this.nominees.map(nominee => ({
        userId: nominee.userId,
        ownerPercentage: nominee.ownerPercentage,
        fdRegId: nominee.fdRegId
      }));


      const simplifiedHoldDetails = this.mainFDTable.map(item => ({
        pan: item.pan,
        holdId: item.holdId,
        newRegId: item.newRegId,
        fdId: this.FDrNo,
      }));



      const guardianDetails = this.guardianList.map((item: any) => ({
        pan: item.pan,
        holdId: item.holdId,
        newRegId: item.newRegId,
        fdId: this.FDrNo,
        isGuardian: true
      }));



      let formData = {
        amount: this.createFDForm.get('amount')?.value,
        period: this.createFDForm.get('period')?.value,
        schemeCd: this.createFDForm.get('schemeCd')?.value,
        catSubTypCd: this.createFDForm.get('catSubTypCd')?.value,
        taxExemptFlag: this.createFDForm.get('taxExemptFlag')?.value,
        empCode: this.createFDForm.get('empCode')?.value,
        mopCd: this.createFDForm.get('mopCd')?.value,
        neftNum: this.createFDForm.get('neftNum')?.value,
        neftDt: this.createFDForm.get('neftDt')?.value,
        wudUserId: this.authService.getResponseValueByKey("fdUserId"),
        entryId: this.FDrNo,
        branchCd: this.createFDForm.get('branchCd')?.value,
        cifCd: this.createFDForm.get('cifCd')?.value,
        intRate: this.createFDForm.get('intRate')?.value,

        autoRenewFlag: this.createFDForm.get('autoRenewFlag')?.value == 'Y' ? this.createFDForm.get('autoRenewType')?.value : 'N',
        invCatHoldTypCd: this.createFDForm.get('invCatHoldTypCd')?.value,
        agentCode: this.isAgentVerified ? this.createFDForm.get('agentCode')?.value : "0",

        nomiees: filteredNominees,
        holdDetails: guardianDetails.length > 0
          ? [...simplifiedHoldDetails, ...guardianDetails]
          : simplifiedHoldDetails,


        saveFlag: '01',
        ...{
          custAccType: this.bankDetails.custAccType?.toLowerCase() || null,
          custBankName: this.bankDetails.custBankName || null,
          custBranch: this.bankDetails.custBranch || null,
          payeeName: this.bankDetails.payeeName || null,
          custAccNum: this.bankDetails.custAccNum || null,
          custIfsc: this.bankDetails.custIfsc || null,
        }

      }

      console.log('Draft api first level', formData?.entryId);
      this.subscription.add(

        this.apiService.saveFdCreationDetails(this.hybridEncryptor.encrypted(JSON.stringify(formData))).subscribe({
          next: (response: any) => {
            console.log('draftAPI Response', response)
            if (response.statusCode == '1002') {
              // this.notify.success(response.statusMsg);
              this.notify.success('Saved Data in Draft', 'Success')
            } else if (response.statusCode == '1008') {
              this.notify.error("Unable to Save the Data in Draft", "Error")
            }
          }, error: (err) => {
            console.error("Submission error", err);
            this.notify.error("An error occurred. Please try again.");
          }



        })
      );


    } else {
      /*  for (const field in this.createFDForm.controls) {
         const control = this.createFDForm.get(field);
         if (control && control.invalid) {
           console.log(`Field '${otherInvalidFields}' is invalid`);
           console.log(control.errors); // Shows specific validation errors
           control.markAsTouched();
         }
       } */

    }


  }



  convertArrayToObject(): any {
    const obj: any = {};
    this.nominees.forEach((nominee, index) => {
      obj[`nominee${index + 1}`] = nominee;
    });
    return obj;
  }


  convertHoldArrayToObject() {
    const obj: any = {};
    this.mainFDTable.forEach((nominee, index) => {
      obj[`holder${index + 1}`] = nominee;
    });
    return obj;
  }


  cleanInput(event: any): void {
    const input = event.target as HTMLInputElement;
    const sanitized = input.value.replace(/[^a-zA-Z0-9 _.\-]/g, '');
    this.createFDForm.get('neftNum')?.setValue(sanitized, { emitEvent: false });
  }


  preventSpecialChars(event: KeyboardEvent): void {
    this.customValidator.preventSpecialChars(event);
  }

  allowEmptyFields(): boolean {
    return true;
  }


  /* updateReturns(): void {
    const actualTenure = this.tenureOption === 'custom' ? this.tenure : Number(this.tenureOption);
    const baseRate = this.citizenType === 'senior' ? 8.0 : 7.5;

    let rateAdjustment = 0;
    if (this.interestPayout === 'monthly') rateAdjustment = -0.25;
    else if (this.interestPayout === 'quarterly') rateAdjustment = -0.10;

    this.interestRate = baseRate + rateAdjustment;

    if (actualTenure > 0 && this.depositAmount > 0) {
      const years = actualTenure / 12;
      this.interestEarned = this.depositAmount * (this.interestRate / 100) * years;
      this.maturityAmount = this.depositAmount + this.interestEarned;
    } else {
      this.interestEarned = 0;
      this.maturityAmount = 0;
    }
  } */
  updateReturns(): void {
    const amountControl = this.createFDForm.get('amount');
    if (amountControl) {
      const rawValue = amountControl.value != null ? String(amountControl.value) : '';
      const numericValue = rawValue.replace(/[^0-9]/g, ''); // allow only digits

      if (numericValue !== rawValue) {
        amountControl.setValue(numericValue);
      }

      this.depositAmount = Number(numericValue);
    }

    this.tenureOption = this.createFDForm.get('tenureType')?.value;

    let actualTenureInMonths: number;
    if (this.tenureOption === 'custom') {
      const years = Number(this.createFDForm.get('customYear')?.value || 0);
      const months = Number(this.createFDForm.get('customMonth')?.value || 0);
      const days = Number(this.createFDForm.get('customDay')?.value || 0);

      let totalMonthsFloat = years * 12 + months + days / 30.44;

      // Clamp logic
      if (totalMonthsFloat > 60) {
        totalMonthsFloat = 60;
      }

      // If exactly 60 months, ensure days=0 for consistency with your rule
      if (Math.abs(totalMonthsFloat - 60) < 1e-6 && days > 0) {
        this.createFDForm.patchValue({ customDay: 0 }, { emitEvent: false });
        totalMonthsFloat = 60;
      }

      // Decide what you *store* as 'period' for validations and API
      // Option 1: round to 2 decimals
      // Option 2 (safer for validators): use integer months
      const periodForForm = Math.round(totalMonthsFloat); // or Math.floor/ceil as business requires

      actualTenureInMonths = totalMonthsFloat;        // internal usage if you need precision
      this.createFDForm.get('period')?.setValue(periodForForm, { emitEvent: false });
    } else {
      const years = Number(this.tenureOption);
      actualTenureInMonths = years * 12;
      this.createFDForm.get('period')?.setValue(actualTenureInMonths, { emitEvent: false });

      // Clear custom fields
      this.createFDForm.patchValue(
        { customYear: 1, customMonth: 0, customDay: null },
        { emitEvent: false }
      );
    }

    // ✅ Maturity Date calculation
    this.maturityDate = this.addMonths(this.fdStartDate, actualTenureInMonths);

    // ✅ Format for display (DD-MMM-YYYY)
    this.maturityDateDisplay = this.maturityDate.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });


    const schemeCd = this.createFDForm.get('schemeCd')?.value;
    const catSubTypCd = this.createFDForm.get('catSubTypCd')?.value;

    const data = {
      fdScheme: schemeCd,
      fdAmount: this.depositAmount,
      custCat: catSubTypCd,
      fdPeriod: actualTenureInMonths
    };

    this.createFDForm.get('period')?.setValue(actualTenureInMonths);

    this.subscription.add(
      this.apiService.intCalc(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe({
        next: (response: any) => {
          const formattedResponse = response.replace(/['"]+/g, '');
          this.createFDForm.get('intRate')?.setValue(formattedResponse);

          const baseRate = parseFloat(formattedResponse);
          this.interestRate = baseRate;
          this.nonCumulativeQuarterlyRate = baseRate - 0.10;
          this.nonCumulativeYearlyRate = baseRate;

          const years = actualTenureInMonths / 12;

          // We'll compute into maturityAmountRaw first
          let maturityAmountRawLocal = 0;

          if (actualTenureInMonths > 0 && this.depositAmount > 0) {

            if (schemeCd === 'QUARTERLY COMPOUNDING') {
              // Quarterly compounding
              const r = baseRate / 100;
              const n = 4;
              const t = actualTenureInMonths / 12;
              const amount = this.depositAmount * Math.pow(1 + r / n, n * t);
              maturityAmountRawLocal = amount;
              const intErn = Math.round(amount - this.depositAmount)
              this.interestEarned = intErn;

            } else if (schemeCd === 'QCAP') {
              // Quarterly Capitalization logic
              let principal = this.depositAmount;
              const quarterlyRate = baseRate / 100 / 4;
              const totalMonths = actualTenureInMonths;
              let totalInterest = 0;
              let firstYearInterest = 0;

              const yearsCount = Math.ceil(totalMonths / 12);
              for (let year = 1; year <= yearsCount; year++) {
                let yearlyInterest = 0;
                for (let q = 1; q <= 4; q++) {
                  if ((year - 1) * 12 + q * 3 <= totalMonths) {
                    const interest = principal * quarterlyRate;
                    yearlyInterest += interest;
                    principal += interest; // add interest for next quarter
                  }
                }
                totalInterest += yearlyInterest;

                if (year === 1) {
                  firstYearInterest = yearlyInterest;
                }

                if (year < yearsCount) {
                  principal = this.depositAmount; // reset principal for next year
                }
              }

              this.interestEarned = firstYearInterest; // Show only first year's interest
              maturityAmountRawLocal = this.depositAmount + totalInterest; // Full maturity amount

            } else {
              // Simple interest
              this.interestEarned = this.depositAmount * (this.interestRate / 100) * years;
              maturityAmountRawLocal = this.depositAmount + this.interestEarned;
            }

          } else {
            this.interestEarned = 0;
            maturityAmountRawLocal = 0;
          }

          // Non-cumulative payouts
          this.nonCumulativeQuarterlyPayout =
            this.depositAmount * (this.nonCumulativeQuarterlyRate / 100) * (1 / 4);
          this.nonCumulativeYearlyPayout =
            this.depositAmount * (this.nonCumulativeYearlyRate / 100);

          // >>> Normalize & assign to keep the SAME name "maturityAmount" for display
          this.maturityAmountRaw = maturityAmountRawLocal; // keep raw number if needed elsewhere
          const mRounded = this.roundToNearestRupee(maturityAmountRawLocal);
          this.maturityAmount = this.toTwoDecimals(mRounded); // display string, e.g., "16938.00"

          // >>> Also prep a display value for deposit (for QCAP ternary in template)
          const depRounded = this.roundToNearestRupee(this.depositAmount);
          this.depositAmountDisplay = this.toTwoDecimals(depRounded);

          this.cdChanges.detectChanges();
        }
      })
    );
  }

  /**
   * Auto-calculate journey step based on current form state.
   * Call this whenever relevant form values change.
   */
  updateJourneyStep(): void {
    const form = this.createFDForm;
    const amount = form.get('amount')?.value;
    const scheme = form.get('schemeCd')?.value;
    const branch = form.get('branchCd')?.value;
    const category = form.get('catSubTypCd')?.value;
    const period = form.get('period')?.value;

    // Step 0: Account Details – basic deposit details filled
    const accountDetailsFilled = amount && amount >= 10000 && scheme && branch && category && period;
    // Step 1: KYC Verification – PAN is set (user is logged in & KYC done before creating FD)
    const kycVerified = !!form.get('panNo')?.value && !!form.get('cifCd')?.value;
    // Step 2: Bank Details – bank info fetched
    const bankDetailsFilled = !!(this.bankDetails && this.bankDetails.custAccNum);
    // Step 3: Payment Details – UTR and payment date OR payment gateway done
    const paymentDone = this.paymentGateewayDone || (
      form.get('neftNum')?.value && form.get('neftDt')?.value
    );
    // Step 4: Final Submission – terms accepted and form valid
    const readyForSubmit = this.hasClickedTerms && form.valid;

    let step = 0;
    if (readyForSubmit) {
      step = 4;
    } else if (paymentDone) {
      step = 3;
    } else if (bankDetailsFilled) {
      step = 2;
    } else if (kycVerified) {
      step = 1;
    } else if (accountDetailsFilled) {
      step = 0;
    } else {
      step = 0;
    }

    this.currentJourneyStep = step;
  }

  private addMonths(startDate: Date, months: number): Date {
    const date = new Date(startDate);
    const day = date.getDate();

    date.setMonth(date.getMonth() + Math.floor(months));

    // Handle month-end overflow (e.g. Jan 31 → Feb)
    if (date.getDate() < day) {
      date.setDate(0); // last day of previous month
    }

    return date;
  }


  /** Half-up rounding to nearest rupee: >= .50 up, else down. */
  private roundToNearestRupee(v: any): number {
    const n = parseFloat(v ?? '0');
    if (isNaN(n)) return 0;
    return Math.round(n);
  }

  /** Always render with two decimals (.00). */
  private toTwoDecimals(n: number): string {
    return n.toFixed(2);
  }

  verifyEmpCode() {
    const empCode = this.createFDForm.get('empCode')?.value;
    const panNo = this.createFDForm.get("panNo")?.value;
    let data = {
      empCode: empCode,
      fdUserPan: panNo
    }
    this.subscription.add(
      this.apiService.verifyEmpCode(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe((res) => {
        if (res.message == 'Yes' && res.statusCode == '1002') {
          this.isEmpValidated = true
          this.notify.success('Employee Code is Verified');

        } else if (res.message == 'No') {
          this.notify.error('Your Employee code is invalid, Please Try with correct Employee code');
          this.createFDForm.get('catSubTypCd')?.setValue('GENERAL');
          this.updateReturns();
          this.createFDForm.get('empCode')?.disable();
          this.createFDForm.get('empCode')?.setValue('');
        }
      })
    )
  }


  /*   openJointModal() {
      this.modalService.open(this.jointModal, { size: 'lg' });
    } */

  OnChangeofDepositorType(event: Event) {

    this.mainFDTable = [];
    this.createFDForm.get('invCatHoldTypCd')?.setValue('');


  }

  addRemoveJointHolder() {
    this.finalObjectJointHolder = null;

    if (this.createFDForm.get('branchCd')?.invalid) {
      this.notify.info('Please fill the Branch office to Manage Joint holder', 'Info');
      this.createFDForm.get('branchCd')?.markAllAsTouched();
      return
    }
    if (this.createFDForm.get('invCatHoldTypCd')?.value == '' || this.createFDForm.get('invCatHoldTypCd')?.value == null) {
      this.notify.info('Please fill the Holding Type to Manage Joint holder', 'Info');
      this.createFDForm.get('invCatHoldTypCd')?.markAllAsTouched();
      return
    }


    this.getHoldGuardDetails();


    if (this.createFDForm.get('depositorType')?.value == 'JOINT') {
      this.showForm = false;
      this.modalService.open(this.jointModal, {
        size: 'lg',
        backdrop: 'static',
        keyboard: false
      });
      this.vkycURL = '';
      this.vkycLinkFetchError = false;
      this.vkycInitiated = false;
      this.vkycConfirmationAccepted = false;
      this.finalObjectJointHolder = {

        pan: null,
        name: null,
        dob: null,
        guardFlag: 'N',
        panVerifyFlag: null,
        kycBranchCd: null,
        userId: null,
        relationship: null,
        aadharNo: null,
        postalCode: '',
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        aadharFlag: null,
        isPEP: null,
        mobileNo: null,
        vkycFlag: null,
        vkycUrl: null


      };
    }

  }


  callInterestRateModal() {
    this.modalService.open(this.interestRateModal, {
      size: 'xl',
      backdrop: 'static',
      keyboard: false,
    });

  }

  OnChangeofDepositorIs() {
    if (this.createFDForm.get('dob')?.value) {

      let dob = this.createFDForm.get('dob')?.value;

      if (!dob) return;

      const birthDate = new Date(dob);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const m = today.getMonth() - birthDate.getMonth();

      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }

      if (age < 18) {
        this.createFDForm.get('depositorIs')?.setValue('Minor');
        this.createFDForm.get('depositorIs')?.disable();

      } else {
        this.createFDForm.get('depositorIs')?.setValue('Major');
        this.createFDForm.get('depositorIs')?.disable();

      }

    }
  }


  getHoldGuardDetails() {
    let newRegId = this.authService.getResponseValueByKey('fdUserDtlsId');
    let data = { newRegId: newRegId };

    this.apiService.getHoldGuardDetails(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe((res: any) => {
      const allHolders = res?.data || [];

      const jointHolders = allHolders.filter((val: any) => val.guardFlag === 'N');
      const guardians = allHolders.filter((val: any) => val.guardFlag === 'Y');

      // Initialize guardianList
      this.guardianList = [];

      this.jointHolders = jointHolders.map((holder: any) => {
        const guardian = guardians.find((g: any) => g.jointGuardMapFlag === holder.pan);
        const holderWithGuardianFlag = guardian ? { ...holder, hasGuardian: true } : holder;

        // Remove matched guardian from guardians list to avoid duplication
        if (guardian) {
          // Optional: remove matched guardian from the list
          guardians.splice(guardians.indexOf(guardian), 1);
          return [holderWithGuardianFlag, { ...guardian, isGuardian: true }];
        } else {
          return [holderWithGuardianFlag];
        }
      }).flat();

      // Remaining guardians not mapped to any joint holder
      this.guardianList = guardians;
      console.log(this.jointHolders)
    });
  }


  addToMainTable(holder: any) {
    const vkycFlag = this.createFDForm.get("vkycFlag")?.value;
    const amount = this.createFDForm.get('amount')?.value;

    const MAX_HOLDERS = 2;

    // Check if already added
    if (this.isAlreadyAdded(holder)) {
      return;
    }

    // Check for matching joint holder by PAN
    let matchedJointHolder: any = null;
    if (holder.hasGuardian) {
      matchedJointHolder = this.jointHolders.find(jh => jh.jointGuardMapFlag === holder.pan);
    }

    // Calculate how many entries will be added
    let additionalCount = 1; // holder
    if (holder.hasGuardian) {
      additionalCount += 1; // guardian or matched joint holder
    }

    if (this.mainFDTable.length + additionalCount > MAX_HOLDERS) {
      this.notify.warning('Maximum of 2 holders can be added.');
      return;
    }

    if (amount == null || amount === '') {
      this.notify.warning('Please update add the Amount to Deposit', 'Warning');
      this.createFDForm.get('amount')?.markAllAsTouched();
      return;
    }

    if (amount > 100000 && vkycFlag === '1') {
      const isHolderVkycIncomplete = holder.vkycFlag == null || holder.vkycFlag === '0';
      const isGuardianVkycIncomplete = holder.hasGuardian && (
        matchedJointHolder
          ? (matchedJointHolder.vkycFlag == null || matchedJointHolder.vkycFlag === '0')
          : (holder.guardianVkycFlag == null || holder.guardianVkycFlag === '0')
      );

      if (isHolderVkycIncomplete || isGuardianVkycIncomplete) {
        this.notify.warning(`Please complete the VKYC for ${holder.name}${holder.hasGuardian ? ' and their guardian' : ''} to invest more than ₹1 Lakh.`);
        return;
      }
    }

    // Temporarily add holder and guardian/matchedJointHolder to check age condition
    const tempList = [...this.mainFDTable, holder];
    if (holder.hasGuardian) {
      tempList.push(matchedJointHolder || holder.guardian);
    }

    const isAnyAdult = tempList.some(item => {
      const dob = new Date(item.dob);
      const age = this.calculateAge(dob);
      return age >= 18;
    });

    if (!isAnyAdult) {
      this.notify.warning('At least one holder must be 18 years or older.');
      return;
    }

    // ✅ All checks passed, add both to mainFDTable
    this.mainFDTable.push(holder);
    if (holder.hasGuardian) {
      this.mainFDTable.push(matchedJointHolder || holder.guardian);
    }
  }

  // Helper function to calculate age
  calculateAge(dob: Date): number {
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
      age--;
    }
    return age;
  }


  removeHolder(index: number) {
    this.jointHolders.splice(index, 1);
  }

  removeFromMainTable(index: number) {
    const removedHolder = this.mainFDTable[index];

    // Remove the holder
    this.mainFDTable.splice(index, 1);

    // If the removed holder has a guardian, check and remove the guardian or matched joint holder
    if (removedHolder.hasGuardian) {
      // Check for matched joint holder by PAN
      const matchedIndex = this.mainFDTable.findIndex(item => item.jointGuardMapFlag === removedHolder.pan);

      if (matchedIndex !== -1) {
        this.mainFDTable.splice(matchedIndex, 1);
      } else {
        // If no joint holder match, remove guardian by comparing object reference or unique ID
        const guardianIndex = this.mainFDTable.findIndex(item =>
          item.pan === removedHolder.guardian?.pan
        );
        if (guardianIndex !== -1) {
          this.mainFDTable.splice(guardianIndex, 1);
        }
      }
    }
  }

  isAlreadyAdded(holder: any): boolean {
    return this.mainFDTable.some(
      h => h.pan === holder.pan && h.aadhaar === holder.aadhaar
    );
  }




  verifyPAN() {
    this.panForm.get('kycbranchName')?.setValue(this.createFDForm.get('branchCd')?.value);
    if (this.panForm.valid) {
      const panNumber = this.panForm.get('panNumber')?.value;
      const primaryPan = this.createFDForm.get('panNo')?.value;
      if (this.jointHolders && this.jointHolders?.length > 0) {


        // Check if PAN already exists in joint holders
        const matchedItem = this.jointHolders.find(item => item.pan === panNumber);

        if (matchedItem) {
          this.notify.info('PAN Number already exists in the Joint Holder table', 'Info');
          this.panForm.reset();
          return;
        }

        // Check if PAN matches primary depositor
        if (primaryPan === panNumber) {
          this.notify.info('Primary Depositor cannot be added as a Joint Holder', 'Info');
          this.panForm.reset();
          return;
        }
      }
      if (primaryPan === panNumber) {
        this.notify.info('Primary Depositor cannot be added as a Joint Holder', 'Info');
        this.panForm.reset();
        return;
      }
      this.verifyPanCount();
      const datePipe = new DatePipe('en-US');
      const rawDob = this.panForm.get('panDOB')?.value;
      const formattedDob = datePipe.transform(rawDob, 'dd/MM/yyyy');
      this.spinner.show();
      const data = {
        pan: this.panForm.get('panNumber')?.value,
        dob: formattedDob,
        kycbranchName: this.createFDForm.get('branchCd')?.value,
        name: this.panForm.get('panName')?.value,
        fdRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        fdUserId: this.authService.getResponseValueByKey('fdUserId'),
        flag: 1
      };

      this.subscription.add(
        this.apiService
          .verifiyPanData(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();
              try {
                const parsedMessage = JSON.parse(response.message);
                const panData = parsedMessage.payload?.data?.[0];
                const employeeData = response?.['employeeData'];

                if (
                  parsedMessage.statusCode === '1000' &&
                  parsedMessage.statusMsg === 'Success' &&
                  panData
                ) {
                  const { pan_status, name, dob, seeding_status } = panData;

                  // Handle all valid/invalid combinations
                  if (
                    response.statusCode === '1002' ||
                    response.statusCode === '1008'
                  ) {
                    if (pan_status === 'E' && name === 'Y' && dob === 'Y') {
                      // All matched
                      this.panForm.get('panNumber')?.disable();
                      this.panForm.get('panName')?.disable();
                      this.panForm.get('panDOB')?.disable();
                      this.panForm.get('kycbranchName')?.disable();
                      this.panForm.get('selectedPEP')?.disable();
                      this.panForm.get('relationship')?.disable();
                      // this.panForm.get('guardianName')?.disable();


                      this.notify.success(
                        'PAN verified successfully',
                        'Success',
                      );
                      //  this.aadharpanSedingstatus();
                      this.panSubmitted = true;
                      this.updateFinalRequest('PAN');


                      this.cdChanges.detectChanges();
                    } else if (
                      pan_status === 'E' &&
                      name === 'N' &&
                      dob === 'N'
                    ) {
                      // Both name and DOB mismatch
                      this.panSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to both Name and Date of Birth mismatch. Kindly ensure both fields match your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' &&
                      name === 'N' &&
                      dob === 'Y'
                    ) {
                      // Only name mismatch
                      this.panSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a name mismatch. Kindly ensure the name entered matches your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' &&
                      name === 'Y' &&
                      dob === 'N'
                    ) {
                      // Only DOB mismatch
                      this.panSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a mismatch in the date of birth. Please ensure the date of birth matches the one on your PAN record.',
                        'Error',
                      );
                    } else if (pan_status === 'N') {
                      // Invalid PAN
                      this.panSubmitted = false;
                      this.notify.error(
                        'Invalid PAN. Kindly check and try again.',
                        'Error',
                      );
                    } else {
                      // Unknown response
                      this.panSubmitted = false;
                      this.notify.warning(
                        'PAN verification returned an unknown response. Please contact support.',
                        'Warning',
                      );
                    }
                  } else {
                    // Unexpected statusCode
                    this.panSubmitted = false;
                    this.notify.warning(
                      'PAN verification failed due to unexpected response.',
                      'Warning',
                    );
                  }
                } else {
                  this.panSubmitted = false;
                  this.notify.error(
                    'Invalid response received during PAN verification.',
                    'Error',
                  );
                }
              } catch (e) {
                // PAN already registered case
                if (
                  response.statusCode === '1008' &&
                  typeof response.message === 'string'
                ) {

                  let getUserdata = {
                    fdUserId: response?.fdUserId
                  };

                  this.subscription.add(
                    this.apiService
                      .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(getUserdata)))
                      .subscribe({
                        next: (response: any) => {
                          if (response != null) {

                            if (
                              response.aadhaarVirifystsFlag === 'Y' &&
                              response.panverify_Flag === 'Y'
                            ) {
                              this.notify.success(
                                'PAN and AADHAAR Already Reqistered successfully',
                                'Success',
                              );
                              this.panSubmitted = true;
                              this.aadhaarSubmitted = true;
                              this.panForm.get('panName')?.setValue(response.fdUserName);
                              this.panForm.get('panNumber')?.setValue(response.fdUserPan);
                              if (response.politicalExposedPerson === 'Y') {
                                this.panForm.get('isPEP')?.setValue('Yes');
                              } else if (response.politicalExposedPerson === 'N') {
                                this.panForm.get('isPEP')?.setValue('No');
                              }

                              // set Aadhar number
                              this.aadhaarForm
                                .get('aadhaarNumber')
                                ?.setValue(response.fdUserAdharCard);
                              this.updateFinalRequest('PAN');
                              this.updateFinalRequest('AADHAAR');
                              this.panForm.disable();
                              this.aadhaarForm.disable();

                              this.cdChanges.detectChanges();
                            } else if ((response.aadhaarVirifystsFlag === null ||
                              response.aadhaarVirifystsFlag === '') &&
                              response.panverify_Flag === 'Y') {



                              this.notify.success(
                                'PAN Already Reqistered successfully',
                                'Success',
                              );
                              this.panForm.get('panNumber')?.disable();
                              this.panForm.get('panName')?.disable();
                              this.panForm.get('panDOB')?.disable();
                              this.panForm.get('kycbranchName')?.disable();
                              this.panForm.get('selectedPEP')?.disable();
                              this.panForm.get('relationship')?.disable();
                              // this.panForm.get('guardianName')?.disable();
                              this.panSubmitted = true;
                              this.updateFinalRequest('PAN');
                              //  }




                            }

                          }
                        },
                        error: (e) => {
                          console.log('error', e)
                          this.spinner.hide();
                          this.notify.warning(
                            'An error occurred while verifying PAN.',
                            'Warning',
                          );
                        },
                      })
                  );

                  /* end */



                } else {
                  this.notify.error(
                    'Invalid or malformed response received during PAN verification.',
                    'Error',
                  );
                  this.panSubmitted = false;
                }
              }
            },
            error: (e) => {
              console.log('error', e)
              this.spinner.hide();
              this.notify.warning(
                'An error occurred while verifying PAN.',
                'Warning',
              );
            },
          })
      );


    } else {
      this.panForm.markAllAsTouched();
    }
  }

  updateFinalRequest(where: string) {
    console.log('where', where);
    if (where == 'PAN') {
      this.finalObjectJointHolder.pan = this.panForm.get('panNumber')?.value
      this.finalObjectJointHolder.dob = this.panForm.get('panDOB')?.value
      this.finalObjectJointHolder.kycBranchCd = this.panForm.get('kycbranchName')?.value
      this.finalObjectJointHolder.name = this.panForm.get('panName')?.value
      this.finalObjectJointHolder.isPEP = this.panForm.get('isPEP')?.value
      this.finalObjectJointHolder.panVerifyFlag = 'Y'
      this.finalObjectJointHolder.mobileNo = this.panForm.get('mobileNumber')?.value
      this.finalObjectJointHolder.mailId = this.panForm.get('emailId')?.value
    } else if (where == 'AADHAAR') {
      this.finalObjectJointHolder.aadharFlag = 'Y'
      this.finalObjectJointHolder.aadharNo = this.aadhaarForm.get('aadhaarNumber')?.value


    } else {

      this.finalObjectJointHolder.vkycFlag = 0
      this.finalObjectJointHolder.vkycUrl = this.vkycURL;

    }


    console.log('req', this.finalObjectJointHolder);

  }

  sendAadhaarOTP(isResend: boolean = false) {
    const aadhaarControl = this.aadhaarForm.get('aadhaarNumber');

    // ✅ getRawValue() is needed because aadhaarNumber is disabled after first OTP
    const aadhaarValue =
      aadhaarControl?.value || this.aadhaarForm.getRawValue().aadhaarNumber;

    if (!aadhaarValue) {
      aadhaarControl?.markAsTouched();
      return;
    }

    // ✅ Validate only for first Send OTP
    // On resend, aadhaarNumber is disabled, so don't depend on control.valid
    if (!isResend && aadhaarControl?.invalid) {
      aadhaarControl.markAsTouched();
      return;
    }

    // ✅ Immediately disable resend button when resend is clicked
    if (isResend) {
      this.canResendAadhaarOtp = false;
      this.aadhaarResendTimer = 60;
    }

    this.spinner.show();

    const data = {
      aadharno: String(aadhaarValue),
      newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
      flag: 1
    };

    this.subscription.add(
      this.apiService
        .eKYCRequestOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            this.spinner.hide();

            if (response.statusCode == '1002') {
              this.notify.success(
                isResend
                  ? 'Aadhaar OTP resent successfully'
                  : 'Aadhaar OTP sent to registered mobile number',
                'Success'
              );

              this.aadhaarForm.get('aadhaarNumber')?.disable();
              this.aadhaarForm.get('aadhaarOTP')?.reset();
              this.aadhaarForm.get('aadhaarOTP')?.enable();

              this.sendOTPbtn = true;

              // ✅ Restart resend countdown
              this.startAadhaarResendTimer();

            } else if (response.statusCode == '1008') {
              this.notify.error(
                'Aadhaar OTP generation was unsuccessful. This may be due to an invalid Aadhaar number. Kindly verify the details and try again.',
                'Error'
              );

              // ✅ If resend failed, allow resend again
              if (isResend) {
                this.canResendAadhaarOtp = true;
              }
            }
          },
          error: (error) => {
            console.error('An error occurred in aadharOTPRequest:', error);
            this.spinner.hide();

            // ✅ If resend API failed, allow user to retry
            if (isResend) {
              this.canResendAadhaarOtp = true;
            }
          },
        })
    );
  }
  submitAadhaarOTP() {

    if (this.aadhaarForm.valid) {
      this.notify.info(
        'Your Aadhaar eKYC verification is in progress. Please wait a few moments while the process completes.',
        'Information',
      );

      setTimeout(() => {
        this.spinner.show();
        const data = {
          aadharno: this.aadhaarForm.get('aadhaarNumber')?.value,
          otp: this.aadhaarForm.get('aadhaarOTP')?.value,
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          mailId: this.authService.getResponseValueByKey('fdUserEmail'),
          flag: 1,
          panNo: this.panForm.get('panNumber')?.value
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestdata(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  console.log("AAdhar RESP >>>>>>>>>>>>>>>>>>" + response);
                  this.notify.success(
                    'Aadhaar Verification Successfully Completed',
                    'Success',
                  );
                  this.clearAadhaarResendTimer();

                  this.aadhaarOtpSent = false;
                  this.canResendAadhaarOtp = false;
                  this.updateFinalRequest('AADHAAR');
                  //  this.gettingLocalStorageData(data.mailId || '');
                  // this.aadharpanSedingstatus();
                  /*      setTimeout(() => {
                         this.showFDConfirmationDialog = true;
                       }, 1000); */
                  this.aadhaarSubmitted = true;
                  this.aadhaarForm?.disable();
                  // set Aadhar number
                  // this.aadhaarForm.get('aadhaarNumber')?.setValue(data.aadharno);
                  this.cdChanges.detectChanges();
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Resident authentication failed'
                ) {
                  this.notify.error(
                    'Enter Aadhaar valid OTP Number',
                    'Error',
                  );
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Invalid transactionId.'
                ) {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                } else if (response.statusCode == '1008' &&
                  response.statusMsg == 'The given customer Pan and Aadhar name Mismatch'
                ) {
                  this.notify.error(
                    response.statusMsg,
                    'Mismatch',
                  );
                } else if (response.statusCode == '1008') {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                }
              },
              error: (error) => {
                this.spinner.hide();
                console.error('An error occurred in submitAadhaarForm:', error);
              },
            })
        );
      }, 3000);


    }

  }



  addNewGuardian() {
    // You can replace this with a modal or form later
    const newGuardian = {
      name: 'New Guardian',
      relationship: 'Guardian',
      contact: '9000000000'
    };
    this.guardianList.push(newGuardian);
  }

  removeGuardian(index: number) {
    this.guardianList.splice(index, 1);
  }

  handlePanInput(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('panNumber')?.setValue(upperValue);
  }

  handlePanInputOne(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('panName')?.setValue(upperValue);
  }


  verifyPanCount() {
    if (this.panAttemptCount < this.maxAttempts) {
      this.panAttemptCount++;
      if (this.panAttemptCount >= this.maxAttempts) {
        this.panDisabled = true;
        this.panAttemptMsg =
          'Max attempts reached for pan verification kindly try after some time';
        setTimeout(() => {
          this.panAttemptMsg = '';
        }, 15000);
      }
    }
  }

  AddJointHolder() {
    if (this.panSubmitted && this.aadhaarSubmitted) {

      /*  if (this.isMinor && this.panForm.get('guardianName')?.value == null) {
         this.notify.warning('Please fill the Gaurdian Name');
         this.enableGurdianErrorMsg = true;
         return
       } */

      if (this.isAddjointHolderSubmitting) return;
      this.isAddjointHolderSubmitting = true;

      if (this.panForm.get('relationship')?.value == null || this.panForm.get('relationship')?.value == '') {
        this.notify.warning('Please fill the Relationship');
        this.enableRelationshipErrorMsg = true;
      } else {
        this.finalObjectJointHolder.relationship = this.panForm.get('relationship')?.value
      }
      this.finalObjectJointHolder.userId = this.authService.getResponseValueByKey('fdUserEmail');

      this.subscription.add(
        this.apiService.saveHoldGuardDetails(
          this.hybridEncryptor.encrypted(JSON.stringify(this.finalObjectJointHolder))
        ).subscribe({
          next: (response: any) => {
            console.log('save holder', response);
            if (response.statusCode == '1002') {
              if (this.isMinor) {
                this.enableGuardianSection = true;
                this.notify.success('Joint Holder Added Successfully. Please Proceed to Add Gaurdian', 'Information')
              } else {
                this.getHoldGuardDetails();
                this.showForm = false;
              }

            }
            this.isAddjointHolderSubmitting = false;

          },
          error: (err: any) => {
            console.error('Error saving holder details:', err);
            // Optionally show an error message to the user
            this.notify.error('Failed to save holder details. Please try again.', 'Error');
            this.isAddjointHolderSubmitting = false;
          }
        })
      );
    }
  }

  enableAddHolderForm() {
    this.vkycConfirmationAccepted = false;
    this.vkycLinkFetchError = false;

    this.showForm = true;
    this.panForm.enable();
    this.aadhaarForm.enable();
    this.panForm.reset();
    this.vkycForm.reset();
    this.aadhaarForm.reset();
    this.panSubmitted = false;
    this.aadhaarSubmitted = false;

  }

  belowOneLaks() {
    this.isSelectedBelowOneLaks = 'Y';
    if (!this.panSubmitted && !this.aadhaarSubmitted) {
      this.notify.warning(
        'Please complete the Pan and Aadhar verification',
        'KYC Pending',
      );
    }
  }

  doVkycProcessForJointHolder() {

    const vkycPan = this.panForm.get('panNumber')?.value;
    const vkycDob = this.panForm.get('panDOB')?.value;

    const isEmpty = (v: any) =>
      v == null || (typeof v === 'string' && v.trim() === '');

    if (isEmpty(vkycPan) || isEmpty(vkycDob)) {
      this.notify.warning('Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.', 'Info');
      return;
    }
    if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
      this.notify.warning('Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.', 'Info');
      return;
    }
    if (isEmpty(vkycPan)) {
      this.notify.warning('Unable to proceed with VKYC as your PAN is not updated in our records.', 'Info');
      return;
    }
    if (isEmpty(vkycDob)) {
      this.notify.warning('Unable to proceed with VKYC as your Date of Birth is not updated in our records.', 'Info');
      return;
    }



    if (this.panForm.get('mobileNumber')?.value && this.panForm.get('emailId')?.value) {
      let rowDate = this.panForm.get('panDOB')?.value
      if (this.panForm.get('panDOB')?.value) {
        rowDate = this.formatDateToDDMMYYYY(rowDate);
      }

      let data = {
        name: this.panForm.get('panName')?.value,
        namePrintedInPan: this.panForm.get('panName')?.value,
        dob: rowDate,
        pan: this.panForm.get('panNumber')?.value,
        panValidation: 'false',
        email: this.createFDForm.get('fdUserId')?.value,
        mobile: this.panForm.get('mobileNumber')?.value,
        mailId: this.panForm.get('emailId')?.value,
      };
      this.subscription.add(
        this.apiService
          .doVkycProcessService(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == 1002) {

                this.vkycConfirmationAccepted = true;
                this.vkycInitiated = true;
                // Access the vkycURL
                const formated = JSON.parse(response.message);
                this.vkycURL = formated.vkycURL;

                this.updateFinalRequest('vkyc');
                // Desired dimensions
                const width = 500;
                const height = 500;
                // Calculate center position
                const left = Math.floor((window.screen.width - width) / 2);
                const top = Math.floor((window.screen.height - height) / 2);
                // Open centered window
                const features = `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`;
                window.open(this.vkycURL, '_blank');
              } else {
                this.vkycURL = '';
                this.vkycLinkFetchError = true;
                this.vkycInitiated = false;
                this.vkycConfirmationAccepted = false;

              }
            },
            error: (err) => {
              console.log('An error occurred something went wrong ' + err);
            },
          })
      );


    } else {
      this.vkycForm.markAllAsTouched();
    }



  }


  doVkycProcessForJointHolderSecondary(selectedHolder: any) {


    if (this.vkycForm.valid) {
      let rowDate = this.selectedHolder?.dob
      if (this.selectedHolder?.dob) {
        rowDate = this.formatDateToDDMMYYYY(rowDate);
      }


      const vkycPan = this.selectedHolder?.pan;
      const vkycDob = this.selectedHolder?.dob;

      const isEmpty = (v: any) =>
        v == null || (typeof v === 'string' && v.trim() === '');

      if (isEmpty(vkycPan) || isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan)) {
        this.notify.warning('Unable to proceed with VKYC as your PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth is not updated in our records.', 'Info');
        return;
      }
      let data = {
        name: this.selectedHolder?.name,
        namePrintedInPan: this.selectedHolder?.name,
        dob: rowDate,
        pan: this.selectedHolder?.pan,
        panValidation: 'false',
        email: this.createFDForm.get('fdUserId')?.value,
        mobile: this.vkycForm.get('mobileNumber')?.value,
        mailId: this.vkycForm.get('emailId')?.value,
      };
      this.subscription.add(
        this.apiService
          .doVkycProcessService(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == 1002) {

                this.vkycConfirmationAccepted = true;
                this.vkycInitiated = true;
                // Access the vkycURL
                const formated = JSON.parse(response.message);
                this.vkycURL = formated.vkycURL;

                this.updateFinalRequestForOnlyVkycInitiate();
                // Desired dimensions
                const width = 500;
                const height = 500;
                // Calculate center position
                const left = Math.floor((window.screen.width - width) / 2);
                const top = Math.floor((window.screen.height - height) / 2);
                // Open centered window
                this.vkycForm.reset();
                this.showVkycPopup = false;
                this.selectedHolder = null;
                this.getHoldGuardDetails();
                this.cdChanges.detectChanges();
                const features = `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`;
                window.open(this.vkycURL, '_blank');
              } else {
                this.vkycURL = '';
                this.vkycLinkFetchError = true;
                this.vkycInitiated = false;
                this.vkycConfirmationAccepted = false;

              }
            },
            error: (err) => {
              console.log('An error occurred something went wrong ' + err);
            },
          })
      );


    } else {
      this.vkycForm.markAllAsTouched();
    }



  }

  updateFinalRequestForOnlyVkycInitiate() {
    let rowDate = this.selectedHolder?.dob
    if (this.selectedHolder?.dob) {
      rowDate = this.formatDateToDDMMYYYY(rowDate);
    }

    this.finalObjectJointHolder.pan = this.selectedHolder?.pan
    this.finalObjectJointHolder.dob = rowDate
    this.finalObjectJointHolder.kycBranchCd = this.selectedHolder?.kycBranchCd
    this.finalObjectJointHolder.name = this.selectedHolder?.name
    this.finalObjectJointHolder.isPEP = this.selectedHolder?.isPEP
    this.finalObjectJointHolder.panVerifyFlag = 'Y'


    this.finalObjectJointHolder.aadharFlag = 'Y'
    this.finalObjectJointHolder.aadharNo = this.selectedHolder?.aadharNo



    this.finalObjectJointHolder.mobileNo = this.vkycForm.get('mobileNumber')?.value
    this.finalObjectJointHolder.mailId = this.vkycForm.get('emailId')?.value
    this.finalObjectJointHolder.vkycFlag = 0
    this.finalObjectJointHolder.vkycUrl = this.vkycURL;
    this.finalObjectJointHolder.relationship = this.selectedHolder?.relationship
    this.finalObjectJointHolder['holdId'] = this.selectedHolder?.holdId
    this.finalObjectJointHolder['guardFlag'] = 'N'
    this.finalObjectJointHolder['newRegId'] = this.selectedHolder?.newRegId
    this.finalObjectJointHolder['minorFlag'] = this.selectedHolder?.minorFlag





    console.log('req', this.finalObjectJointHolder);

    this.AddJointHolderForSecondary();

  }


  AddJointHolderForSecondary() {

    if (this.vkycForm.valid) {
      this.finalObjectJointHolder.userId = this.authService.getResponseValueByKey('fdUserEmail');
      this.subscription.add(
        this.apiService.saveHoldGuardDetails(
          this.hybridEncryptor.encrypted(JSON.stringify(this.finalObjectJointHolder))
        ).subscribe({
          next: (response: any) => {
            console.log('save holder', response);
            if (response.statusCode == '1002') {
              this.modalService.dismissAll();
              this.getHoldGuardDetails();
            }
          },
          error: (err: any) => {
            console.error('Error saving holder details:', err);
            // Optionally show an error message to the user
            this.notify.error('Failed to save holder details. Please try again.', 'Error');
          }
        })
      );
    }



  }

  backtoTable() {
    this.vkycForm.reset();
    this.showVkycPopup = false;
    this.selectedHolder = null;
  }


  handleVkycClick(holder: any): void {
    if (holder.vkycFlag === null) {
      // Show VKYC popup for verification
      this.selectedHolder = holder;
      this.showVkycPopup = !this.showVkycPopup;
      this.vkycForm.reset();
    } else if (holder.vkycFlag === '0') {
      // Open VKYC URL in centered popup
      const width = 500;
      const height = 500;
      const left = Math.floor((window.screen.width - width) / 2);
      const top = Math.floor((window.screen.height - height) / 2);
      const features = `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`;


      if (holder.vkycUrl) {
        window.open(holder.vkycUrl, '_blank');
      } else {
        alert('VKYC URL not available.');
      }
    }
  }

  closeVkycPopup(): void {
    this.showVkycPopup = false;
    this.selectedHolder = null;
  }

  proceedVkycForHolder(): void {
    // Your VKYC logic here
    alert(`Proceeding VKYC for ${this.selectedHolder?.name}`);
    this.closeVkycPopup();
  }


  formatDateToDDMMYYYY(dateStr: any): string {
    const [year, month, day] = dateStr.split('-');
    return `${day}-${month}-${year}`;
  }




  // PAN
  guardianVerifyPAN() {
    this.guardianPanForm.get('kycbranchName')?.setValue(this.createFDForm.get('branchCd')?.value);
    if (this.guardianPanForm.valid) {
      const panNumber = this.guardianPanForm.get('panNumber')?.value;
      const primaryPan = this.createFDForm.get('panNo')?.value;

      if (this.jointHolders && this.jointHolders?.length > 0) {





        // Check if PAN already exists in joint holders
        const matchedItem = this.jointHolders.find(item => item.pan === panNumber);

        if (matchedItem) {
          this.notify.info('PAN Number already exists in the Joint Holder table', 'Info');
          this.guardianPanForm.reset();
          return;
        }

        // Check if PAN matches primary depositor
        if (primaryPan === panNumber) {
          this.notify.info('Primary Depositor cannot be added as a Joint Holders Guardian', 'Info');
          this.guardianPanForm.reset();
          return;
        }

      }

      // Check if PAN matches primary depositor
      if (primaryPan === panNumber) {
        this.notify.info('Primary Depositor cannot be added as a Joint Holders Guardian', 'Info');
        this.guardianPanForm.reset();
        return;
      }
      this.verifyPanCount();
      const datePipe = new DatePipe('en-US');
      const rawDob = this.guardianPanForm.get('panDOB')?.value;
      const formattedDob = datePipe.transform(rawDob, 'dd/MM/yyyy');
      this.spinner.show();
      const data = {
        pan: this.guardianPanForm.get('panNumber')?.value,
        dob: formattedDob,
        kycbranchName: this.createFDForm.get('branchCd')?.value,
        name: this.guardianPanForm.get('panName')?.value,
        fdRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        fdUserId: this.authService.getResponseValueByKey('fdUserId'),
        flag: 1
      };
      this.subscription.add(
        this.apiService
          .verifiyPanData(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();
              try {
                const parsedMessage = JSON.parse(response.message);
                const panData = parsedMessage.payload?.data?.[0];
                const employeeData = response?.['employeeData'];
                if (
                  parsedMessage.statusCode === '1000' &&
                  parsedMessage.statusMsg === 'Success' &&
                  panData
                ) {
                  const { pan_status, name, dob, seeding_status } = panData;
                  if (
                    response.statusCode === '1002' ||
                    response.statusCode === '1008'
                  ) {
                    if (pan_status === 'E' && name === 'Y' && dob === 'Y') {
                      this.guardianPanForm.get('panNumber')?.disable();
                      this.guardianPanForm.get('panName')?.disable();
                      this.guardianPanForm.get('panDOB')?.disable();
                      this.guardianPanForm.get('kycbranchName')?.disable();
                      this.guardianPanForm.get('selectedPEP')?.disable();
                      this.guardianPanForm.get('relationship')?.disable();
                      // this.guardianPanForm.get('guardianName')?.disable();
                      this.notify.success(
                        'PAN verified successfully',
                        'Success',
                      );
                      this.guardianPanSubmitted = true;
                      this.guardianUpdateFinalRequest('PAN');
                      this.cdChanges.detectChanges();
                    } else if (
                      pan_status === 'E' && name === 'N' && dob === 'N'
                    ) {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to both Name and Date of Birth mismatch. Kindly ensure both fields match your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' && name === 'N' && dob === 'Y'
                    ) {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a name mismatch. Kindly ensure the name entered matches your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' && name === 'Y' && dob === 'N'
                    ) {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a mismatch in the date of birth. Please ensure the date of birth matches the one on your PAN record.',
                        'Error',
                      );
                    } else if (pan_status === 'N') {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'Invalid PAN. Kindly check and try again.',
                        'Error',
                      );
                    } else {
                      this.guardianPanSubmitted = false;
                      this.notify.warning(
                        'PAN verification returned an unknown response. Please contact support.',
                        'Warning',
                      );
                    }
                  } else {
                    this.guardianPanSubmitted = false;
                    this.notify.warning(
                      'PAN verification failed due to unexpected response.',
                      'Warning',
                    );
                  }
                } else {
                  this.guardianPanSubmitted = false;
                  this.notify.error(
                    'Invalid response received during PAN verification.',
                    'Error',
                  );
                }
              } catch (e) {
                if (
                  response.statusCode === '1008' &&
                  typeof response.message === 'string'
                ) {

                  const matchedItem = this.jointHolders.find(item => item.pan === panNumber);

                  if (matchedItem) {
                    this.notify.info('PAN Number already exists in the Joint Holder table', 'Info');
                    this.guardianPanForm.reset();
                    return;
                  }

                  // Check if PAN matches primary depositor
                  if (primaryPan === panNumber) {
                    this.notify.info('Primary Depositor cannot be added as a Joint Holders Guardian', 'Info');
                    this.guardianPanForm.reset();
                    return;
                  }

                  let getUserdata = {
                    fdUserId: response?.fdUserId
                  };
                  this.subscription.add(
                    this.apiService
                      .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(getUserdata)))
                      .subscribe({
                        next: (response: any) => {
                          if (response != null) {
                            if (
                              response.aadhaarVirifystsFlag === 'Y' &&
                              response.panverify_Flag === 'Y'
                            ) {
                              this.notify.success(
                                'PAN and AADHAAR Already Reqistered successfully',
                                'Success',
                              );
                              this.guardianPanSubmitted = true;
                              this.guardianAadhaarSubmitted = true;

                              this.guardianPanForm.get('panName')?.setValue(response.fdUserName);
                              this.guardianPanForm.get('panNumber')?.setValue(response.fdUserPan);

                              if (response.politicalExposedPerson === 'Y') {
                                this.guardianPanForm.get('isPEP')?.setValue('Yes');
                              } else if (response.politicalExposedPerson === 'N') {
                                this.guardianPanForm.get('isPEP')?.setValue('No');
                              }

                              this.guardianAadhaarForm
                                .get('aadhaarNumber')
                                ?.setValue(response.fdUserAdharCard);

                              this.guardianUpdateFinalRequest('PAN');
                              this.guardianUpdateFinalRequest('AADHAAR');

                              this.guardianPanForm.disable();
                              this.guardianAadhaarForm.disable();
                              this.cdChanges.detectChanges();
                            } else if (
                              (response.aadhaarVirifystsFlag === null || response.aadhaarVirifystsFlag === '') &&
                              response.panverify_Flag === 'Y'
                            ) {
                              this.notify.success(
                                'PAN Already Registered successfully',
                                'Success',
                              );
                              this.guardianPanForm.get('panNumber')?.disable();
                              this.guardianPanForm.get('panName')?.disable();
                              this.guardianPanForm.get('panDOB')?.disable();
                              this.guardianPanForm.get('kycbranchName')?.disable();
                              this.guardianPanForm.get('selectedPEP')?.disable();
                              this.guardianPanForm.get('relationship')?.disable();
                              // this.guardianPanForm.get('guardianName')?.disable();
                              this.guardianPanSubmitted = true;
                              this.guardianPanSubmitted = true;
                              this.guardianUpdateFinalRequest('PAN');
                            }
                          }
                        },
                        error: (e) => {
                          console.log('error', e)
                          this.spinner.hide();
                          this.notify.warning(
                            'An error occurred while verifying PAN.',
                            'Warning',
                          );
                        },
                      })
                  );
                } else {
                  this.notify.error(
                    'Invalid or malformed response received during PAN verification.',
                    'Error',
                  );
                  this.guardianPanSubmitted = false;
                }
              }
            },
            error: (e) => {
              console.log('error', e)
              this.spinner.hide();
              this.notify.warning(
                'An error occurred while verifying PAN.',
                'Warning',
              );
            },
          })
      );
    } else {
      this.guardianPanForm.markAllAsTouched();
    }
  }

  // Aadhaar
  guardianSendAadhaarOTP() {
    if (this.guardianAadhaarForm.get('aadhaarNumber')?.valid) {
      var aadharnum = this.guardianAadhaarForm.get('aadhaarNumber')?.value;
      this.spinner.show();
      if (aadharnum != null && aadharnum != '') {
        const data = {
          aadharno: String(this.guardianAadhaarForm.get('aadhaarNumber')?.value),
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          flag: 1
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  if (response.statusCode == '1002') {
                    this.notify.success(
                      'Guardian Aadhaar OTP sent to registered mobile number',
                      'Success',
                    );

                    this.guardianAadhaarForm.get('aadhaarNumber')?.disable();
                    this.guardianAadhaarForm.get('aadhaarOTP')?.reset();
                    this.guardianAadhaarForm.get('aadhaarOTP')?.enable();

                    this.sendOTPbtn = true;

                    // ✅ Start guardian resend countdown
                    this.startGuardianAadhaarResendTimer();
                  }
                } else if (response.statusCode == '1008') {
                  this.notify.error(
                    'Aadhaar OTP generation was unsuccessful. This may be due to an invalid Aadhaar number. Kindly verify the details and try again.',
                    'Error',
                  );
                }
              },
              error: (error) => {
                console.error('An error occurred in aadharOTPRequest:', error);
                this.spinner.hide();
                // this.CommonError = "The server is currently busy. Please try again shortly";}
              },
            })
        );
      }
    } else {
      this.guardianAadhaarForm.get('aadhaarNumber')?.markAsTouched();
    }
  }
  guardianSubmitAadhaarOTP() {
    if (this.guardianAadhaarForm.valid) {
      this.notify.info(
        'Your Aadhaar eKYC verification is in progress. Please wait a few moments while the process completes.',
        'Information',
      );
      setTimeout(() => {
        this.spinner.show();
        const data = {
          aadharno: this.guardianAadhaarForm.get('aadhaarNumber')?.value,
          otp: this.guardianAadhaarForm.get('aadhaarOTP')?.value,
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          mailId: this.authService.getResponseValueByKey('fdUserEmail'),
          flag: 1,
          panNo: this.panForm.get('panNumber')?.value
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestdata(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  console.log("AAdhar RESP >>>>>>>>>>>>>>>>>>" + response);
                  this.notify.success(
                    'Aadhaar Verification Successfully Completed',
                    'Success',
                  );
                  this.guardianUpdateFinalRequest('AADHAAR');

                  this.clearGuardianAadhaarResendTimer();

                  this.guardianAadhaarOtpSent = false;
                  this.canResendGuardianAadhaarOtp = false;

                  this.guardianAadhaarForm.disable();
                  this.cdChanges.detectChanges();

                  this.guardianAadhaarSubmitted = true;

                  this.cdChanges.detectChanges();
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Resident authentication failed'
                ) {
                  this.notify.error(
                    'Enter valid Guardian Aadhaar OTP Number',
                    'Error',
                  );

                  // ✅ Clear wrong OTP
                  this.guardianAadhaarForm.get('aadhaarOTP')?.reset();

                  // ✅ Enable resend immediately after wrong OTP
                  this.canResendGuardianAadhaarOtp = true;
                } else if (
                  response.statusCode == '1008' && response.statusMsg == 'Invalid transactionId.'
                ) {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                } else if (response.statusCode == '1008' &&
                  response.statusMsg == 'The given customer Pan and Aadhar name Mismatch'
                ) {
                  this.notify.error(
                    response.statusMsg,
                    'Mismatch',
                  );
                } else if (response.statusCode == '1008') {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                }
              },
              error: (error) => {
                this.spinner.hide();
                console.error('An error occurred in submitAadhaarForm:', error);
              },
            })
        );
      }, 3000);
    }
  }


  guardianBelowOneLaks() {
    this.isSelectedBelowOneLaks = 'Y';
    if (!this.guardianPanSubmitted && !this.guardianAadhaarSubmitted) {
      this.notify.warning(
        'Please complete the Pan and Aadhar verification',
        'KYC Pending',
      );
    }
  }

  guardianDoVkycProcessForJointHolder() {
    if (this.guardianVkycForm.valid) {
      let rowDate = this.guardianPanForm.get('panDOB')?.value
      if (this.guardianPanForm.get('panDOB')?.value) {
        rowDate = this.formatDateToDDMMYYYY(rowDate);
      }

      const vkycPan = this.guardianPanForm.get('panNumber')?.value;
      const vkycDob = this.createFDForm.get('dob')?.value;

      const isEmpty = (v: any) =>
        v == null || (typeof v === 'string' && v.trim() === '');

      if (isEmpty(vkycPan) || isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan)) {
        this.notify.warning('Unable to proceed with VKYC as your PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth is not updated in our records.', 'Info');
        return;
      }


      let data = {
        name: this.guardianPanForm.get('panName')?.value,
        namePrintedInPan: this.guardianPanForm.get('panName')?.value,
        dob: rowDate,
        pan: this.guardianPanForm.get('panNumber')?.value,
        panValidation: 'false',
        email: this.createFDForm.get('fdUserId')?.value,
        mobile: this.guardianVkycForm.get('mobileNumber')?.value,
      };
      this.subscription.add(
        this.apiService
          .doVkycProcessService(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == 1002) {
                this.guardianVkycConfirmationAccepted = true;
                this.vkycInitiated = true;
                const formated = JSON.parse(response.message);
                this.guardianVkycURL = formated.vkycURL;
                this.guardianUpdateFinalRequest('vkyc');
                const width = 500;
                const height = 500;
                const left = Math.floor((window.screen.width - width) / 2);
                const top = Math.floor((window.screen.height - height) / 2);
                const features = `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`;
                window.open(this.guardianVkycURL, '_blank');
              } else {
                this.guardianVkycURL = '';
                this.guardianVkycLinkFetchError = true;
                this.vkycInitiated = false;
                this.guardianVkycConfirmationAccepted = false;
              }
            },
            error: (err) => {
              console.log('An error occurred something went wrong ' + err);
            },
          })
      );
    } else {
      this.guardianVkycForm.markAllAsTouched();
    }
  }


  guardianAddJointHolder() {
    if (this.guardianPanSubmitted && this.guardianAadhaarSubmitted) {
      /* if (this.isMinor && this.guardianPanForm.get('guardianName')?.value == null) {
        this.notify.warning('Please fill the Gaurdian Name');
        this.enableGurdianErrorMsg = true;
        return;
      } */
      if (this.guardianPanForm.get('relationship')?.value == null || this.guardianPanForm.get('relationship')?.value == '') {
        this.notify.warning('Please fill the Relationship');
        this.enableRelationshipErrorMsg = true;
      } else {
        this.finalObjectJointHolderGuardian.relationship = this.guardianPanForm.get('relationship')?.value;
      }
      this.finalObjectJointHolderGuardian.jointGuardMapFlag = this.finalObjectJointHolder.pan;
      this.finalObjectJointHolderGuardian.isPEP = 'No';

      this.finalObjectJointHolder.userId = this.authService.getResponseValueByKey('fdUserEmail');

      this.subscription.add(
        this.apiService.saveHoldGuardDetails(
          this.hybridEncryptor.encrypted(JSON.stringify(this.finalObjectJointHolderGuardian))
        ).subscribe({
          next: (response: any) => {
            console.log('save holder', response);
            if (response.statusCode == '1002') this.getHoldGuardDetails();
            this.showForm = false;
          },
          error: (err: any) => {
            console.error('Error saving holder details:', err);
            this.notify.error('Failed to save holder details.Please try again.', 'Error');
          }
        })
      );
    }
    // Note: The original structure had the closing brace after the subscription and then a stray block.
    // The guardian version preserves the same branching and flow as the original.
  }


  guardianUpdateFinalRequest(where: string) {
    console.log('where', where);
    if (where == 'PAN') {
      this.finalObjectJointHolderGuardian.pan = this.guardianPanForm.get('panNumber')?.value;
      this.finalObjectJointHolderGuardian.dob = this.guardianPanForm.get('panDOB')?.value;
      this.finalObjectJointHolderGuardian.kycBranchCd = this.guardianPanForm.get('kycbranchName')?.value;
      this.finalObjectJointHolderGuardian.name = this.guardianPanForm.get('panName')?.value;
      this.finalObjectJointHolderGuardian.isPEP = this.guardianPanForm.get('isPEP')?.value;
      this.finalObjectJointHolderGuardian.panVerifyFlag = 'Y';
      this.finalObjectJointHolderGuardian.finalObjectJointHolderGuardian = this.panForm.get('panNumber')?.value;;
      this.finalObjectJointHolderGuardian.mobileNo = this.guardianPanForm.get('mobileNumber')?.value;
      this.finalObjectJointHolderGuardian.userId = this.guardianPanForm.get('emailId')?.value;
    } else if (where == 'AADHAAR') {
      this.finalObjectJointHolderGuardian.aadharFlag = 'Y';
      this.finalObjectJointHolderGuardian.aadharNo = this.guardianAadhaarForm.get('aadhaarNumber')?.value;
    } else {

      this.finalObjectJointHolderGuardian.vkycFlag = 0;
      this.finalObjectJointHolderGuardian.vkycUrl = this.guardianVkycURL;
    }
    console.log('req', this.finalObjectJointHolder);
  }

  onDateChange(event: any, controlName: string, formGroup: FormGroup) {
    const selectedDate = new Date(event.target.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Normalize time for comparison

    if (selectedDate >= today) {
      formGroup.get(controlName)?.setValue('');
      // Optionally show a message or trigger a validation error
      // alert('Future or today\'s date is not allowed.');
    }
  }


  resetNomineeModal() {
    this.showNomineeForm = false;
  }


  mask(value: string): string {
    if (!value || value.length < 4) return '...';
    return '...' + value.slice(-4);
  }

  openForm121(): void {
    const modalRef = this.modalService.open(FdForm121Component, {
      centered: true,
      scrollable: true,
      size: 'xl',
      windowClass: 'form121-modal',
    });

    modalRef.result.then(
      (result: { status?: string } | undefined) => {
        if (result?.status === 'SUBMITTED') {
          this.isForm121Submitted = true;
        }
        this.loadExistingForm();
      },
      () => {
        this.loadExistingForm();
      }
    );
  }

  verifyAgentCode() {

    const enteredCode =
      this.createFDForm.get('agentCode')?.value;

    if (!enteredCode || enteredCode === '0') {
      this.notify.warning('Please enter Agent Code');
      return;
    }

    this.selectedAgentCode = enteredCode;

    this.subscription.add(
      this.apiService.verifyAgentCode(enteredCode)
        .subscribe({

          next: (response: any) => {

            if (response?.agentCode && response.agentCode !== '0') {

              this.brokerDetails = response;

              this.pendingAgentCode = response.agentCode;

              this.fetchedAgentCode = response.agentCode;
              this.fetchedAgentName = response.agentName;

              this.agentModalRef = this.modalService.open(
                this.agentConfirmModal,
                {
                  centered: true,
                  backdrop: 'static',
                  keyboard: false,
                  size: 'sm'
                }
              );
            }
            else {
              this.notify.warning('Invalid Agent Code');
              this.createFDForm.get('agentCode')?.reset();
            }
          },

          error: () => {

            this.notify.warning(
              'Agent Code is Invalid',
              'Warning'
            );

            this.createFDForm.get('agentCode')?.reset();
          }
        })
    );
  }

  confirmAgentVerification(modal: any) {

    this.isAgentVerified = true;

    this.createFDForm.patchValue({
      agentCode: this.pendingAgentCode
    });

    modal.close();
  }

  cancelAgentVerification(modal: any) {

    this.isAgentVerified = false;
    this.brokerDetails = null;

    /*     this.createFDForm.patchValue({
          agentCode: ''
        }); */

    this.pendingAgentCode = '';

    modal.dismiss();
  }

  removeAgentDetails(): void {
    this.isAgentVerified = false;
    this.brokerDetails = null;
    this.selectedAgentCode = '0';
    this.pendingAgentCode = '';
    this.fetchedAgentCode = '';
    this.fetchedAgentName = '';
    this.agentModalRef = null;

    this.createFDForm.get('agentCode')?.setValue(0);
  }

  allowNumbersOnly(event: KeyboardEvent) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }

  startAadhaarResendTimer(): void {
    this.clearAadhaarResendTimer();

    this.aadhaarOtpSent = true;
    this.canResendAadhaarOtp = false;
    this.aadhaarResendTimer = 60;

    this.aadhaarResendInterval = setInterval(() => {
      this.aadhaarResendTimer--;

      if (this.aadhaarResendTimer <= 0) {
        this.canResendAadhaarOtp = true;
        clearInterval(this.aadhaarResendInterval);
        this.aadhaarResendInterval = null;
      }

      this.cdChanges.detectChanges();
    }, 1000);
  }

  clearAadhaarResendTimer(): void {
    if (this.aadhaarResendInterval) {
      clearInterval(this.aadhaarResendInterval);
      this.aadhaarResendInterval = null;
    }
  }

  startGuardianAadhaarResendTimer(): void {
    this.clearGuardianAadhaarResendTimer();

    this.guardianAadhaarOtpSent = true;
    this.canResendGuardianAadhaarOtp = false;
    this.guardianAadhaarResendTimer = 60;

    this.guardianAadhaarResendInterval = setInterval(() => {
      this.guardianAadhaarResendTimer--;

      if (this.guardianAadhaarResendTimer <= 0) {
        this.canResendGuardianAadhaarOtp = true;
        clearInterval(this.guardianAadhaarResendInterval);
        this.guardianAadhaarResendInterval = null;
      }
    }, 1000);
  }

  clearGuardianAadhaarResendTimer(): void {
    if (this.guardianAadhaarResendInterval) {
      clearInterval(this.guardianAadhaarResendInterval);
      this.guardianAadhaarResendInterval = null;
    }
  }

  resendAadhaarOTP(): void {
    if (!this.canResendAadhaarOtp) {
      return;
    }

    this.aadhaarForm.get('aadhaarOTP')?.reset();

    // ✅ Pass true for resend flow
    this.sendAadhaarOTP(true);
  }

  guardianResendAadhaarOTP(): void {
    if (!this.canResendGuardianAadhaarOtp) {
      return;
    }

    this.guardianAadhaarForm.get('aadhaarOTP')?.reset();

    this.guardianSendAadhaarOTP();
  }


}

