import { Component, inject, OnInit } from '@angular/core';
import { AuthService } from '../../../../service/auth.service';
import { NgxSpinnerModule } from "ngx-spinner";
import { NgxSpinnerService } from "ngx-spinner"
declare var bootstrap: any; // Needed to access Bootstrap JS
import { Router } from '@angular/router';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { ApiService } from '../../../../service/api.service';
import { FdCacheService } from '../../../../service/fd-cache.service';
import { forkJoin, Observable, Subscription } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FdCalculatorComponent } from '../fd-calculator/fd-calculator.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [NgxSpinnerModule, CommonModule, FormsModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit {
  fdUserId!: string;
  userPan: any;
  cifId: any;
  fdEmptyMessage!: string;
  fdData: any[] = [];
  expandedRows!: any[];
  fdErrorMessage!: string;
  constructor(
    private authService: AuthService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private apiService: ApiService,
    private fdCacheService: FdCacheService,
    private modalService: NgbModal
  ) { }
  public FduserNam!: string;
  public LastloginTime!: string;
  public alertMsg!: String;
  public kycRevDate!: String;
  public kycFlag!: String;
  private hybridEncryptor!: HybridEncryptor;
  subscription: Subscription = new Subscription();

  
trackByFdNo(index: number, item: any) {
  return item?.no ?? index;
}


  ngOnInit(): void {
    this.spinner.show();
    this.FduserNam = this.authService.getResponseValueByKey('fdUserName') || '';
    this.LastloginTime = this.authService.getResponseValueByKey('userLastLogintim') || '';
    this.kycRevDate = this.authService.getResponseValueByKey('kycRevDate') || '';
    this.kycFlag = this.authService.getResponseValueByKey('kycFlag') || '';
    this.hybridEncryptor = new HybridEncryptor();
    setTimeout(() => {
      this.spinner.hide();
    }, 1000)
    this.ShowModel();

    /* start */
    this.fdUserId = this.authService.getResponseValueByKey('fdUserEmail') || '';

    if (this.fdUserId) {

      this.fdCacheService.getUserDetails(this.fdUserId).subscribe({

        next: (response: any) => {

          this.userPan = response['fdUserPan'];

          const fdEntryListReq = {
            cif: "",
            fdUserPan: response['fdUserPan'],
          };

          this.cifId = response['custCifId'];

          // ▶ ONLY ONLINE FD LIST — NO OFFLINE
          this.fetchFdEntryListDetails(fdEntryListReq).subscribe({

            next: (onlineFDs: any[]) => {

              if (!onlineFDs || onlineFDs.length === 0) {
                this.fdEmptyMessage = 'There are no FDs created for this account. Kindly continue to create a new FD.';
                this.fdData = [];
                return;
              }
              console.log(onlineFDs);
              // Transform Online FD Data
              this.fdData = onlineFDs
                .filter(entry =>
                  entry.saveFlag === "01"

                )
                .map((entry, index) => {

                  const principal = parseFloat(entry.amount ?? '0');
                  const rate = parseFloat(entry.intRate ?? '0');
                  const tenureMonths = parseFloat(entry.period ?? '0');
                  const tenureYears = tenureMonths / 12;

                  const interestEarned = principal * (rate / 100) * tenureYears;
                  const calculatedMaturityAmount = principal + interestEarned;

                  let calculatedMaturityDate = '';
                  if (entry.entryDt) {
                    const startDate = new Date(entry.entryDt);
                    startDate.setMonth(startDate.getMonth() + tenureMonths);
                    calculatedMaturityDate = startDate.toLocaleDateString();
                  }

                  return {
                    no: index + 1,
                    entryId: entry?.entryId,
                    cifCd: entry?.cifCd,
                    branchCd: entry?.branchCd,
                    schemeCd: entry?.schemeCd,
                    period: entry?.period,
                    catSubTypCd: entry?.catSubTypCd,
                    intRate: entry?.intRate,
                    amount: entry?.amount,
                    empCode: entry?.empCode,
                    taxExemptFlag: entry?.taxExemptFlag,
                    mopCd: entry?.mopCd,
                    neftNum: entry?.neftNum,
                    neftDt: entry?.neftDt,

                    wudUserId: this.authService.getResponseValueByKey("fdUserId"),
                    autoRenewFlag: entry?.autoRenewFlag,
                    invCatHoldTypCd: entry?.invCatHoldTypCd,
                    nominees: entry?.nomiees,
                    holdDetails: entry?.holdDetails,
                    /* depositorType: entry?., */
                    ...entry
                  };
                });

              this.expandedRows = new Array(this.fdData.length).fill(false);
              this.fdErrorMessage = '';
              this.fdEmptyMessage = '';
            },

            error: (err) => {
              console.error('Error fetching online FD details:', err);
              this.fdErrorMessage = '⚠️ An unexpected error occurred. Please try again later.';
              this.fdData = [];
            }

          });

          // Pre-close Message Listener
          this.apiService.currentPreCloseMessage$.subscribe(msg => {
            if (msg === 'Closed') {
              window.location.reload();
            }
          });
        },

        error: (err) => {
          console.error('Error fetching User details:', err);
        }

      });
    }
    /* End */


    console.log(this.fdData);

  }

  viewDetails(fd: any) {

  }

  openFdCalculator() {
    const modalRef = this.modalService.open(FdCalculatorComponent, {
      centered: true,
      size: 'md',
      scrollable: true,
      backdropClass: 'fd-calc-backdrop',
    });
    modalRef.componentInstance.inlineMode = true;
  }




  proceed(fd: any) {

    // navigate with param
    this.router.navigate(['/dashboard/manage', fd.entryId]);
  }





  remind(fd: any) {

  }



  fetchFdEntryListDetails(req: any): Observable<any[]> {
    return this.apiService.getFdEntryListDetails(
      this.hybridEncryptor.encrypted(JSON.stringify(req))
    );
  }


  ShowModel() {
    const modalElement = document.getElementById('reKycModel');
    const modal = new bootstrap.Modal(modalElement);
    if (this.kycFlag == 'Y') {
      modal.show();
    }
  }

  closeModel() {
    const modalElement = document.getElementById('reKycModel');
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
      modalInstance.hide();
    }

  }
  initiateKYC() {
    this.resetVKycFlagDirect();


  }

  resetVKycFlagDirect(): void {
    const data = {
      wudUserID: this.authService.getResponseValueByKey('fdUserId'),
    };
    const encryptedPayload = this.hybridEncryptor.encrypted(
      JSON.stringify(data)
    );
    this.subscription.add(
      this.apiService.resetVKycFlagDirect(encryptedPayload).subscribe({
        next: (response: any) => {
          console.log("Reseted VKYC Sucessfully");
          this.router.navigate(['/kycVerification']).
            then(() => {
              window.location.reload();
            });
        },
        error: (err) => {
          console.error('Error fetching bank details:', err);
        },
      })
    );
  }

}


