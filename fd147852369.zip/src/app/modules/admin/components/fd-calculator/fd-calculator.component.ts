import { Component, inject, Input, OnDestroy, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../../service/auth.service';
import { FdCacheService } from '../../../../service/fd-cache.service';

@Component({
  selector: 'app-fd-calculator',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './fd-calculator.component.html',
  styleUrl: './fd-calculator.component.scss'
})
export class FdCalculatorComponent implements OnInit, OnDestroy {

  amount: number = 100000;
  schemeCd: string = 'QUARTERLY COMPOUNDING';
  tenureType: string = '1';
  customYear: number = 1;
  customMonth: number = 0;

  schemeList: string[] = [];
  tenureOptions = [
    { key: '1', label: '1 Yr' },
    { key: '2', label: '2 Yr' },
    { key: '3', label: '3 Yr' },
    { key: '5', label: '5 Yr' },
  ];
  amountPresets = [100000, 200000, 300000, 400000, 500000];
  customYears = [1, 2, 3, 4, 5];
  customMonths = Array.from({ length: 12 }, (_, i) => i);

  categoryLabel = 'GENERAL';
  custCat = 'GENERAL';
  categoryBadgeClass = 'cat-general';

  interestRate = 0;
  interestEarned = 0;
  maturityAmount = 0;
  tenureLabel = '';
  nonCumulativeQuarterlyRate = 0;
  nonCumulativeQuarterlyPayout = 0;
  nonCumulativeYearlyRate = 0;
  nonCumulativeYearlyPayout = 0;

  displayMaturity = 0;
  displayInterest = 0;
  displayQuarterlyPayout = 0;
  displayYearlyPayout = 0;

  loading = false;
  calcError: string | null = null;
  showResult = false;
  pulse = false;
  schemesLoading = false;
  schemesError: string | null = null;
  categoryLoading = false;

  private subscription = new Subscription();
  private rafId: number | null = null;
  private debounceId: any = null;
  private pendingRecalc = false;
  private calculationVersion = 0;
  @Input() inlineMode = false;

  categoryOptions = [
    'GENERAL',
    'STAFF',
    'SENIOR CITIZEN',
    'STAFF + SENIOR CITIZEN'
  ];

  activeModal = inject(NgbActiveModal, {
    optional: true
  });

  constructor(

    private authService: AuthService,
    private fdCacheService: FdCacheService
  ) { }

  ngOnInit(): void {
    this.loadSchemes();

    if (this.inlineMode) {
      this.applyCategory('GENERAL');
    } else {
      this.resolveCategory();
    }

    this.calculate();
  }

  onCategoryChange(category: string): void {
    this.applyCategory(category);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    if (this.debounceId) {
      clearTimeout(this.debounceId);
    }
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
    }
  }

  fmtVal(value: number, decimals: number): string {
    const fixed = Number(value || 0).toFixed(decimals);
    const [intPart, decPart] = fixed.split('.');
    const grouped = Number(intPart).toLocaleString('en-IN');
    return decPart ? `${grouped}.${decPart}` : grouped;
  }

  presetLabel(preset: number): string {
    const lakhs = preset / 100000;
    return Number.isInteger(lakhs) ? `${lakhs}L` : `${lakhs.toFixed(2)}L`;
  }

  onAmountInput(): void {
    this.calcError = null;
    if (this.debounceId) {
      clearTimeout(this.debounceId);
    }
    this.debounceId = setTimeout(() => this.calculate(), 400);
  }

  setAmountPreset(val: number): void {
    this.amount = val;
    this.calcError = null;
    this.calculate();
  }

  setTenure(key: string): void {
    this.tenureType = key;
    this.calculate();
  }

  onCustomTenureChange(): void {
    this.calculate();
  }

  onSchemeChange(): void {
    this.calculate();
  }

  calculate(): void {
    this.calcError = null;
    const amt = Number(this.amount) || 0;
    const calculationVersion = ++this.calculationVersion;
    if (amt < 10000) {
      this.calcError = 'Amount should be at least ₹10,000.';
      this.clearResults();
      this.loading = false;
      this.pendingRecalc = false;
      return;
    }

    if (amt % 1000 !== 0) {
      this.calcError = 'Amount should be in multiples of ₹1,000.';
      this.clearResults();
      this.loading = false;
      this.pendingRecalc = false;
      return;
    }

    const period = this.periodInMonths();
    if (period < 12 || period > 60) {
      this.calcError = 'Tenure should be between 12 and 60 months.';
      this.loading = false;
      return;
    }

    if (this.loading) {
      this.pendingRecalc = true;
      return;
    }

    this.loading = true;
    this.subscription.add(
      this.fdCacheService.getInterestRate({
        fdScheme: this.schemeCd,
        fdAmount: amt,
        custCat: this.custCat,
        fdPeriod: period,
      }).subscribe({
        next: (rateStr: string) => {
          this.loading = false;

          if (calculationVersion !== this.calculationVersion) {
            if (this.pendingRecalc) {
              this.pendingRecalc = false;
              this.calculate();
            }
            return;
          }

          const rate = parseFloat(rateStr) || 0;
          this.interestRate = rate;
          this.computeReturns(amt, period, rate);
          this.showResult = true;
          if (this.pendingRecalc) {
            this.pendingRecalc = false;
            this.calculate();
          }
        },
        error: () => {
          this.loading = false;
          this.calcError = 'Could not fetch interest rate. Please try again.';
        },
      })
    );
  }

  private clearResults(): void {
    this.showResult = false;
    this.interestRate = 0;
    this.interestEarned = 0;
    this.maturityAmount = 0;
    this.tenureLabel = '';
    this.nonCumulativeQuarterlyRate = 0;
    this.nonCumulativeQuarterlyPayout = 0;
    this.nonCumulativeYearlyRate = 0;
    this.nonCumulativeYearlyPayout = 0;
    this.displayMaturity = 0;
    this.displayInterest = 0;
    this.displayQuarterlyPayout = 0;
    this.displayYearlyPayout = 0;
    this.pulse = false;
  }

  private periodInMonths(): number {
    if (this.tenureType === 'custom') {
      return Number(this.customYear) * 12 + Number(this.customMonth);
    }
    return Number(this.tenureType) * 12;
  }

  private computeReturns(principal: number, months: number, baseRate: number): void {
    this.nonCumulativeQuarterlyRate = baseRate - 0.10;
    this.nonCumulativeYearlyRate = baseRate;

    const years = months / 12;
    let interest = 0;
    let maturityRaw = 0;

    if (months > 0 && principal > 0) {
      if (this.schemeCd === 'QUARTERLY COMPOUNDING') {
        const r = baseRate / 100;
        const n = 4;
        const t = months / 12;
        const amount = principal * Math.pow(1 + r / n, n * t);
        maturityRaw = amount;
        interest = Math.round(amount - principal);
      } else if (this.schemeCd === 'QCAP') {
        let pr = principal;
        const quarterlyRate = baseRate / 100 / 4;
        const totalMonths = months;
        let firstYearInterest = 0;
        let yearlyInterest = 0;
        for (let q = 1; q <= 4; q++) {
          if (q * 3 <= totalMonths) {
            const qi = pr * quarterlyRate;
            yearlyInterest += qi;
            pr += qi;
          }
        }
        firstYearInterest = yearlyInterest;
        interest = firstYearInterest;
        maturityRaw = principal;
      } else {
        interest = principal * (baseRate / 100) * years;
        maturityRaw = principal + interest;
      }
    }

    this.interestEarned = Math.round(interest);
    this.maturityAmount = Math.round(maturityRaw);
    this.nonCumulativeQuarterlyPayout =
      principal * (this.nonCumulativeQuarterlyRate / 100) * (1 / 4);
    this.nonCumulativeYearlyPayout =
      principal * (this.nonCumulativeYearlyRate / 100);
    this.tenureLabel = this.buildTenureLabel(months);

    this.pulse = false;
    setTimeout(() => {
      this.pulse = true;
    }, 20);

    this.animateResult();
  }

  private buildTenureLabel(months: number): string {
    const y = Math.floor(months / 12);
    const m = months % 12;
    if (y > 0 && m === 0) return `${y} Year${y > 1 ? 's' : ''}`;
    if (y > 0) return `${y} Year${y > 1 ? 's' : ''} ${m} Month${m > 1 ? 's' : ''}`;
    return `${m} Month${m > 1 ? 's' : ''}`;
  }

  private animateResult(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
    }
    const from = {
      maturity: this.displayMaturity,
      interest: this.displayInterest,
      quarterly: this.displayQuarterlyPayout,
      yearly: this.displayYearlyPayout,
    };
    const to = {
      maturity: this.maturityAmount,
      interest: this.interestEarned,
      quarterly: this.nonCumulativeQuarterlyPayout,
      yearly: this.nonCumulativeYearlyPayout,
    };
    const duration = 600;
    const start = performance.now();
    const ease = (t: number) => 1 - Math.pow(1 - t, 3);

    const step = (now: number) => {
      const elapsed = Math.min(now - start, duration);
      const t = ease(elapsed / duration);
      this.displayMaturity = from.maturity + (to.maturity - from.maturity) * t;
      this.displayInterest = from.interest + (to.interest - from.interest) * t;
      this.displayQuarterlyPayout =
        from.quarterly + (to.quarterly - from.quarterly) * t;
      this.displayYearlyPayout = from.yearly + (to.yearly - from.yearly) * t;
      if (elapsed < duration) {
        this.rafId = requestAnimationFrame(step);
      } else {
        this.rafId = null;
      }
    };
    this.rafId = requestAnimationFrame(step);
  }

  private loadSchemes(): void {
    this.schemesLoading = true;
    this.schemesError = null;
    this.fdCacheService.getSchemeList().subscribe({
      next: (res: any) => {
        this.schemesLoading = false;
        const list: string[] = res?.schemeList || [];
        this.schemeList = list;
        if (list.length && list.indexOf(this.schemeCd) === -1) {
          this.schemeCd = list[0];
          this.calculate();
        }
      },
      error: () => {
        this.schemesLoading = false;
        this.schemesError = 'Could not load schemes. Please try again.';
        this.schemeList = [];
      },
    });
  }

  retrySchemes(): void {
    this.loadSchemes();
  }

  private resolveCategory(): void {
    const fdUserId =
      this.authService.getResponseValueByKey('fdUserEmail') || '';
    this.categoryLoading = true;
    this.fdCacheService.getUserFullDetails(fdUserId).subscribe({
      next: (res: any) => {
        this.categoryLoading = false;
        if (!res) {
          this.applyCategory('GENERAL');
          return;
        }
        const empStatus = res.empStatus === 'Y';
        const dobStr = (typeof res.dob === 'string' ? res.dob : String(res.dob ?? ''))
          .trim();
        const isDobMissing = !dobStr || dobStr.toLowerCase() === 'null';
        let cat: string;
        if (isDobMissing) {
          cat = empStatus ? 'STAFF' : 'GENERAL';
        } else {
          const isSenior = this.calculateAgeFromDob(dobStr) >= 60;
          if (empStatus) {
            cat = isSenior ? 'STAFF + SENIOR CITIZEN' : 'STAFF';
          } else {
            cat = isSenior ? 'SENIOR CITIZEN' : 'GENERAL';
          }
        }
        this.applyCategory(cat);
      },
      error: () => {
        this.categoryLoading = false;
        this.applyCategory('GENERAL');
      },
    });
  }

  private calculateAgeFromDob(dobStr: string): number {
    const [day, month, year] = dobStr.split(/[/\-]/).map(Number);
    if (!day || !month || !year) return 0;
    const dob = new Date(year, month - 1, day);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
      age--;
    }
    return age;
  }

  private applyCategory(cat: string): void {
    if (this.custCat !== cat) {
      this.custCat = cat;
      this.categoryLabel = cat;
      this.categoryBadgeClass = 'cat-' + cat.toLowerCase().replace(/[^a-z]+/g, '-');
      this.calculate();
    }
  }

  closeCalculator(): void {

    this.activeModal?.dismiss();
  }
}
