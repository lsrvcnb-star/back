import { Component, OnInit, AfterViewInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { ApiService } from '../../../../service/api.service';
import { Subscription } from 'rxjs';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { AuthService } from '../../../../service/auth.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { FdCacheService } from '../../../../service/fd-cache.service';

declare var bootstrap: any;

export interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
  showSubMenu?: boolean;
  badgeCount?: Number;
  badgeEnable?: string;
  openInNewTab?: boolean;
  externalUrl?: string;
  tabName?: string;
  


  

}

export const ROUTES: RouteInfo[] = [
  { path: '/dashboard/home', title: 'Home', icon: 'fa fa-home', class: '' },
  {
    path: '/dashboard/accountDetails',
    title: 'Personal Details',
    icon: 'fa fa-user-plus',
    class: '',
    badgeCount: 0,
  },
  {
    path: '/dashboard/createFD',
    title: 'Create Fixed Deposit',
    icon: 'fa fa-pencil',
    class: '',
  },
  {
    path: '/dashboard/fdApplication',
    title: 'Manage Fixed Deposit',
    icon: 'fa fa-database',
    class: '',
    showSubMenu: false,
  },

    {
    path: '/kycVerification',
    title: 'Manage KYC',
    icon: 'fa fa-address-card',
    class: '',
    showSubMenu: false,
    badgeEnable:'kyc',
  },

  {
    path: '/dashboard/enquiry',
    title: 'Customer Inquiries',
    icon: 'fa fa-comments',
    class: '',
  },

  {
    path: '/dashboard/fdForm',
    title: 'Download Forms',
    icon: 'fa fa-arrow-down',
    class: '',
    showSubMenu: false,
  },
  {
    path: null as any,
    title: 'User Guide',
    icon: 'fa fa-book',
    class: '',
    externalUrl: '/assets/FDUserGuide.pdf',     // OR 'https://...'
    tabName: 'USER_GUIDE_TAB',                // fixed name to reuse tab
    openInNewTab: true
  },
  {
    path: null as any,
    title: 'Refund Policy',
    icon: 'fa  fa-address-book-o',
    class: '',
    externalUrl: '/assets/Refund-and-cancellation-policy.pdf',     // OR 'https://...'
    tabName: 'REFUND_POLICY_TAB',                // fixed name to reuse tab
    openInNewTab: true
  }


  /* { path: '/dashbord/preClosureFd', title: 'Pre-closure FD', icon: 'fa fa-file', class: '' }, */
];

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
})
export class SidebarComponent implements OnInit, AfterViewInit {
  public menuItems!: any[];
  subscription: Subscription = new Subscription();
  public hybridEncryptor!: HybridEncryptor;
  branchName: any;
  bank_NAME: any;
  BANKACC_NO: any;
  selectedSubmenu: string = '';
  BANKIFSC_CODE: any;
  fdUserId: string = '';
  isShowDownloadForm: boolean = false;
  fdUserPan:any;
  kycFlag?:String;
  kycRevDate?: string;
  reKycpopover: boolean =false;
  
activeMenuTitle: string | null = null;
   userGuidePdfUrl = '/assets/FDUserGuide.pdf';
   userGuidePdfSafeUrl!: SafeResourceUrl;
  private userGuideWindow: Window | null = null;

  refundPolicyPdfUrl = '/assets/Refund-and-cancellation-policy.pdf';
  refundPolicyPdfSafeUrl!: SafeResourceUrl;
  private refundPolicyWindow: Window | null = null;
  
  constructor(
    private apiService: ApiService,
    private cookieService: CookieService,
    private authService: AuthService,
    private sanitizer: DomSanitizer,
    private fdCacheService: FdCacheService
  ) {

// iframe requires SafeResourceUrl
    this.userGuidePdfSafeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
      this.userGuidePdfUrl
    );

     this.refundPolicyPdfSafeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
      this.refundPolicyPdfUrl
    );
  }

  // personal details
  unfilledCount: number = 0;

  ngOnInit() {
    this.hybridEncryptor = new HybridEncryptor();
    this.menuItems = ROUTES.filter((menuItem) => menuItem);
    this.getBankDetails();
   
  this.kycRevDate = this.authService.getResponseValueByKey('kycRevDate') || '';
  this.kycFlag = this.authService.getResponseValueByKey('kycFlag') || '';
  if(this.kycFlag =='Y'){
   this.reKycpopover=true;
  }


   // this.getlistOFDs();

    this.apiService.unfilledFieldsCount$.subscribe((count) => {
      const personalDetailsItem = this.menuItems.find(
        (item) => item.path === '/dashboard/accountDetails'
      );
      if (personalDetailsItem) {
        personalDetailsItem.badgeCount = count;
      }
    });
  }

 
  formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }


  ngAfterViewInit(): void {
    setTimeout(() => {
      const popoverTriggerList = Array.from(
        document.querySelectorAll('[data-bs-toggle="popover"]')
      );
      popoverTriggerList.map((popoverTriggerEl) => {
        new bootstrap.Popover(popoverTriggerEl);
      });
    }, 0);
  }
  getBankDetails(): void {
    this.branchName = this.authService.getResponseValueByKey('kycBranchName');
    let data = {
      kycBranchName: this.branchName,
    };
    this.subscription.add(
      this.apiService
        .getBankDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response) {
              this.bank_NAME = response.split(',')[0];
              this.BANKACC_NO = response.split(',')[1];
              this.BANKIFSC_CODE = response.split(',')[2];
              if (this.cookieService.get("remitterAcc") !== this.BANKACC_NO) {
                this.cookieService.set('remitterAcc', this.BANKACC_NO, {
                  path: '/',
                  secure: true,
                  sameSite: 'Strict',
                  expires: new Date(new Date().getTime() + 20 * 60 * 1000),
                });
              }
            }
          },
        })
    );
  }












  getlistOFDs() {
    this.fdUserId = this.authService.getResponseValueByKey('fdUserEmail') || '';
    if (this.fdUserId) {
      this.fdCacheService
        .getUserDetails(this.fdUserId)
        .subscribe({
          next: (response: any) => {
            let fdEntryListReq = {
              cif: response['custCifId'],
              fdUserPan: response['fdUserPan'],
              // fdUserPan: 'CJSPA3510J',
            };
            this.fetchFdEntryListDetails(fdEntryListReq);
          },
          error: (err) => {
            console.error('Error fetching User details:', err);
          },
        });
    }
  }

  fetchFdEntryListDetails(req: any): void {
    this.apiService
      .getFdEntryListDetails(
        this.hybridEncryptor.encrypted(JSON.stringify(req))
      )
      .subscribe({

        next: (response: any[]) => {
          // Check if any object in the response has a valid entryId
         // this.isShowDownloadForm = response?.some(item => item.fdappStatus === 'LIVE FD');

          // Filter menu items based on the flag
          /* this.menuItems = ROUTES.filter(item => {
            if (item.title === 'Download Forms') {
              return this.isShowDownloadForm;
            }
            return true;
          }); */
        },

        error: (err) => {
          console.error('Error fetching FD details:', err);
        },
      });
  }

  // toggleSubMenu(menuItem: any): void {
  //   if (menuItem.title === 'Manage Fixed Deposit' || menuItem.title === 'Manage KYC' ) {
  //     menuItem.showSubMenu = true;
  //     this.selectedSubmenu = 'statement';
  //   } else {
  //     this.selectedSubmenu = '';
  //   }
  // }
handleMenuClick(menuItem: any, event?: MouseEvent) {
  // Prevent default anchor behavior
  event?.preventDefault();

  // ✅ User Guide open in new tab and reuse it
  if (menuItem.openInNewTab && menuItem.externalUrl) {
    if (menuItem.tabName == 'USER_GUIDE_TAB') {
      
      this.openOrFocusTab(menuItem.externalUrl, menuItem.tabName || 'USER_GUIDE_TAB');
      return;
    } else if (menuItem.tabName == 'REFUND_POLICY_TAB') {
      
      this.openOrFocusTabForFundPolicy(menuItem.externalUrl, menuItem.tabName || 'REFUND_POLICY_TAB');
      return;
    }

  }

  // Otherwise existing behavior (submenu etc.)
  this.toggleSubMenu(menuItem);
}

openOrFocusTab(url: string, tabName: string) {
  if (this.userGuideWindow && !this.userGuideWindow.closed) {
    // ✅ JUST focus — DO NOT set location.href again
    this.userGuideWindow.focus();
    return;
  }

  // First time: open PDF
  this.userGuideWindow = window.open(url, tabName);
}

openOrFocusTabForFundPolicy(url: string, tabName: string) {
  if (this.refundPolicyWindow && !this.refundPolicyWindow.closed) {
    // ✅ JUST focus — DO NOT set location.href again
    this.refundPolicyWindow.focus();
    return;
  }

  // First time: open PDF
  this.refundPolicyWindow = window.open(url, tabName);
}


  
toggleSubMenu(menuItem: any): void {
  this.menuItems.forEach(item => {
    if (item.title === 'Manage Fixed Deposit' || item.title === 'Manage KYC') {
      item.showSubMenu = false;
       item.class = ''; 
    }
  });

  menuItem.showSubMenu = true;
  this.selectedSubmenu = '';
}







  updateSubMemu(str: string) {
    this.selectedSubmenu = str;
  }
}
