import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { Subscription } from 'rxjs';
import { ApiService } from '../../../../service/api.service';
import {
  FormGroup,
  FormsModule,
  FormControl,
  Validators,
  FormBuilder,
  ReactiveFormsModule,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import {
  ActivatedRoute,
  Router,
  RouterModule,
  RouterOutlet,
} from '@angular/router';
import { CustomValidator } from '../../Constom/validator';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';

interface fdData {
  strDepositNum: string;
  strDepositDt: string;
  intPeriod: number;
  strIntRate: number;
  strDepositAmount: number;
  strNewMaturityAmount: number;
  strMaturityDt: string;
  strSchemeName: string;
  strDepositType: string;
  strOldMaturityAmount: string;
  strpayeeName: string;
  strBankDetails: string;
  strAccDetails: String;
  strifsc: string;
  strReasonforClosure: string;
  strPreClosureRemarks: string;
  strClaimReciptDate: string;
  strPreclosureAmt: string;
  fdUserId: String;
}
@Component({
  selector: 'app-pre-closure-form',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './pre-closure-form.component.html',
  styleUrl: './pre-closure-form.component.scss',
})
export class PreClosureFormComponent implements OnInit {
  [x: string]: any;
  preclosureReaseon!: [];
  savePreClosureForm!: FormGroup;
  fdData: any;
  strFdrNo: String;
  customValidator: CustomValidator = new CustomValidator();
  public hybridEncryptor!: HybridEncryptor;
  showModal: boolean = false;
	PrecloseModelmsg!:String;
  @Input() fdrNumber: any;
  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private CookieService: CookieService,
    private router: Router,
    private route: ActivatedRoute,
  ) {
    this.strFdrNo = this.route.snapshot.paramMap.get('strFdrNo')!;
  }
  fdEntryResponse: any = {};
  subscription: Subscription = new Subscription();
  todayDate = new Date().toISOString().split('T')[0];
  minDate = '1900-01-01';
  ngOnInit(): void {
    this.savePreClosureForm = this.fb.group({
      strReasonforClosure: '',
      //  [ [ ' ' ,Validators.required]],
      strPreClosureRemarks: '',
      strClaimReciptDate: '',
      strDepositNum: [[Validators.required]],
      strDepositDt: [[Validators.required]],
      strDepositAmount: [[Validators.required]],
      strDepositType: [[Validators.required]],
      strSchemeName: [[Validators.required]],
      intPeriod: [[Validators.required]],
      strIntRate: [[Validators.required]],
      strMaturityDt: [[Validators.required]],
      strOldMaturityAmount: [[Validators.required]],
      strNewMaturityAmount: [[Validators.required]],
      strpayeeName: [[Validators.required]],
      strBankDetails: [[Validators.required]],
      strAccDetails: [[Validators.required]],
      strifsc: [[Validators.required]],
    });
    this.hybridEncryptor = new HybridEncryptor();
    this.getPreCloseReasonFd();
    this.getPreClosureDetails(this.strFdrNo);
  }

  get strReasonforClosure() {
    return this.savePreClosureForm.get('strReasonforClosure');
  }

  get strPreClosureRemarks() {
    return this.savePreClosureForm.get('strPreClosureRemarks');
  }

  get strClaimReciptDate() {
    return this.savePreClosureForm.get('strClaimReciptDate');
  }

  CharacterSpacevalidator(event: any) {
    this.customValidator.CharacterSpaceValidator(event);
  }

  get form() {
    return this.savePreClosureForm.value;
  }
  getPreCloseReasonFd(): void {
    this.subscription.add(
      this.apiService.getPreCloseReason().subscribe({
        next: (response: any) => {
          if (response) {
            this.preclosureReaseon = response;
          }
        },
      })
    );
  }




  getPreClosureDetails(fdrNumber: String): void {
    const data = {
      strFdrNo: this.fdrNumber,
    };
    this.subscription.add(
      this.apiService
        .getPreClosureDetails(
          this.hybridEncryptor.encrypted(JSON.stringify(data))
        )
        .subscribe({
          next: (response: any) => {
            if (response) {
              this.fdData = response;
              this.savePreClosureForm.setValue(response);
            }
          },
        })
    );
  }
  
  fdApplications: fdData = this.fdEntryResponse;
  submitPreClose() {
    const rawFormData = this.savePreClosureForm.value;
    const encrypted = this.hybridEncryptor.encrypted(
      JSON.stringify(rawFormData)
    );
    if (encrypted !== null) {
      this.subscription.add(
        this.apiService.savePreClosure(encrypted).subscribe({
          next: (response: any) => {
            if (response) {
              if (response.statusCode == '1008') {
                // alert(response.statusMsg);
                         this.PrecloseModelmsg= 'We were unable to process your FD preclosure request. Please try again'
                         this.showModal=true;
              } else if (response.statusCode == '1002') {
                    this.PrecloseModelmsg= 'Your request to preclose the Fixed Deposit has been fulfilled successfully.'
                   this.showModal=true;
              }
            }
          },
        })
    );
  }
  }

  showAlert(
    severity: 'success' | 'info' | 'warn' | 'error',
    summary: string,
    detail: string
  ) {
    console.log(`Alert: ${severity} - ${summary}: ${detail}`);
  }

   closeModal(): void {
    this.showModal = false;
    this.apiService.changeMessage('Closed');
  }
 
}
