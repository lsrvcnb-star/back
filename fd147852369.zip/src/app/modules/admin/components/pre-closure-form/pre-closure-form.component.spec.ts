import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreClosureFormComponent } from './pre-closure-form.component';

describe('PreClosureFormComponent', () => {
  let component: PreClosureFormComponent;
  let fixture: ComponentFixture<PreClosureFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreClosureFormComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreClosureFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
