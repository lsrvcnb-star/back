import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { NotificationService } from '../../../../service/notification.service';
import { ApiService } from '../../../../service/api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subscription, Subject, exhaustMap } from 'rxjs';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { Router } from '@angular/router';
import { SanitizeInputDirective } from '../../../../sanitize-input.directive';

@Component({
  selector: 'app-enquiry',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SanitizeInputDirective],
  templateUrl: './enquiry.component.html',
  styleUrl: './enquiry.component.scss',
})
export class EnquiryComponent implements OnInit, OnDestroy {

  private readonly strictEmailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  enquiryForm!: FormGroup;
  submitted = false;
  private submitClick$ = new Subject<void>();
  private subscription: Subscription = new Subscription();
  public hybridEncryptor!: HybridEncryptor;
  @ViewChild('confirmModal') confirmModal!: TemplateRef<any>;
  private confirmModalRef: NgbModalRef | null = null;
  inquiryOptionData: any;

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private notify: NotificationService,
    private spinner: NgxSpinnerService,
    private modalService: NgbModal,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.setupSubmitHandler();
    this.inquiryOptions();
     this.hybridEncryptor = new HybridEncryptor();
  }

  private initForm(): void {
    this.enquiryForm = this.fb.group({
      type: [1, Validators.required],
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      phone: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      email: ['', [
        Validators.required,
        Validators.email,
        Validators.pattern(/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/)
      ]],
      inquiryDetails: ['', [Validators.required, Validators.maxLength(200)]],
    });
  }

  private setupSubmitHandler(): void {
    this.subscription.add(
      this.submitClick$.pipe(
        exhaustMap(() => {
          if (this.enquiryForm.invalid) {
            this.enquiryForm.markAllAsTouched();
            return [];
          }
          this.spinner.show();
          const payload = this.enquiryForm.value;
          const encryptedEnquiryData = this.hybridEncryptor.encrypted(JSON.stringify(payload));
          return this.apiService.submitEnquiry(encryptedEnquiryData);
        })
      ).subscribe({
        next: (response: any) => {
          this.spinner.hide();
          if (response) {
            this.openSuccessPopup(response.message || 'Enquiry submitted successfully.');
          }
        },
        error: () => {
          this.spinner.hide();
          this.notify.error('Something went wrong. Please try again later.', 'Error');
        },
      })
    );
  }

  onSubmit(): void {
    this.validateInquiryEmail();
    this.submitClick$.next();
  }

  validateInquiryEmail(): void {
    const emailControl = this.enquiryForm.get('email');
    const email = String(emailControl?.value ?? '').trim();

    if (!email) {
      emailControl?.updateValueAndValidity({ emitEvent: false });
      return;
    }

    const errors = { ...(emailControl?.errors ?? {}) };
    if (!this.strictEmailPattern.test(email)) {
      errors['strictEmail'] = true;
    } else {
      delete errors['strictEmail'];
    }

    emailControl?.setErrors(Object.keys(errors).length ? errors : null);
  }

  private openSuccessPopup(message: string): void {
    this.confirmModalRef = this.modalService.open(this.confirmModal, {
      centered: true,
      backdrop: 'static',
      keyboard: false,
    });
    this.confirmModalRef.result.finally(() => {
      this.confirmModalRef = null;
    });
  }

  onOkClick(): void {
    this.confirmModalRef?.close();
    this.enquiryForm.reset({ type: '1' });
    this.submitted = false;
  }

  get f() {
    return this.enquiryForm.controls;
  }

  isEmailFormatInvalid(): boolean {
    const email = String(this.enquiryForm.get('email')?.value ?? '').trim();
    return email.length > 0 && !this.strictEmailPattern.test(email);
  }

  restrictDetailsInput(event: Event): void {
    const input = event.target as HTMLTextAreaElement;
    if (input.value.length > 200) {
      input.value = input.value.substring(0, 200);
      this.enquiryForm.get('inquiryDetails')?.setValue(input.value);
    }
  }


  private inquiryOptions(){
    this.subscription.add(
      this.apiService.inquiryOptions().subscribe({
        next: (res: any) => {
          this.inquiryOptionData = res;
          console.log(this.inquiryOptionData)
        },
        error: (err: any) => {
          this.notify.error("Error while loading the Inquire Types")
        }
      })
    )
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }


  isEnquiryRoute(): boolean {
    return this.router.url !== '/enquiry';
  }

}
