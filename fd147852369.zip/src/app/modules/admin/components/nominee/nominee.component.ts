import { CommonModule, DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ApiService } from '../../../../service/api.service';
import { catchError, of, Subscription, switchMap } from 'rxjs';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { CookieService } from 'ngx-cookie-service';
import { NotificationService } from '../../../../service/notification.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from '../../../../service/auth.service';
import { SanitizeInputDirective } from '../../../../sanitize-input.directive';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FdCacheService } from '../../../../service/fd-cache.service';



@Component({
  selector: 'app-nominee',
  templateUrl: './nominee.component.html',
  styleUrls: ['./nominee.component.scss'],
  providers: [NotificationService],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
    SanitizeInputDirective,
    FormsModule
  ]
})

export class NomineeComponent implements OnInit {
  nomineeForm: FormGroup;
  nominees: any[] = [];
  displayModal: boolean = false;
  editIndex: number | null = null;
  subscription: Subscription = new Subscription();
  FDrNo: any;
  hybridEncryptor = new HybridEncryptor();
  newFdRegId: any;
  loading: boolean = false;
  emptyMessage: string = ''
  today: Date = new Date();
  activeTabIndex: number = 0;

  panForm = new FormGroup({
    panName: new FormControl('', Validators.required),
    panNumber: new FormControl('', [Validators.required, Validators.pattern(/[A-Z]{5}[0-9]{4}[A-Z]{1}/)]),
    panDOB: new FormControl('', Validators.required),
    kycbranchName: new FormControl('', Validators.required),
    isPEP: new FormControl('No',),
    relationship: new FormControl('', Validators.required),
    mobileNumber: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]),
    emailId: new FormControl([Validators.required, Validators.email])
    /*  guardianName: new FormControl({ value: null, disabled: true }) */

  });

  aadhaarForm = new FormGroup({
    aadhaarNumber: new FormControl('', [Validators.required, Validators.pattern(/^\d{12}$/)]),
    aadhaarOTP: new FormControl('')
  });

  aadhaarSubmitted: boolean = false;
  panSubmitted: boolean = false;
  sendOTPbtn: boolean = false;
  enableOtpSendmsg: boolean = false;
  finalObjectJointHolder: any = {};
  isMinor: boolean = false;
  enableGurdianErrorMsg: boolean = false;
  enableRelationshipErrorMsg: boolean = false;
  saveTempJointHolderData: any;
  vkycConfirmationAccepted: boolean = false;
  vkycLinkFetchError: boolean = false;
  vkycInitiated: boolean = false;
  isSelectedBelowOneLaks!: string;
  isVkycCompleted: boolean = false;
  proceedWithoutVkycChecked: boolean = false;
  vkycURL: string = '';
  vkycForm!: FormGroup;
  selectedHolder: any = null;
  showVkycPopup: boolean = false;
  @ViewChild('jointModal') jointModal!: TemplateRef<any>;

  jointHolders: any[] = [];
  guardianList: any = [];
  holder: any;
  maxDate: string;
  enableGuardianSection: boolean = false;
  guardianPanForm!: FormGroup;
  guardianAadhaarForm!: FormGroup
  guardianVkycForm!: FormGroup

  guardianPanSubmitted = false;
  guardianAadhaarSubmitted = false;

  guardianEnableOtpSentMsg = false;
  guardianVkycConfirmationAccepted = false;
  guardianVkycLinkFetchError = false;
  guardianIsVkycCompleted = false;
  guardianProceedWithoutVkycChecked = false;
  guardianVkycURL: string = '';
  finalObjectJointHolderGuardian: any = {};
  userBranchName: any;
  userPanNumber: any;


  constructor(private fb: FormBuilder, private apiService: ApiService, private CookieService: CookieService,
    private notify: NotificationService,
    private spinner: NgxSpinnerService,
    private authService: AuthService,
    private cdChanges: ChangeDetectorRef,
    private modalService: NgbModal,
    private fdCacheService: FdCacheService,
  ) {
    this.nomineeForm = this.fb.group({
      name: ['', Validators.required],
      dob: [new Date, Validators.required],
      address: ['', Validators.required],
      // ownerPercentage: ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      relationship: ['', Validators.required],
      userId: ['']
    });

    this.vkycForm = this.fb.group({
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      emailId: ['', [Validators.required, Validators.email]]
    });

    const today = new Date();
    today.setDate(today.getDate() - 1); // Set to yesterday
    this.maxDate = today.toISOString().split('T')[0];

    // Guardian-specific forms and flags
    this.guardianPanForm = new FormGroup({
      panName: new FormControl('', Validators.required),
      panNumber: new FormControl('', [Validators.required, Validators.pattern(/[A-Z]{5}[0-9]{4}[A-Z]{1}/)]),
      panDOB: new FormControl('', Validators.required),
      kycbranchName: new FormControl('', Validators.required),
      relationship: new FormControl('', Validators.required),
    });

    this.guardianAadhaarForm = new FormGroup({
      aadhaarNumber: new FormControl('', [Validators.required, Validators.pattern(/^\d{12}$/)]),
      aadhaarOTP: new FormControl('', [Validators.minLength(4), Validators.maxLength(8)]),
    });

    this.guardianVkycForm = this.fb.group({
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      emailId: ['', [Validators.required, Validators.email]],
    });
  }


  ngOnInit() {
    this.loading = true; // Start loading
    this.today = new Date();
    this.getfdrNumber();

    const fdUserId = this.authService.getResponseValueByKey("fdUserId");

    this.fdCacheService.getUserFullDetails(fdUserId).pipe(
      switchMap((res) => {
        this.newFdRegId = res?.newFdRegId;
        this.userBranchName = res?.fdBranch;
        this.userPanNumber = res?.panNo
        const reqData = { fdRegId: res?.newFdRegId };
        return this.apiService.getNomineeDetails(this.hybridEncryptor.encrypted(JSON.stringify(reqData)));
      }),
      catchError(err => {
        console.error('Error fetching nominee details:', err);
        this.loading = false;
        return of({ error: true, message: 'Failed to fetch nominee details' });
      })
    ).subscribe((val: any) => {

      if (!val?.error) {
        this.nominees = val;
        this.loading = false;
        if (this.nominees.length == 0) {
          this.emptyMessage = 'There are no Nominees created for this Account. Kindly continue to create a new Nominee.'
        }
      }
    });

    this.enableGuardianSection = false;
    this.panForm.get('panDOB')?.valueChanges.subscribe((dob: any) => {
      this.isMinor = false;
      this.toggleGuardianField(dob);
    });

    this.getHoldGuardDetails();
  }

  toggleGuardianField(dob: string) {
    if (!dob) return;

    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age < 18) {
      // this.panForm.get('guardianName')?.enable();

      this.notify.warning('A minor cannot be added as a joint holder. Please visit your nearest SIDBI branch for assistance.', 'Alert')
      this.panForm.reset();
      return
      /* this.isMinor = true;
      this.finalObjectJointHolderGuardian = {

        pan: null,
        name: null,
        dob: null,
        guardFlag: 'N',
        panVerifyFlag: null,
        kycBranchCd: null,
        userId: null,
        relationship: null,
        aadharNo: null,
        postalCode: '',
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        aadharFlag: null,
        isPEP: null,
        mobileNo: null,
        vkycFlag: null,
        vkycUrl: null,
        jointGuardMapFlag: null 


    };*/
  } else {
  // this.panForm.get('guardianName')?.disable();
  this.isMinor = false;
  this.finalObjectJointHolderGuardian = {

    pan: null,
    name: null,
    dob: null,
    guardFlag: 'Y',
    panVerifyFlag: null,
    kycBranchCd: null,
    userId: null,
    relationship: null,
    aadharNo: null,
    postalCode: '',
    newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
    aadharFlag: null,
    isPEP: null,
    mobileNo: null,
    vkycFlag: null,
    vkycUrl: null,
    jointGuardMapFlag: null


  };
}
  }


getfdrNumber() {
  this.subscription.add(
    this.apiService.getfdrNumber().subscribe({
      next: (response: any) => {
        if (response) {
          this.FDrNo = response;
        }
      },
      error: (err) => {
        console.log("pennydropCheckAccountNumber error", err);
        // alert("An error occurred in Account Number Verification. Please try again.");
      }
    })
  );
}

openModal(index: number | null = null) {
  this.editIndex = index;
  if (index !== null) {
    const response = this.nominees[index]
    const patchedData = {
      ...response,
      dob: new Date(response.dob)
    };

    this.nomineeForm.patchValue(patchedData);

    this.nomineeForm.get('name')?.disable();
    this.nomineeForm.get('dob')?.disable();

  } else {
    this.nomineeForm.reset();

    this.nomineeForm.get('name')?.enable();
    this.nomineeForm.get('dob')?.enable();

  }
  this.displayModal = true;
}

saveNominee() {
  if (this.nomineeForm.valid) {
    const newNominee = this.nomineeForm.getRawValue();
    const currentTotal = this.nominees.reduce((sum, n) => sum + Number(n.percentage), 0);
    const newTotal = currentTotal + Number(newNominee.percentage);

    newNominee['fdRegId'] = this.newFdRegId

    this.apiService.saveNomineeDetails(this.hybridEncryptor.encrypted(JSON.stringify(newNominee))).subscribe((res: any) => {
      this.ngOnInit();
      this.notify.success(res?.message, 'Add Nominee');
    })



    this.displayModal = false;
  }
}


goToNextStep() {
  if (this.activeTabIndex < 1) {
    this.activeTabIndex++;
  }
}

  goToPreviousStep() {
  if (this.activeTabIndex > 0) {
    this.activeTabIndex--;
  }
}

setActiveTab(index: number): void {
  this.activeTabIndex = index;
}

closeNomineeModal(): void {
  this.displayModal = false;
}

enableAddHolderForm() {

      this.vkycConfirmationAccepted = false;
    this.vkycLinkFetchError = false;
  this.panForm.enable();
  this.aadhaarForm.enable();
  this.panForm.reset();
  this.vkycForm.reset();
  this.aadhaarForm.reset();
  this.panSubmitted = false;
  this.aadhaarSubmitted = false;
  this.addRemoveJointHolder();
}


addRemoveJointHolder() {
  this.finalObjectJointHolder = null;

  /*  if (this.createFDForm.get('branchCd')?.invalid) {
     this.notify.info('Please fill the Branch office to Manage Joint holder', 'Info');
     this.createFDForm.get('branchCd')?.markAllAsTouched();
     return
   }
   if (this.createFDForm.get('invCatHoldTypCd')?.value == '' || this.createFDForm.get('invCatHoldTypCd')?.value == null) {
     this.notify.info('Please fill the Holding Type to Manage Joint holder', 'Info');
     this.createFDForm.get('invCatHoldTypCd')?.markAllAsTouched();
     return
   }
*/

  this.getHoldGuardDetails();


  this.modalService.open(this.jointModal, {
    size: 'lg',
    backdrop: 'static',
    keyboard: false
  });
  this.vkycURL = '';
  this.vkycLinkFetchError = false;
  this.vkycInitiated = false;
  this.vkycConfirmationAccepted = false;
  this.finalObjectJointHolder = {

    pan: null,
    name: null,
    dob: null,
    guardFlag: 'N',
    panVerifyFlag: null,
    kycBranchCd: null,
    userId: null,
    relationship: null,
    aadharNo: null,
    postalCode: '',
    newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
    aadharFlag: null,
    isPEP: null,
    mobileNo: null,
    vkycFlag: null,
    vkycUrl: null


  };


}

getHoldGuardDetails() {
  let newRegId = this.authService.getResponseValueByKey('fdUserDtlsId');
  let data = { newRegId: newRegId };

  this.apiService.getHoldGuardDetails(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe((res: any) => {
    const allHolders = res?.data || [];

    const jointHolders = allHolders.filter((val: any) => val.guardFlag === 'N');
    const guardians = allHolders.filter((val: any) => val.guardFlag === 'Y');

    // Initialize guardianList
    this.guardianList = [];

    this.jointHolders = jointHolders.map((holder: any) => {
      const guardian = guardians.find((g: any) => g.jointGuardMapFlag === holder.pan);
      const holderWithGuardianFlag = guardian ? { ...holder, hasGuardian: true } : holder;

      // Remove matched guardian from guardians list to avoid duplication
      if (guardian) {
        // Optional: remove matched guardian from the list
        guardians.splice(guardians.indexOf(guardian), 1);
        return [holderWithGuardianFlag, { ...guardian, isGuardian: true }];
      } else {
        return [holderWithGuardianFlag];
      }
    }).flat();

    // Remaining guardians not mapped to any joint holder
    this.guardianList = guardians;
  });
}


handleVkycClick(holder: any): void {
  if(holder.vkycFlag === null) {
  // Show VKYC popup for verification
  this.selectedHolder = holder;
  this.showVkycPopup = !this.showVkycPopup;
  this.vkycForm.reset();
} else if (holder.vkycFlag === '0') {
  // Open VKYC URL in centered popup
  const width = 500;
  const height = 500;
  const left = Math.floor((window.screen.width - width) / 2);
  const top = Math.floor((window.screen.height - height) / 2);
  const features = `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`;


  if (holder.vkycUrl) {
    window.open(holder.vkycUrl, '_blank');
  } else {
    alert('VKYC URL not available.');
  }
}
  }

closeVkycPopup(): void {
  this.showVkycPopup = false;
  this.selectedHolder = null;
}

proceedVkycForHolder(): void {
  // Your VKYC logic here
  alert(`Proceeding VKYC for ${this.selectedHolder?.name
}`);
    this.closeVkycPopup();
  }

  doVkycProcessForJointHolderSecondary(selectedHolder: any) {


    if (this.vkycForm.valid) {
      let rowDate = this.selectedHolder?.dob
      if (this.selectedHolder?.dob) {
        rowDate = this.formatDateToDDMMYYYY(rowDate);
      }

      let data = {
        name: this.selectedHolder?.name,
        namePrintedInPan: this.selectedHolder?.name,
        dob: rowDate,
        pan: this.selectedHolder?.pan,
        panValidation: 'false',
        email: this.authService.getResponseValueByKey('fdUserId'),
        mobile: this.vkycForm.get('mobileNumber')?.value,
        mailId: this.vkycForm.get('emailId')?.value,
      };

      const vkycPan = this.selectedHolder?.pan;
      const vkycDob = this.selectedHolder?.dob;

      const isEmpty = (v: any) =>
        v == null || (typeof v === 'string' && v.trim() === '');

      if (isEmpty(vkycPan) || isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan)) {
        this.notify.warning('Unable to proceed with VKYC as your PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth is not updated in our records.', 'Info');
        return;
      }
      this.subscription.add(
        this.apiService
          .doVkycProcessService(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == 1002) {

                this.vkycConfirmationAccepted = true;
                this.vkycInitiated = true;
                // Access the vkycURL
                const formated = JSON.parse(response.message);
                this.vkycURL = formated.vkycURL;

                this.updateFinalRequestForOnlyVkycInitiate();
                // Desired dimensions
                const width = 500;
                const height = 500;
                // Calculate center position
                const left = Math.floor((window.screen.width - width) / 2);
                const top = Math.floor((window.screen.height - height) / 2);
                // Open centered window
                this.vkycForm.reset();
                this.showVkycPopup = false;
                this.selectedHolder = null;
                this.getHoldGuardDetails();
                this.cdChanges.detectChanges();
                const features = `width = ${ width }, height = ${ height }, top = ${ top }, left = ${ left }, resizable = yes, scrollbars = yes`;
                window.open(this.vkycURL, '_blank');
              } else {
                this.vkycURL = '';
                this.vkycLinkFetchError = true;
                this.vkycInitiated = false;
                this.vkycConfirmationAccepted = false;

              }
            },
            error: (err) => {
              console.log('An error occurred something went wrong ' + err);
            },
          })
      );


    } else {
      this.vkycForm.markAllAsTouched();
    }



  }

  updateFinalRequest(where: string) {
    console.log('where', where);
    if (where == 'PAN') {
      this.finalObjectJointHolder.pan = this.panForm.get('panNumber')?.value
      this.finalObjectJointHolder.dob = this.panForm.get('panDOB')?.value
      this.finalObjectJointHolder.kycBranchCd = this.panForm.get('kycbranchName')?.value
      this.finalObjectJointHolder.name = this.panForm.get('panName')?.value
      this.finalObjectJointHolder.isPEP = this.panForm.get('isPEP')?.value
      this.finalObjectJointHolder.mobileNo = this.panForm.get('mobileNumber')?.value
      this.finalObjectJointHolder.mailId = this.panForm.get('emailId')?.value
      this.finalObjectJointHolder.panVerifyFlag = 'Y'
    } else if (where == 'AADHAAR') {
      this.finalObjectJointHolder.aadharFlag = 'Y'
      this.finalObjectJointHolder.aadharNo = this.aadhaarForm.get('aadhaarNumber')?.value


    } else {
     
      this.finalObjectJointHolder.vkycFlag = 0
      this.finalObjectJointHolder.vkycUrl = this.vkycURL;

    }




    console.log('req', this.finalObjectJointHolder);

  }


  updateFinalRequestForOnlyVkycInitiate() {
    let rowDate = this.selectedHolder?.dob
    if (this.selectedHolder?.dob) {
      rowDate = this.formatDateToDDMMYYYY(rowDate);
    }

    this.finalObjectJointHolder.pan = this.selectedHolder?.pan
    this.finalObjectJointHolder.dob = rowDate
    this.finalObjectJointHolder.kycBranchCd = this.selectedHolder?.kycBranchCd
    this.finalObjectJointHolder.name = this.selectedHolder?.name
    this.finalObjectJointHolder.isPEP = this.selectedHolder?.isPEP
    this.finalObjectJointHolder.panVerifyFlag = 'Y'


    this.finalObjectJointHolder.aadharFlag = 'Y'
    this.finalObjectJointHolder.aadharNo = this.selectedHolder?.aadharNo



    this.finalObjectJointHolder.mobileNo = this.vkycForm.get('mobileNumber')?.value
    this.finalObjectJointHolder.mailId = this.vkycForm.get('emailId')?.value
    this.finalObjectJointHolder.vkycFlag = 0
    this.finalObjectJointHolder.vkycUrl = this.vkycURL;
    this.finalObjectJointHolder.relationship = this.selectedHolder?.relationship
    this.finalObjectJointHolder['holdId'] = this.selectedHolder?.holdId
    this.finalObjectJointHolder['guardFlag'] = 'N'
    this.finalObjectJointHolder['newRegId'] = this.selectedHolder?.newRegId
    this.finalObjectJointHolder['minorFlag'] = this.selectedHolder?.minorFlag





    console.log('req', this.finalObjectJointHolder);

    this.AddJointHolderForSecondary();

  }

  formatDateToDDMMYYYY(dateStr: any): string {
    const [year, month, day] = dateStr.split('-');
    return `${ day } -${ month } -${ year } `;
  }

  backtoTable() {
    this.vkycForm.reset();
    this.showVkycPopup = false;
    this.selectedHolder = null;
  }

  handlePanInput(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('panNumber')?.setValue(upperValue);
  }

  handlePanInputOne(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('panName')?.setValue(upperValue);
  }

  onDateChange(event: any, controlName: string, formGroup: FormGroup) {
    const selectedDate = new Date(event.target.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Normalize time for comparison

    if (selectedDate >= today) {
      formGroup.get(controlName)?.setValue('');
      // Optionally show a message or trigger a validation error
      // alert('Future or today\'s date is not allowed.');
    }
  }

  verifyPAN() {
    this.panForm.get('kycbranchName')?.setValue(this.userBranchName);
    if (this.panForm.valid) {
      if (this.jointHolders && this.jointHolders?.length > 0) {

        const panNumber = this.panForm.get('panNumber')?.value;
        const primaryPan = this.userPanNumber;

        // Check if PAN already exists in joint holders
        const matchedItem = this.jointHolders.find(item => item.pan === panNumber);

        if (matchedItem) {
          this.notify.info('PAN Number already exists in the Joint Holder table', 'Info');
          this.panForm.reset();
          return;
        }

        // Check if PAN matches primary depositor
        if (primaryPan === panNumber) {
          this.notify.info('Primary Depositor cannot be added as a Joint Holder', 'Info');
          this.panForm.reset();
          return;
        }
      }
      this.verifyPanCount();
      const datePipe = new DatePipe('en-US');
      const rawDob = this.panForm.get('panDOB')?.value;
      const formattedDob = datePipe.transform(rawDob, 'dd/MM/yyyy');
      this.spinner.show();
      const data = {
        pan: this.panForm.get('panNumber')?.value,
        dob: formattedDob,
        kycbranchName: this.userBranchName,
        name: this.panForm.get('panName')?.value,
        fdRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        fdUserId: this.authService.getResponseValueByKey('fdUserId'),
        flag: 1
      };

      this.subscription.add(
        this.apiService
          .verifiyPanData(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();
              try {
                const parsedMessage = JSON.parse(response.message);
                const panData = parsedMessage.payload?.data?.[0];
                const employeeData = response?.['employeeData'];

                if (
                  parsedMessage.statusCode === '1000' &&
                  parsedMessage.statusMsg === 'Success' &&
                  panData
                ) {
                  const { pan_status, name, dob, seeding_status } = panData;

                  // Handle all valid/invalid combinations
                  if (
                    response.statusCode === '1002' ||
                    response.statusCode === '1008'
                  ) {
                    if (pan_status === 'E' && name === 'Y' && dob === 'Y') {
                      // All matched
                      this.panForm.get('panNumber')?.disable();
                      this.panForm.get('panName')?.disable();
                      this.panForm.get('panDOB')?.disable();
                      this.panForm.get('kycbranchName')?.disable();
                      this.panForm.get('selectedPEP')?.disable();
                      this.panForm.get('relationship')?.disable();
                      // this.panForm.get('guardianName')?.disable();


                      this.notify.success(
                        'PAN verified successfully',
                        'Success',
                      );
                      //  this.aadharpanSedingstatus();
                      this.panSubmitted = true;
                      this.updateFinalRequest('PAN');


                      this.cdChanges.detectChanges();
                    } else if (
                      pan_status === 'E' &&
                      name === 'N' &&
                      dob === 'N'
                    ) {
                      // Both name and DOB mismatch
                      this.panSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to both Name and Date of Birth mismatch. Kindly ensure both fields match your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' &&
                      name === 'N' &&
                      dob === 'Y'
                    ) {
                      // Only name mismatch
                      this.panSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a name mismatch. Kindly ensure the name entered matches your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' &&
                      name === 'Y' &&
                      dob === 'N'
                    ) {
                      // Only DOB mismatch
                      this.panSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a mismatch in the date of birth. Please ensure the date of birth matches the one on your PAN record.',
                        'Error',
                      );
                    } else if (pan_status === 'N') {
                      // Invalid PAN
                      this.panSubmitted = false;
                      this.notify.error(
                        'Invalid PAN. Kindly check and try again.',
                        'Error',
                      );
                    } else {
                      // Unknown response
                      this.panSubmitted = false;
                      this.notify.warning(
                        'PAN verification returned an unknown response. Please contact support.',
                        'Warning',
                      );
                    }
                  } else {
                    // Unexpected statusCode
                    this.panSubmitted = false;
                    this.notify.warning(
                      'PAN verification failed due to unexpected response.',
                      'Warning',
                    );
                  }
                } else {
                  this.panSubmitted = false;
                  this.notify.error(
                    'Invalid response received during PAN verification.',
                    'Error',
                  );
                }
              } catch (e) {
                // PAN already registered case
                if (
                  response.statusCode === '1008' &&
                  typeof response.message === 'string'
                ) {

                  let getUserdata = {
                    fdUserId: response?.fdUserId
                  };

                  this.subscription.add(
                    this.apiService
                      .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(getUserdata)))
                      .subscribe({
                        next: (response: any) => {
                          if (response != null) {

                            if (
                              response.aadhaarVirifystsFlag === 'Y' &&
                              response.panverify_Flag === 'Y'
                            ) {
                              this.notify.success(
                                'PAN and AADHAAR Already Reqistered successfully',
                                'Success',
                              );
                              this.panSubmitted = true;
                              this.aadhaarSubmitted = true;
                              this.panForm.get('panName')?.setValue(response.fdUserName);
                              this.panForm.get('panNumber')?.setValue(response.fdUserPan);
                              if (response.politicalExposedPerson === 'Y') {
                                this.panForm.get('isPEP')?.setValue('Yes');
                              } else if (response.politicalExposedPerson === 'N') {
                                this.panForm.get('isPEP')?.setValue('No');
                              }

                              // set Aadhar number
                              this.aadhaarForm
                                .get('aadhaarNumber')
                                ?.setValue(response.fdUserAdharCard);
                              this.updateFinalRequest('PAN');
                              this.updateFinalRequest('AADHAAR');
                              this.panForm.disable();
                              this.aadhaarForm.disable();

                              this.cdChanges.detectChanges();
                            } else if ((response.aadhaarVirifystsFlag === null ||
                              response.aadhaarVirifystsFlag === '') &&
                              response.panverify_Flag === 'Y') {



                              this.notify.success(
                                'PAN Already Reqistered successfully',
                                'Success',
                              );
                              this.panForm.get('panNumber')?.disable();
                              this.panForm.get('panName')?.disable();
                              this.panForm.get('panDOB')?.disable();
                              this.panForm.get('kycbranchName')?.disable();
                              this.panForm.get('selectedPEP')?.disable();
                              this.panForm.get('relationship')?.disable();
                              // this.panForm.get('guardianName')?.disable();
                              this.panSubmitted = true;
                              this.updateFinalRequest('PAN');
                              //  }




                            }

                          }
                        },
                        error: (e) => {
                          console.log('error', e)
                          this.spinner.hide();
                          this.notify.warning(
                            'An error occurred while verifying PAN.',
                            'Warning',
                          );
                        },
                      })
                  );

                  /* end */



                } else {
                  this.notify.error(
                    'Invalid or malformed response received during PAN verification.',
                    'Error',
                  );
                  this.panSubmitted = false;
                }
              }
            },
            error: (e) => {
              console.log('error', e)
              this.spinner.hide();
              this.notify.warning(
                'An error occurred while verifying PAN.',
                'Warning',
              );
            },
          })
      );


    } else {
      this.panForm.markAllAsTouched();
    }
  }

  verifyPanCount() {
    /*  if (this.panAttemptCount < this.maxAttempts) {
       this.panAttemptCount++;
       if (this.panAttemptCount >= this.maxAttempts) {
         this.panDisabled = true;
         this.panAttemptMsg =
           'Max attempts reached for pan verification kindly try after some time';
         setTimeout(() => {
           this.panAttemptMsg = '';
         }, 15000);
       }
     } */
  }

  sendAadhaarOTP() {
    if (this.aadhaarForm.get('aadhaarNumber')?.valid) {

      var aadharnum = this.aadhaarForm.get('aadhaarNumber')?.value;
      this.spinner.show();
      if (aadharnum != null && aadharnum != '') {
        const data = {
          aadharno: String(this.aadhaarForm.get('aadhaarNumber')?.value),
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          flag: 1
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  this.notify.success(
                    'Aadhaar OTP sent to register mobile number',
                    'Success',
                  );
                  this.aadhaarForm.get('aadhaarNumber')?.disable();
                  this.sendOTPbtn = true;
                } else if (response.statusCode == '1008') {
                  this.notify.error(
                    'Aadhaar OTP generation was unsuccessful. This may be due to an invalid Aadhaar number. Kindly verify the details and try again.',
                    'Error',
                  );
                }
              },
              error: (error) => {
                console.error('An error occurred in aadharOTPRequest:', error);
                this.spinner.hide();
                // this.CommonError = "The server is currently busy. Please try again shortly";}
              },
            })
        );
      }



    } else {
      this.aadhaarForm.get('aadhaarNumber')?.markAsTouched();
    }
  }

  submitAadhaarOTP() {

    if (this.aadhaarForm.valid) {
      this.notify.info(
        'Your Aadhaar eKYC verification is in progress. Please wait a few moments while the process completes.',
        'Information',
      );

      setTimeout(() => {
        this.spinner.show();
        const data = {
          aadharno: this.aadhaarForm.get('aadhaarNumber')?.value,
          otp: this.aadhaarForm.get('aadhaarOTP')?.value,
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          mailId: this.authService.getResponseValueByKey('fdUserEmail'),
          flag: 1,
          panNo: this.panForm.get('panNumber')?.value
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestdata(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  this.notify.success(
                    'Aadhaar Verification Successfully Completed',
                    'Success',
                  );
                  this.updateFinalRequest('AADHAAR');
                  //  this.gettingLocalStorageData(data.mailId || '');
                  // this.aadharpanSedingstatus();
                  /*      setTimeout(() => {
                         this.showFDConfirmationDialog = true;
                       }, 1000); */
                  this.aadhaarSubmitted = true;
                  this.aadhaarForm?.disable();
                  // set Aadhar number
                  // this.aadhaarForm.get('aadhaarNumber')?.setValue(data.aadharno);
                  this.cdChanges.detectChanges();
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Resident authentication failed'
                ) {
                  this.notify.error(
                    'Enter Aadhaar valid OTP Number',
                    'Error',
                  );
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Invalid transactionId.'
                ) {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                }  else if (response.statusCode == '1008' &&
                  response.statusMsg == 'The given customer Pan and Aadhar name Mismatch'
                ) {
                  this.notify.error(
                    response.statusMsg,
                    'Mismatch',
                  );
                }  else if (response.statusCode == '1008') {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                }
              },
              error: (error) => {
                this.spinner.hide();
                console.error('An error occurred in submitAadhaarForm:', error);
              },
            })
        );
      }, 3000);


    }

  }

  AddJointHolder() {
    if (this.panSubmitted && this.aadhaarSubmitted) {

      /*  if (this.isMinor && this.panForm.get('guardianName')?.value == null) {
         this.notify.warning('Please fill the Gaurdian Name');
         this.enableGurdianErrorMsg = true;
         return
       } */

      if (this.panForm.get('relationship')?.value == null || this.panForm.get('relationship')?.value == '') {
        this.notify.warning('Please fill the Relationship');
        this.enableRelationshipErrorMsg = true;
      } else {
        this.finalObjectJointHolder.relationship = this.panForm.get('relationship')?.value
      }

       this.finalObjectJointHolder.userId = this.authService.getResponseValueByKey('fdUserEmail');

      this.subscription.add(
        this.apiService.saveHoldGuardDetails(
          this.hybridEncryptor.encrypted(JSON.stringify(this.finalObjectJointHolder))
        ).subscribe({
          next: (response: any) => {
            console.log('save holder', response);
            if (response.statusCode == '1002') {
              if (this.isMinor) {
                this.enableGuardianSection = true;
                this.notify.success('Joint Holder Added Successfully. Please Proceed to Add Gaurdian', 'Information')
              } else {
                this.modalService.dismissAll();
                this.getHoldGuardDetails();

              }

            }

          },
          error: (err: any) => {
            console.error('Error saving holder details:', err);
            // Optionally show an error message to the user
            this.notify.error('Failed to save holder details. Please try again.', 'Error');
          }
        })
      );
    }
  }


  AddJointHolderForSecondary() {

    if (this.vkycForm.valid) {
      this.finalObjectJointHolder.userId = this.authService.getResponseValueByKey('fdUserEmail');
      this.subscription.add(
        this.apiService.saveHoldGuardDetails(
          this.hybridEncryptor.encrypted(JSON.stringify(this.finalObjectJointHolder))
        ).subscribe({
          next: (response: any) => {
            console.log('save holder', response);
            if (response.statusCode == '1002') {
              this.modalService.dismissAll();
              this.getHoldGuardDetails();
            }
          },
          error: (err: any) => {
            console.error('Error saving holder details:', err);
            // Optionally show an error message to the user
            this.notify.error('Failed to save holder details. Please try again.', 'Error');
          }
        })
      );
    }



  }


  // PAN
  guardianVerifyPAN() {
    this.guardianPanForm.get('kycbranchName')?.setValue(this.userBranchName);
    if (this.guardianPanForm.valid) {
      if (this.jointHolders && this.jointHolders?.length > 0) {


        const panNumber = this.guardianPanForm.get('panNumber')?.value;
        const primaryPan = this.userPanNumber
          ;



        // Check if PAN already exists in joint holders
        const matchedItem = this.jointHolders.find(item => item.pan === panNumber);

        if (matchedItem) {
          this.notify.info('PAN Number already exists in the Joint Holder table', 'Info');
          this.guardianPanForm.reset();
          return;
        }

        // Check if PAN matches primary depositor
        if (primaryPan === panNumber) {
          this.notify.info('Primary Depositor cannot be added as a Joint Holders Guardian', 'Info');
          this.guardianPanForm.reset();
          return;
        }

      }
      this.verifyPanCount();
      const datePipe = new DatePipe('en-US');
      const rawDob = this.guardianPanForm.get('panDOB')?.value;
      const formattedDob = datePipe.transform(rawDob, 'dd/MM/yyyy');
      this.spinner.show();
      const data = {
        pan: this.guardianPanForm.get('panNumber')?.value,
        dob: formattedDob,
        kycbranchName: this.userBranchName,
        name: this.guardianPanForm.get('panName')?.value,
        fdRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        fdUserId: this.authService.getResponseValueByKey('fdUserId'),
        flag: 1
      };
      this.subscription.add(
        this.apiService
          .verifiyPanData(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();
              try {
                const parsedMessage = JSON.parse(response.message);
                const panData = parsedMessage.payload?.data?.[0];
                const employeeData = response?.['employeeData'];
                if (
                  parsedMessage.statusCode === '1000' &&
                  parsedMessage.statusMsg === 'Success' &&
                  panData
                ) {
                  const { pan_status, name, dob, seeding_status } = panData;
                  if (
                    response.statusCode === '1002' ||
                    response.statusCode === '1008'
                  ) {
                    if (pan_status === 'E' && name === 'Y' && dob === 'Y') {
                      this.guardianPanForm.get('panNumber')?.disable();
                      this.guardianPanForm.get('panName')?.disable();
                      this.guardianPanForm.get('panDOB')?.disable();
                      this.guardianPanForm.get('kycbranchName')?.disable();
                      this.guardianPanForm.get('selectedPEP')?.disable();
                      this.guardianPanForm.get('relationship')?.disable();
                      // this.guardianPanForm.get('guardianName')?.disable();
                      this.notify.success(
                        'PAN verified successfully',
                        'Success',
                      );
                      this.guardianPanSubmitted = true;
                      this.guardianUpdateFinalRequest('PAN');
                      this.cdChanges.detectChanges();
                    } else if (
                      pan_status === 'E' && name === 'N' && dob === 'N'
                    ) {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to both Name and Date of Birth mismatch. Kindly ensure both fields match your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' && name === 'N' && dob === 'Y'
                    ) {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a name mismatch. Kindly ensure the name entered matches your PAN record.',
                        'Error',
                      );
                    } else if (
                      pan_status === 'E' && name === 'Y' && dob === 'N'
                    ) {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'PAN verification failed due to a mismatch in the date of birth. Please ensure the date of birth matches the one on your PAN record.',
                        'Error',
                      );
                    } else if (pan_status === 'N') {
                      this.guardianPanSubmitted = false;
                      this.notify.error(
                        'Invalid PAN. Kindly check and try again.',
                        'Error',
                      );
                    } else {
                      this.guardianPanSubmitted = false;
                      this.notify.warning(
                        'PAN verification returned an unknown response. Please contact support.',
                        'Warning',
                      );
                    }
                  } else {
                    this.guardianPanSubmitted = false;
                    this.notify.warning(
                      'PAN verification failed due to unexpected response.',
                      'Warning',
                    );
                  }
                } else {
                  this.guardianPanSubmitted = false;
                  this.notify.error(
                    'Invalid response received during PAN verification.',
                    'Error',
                  );
                }
              } catch (e) {
                if (
                  response.statusCode === '1008' &&
                  typeof response.message === 'string'
                ) {
                  let getUserdata = {
                    fdUserId: response?.fdUserId
                  };
                  this.subscription.add(
                    this.apiService
                      .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(getUserdata)))
                      .subscribe({
                        next: (response: any) => {
                          if (response != null) {
                            if (
                              response.aadhaarVirifystsFlag === 'Y' &&
                              response.panverify_Flag === 'Y'
                            ) {
                              this.notify.success(
                                'PAN and AADHAAR Already Reqistered successfully',
                                'Success',
                              );
                              this.guardianPanSubmitted = true;
                              this.guardianAadhaarSubmitted = true;

                              this.guardianPanForm.get('panName')?.setValue(response.fdUserName);
                              this.guardianPanForm.get('panNumber')?.setValue(response.fdUserPan);

                              if (response.politicalExposedPerson === 'Y') {
                                this.guardianPanForm.get('isPEP')?.setValue('Yes');
                              } else if (response.politicalExposedPerson === 'N') {
                                this.guardianPanForm.get('isPEP')?.setValue('No');
                              }

                              this.guardianAadhaarForm
                                .get('aadhaarNumber')
                                ?.setValue(response.fdUserAdharCard);

                              this.guardianUpdateFinalRequest('PAN');
                              this.guardianUpdateFinalRequest('AADHAAR');

                              this.guardianPanForm.disable();
                              this.guardianAadhaarForm.disable();
                              this.cdChanges.detectChanges();
                            } else if (
                              (response.aadhaarVirifystsFlag === null || response.aadhaarVirifystsFlag === '') &&
                              response.panverify_Flag === 'Y'
                            ) {
                              this.notify.success(
                                'PAN Already Registered successfully',
                                'Success',
                              );
                              this.guardianPanForm.get('panNumber')?.disable();
                              this.guardianPanForm.get('panName')?.disable();
                              this.guardianPanForm.get('panDOB')?.disable();
                              this.guardianPanForm.get('kycbranchName')?.disable();
                              this.guardianPanForm.get('selectedPEP')?.disable();
                              this.guardianPanForm.get('relationship')?.disable();
                              // this.guardianPanForm.get('guardianName')?.disable();
                              this.guardianPanSubmitted = true;
                              this.guardianPanSubmitted = true;
                              this.guardianUpdateFinalRequest('PAN');
                            }
                          }
                        },
                        error: (e) => {
                          console.log('error', e)
                          this.spinner.hide();
                          this.notify.warning(
                            'An error occurred while verifying PAN.',
                            'Warning',
                          );
                        },
                      })
                  );
                } else {
                  this.notify.error(
                    'Invalid or malformed response received during PAN verification.',
                    'Error',
                  );
                  this.guardianPanSubmitted = false;
                }
              }
            },
            error: (e) => {
              console.log('error', e)
              this.spinner.hide();
              this.notify.warning(
                'An error occurred while verifying PAN.',
                'Warning',
              );
            },
          })
      );
    } else {
      this.guardianPanForm.markAllAsTouched();
    }
  }

  // Aadhaar
  guardianSendAadhaarOTP() {
    if (this.guardianAadhaarForm.get('aadhaarNumber')?.valid) {
      var aadharnum = this.guardianAadhaarForm.get('aadhaarNumber')?.value;
      this.spinner.show();
      if (aadharnum != null && aadharnum != '') {
        const data = {
          aadharno: String(this.guardianAadhaarForm.get('aadhaarNumber')?.value),
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          flag: 1
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  this.notify.success(
                    'Aadhaar OTP sent to register mobile number',
                    'Success',
                  );
                  this.guardianAadhaarForm.get('aadhaarNumber')?.disable();
                  this.sendOTPbtn = true;
                } else if (response.statusCode == '1008') {
                  this.notify.error(
                    'Aadhaar OTP generation was unsuccessful. This may be due to an invalid Aadhaar number. Kindly verify the details and try again.',
                    'Error',
                  );
                }
              },
              error: (error) => {
                console.error('An error occurred in aadharOTPRequest:', error);
                this.spinner.hide();
                // this.CommonError = "The server is currently busy. Please try again shortly";}
              },
            })
        );
      }
    } else {
      this.guardianAadhaarForm.get('aadhaarNumber')?.markAsTouched();
    }
  }
  guardianSubmitAadhaarOTP() {
    if (this.guardianAadhaarForm.valid) {
      this.notify.info(
        'Your Aadhaar eKYC verification is in progress. Please wait a few moments while the process completes.',
        'Information',
      );
      setTimeout(() => {
        this.spinner.show();
        const data = {
          aadharno: this.guardianAadhaarForm.get('aadhaarNumber')?.value,
          otp: this.guardianAadhaarForm.get('aadhaarOTP')?.value,
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          mailId: this.authService.getResponseValueByKey('fdUserEmail'),
          flag: 1,
          panNo: this.panForm.get('panNumber')?.value
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestdata(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  this.notify.success(
                    'Aadhaar Verification Successfully Completed',
                    'Success',
                  );
                  this.guardianUpdateFinalRequest('AADHAAR');
                  this.guardianAadhaarForm.disable();
                  this.cdChanges.detectChanges();

                  this.guardianAadhaarSubmitted = true;

                  this.cdChanges.detectChanges();
                } else if (
                  response.statusCode == '1008' && response.statusMsg == 'Resident authentication failed'
                ) {
                  this.notify.error(
                    'Enter Aadhaar valid OTP Number',
                    'Error',
                  );
                } else if (
                  response.statusCode == '1008' && response.statusMsg == 'Invalid transactionId.'
                ) {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                }  else if (response.statusCode == '1008' &&
                  response.statusMsg == 'The given customer Pan and Aadhar name Mismatch'
                ) {
                  this.notify.error(
                    response.statusMsg,
                    'Mismatch',
                  );
                }  else if (response.statusCode == '1008') {
                  this.notify.error(
                    'Aadhaar Verification failed due to some technical issue try again after some time',
                    'Error',
                  );
                }
              },
              error: (error) => {
                this.spinner.hide();
                console.error('An error occurred in submitAadhaarForm:', error);
              },
            })
        );
      }, 3000);
    }
  }


  guardianBelowOneLaks() {
    this.isSelectedBelowOneLaks = 'Y';
    if (!this.guardianPanSubmitted && !this.guardianAadhaarSubmitted) {
      this.notify.warning(
        'Please complete the Pan and Aadhar verification',
        'KYC Pending',
      );
    }
  }

  guardianDoVkycProcessForJointHolder() {
    if (this.guardianVkycForm.valid) {
      let rowDate = this.guardianPanForm.get('panDOB')?.value
      if (this.guardianPanForm.get('panDOB')?.value) {
        rowDate = this.formatDateToDDMMYYYY(rowDate);
      }
      let data = {
        name: this.guardianPanForm.get('panName')?.value,
        namePrintedInPan: this.guardianPanForm.get('panName')?.value,
        dob: rowDate,
        pan: this.guardianPanForm.get('panNumber')?.value,
        panValidation: 'false',
        email: this.authService.getResponseValueByKey("fdUserId"),
        mobile: this.guardianVkycForm.get('mobileNumber')?.value,
      };

      const vkycPan = this.guardianPanForm.get('panNumber')?.value;
      const vkycDob = this.guardianPanForm.get('panDOB')?.value;

      const isEmpty = (v: any) =>
        v == null || (typeof v === 'string' && v.trim() === '');

      if (isEmpty(vkycPan) || isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan)) {
        this.notify.warning('Unable to proceed with VKYC as your PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth is not updated in our records.', 'Info');
        return;
      }

      this.subscription.add(
        this.apiService
          .doVkycProcessService(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == 1002) {
                this.guardianVkycConfirmationAccepted = true;
                this.vkycInitiated = true;
                const formated = JSON.parse(response.message);
                this.guardianVkycURL = formated.vkycURL;
                this.guardianUpdateFinalRequest('vkyc');
                const width = 500;
                const height = 500;
                const left = Math.floor((window.screen.width - width) / 2);
                const top = Math.floor((window.screen.height - height) / 2);
                const features = `width = ${ width }, height = ${ height }, top = ${ top }, left = ${ left }, resizable = yes, scrollbars = yes`;
                window.open(this.guardianVkycURL, '_blank');
              } else {
                this.guardianVkycURL = '';
                this.guardianVkycLinkFetchError = true;
                this.vkycInitiated = false;
                this.guardianVkycConfirmationAccepted = false;
              }
            },
            error: (err) => {
              console.log('An error occurred something went wrong ' + err);
            },
          })
      );
    } else {
      this.guardianVkycForm.markAllAsTouched();
    }
  }


  guardianAddJointHolder() {
    if (this.guardianPanSubmitted && this.guardianAadhaarSubmitted) {
      /* if (this.isMinor && this.guardianPanForm.get('guardianName')?.value == null) {
        this.notify.warning('Please fill the Gaurdian Name');
        this.enableGurdianErrorMsg = true;
        return;
      } */
      if (this.guardianPanForm.get('relationship')?.value == null || this.guardianPanForm.get('relationship')?.value == '') {
        this.notify.warning('Please fill the Relationship');
        this.enableRelationshipErrorMsg = true;
      } else {
        this.finalObjectJointHolderGuardian.relationship = this.guardianPanForm.get('relationship')?.value;
      }
      this.finalObjectJointHolderGuardian.jointGuardMapFlag = this.finalObjectJointHolder.pan;
      this.finalObjectJointHolderGuardian.isPEP = 'No';

      this.finalObjectJointHolder.userId = this.authService.getResponseValueByKey('fdUserEmail');

      this.subscription.add(
        this.apiService.saveHoldGuardDetails(
          this.hybridEncryptor.encrypted(JSON.stringify(this.finalObjectJointHolderGuardian))
        ).subscribe({
          next: (response: any) => {
            console.log('save holder', response);
            if (response.statusCode == '1002') this.getHoldGuardDetails();
          },
          error: (err: any) => {
            console.error('Error saving holder details:', err);
            this.notify.error('Failed to save holder details.Please try again.', 'Error');
          }
        })
      );
    }
    // Note: The original structure had the closing brace after the subscription and then a stray block.
    // The guardian version preserves the same branching and flow as the original.
  }


  guardianUpdateFinalRequest(where: string) {
    console.log('where', where);
    if (where == 'PAN') {
      this.finalObjectJointHolderGuardian.pan = this.guardianPanForm.get('panNumber')?.value;
      this.finalObjectJointHolderGuardian.dob = this.guardianPanForm.get('panDOB')?.value;
      this.finalObjectJointHolderGuardian.kycBranchCd = this.guardianPanForm.get('kycbranchName')?.value;
      this.finalObjectJointHolderGuardian.name = this.guardianPanForm.get('panName')?.value;
      this.finalObjectJointHolderGuardian.isPEP = this.guardianPanForm.get('isPEP')?.value;
      this.finalObjectJointHolderGuardian.panVerifyFlag = 'Y';
      this.finalObjectJointHolderGuardian.finalObjectJointHolderGuardian = this.panForm.get('panNumber')?.value;;
      this.finalObjectJointHolderGuardian.mobileNo = this.guardianPanForm.get('mobileNumber')?.value;
      this.finalObjectJointHolderGuardian.userId = this.guardianPanForm.get('emailId')?.value;
    } else if (where == 'AADHAAR') {
      this.finalObjectJointHolderGuardian.aadharFlag = 'Y';
      this.finalObjectJointHolderGuardian.aadharNo = this.guardianAadhaarForm.get('aadhaarNumber')?.value;
    } else {
      
      this.finalObjectJointHolderGuardian.vkycFlag = 0;
      this.finalObjectJointHolderGuardian.vkycUrl = this.guardianVkycURL;
    }
    console.log('req', this.finalObjectJointHolder);
  }

  belowOneLaks() {
    this.isSelectedBelowOneLaks = 'Y';
    if (!this.panSubmitted && !this.aadhaarSubmitted) {
      this.notify.warning(
        'Please complete the Pan and Aadhar verification',
        'KYC Pending',
      );
    }
  }

  doVkycProcessForJointHolder() {


    if (this.panForm.get('mobileNumber')?.value && this.panForm.get('emailId')?.value) {
      let rowDate = this.panForm.get('panDOB')?.value
      if (this.panForm.get('panDOB')?.value) {
        rowDate = this.formatDateToDDMMYYYY(rowDate);
      }

      let data = {
        name: this.panForm.get('panName')?.value,
        namePrintedInPan: this.panForm.get('panName')?.value,
        dob: rowDate,
        pan: this.panForm.get('panNumber')?.value,
        panValidation: 'false',
        email: this.authService.getResponseValueByKey("fdUserId"),
        mobile: this.panForm.get('mobileNumber')?.value,
        mailId: this.panForm.get('emailId')?.value,
      };

      const vkycPan = this.panForm.get('panNumber')?.value;
      const vkycDob = this.panForm.get('panDOB')?.value;

      const isEmpty = (v: any) =>
        v == null || (typeof v === 'string' && v.trim() === '');

      if (isEmpty(vkycPan) || isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycPan)) {
        this.notify.warning('Unable to proceed with VKYC as your PAN is not updated in our records.', 'Info');
        return;
      }
      if (isEmpty(vkycDob)) {
        this.notify.warning('Unable to proceed with VKYC as your Date of Birth is not updated in our records.', 'Info');
        return;
      }
      this.subscription.add(
        this.apiService
          .doVkycProcessService(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == 1002) {

                this.vkycConfirmationAccepted = true;
                this.vkycInitiated = true;
                // Access the vkycURL
                const formated = JSON.parse(response.message);
                this.vkycURL = formated.vkycURL;

                this.updateFinalRequest('vkyc');
                // Desired dimensions
                const width = 500;
                const height = 500;
                // Calculate center position
                const left = Math.floor((window.screen.width - width) / 2);
                const top = Math.floor((window.screen.height - height) / 2);
                // Open centered window
                const features = `width = ${ width }, height = ${ height }, top = ${ top }, left = ${ left }, resizable = yes, scrollbars = yes`;
                window.open(this.vkycURL, '_blank');
              } else {
                this.vkycURL = '';
                this.vkycLinkFetchError = true;
                this.vkycInitiated = false;
                this.vkycConfirmationAccepted = false;

              }
            },
            error: (err) => {
              console.log('An error occurred something went wrong ' + err);
            },
          })
      );


    } else {

      if (!this.panSubmitted && !this.aadhaarSubmitted) {
      this.notify.warning(
        'Please complete the Pan and Aadhar verification',
        'KYC Pending',
      );
    }

      this.vkycForm.markAllAsTouched();
    }



  }

}
