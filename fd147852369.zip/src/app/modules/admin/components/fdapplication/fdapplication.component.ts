import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router,RouterModule,RouterOutlet } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { Subscription } from 'rxjs';
import { ApiService } from '../../../../service/api.service';
import { AuthService } from '../../../../service/auth.service';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { NgxSpinnerModule } from "ngx-spinner";
import {NgxSpinnerService} from "ngx-spinner"
import { FdCacheService } from '../../../../service/fd-cache.service';

// Define the FDApplication model interface
interface FDApplication {
  entryId: string;
  entryDt: string;
  period: number;
  intRate: number;
  amount: number;
  presentFDValue: number;
  autoRenewFlag: string;
  branchCd: string;
  strAppStatus: string;
  fdappStatus: string;
  pdfDocUrl: string;
  saveFlag: string;
  operation?: 'view' | 'edit'; // Optional operation property for conditional rendering
}
 
@Component({
  selector: 'app-fdapplication',
  standalone: true,
  imports: [FormsModule, CommonModule,RouterModule,RouterOutlet,NgxSpinnerModule],
  templateUrl: './fdapplication.component.html',
  styleUrls: ['./fdapplication.component.scss']
})

export class FdapplicationComponent implements OnInit{
  constructor(
    private apiService :ApiService,
    private CookieService : CookieService,
    private authService :AuthService,
    private spinner: NgxSpinnerService,
    private fdCacheService: FdCacheService,
    ){} 
  newFD: any = {};
  cifId : any;
  fdEntryResponse: any = [];
  subscription: Subscription = new Subscription();
  public hybridEncryptor!:HybridEncryptor;
  ngOnInit(): void {
    this.spinner.show();
  
    setTimeout(() => {
               this.spinner.hide();
             }, 1000)
       
    // this.userFdDetailsView(); 
    this.hybridEncryptor = new HybridEncryptor();
  this.getFdEntryListDetails();  
  }
   getFdEntryListDetails(): void {
     
    const fdUserId = this.authService.getResponseValueByKey("fdUserId");
      this.subscription.add(
        this.fdCacheService.getUserFullDetails(fdUserId).subscribe({
          next: (response: any) => {
            if(response){
              
                const data = {
                    cif : "",
                    fdUserPan: response.panNo
                   } 
                  this.subscription.add(
                    this.apiService.getFdEntryListDetails(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe({
                      next: (response: any) => {
                        if(response){
                          this.fdApplications = response ;
                          }
                       
                        }
                      
                    })
                  );
            }
          }
        })
      );
   
    }
    fdApplications: FDApplication[] = this.fdEntryResponse ;
  
  // View FD function
  viewFD(fd: any) {
      if(fd.entryId !=null && fd.entryId != ""){
      this.authService.setviewFDentryId(fd.entryId)
      this.apiService.setFdViewApplication(fd);
    }
  }
 
 
  editFD(fd: any) {
    if(fd.entryId !=null && fd.entryId != ""){
    this.apiService.setFdViewApplication(fd);
    this.authService.setEditFDentryId(fd.entryId);
    }
}
 
  // Print Receipt function
  printReceipt(fd: any) {
  }
 
  // Form submission logic
  submitForm(fdForm: any) {
    if (fdForm.valid) {
      console.log('Form submitted successfully!');
      // You can add further submission logic like saving the form data
    } else {
      console.log('Please fill in all the required fields.');
    }
  }
  downloadPDF(fd: any) {
    this.subscription.add(
      this.apiService.downloadFdrePort(fd.entryId).subscribe({
        next: (response: any) => {
          if(response.status =='200'){
          const blob = new Blob([response.body], { type: response.headers.get('Content-Type') });
           const contentDisposition = response.headers.get('Content-Disposition');
           let filename = contentDisposition
           ? contentDisposition.split('filename=')[1].trim()
           :'FD_APPLICATION_FORM.pdf';
           const link = document.createElement('a');
           link.href = window.URL.createObjectURL(blob);
           link.download = filename;
           link.click();
            // Clean up the URL object
           window.URL.revokeObjectURL(link.href);
               
        }
        }, error: (error) => {
          console.error('Error downloading PDF:', error);
        }
      })
    );
  }
   
}