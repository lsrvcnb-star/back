import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FdapplicationComponent } from './fdapplication.component';

describe('FdapplicationComponent', () => {
  let component: FdapplicationComponent;
  let fixture: ComponentFixture<FdapplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FdapplicationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FdapplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
