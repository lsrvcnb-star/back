import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../../service/api.service';
import { CookieService } from 'ngx-cookie-service';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../../service/auth.service';
import { FdCacheService } from '../../../../service/fd-cache.service';

@Component({
  selector: 'app-fd-form-download',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './fd-form-download.component.html',
  styleUrl: './fd-form-download.component.scss'
})
export class FdFormDownloadComponent implements OnInit {

  hybridEncryptor = new HybridEncryptor();
  fdUserId: any;
  customerType: any;
  isShowDownloadForm: boolean = false;
  constructor(private apiService: ApiService,
    private cookieService: CookieService,
   private authService: AuthService,
   private fdCacheService: FdCacheService) {

  }
  ngOnInit() {
    this.isShowDownloadForm = false;
    this.getlistOFDs();
    const fdUserId = this.authService.getResponseValueByKey("fdUserId");

    this.fdCacheService.getUserFullDetails(fdUserId).subscribe((res: any) => {
      this.fdUserId = res?.fdUserId
      this.customerType = res?.customerType
    })



  }

  getlistOFDs() {
    this.fdUserId = this.authService.getResponseValueByKey('fdUserEmail');
    if (this.fdUserId) {
      this.fdCacheService
        .getUserDetails(this.fdUserId)
        .subscribe({
          next: (response: any) => {
            let fdEntryListReq = {
              cif: response['custCifId'],
              fdUserPan: response['fdUserPan'],
              // fdUserPan: 'CJSPA3510J',
            };
            this.fetchFdEntryListDetails(fdEntryListReq);
          },
          error: (err) => {
            console.error('Error fetching User details:', err);
          },
        });
    }
  }

  fetchFdEntryListDetails(req: any): void {
    this.apiService
      .getFdEntryListDetails(
        this.hybridEncryptor.encrypted(JSON.stringify(req))
      )
      .subscribe({

        next: (response: any[]) => {
          // Check if any object in the response has a valid entryId
          this.isShowDownloadForm = response?.some(item => item.fdappStatus === 'LIVE FD');


        },

        error: (err) => {
          console.error('Error fetching FD details:', err);
        },
      });
  }


  downloadForm(formType: '15g' | '15h'): void {
    const req = {
      fdUserId: this.fdUserId
    }
    this.apiService.downloadForm(formType, this.hybridEncryptor.encrypted(JSON.stringify(req))).subscribe({

      next: (response: Blob) => {
        const blob = new Blob([response], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Form_${formType}.pdf`;
        a.click();
        window.URL.revokeObjectURL(url);
      },
      error: (err) => {
        console.error(`Error downloading Form ${formType}:`, err);
        alert(`Failed to download Form ${formType}. Please try again later.`);
      }
    });


  }

}
