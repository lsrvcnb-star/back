import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FdFormDownloadComponent } from './fd-form-download.component';

describe('FdFormDownloadComponent', () => {
  let component: FdFormDownloadComponent;
  let fixture: ComponentFixture<FdFormDownloadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FdFormDownloadComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FdFormDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
