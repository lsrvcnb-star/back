import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../../service/api.service';
import { CookieService } from 'ngx-cookie-service';
import { forkJoin, Subscription } from 'rxjs';
import {
  FormGroup,
  FormControl,
  Validators,
  ReactiveFormsModule,
  FormBuilder,
} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CustomValidator } from '../../Constom/validator';
import { AuthService } from '../../../../service/auth.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxSpinnerService } from 'ngx-spinner';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { HostListener } from '@angular/core';
import { Route, Router } from '@angular/router';
import { SanitizeInputDirective } from '../../../../sanitize-input.directive';
import { environment } from '../../../../../environments/environment';
import { CustomValidatorService } from '../../../../service/custom-validator-service.service';

interface AlertItem {
  severity: 'success' | 'info' | 'warn' | 'error';
  summary: string;
  detail: string;
}

@Component({
  selector: 'app-account-details',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule, NgxSpinnerModule, SanitizeInputDirective],
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.scss',
})
export class AccountDetailsComponent implements OnInit {

  initialOccupation!: string | null;
  occupationChanged = false;
  public FDUserName!: string;
  Usedrinfo!: FormGroup;
  shortNamevalue!: any;
  strButton: any;
  disable = true;
  responseUser!: any;
  todayDate = new Date().toISOString().split('T')[0];
  minDate = '1900-01-01';
  kycbranchName = [, Validators.required];
  schemeList = [, Validators.required];
  AccountdetailsForm!: FormGroup;
  public subtypeLists: any;
  public hybridEncryptor!: HybridEncryptor;
  customValidator: CustomValidator = new CustomValidator();
  autoRenewError: string | null = null;
  FdmaxAmt!: any;
  isSubmitting: boolean = false;
  FDrNo!: any;
  verfyButtonbooleanVal: boolean = true;
  isSelectDisabled: boolean = false;
  myTrigger: boolean = true;
  kycValues: any;
  isEmployee!: boolean;
  accountVerifed: boolean = true;
  occupation: any;
  stateName: any;
  stateOptions: any[] = [];
  cityOptions: any[] = [];
  occupationOption: any;
  showAlertModal = false;
  activeAlert: AlertItem | null = null;
  maritalStatusOption: any[] = [{ key: 'Married', value: 'married' }, { key: 'Unmarried', value: 'unmarried' }, { key: 'Others', value: 'others' }]
  isIfscVerified: boolean = false;
  isInitialPatch = true;
  isCIFCustomer: boolean = false;
  bankEditTrigger: boolean = true;
  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private CookieService: CookieService,
    private authService: AuthService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private CustomValidatorService: CustomValidatorService


  ) { }
  subscription: Subscription = new Subscription();

  @HostListener('paste', ['$event'])
  handlePaste(event: ClipboardEvent) {
    const pasted = event.clipboardData?.getData('text') || '';
    const unsafePattern = /[^a-zA-Z0-9 _.-]/;
    if (unsafePattern.test(pasted)) {
      event.preventDefault();
    }
  }

  ngOnInit(): void {
    // this.apiService.form$.subscribe((res) => {
    //   this.kycValues = res;

    // });
    this.isCIFCustomer = false
    this.branchList();
    this.getDropdownListdata();
    this.getDropdownListF();

    this.hybridEncryptor = new HybridEncryptor();
    this.AccountdetailsForm = this.fb.group({
      state: [this.kycValues?.kyc?.state, Validators.required],
      pinCode: [this.kycValues?.kyc?.pinCode, Validators.required],
      occupation: [this.kycValues?.kyc?.occupation, Validators.required],
      kycBranchName: [this.kycValues?.kyc?.kycBranchName, Validators.required],
      annualIncome: [
        this.kycValues?.kyc?.annualIncome,
        [
          Validators.pattern(/^[0-9]+$/) // only positive whole numbers
        ]
      ],
      maritalStatus: [this.kycValues?.kyc?.maritalStatus, Validators.required],
      dob: [this.kycValues?.kyc?.dob, Validators.required],
      gender: [this.kycValues?.kyc?.gender, Validators.required],
      mobNum: [this.kycValues?.kyc?.mobile],
      emailId: [this.kycValues?.kyc?.email],
      city: [this.kycValues?.kyc?.city, Validators.required],
      panNo: [this.kycValues?.kyc?.pan],
      shortName: [this.kycValues?.kyc?.shortName],
      longName: [this.kycValues?.kyc?.longName],
      custAccType: [''],
      custBankName: [''],
      custBranch: [''],
      payeeName: [this.kycValues?.kyc?.shortName],
      socialCategory: [this.kycValues?.kyc?.socialCategory],
      minority: [{value: this.kycValues?.kyc?.minority, disabled: true}],
      custAccNum: [''],

      custIfsc: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[A-Z]{4}0[A-Z0-9]{6}$/)
        ]
      ],

      custCode: [''],
      bankId: [''],
      cifCd: [''],
      empId: [{value: '', disabled: true}],
      empStatus: [{value: '', disabled: true}],
      address: [
        this.kycValues?.kyc?.line1 +
        this.kycValues?.kyc?.line2 +
        this.kycValues?.kyc?.city +
        this.kycValues?.kyc?.state, Validators.required
      ],
      newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
    });

    this.spinner.show();

    const userDetailsPayload = {
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
      newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
      entryId: this.authService.getResponseValueByKey('entryId'),
      cif: this.authService.getResponseValueByKey('cif'),
      kycBranchName: this.authService.getResponseValueByKey(''),
    };

    const bankDetailsPayload = {
      fdRegId: this.authService.getResponseValueByKey('newFdRegId'),
    };

    const encryptedUserDetails = this.hybridEncryptor.encrypted(JSON.stringify(userDetailsPayload));
    const encryptedBankDetails = this.hybridEncryptor.encrypted(JSON.stringify(bankDetailsPayload));

    this.subscription.add(
      forkJoin({
        userDetails: this.apiService.userFdDetailsView(encryptedUserDetails),
        bankDetails: this.apiService.getbankDetails(encryptedBankDetails),
      }).subscribe({
        next: ({ userDetails, bankDetails }) => {
          // Handle user details response
          if (userDetails) {
            this.responseUser = userDetails;
            if (userDetails.cif != null && userDetails.cif > 0) {
              this.isCIFCustomer = true;
            } else {
              this.isCIFCustomer = false;
            }

            // ✅ IMPORTANT
            this.updateValidatorsForCIF();

            this.isEmployee = this.responseUser.empKycFlag === "Y" ? true : false;
            this.shortNamevalue = userDetails.shortName;
            this.AccountdetailsForm.patchValue({
              longName: userDetails.firDepoName,
              shortName: userDetails.shortName,
              cifCd: userDetails.cif,
              panNo: userDetails.panNo,
              address: userDetails.address,
              kycBranchName: userDetails.fdBranch,

              /* city: userDetails.city,
              state: userDetails.state, */
              pinCode: userDetails.pinCode,
              occupation: userDetails.occupation,
              annualIncome: userDetails.annualIncome,
              maritalStatus: userDetails.maritalStatus,
              socialCategory: userDetails.socialCategory,
              minority: userDetails.minority,
              custCode: userDetails.custCode,
              gender: userDetails.gender,
              mobNum: userDetails.mobNum,
              emailId: userDetails.email,
              payeeName: userDetails.shortName || '',
              empId: userDetails?.employee.empId,
              empStatus: userDetails?.employee.empStatus,
            });
            // ✅ Save initial occupation from API
            this.initialOccupation = this.AccountdetailsForm.get('occupation')?.value;

            this.validateStaffServiceDetails();
            
            // ✅ Detect only USER-DRIVEN occupation changes
            this.AccountdetailsForm.get('occupation')?.valueChanges.subscribe(value => {
              this.occupationChanged = value !== this.initialOccupation;
              this.accountVerifed = false;
            });

            this.getStateCode(userDetails.state, userDetails.city);

            // ✅ Format DOB
            if (userDetails.dob) {
              const rawDob = String(userDetails.dob).trim();
              const normalizedDob = rawDob.replace(/\//g, '-');
              const dobParts = normalizedDob.split('-');
              if (dobParts.length === 3) {
                const formattedDob = `${dobParts[2]}-${dobParts[1]}-${dobParts[0]}`;
                this.AccountdetailsForm.get('dob')?.setValue(formattedDob);
              } else {
                console.warn('Unexpected DOB format:', userDetails.dob);
                this.AccountdetailsForm.get('dob')?.setValue(null);
              }
            }


          }

          // Handle bank details response
          if (bankDetails && bankDetails.length > 0) {
            const bd = bankDetails[0];
            this.AccountdetailsForm.patchValue({
              custAccType: bd.custAccType?.toLowerCase(),
              custBankName: bd.custBankName,
              custBranch: bd.custBranch,
              payeeName: bd.payeeName,
              custAccNum: bd.custAccNum,
              custIfsc: bd.custIfsc,
              bankId: bd.bankId,
            }, { emitEvent: false });   // ✅ IMPORTANT FIX
            this.isInitialPatch = false;
          }
          this.checkFormFields();
          this.spinner.hide();
        },
        error: (err) => {
          console.error('Error in one or both API calls:', err);
          this.spinner.hide();
        }
      })
    );



    this.AccountdetailsForm.get('custIfsc')?.valueChanges.subscribe(() => {
      if (this.isInitialPatch) return;   // ✅ skip during patch

      this.isIfscVerified = false;


      this.AccountdetailsForm.get('custBankName')?.enable();
      this.AccountdetailsForm.get('custBranch')?.enable();


      this.AccountdetailsForm.get('custBankName')?.reset();
      this.AccountdetailsForm.get('custBranch')?.reset();
    });


  }


  areRequiredFieldsValid(): boolean {
    const requiredFields = ['occupation', 'maritalStatus', 'socialCategory', 'minority'];
    return requiredFields.every(field => this.AccountdetailsForm.get(field)?.valid);
  }

  preventNegativeNumber(event: KeyboardEvent): void {
    if (event.key === '-' || event.key === '+' || event.key.toLowerCase() === 'e') {
      event.preventDefault();
    }
  }

  isStaffServOccupation(): boolean {
  return this.AccountdetailsForm.get('occupation')?.value === 'STAFF-SERV';
}

validateStaffServiceDetails(): void {
  const occupation =
    this.AccountdetailsForm.get('occupation')?.value;

  const empCode =
    this.AccountdetailsForm.get('empId')?.value;

  const empStatus =
    this.AccountdetailsForm.get('empStatus')?.value;

  if (
    occupation === 'STAFF-SERV' &&
    (!empCode || !empStatus)
  ) {
    this.showAlert(
      'warn',
      'Employee Information Missing',
      'Employee/Retired Code or Employee Status is not available. Please contact FD Support Team.'
    );
  }
}



  bankRequiredFieldsValid(): boolean {
    const requiredFields = [
      'custBankName',
      'custBranch',
      'payeeName',
      'custAccType',
      'custAccNum',
      'custIfsc'
    ];

    return requiredFields.every(field => {
      const control = this.AccountdetailsForm.get(field);

      // ✅ treat disabled fields as valid
      return control?.disabled || control?.valid;
    });
  }


  checkFormFields() {
    // Example logic to count unfilled fields
    const unfilledCount = this.calculateUnfilledFields();
    this.apiService.updateUnfilledFieldsCount(unfilledCount);
  }

  calculateUnfilledFields(): number {
    const excludedFields = ['custCode', 'bankId', 'newFdRegId', 'cifCd'];
    let count = 0;

    Object.keys(this.AccountdetailsForm.controls).forEach((key) => {
      if (!excludedFields.includes(key)) {
        const control = this.AccountdetailsForm.get(key);
        if (!control?.value || control.value.toString().trim() === '') {
          count++;
        }
      }
    });
    this.AccountdetailsForm.markAllAsTouched();

    return count;
  }

  enableFields(): void {
    Object.keys(this.AccountdetailsForm.controls).forEach((field) => {
      this.AccountdetailsForm.get(field)?.enable();
    });
  }

  enableToEdit() {
    this.spinner.show();
    setTimeout(() => {
      this.spinner.hide();
      this.myTrigger = false;
      this.AccountdetailsForm.get('minority')?.enable();
    }, 500)
    // ✅ enables occupation & bank fields
  }

  enableBankEdit() {
    this.spinner.show();

    setTimeout(() => {
      this.spinner.hide();
      this.bankEditTrigger = false;
    }, 500);
  }

  get branchCd() {
    return this.AccountdetailsForm.get('branchCd');
  }
  get cifCd() {
    return this.AccountdetailsForm.get('cifCd');
  }

  get catSubTypCd() {
    return this.AccountdetailsForm.get('catSubTypCd');
  }
  get invCategory() {
    return this.AccountdetailsForm.get('invCategory');
  }

  get invCatHoldTypCd() {
    return this.AccountdetailsForm.get('invCatHoldTypCd');
  }

  get custBankName() {
    return this.AccountdetailsForm.get('custBankName');
  }

  get custBranch() {
    return this.AccountdetailsForm.get('custBranch');
  }

  get payeeName() {
    return this.AccountdetailsForm.get('payeeName');
  }

  get custAccType() {
    return this.AccountdetailsForm.get('custAccType');
  }

  get custAccNum() {
    return this.AccountdetailsForm.get('custAccNum');
  }

  get custIfsc() {
    return this.AccountdetailsForm.get('custIfsc');
  }

  get form() {
    return this.AccountdetailsForm.value;
  }

  numberOnly(event: any) {
    this.customValidator.OnlyNumbervalidator(event);
  }

  CharacterSpacevalidator(event: any) {
    this.customValidator.CharacterSpaceValidator(event);
  }

  getAlertClass(severity: 'success' | 'info' | 'warn' | 'error'): string {
    switch (severity) {
      case 'success':
        return 'alert-success';
      case 'info':
        return 'alert-info';
      case 'warn':
        return 'alert-warning';
      case 'error':
        return 'alert-danger';
      default:
        return 'alert-info';
    }
  }

  getAlertButtonClass(severity: 'success' | 'info' | 'warn' | 'error'): string {
    switch (severity) {
      case 'success':
        return 'btn-success';
      case 'info':
        return 'btn-info';
      case 'warn':
        return 'btn-warning';
      case 'error':
        return 'btn-danger';
      default:
        return 'btn-primary';
    }
  }

  dismissAlert(): void {
    this.showAlertModal = false;
    this.activeAlert = null;
  }

  toUpperCase(event: any) {
    this.customValidator.toUpperCase(event);
  }

  characterSpaceNumberValidator(event: any) {
    this.customValidator.characterSpaceNumberValidator(event);
  }

  futureDateValidator() {
    this.customValidator.futureDateValidator();
  }

  onAutoRenewChange() {
    const autoRenewFlag = this.AccountdetailsForm.get('autoRenewFlag')?.value;
    if (autoRenewFlag === 'Y' || autoRenewFlag === 'N') {
      this.autoRenewError =
        'Dear customer, if you need automatic renewal, kindly visit the branch office.';
      // Reset the value to "N" to enforce selection of "No"
      this.AccountdetailsForm.get('autoRenewFlag')?.setValue('N');
    } else {
      this.autoRenewError = null; // Clear error when "No" is selected
    }
  }

  FloatValue(event: any) {
    this.customValidator.FloatValue(event);
  }

  ifsCodevalidator(event: any): void {
    this.customValidator.ifsCodevalidator(event); // Call the custom validator from the service
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.AccountdetailsForm.get('custIfsc')?.setValue(upperValue);
  }

  AddressValidator(event: any) {
    this.customValidator.AddressValidator(event);
  }

  branchList(): void {
    this.subscription.add(
      this.apiService.branchList().subscribe({
        next: (response: any) => {
          this.kycbranchName = response;
        },
      })
    );
  }

  getDropdownListdata(): void {
    this.subscription.add(
      this.apiService.getDropdownList().subscribe({
        next: (response: any) => {
          if (response) {
            if (response) {
              this.occupationOption = response.occupationList.map(
                (item: string) => ({
                  label: item,
                  value: item,
                })
              );
            } else {
              response = {};
            }

            // this.occupationLists =response.occupationList;
            // this.schemeLists =response.schemeList;
            // this.subtypeLists =response.subtypeList;
            // this.htmTypeLists=response.htmTypeList;
            // this.invCatLsts =response.invCatLst;
            // this.CondtionLsts =response.CondtionLst;
            // this.accTypeLstas =response.accTypeLst;
            // this.instypNames =response.instypName;
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log('An error occurred something went wrong ' + err);
        },
      })
    );
  }

  submitAccountDetails() {
    const bankName = this.AccountdetailsForm.get('custBankName')?.value;
    const branch = this.AccountdetailsForm.get('custBranch')?.value;
    const payeeName = this.AccountdetailsForm.get('payeeName')?.value;
    const accType = this.AccountdetailsForm.get('custAccType')?.value;
    const accNum = this.AccountdetailsForm.get('custAccNum')?.value;
    const ifsc = this.AccountdetailsForm.get('custIfsc')?.value;
    const fdRegId = this.authService.getResponseValueByKey('newFdRegId');
    // Validate all fields
    if (
      !bankName ||
      !branch ||
      !payeeName ||
      !accType ||
      !accNum ||
      !ifsc ||
      !fdRegId
    ) {
      alert('Please fill in all required fields ');
      return;
    }
    const data = {
      custBankName: bankName,
      custBranch: branch,
      payeeName: payeeName,
      custAccType: accType,
      custAccNum: accNum,
      custIfsc: ifsc,
      fdRegId: fdRegId,
      bankId: this.AccountdetailsForm.get('bankId')?.value
    };
    const encryptedData = this.hybridEncryptor.encrypted(JSON.stringify(data));
    this.subscription.add(
      this.apiService.saveFdBankDetails(encryptedData).subscribe({
        next: (response: any) => {

          if (
            response?.statusCode === '1002' &&
            response?.message === 'FdBankDetails details saved successfully'
          ) {
            this.showAlert('success', 'Alert', response?.message)
            this.myTrigger = true;
            this.accountVerifed = true;
            setTimeout(() => {

              this.router.navigate(['/dashboard/home']);
            }, 1000)

          } else {
            alert('Failed to update details. Please try again.');
            this.myTrigger = false;
          }
        },
        error: (err) => {
          console.error('Error fetching bank details:', err);
          alert('An error occurred while updating details.');
        },
      })
    );
  }

  pennyDropRequestDataApi() {
    const accNum = this.AccountdetailsForm.get('custAccNum')?.value;
    const ifsc = this.AccountdetailsForm.get('custIfsc')?.value;
    const fdRegId = this.authService.getResponseValueByKey('newFdRegId');
    // const remitterAcc = this.CookieService.get('remitterAcc');
    const remitterAcc = this.CustomValidatorService.getRemiterAccountNo();
    if (!accNum || !ifsc || !fdRegId || !remitterAcc) {
      alert('Please fill in all required fields.');
      return;
    }

    if (this.payeeName?.value?.toLowerCase() !== this.shortNamevalue?.toLowerCase()) {
      alert('Depositor name & Payee name are different!');
      return;
    }
    const genenUnId = this.CustomValidatorService.generateUniqueReqId();
    const requestData = {
      reqId: genenUnId,
      remitterAcc: remitterAcc,
      beneAccNum: accNum,
      beneIFSC: ifsc,
      fdRegId: fdRegId,
    };

    this.spinner.show();
    this.subscription.add(
      this.apiService
        .pennyDropRequestDataapi(
          this.hybridEncryptor.encrypted(JSON.stringify(requestData))
        )
        .subscribe({
          next: (response: any) => {
            if (response && response.statusCode === '1002') {
              const requestId = response.reqId;

              this.showAlert(
                'info',
                'Account Verification Initiated',
                'Your bank account verification is in progress. Please wait a few moments...'
              );


              setTimeout(() => {
                this.spinner.hide();
                const statusRequest = { reqId: requestId };

                this.apiService
                  .getPennyDropStatusDataapi(
                    this.hybridEncryptor.encrypted(
                      JSON.stringify(statusRequest)
                    )
                  )
                  .subscribe({
                    next: (statusResponse: any) => {
                      if (statusResponse) {
                        if (
                          statusResponse.message === 'Success' &&
                          statusResponse.statusCode === '02'
                        ) {

                          if (environment.envName === 'prod') {
                            const payeeName = this.AccountdetailsForm.get('payeeName')?.value;
                            this.checkNamesAndProceed(payeeName.toUpperCase(), statusResponse.reqId.toUpperCase())

                          } else {
                            this.showAlert('success', 'Alert', 'Bank Account Successfully verified');
                            this.myTrigger = true;
                            this.accountVerifed = false;
                          }
                        } else if (
                          statusResponse.message === 'Pending' &&
                          statusResponse.statusCode === '05'
                        ) {
                          alert('Bank Account is Pending try again');
                        } else if (
                          statusResponse.message === 'Failure' &&
                          statusResponse.statusCode === '03'
                        ) {
                          alert('Bank Account is faild try again');
                        }
                      }
                    },
                    error: (err) => {
                      console.error(' Error in getPennyDropStatus', err);
                      alert('Failed to retrieve penny drop status.');
                    },
                  });
              }, 15000);
            } else {
              console.warn('Unexpected response:', response);
              alert('Penny drop failed or returned unexpected status.');
            }
          },
        })
    );
  }

  pennydropCheckAccountNumber() {
    const data = {
      username: '289af78e-b02b-4952-b32d-710751e73826',
      password: '078841d1-9401-4724-a353-5403396f1522',
    };
    this.subscription.add(
      this.apiService
        .pennydropCheckAccountNumber(
          this.hybridEncryptor.encrypted(JSON.stringify(data))
        )
        .subscribe({
          next: (response: any) => {
            if (
              response.statusCode === '1000' &&
              response.payload?.statusCode === '2000'
            ) {
              const token = response.payload.token;

              const requestData = {
                reqId: this.FDrNo,
                remitterAcc: this.CookieService.get('remitterAcc'),
                beneAccNum: this.custAccNum?.value,
                beneIFSC: this.custIfsc?.value,
              };

              this.apiService
                .pennyDropRequest(requestData, `Bearer ${token}`)
                .subscribe({
                  next: (res: any) => {

                    const statusCode = res.statusCode || res['statusCode:'];
                    const payload = res.payload || res['payload '] || {};
                    const dataBlock = payload.data;
                    if (statusCode === '1000' && dataBlock) {
                      const requestId = dataBlock;
                      alert('Please wait while we verify your account.');
                      this.spinner.show();
                      setTimeout(() => {
                        this.spinner.hide();
                        this.apiService
                          .pennydropCheckAccountNumber(data)
                          .subscribe({
                            next: (tokenResp: any) => {
                              if (
                                tokenResp.statusCode === '1000' &&
                                tokenResp.payload?.statusCode === '2000'
                              ) {
                                const statusToken = tokenResp.payload.token;
                                const statusRequest = { reqId: requestId };
                                this.apiService
                                  .getPennyDropStatus(
                                    statusRequest,
                                    statusToken
                                  )
                                  .subscribe({
                                    next: (statusResponse: any) => {
                                      if (
                                        statusResponse.statusCode === '1000' &&
                                        statusResponse.payload
                                      ) {
                                        const payload = statusResponse.payload;
                                        const status = payload.statusCode;
                                        const message = payload.message;
                                        let data = payload.data;
                                        const payeeName =
                                          this.AccountdetailsForm.get(
                                            'payeeName'
                                          )?.value;
                                        //  data = "JAGANATHAN S";
                                        if (status === '02') {
                                          if (
                                            payeeName.toUpperCase() ===
                                            data.toUpperCase()
                                          ) {
                                            // if (data.toUpperCase() === data.toUpperCase()) {
                                            this.verfyButtonbooleanVal = true;
                                            alert(
                                              `Beneficiary account details have been successfully verified.`
                                            );
                                            this.myTrigger = true;
                                          } else {
                                            alert(
                                              `Beneficiary account name is mismatched. Please try again.`
                                            );
                                          }
                                        } else if (status === '03') {
                                          alert(` Failure\nReason: ${data}`);
                                        } else if (status === '05') {
                                          alert(
                                            `Take a few more seconds to verify; try again`
                                          );
                                        } else {
                                          alert(
                                            ` Unexpected response\nStatus Code: ${statusResponse.statusCode}\nMessage: ${statusResponse.statusMsg}`
                                          );
                                        }
                                      }
                                    },
                                    error: (err) => {
                                      console.error(
                                        ' Error in getPennyDropStatus',
                                        err
                                      );
                                      alert(
                                        'Failed to retrieve penny drop status.'
                                      );
                                    },
                                  });
                              } else {
                                alert(
                                  ' Token generation failed for status check.'
                                );
                              }
                            },
                            error: (err) => {
                              console.error(
                                ' Error generating token for status check',
                                err
                              );
                              alert(
                                'Token generation error before status check.'
                              );
                            },
                          });
                      }, 40000);
                    } else {
                      alert(' failed or response malformed.');
                    }
                  },
                  error: (err) => {
                    console.error(' Error in pennyDropRequest', err);
                    alert(
                      'Error during Account verification or verification data is empty'
                    );
                  },
                });
            } else if (response.statusCode === '1008') {
              alert(' Invalid credentials.');
            } else {
              alert(
                ' Unexpected token generation status: ' + response.statusCode
              );
            }
          },
          error: (err) => {
            console.error(' Error in pennydropCheckAccountNumber', err);
            alert('Error during account verification.');
          },
        })
    );
  }

  cleanInput(event: any): void {
    const input = event.target as HTMLInputElement;
    const sanitized = input.value.replace(/[^a-zA-Z0-9 _.\-]/g, '');
    this.AccountdetailsForm.get('neftNum')?.setValue(sanitized, {
      emitEvent: false,
    });
  }

  preventSpecialChars(event: KeyboardEvent): void {
    this.customValidator.preventSpecialChars(event);
  }

  allowEmptyFields(): boolean {
    return true;
  }
  processFormData(data: any) {
    Object.keys(data).forEach(key => {
      if (data[key] === 'select') {
        data[key] = '';
      }
    });
    return data;
  }

  saveAccountDetails() {
    if (this.areRequiredFieldsValid()) {

      this.myTrigger = true;
      this.spinner.show();

      let formValues = this.AccountdetailsForm.value;

      // ✅ Build payload similar to ekycForm
      let reqBody: any = {
        occupation: formValues.occupation,
        maritalStatus: formValues.maritalStatus,
        socialCategory: formValues.socialCategory,
        minority: formValues.minority,
        annualIncome: formValues.annualIncome,
        dob: formValues.dob,
        addLine1: formValues.address,
        state: formValues.state,
        city: formValues.city,
        pinCode: formValues.pinCode,

        fdUserEmail: formValues.emailId,

        // ✅ required from auth
        newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
        fdUserEmailFromSession: this.authService.getResponseValueByKey('fdUserEmail'),
        kycBranchName: this.AccountdetailsForm.value?.kycBranchName,
        gender: formValues.gender,
        fdUserPan: formValues.panNo,
        depositorName: formValues.shortName,
        borrowerLongName: formValues.longName,
        fdUserMobile: this.responseUser?.mobNum,
        // ✅ optional defaults if required
        customerType: 'I'
      };

      reqBody = this.processFormData(reqBody);

      this.subscription.add(
        this.apiService
          .saveFdNewUserCifDetails(
            this.hybridEncryptor.encrypted(JSON.stringify(reqBody))
          )
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();

              if (response.statusCode === '1002') {
                this.showAlert(
                  'success',
                  'Alert',
                  'Account Details Submitted Successfully'
                );

                this.profileDetailsUpdate();
              } else if (response.statusCode === '1008') {
                this.showAlert(
                  'success',
                  'Alert',
                  response.sstatusMsg || 'User Alerady Exist'
                );
                this.profileDetailsUpdate();
              }

            },
            error: (err) => {
              this.spinner.hide();
              console.error('Error:', err);
              this.showAlert(
                'error',
                'Alert',
                'Error submitting account details'
              );
            }
          })
      );

    } else {
      alert("Please fill all the mandatory fields");
    }
  }

  profileDetailsUpdate() {

    if (this.areRequiredFieldsValid()) {
      this.myTrigger = true;
      let reqBody = {
        address: this.AccountdetailsForm.value?.address,
        city: this.AccountdetailsForm.value?.city,
        state: this.AccountdetailsForm.value?.state,
        pinCode: this.AccountdetailsForm.value?.pinCode,
        occupation: this.AccountdetailsForm.value?.occupation,
        maritalStatus: this.AccountdetailsForm.value?.maritalStatus,
        socialCategory: this.AccountdetailsForm.value?.socialCategory,
        minority: this.AccountdetailsForm.value?.minority,
        annualIncome: this.AccountdetailsForm.value?.annualIncome,
        newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
        fdUserEmail: this.AccountdetailsForm.value?.emailId,
        emailID: this.AccountdetailsForm.value?.emailId,
        kycBranchName: this.AccountdetailsForm.value?.kycBranchName

      }
      this.spinner.show();
      this.subscription.add(
        this.apiService
          .saveCustAddressDetails(
            this.hybridEncryptor.encrypted(JSON.stringify(reqBody))
          )
          .subscribe({
            next: (response: any) => {

              if (response.statusCode == '1002') {
                this.showAlert(
                  'success',
                  'Alert',
                  'Personal Details Updated Successfully'
                );
                this.spinner.hide();

              }
            },
            error: (err) => {
              this.spinner.hide();
              console.log(
                'Error occurred in wudCifCreationForm details Form submitting ' +
                err
              );
            },
          })
      );
    } else {
      alert("Please fill all the mandatory fields")
    }

  }

  getDropdownListF(): void {
    this.subscription.add(
      this.apiService.getDropdownListF().subscribe({
        next: (response: any) => {


          if (response && response.state) {
            this.stateOptions = Object.entries(response.state).map(
              ([key, value]) => ({
                label: value,
                value: key,
              })
            );
          } else {
            response = {};
          }

        },
        error: (err) => {
          console.log('An error occurred, something went wrong: ' + err);
        },
      })
    );
  }

  getStateCode(stateName: string, city: String): any {
    let data = {
      state: stateName,
      district: city,
    };
    this.subscription.add(
      this.apiService.getstateCode(data).subscribe({
        next: (response: any) => {
          if (response) {
            this.AccountdetailsForm.patchValue({
              state: response,
            });
            this.checkFormFields();
            this.getcity();
            this.getcityCodedata(response, city);
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log('An error occurred something went wrong ' + err);
        },
      })
    );
  }

  getcityCodedata(stateName: string, distName: any): any {
    this.stateName = this.form.state;
    let data = {
      state: stateName,
      district: distName,
    };
    this.subscription.add(
      this.apiService.getcityCode(data).subscribe({
        next: (response: any) => {
          if (response) {
            this.AccountdetailsForm.controls['city'].setValue(response);
            this.checkFormFields();
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log('An error occurred something went wrong ' + err);
        },
      })
    );
  }


  getcity(): void {
    this.stateName = this.AccountdetailsForm.get('state')?.value;
    let data = {
      state: this.stateName,
    };
    this.subscription.add(
      this.apiService.getcity(data).subscribe({
        next: (response: any) => {
          if (response) {
            this.cityOptions = Object.entries(response.district).map(
              ([key, value]) => ({
                label: value,
                value: key,
              })
            );
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log(
            'An error occurred in getingState something went wrong ' + err
          );
        },
      })
    );
  }
  showAlert(
    severity: 'success' | 'info' | 'warn' | 'error',
    summary: string,
    detail: string
  ) {
    this.activeAlert = {
      severity: severity,
      summary: summary,
      detail: detail,
    };
    this.showAlertModal = true;
  }
  private checkNamesAndProceed(payeeName: string, bankName: string) {
    const pct = this.CustomValidatorService.nameMatchPercentage(payeeName, bankName);
    const THRESHOLD = 85;
    if (pct >= THRESHOLD) {
      this.showAlert('success', 'Success', `Your Bank account verified successfully.`);
      this.myTrigger = true;
      this.accountVerifed = false;
    } else {
      this.showAlert('error', 'Account Verification Failed', `Name mismatch  Please enter valid bank information..`);
    }
  }

  verifyIfsc(): void {
    const ifsc = this.AccountdetailsForm.get('custIfsc')?.value;

    if (!ifsc) return;

    this.subscription.add(
      this.apiService.ifscValidate(ifsc).subscribe({
        next: (response: any) => {
          if (response) {
            const bankName = response.bankName;
            const branchName = response.branchName;

            this.AccountdetailsForm.get('custBankName')?.setValue(bankName);
            this.AccountdetailsForm.get('custBranch')?.setValue(branchName);

            // ✅ Mark IFSC as verified
            this.isIfscVerified = true;

            // ✅ Clear account number after IFSC verification
            this.AccountdetailsForm.get('custAccNum')?.reset();

            this.AccountdetailsForm.get('custBankName')?.disable();
            this.AccountdetailsForm.get('custBranch')?.disable();

          }

        },
        error: (err: any) => {
          console.log('Error: ', err);

          this.isIfscVerified = false;

          if (err.status == 404) {
            this.showAlert('error', 'IFSC Verification', `Given IFSC code is Invalid`);
            this.AccountdetailsForm.get('custIfsc')?.setValue("");
          }
        },
      })
    );
  }

  canEnableSubmit(): boolean {
    if (this.accountVerifed) {
      return false;
    }

    // ✅ CIF → ignore form validation
    if (this.isCIFCustomer) {
      return true;
    }

    // ✅ Non-CIF → full validation
    if (this.AccountdetailsForm.invalid) {
      return false;
    }

    // ✅ Non-CIF → must have edited & successfully verified the bank details
    return !this.bankEditTrigger;
  }

  updateValidatorsForCIF(): void {
    const requiredFields = [
      'custBankName',
      'custBranch',
      'payeeName',
      'custAccType',
      'custAccNum',
      'custIfsc'
    ];

    if (this.isCIFCustomer) {
      // ✅ Remove validators
      requiredFields.forEach(field => {
        const control = this.AccountdetailsForm.get(field);
        control?.clearValidators();
        control?.updateValueAndValidity();
      });
    } else {
      // ✅ Add validators back
      requiredFields.forEach(field => {
        const control = this.AccountdetailsForm.get(field);
        control?.setValidators(Validators.required);
        control?.updateValueAndValidity();
      });
    }
  }

  getMissingRequiredFields(): string[] {
    const requiredFields = [
      { key: 'state', label: 'State' },
      { key: 'pinCode', label: 'Pin Code' },
      { key: 'occupation', label: 'Occupation' },
      { key: 'maritalStatus', label: 'Marital Status' },
      { key: 'dob', label: 'Date of Birth' },
      { key: 'gender', label: 'Gender' },
      { key: 'city', label: 'City' },
      { key: 'address', label: 'Address' }
    ];

    let missingFields: string[] = [];
    requiredFields.forEach(field => {
      const control = this.AccountdetailsForm.get(field.key);
      // ✅ check value manually (even if disabled)
      const value = control?.value;
      if (!value || value.toString().trim() === '') {
        missingFields.push(field.label);
      }
    });
    return missingFields;
  }




}








//  userFdDetailsView(): void {
//     const data = {
//       fdUserId: this.authService.getResponseValueByKey('fdUserId'),
//       newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
//       entryId: this.authService.getResponseValueByKey('entryId'),
//       cif: this.authService.getResponseValueByKey('cif'),
//       kycBranchName: this.authService.getResponseValueByKey(''),
//     };
//     this.spinner.show();
//     this.subscription.add(
//       this.apiService
//         .userFdDetailsView(this.hybridEncryptor.encrypted(JSON.stringify(data)))
//         .subscribe({
//           next: (response: any) => {
//             if (response) {
//               this.responseUser = response;
//               this.shortNamevalue = response.shortName;
//               this.AccountdetailsForm.get('longName')?.setValue(
//                 response.firDepoName
//               );
//               this.AccountdetailsForm.get('shortName')?.setValue(
//                 response.shortName
//               );
//               this.AccountdetailsForm.get('cifCd')?.setValue(response.cif);
//               this.AccountdetailsForm.get('panNo')?.setValue(response.panNo);
//               this.AccountdetailsForm.get('address')?.setValue(
//                 response.address
//               );
//               this.AccountdetailsForm.get('city')?.setValue(response.city);
//               this.AccountdetailsForm.get('state')?.setValue(response.state);
//               this.AccountdetailsForm.get('pinCode')?.setValue(
//                 response.pinCode
//               );
//               this.AccountdetailsForm.get('occupation')?.setValue(
//                 response.occupation
//               );
//               this.AccountdetailsForm.get('custCode')?.setValue(
//                 response.custCode
//               );

//               if (response && response.dob) {
//                 // Ensure the input is a string and replace slashes with dashes
//                 const rawDob = String(response.dob).trim(); // "03/06/1992"
//                 const normalizedDob = rawDob.replace(/\//g, '-'); // "03-06-1992"
//                 const dobParts = normalizedDob.split('-'); // [dd, MM, yyyy]

//                 if (dobParts.length === 3) {
//                   const formattedDob = `${dobParts[2]}-${dobParts[1]}-${dobParts[0]}`; // yyyy-MM-dd
//                   this.AccountdetailsForm.get('dob')?.setValue(formattedDob);
//                 } else {
//                   console.warn('Unexpected DOB format:', response.dob);
//                   this.AccountdetailsForm.get('dob')?.setValue(null); // or fallback
//                 }
//               }
//               this.AccountdetailsForm.get('gender')?.setValue(response.gender);
//               this.AccountdetailsForm.get('mobNum')?.setValue(response.mobNum);
//               this.AccountdetailsForm.get('emailId')?.setValue(response.email);
//               this.AccountdetailsForm.get('custCode')?.setValue(
//                 response.custCode
//               );
//             }
//             // for alerting the user
//             this.checkFormFields();
//             this.spinner.hide();
//           },
//           error : (error:any)=>{
//             console.log("Error fetching user details at personal details page ", error.message);
//             this.spinner.hide();
//           }
//         })
//     );
//   }

// getbankDetails(): void {
//     const data = {
//       fdRegId: this.authService.getResponseValueByKey('newFdRegId'),
//     };
//     const encryptedPayload = this.hybridEncryptor.encrypted(
//       JSON.stringify(data)
//     );
//     this.spinner.show();
//     this.subscription.add(
//       this.apiService.getbankDetails(encryptedPayload).subscribe({
//         next: (response: any) => {

//           if (response && response.length > 0) {
//             const bankDetails = response[0];
//             this.AccountdetailsForm.patchValue({
//               custAccType: bankDetails.custAccType?.toLowerCase(), // Ensure it matches the dropdown value
//               custBankName: bankDetails.custBankName,
//               custBranch: bankDetails.custBranch,
//               payeeName: bankDetails.payeeName,
//               custAccNum: bankDetails.custAccNum,
//               custIfsc: bankDetails.custIfsc,
//               bankId: bankDetails.bankId,
//             });
//           }
//           // this.spinner.hide();
//         },
//         error: (err) => {
//           // this.spinner.hide();
//           console.error('Error fetching bank details:', err);
//         },
//       })
//     );
//   }





