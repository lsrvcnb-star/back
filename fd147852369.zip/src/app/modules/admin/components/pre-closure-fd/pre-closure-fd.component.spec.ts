import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreClosureFdComponent } from './pre-closure-fd.component';

describe('PreClosureFdComponent', () => {
  let component: PreClosureFdComponent;
  let fixture: ComponentFixture<PreClosureFdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreClosureFdComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreClosureFdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
