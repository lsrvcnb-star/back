import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { Subscription } from 'rxjs';
import { ApiService } from '../../../../service/api.service';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { NgxSpinnerModule } from "ngx-spinner";
import {NgxSpinnerService} from "ngx-spinner";
import { AuthService } from '../../../../service/auth.service';
import { FdCacheService } from '../../../../service/fd-cache.service';

interface FDApplication {
  entryId: string;
  entryDt: string;
  period: number;
  intRate: number;
  amount: number;
  presentFDValue: number;
  autoRenewFlag: string;
  strFdrNo: string;
  strAppStatus: string;
  fdappStatus: string;
  pdfDocUrl: string;
  saveFlag: string;
  operation?: 'view' | 'edit'; // Optional operation property for conditional rendering
}

@Component({
  selector: 'app-pre-closure-fd',
  standalone: true,
  imports: [FormsModule,CommonModule,RouterModule,NgxSpinnerModule],
  templateUrl: './pre-closure-fd.component.html',
  styleUrl: './pre-closure-fd.component.scss'
})
export class PreClosureFdComponent implements OnInit {
   constructor(
    private apiService :ApiService,
    private CookieService : CookieService,
    private spinner: NgxSpinnerService,
    private authService:AuthService,
    private fdCacheService: FdCacheService,
     ){} 

     fdEntryResponse: any = [];
 cifId : any;
  subscription: Subscription = new Subscription();
  public hybridEncryptor!:HybridEncryptor;
  ngOnInit(): void {
    this.spinner.show();
    setTimeout(() => {
               this.spinner.hide();
             }, 1000)
    this.hybridEncryptor = new HybridEncryptor();
    this.getFdEntryListDetails();  
  }
  getFdEntryListDetails(): void {
    const fdUserId = this.authService.getResponseValueByKey("fdUserId");
    this.subscription.add(
      this.fdCacheService.getUserFullDetails(fdUserId).subscribe({
        next: (response: any) => {
          if(response){
             this.cifId = response.cif ;
          }
        }
      })
    );
    const data = {
      fdUserId : this.authService.getResponseValueByKey("fdUserId"),
    } 
    this.subscription.add(
        this.apiService.getFdPrecloserDashboard(this.hybridEncryptor.encrypted(JSON.stringify(data))).subscribe({
          next: (response: any) => {
            if(response){
              this.fdData = response ;
            }
           }
        })
      );
    }




    
 fdData: FDApplication[] = this.fdEntryResponse ;
 
  printReceipt(fdrNumber: string) {
   
  }
 
  preClose(fdrNumber: string) {
    this.apiService.setPreClosure(fdrNumber);
    
  }

}
