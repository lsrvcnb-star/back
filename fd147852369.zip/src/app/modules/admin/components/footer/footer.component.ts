import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AppVersion } from '../../../../config';


@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss'
})
export class FooterComponent  {
  
  test : Date = new Date();
  appversion :string = AppVersion;

}
