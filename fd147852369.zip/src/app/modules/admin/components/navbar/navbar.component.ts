import { Component, OnInit, Renderer2, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ROUTES } from '../sidebar/sidebar.component';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { AuthGuard } from '../../../../service/authGuard';
import { AuthService } from '../../../../service/auth.service';
import { Subscription } from 'rxjs';
import { ApiService } from '../../../../service/api.service';
import { HybridEncryptor } from '../../../../Services/HybridEncryptor';
import { AccessibilityFontSizeComponent } from '../../../../components/accessibility-font-size/accessibility-font-size.component';
import { FdCacheService } from '../../../../service/fd-cache.service';


@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule, NgbModule, AccessibilityFontSizeComponent],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent implements OnInit {
  private listTitles!: any[];
  location: Location;
  private nativeElement!: Node;
  private toggleButton!: HTMLElement;
  private sidebarVisible!: boolean;
  public FDUserName!: string;


  public isCollapsed = true;
  @ViewChild("navbar-cmp", { static: false }) button: any;
  subscription: Subscription = new Subscription();
  showHome: boolean = false;

  constructor(location: Location, private renderer: Renderer2, private element: ElementRef, private router: Router, private cookieService: CookieService, private authgud: AuthGuard, private authService: AuthService, private apiService: ApiService, private hybridEncryptor: HybridEncryptor, private fdCacheService: FdCacheService) {
    this.location = location;
    this.nativeElement = element.nativeElement;
    this.sidebarVisible = false;

  }

  ngOnInit() {
    this.showHome = false
    this.FDUserName = this.authService.getFdUserName();
    this.listTitles = ROUTES.filter(listTitle => listTitle);
    var navbar: HTMLElement = this.element.nativeElement;
    this.toggleButton = navbar.getElementsByClassName('navbar-toggle')[1] as HTMLElement
    this.router.events.subscribe((event) => {
      this.sidebarClose();
    });
   // this.activeAccordion();
  }
  getTitle() {

    var titlee = this.location.prepareExternalUrl(this.location.path());
    if (titlee.includes("kycVerification")) {
      titlee = "KYC VERIFICATION"

    } if (titlee.includes("WudCifCreationData")) {

      titlee = "USER DETAILS"

    } if (titlee.includes("dashboard")) {
      titlee = "WELCOME TO SIDBI FD"

    } if (titlee.includes("kycVerification")) {
      titlee = "kyc verfication"
    }
    if (titlee.charAt(0) === '#') {
      titlee = titlee.slice(1);
    }
    for (var item = 0; item < this.listTitles.length; item++) {
      if (this.listTitles[item].path === titlee) {
        return this.listTitles[item].title;

      }
    }
    return titlee;
  }

  getTitleOne() {

    return "FIXED DEPOSIT"


  }

  logout() {
    this.authgud.logout();
  }

  sidebarToggle() {
    if (this.sidebarVisible === false) {
      this.sidebarOpen();
    } else {
      this.sidebarClose();
    }
  }
  sidebarOpen() {
    const toggleButton = this.toggleButton;
    const html = document.getElementsByTagName('html')[0];
    const mainPanel = <HTMLElement>document.getElementsByClassName('main-panel')[0];
    setTimeout(function () {
      toggleButton.classList.add('toggled');
    }, 500);

    html.classList.add('nav-open');
    if (window.innerWidth < 991 && mainPanel) {
      // CSP-safe: previously `mainPanel.style.position = 'fixed'` which sets the
      // inline style attribute and is blocked by `style-src 'self'`. Use
      // Renderer2 to add a CSS class instead (.main-panel-fixed defined in
      // src/styles.scss).
      this.renderer.addClass(mainPanel, 'main-panel-fixed');
    }
    this.sidebarVisible = true;
  };
  sidebarClose() {
    const html = document.getElementsByTagName('html')[0];
    const mainPanel = <HTMLElement>document.getElementsByClassName('main-panel')[0];
    if (window.innerWidth < 991 && mainPanel) {
      setTimeout(() => {
        // CSP-safe equivalent of `mainPanel.style.position = ''`
        this.renderer.removeClass(mainPanel, 'main-panel-fixed');
      }, 500);
    }
    this.toggleButton?.classList?.remove('toggled');
    this.sidebarVisible = false;
    html.classList?.remove('nav-open');
  };
  collapse() {
    this.isCollapsed = !this.isCollapsed;
    const navbar = document.getElementsByTagName('nav')[0];
    if (!this.isCollapsed) {
      navbar.classList?.remove('navbar-transparent');
      navbar.classList?.add('bg-white');
    } else {
      navbar.classList?.add('navbar-transparent');
      navbar.classList?.remove('bg-white');
    }

  }

  activeAccordion(): any {
    let fdUserId = this.authService.getResponseValueByKey('fdUserId');
    this.subscription.add(
      this.fdCacheService
        .getUserDetails(fdUserId).subscribe({
          next: (response: any) => {
            if (response != null) {
              if ((response.aadhaarVirifystsFlag === 'Y' &&
                response.panverify_Flag === 'Y') || response.empKycFlag === 'Y' || Number(response.vkycFlag) == 1) {
                this.showHome = true;
              } else {
                this.showHome = false;
              }



              // set Aadhar number

            }
          },
          error: (err) => {
            console.log('Error occurred in gettingLocalStorageData' + err);
          },
        })
    );
  }
}
