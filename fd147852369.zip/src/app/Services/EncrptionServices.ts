import * as forge from 'node-forge';
import { publicKeyPem } from '../config';


export class EncrptionServices {

  publicKeypemone!: forge.pki.PublicKey | null;
  encryptedDataValue: any;
  encryptedData: any;
  public EncrptionUsingpublickey(data: any): any {
    try {
      const publicKeypemone = this.getPublicKey(publicKeyPem);
      if (!publicKeypemone) {
        throw new Error('Public key extraction failed');
      }
      // ✅ Limit data size based on RSA key size
      const maxLength = 190; // For 2048-bit keys (adjust if needed)
      const truncatedData = data.substring(0, maxLength);
 
      // Encrypt the truncated data
      const encryptedBytes = (publicKeypemone as any).encrypt(
        forge.util.encodeUtf8(truncatedData),
        'RSA-OAEP',
        {
md: forge.md.sha256.create(),
        }
      );
 
      const encryptedTextBase64 = forge.util.encode64(encryptedBytes);
      this.encryptedData = encryptedTextBase64;
      this.encryptedDataValue = this.encryptedData;
 
    } catch (error) {
      console.error('Encryption error:', error);
    }
    return this.encryptedDataValue;
  }
 
  public getPublicKey(certificatePem: string): forge.pki.PublicKey | null {
    try {
      const cleanedCertificate = certificatePem
        .replace('-----BEGIN CERTIFICATE-----', '')
        .replace('-----END CERTIFICATE-----', '')
        .replace(/\s/g, ''); // Removes all whitespace
 
      const decodedCert = forge.util.decode64(cleanedCertificate);
      const asn1 = forge.asn1.fromDer(decodedCert);
      const cert = forge.pki.certificateFromAsn1(asn1);
 
      return cert.publicKey;
    } catch (error) {
      console.error('Error extracting public key from certificate:', error);
      return null;
    }
  }

}
