import * as forge from 'node-forge';
import { publicKeyPem } from '../config';
import {privateKeyPem} from '../config'

export class HybridEncryptor {
    decrypted!:any // default: public
    encryptedKey!: any;
    encryptedData!: any;
    iv!: any;
    publicKeypemone!: forge.pki.PublicKey | null;
    encryptedDataValue: any;
    public encrypted(data: string){
      try {
        // Step 1: Extract RSA Public Key from Certificate PEM
       const publicKey = this.getPublicKey(publicKeyPem);
        if (!publicKey) {
          throw new Error('Failed to extract public key');
        }
           // Step 2: Generate AES key and IV
        const aesKey = forge.random.getBytesSync(32); // AES-256
        const iv = forge.random.getBytesSync(16);     // 128-bit IV
           // Step 3: Encrypt data using AES
        const cipher = forge.cipher.createCipher('AES-CBC', aesKey);
        cipher.start({ iv });
        cipher.update(forge.util.createBuffer(data, 'utf8'));
        cipher.finish();
        const encryptedBytes = cipher.output.getBytes();
   
        // Step 4: Encrypt AES key with RSA public key
        const encryptedKeyBytes = (publicKey as any).encrypt(aesKey, 'RSA-OAEP', {
            md: forge.md.sha256.create()
            });
   
        // Step 5: Base64 encode all
        const result = {
          encryptedKey: forge.util.encode64(encryptedKeyBytes),
          encryptedData: forge.util.encode64(encryptedBytes),
          iv: forge.util.encode64(iv)
        };
        this.encryptedKey = result.encryptedKey;
        this.encryptedData = result.encryptedData;
        this.iv = result.iv;
          return result;
   
      } catch (error) {
        console.error('Hybrid encryption error:', error);
        return null;
      }
    }

     private getPublicKey(certificatePem: string): forge.pki.PublicKey | null {
      try {
        const cleanedCertificate = certificatePem
          .replace('-----BEGIN CERTIFICATE-----', '')
          .replace('-----END CERTIFICATE-----', '')
          .replace(/\s/g, '');
        const decodedCert = forge.util.decode64(cleanedCertificate);
        const asn1 = forge.asn1.fromDer(decodedCert);
        const cert = forge.pki.certificateFromAsn1(asn1);
        return cert.publicKey;
      } catch (error) {
        console.error('Error extracting public key:', error);
        return null;
      }
    }


decryptHybridData(encryptedKey: string, encryptedData: string, ivB64: string): string | null {
  try {
    const encryptedKeyBytes = forge.util.decode64(encryptedKey);
    const encryptedDataBytes = forge.util.decode64(encryptedData);
    const ivBytes = forge.util.decode64(ivB64);
     const privateKey = forge.pki.privateKeyFromPem(privateKeyPem); // Make sure this is loaded correctly
     const aesKeyBytes = privateKey.decrypt(encryptedKeyBytes, 'RSA-OAEP', {
md: forge.md.sha256.create(),
      mgf1: {
md: forge.md.sha256.create()
      },
      label: null  // ✅ required to match Java OAEP with SHA-256
    });
     const decipher = forge.cipher.createDecipher('AES-CBC', aesKeyBytes);
    decipher.start({ iv: ivBytes });
    decipher.update(forge.util.createBuffer(encryptedDataBytes));
    const success = decipher.finish();
     if (success) {
      return decipher.output.toString();
    } else {
      console.error('AES decryption failed');
      return "error: decryption failed";
    }
 
  } catch (err) {
    console.error('Decryption error:', err);
    return "error : decryption failed";
  }
}

newdecryptHybridData(
  response: { encryptedKey: string; encryptedData: string; iv: string },
  hybridEncryptor: HybridEncryptor
): any {
  const keyBytes = forge.util.decode64(response.encryptedKey);
  const dataBytes = forge.util.decode64(response.encryptedData);
  const ivBytes = forge.util.decode64(response.iv);

  const privateKey = forge.pki.privateKeyFromPem(privateKeyPem);
  const aesKey = privateKey.decrypt(keyBytes, 'RSA-OAEP', {
    md: forge.md.sha256.create(),
    mgf1: { md: forge.md.sha256.create() },
    label: null,
  });

  const decipher = forge.cipher.createDecipher('AES-CBC', aesKey);
  decipher.start({ iv: ivBytes });
  decipher.update(forge.util.createBuffer(dataBytes));

  if (!decipher.finish()) {
    throw new Error('AES decryption failed');
  }

  return JSON.parse(decipher.output.toString());
}

}

