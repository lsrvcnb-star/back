import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageFDAppComponent } from './manage-fdapp.component';

describe('ManageFDAppComponent', () => {
  let component: ManageFDAppComponent;
  let fixture: ComponentFixture<ManageFDAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageFDAppComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageFDAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
