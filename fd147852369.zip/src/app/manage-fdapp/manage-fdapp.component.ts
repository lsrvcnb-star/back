import { Component, Input, OnInit, Type, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../service/api.service';
import { HybridEncryptor } from '../Services/HybridEncryptor';
import { CookieService } from 'ngx-cookie-service';
import { PreClosureFormComponent } from '../modules/admin/components/pre-closure-form/pre-closure-form.component';
import { clippingParents } from '@popperjs/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { forkJoin, Observable, switchMap } from 'rxjs';
import { AuthService } from '../service/auth.service';
import { SanitizeInputDirective } from '../sanitize-input.directive';
import { FdCacheService } from '../service/fd-cache.service';




@Component({
  selector: 'app-manage-fdapp',
  standalone: true,
  imports: [CommonModule, FormsModule, PreClosureFormComponent, SanitizeInputDirective],
  templateUrl: './manage-fdapp.component.html',
  styleUrl: './manage-fdapp.component.scss',
})
// ManageFDAppComponent
export class ManageFDAppComponent implements OnInit {
  @Input() PreCloseFDRNo: any;

  @ViewChild(PreClosureFormComponent)
  childComponent!: PreClosureFormComponent;

  fdData: any[] = [];
  nomineeList: any[] = [];
  globalFilter: string = '';
  expandedRows: boolean[] = [];
  selectedFdDetails: any = null;
  fdBankDetails: any = null;
  fdUserName: string = '';

  currentSortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  fdUserId: string = '';
  fdErrorMessage: string = '';
  fdEmptyMessage: string = '';
  cifId: any;
  showModal: boolean = false;
  selectedFD: any = null;
  selectedIndex: number = -1;
  closureReason: string = '';
  today: Date = new Date();
  showPrematureAlert: boolean = false;
  showReasonAlert: boolean = false;
  showSuccessAlert: boolean = false;
  preClosefdData: any = null;
  message: string = '';
  jointHoldersList: any = [];
  primaryGuardianList: any[] = [];
  userPan: any;
  fdRegIdView: any;
  constructor(
    private apiService: ApiService,
    private hybridEncryptor: HybridEncryptor,
    private cookieService: CookieService,
    private modalService: NgbModal,
    private authService: AuthService,
    private fdCacheService: FdCacheService,
  ) { }


  ngOnInit(): void {
    this.fdUserId = this.authService.getResponseValueByKey('fdUserEmail') || '';
    if (this.fdUserId) {

      this.fdCacheService.getUserDetails(this.fdUserId).subscribe({
        next: (response: any) => {
          this.userPan = response['fdUserPan']
          this.fdRegIdView = response?.newFdRegId
          const fdEntryListReq = {
            cif: "",
            fdUserPan: response['fdUserPan'],
          };
          const offlineFDRequest = {
            fdUserPan: response['fdUserPan'], //"AKCPB1261C",
            newFdRegId: response['newFdRegId'], // "222222222"
            fdUserId: response['fdUserId']
          };

          this.cifId = response['custCifId'] ?? response['custCifId']

          forkJoin([
            this.fetchFdEntryListDetails(fdEntryListReq),
            this.getOfflineFdDetails(offlineFDRequest)
          ]).subscribe({
            next: ([onlineFDs, offlineFDs]: any[]) => {
              // const combinedFDs = [...offlineFDs.fdrView, ...onlineFDs];
              
              // Step 1: Collect online FDR numbers (strFdrNo)
              const onlineFdrNos = new Set(
                (onlineFDs || [])
                  .map((fd: any) => fd.strFdrNo)
                  .filter((no: any) => !!no)
              );

              // Step 2: Filter offline FDs using fdrNo
              const filteredOfflineFDs = (offlineFDs?.fdrView || []).filter((fd: any) => {
                const isDuplicate = onlineFdrNos.has(fd.fdrNo);

                if (isDuplicate) {
                  console.log('Skipped duplicate offline FD:', fd.fdrNo);
                }

                return !isDuplicate;
              });

              // Step 3: Attach source flag explicitly (recommended ✅)
              const combinedFDs = [
                ...(onlineFDs || []).map((fd: any) => ({
                  ...fd,
                  _source: 'direct'
                })),
                ...filteredOfflineFDs.map((fd: any) => ({
                  ...fd,
                  _source: 'offline'
                }))
              ];



              if (!combinedFDs || combinedFDs.length === 0) {
                this.fdEmptyMessage = 'There are no FDs created for this account. Kindly continue to create a new FD.';
                this.fdData = [];
                return;
              }

              this.fdData = combinedFDs
                .filter(entry => entry.saveFlag === "02" || entry.status == 'APPROVED / LIVE' || entry.status == 'MATURED AND NOT PAID' || entry.status == 'LIVE')
                .map((entry, index) => {
                  const principal = parseFloat(entry.amount ?? '0');
                  const rate = parseFloat(entry.intRate ?? '0');
                  const tenureMonths = parseFloat(entry.period ?? '0');
                  const tenureYears = tenureMonths / 12;
                  const interestEarned = principal * (rate / 100) * tenureYears;
                  const calculatedMaturityAmount = principal + interestEarned;

                  let calculatedMaturityDate: Date | null = null;
                  if (entry.entryDt) {
                    const startDate = new Date(entry.entryDt);
                    if (!isNaN(startDate.getTime())) {
                      startDate.setMonth(startDate.getMonth() + tenureMonths);
                      calculatedMaturityDate = startDate;
                    }
                  }

                  // ---- Normalize maturityAmount (TOP-LEVEL) ----
                  const maturityAmountRawTop =
                    entry.fdrMaturityAmt && entry.fdrMaturityAmt !== 'null'
                      ? parseFloat(entry.fdrMaturityAmt)
                      : calculatedMaturityAmount;

                  const maturityAmountRoundedTop = this.roundToNearestRupee(maturityAmountRawTop);
                  const maturityAmountDisplayTop = this.toTwoDecimals(maturityAmountRoundedTop);

                  // ---- Normalize maturityAmount (DETAILS) ----
                  const maturityAmountRawDetails =
                    entry.fdrMaturityAmt && entry.fdrMaturityAmt !== 'null'
                      ? parseFloat(entry.fdrMaturityAmt)
                      : calculatedMaturityAmount;

                  const maturityAmountRoundedDetails = this.roundToNearestRupee(maturityAmountRawDetails);
                  const maturityAmountDisplayDetails = this.toTwoDecimals(maturityAmountRoundedDetails);




                  return {
                    no: index + 1,
                    scheme: entry.schemeCd ?? entry.scheme ?? '',
                    depositedAmount: entry.amount ?? entry.fdrAmount ?? '',
                    maturityAmount: maturityAmountDisplayDetails,
                    maturityDate: entry.fdrMaturityDate && entry.fdrMaturityDate !== 'null'
                      ? this.parseDate(entry.fdrMaturityDate)
                      : entry.maturityDt && entry.maturityDt !== 'null'
                        ? this.parseDate(entry.maturityDt)
                        : calculatedMaturityDate,

                    interestRate: entry.intRate ? `${entry.intRate} %` : '',
                    autoRenewal: entry.autoRenewFlag == 'Y' ? 'YES' : entry.autoRenewFlag ?? '',
                    status: entry.fdappStatus ?? entry.status ?? '',
                    source: entry._source,
                    invCatHoldTypCd: entry.invCatHoldTypCd ?? entry.invCatHoldTypCd ?? '',
                    jointHolName: entry.jointHolName ?? entry.jointHolName ?? '',
                    startDate: entry.entryDt
                      ? this.parseDate(entry.entryDt)
                      : entry.depositDt
                        ? this.parseDate(entry.depositDt)
                        : '',

                    details: {
                      startDate: entry.entryDt
                        ? this.parseDate(entry.entryDt)
                        : entry.depositDt
                          ? this.parseDate(entry.depositDt)
                          : '',

                      depositAmount: entry.amount ?? entry.fdrAmount ?? '',
                      period: entry.period ?? entry.tenureInMths ?? '',
                      type: entry.schemeCd ?? '',
                      repaymentAccount: entry.custAccNum ?? '',
                      branchCd: entry.branchCd ?? '',
                      nom1Name: entry.nom1Name ?? '',
                      nom1Percent: entry.nom1Percent ?? '',
                      nom2Name: entry.nom2Name ?? '',
                      nom2Percent: entry.nom2Percent ?? '',
                      nom3Name: entry.nom3Name ?? '',
                      nom3Percent: entry.nom3Percent ?? '',
                      maturityDate: entry.fdrMaturityDate && entry.fdrMaturityDate !== 'null'
                        ? this.parseDate(entry.fdrMaturityDate)
                        : entry.maturityDt && entry.maturityDt !== 'null'
                          ? this.parseDate(entry.maturityDt)
                          : calculatedMaturityDate,

                      maturityAmount: maturityAmountDisplayDetails,
                      interestRate: entry.intRate ?? '',
                      autoRenewal: entry.autoRenewFlag ?? '',
                      entryId: entry.entryId ?? entry.fdrNo ?? '',
                      source: entry?.saveFlag == '02' ? 'direct' : 'offline',
                      offlineNomineeList: entry?.fdrViewNominee,
                      invCatHoldTypCd: entry.invCatHoldTypCd ?? entry.invCatHoldTypCd ?? '',
                      jointHolName: entry.jointHolName ?? entry.jointHolName ?? '',
                    },
                    entryId: entry?.entryId,
                  };
                });

              this.expandedRows = new Array(this.fdData.length).fill(false);
              this.fdErrorMessage = '';
              this.fdEmptyMessage = '';
            },
            error: (err) => {
              console.error('Error fetching FD details:', err);
              this.fdErrorMessage = '⚠️ An unexpected error occurred. Please try again later.';
              this.fdData = [];
            }
          });
        },
        error: (err) => {
          console.error('Error fetching User details:', err);
        }
      });

      this.apiService.currentPreCloseMessage$.subscribe(msg => {
        if (msg === 'Closed') {
          this.closeModal();
          window.location.reload();
        }
      });
    }
  }



  // Rounds .50 and above up, below .50 down, then returns integer rupees
  private roundToNearestRupee(amount: any): number {
    const n = parseFloat(amount ?? '0');
    if (isNaN(n)) return 0;
    return Math.round(n); // Standard half-up for positive numbers
  }

  // Returns a Date object for the value, or null if it cannot be parsed.
  // The component stores Date objects (not locale-formatted strings) so that
  // the Angular `date` pipe in the template parses them deterministically.
  private parseDate(value: any): Date | null {
    if (value === null || value === undefined || value === '') return null;
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  // Ensures visual .00 when needed
  private toTwoDecimals(amount: number): string {
    return amount.toFixed(2);
  }

  fetchFdEntryListDetails(req: any): Observable<any[]> {
    return this.apiService.getFdEntryListDetails(
      this.hybridEncryptor.encrypted(JSON.stringify(req))
    );
  }

  getOfflineFdDetails(reqData: any): Observable<any[]> {
    return this.apiService.getOfflineFdDetails(
      this.hybridEncryptor.encrypted(JSON.stringify(reqData))
    );
  }

  filteredAndSortedData(): any[] {
    let filtered = this.fdData;

    if (this.globalFilter.trim()) {
      const filter = this.globalFilter.toLowerCase();
      filtered = filtered.filter(
        (fd) =>
          fd.scheme.toLowerCase().includes(filter) ||
          fd.status.toLowerCase().includes(filter) ||
          fd.no.toString().includes(filter)
      );
    }

    if (this.currentSortColumn === 'status') {
      filtered = [...filtered].sort((a, b) => {
        const valA = a.status?.toLowerCase() ?? '';
        const valB = b.status?.toLowerCase() ?? '';
        return this.sortDirection === 'asc'
          ? valA.localeCompare(valB)
          : valB.localeCompare(valA);
      });
    }

    return filtered;
  }

  openDetailsModal(content: any, fdDetails: any): void {
    this.selectedFdDetails = fdDetails;
    const fdId = fdDetails.entryId;
    const fdUserDtlsId = this.authService.getResponseValueByKey('fdUserDtlsId');
    const cifNo = this.cifId ? this.cifId : '';
    const bankReq = { fdRegId: fdUserDtlsId };
    const nomineeReq = { fdId };
    const jointHolderReq = {
      entryId: fdId,
      fdUserId: this.fdUserId,
      cif: cifNo
    }
    this.fdCacheService
      .getUserDetails(this.fdUserId)
      .pipe(
        switchMap((userRes: any) => {
          this.fdUserName = userRes?.fdUserName ?? '';
          return forkJoin({
            bank: this.apiService.getbankDetails(
              this.hybridEncryptor.encrypted(JSON.stringify(bankReq))
            ),
            nominees: this.apiService.getFdNomineeDetails(
              this.hybridEncryptor.encrypted(JSON.stringify(nomineeReq))
            ),
            jointHoldersList: this.apiService.getFDJointHoldersDetails(
              this.hybridEncryptor.encrypted(JSON.stringify(jointHolderReq))
            ),
          });
        })
      )
      .subscribe({
        next: ({ bank, nominees, jointHoldersList }) => {
          this.fdBankDetails = bank[0];
          this.nomineeList = nominees;
          this.jointHoldersList = this.findHolderAndGuaridan(jointHoldersList);
          if (this.selectedFdDetails.source == 'offline') {
            this.nomineeList = this.selectedFdDetails.offlineNomineeList
          }
          this.modalService.open(content, { centered: true, size: 'lg' });
        },
        error: (err) => console.error('Error loading FD modal data', err),
      });
  }

  findHolderAndGuaridan(list: any): any[] {
    let gurndian: any[] = [];

    // ✅ Reset output lists first
    this.jointHoldersList = [];
    this.primaryGuardianList = [];

    if (list?.fdJointHoldDetails?.length > 0) {

      // ✅ Remove duplicates based on holdId before proceeding
      const uniqueHolders = list.fdJointHoldDetails.filter(
        (item: any, index: number, self: any[]) =>
          index === self.findIndex((x: any) => x?.holdId === item?.holdId)
      );

      const jointHolders = uniqueHolders.filter(
        (val: any) => val?.guardFlag === 'N'
      );

      const guardians = uniqueHolders.filter(
        (val: any) => val?.guardFlag === 'Y'
      );

      this.jointHoldersList = jointHolders
        .map((holder: any) => {
          const guardian = guardians.find(
            (g: any) => g.jointGuardMapFlag === holder.pan
          );

          const holderWithGuardianFlag = guardian
            ? { ...holder, hasGuardian: true }
            : holder;

          if (guardian) {
            guardians.splice(guardians.indexOf(guardian), 1);

            return [
              holderWithGuardianFlag,
              { ...guardian, isGuardian: true }
            ];
          } else {
            return [holderWithGuardianFlag];
          }
        })
        .flat();

      this.primaryGuardianList = guardians.filter(
        (res: any) => res.jointGuardMapFlag === this.userPan
      );

      console.log(this.primaryGuardianList, this.jointHoldersList);
    }

    return this.jointHoldersList;
  }


  downloadPDF(entryId: any) {
    this.apiService.downloadFdrePort(entryId).subscribe({
      next: (response: any) => {
        if (response.status == '200') {
          const blob = new Blob([response.body], { type: response.headers.get('Content-Type') });
          const contentDisposition = response.headers.get('Content-Disposition');
          let filename = contentDisposition
            ? contentDisposition.split('filename=')[1].trim()
            : 'FD_APPLICATION_FORM.pdf';
          const link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = filename;
          link.click();
          // Clean up the URL object
          window.URL.revokeObjectURL(link.href);

        }
      }, error: (error) => {
        console.error('Error downloading PDF:', error);
      }
    });
  }






  sortBy(column: string): void {
    if (column !== 'status') return;

    if (this.currentSortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.currentSortColumn = column;
      this.sortDirection = 'asc';
    }
  }

  sortIcon(column: string): string {
    if (column !== 'status') return '';
    if (this.currentSortColumn !== column) return '&#9650;'; // Upward carrot ▲
    return this.sortDirection === 'asc' ? '&#9650;' : '&#9660;'; // ▲ or ▼
  }

  toggleRow(index: number): void {
    this.expandedRows[index] = !this.expandedRows[index];
  }

  initiatePreClosure(item: any) {
    this.showModal = true;
    this.PreCloseFDRNo = item.entryId;
    if (this.childComponent) {
      this.showModal = true;
      this.childComponent.getPreClosureDetails(this.PreCloseFDRNo);

    }
  }



  closeModal(): void {
    this.showModal = false;
  }
  printAdvice(): void {
    const printContents = document.getElementById('fdAdviceContent')?.innerHTML;
    const popupWin = window.open('', '_blank', 'width=800,height=600');
    popupWin?.document.write(`
    <html>
      <head>
        <title>Fixed Deposit Advice</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; font-size: 12px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          th, td { padding: 6px; text-align: left; border: 1px solid #ccc; }
          th { background-color: #f8f9fa; }
          h5 { color: #007b8f; }
          .text-muted { color: #6c757d; }
        </style>
      </head>
      <body onload="window.print(); window.close();">
        ${printContents}

      </body>
    </html>
  `);
    popupWin?.document.close();
  }
}


// <p class="text-center text-muted small mt-4">
//           © SIDBI. All rights reserved.
//         </p>
