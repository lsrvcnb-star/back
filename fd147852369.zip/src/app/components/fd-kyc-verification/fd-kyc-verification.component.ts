import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
  FormsModule,
} from '@angular/forms';
declare var bootstrap: any; // Needed to access Bootstrap JS
import { Router } from '@angular/router';
import { NavbarComponent } from '../../modules/admin/components/navbar/navbar.component';
import { ApiService } from '../../service/api.service';
import { Subscription } from 'rxjs';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { CustomValidator } from '../../modules/admin/Constom/validator';
import { CookieService } from 'ngx-cookie-service';
import { HybridEncryptor } from '../../Services/HybridEncryptor';
import { AuthGuard } from '../../service/authGuard';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
import { AuthService } from '../../service/auth.service';
import { formatDate } from '@angular/common';
import { CustomValidatorService } from '../../service/custom-validator-service.service';
import { SidebarComponent } from '../../modules/admin/components/sidebar/sidebar.component';
import { SanitizeInputDirective } from '../../sanitize-input.directive';
import { environment } from '../../../environments/environment';

interface StepItem {
  label: string;
  styleClass?: string;
}

interface AlertItem {
  severity: 'success' | 'info' | 'warn' | 'error';
  summary: string;
  detail: string;
}

@Component({
  selector: 'app-fd-kyc-verification',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NavbarComponent,
    FormsModule,
    NgxSpinnerModule,
    SidebarComponent,
    SanitizeInputDirective,
  ],
  templateUrl: './fd-kyc-verification.component.html',
  styleUrl: './fd-kyc-verification.component.scss',
})
export class FdKycVerificationComponent implements OnInit {
  isDisclimar: boolean = false;
  pepDisclim: boolean = false;
  pepDisclimgurd: boolean = false;
  isGuardianBank = false;
  isGuardianAddress = false;
  getcityCodedataFlag = false;
  public genders: any;
  panSubmitted = false;
  panVerifyFlag: any;
  aadharFlag: any;
  aadhaarSubmitted = false;
  gurdianAccordionTab = false;
  gurdianPanSubmitted = false;
  gurdianAadhaarSubmitted = false;
  depositerDetailsSubmitted = false;
  gurdiandetialsSubmitted = true;
  guardianKYCFlag = true;
  guardianVKYChiddenFlag = false;
  disableSubmit = false;
  steps: StepItem[] = [];
  activeIndex = 0;
  activeAccordionIndex = 0;
  gactiveAccordionIndex = 0;
  // kycTypes: any[] = [{ label: 'eKYC Verification', value: 'eKYC' },];
  value: string = 'off';
  kycMethod: 'eKYC' | 'vKYC' = 'eKYC';
  kycStepperIndex = 0;
  mainStepperIndex = 0;
  public stateName: any;
  panForm: FormGroup;
  aadhaarForm: FormGroup;
  ekycForm: FormGroup;
  guardianPanForm: FormGroup;
  guardianAadhaarForm: FormGroup;
  maskedAadhaar: string = '';
  SupportUser: string = 'Smart Support Group';
  SupportEmail: string = 'fd@sidbi.in';
  // kycbranchName = [];
  kycbranchName: string[] = []; // ✅ Correct declaration
  // branchList:string [] =[];
  subscription: Subscription = new Subscription();
  customValidatorone: CustomValidator = new CustomValidator();
  maxAttempts = 3;
  panAttemptCount = 0;
  panDisabled = false;
  panAttemptMsg!: string;
  maxDate!: Date;
  showPEPDialog: boolean = false;
  pepVal!: string;
  NewRegId!: string;
  sendOTPbtn: boolean = false;
  gurdiansendOTPbtn: boolean = false;
  loading: boolean = false;
  aadharBtn: boolean = false;
  //  showFDConfirmationDialog:boolean=true;
  showFDConfirmationDialog: boolean = false;
  panVerificationaccorBtn: boolean = false;
  AadhaVerificationaccorBtn: boolean = false;
  VkycVerificationaccorBtn: boolean = false;
  panverify_Flag!: String;
  aadhaarVirifystsFlag!: String;
  vkycInitiated: boolean = true;
  disclaimerStatus: boolean = true;
  isSelectedBelowOneLaks!: string;
  accountVerifed: boolean = false;
  bankverifyflag: boolean = false;
  bankInfoFlag: boolean = false;
  branchName: any;
  bank_NAME: any;
  BANKACC_NO: any;
  BANKIFSC_CODE: any;
  vkycFlag: number | null = null;
  vkycURL: string = '';
  vkycConfirmationAccepted = false;
  vkycLinkFetchError = false;
  isVkycCompleted = false;
  isVkycCompletedgurdian = false;
  proceedWithoutVkycChecked = false;
  gurdianproceedWithoutVkycChecked = false;
  //penneydrop check
  pennyDropStatusRequst!: string;
  finalObjectforGurdian: any;
  private hybridEncryptor!: HybridEncryptor;
  genderOptions: any[] = [];
  occupationOption: any[] = [];
  stateOptions: any[] = [];
  cityOptions: any[] = [];
  public districs: any;
  isCIFCustomer: boolean = false;

  maritalStatusOption: any[] = [{ key: 'Married', value: 'married' }, { key: 'Unmarried', value: 'unmarried' }, { key: 'Others', value: 'others' }]
  pepOptions = [

    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' },
  ];
  customerTypeOptions = [{ label: 'Individual', value: 'I' }];
  alerts: AlertItem[] = [];
  mainSteps: StepItem[] = [
    { label: 'KYC Verification' },
    { label: "Depositor's Account Details" },
  ];

  kycSteps: StepItem[] = [
    { label: 'PAN Verification' },
    { label: 'Aadhaar Verification' },
  ];
  accountTypeOptions = [
    { label: 'Savings', value: 'savings' },
    { label: 'Current', value: 'current' },
  ];
  enableOtpSendmsg: boolean = false;
  selectedCustomerType!: any;
  showMenu: boolean = false;
  customValidatorifsc: CustomValidator = new CustomValidator();


  ckycForm!: FormGroup;
  ckycSubmitted = false;
  ckycOtpRequested = false;
  fdUserMobile: any;
  private ckycRequestId!: string;
  ckycFlag: any = null;
  knowCKYCNO: string = "https://www.ckycindia.in/kyc/getkyccard"
  isIfscVerified: boolean = false;

  otpSent: boolean = false;
  canResendOtp: boolean = false;

  resendOtpTimer: number = 60;
  otpExpiryTimer: number = 600; // 10 minutes

  private resendInterval: any;
  private expiryInterval: any;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private cd: ChangeDetectorRef,
    private apiService: ApiService,
    private cookieService: CookieService,
    private authgurd: AuthGuard,
    private spinner: NgxSpinnerService,
    private authService: AuthService,
    private customValidator: CustomValidatorService
  ) {


    this.ckycForm = this.fb.group({
      kycNo: ['', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9]{6,20}$')
      ]],
      authfactorType: ['OTP'],
      authFactor: ['', Validators.required],
      requestedId: [''],
      reqType: ['VERIFY'],
    });
    this.subscription.add(
      this.ckycForm.get('kycNo')?.valueChanges.subscribe(() => {
        this.resetCkycOtpStep();
      })
    );

    this.steps = [
      {
        label: 'PAN Verification',
      },
      {
        label: 'Aadhaar Verification',
      },
      {
        label: 'eKYC Verification',
      },
    ];

    this.panForm = this.fb.group({
      kycbranchName: ['', Validators.required],
      nameAsperOvd: [
        '',
        [Validators.required, Validators.pattern('^[A-Za-z\\s]+$')],
      ],
      dobAsPerPAN: ['', [Validators.required, this.futureDateValidator]],
      panNumber: [
        '',
        [Validators.required, Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]$/)],
      ],
      selectedPEP: this.guardianKYCFlag ? ['', Validators.required] : [''],
    });

    this.aadhaarForm = this.fb.group({
      aadhaarNumber: [
        '',
        [Validators.required, Validators.pattern(/^\d{12}$/)],
      ],
      aadhaarOtp: [{ value: '', disabled: true }, Validators.required],
    });

    this.aadhaarForm.get('aadhaarNumber')?.valueChanges.subscribe((value) => {
      const isValid = /^\d{12}$/.test(value);
      const otpControl = this.aadhaarForm.get('aadhaarOtp');
      if (isValid) {
        otpControl?.enable();
      } else {
        otpControl?.disable();
        otpControl?.reset();
      }
    });

    this.ekycForm = this.fb.group({
      depositorName: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.onlyLettersAllowed(),
        ]),
      ],
      borrowerLongName: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.onlyLettersAllowed(),
        ]),
      ],
      fdUserPan: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.panNumberValidate(),
        ]),
      ], // PAN pattern
      dob: ['', Validators.required],
      gender: [
        'select',
        Validators.compose([
          Validators.required,
          this.customValidator.invalidSelectValidator,
        ]),
      ],
      occupation: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.invalidSelectValidator,
        ]),
      ],
      maritalStatus: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.invalidSelectValidator,
        ]),
      ],
      annualIncome: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern(/^[0-9]+$/),
          this.customValidator.invalidSelectValidator,
        ]),
      ],
      socialCategory: [
        'General',
        Validators.compose([
          Validators.required,
          this.customValidator.invalidSelectValidator,
        ]),
      ],
      minority: [
        'N',
        Validators.compose([
          Validators.required,
          this.customValidator.invalidSelectValidator,
        ]),
      ],
      customerType: [
        'Individual',
        Validators.compose([
          Validators.required,
          this.customValidator.invalidSelectValidator(),
        ]),
      ],
      addLine1: ['',],
      addLine2: [''],
      state: [
        'select',
        Validators.compose([

          this.customValidator.invalidSelectValidator(),
        ]),
      ],
      city: [
        'select',
        Validators.compose([

          this.customValidator.invalidSelectValidator(),
        ]),
      ],
      pinCode: [''],
      fdUserEmail: [
        '',
        [
          Validators.pattern(
            /^[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]{3,}\.[a-zA-Z]{2,}$/
          ),
        ],
      ],
      fdUserMobile: ['', [Validators.pattern(/^[0-9]{10}$/)]],
      branch: ['', Validators.required],

      payeeName: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.onlyLettersAllowed(),
        ]),
      ],
      accType: ['', Validators.required],
      accNum: ['', [Validators.required, Validators.pattern(/^[0-9]{9,18}$/)]],
      ifsc: [
        '',
        [Validators.required, Validators.pattern('^[A-Z]{4}0[A-Z0-9]{6}$')],
      ],

      bankName: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.onlyLettersAllowed(),
        ]),
      ],
      selectedPEP: ['', Validators.compose([
        Validators.required,
        this.customValidator.invalidSelectValidator(),
      ]),],
      kycbranchName: ['', Validators.compose([
        Validators.required,
        this.customValidator.invalidSelectValidator(),
      ]),]
    });

    this.guardianPanForm = this.fb.group({
      guardianKycbranchName: ['select', Validators.required],
      guardianNameAsperOvd: [
        '',
        [Validators.required, Validators.pattern('^[A-Za-z\\s]+$')],
      ],
      guardiaDobAsPerPAN: ['', [Validators.required, this.futureDateValidator]],
      guardianPanNumber: [
        '',
        [Validators.required, Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]$/i)],
      ],
      gurdianRelation: [
        '',
        [Validators.required, Validators.pattern('^[A-Za-z\\s]+$')],
      ],
      gurdianEmail: [
        '',
        [
          Validators.pattern(
            /^[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]{3,}\.[a-zA-Z]{2,}$/
          ),
        ],
      ],
      gurdianMobile: ['', [Validators.pattern(/^[0-9]{10}$/)]],
      guardianSelectedPEP: ['', Validators.required],
    });

    this.guardianAadhaarForm = this.fb.group({
      guardianAadhaarNumber: [
        '',
        [Validators.required, Validators.pattern(/^\d{12}$/)],
      ],
      guardianAadhaarOtp: [{ value: '', disabled: true }, Validators.required],
    });
    this.guardianAadhaarForm
      .get('guardianAadhaarNumber')
      ?.valueChanges.subscribe((value) => {
        const isValid = /^\d{12}$/.test(value);
        const otpControl = this.guardianAadhaarForm.get('guardianAadhaarOtp');
        if (isValid) {
          otpControl?.enable();
        } else {
          otpControl?.disable();
          otpControl?.reset();
        }
      });
  }

  get otpExpiryTimerDisplay(): string {
    const minutes = Math.floor(this.otpExpiryTimer / 60);
    const seconds = this.otpExpiryTimer % 60;
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  }

  ngOnInit(): void {
    this.isCIFCustomer = false;
    this.ckycFlag = null;
    this.enableOtpSendmsg = false;
    this.activeIndex = 0;
    this.branchList();
    this.maxDate = new Date();
    this.hybridEncryptor = new HybridEncryptor();
    this.activeAccordion();
    this.userDetailsView();
    this.getDropdownListF();
    this.getDropdownListdata();
    this.getBankDetails();
    this.getUserBankDetails();
    this.aadharpanSedingstatus();
    this.getCombinedGuardianKycDetailsView();
    this.getCombinedGuardianpanKycDetailsView();

    this.toggleFormState();

    //customertype select
    this.selectedCustomerType = this.customerTypeOptions[0];
    console.log('Environment Name: ' + environment.envName);

    this.ekycForm.get('ifsc')?.valueChanges.subscribe(() => {

      this.isIfscVerified = false;

    });


  }

  setMainStep(index: number): void {
    this.onStepClick(index);
  }

  setActiveAccordion(index: number): void {
    this.activeAccordionIndex =
      this.activeAccordionIndex === index ? -1 : index;
  }

  setGuardianAccordion(index: number): void {
    this.gactiveAccordionIndex =
      this.gactiveAccordionIndex === index ? -1 : index;
  }

  preventNegativeNumber(event: KeyboardEvent): void {
    if (event.key === '-' || event.key === '+' || event.key.toLowerCase() === 'e') {
      event.preventDefault();
    }
  }

  getAlertClass(
    severity: 'success' | 'info' | 'warn' | 'error'
  ): string {
    switch (severity) {
      case 'success':
        return 'alert-success';
      case 'info':
        return 'alert-info';
      case 'warn':
        return 'alert-warning';
      case 'error':
        return 'alert-danger';
      default:
        return 'alert-info';
    }
  }

  dismissAlert(index: number): void {
    this.alerts.splice(index, 1);
  }

  get form() {
    return this.ekycForm.value;
  }

  toggleGuardianKYC() {
    this.gurdiandetialsSubmitted = !this.gurdiandetialsSubmitted;
  }

  toggleFormState(): void {
    if (this.bankInfoFlag) {
      this.ekycForm.disable();
    } else {
      this.ekycForm.enable();
    }
  }

  getPepLabel(value: string): string {
    const option = this.pepOptions.find((p) => p.value === value);
    return option ? option.label : '';
  }

  getMaskedGuardianAadhaar(): string {
    const aadhaar = this.guardianAadhaarForm.get(
      'guardianAadhaarNumber'
    )?.value;
    if (aadhaar && aadhaar.length === 12) {
      return 'XXXXXXXX' + aadhaar.slice(-4);
    }
    return '';
  }

  getMaskedAadhaar(): string {
    const aadhaar = this.aadhaarForm.get('aadhaarNumber')?.value;
    if (aadhaar && aadhaar.length === 12) {
      return 'XXXXXXXX' + aadhaar.slice(-4);
    }
    return '';
  }

  futureDateValidator(control: AbstractControl): ValidationErrors | null {
    if (!control.value) return null;
    const inputDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time to ensure accurate comparison
    return inputDate > today ? { futureDate: true } : null;
  }

  branchList(): void {
    this.subscription.add(
      this.apiService.branchList().subscribe({
        next: (response: any) => {
          // this.kycbranchName = response;
          this.kycbranchName = response.filter(
            (branch: any) => branch.toUpperCase() !== 'MUMBAI-BKC'
          );
        },
      })
    );
  }
  pennyDropRequestDataApi() {
    this.spinner.show();

    const accNum = this.ekycForm.get('accNum')?.value;
    const ifsc = this.ekycForm.get('ifsc')?.value;
    const payeeName = this.ekycForm.get('payeeName')?.value;
    const depositorName = this.ekycForm.get('depositorName')?.value;
    const fdRegId = this.authService.getResponseValueByKey('newFdRegId');
    const remitterAcc = this.customValidator.getRemiterAccountNo();
    if (!accNum || !ifsc || !fdRegId || !remitterAcc) {
      this.spinner.hide();
      alert('Please fill in all required fields.'); // this.showAlert()
      return;
    }
    // if (payeeName !== depositorName) {
    //   alert('Depositor name & Payee name are different!');
    //   return;
    // }

    if (payeeName !== depositorName) {
      this.spinner.hide();
      const confirmProceed = window.confirm(
        'Depositor name & Payee name are different!\nDo you want to continue?'
      );
      if (!confirmProceed) {
        return; // Stop further execution if user clicks "Cancel"
      }
    }
    const genenUnId = this.customValidator.generateUniqueReqId();
    const requestData = {
      reqId: genenUnId,
      remitterAcc: remitterAcc,
      beneAccNum: accNum,
      beneIFSC: ifsc,
      fdRegId: fdRegId
    };
    this.subscription.add(
      this.apiService
        .pennyDropRequestDataapi(
          this.hybridEncryptor.encrypted(JSON.stringify(requestData))
        )
        .subscribe({
          next: (response: any) => {
            this.spinner.hide();
            if (response && response.statusCode === '1002') {
              const requestId = response.reqId;
              // alert('Please wait while we verify your account.');
              this.pennyDropStatusRequst = requestId;
              if (!this.ekycForm.valid) {
                this.showAlert(
                  'info',
                  'Mandatory Fields',
                  'Please select all the required fields to proceed for submission'
                );
              }
              // this.accountVerifed = true;
              this.bankverifyflag = true;
              // this.isIfscVerified = true; 
              // this.checkPennyDropStatus();
              this.showAlert(
                'info',
                'Account Verification Initiated',
                'Your bank account verification is in progress. Please wait a few moments...'
              );
              this.spinner.show();
              setTimeout(() => {
                this.spinner.hide();
                this.checkPennyDropStatus();
              }, 15000); // 10 seconds

            } else {
              console.warn('Unexpected response:', response);
              this.accountVerifed = false;
              this.bankverifyflag = false;
              this.showAlert(
                'error',
                'Error',
                'Penny drop failed. Please try again'
              );
            }
          },
          error: (error: any) => {
            this.spinner.hide();
            console.warn('Unexpected response:', error?.message);
            this.accountVerifed = false;
            this.bankverifyflag = false;
            this.showAlert(
              'error',
              'Error',
              'Penny drop failed. Please try again'
            );
          },
        })
    );
  }

  checkPennyDropStatus(): void {
    this.spinner.show();
    setTimeout(() => {
      this.apiService
        .getPennyDropStatusDataapi(
          this.hybridEncryptor.encrypted(
            JSON.stringify({ reqId: this.pennyDropStatusRequst })
          )
        )
        .subscribe({
          next: (statusResponse: any) => {
            this.spinner.hide();
            if (statusResponse) {
              if (
                statusResponse.message === 'Success' &&
                statusResponse.statusCode === '02'
              ) {
                if (environment.envName === 'prod') {
                  const payeeName = this.ekycForm.get('payeeName')?.value;
                  // this.checkNamesAndProceed(payeeName.toUpperCase(),statusResponse.reqId.toUpperCase())
                  this.checkNamesAndProceed(payeeName.toUpperCase(), statusResponse.reqId.toUpperCase())

                } else {
                  // Non-prod environments: skip name match check
                  alert('Bank Account Successfully verified');
                  this.showAlert(
                    'success',
                    'Success',
                    'Your Bank Account verified successfully'
                  );
                  this.bankverifyflag = true;
                  this.accountVerifed = true;
                }
              } else if (
                statusResponse.message === 'Pending' &&
                statusResponse.statusCode === '05'
              ) {
                this.showAlert(
                  'info',
                  'Account Verification Initiated',
                  'Your Bank Account verification is in progress'
                );
              } else if (
                statusResponse.message === 'Failure' &&
                statusResponse.statusCode === '03'
              ) {
                this.showAlert(
                  'error',
                  'Account Verification Failed',
                  'Your Bank Account could not be verified'
                );
                this.accountVerifed = false;
                this.bankverifyflag = false;
              }
            }
          },
          error: (err) => {
            this.spinner.hide();
            console.error(' Error in getPennyDropStatus', err);
            this.showAlert(
              'error',
              'Account Verification Failed',
              'Error verifying your Bank Account. Kindly initiate again'
            );
          },
        });
    }, 1000);
  }
  submitKYCform() {

    if (this.ekycForm.valid) {
      this.ekycForm.enable();
      this.spinner.show();
      let rawFormData = this.ekycForm.value;
      function processFormData(data: any) {
        for (let key in data) {
          if (data[key] === 'select') {
            data[key] = '';
          }
        }
        return data;
      }
      rawFormData['customerType'] = rawFormData['customerType']?.value;

      let data = processFormData(rawFormData);
      data.fdUserEmail = this.authService.getResponseValueByKey('fdUserEmail');
      data.newFdRegId = this.authService.getResponseValueByKey('newFdRegId');
      data.kycBranchName =
        this.authService.getResponseValueByKey('kycBranchName');
      if (this.ckycFlag == 'Y') {
        data.kycBranchName = this.ekycForm.get('kycbranchName')?.value;

      }


      this.subscription.add(
        this.apiService
          .saveFdNewUserCifDetails(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();
              this.ekycForm.disable();
              if (response.statusCode == '1002') {
                this.showAlert(
                  'success',
                  'Form Submission',
                  'Thanks for submitting the details for Account creation'
                );
                this.PEPCheckForCKYC();
                this.isIfscVerified = true;
                if (this.ckycSubmitted) {
                  this.router.navigate(['/dashboard/createFD']);

                }
                this.mainStepperIndex = 0;
                this.activeAccordionIndex = 2;
                this.cd.detectChanges();
              } else if (response.statusCode == '1008') {
                this.ekycForm.get('fdUserPan')?.disable();
                this.ekycForm.get('depositorName')?.disable();
                this.ekycForm.get('borrowerLongName')?.disable();
                this.ekycForm.get('fdUserPan')?.disable();
                this.ekycForm.get('dob')?.disable();
                this.ekycForm.get('gender')?.disable();
                this.ekycForm.get('fdUserEmail')?.disable();
                this.ekycForm.get('fdUserMobile')?.disable();
                this.ekycForm.get('addLine1')?.disable();
                this.ekycForm.get('addLine2')?.disable();
                this.ekycForm.get('state')?.disable();
                this.ekycForm.get('city')?.disable();
                this.ekycForm.get('pinCode')?.disable();
                this.showAlert(
                  'info',
                  'User Exist',
                  'We have you already in our records'
                );
                this.router.navigate(['/dashboard/createFD']);
              }
            },
            error: (err) => {
              this.spinner.hide();
              this.ekycForm.get('fdUserPan')?.disable();
              this.ekycForm.get('depositorName')?.disable();
              this.ekycForm.get('borrowerLongName')?.disable();
              this.ekycForm.get('fdUserPan')?.disable();
              this.ekycForm.get('dob')?.disable();
              this.ekycForm.get('gender')?.disable();
              this.ekycForm.get('fdUserEmail')?.disable();
              this.ekycForm.get('fdUserMobile')?.disable();
              this.ekycForm.get('addLine1')?.disable();
              this.ekycForm.get('addLine2')?.disable();
              this.ekycForm.get('state')?.disable();
              this.ekycForm.get('city')?.disable();
              this.ekycForm.get('pinCode')?.disable();
              this.showAlert(
                'error',
                'Alert',
                'Error occurred in wudCifCreationForm details Form submitting'
              );
              console.log(
                'Error occurred in wudCifCreationForm details Form submitting ' +
                err
              );
            },
          })
      );
    }
  }

  submitPanForm() {
    if (this.panForm.valid) {
      this.verifyPan();
      const datePipe = new DatePipe('en-US');
      const rawDob = this.panForm.get('dobAsPerPAN')?.value;
      const formattedDob = datePipe.transform(rawDob, 'dd/MM/yyyy');
      this.spinner.show();
      const data = {
        pan: this.panForm.get('panNumber')?.value,
        dob: formattedDob,
        kycbranchName: this.panForm.get('kycbranchName')?.value,
        name: this.panForm.get('nameAsperOvd')?.value,
        fdRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        fdUserId: this.authService.getResponseValueByKey('fdUserId'),
        flag: 0,
      };

      this.subscription.add(
        this.apiService
          .verifiyPanData(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();
              console.log("pan Verify", response)
              try {
                const parsedMessage = JSON.parse(response.message);
                const panData = parsedMessage.payload?.data?.[0];
                const employeeData = response?.['employeeData'];

                if (
                  parsedMessage.statusCode === '1000' &&
                  parsedMessage.statusMsg === 'Success' &&
                  panData
                ) {
                  const { pan_status, name, dob, seeding_status } = panData;

                  // Handle all valid/invalid combinations
                  if (
                    response.statusCode === '1002' ||
                    response.statusCode === '1008'
                  ) {
                    if (name === 'Y' && dob === 'Y') {
                      // All matched
                      this.panForm.get('panNumber')?.disable();
                      this.panForm.get('nameAsperOvd')?.disable();
                      this.panForm.get('dobAsPerPAN')?.disable();
                      this.panForm.get('kycbranchName')?.disable();
                      this.panForm.get('selectedPEP')?.disable();
                      this.showAlert(
                        'success',
                        'Success',
                        'PAN verified successfully'
                      );
                      this.aadharpanSedingstatus();
                      this.panSubmitted = true;
                      this.activeAccordionIndex = 1;

                      if (employeeData?.EMP_STATUS === 'N') {
                        // y
                        this.handleAadhaarSuccessLogic();
                        this.handleKYCSuccessLogic();

                        // Show SIDBI employee alert before redirect
                        this.showAlert(
                          'info',
                          'SIDBI Employee',
                          'As a SIDBI employee, KYC verification is not required. Redirecting to FD creation...'
                        );

                        setTimeout(() => {
                          this.router.navigate(['/dashboard/createFD']);
                        }, 3000); // Delay to allow user to read the alert
                        return;
                      }

                      this.cd.detectChanges();
                    } else if (name === 'N' && dob === 'N') {
                      // Both name and DOB mismatch
                      this.panSubmitted = false;
                      this.showAlert(
                        'error',
                        'Error',
                        'PAN verification failed due to both Name and Date of Birth mismatch. Kindly ensure both fields match your PAN record.'
                      );
                    } else if (name === 'N' && dob === 'Y') {
                      // Only name mismatch
                      this.panSubmitted = false;
                      this.showAlert(
                        'error',
                        'Error',
                        'PAN verification failed due to a name mismatch. Kindly ensure the name entered matches your PAN record.'
                      );
                    } else if (name === 'Y' && dob === 'N') {
                      // Only DOB mismatch
                      this.panSubmitted = false;
                      this.showAlert(
                        'error',
                        'Error',
                        'PAN verification failed due to a mismatch in the date of birth. Please ensure the date of birth matches the one on your PAN record.'
                      );
                    } else if (pan_status === 'N') {
                      // Invalid PAN
                      this.panSubmitted = false;
                      this.showAlert(
                        'error',
                        'Error',
                        'Invalid PAN. Kindly check and try again.'
                      );
                    } else {
                      // Unknown response
                      this.panSubmitted = false;
                      this.showAlert(
                        'warn',
                        'Warning',
                        'PAN verification returned an unknown response. Please contact support.'
                      );
                    }
                  } else {
                    // Unexpected statusCode
                    this.panSubmitted = false;
                    this.showAlert(
                      'warn',
                      'Warning',
                      'PAN verification failed due to unexpected response.'
                    );
                  }
                } else {
                  this.panSubmitted = false;
                  this.showAlert(
                    'error',
                    'Error',
                    'Invalid response received during PAN verification.'
                  );
                }
              } catch (e) {
                // PAN already registered case
                if (
                  response.statusCode === '1008' &&
                  typeof response.message === 'string'
                ) {
                  /* this.showAlert(
                    'error',
                    'Already Registered',
                    response.message
                  ); */
                  this.showAlert(
                    'error',
                    'Already Registered',
                    'Your PAN is already registered with SIDBI. It is linked to the email ID ' + response?.existingEmailId + ' . Please log in using this account to continue.'
                  );

                  this.panSubmitted = false;
                } else {
                  this.showAlert(
                    'error',
                    'Error',
                    'Invalid or malformed response received during PAN verification.'
                  );
                  this.panSubmitted = false;
                }
              }
            },
            error: () => {
              this.spinner.hide();
              this.showAlert(
                'warn',
                'Warning',
                'An error occurred while verifying PAN.'
              );
            },
          })
      );
    }
  }

  gudardianSubmitPanForm() {
    if (this.guardianPanForm.valid) {
      this.verifyPan();
      const datePipe = new DatePipe('en-US');
      const rawDob = this.guardianPanForm.get('guardiaDobAsPerPAN')?.value;
      const formattedDob = datePipe.transform(rawDob, 'dd/MM/yyyy');
      const gurdianRelation =
        this.guardianPanForm.get('gurdianRelation')?.value;
      const minpan = this.panForm.get('panNumber')?.value;
      const gurdpan = this.guardianPanForm.get('guardianPanNumber')?.value;
      if (minpan === gurdpan) {
        this.showAlert(
          'error',
          'Error',
          "The Guardian 's PAN must be different from the Minor's PAN"
        );
        this.guardianPanForm.reset();
      } else {
        this.spinner.show();
        const data = {
          pan: this.guardianPanForm.get('guardianPanNumber')?.value,
          dob: formattedDob,
          kycbranchName: this.guardianPanForm.get('guardianKycbranchName')
            ?.value,
          name: this.guardianPanForm.get('guardianNameAsperOvd')?.value,
          fdRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          fdUserId: this.authService.getResponseValueByKey('fdUserId'),
          flag: 1,
        };

        this.subscription.add(
          this.apiService
            .verifiyPanData(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                try {
                  const parsedMessage = JSON.parse(response.message);
                  const panData = parsedMessage.payload?.data?.[0];
                  if (
                    parsedMessage.statusCode === '1000' &&
                    parsedMessage.statusMsg === 'Success' &&
                    panData
                  ) {
                    const { pan_status, name, dob, seeding_status } = panData;
                    // Handle all valid/invalid combinations
                    if (
                      response.statusCode === '1002' ||
                      response.statusCode === '1008'
                    ) {
                      if (name === 'Y' && dob === 'Y') {
                        // All matched
                        this.guardianPanForm
                          .get('guardianPanNumber')
                          ?.disable();
                        this.guardianPanForm
                          .get('guardianNameAsperOvd')
                          ?.disable();
                        this.guardianPanForm
                          .get('guardiaDobAsPerPAN')
                          ?.disable();
                        this.guardianPanForm
                          .get('guardianKycbranchName')
                          ?.disable();
                        this.guardianPanForm
                          .get('guardianSelectedPEP')
                          ?.disable();
                        this.guardianPanForm.get('gurdianRelation')?.disable();
                        this.showAlert(
                          'success',
                          'Success',
                          'PAN verified successfully'
                        );
                        this.gactiveAccordionIndex = 1;
                        this.gurdianPanSubmitted = true;
                        this.UpdatedfinalrequestForGurdian('PAN');
                      } else if (name === 'N' && dob === 'N') {
                        // Both name and DOB mismatch
                        this.gurdianPanSubmitted = false;
                        this.showAlert(
                          'error',
                          'Error',
                          'PAN verification failed due to both Name and Date of Birth mismatch. Kindly ensure both fields match your PAN record.'
                        );
                      } else if (name === 'N' && dob === 'Y') {
                        // Only name mismatch
                        this.gurdianPanSubmitted = false;
                        this.showAlert(
                          'error',
                          'Error',
                          'PAN verification failed due to a name mismatch. Kindly ensure the name entered matches your PAN record.'
                        );
                      } else if (name === 'Y' && dob === 'N') {
                        // Only DOB mismatch
                        this.gurdianPanSubmitted = false;
                        this.showAlert(
                          'error',
                          'Error',
                          'PAN verification failed due to a mismatch in the date of birth. Please ensure the date of birth matches the one on your PAN record.'
                        );
                      } else if (pan_status === 'N') {
                        // Invalid PAN
                        this.gurdianPanSubmitted = false;
                        this.showAlert(
                          'error',
                          'Error',
                          'Invalid PAN. Kindly check and try again.'
                        );
                      } else {
                        // Unknown response
                        this.gurdianPanSubmitted = false;
                        this.showAlert(
                          'warn',
                          'Warning',
                          'PAN verification returned an unknown response. Please contact support.'
                        );
                      }
                    } else {
                      // Unexpected statusCode
                      this.gurdianPanSubmitted = false;
                      this.showAlert(
                        'warn',
                        'Warning',
                        'PAN verification failed due to unexpected response.'
                      );
                    }
                  } else {
                    this.gurdianPanSubmitted = false;
                    this.showAlert(
                      'error',
                      'Error',
                      'Invalid response received during PAN verification.'
                    );
                  }
                } catch (e) {
                  // PAN already registered case
                  if (
                    response.statusCode === '1008' &&
                    typeof response.message === 'string'
                  ) {
                    this.showAlert(
                      'error',
                      'Already Registered',
                      response.message
                    );
                    this.showAlert(
                      'error',
                      'Error',
                      'Your PAN is already registered with SIDBI.please log in using your existing account.If you already have an account, kindly proceed to the login page'
                    );

                    this.gurdianPanSubmitted = false;
                  } else {
                    this.showAlert(
                      'error',
                      'Error',
                      'Invalid or malformed response received during PAN verification.'
                    );
                    this.gurdianPanSubmitted = false;
                  }
                }
              },
              error: () => {
                this.spinner.hide();
                this.showAlert(
                  'warn',
                  'Warning',
                  'An error occurred while verifying PAN.'
                );
              },
            })
        );
      }
    }
  }

  handleAadhaarSuccessLogic() {
    const mailId = this.authService.getResponseValueByKey('fdUserEmail') || '';
    // this.showAlert('success', 'Success', 'Aadhaar Verification Successfully Completed');
    this.gettingLocalStorageData(mailId);
    setTimeout(() => {
      this.showFDConfirmationDialog = true;
    }, 1000);
    this.aadhaarSubmitted = true;
    this.aadhaarForm.get('aadhaarOtp')?.disable();
    this.activeAccordionIndex = 2;
    this.cd.detectChanges();
  }

  handleKYCSuccessLogic() { }

  sendOTP() {
    var aadharnum = this.aadhaarForm.get('aadhaarNumber')?.value;
    this.spinner.show();
    if (aadharnum != null && aadharnum != '') {
      const data = {
        aadharno: String(this.aadhaarForm.get('aadhaarNumber')?.value),
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        flag: 0,
      };
      this.subscription.add(
        this.apiService
          .eKYCRequestOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              this.spinner.hide();
              if (response.statusCode == '1002') {
                this.showAlert(
                  'success',
                  'Success',
                  'Aadhaar OTP sent to registered mobile number'
                );

                this.aadhaarForm.get('aadhaarNumber')?.disable();
                this.aadhaarForm.get('aadhaarOtp')?.enable();
                this.aadhaarForm.get('aadhaarOtp')?.reset();

                this.sendOTPbtn = true;

                // ✅ start resend and expiry timers
                this.startOtpTimers();
              } else if (response.statusCode == '1008') {
                this.showAlert(
                  'error',
                  'Error',
                  'Aadhaar OTP generation was unsuccessful. This may be due to an invalid Aadhaar number. Kindly verify the details and try again.'
                );
              }
            },
            error: (error) => {
              console.error('An error occurred in aadharOTPRequest:', error);
              this.spinner.hide();
              // this.CommonError = "The server is currently busy. Please try again shortly";}
            },
          })
      );
    }
  }

  resendAadhaarOtp(): void {
    if (!this.canResendOtp) {
      return;
    }

    this.aadhaarForm.get('aadhaarOtp')?.reset();

    // Reuse existing sendOTP method
    this.sendOTP();
  }

  submitAadhaarForm() {
    if (this.aadhaarForm.valid) {
      this.showAlert(
        'info',
        'Information',
        'Your Aadhaar eKYC verification is in progress. Please wait a few moments while the process completes.'
      );
      setTimeout(() => {
        this.spinner.show();
        const data = {
          aadharno: this.aadhaarForm.get('aadhaarNumber')?.value,
          otp: this.aadhaarForm.get('aadhaarOtp')?.value,
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          mailId: this.authService.getResponseValueByKey('fdUserEmail'),
          panNo: this.panForm.get('panNumber')?.value,
          flag: 0,
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestdata(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  this.clearOtpTimers();
                  this.otpSent = false;
                  this.canResendOtp = false;
                  this.showAlert(
                    'success',
                    'Success',
                    'Aadhaar Verification Successfully Completed'
                  );
                  this.gettingLocalStorageData(data.mailId || '');
                  this.aadharpanSedingstatus();
                  setTimeout(() => {
                    this.showFDConfirmationDialog = true;
                  }, 1000);
                  this.aadhaarSubmitted = true;
                  this.aadhaarForm.get('aadhaarOtp')?.disable();
                  // this.activeAccordionIndex = 2;
                  this.spinner.show();
                  this.userDetailsView();
                  setTimeout(() => {
                    this.spinner.hide();

                    this.mainStepperIndex = 1;
                    this.ekycForm.get('fdUserPan')?.disable();
                    this.ekycForm.get('depositorName')?.disable();
                    this.ekycForm.get('borrowerLongName')?.disable();
                    this.ekycForm.get('fdUserPan')?.disable();
                    this.ekycForm.get('dob')?.disable();
                    this.ekycForm.get('gender')?.disable();
                    this.ekycForm.get('fdUserEmail')?.disable();
                    this.ekycForm.get('fdUserMobile')?.disable();
                    this.ekycForm.get('addLine1')?.disable();
                    this.ekycForm.get('addLine2')?.disable();
                    this.ekycForm.get('state')?.disable();
                    this.ekycForm.get('city')?.disable();
                    this.ekycForm.get('pinCode')?.disable();



                    this.cd.detectChanges();
                  }, 2000)

                  // set Aadhar number
                  this.aadhaarForm
                    .get('aadhaarNumber')
                    ?.setValue(data.aadharno);
                  this.cd.detectChanges();
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Resident authentication failed'
                ) {
                  this.showAlert(
                    'error',
                    'Invalid OTP',
                    'The Aadhaar OTP entered is invalid. Please try again or resend OTP.'
                  );

                  this.aadhaarForm.get('aadhaarOtp')?.reset();

                  // ✅ allow resend after wrong OTP
                  this.canResendOtp = true;
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Invalid transactionId.'
                ) {
                  this.showAlert(
                    'error',
                    'Error',
                    'Aadhaar Verification failed due to some technical issue try again after some time'
                  );
                }
                else if (response.statusCode == '1008' && response.statusMsg == 'The given customer Pan and Aadhar name Mismatch') {
                  this.showAlert(
                    'error',
                    'Error',
                    'The given customer Pan and Aadhar name Mismatch'
                  );
                } else if (response.statusCode == '1008') {
                  this.showAlert(
                    'error',
                    'Error',
                    'Aadhaar Verification failed due to some technical issue try again after some time'
                  );
                }
              },
              error: (error) => {
                this.spinner.hide();
                console.error('An error occurred in submitAadhaarForm:', error);
              },
            })
        );
      }, 3000);
    }
  }

  gurdiansendOTP() {
    var aadharnum = this.guardianAadhaarForm.get(
      'guardianAadhaarNumber'
    )?.value;
    var maadharnum = this.aadhaarForm.get('guardianAadhaarNumber')?.value;
    this.spinner.show();
    if (aadharnum === maadharnum) {
      this.showAlert(
        'error',
        'Error',
        "The Guardian 's Aadhar must be different from the Minor's Aadhar"
      );
      this.guardianAadhaarForm.reset();
    } else {
      if (aadharnum != null && aadharnum != '') {
        const data = {
          aadharno: String(
            this.guardianAadhaarForm.get('guardianAadhaarNumber')?.value
          ),
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          flag: 1,
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestOTP(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  this.showAlert(
                    'success',
                    'Success',
                    'Aadhaar OTP sent to register mobile number'
                  );
                  this.guardianAadhaarForm
                    .get('guardianAadhaarNumber')
                    ?.disable();
                  this.gurdiansendOTPbtn = true;
                } else if (response.statusCode == '1008') {
                  this.showAlert(
                    'error',
                    'Error',
                    'Aadhaar OTP generation was unsuccessful. This may be due to an invalid Aadhaar number. Kindly verify the details and try again.'
                  );
                }
              },
              error: (error) => {
                console.error('An error occurred in aadharOTPRequest:', error);
                this.spinner.hide();
                // this.CommonError = "The server is currently busy. Please try again shortly";}
              },
            })
        );
      }
    }
  }

  gurdianAadhaarFormSubmit() {
    if (this.guardianAadhaarForm.valid) {
      this.showAlert(
        'info',
        'Information',
        'Your Aadhaar eKYC verification is in progress. Please wait a few moments while the process completes.'
      );
      setTimeout(() => {
        this.spinner.show();
        const data = {
          aadharno: this.guardianAadhaarForm.get('guardianAadhaarNumber')
            ?.value,
          otp: this.guardianAadhaarForm.get('guardianAadhaarOtp')?.value,
          newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
          mailId: this.authService.getResponseValueByKey('fdUserEmail'),
          panNo: this.guardianPanForm.get('panNumber')?.value,
        };
        this.subscription.add(
          this.apiService
            .eKYCRequestdata(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                this.spinner.hide();
                if (response.statusCode == '1002') {
                  this.showAlert(
                    'success',
                    'Success',
                    'Aadhaar Verification Successfully Completed'
                  );
                  this.UpdatedfinalrequestForGurdian('AADHAAR');
                  this.gurdianAadhaarSubmitted = true;

                  this.guardianAadhaarForm.get('guardianAadhaarOtp')?.disable();
                  this.activeAccordionIndex = 2;
                  // set Aadhar number
                  this.guardianAadhaarForm
                    .get('guardianAadhaarNumber')
                    ?.setValue(data.aadharno);
                  this.cd.detectChanges();
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Resident authentication failed'
                ) {
                  this.showAlert(
                    'error',
                    'Error',
                    'Enter Aadhaar valid OTP Number'
                  );
                } else if (
                  response.statusCode == '1008' &&
                  response.statusMsg == 'Invalid transactionId.'
                ) {
                  this.showAlert(
                    'error',
                    'Error',
                    'Aadhaar Verification failed due to some technical issue try again after some time'
                  );
                } else if (response.statusCode == '1008') {
                  this.showAlert(
                    'error',
                    'Error',
                    'Aadhaar Verification failed due to some technical issue try again after some time'
                  );
                }
              },
              error: (error) => {
                this.spinner.hide();
                console.error('An error occurred in submitAadhaarForm:', error);
              },
            })
        );
      }, 3000);
    }
  }

  activeAccordion(): any {
    let data = {
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
    };
    this.subscription.add(
      this.apiService
        .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response != null) {
              if (
                response.aadhaarVirifystsFlag === 'Y' &&
                response.panverify_Flag === 'Y' &&
                response.empKycFlag === 'Y' &&
                Number(response.vkycFlag) == 1
              ) {
                // this.router.navigate(['/dashboard/home']);
                // return
              }

              if (response.ckycFlag === 'Y') {
                //need to check
                this.ckycForm.get("kycNo")?.setValue(response.ckycNo);
                this.ckycFlag = response.ckycFlag;
                this.ckycSubmitted = true
                // this.isVkycCompleted = true  
              }

              if (
                response.aadhaarVirifystsFlag === 'Y' &&
                response.panverify_Flag === 'Y'
              ) {
                this.panSubmitted = true;
                this.aadhaarSubmitted = true;
                // this.panVerificationaccorBtn = true;
                // this.AadhaVerificationaccorBtn = true;
                this.activeAccordionIndex = 2;
              } else if (
                (response.aadhaarVirifystsFlag === null ||
                  response.aadhaarVirifystsFlag === '') &&
                response.panverify_Flag === 'Y'
              ) {
                this.panSubmitted = true;
                this.aadhaarSubmitted = false;
                // this.panVerificationaccorBtn = true;
                // this.AadhaVerificationaccorBtn = false;
                this.activeAccordionIndex = 1;
              } else if (
                response.aadhaarVirifystsFlag === 'Y' &&
                (response.panverify_Flag === '' ||
                  response.panverify_Flag === null)
              ) {
                this.panSubmitted = false;
                this.aadhaarSubmitted = true;
                // this.panVerificationaccorBtn = false;
                // this.AadhaVerificationaccorBtn = true;
                this.activeAccordionIndex = 0;
              } else if (
                (response.aadhaarVirifystsFlag === null ||
                  response.aadhaarVirifystsFlag === '') &&
                (response.panverify_Flag === '' ||
                  response.panverify_Flag === null)
              ) {
                this.panSubmitted = false;
                this.aadhaarSubmitted = false;
                // this.panVerificationaccorBtn = false;
                // this.AadhaVerificationaccorBtn = false;
                this.activeAccordionIndex = 0;
              }
              if (
                (response.aadhaarVirifystsFlag === 'Y' &&
                  response.panverify_Flag === 'Y') ||
                response.empKycFlag === 'Y' ||
                Number(response.vkycFlag) == 1
              ) {
                this.showMenu = true;
                this.isIfscVerified = true;
              } else {
                this.showMenu = false;
              }
              this.panForm.get('nameAsperOvd')?.setValue(response.fdUserName);
              this.panForm.get('panNumber')?.setValue(response.fdUserPan);
              if (response?.kycBranchNam) {
                this.panForm
                  .get('kycbranchName')
                  ?.setValue(response.kycBranchName);
              }

              if (response.politicalExposedPerson === 'Y') {
                if (this.ckycFlag) {
                  this.ekycForm.get('selectedPEP')?.setValue('Yes');
                } else {
                  this.panForm.get('selectedPEP')?.setValue('Yes');
                }

              } else if (response.politicalExposedPerson === 'N') {
                if (this.ckycFlag) {

                  this.ekycForm.get('selectedPEP')?.setValue('No');
                } else {

                  this.panForm.get('selectedPEP')?.setValue('No');
                }
              } else {
                this.panForm.get('selectedPEP')?.setValue('');
              }

              // set Aadhar number
              this.aadhaarForm
                .get('aadhaarNumber')
                ?.setValue(response.fdUserAdharCard);

              this.cd.detectChanges();
            }
          },
          error: (err) => {
            console.log('Error occurred in gettingLocalStorageData' + err);
          },
        })
    );
  }

  PEPCheck() {
    this.pepDisclim = false;
    if (this.panForm.get('selectedPEP') != null) {
      (this.pepVal = this.panForm.get('selectedPEP')?.value),
        (this.NewRegId =
          this.authService.getResponseValueByKey('fdUserDtlsId') || '');
      if (this.pepVal == 'Yes') {
        this.pepVal = 'Y';
        this.pepDisclim = true;
      } else if (this.pepVal == 'No') {
        this.pepVal = 'N';
        this.pepDisclim = false;
      }
      let data = {
        politicalExposedPerson: this.pepVal,
        newFdRegId: this.NewRegId,
      };
      this.subscription.add(
        this.apiService
          .PEPCheck(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (response != null) {
                if (response == 'Y') {
                  console.log(response);
                }
              }
            },
            error: (error) => {
              console.error('An error occurred:', error);
              // this.CommonError = "The server is currently busy. Please try again shortly";
            },
          })
      );
    }
  }

  PEPCheckForCKYC() {
    // this.pepDisclim = false;
    if (this.ekycForm.get('selectedPEP') != null) {
      let pepVal = '';
      (pepVal = this.ekycForm.get('selectedPEP')?.value),
        (this.NewRegId =
          this.authService.getResponseValueByKey('fdUserDtlsId') || '');
      if (pepVal == 'Yes') {
        pepVal = 'Y';
        this.pepDisclim = true;
      } else if (this.pepVal == 'No') {
        pepVal = 'N';
        this.pepDisclim = false;
      }
      let data = {
        politicalExposedPerson: pepVal,
        newFdRegId: this.NewRegId,
      };
      this.subscription.add(
        this.apiService
          .PEPCheck(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (response != null) {
                if (response == 'Y') {
                  console.log(response);
                }
              }
            },
            error: (error) => {
              console.error('An error occurred:', error);
              // this.CommonError = "The server is currently busy. Please try again shortly";
            },
          })
      );
    }
  }

  PEPCheckgurdian() {
    // this.pepDisclimgurd = false;
    if (this.guardianPanForm.get('guardianSelectedPEP') != null) {
      (this.pepVal = this.guardianPanForm.get('guardianSelectedPEP')?.value),
        (this.NewRegId =
          this.authService.getResponseValueByKey('fdUserDtlsId') || '');
      if (this.pepVal == 'Yes') {
        this.pepVal = 'Y';
        // this.pepDisclimgurd = true;
      } else if (this.pepVal == 'No') {
        this.pepVal = 'N';
        //  this.pepDisclimgurd = false;
      }
      let data = {
        politicalExposedPerson: this.pepVal,
        newFdRegId: this.NewRegId,
      };
      this.subscription.add(
        this.apiService
          .PEPCheck(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (response != null) {
                if (response == 'Y') {
                  console.log(response);
                }
              }
            },
            error: (error) => {
              console.error('An error occurred:', error);
              // this.CommonError = "The server is currently busy. Please try again shortly";
            },
          })
      );
    }
  }


  togglePepInfo(): void {
    this.pepDisclim = !this.pepDisclim;
  }

  togglePepInfoGuardian(): void {
    this.pepDisclimgurd = !this.pepDisclimgurd;
  }


  onDisagree() {
    this.showPEPDialog = false;
  }

  onAgree() {
    this.showPEPDialog = false;
  }

  finalSubmit() {
    if (this.panForm.valid || this.aadhaarForm.valid || this.ekycForm.valid) {
      this.router.navigate(['/dashboard/home']);
    } else {
      this.showAlert('warn', 'Warning', 'Please Complete All the Verification');
    }
  }

  updateStepperStatus() {
    this.mainSteps = [
      {
        label: 'KYC Verification',
        styleClass:
          this.aadhaarSubmitted && this.panSubmitted ? 'step-complete' : '',
      },
      {
        label: "Depositor's Account Details",
        styleClass: this.depositerDetailsSubmitted ? 'step-complete' : '',
      },
    ];
    this.cd.detectChanges();
  }

  onStepClick(index: number) {
    this.userDetailsView();
    if (index === 1 && (!this.panSubmitted || !this.aadhaarSubmitted)) {
      this.showAlert(
        'info',
        'KYC Pending',
        'Please complete the Pan and Aadhar verification to view Account Details'
      );
      return; // Prevent navigation
    }
    this.activeIndex = index;
    this.mainStepperIndex = index;
  }

  onStepOpen(event: any) {
    this.kycStepperIndex = event.index;
  }

  onPanInput(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    const upperCaseValue = inputElement.value.toUpperCase();
    this.panForm.controls['panNumber'].setValue(upperCaseValue, {
      emitEvent: false,
    });
  }

  characterSpaceNumberValidator(event: any) {
    this.customValidatorone.characterSpaceNumberValidator(event);
  }

  CharacterSpaceValidator(event: any) {
    this.customValidatorone.CharacterSpaceValidator(event);
  }

  toUpperCase(event: any) {
    this.customValidatorone.toUpperCase(event);
  }

  OnlyNumbervalidator(event: any) {
    this.customValidatorone.OnlyNumbervalidator(event);
  }

  handlePanInput(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('panNumber')?.setValue(upperValue);
  }

  handlePanInputOne(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('nameAsperOvd')?.setValue(upperValue);
  }

  gurdianhandlePanInput(event: any): void {
    const input = event.target;
    const sanitizedValue = input.value
      .replace(/[^a-zA-Z\s]/g, '')
      .toUpperCase();
    input.value = sanitizedValue;
    this.guardianPanForm
      .get('gurdianRelation')
      ?.setValue(sanitizedValue, { emitEvent: false });
  }

  gurdianhandhandlePanInput(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('guardianPanNumber')?.setValue(upperValue);
  }

  gurdianhandlePanInputOne(event: any): void {
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.panForm.get('guardianNameAsperOvd')?.setValue(upperValue);
  }

  verifyPan() {
    if (this.panAttemptCount < this.maxAttempts) {
      this.panAttemptCount++;
      if (this.panAttemptCount >= this.maxAttempts) {
        this.panDisabled = true;
        this.panAttemptMsg =
          'Max attempts reached for pan verification kindly try after some time';
        setTimeout(() => {
          this.panAttemptMsg = '';
          ``;
        }, 15000);
      }
    }
  }

  gettingLocalStorageData(loginId: string): void {
    // Change 'String' to 'string'
    localStorage.removeItem('UserDetails');
    let data = {
      fdUserId: loginId,
    };
    this.subscription.add(
      this.apiService
        .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response != null) {
              // const encrptRespon =this.crypto.encryptData(response);
              // this.authService.setresPonse(response);
              this.gettingLocalStorageDataOne(loginId);
            }
          },
          error: (err) => {
            console.log('Error occurred in gettingLocalStorageData' + err);
          },
        })
    );
  }

  showAlert(
    severity: 'success' | 'info' | 'warn' | 'error',
    summary: string,
    detail: string
  ) {
    const alert: AlertItem = {
      severity: severity,
      summary: summary,
      detail: detail,
    };
    this.alerts = [...this.alerts, alert];
    setTimeout(() => {
      const alertIndex = this.alerts.indexOf(alert);
      if (alertIndex > -1) {
        this.dismissAlert(alertIndex);
      }
    }, 5000);
  }

  onFDDisagree() {
    this.showFDConfirmationDialog = false;
    this.mainStepperIndex = 1;
  }

  onFDAgree() {
    this.showFDConfirmationDialog = false;
  }

  getDropdownListF(): void {
    this.subscription.add(
      this.apiService.getDropdownListF().subscribe({
        next: (response: any) => {
          if (response && response.gender) {
            this.genderOptions = Object.entries(response.gender).map(
              ([key, value]) => ({
                label: value,
                value: key,
              })
            );
          } else {
            response = {};
          }

          if (response && response.state) {
            this.stateOptions = Object.entries(response.state).map(
              ([key, value]) => ({
                label: value,
                value: key,
              })
            );
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log('An error occurred, something went wrong: ' + err);
        },
      })
    );
  }

  getDropdownListdata(): void {
    this.subscription.add(
      this.apiService.getDropdownList().subscribe({
        next: (response: any) => {
          if (response) {
            if (response) {
              this.occupationOption = response.occupationList.map(
                (item: string) => ({
                  label: item,
                  value: item,
                })
              );
            } else {
              response = {};
            }

            // this.occupationLists =response.occupationList;
            // this.schemeLists =response.schemeList;
            // this.subtypeLists =response.subtypeList;
            // this.htmTypeLists=response.htmTypeList;
            // this.invCatLsts =response.invCatLst;
            // this.CondtionLsts =response.CondtionLst;
            // this.accTypeLstas =response.accTypeLst;
            // this.instypNames =response.instypName;
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log('An error occurred something went wrong ' + err);
        },
      })
    );
  }

  getCombinedGuardianpanKycDetailsView(): void {
    const newRegId = this.authService.getResponseValueByKey('newFdRegId');
    const jointGuardMapFlag =
      this.authService.getResponseValueByKey('fdUserPan') || '';
    const pep = this.authService.getResponseValueByKey(
      'politicalExposedPerson'
    );
    if (!newRegId) {
      console.warn('newRegId is missing');
      return;
    }
    if (!jointGuardMapFlag) {
      console.warn('pan number is missing');
      return;
    }

    this.subscription.add(
      this.apiService
        .getCombinedGuardianKycDetails(newRegId, jointGuardMapFlag)
        .subscribe({
          next: (response: any) => {
            const guardians = response?.kycGuardJointHolders;
            const indv = response?.jointKycIndvDtls;
            const ekyc = response?.jointEkycData;

            if (!indv && !ekyc && (!guardians || guardians.length === 0)) {
              console.warn(
                'Combined KYC response is empty, falling back to userDetailsView'
              );
              return;
            }

            if (!guardians || guardians.length === 0) {
              console.warn('No guardian data found in response');
              return;
            }

            const guardian = guardians[0];

            // Format DOB
            let formattedDob = '';
            if (guardian?.dob) {
              const [year, month, day] = guardian.dob.split(/[-\/]/);
              formattedDob = `${year}-${month}-${day}`;
            }

            let pepStatus = '';
            if (pep === 'Y') {
              pepStatus = 'Yes';
            } else if (pep === 'N') {
              pepStatus = 'No';
            }
            this.guardianPanForm.patchValue({
              guardianKycbranchName: guardian.kycBranchCd?.trim() || 'select',
              guardianNameAsperOvd: guardian.name || '',
              guardiaDobAsPerPAN: formattedDob,
              guardianPanNumber: guardian.pan || '',
              gurdianRelation: guardian.relationship || '',
              gurdianEmail: guardian.userId || '',
              gurdianMobile: guardian.mobileNo || '',
              guardianSelectedPEP: pepStatus || '',
            });

            this.guardianAadhaarForm.patchValue({
              guardianAadhaarNumber: ekyc.aadharNo || '',
            });

            this.gurdianPanSubmitted = true;
            this.gurdianAadhaarSubmitted = true;
          },
          error: (err) => {
            console.error('Error fetching guardian KYC details:', err);
          },
        })
    );
  }

  userDetailsView(): any {
    let data = {
      newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
    };
    this.subscription.add(
      this.apiService
        .userDetailsView(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response) {
              console.log(response)
              if (response?.cif) {
                this.isCIFCustomer = true;
                this.panForm.disable();
                this.disableSubmit = true;
                this.aadhaarForm.disable();
              } else {
                this.panForm.enable();
                this.disableSubmit = false;
                this.aadhaarForm.enable();

              }

              if (response?.dob) {
                let mydob = response.dob;
                const [day, month, year] = mydob.split(/[/\-]/);
                const formattedDate = `${year}-${month}-${day}`; // '1999-05-20'
                this.panForm.get('dobAsPerPAN')?.setValue(formattedDate);
                this.ekycForm.get('dob')?.setValue(formattedDate);
                this.ekycForm.get('occupation')?.setValue(response.occupation);
                this.cd.detectChanges();
                //  const event = { target: { value: formattedDate } };
                // this.checkMinorStatusdumy(event);
              }
              if (response?.mobNum) {
                this.fdUserMobile = response.mobNum
              }

              if (response?.fdBranch) {
                const branch: string = response.fdBranch.trim();
                if (this.kycbranchName.includes(branch)) {
                  this.ekycForm.get('kycbranchName')?.setValue(branch);
                  this.panForm.get('kycbranchName')?.setValue(branch);
                  this.guardianPanForm
                    .get('guardianKycbranchName')
                    ?.setValue(branch);
                  this.cd.detectChanges();
                } else {
                  console.warn('Branch from response not found:', branch);
                  this.panForm.get('kycbranchName')?.setValue('select');
                  this.guardianPanForm
                    .get('guardianKycbranchName')
                    ?.setValue('select');
                  this.cd.detectChanges();
                }
              }

              this.vkycFlag = Number(response.vkycFlag);
              this.vkycURL = response.vkycUrl;
              if (this.vkycFlag === 1) {
                this.isVkycCompleted = true;
              } else if (this.vkycFlag === 0 && this.vkycURL) {
                this.vkycConfirmationAccepted = true;
              }

              response.address;
              let genderValue = '';
              switch (response.gender) {
                case 'Male':
                  genderValue = 'M';
                  break;
                case 'Female':
                  genderValue = 'F';
                  break;
                default:
                  genderValue = 'O';
              }

              this.isVkycCompleted = response?.vkycFlag === '1' ? true : false;
              let addressParts = response.address
                ? response.address.split(',')
                : [];
              let midIndex = Math.ceil(addressParts.length / 2); // Split at the middle
              let addLine1 = addressParts.slice(0, midIndex).join(',').trim();
              let addLine2 = addressParts.slice(midIndex).join(',').trim();

              this.ekycForm.patchValue({
                addLine1: addLine1,
                addLine2: addLine2,
                pinCode: response.pinCode,
                gender: genderValue,
                depositorName: response.shortName,
                borrowerLongName: response.firDepoName,
                fdUserPan: response.panNo,
                fdUserMobile: response.mobNum,
                fdUserEmail: response.email,
                payeeName: response.shortName || '',
                annualIncome: response?.annualIncome || '',
                maritalStatus: response?.maritalStatus || '',
                socialCategory: response?.socialCategory || '',
                minority: response?.minority || 'N',
                kycbranchName: response?.fdBranch || '',
                selectedPEP: response?.politicalExposedPerson == 'Y' ? 'Yes' : 'No'
              });

              this.ekycForm.get('fdUserPan')?.disable();
              this.ekycForm.get('depositorName')?.disable();
              this.ekycForm.get('borrowerLongName')?.disable();
              this.ekycForm.get('fdUserPan')?.disable();
              this.ekycForm.get('dob')?.disable();
              this.ekycForm.get('gender')?.disable();
              this.ekycForm.get('fdUserEmail')?.disable();
              this.ekycForm.get('fdUserMobile')?.disable();
              this.ekycForm.get('addLine1')?.disable();
              this.ekycForm.get('addLine2')?.disable();
              this.ekycForm.get('state')?.disable();
              this.ekycForm.get('city')?.disable();
              this.ekycForm.get('pinCode')?.disable();

              this.cd.detectChanges();
              this.getCombinedGuardianKycDetailsView();
              this.getStateCode(response.state, response.city);

            } else {
              response = {};
            }
          },
          error: (err) => {
            console.log('An error occurred something went wrong ' + err);
          },
        })
    );
  }

  getCombinedGuardianKycDetailsView(): void {
    const newRegId = this.authService.getResponseValueByKey('newFdRegId');
    const jointGuardMapFlag =
      this.authService.getResponseValueByKey('fdUserPan') || '';
    if (!newRegId) {
      console.warn('newRegId is missing, falling back to userDetailsView');
      return;
    }

    if (!jointGuardMapFlag) {
      console.warn('pan  missing, falling back to userDetailsView');
      return;
    }
    this.subscription.add(
      this.apiService
        .getCombinedGuardianKycDetails(newRegId, jointGuardMapFlag)
        .subscribe({
          next: (response: any) => {
            const indv = response?.jointKycIndvDtls;
            const ekyc = response?.jointEkycData;
            const guardians = response?.kycGuardJointHolders;
            if (!indv && !ekyc && (!guardians || guardians.length === 0)) {
              console.warn(
                'Combined KYC response is empty, falling back to userDetailsView'
              );
              return;
            }

            if (ekyc?.house && ekyc?.street) {
              this.ekycForm.patchValue({
                addLine1: ekyc.house,
                addLine2: ekyc.street,
                pinCode: ekyc?.pincode ?? '',
                payeeName: ekyc?.name ?? '',
              });
              this.cd.detectChanges();
            }
          },
          error: (err) => {
            console.error('Error fetching combined KYC details:', err);
          },
        })
    );
  }

  getStateCode(stateName: string, city: String): any {
    let data = {
      state: stateName,
      district: city,
    };
    this.subscription.add(
      this.apiService.getstateCode(data).subscribe({
        next: (response: any) => {
          if (response) {
            this.ekycForm.patchValue({
              state: response,
            });
            this.cd.detectChanges();
            if (this.getcityCodedataFlag == false) {
              this.getcity();
            }

            this.getcityCodedata(response, city);
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log('An error occurred something went wrong ' + err);
        },
      })
    );
  }

  getcityCodedata(stateName: string, distName: any): any {
    this.stateName = this.form.state;
    let data = {
      state: stateName,
      district: distName,
    };
    this.subscription.add(
      this.apiService.getcityCode(data).subscribe({
        next: (response: any) => {
          if (response) {
            this.getcityCodedataFlag = true;
            this.ekycForm.controls['city'].setValue(response);
            this.cd.detectChanges();
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log('An error occurred something went wrong ' + err);
        },
      })
    );
  }

  getcity(): void {
    this.stateName = this.ekycForm.get('state')?.value;
    let data = {
      state: this.stateName,
    };
    this.subscription.add(
      this.apiService.getcity(data).subscribe({
        next: (response: any) => {
          if (response) {
            this.cityOptions = Object.entries(response.district).map(
              ([key, value]) => ({
                label: value,
                value: key,
              })
            );
          } else {
            response = {};
          }
        },
        error: (err) => {
          console.log(
            'An error occurred in getingState something went wrong ' + err
          );
        },
      })
    );
  }

  getcityCode(): void {
    this.stateName = this.ekycForm.get('state')?.value;
    let data = {
      state: this.stateName,
    };
    this.subscription.add(
      this.apiService.getcity(data).subscribe({
        next: (response: any) => {
          if (response) {
            this.districs = response.district;
          } else {
            this.districs = response = {};
          }
        },
        error: (err) => {
          console.log(
            'An error occurred in getingState something went wrong ' + err
          );
        },
      })
    );
  }

  belowOneLaks() {
    //this.mainStepperIndex = 1;
    this.router.navigate(['/dashboard/createFD']);
    this.isSelectedBelowOneLaks = 'Y';
    if (!this.panSubmitted && !this.aadhaarSubmitted) {
      this.showAlert(
        'info',
        'KYC Pending',
        'Please complete the Pan and Aadhar verification to proceed to Account Details'
      );
    }
  }

  gurdianbelowOneLaks() {
    this.mainStepperIndex = 1;
    this.isSelectedBelowOneLaks = 'Y';
    if (!this.gurdianPanSubmitted && !this.gurdianAadhaarSubmitted) {
      this.showAlert(
        'info',
        'KYC Pending',
        'Please complete the Pan and Aadhar verification to proceed to Account Details'
      );
    }
  }
  gurdiandoVkycProcess() {
    if (!this.gurdianPanSubmitted || !this.gurdianAadhaarSubmitted) {
      this.showAlert(
        'info',
        'KYC Pending',
        'Please complete both Pan and Aadhar verification to proceed to VKYC Verification'
      );
      if (!this.gurdianPanSubmitted) {
        this.activeAccordionIndex = 0;
        return;
      } else if (!this.gurdianAadhaarSubmitted) {
        this.activeAccordionIndex = 1;
        return;
      }
    }
    const rawDob = this.guardianPanForm.get('guardiaDobAsPerPAN')?.value;
    let formattedDob = '';
    if (rawDob) {
      const dateObj = new Date(rawDob);
      const day = String(dateObj.getDate()).padStart(2, '0');
      const month = String(dateObj.getMonth() + 1).padStart(2, '0');
      const year = dateObj.getFullYear();
      formattedDob = `${day}-${month}-${year}`; // This is a string
    }
    const data = {
      name: this.guardianPanForm.get('guardianNameAsperOvd')?.value,
      namePrintedInPan: this.guardianPanForm.get('guardianNameAsperOvd')?.value,
      dob: formattedDob,
      pan: this.guardianPanForm.get('guardianPanNumber')?.value,
      panValidation: 'false',
      email: this.guardianPanForm.get('gurdianEmail')?.value,
      mobile: this.guardianPanForm.get('gurdianMobile')?.value,
    };

    const vkycPan = this.guardianPanForm.get('guardianPanNumber')?.value;
    const vkycDob = formattedDob;

    const isEmpty = (v: any) =>
      v == null || (typeof v === 'string' && v.trim() === '');

    if (isEmpty(vkycPan) || isEmpty(vkycDob)) {

      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.'
      );
      return;
    }
    if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.'
      );
      return;
    }
    if (isEmpty(vkycPan)) {
      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your PAN is not updated in our records.'
      );
      return;
    }
    if (isEmpty(vkycDob)) {

      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your Date of Birth is not updated in our records.'
      );
      return;
    }

    this.spinner.show();
    this.subscription.add(
      this.apiService
        .doVkycProcessService(
          this.hybridEncryptor.encrypted(JSON.stringify(data))
        )
        .subscribe({
          next: (response: any) => {
            if (response.statusCode == 1002) {
              this.spinner.hide();
              this.vkycConfirmationAccepted = true;
              this.vkycInitiated = true;
              const formated = JSON.parse(response.message);
              this.vkycURL = formated.vkycURL; // Store the URL
            } else {
              this.spinner.hide();
              this.vkycLinkFetchError = true;
              this.vkycInitiated = false;
              this.vkycConfirmationAccepted = false;
              this.vkycURL = '';
              this.showAlert(
                'error',
                'Error Initiating VKYC',
                'Error ocurred while initiating VKYC'
              );
            }
          },
          error: (err) => {
            this.spinner.hide();
            console.log('An error occurred something went wrong ' + err);
            this.vkycLinkFetchError = true;
            this.vkycInitiated = false;
            this.vkycConfirmationAccepted = false;
            this.vkycURL = '';
            this.showAlert(
              'error',
              'Error Initiating VKYC',
              'Error ocurred while initiating VKYC'
            );
          },
        })
    );
  }

  doVkycProcess() {
    if (!this.panSubmitted || !this.aadhaarSubmitted) {
      this.showAlert(
        'info',
        'KYC Pending',
        'Please complete both Pan and Aadhar verification to proceed to VKYC Verification'
      );
      if (!this.panSubmitted) {
        this.activeAccordionIndex = 0;
        return;
      } else if (!this.aadhaarSubmitted) {
        this.activeAccordionIndex = 1;
        return;
      }
    }
    const rawDob = this.ekycForm.get('dob')?.value;
    let formattedDob = '';
    if (rawDob) {
      const dateObj = new Date(rawDob);
      const day = String(dateObj.getDate()).padStart(2, '0');
      const month = String(dateObj.getMonth() + 1).padStart(2, '0');
      const year = dateObj.getFullYear();
      formattedDob = `${day}-${month}-${year}`; // This is a string
    }
    const data = {
      name: this.ekycForm.get('depositorName')?.value,
      namePrintedInPan: this.ekycForm.get('depositorName')?.value,
      dob: formattedDob,
      pan: this.ekycForm.get('fdUserPan')?.value,
      panValidation: 'false',
      email: this.ekycForm.get('fdUserEmail')?.value,
      mobile: this.ekycForm.get('fdUserMobile')?.value,
    };

    const vkycPan = data.pan //this.ekycForm.get('fdUserPan')?.value;
    const vkycDob = formattedDob;

    const isEmpty = (v: any) =>
      v == null || (typeof v === 'string' && v.trim() === '');

    if (isEmpty(vkycPan) || isEmpty(vkycDob)) {

      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your Date of Birth/PAN is not updated in our records.'
      );
      return;
    }
    if (isEmpty(vkycPan) && isEmpty(vkycDob)) {
      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your Date of Birth and PAN are not updated in our records.'
      );
      return;
    }
    if (isEmpty(vkycPan)) {
      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your PAN is not updated in our records.'
      );
      return;
    }
    if (isEmpty(vkycDob)) {

      this.showAlert(
        'info',
        'VKYC',
        'Unable to proceed with VKYC as your Date of Birth is not updated in our records.'
      );
      return;
    }


    this.spinner.show();
    this.subscription.add(
      this.apiService
        .doVkycProcessService(
          this.hybridEncryptor.encrypted(JSON.stringify(data))
        )
        .subscribe({
          next: (response: any) => {
            if (response.statusCode == 1002) {
              this.spinner.hide();
              this.vkycConfirmationAccepted = true;
              this.vkycInitiated = true;
              const formated = JSON.parse(response.message);
              this.vkycURL = formated.vkycURL; // Store the URL
            } else {
              this.spinner.hide();
              this.vkycLinkFetchError = true;
              this.vkycInitiated = false;
              this.vkycConfirmationAccepted = false;
              this.vkycURL = '';
              this.showAlert(
                'error',
                'Error Initiating VKYC',
                'Error ocurred while initiating VKYC'
              );
            }
          },
          error: (err) => {
            this.spinner.hide();
            console.log('An error occurred something went wrong ' + err);
            this.vkycLinkFetchError = true;
            this.vkycInitiated = false;
            this.vkycConfirmationAccepted = false;
            this.vkycURL = '';
            this.showAlert(
              'error',
              'Error Initiating VKYC',
              'Error ocurred while initiating VKYC'
            );
          },
        })
    );
    // this.vkycURL =
    //   'https://gitlab.sidbi.in/root/sidbifd-frontend/-/commits/fdChanges-latest?ref_type=heads';
  }
  openVkycWindow() {
    // commented window styling done
    // const width = 500;
    // const height = 500;
    // const left = Math.floor(window.screen.width );
    // const top = Math.floor(window.screen.height - height) / 2);
    // width=${width},height=${height},top=${top},left=${left}
    const features = `resizable=yes,scrollbars=yes`;
    window.open(this.vkycURL, '_blank');
    this.showAlert(
      'success',
      'VKYC Initiated',
      'Your VKYC has been initiated successfully'
    );
  }

  getBankDetails(): void {
    this.branchName = this.authService.getResponseValueByKey('kycBranchName');
    let data = {
      kycBranchName: this.branchName,
    };
    this.subscription.add(
      this.apiService
        .getBankDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response) {
              this.bank_NAME = response.split(',')[0];
              this.BANKACC_NO = response.split(',')[1];
              this.BANKIFSC_CODE = response.split(',')[2];
              if (this.cookieService.get('remitterAcc') !== this.BANKACC_NO) {
                this.cookieService.set('remitterAcc', this.BANKACC_NO, {
                  path: '/',
                  secure: true,
                  sameSite: 'Strict',
                  expires: new Date(new Date().getTime() + 20 * 60 * 1000),
                });
              }
            }
          },
        })
    );
  }

  getUserBankDetails(): void {
    const data = {
      fdRegId: this.authService.getResponseValueByKey('newFdRegId'),
    };
    const encryptedPayload = this.hybridEncryptor.encrypted(
      JSON.stringify(data)
    );
    this.subscription.add(
      this.apiService.getbankDetails(encryptedPayload).subscribe({
        next: (response: any) => {
          if (response && response.length > 0) {
            const bankDetails = response[0];
            this.bankInfoFlag = true;
            this.toggleFormState();
            this.ekycForm.patchValue({
              accType: bankDetails.custAccType?.toLowerCase(), // Ensure it matches the dropdown value
              bankName: bankDetails.custBankName,
              branch: bankDetails.custBranch,
              payeeName: bankDetails.payeeName,
              accNum: bankDetails.custAccNum,
              ifsc: bankDetails.custIfsc,
            });
            this.isIfscVerified = true;
          } else {
            this.bankInfoFlag = false;
            this.toggleFormState();
          }
        },
        error: (err) => {
          console.error('Error fetching bank details:', err);
        },
      })
    );
  }

  formatDate(date: string, format: string, locale: string): string {
    return formatDate(date, format, locale);
  }

  navigateDepositer() {
    this.mainStepperIndex = 1;
    this.vkycInitiated = true;
    this.disclaimerStatus = true;
  }
  gettingLocalStorageDataOne(loginId: string): void {
    localStorage.removeItem('RESPONSEDATA');
    let data = {
      fdUserId: loginId,
    };
    this.subscription.add(
      this.apiService
        .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response != null) {
              let encrypt = this.hybridEncryptor.encrypted(
                JSON.stringify(response)
              );
              this.authService.responseData(JSON.stringify(encrypt));
              // this.aadharpanSedingstatus();
            }
          },
          error: (err) => {
            console.log('Error occurred in gettingLocalStorageData' + err);
          },
        })
    );
  }

  aadharpanSedingstatus() {
    const mailId = this.authService.getResponseValueByKey('fdUserEmail') || '';
    const data = {
      fdUserId: mailId,
    };
    this.subscription.add(
      this.apiService
        .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response != null) {
              const panSeeding = response['panSeeding'] || '';
              const panAadharFlag = response['panAadharFlag'] || '';
              const isSeeded = this.authService.aadharpanSeedingStatus(
                panSeeding,
                panAadharFlag
              );
              if (!isSeeded) {
                this.isDisclimar = true;
              }
            }
          },
          error: (err) => {
            console.log('Error occurred in gettingLocalStorageData: ' + err);
          },
        })
    );
  }

  checkMinorStatusdumy(event: any): void {
    const dob = new Date(event.target.value);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
      age--;
    }

    if (age >= 18) {
      this.guardianKYCFlag = true;
      this.isGuardianAddress = false;
      this.isGuardianBank = false;
    } else {
      // Minor
      // Show Guardian KYC
      this.isGuardianAddress = true;
      this.isGuardianBank = true;
      this.guardianKYCFlag = false;
      // Major

      this.guardianVKYChiddenFlag = true;
      this.panForm.get('selectedPEP')?.clearValidators();
      this.panForm.get('selectedPEP')?.updateValueAndValidity();
      this.finalObjectforGurdian = {
        pan: null,
        aadharNo: null,
        name: null,
        dob: null,
        guardFlag: 'Y',
        panVerifyFlag: null,
        aadharFlag: null,
        kycBranchCd: null,
        postalCode: '',
        userId: this.authService.getResponseValueByKey('fdUserId'),
        relationship: null,
        mobileNo: null,
        jointGuardMapFlag: null,
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
      };

      // Hide Guardian KYC
    }
  }
  checkMinorStatus(event: any): void {
    const dob = new Date(event.target.value);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
      age--;
    }

    if (age >= 18) {
      this.guardianKYCFlag = true;
      this.isGuardianAddress = false;
      this.isGuardianBank = false;
    } else {
      const modalElement = document.getElementById('MinorPopUp');
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
      this.panForm.get('panNumber')?.reset();
      this.panForm.get('nameAsperOvd')?.reset();
      this.panForm.get('dobAsPerPAN')?.disable();
    }
  }
  closeModel() {
    const modalElement = document.getElementById('MinorPopUp');
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
      modalInstance.hide();
    }
  }

  UpdatedfinalrequestForGurdian(where: string) {
    console.log('where', where);
    if (where == 'PAN') {
      this.finalObjectforGurdian.pan =
        this.guardianPanForm.get('guardianPanNumber')?.value;
      this.finalObjectforGurdian.dob =
        this.guardianPanForm.get('guardiaDobAsPerPAN')?.value;
      this.finalObjectforGurdian.kycBranchCd = this.guardianPanForm.get(
        'guardianKycbranchName'
      )?.value;
      this.finalObjectforGurdian.name = this.guardianPanForm.get(
        'guardianNameAsperOvd'
      )?.value;
      this.finalObjectforGurdian.relationship =
        this.guardianPanForm.get('gurdianRelation')?.value;
      this.finalObjectforGurdian.mobileNo =
        this.guardianPanForm.get('gurdianMobile')?.value;
      this.finalObjectforGurdian.panVerifyFlag = 'Y';
    } else {
      this.finalObjectforGurdian.aadharFlag = 'Y';
      this.finalObjectforGurdian.aadharNo = this.guardianAadhaarForm.get(
        'guardianAadhaarNumber'
      )?.value;
      this.finalObjectforGurdian.jointGuardMapFlag =
        this.panForm.get('panNumber')?.value;
    }
    console.log('req', this.finalObjectforGurdian);
    this.saveHoldGuardDetails(this.finalObjectforGurdian);
  }

  saveHoldGuardDetails(finalObjectforGurdian: any) {
    if (
      finalObjectforGurdian.panVerifyFlag == 'Y' &&
      finalObjectforGurdian.aadharFlag == 'Y'
    ) {
      this.subscription.add(
        this.apiService
          .saveHoldGuardDetails(
            this.hybridEncryptor.encrypted(
              JSON.stringify(finalObjectforGurdian)
            )
          )
          .subscribe({
            next: (response: any) => {
              if (response != null) {
                this.showAlert(
                  'info',
                  'KYC',
                  'Guardian KYC has been completed successfully.'
                );
              } else {
                this.showAlert(
                  'info',
                  'KYC',
                  ' Guardian KYC is not completed. Please update the details to proceed.'
                );
              }
            },
            error: (err) => {
              console.log('Error occurred in gettingLocalStorageData: ' + err);
            },
          })
      );
    }
  }

  // checkAndResetFutureDate(controlName: string) {
  //   const control = this.panForm.get(controlName);
  //   if (!control || !control.value) return;

  //   const inputDate = new Date(control.value);
  //   const today = new Date();
  //   today.setHours(0, 0, 0, 0);

  //   if (inputDate > today) {
  //     control.setValue('');
  //   }
  // }

  checkAndResetFutureDate(controlName: string) {
    let control: any;
    if (controlName === 'dobAsPerPAN') {
      control = this.panForm.get(controlName);
    } else {
      control = this.guardianPanForm.get(controlName);
    }

    if (!control || !control.value) return;

    const inputDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (inputDate > today) {
      control.setValue('');
    }
  }
  private checkNamesAndProceed(payeeName: string, bankName: string) {
    const pct = this.customValidator.nameMatchPercentage(payeeName, bankName);
    const THRESHOLD = 85;
    if (pct >= THRESHOLD) {
      this.showAlert('success', 'Success', `Your Bank account verified successfully.`);
      this.bankverifyflag = true;
      this.accountVerifed = true;
    } else {
      this.showAlert(
        'error',
        'Account Verification Failed',
        'Please enter Valid bank information'
      );
      this.bankverifyflag = false;
      this.accountVerifed = false;

    }


  }

  ifsCodevalidator(event: any): void {
    this.customValidatorifsc.ifsCodevalidator(event); // Call the custom validator from the service
    const input = event.target;
    const upperValue = input.value.toUpperCase();
    input.value = upperValue;
    this.ekycForm.get('ifsc')?.setValue(upperValue);

  }

  verifyIfsc(): void {
    const ifsc = this.ekycForm.get('ifsc')?.value;

    if (!ifsc) {
      return;
    }

    this.subscription.add(
      this.apiService.ifscValidate(ifsc).subscribe({
        next: (response: any) => {
          if (response) {
            const bankName = response.bankName
            const branchName = response.branchName

            this.ekycForm.get('bankName')?.setValue(bankName);
            this.ekycForm.get('branch')?.setValue(branchName);

            this.ekycForm.get('bankName')?.disable();
            this.ekycForm.get('branch')?.disable();

            this.isIfscVerified = true;

          }
        },
        error: (err: any) => {
          console.log('An error occurred something went wrong ' + err);
          if (err.status == 404) {
            this.showAlert('error', 'IFSC Verification', `Given IFSC code is Invalid`);
            this.ekycForm.get('ifsc')?.setValue("");
          }
        },
      })
    );


  }


  submitCKYC(): void {
    if (!this.ckycOtpRequested) {
      this.showAlert(
        'warn',
        'OTP Required',
        'Please verify OTP for the CKYC number before proceeding'
      );
      return;
    }

    if (this.ckycForm.invalid) {
      this.showAlert(
        'warn',
        'Validation Error',
        'Please fill all CKYC details correctly'
      );
      return;
    }


    const payload = {
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
      ckycNo: this.ckycForm.get('kycNo')?.value,
      authfactorType: '03',
      authFactor: this.fdUserMobile,
      reqType: 'IND',
      requestId: this.ckycRequestId, //✅ SAME requestId
      ckycOtp: this.ckycForm.get('authFactor')?.value, //✅ OTP from input
    };


    this.spinner.show();

    this.subscription.add(
      this.apiService
        .getckycdata(
          this.hybridEncryptor.encrypted(JSON.stringify(payload))
        )
        .subscribe({
          next: (response: any) => {
            this.spinner.hide();

            if (response?.ekycdata) {
              this.ckycSubmitted = true;
              this.ckycForm.disable();

              console.log("second", payload);

              this.showAlert(
                'success',
                'CKYC Verified',
                'CKYC verification completed successfully'
              );

              // ✅ Optional: move user to next step
              // this.activeAccordionIndex = 0;

              this.spinner.show();
              this.userDetailsView();
              this.activeAccordion();

              setTimeout(() => {
                this.spinner.hide();

                this.mainStepperIndex = 1;

                this.ekycForm.get('fdUserPan')?.disable();
                this.ekycForm.get('depositorName')?.disable();
                this.ekycForm.get('borrowerLongName')?.disable();
                this.ekycForm.get('fdUserPan')?.disable();
                this.ekycForm.get('dob')?.disable();
                this.ekycForm.get('gender')?.disable();
                this.ekycForm.get('fdUserEmail')?.disable();
                this.ekycForm.get('fdUserMobile')?.disable();
                this.ekycForm.get('addLine1')?.disable();
                this.ekycForm.get('addLine2')?.disable();
                this.ekycForm.get('state')?.disable();
                this.ekycForm.get('city')?.disable();
                this.ekycForm.get('pinCode')?.disable();


                this.cd.detectChanges();
              }, 2000)

            } else if (response.validationError) {
              this.showAlert(
                'error',
                'CKYC Failed',
                response?.validationError || 'CKYC verification failed'
              );
            }
            else {
              this.showAlert(
                'error',
                'CKYC Failed',
                response?.message || 'CKYC verification failed'
              );
            }
          },
          error: () => {
            this.spinner.hide();
            this.showAlert(
              'error',
              'Server Error',
              'Unable to process CKYC verification'
            );
          },
        })
    );
  }

  requestCKYCOTP(): void {

    console.log("mobile>>>", this.fdUserMobile);
    const kycNoControl = this.ckycForm.get('kycNo');

    if (kycNoControl?.invalid) {
      kycNoControl.markAsTouched();
      this.showAlert(
        'warn',
        'Validation Error',
        'Please enter a valid CKYC number'
      );
      return;
    }

    this.ckycRequestId = this.generate6DigitRequestId();

    const payload = {
      fdUserId: this.authService.getResponseValueByKey('fdUserId'),
      ckycNo: kycNoControl?.value,
      authfactorType: "03",
      authFactor: this.fdUserMobile,
      reqType: 'IND',
      requestId: this.ckycRequestId,
    };

    this.spinner.show();
    this.subscription.add(
      this.apiService
        .ckycVerification(
          this.hybridEncryptor.encrypted(JSON.stringify(payload))
        )
        .subscribe({
          next: (response: any) => {
            this.spinner.hide();
            console.log("first", payload);

            if (response?.requestedId) {
              this.ckycForm.get('requestedId')?.setValue(response.requestedId);
            }

            if (this.isCkycSuccessResponse(response)) {
              this.ckycOtpRequested = true;


              // ✅ persist for safety (optional)
              localStorage.setItem('CKYC_REQUEST_ID', this.ckycRequestId);


              this.ckycForm.get('authFactor')?.reset();

              this.showAlert(
                'success',
                'OTP Sent',
                response?.data || 'OTP has been sent for CKYC verification'
              );
            } else {
              this.showAlert(
                'error',
                'OTP Failed',
                response?.data || 'Unable to send OTP for the CKYC number'
              );
            }
          },
          error: () => {
            this.spinner.hide();
            this.showAlert(
              'error',
              'Server Error',
              'Unable to send CKYC OTP'
            );
          },
        })
    );
  }

  private resetCkycOtpStep(): void {
    if (!this.ckycOtpRequested) {
      return;
    }

    this.ckycOtpRequested = false;
    this.ckycForm.get('authFactor')?.reset();
    this.ckycForm.get('requestedId')?.reset();
  }

  private isCkycSuccessResponse(response: any): boolean {
    const statusCode = response?.statusCode?.toString();
    return (
      statusCode === '1000' ||
      statusCode === '1002' ||
      response?.success === true ||
      response?.status?.toString().toLowerCase() === 'success'
    );
  }

  private generate6DigitRequestId(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }


  startOtpTimers(): void {
    this.clearOtpTimers();

    this.otpSent = true;
    this.canResendOtp = false;
    this.resendOtpTimer = 60;
    this.otpExpiryTimer = 600;

    this.resendInterval = setInterval(() => {
      this.resendOtpTimer--;

      if (this.resendOtpTimer <= 0) {
        this.canResendOtp = true;
        clearInterval(this.resendInterval);
      }
    }, 1000);

    this.expiryInterval = setInterval(() => {
      this.otpExpiryTimer--;

      if (this.otpExpiryTimer <= 0) {
        clearInterval(this.expiryInterval);
        this.canResendOtp = true;

        this.aadhaarForm.get('aadhaarOtp')?.reset();

        this.showAlert(
          'warn',
          'OTP Expired',
          'Your Aadhaar OTP has expired. Please resend OTP.'
        );
      }
    }, 1000);
  }

  clearOtpTimers(): void {
    if (this.resendInterval) {
      clearInterval(this.resendInterval);
    }

    if (this.expiryInterval) {
      clearInterval(this.expiryInterval);
    }
  }



}
