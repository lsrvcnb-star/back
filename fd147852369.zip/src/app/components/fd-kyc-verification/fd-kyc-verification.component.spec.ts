import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FdKycVerificationComponent } from './fd-kyc-verification.component';

describe('FdKycVerificationComponent', () => {
  let component: FdKycVerificationComponent;
  let fixture: ComponentFixture<FdKycVerificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FdKycVerificationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FdKycVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
