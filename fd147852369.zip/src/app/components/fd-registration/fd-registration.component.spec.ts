import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FdRegistrationComponent } from './fd-registration.component';

describe('FdRegistrationComponent', () => {
  let component: FdRegistrationComponent;
  let fixture: ComponentFixture<FdRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FdRegistrationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FdRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
