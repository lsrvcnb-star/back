import {
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ElementRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  AbstractControl,
  ValidationErrors,
} from '@angular/forms';
import { Subscription, timer } from 'rxjs';
import { ApiService } from '../../service/api.service';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AppVersion } from '../../config';
import { CustomValidator } from '../../modules/admin/Constom/validator';
import { HybridEncryptor } from '../../Services/HybridEncryptor';
import { CustomValidatorService } from '../../service/custom-validator-service.service';
import { TimeFormatPipe } from '../../time-format.pipe';
import { AccessibilityFontSizeComponent } from '../accessibility-font-size/accessibility-font-size.component';

declare var bootstrap: any; // Needed to access Bootstrap JS

@Component({
  selector: 'app-fd-registration',
  templateUrl: './fd-registration.component.html',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, TimeFormatPipe, AccessibilityFontSizeComponent],
  styleUrls: ['./fd-registration.component.scss'],
})
export class FdRegistrationComponent implements OnInit, OnDestroy {
  iscaptchaSuccess: Boolean = false;
  userRegistration!: FormGroup;
  subscription: Subscription = new Subscription();
  siteKey: any;
  captchaVerified: boolean = false;
  captchaResult: any;
  emailError: string = '';
  OTPSentMsg!: string;
  fdUserId!: string;
  fdUserMobileone!: any;
  otpErrorMsg!: String;
  OTPSentMsgErr!: String;
  MailOTPSentMsgErr!: String;
  MailOTPSentMsg!: String;
  mailOTPverifiSucsMsg!: string;
  mailOTPverifiErrMsg!: String;
  CaptchaVerificationMsg!: String;
  CaptchaVerificationMsgError!: String;
  captchaValid: boolean = false;
  isOTPSent: boolean = false;
  regOTPValidSentMsg!: String;
  regOTPValidSentMsgErr!: string;
  ErrorMsgErr!: string;
  appversion: string = AppVersion;
  test: Date = new Date();
  ErrorMailmsg!: string;
  // for timer
  countdown: number = 45;
  intervalId: any;

  isMailVerifyButtonDisabled = true;
  isMailOtpVerifySuccess: Boolean = false;
  isMailResendOTP: Boolean = false;

  isMobileVerifyButtonDisabled = true;
  isMobileOtpVerifySuccess: Boolean = false;
  isMobileResendOTP: Boolean = false;

  isMailOtpVerified: Boolean = false;
  isMobileOtpVerified: Boolean = false;

  alertMsg!: string;

  customValidator: CustomValidator = new CustomValidator();
  private hybridEncryptor!: HybridEncryptor;
  @ViewChild('captchaCanvas', { static: true })
  captchaCanvas!: ElementRef<HTMLCanvasElement>;
  ngAfterViewInit(): void {
    this.CustomValidatorService.setCanvasRef(this.captchaCanvas);
  }
  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private router: Router,
    private CustomValidatorService: CustomValidatorService
  ) { }

  ngOnInit(): void {
    this.hybridEncryptor = new HybridEncryptor();
    this.userRegistration = this.fb.group(
      {
        fdUserId: [
          '',
          [
            Validators.required,
            Validators.pattern(
              /^[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]{3,}\.[a-zA-Z]{2,}$/
            ),
          ],
        ],
        fdUserPassword: [
          { value: '', disabled: true },
          [
            Validators.required,
            Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/),
          ],
        ],
        // emailOTP:['',Validators.pattern(/^\d{1,6}$/)],
        mailOTP: [
          '',
          [
            Validators.required,
            Validators.pattern(/^\d{1,6}$/), // Exactly 6 digits
            Validators.minLength(1), // Minimum length
            Validators.maxLength(6), // Maximum length
          ],
        ],
        VerifyOTP: ['verify otp'],
        StrFdMailActivationOptCD: [
          { value: '', disabled: true },
          [Validators.required, Validators.pattern(/^\d{1,6}$/)],
        ],
        j_captcha_response: [
          { value: '', disabled: true },
          [Validators.required, Validators.pattern(/^[A-Za-z0-9]{4}$/)],
        ],
        fdUserName: [
          { value: '', disabled: true },
          [Validators.required, Validators.pattern(/^[a-zA-Z ]+$/)],
        ],
        fdLastName: [
          { value: '', disabled: true },
          [Validators.required, Validators.pattern(/^[a-zA-Z ]+$/)],
        ],
        confirmPassword: [{ value: '', disabled: true }, [Validators.required]],
        fdUserMobile: [
          { value: '', disabled: true },
          [Validators.required, Validators.pattern(/^\d{10}$/)],
        ],
      },
      { validator: this.passwordMatchValidator }
    );

    this.getCaptcha();
    // this.userRegistration
    //   .get('j_captcha_response')
    //   ?.valueChanges.subscribe(() => {
    //     this.verifyCaptcha();
    //   });

    this.userRegistration.get('fdUserMobile')?.valueChanges.subscribe(() => {
    this.OTPSentMsg = '';
    this.OTPSentMsgErr = '';
  });
  }

  get email() {
    return this.userRegistration.get('fdUserId');
  }

  get password() {
    return this.userRegistration.get('fdUserPassword');
  }

  get otp() {
    return this.userRegistration.get('StrFdMailActivationOptCD');
  }

  get captcha() {
    return this.userRegistration.get('j_captcha_response');
  }

  get fdUserName() {
    return this.userRegistration.get('fdUserName');
  }

  get fdLastName() {
    return this.userRegistration.get('fdLastName');
  }

  get confirmPassword() {
    return this.userRegistration.get('confirmPassword');
  }

  get mobileNumber() {
    return this.userRegistration.get('fdUserMobile');
  }

  get mailOTP() {
    return this.userRegistration.get('mailOTP');
  }

  get form() {
    return this.userRegistration.value;
  }

  CharacterSpacevalidator(event: any) {
    this.customValidator.CharacterSpaceValidator(event);
  }

  numberOnly(event: any) {
    this.customValidator.OnlyNumbervalidator(event);
  }

  characterSpaceNumberValidator(event: any) {
    this.customValidator.characterSpaceNumberValidator(event);
  }

  FloatValue(event: any) {
    this.customValidator.FloatValue(event);
  }

  ifsCodevalidator(event: any) {
    this.customValidator.ifsCodevalidator(event);
  }

  AddressValidator(event: any) {
    this.customValidator.AddressValidator(event);
  }

  getCaptcha(): void {
    this.captchaVerified = false;
    this.subscription.add(
      this.apiService.getCaptcha().subscribe({
        next: (response: any) => {
       
          this.captchaResult = response.systemCaptcha;
          if (this.captchaResult) {
            // this.drawCaptcha(this.captchaResult);
            this.CustomValidatorService.drawCaptcha(this.captchaResult);
          }
        },
      })
    );
  }

  verifyCaptcha(): void {
    // Get the current value of the captcha input

    const captchaInput = this.userRegistration.get('j_captcha_response')?.value;
    // Check if the input matches the system captcha
    if (captchaInput === this.captchaResult) {
      this.captchaValid = true;
      this.iscaptchaSuccess = true;
      this.CaptchaVerificationMsg = 'Captcha is verified';
      this.CaptchaVerificationMsgError = '';
      this.userRegistration.get('j_captcha_response')?.disable();
    } else {
      this.captchaValid = false;
      this.CaptchaVerificationMsg = '';
      this.CaptchaVerificationMsgError = 'Captcha Mismatch!';
    }
  }

  // for OTP

  sendOtpforEmailandMobile(value: String): void {
    if (value == 'Email') {
      let data1 = {
        fdUserId: this.form.fdUserId,
      };
      this.subscription.add(
        this.apiService.checkCustomerExist(JSON.stringify(data1)).subscribe({
          next: (response: any) => {
            const jsonObject = JSON.parse(response);
            if (jsonObject.validUser && jsonObject.validUser === 'NotCIFUser') {
              this.alertMsg = 'This Email ID already Registered';
              const modalElement = document.getElementById('submitModal');
              const modal = new bootstrap.Modal(modalElement);
              modal.show();
            } else if (
              jsonObject.validUser &&
              jsonObject.validUser === 'ExistUser'
            ) {
              this.emailError = 'User Already Registered, Please Login';
            } else if (
              jsonObject.validUser &&
              jsonObject.validUser == 'NewUSer' || jsonObject.validUser === 'CIFUser'
            ) {
              this.sendOTPMail('Email');
            }
          },
          error: (err) => {
            this.emailError = 'An error occurred, please try again later';
          },
        })
      );
    } else {
      if (value == 'Mobile' && this.mobileNumber?.valid) {
        this.OTPSentMsgErr = '';
        this.OTPSentMsg = '';
        const data = {
          mobileNumber: this.userRegistration.get('fdUserMobile')?.value,
        };
        this.subscription.add(
          this.apiService
            .MailOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
            .subscribe({
              next: (response: any) => {
                // Check if OTP was successfully sent
                if (response.statusCode == '1002') {
                // this.OTPSentMsg = response.statusMsg;
                  this.regOTPValidSentMsgErr = '';
                  this.OTPSentMsg='OTP Sent!';
                  this.mobileStartCountdown(180);
                  this.isMobileOtpVerifySuccess = false;
                  this.isMobileResendOTP = true;
                  this.isMobileVerifyButtonDisabled = false;
                  this.userRegistration
                    .get('StrFdMailActivationOptCD')
                    ?.setValue('');
                  
                } else if (response.statusCode == '1008') {
                  this.OTPSentMsg = ''; 
                  this.OTPSentMsgErr = response.statusMsg;
                } else {
                  this.OTPSentMsg = ''; 
                  this.OTPSentMsgErr = 'SMS OTP not sent,Try again.';
                }
              },
              error: (err) => {
                this.OTPSentMsg = ''; 
                this.OTPSentMsgErr = 'Error occurred in SMS OTP generation.';
              },
            })
        );
      }
    }
  }

  sendOTPMail(value: String): void {
    this.MailOTPSentMsgErr = '';
    this.MailOTPSentMsg = '';
    this.isOTPSent = false; // Reset OTP status before sending
    if (value == 'Email' && this.email?.valid) {
      const data = {
        fdUserId: this.userRegistration.get('fdUserId')?.value,
      };
      // Subscription to send OTP
      this.subscription.add(
        this.apiService
          .MailOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == '1002') {
                this.MailOTPSentMsg = 'OTP Sent!';
                this.startCountdown(180);
                this.isMailOtpVerifySuccess = false;
                this.isMailResendOTP = true;
                this.isMailVerifyButtonDisabled = false;
                this.userRegistration.get('mailOTP')?.setValue('');
                this.ErrorMailmsg = '';
              } else if (response.statusCode == '1008') {
                this.MailOTPSentMsgErr = response.statusMsg;
              } else {
                this.MailOTPSentMsgErr = 'MAIL OTP not sent,Try again.';
              }
            },
            error: (err) => {
              this.MailOTPSentMsgErr = 'Error occurred in MAIL OTP generation.';
            },
          })
      );
    } else {
      if (value === 'Email') {
        const email = this.userRegistration.get('fdUserId')?.value;
        if (!email) {
          alert('Kindly provide EmailId for Resending OTP.');
          return;
        }
      }
    }

    if (value == 'Mobile' && this.mobileNumber?.valid) {
      this.OTPSentMsgErr = '';
      this.OTPSentMsg = '';
      const data = {
        mobileNumber: this.userRegistration.get('fdUserMobile')?.value,
      };
      this.subscription.add(
        this.apiService
          .MailOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              // Check if OTP was successfully sent
              if (response.statusCode == '1002') {
                this.mobileStartCountdown(180);
                this.isMobileOtpVerifySuccess = false;
                this.isMobileResendOTP = true;
                this.isMobileVerifyButtonDisabled = false;
                this.OTPSentMsg = 'OTP Sent!';
                this.userRegistration
                  .get('StrFdMailActivationOptCD')
                  ?.setValue('');
              } else if (response.statusCode == '1008') {
                this.OTPSentMsgErr = response.statusMsg;
              } else {
                this.OTPSentMsgErr = 'SMS OTP not sent,Try again.';
                this.isMobileOtpVerifySuccess = false;
              }
            },
            error: (err) => {
              this.OTPSentMsgErr = 'Error occurred in SMS OTP generation.';
            },
          })
      );
    } else {
      if (value === 'Mobile') {
        const fdUserMobile = this.userRegistration.get('fdUserMobile')?.value;
        if (!fdUserMobile) {
          alert('Kindly provide the mobile number for Resending OTP');
          return;
        }
      }
    }
  }

  userRegistrationOtpValid(value: string): void {
    if (value == 'Email' && this.mailOTP?.valid) {
      const data = {
        fdUserId: this.userRegistration.get('fdUserId')?.value,
        otp: this.userRegistration.get('mailOTP')?.value,
        functionType: 'Registration Page',
      };
      if (data.fdUserId == '') {
        alert('Email address cannot be empty for Verifying OTP');
      } else {
        this.mailOTPverifiSucsMsg = '';
        this.mailOTPverifiErrMsg = '';
        this.subscription.add(
          this.apiService
            .userRegistrationOtpValid(
              this.hybridEncryptor.encrypted(JSON.stringify(data))
            )
            .subscribe({
              next: (response: any) => {
                if (response.statusCode == '1002') {
                  this.isMailVerifyButtonDisabled = true;
                  this.isMailOtpVerified = true;
                  clearInterval(this.intervalId);
                  this.isMailOtpVerifySuccess = false;
                  this.isMailResendOTP = false;
                  this.mailOTPverifiErrMsg = '';
                  this.mailOTPverifiSucsMsg = response.statusMsg;
                  this.ErrorMailmsg = '';

                  this.userRegistration.get('fdUserMobile')?.enable();
                  this.userRegistration
                    .get('StrFdMailActivationOptCD')
                    ?.enable();
                  this.userRegistration.get('VerifyOTP')?.disable();
                  this.userRegistration.get('fdUserId')?.disable();
                  this.userRegistration.get('mailOTP')?.disable();
                } else if (response.statusCode === '1008') {
                  this.mailOTPverifiSucsMsg = '';
                  this.mailOTPverifiErrMsg = response.statusMsg;
                  this.isMailResendOTP = true;
                }
              },
              error: (err) => {
                // Handle any error during the OTP sending process
                console.log('Error occured in OTP verification ' + err);
                this.regOTPValidSentMsgErr =
                  'Error occurred in OTP verification try after some time.';
              },
            })
        );
      }
    } else {
      if (value === 'Email') {
        const email = this.userRegistration.get('fdUserId')?.value;
        const emailOtp = this.userRegistration.get('mailOTP')?.value;
        if (!email || !emailOtp) {
          return;
        }
      }
    }
    if (value == 'Mobile' && this.mobileNumber?.valid) {
      this.regOTPValidSentMsg = '';
      this.regOTPValidSentMsgErr = '';
      const data = {
        // fdUserId: this.userRegistration.get('fdUserId')?.value,
        mobileNumber: this.userRegistration.get('fdUserMobile')?.value,
        otp: this.userRegistration.get('StrFdMailActivationOptCD')?.value,
        functionType: 'Registration Page',
      };

      this.subscription.add(
        this.apiService
          .userRegistrationOtpValid(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response.statusCode === '1002') {
                this.isMobileVerifyButtonDisabled = true;
                this.isMobileOtpVerified = true;
                clearInterval(this.intervalId);
                this.isMobileOtpVerifySuccess = false;
                this.isMobileResendOTP = false;
                this.OTPSentMsg = 'OTP Sent!';
                this.regOTPValidSentMsgErr = '';
                this.regOTPValidSentMsg = response.statusMsg;
                this.ErrorMsgErr = ' ';
                this.userRegistration.get('fdUserName')?.enable();
                this.userRegistration.get('fdLastName')?.enable();
                this.userRegistration.get('fdUserPassword')?.enable();
                this.userRegistration.get('confirmPassword')?.enable();
                this.userRegistration.get('j_captcha_response')?.enable();
                this.userRegistration.get('fdUserMobile')?.disable();
                this.userRegistration
                  .get('StrFdMailActivationOptCD')
                  ?.disable();
              } else if (response.statusCode === '1008') {
                this.regOTPValidSentMsg = '';
                this.regOTPValidSentMsgErr = response.statusMsg;
                this.isMobileOtpVerifySuccess = false;
              }
            },
            error: (err) => {
              console.log('Error occured in OTP verification ' + err);
              this.regOTPValidSentMsgErr =
                'Error occurred in OTP verification try after some time.';
            },
          })
      );
    } else {
      if (value == 'Mobile') {
        const mobileNumber = this.userRegistration.get('fdUserMobile')?.value;
        const otp = this.userRegistration.get(
          'StrFdMailActivationOptCD'
        )?.value;
        if (!mobileNumber || !otp) {
          alert(
            'kindly provide Mobile Number and Mobile OTP for verifying OTP'
          );
          return;
        }
      }
    }
  }

  passwordMatchValidator(formGroup: AbstractControl): ValidationErrors | null {
    const password = formGroup.get('fdUserPassword')?.value;
    const confirmPassword = formGroup.get('confirmPassword')?.value;

    if (password !== confirmPassword) {
      formGroup.get('confirmPassword')?.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }
    formGroup.get('confirmPassword')?.setErrors(null); // Clear error if passwords match
    return null;
  }

  login() {
    this.router.navigate(['/login']);
  }

  onSubmit(): void {
    Object.keys(this.userRegistration.controls).forEach((key) => {
      const control = this.userRegistration.get(key);
      if (control?.disabled) {
        control.enable();
      }
    });
    if (this.userRegistration.valid) {
      const data = {
        fdUserId: this.userRegistration.get('fdUserId')?.value,
        mobileNumber: this.userRegistration.get('fdUserMobile')?.value,
        password: this.userRegistration.get('fdUserPassword')?.value,
        confirmPassword: this.userRegistration.get('confirmPassword')?.value,
        captcha: this.userRegistration.get('j_captcha_response')?.value,
        otp: this.userRegistration.get('StrFdMailActivationOptCD')?.value,
        fdUserName:
          this.userRegistration.get('fdUserName')?.value +
          ' ' +
          this.userRegistration.get('fdLastName')?.value,
        fdLastName: this.userRegistration.get('fdLastName')?.value,
      };

      this.subscription.add(
        this.apiService
          .userRegistration(
            this.hybridEncryptor.encrypted(JSON.stringify(data))
          )
          .subscribe({
            next: (response: any) => {
              if (response) {
                if (response.statusCode === '1002') {
                  this.alertMsg = 'Registered Successfully ✅';
                  const modalElement = document.getElementById('submitModal');
                  const modal = new bootstrap.Modal(modalElement);
                  modal.show();
                } else if (response.statusCode === '1008') {
                 alert(response.statusMsg);
                 this.userRegistration.reset();
                }

              }
            },
            error: (error: HttpErrorResponse) => {
              if (error.status === 400) {
                console.log('Bad Request:', error);
                if (error.error.statusCode === '1008') {
                  this.ErrorMsgErr = error.error.statusMsg;
                }
              } else {
                console.error('An unexpected error occurred:', error);
              }
            },
          })
      );
    }
  }

  startCountdown(durationInSeconds: number): void {
    this.countdown = durationInSeconds;
    // this.isMailOtpVerifySuccess = false;
    // this.isMailResendOTP = true;
    this.intervalId = setInterval(() => {
      this.countdown--;

      if (this.countdown === 0 || this.isMailOtpVerified) {
        clearInterval(this.intervalId);
        this.isMailOtpVerifySuccess = true;
        this.isMailVerifyButtonDisabled = true;
        this.isMailResendOTP = false;
      }
    }, 1000); // update every second
  }

  mobileStartCountdown(durationInSeconds: number): void{
    this.countdown = durationInSeconds; // 60 seconds
    // this.isMobileOtpVerifySuccess = false;
    // this.isMobileResendOTP = true;
    this.intervalId = setInterval(() => {
      this.countdown--;

      if (this.countdown === 0 || this.isMobileOtpVerified) {
        clearInterval(this.intervalId);
        this.isMobileOtpVerifySuccess = true;
        this.isMobileVerifyButtonDisabled = true;
        this.isMobileResendOTP = false;
      }
    }, 1000); // update every second
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
