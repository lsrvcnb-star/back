import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, RouterOutlet } from '@angular/router';
import { LoginpageComponent } from '../loginpage/loginpage.component';
import { ApiService } from '../../service/api.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { AppVersion } from '../../config';
import { CustomValidator } from '../../modules/admin/Constom/validator';
import { HybridEncryptor } from '../../Services/HybridEncryptor';
import { CustomValidatorService } from '../../service/custom-validator-service.service';
import { AuthGuard } from '../../service/authGuard';
import { AccessibilityFontSizeComponent } from '../accessibility-font-size/accessibility-font-size.component';


@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule,RouterModule,RouterOutlet, ReactiveFormsModule,LoginpageComponent, AccessibilityFontSizeComponent],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
})
export class ResetPasswordComponent implements OnInit {
  forgotPasswordProcess!: FormGroup;
  subscription: Subscription = new Subscription();
  captchaResult!: any;
  captchaVerified: boolean = false;
  captchaValid:boolean =false;
  CaptchaVerificationMsg!:String;
  CaptchaVerificationMsgError!:String;
  ErrorMsgErr!:string;
  fdUserIdError!: string;
  OTPSentMsgErr!:string;
  appversion :string = AppVersion;
  test : Date = new Date();
  customValidator: CustomValidator = new CustomValidator();
  private hybridEncryptor!:HybridEncryptor;
  @ViewChild('captchaCanvas', { static: true }) captchaCanvas!: ElementRef<HTMLCanvasElement>;
  ngAfterViewInit(): void {
    this.CustomValidatorService.setCanvasRef(this.captchaCanvas);
  }
    constructor(
     private fb: FormBuilder,
     private apiService: ApiService,
     private router: Router,
     private CustomValidatorService :CustomValidatorService,
     private authgurd:AuthGuard,

  ) {}
 
  ngOnInit(): void {
  this.hybridEncryptor = new HybridEncryptor();
  this.forgotPasswordProcess = this.fb.group({
  fdUserId: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]{3,}\.[a-zA-Z]{2,}$/)]],
  fdUserMobile: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
  j_captcha_response: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9]{4}$/)]]
    });
   this.getCaptcha();
  }

  CharacterSpacevalidator(event:any){
    this.customValidator.CharacterSpaceValidator(event);
  }

  numberOnly(event:any){
    this.customValidator.OnlyNumbervalidator(event);
 }


characterSpaceNumberValidator(event:any){
this.customValidator.characterSpaceNumberValidator(event);
}

FloatValue(event:any){
this.customValidator.FloatValue(event);
}


ifsCodevalidator(event:any){
this.customValidator.ifsCodevalidator(event);
}

AddressValidator(event:any){
this.customValidator.AddressValidator(event);
}

  //  getCaptcha(): void {
  //   this.captchaVerified = false;
  //   this.subscription.add(
  //     this.apiService.getCaptcha().subscribe({
  //       next: (response: any) => {
  //         this.captchaResult = response.systemCaptcha;
  //       }
  //     })
  //   );
  // }


  getCaptcha(): void {
    this.captchaVerified = false;
    this.subscription.add(
      this.apiService.getCaptcha().subscribe({
        next: (response: any) => {
          this.captchaResult = response.systemCaptcha;
         if(this.captchaResult){
          // this.drawCaptcha(this.captchaResult);
          this.CustomValidatorService.drawCaptcha(this.captchaResult);
         }
        }
      })
    );
  }

  verifyCaptcha(): void {
    // Get the current value of the captcha input
    const captchaInput = this.forgotPasswordProcess.get('j_captcha_response')?.value;
        // Check if the input matches the system captcha
    if (captchaInput === this.captchaResult) {
      this.captchaValid = true;
      this.CaptchaVerificationMsg = "Captcha is verified";
      this.CaptchaVerificationMsgError = "";
    } else {
      this.captchaValid = false;
      this.CaptchaVerificationMsg = "";
      this.CaptchaVerificationMsgError = "Captcha Mismatch!";
    }
  }
 
  
  get email() { return this.forgotPasswordProcess.get('fdUserId'); }
  get MobileNumber() { return this.forgotPasswordProcess.get('fdUserMobile'); }
  get captcha() { return this.forgotPasswordProcess.get('j_captcha_response'); }
 
  onSubmit(): void {
    if (this.forgotPasswordProcess.valid) {
  const formValues = this.forgotPasswordProcess.value;
  const formattedJson = JSON.stringify({
    fdUserId: formValues.fdUserId,
    fdUserMobile: formValues.fdUserMobile,
    j_captcha_response: formValues.j_captcha_response,
  });
    this.subscription.add(
      this.apiService.forgotPasswordProcess(this.hybridEncryptor.encrypted(formattedJson)).subscribe({
       next: (response: any) => {
        if(response){
         if(response.statusCode==='1002'){
            this.router.navigate(['/resetPasswordProcess']);
            alert(response.statusMsg);
            // this.ErrorMsgErr="";
            this.fdUserIdError="";
            this.OTPSentMsgErr="";
        }
       }
      },
         error: (error: HttpErrorResponse) => {
          if (error.status === 400) {
            console.log('Bad Request:', error);
            if (error.error.statusCode === '1008') {
              // this.ErrorMsgErr = error.error.statusMsg;
              if(error.error.statusMsg === 'Invalid Mobile Number'){
                    this.OTPSentMsgErr = error.error.statusMsg;
             }else if(error.error.statusMsg === 'This EmailId doesnot associated with SIDBI'){ 
                     this.fdUserIdError = error.error.statusMsg;
              }else if(error.error.statusMsg === 'OTP limit exceeded, Kindly try tomorrow/visit nearest branch.'){

                this.OTPSentMsgErr = error.error.statusMsg;
              }
          } else {
            console.error('An unexpected error occurred:', error);
          }
        }
           
      }
    })
     );
      // Handle form submission logic here
    } else {
      console.log('Form is invalid');
      // Handle invalid form logic
    }
  }

  logout(){
  this.authgurd.logout();
  }
   
}
