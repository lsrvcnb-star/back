import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApiService } from '../../service/api.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AppVersion } from '../../config';
import { EncrptionServices } from '../../Services/EncrptionServices';
import { HybridEncryptor } from '../../Services/HybridEncryptor';
import { AuthGuard } from '../../service/authGuard';
import { AccessibilityFontSizeComponent } from '../accessibility-font-size/accessibility-font-size.component';
 
@Component({
  selector: 'app-reset-password-process',
  templateUrl: './reset-password-process.component.html',
  styleUrls: ['./reset-password-process.component.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,RouterModule, AccessibilityFontSizeComponent]
})
export class ResetPasswordProcessComponent implements OnInit {
  changeSetPswrd!: FormGroup;
  ErrorMsgErr!: string;
  OTPSentMsgErr!: string;
  subscription: Subscription = new Subscription();
  test : Date = new Date();
  appversion :string = AppVersion;
  private hybridEncryptor!:HybridEncryptor;
  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private router: Router,
    private authgurd:AuthGuard
  ) {}
 
  ngOnInit(): void {
    
this.hybridEncryptor = new HybridEncryptor();
    // Initialize the form with validators
this.changeSetPswrd = this.fb.group({
fdUserId: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]{3,}\.[a-zA-Z]{2,}$/)]],
      fdUserPassword: ['', [Validators.required, Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/)]],
      fdUserNewPassword: ['', [Validators.required, Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/)]],
      confirmPasword: ['', [Validators.required, Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/)]]
    }, { validator: this.passwordMatchValidator });
     // Clear `ErrorMsgErr` when `fdUserPassword` is touched
    this.changeSetPswrd.get('fdUserPassword')?.statusChanges.subscribe(() => {
      if (this.fdUserPassword?.touched) {
        this.ErrorMsgErr = ''; // Clear ErrorMsgErr when the field is touched
      }
    });
  }
 
  // Custom validator to check if new password matches confirmation
  passwordMatchValidator(formGroup: AbstractControl): ValidationErrors | null {
    const fdUserNewPassword = formGroup.get('fdUserNewPassword')?.value;
    const confirmPaswordControl = formGroup.get('confirmPasword');
    const confirmPasword = confirmPaswordControl?.value;
 
    if (fdUserNewPassword && confirmPasword && fdUserNewPassword !== confirmPasword) {
      confirmPaswordControl?.setErrors({ passwordMismatch: true });
    } else {
      confirmPaswordControl?.setErrors(null);
    }
 
    return null;
  }
 
  // Getters for form controls to use in the template
  get email() { return this.changeSetPswrd.get('fdUserId'); }
  get fdUserPassword() { return this.changeSetPswrd.get('fdUserPassword'); }
  get fdUserNewPassword() { return this.changeSetPswrd.get('fdUserNewPassword'); }
  get confirmPasword() { return this.changeSetPswrd.get('confirmPasword'); }

  clearOTPSentMsgErr(){
   this.OTPSentMsgErr = '';

  }
 
  onSubmit(): void {
    // Clear previous error messages
    this.ErrorMsgErr = '';
    this.OTPSentMsgErr = '';
 
    if (this.changeSetPswrd.valid) {
      const changePasswordval = this.changeSetPswrd.value;
      const changepassjson = JSON.stringify({
        fdUserId: changePasswordval.fdUserId,
        fdUserPassword: changePasswordval.fdUserPassword,
        fdUserNewPassword: changePasswordval.fdUserNewPassword,
        confirmPasword:changePasswordval.confirmPasword
      });
       this.subscription.add(
        this.apiService.changeSetPswrd(this.hybridEncryptor.encrypted(changepassjson)).subscribe({
          next: (response: any) => {
            if (response) {
              if (response.statusCode === '1002') {
                alert(response.statusMsg);
                this.router.navigate(['/login']);
              } else if (response.statusCode === '1008') {
                this.OTPSentMsgErr = response.statusMsg;
              }
            }
          },
          error: (error: HttpErrorResponse) => {
            if (error.status === 400) {
              console.log('Bad Request:', error);
              if (error.error.statusCode === '1008') {
                this.ErrorMsgErr = error.error.statusMsg;
              }
            } else {
              console.error('An unexpected error occurred:', error);
            }
          }
        })
      );
    } else {
      console.log('Form is invalid');
    }
  }
 
 logout(){
  this.authgurd.logout();
}

}
