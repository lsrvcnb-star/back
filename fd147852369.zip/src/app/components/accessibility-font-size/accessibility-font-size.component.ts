import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AccessibilityService, FontSizeOption } from '../../service/accessibility.service';

@Component({
  selector: 'app-accessibility-font-size',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './accessibility-font-size.component.html',
  styleUrl: './accessibility-font-size.component.scss',
})
export class AccessibilityFontSizeComponent implements OnInit, OnDestroy {
  currentFontSize: FontSizeOption = 'normal';
  private readonly fontSizeOrder: FontSizeOption[] = ['small', 'normal', 'large', 'extra-large'];
  private subscription = new Subscription();

  constructor(private accessibilityService: AccessibilityService) {}

  ngOnInit(): void {
    this.subscription.add(
      this.accessibilityService.fontSize$.subscribe((fontSize) => {
        this.currentFontSize = fontSize;
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  decreaseFontSize(): void {
    const currentIndex = this.fontSizeOrder.indexOf(this.currentFontSize);
    if (currentIndex > 0) {
      this.accessibilityService.setFontSize(this.fontSizeOrder[currentIndex - 1]);
    }
  }

  increaseFontSize(): void {
    const currentIndex = this.fontSizeOrder.indexOf(this.currentFontSize);
    if (currentIndex < this.fontSizeOrder.length - 1) {
      this.accessibilityService.setFontSize(this.fontSizeOrder[currentIndex + 1]);
    }
  }

  resetFontSize(): void {
    this.accessibilityService.resetFontSize();
  }

  get canDecrease(): boolean {
    return this.fontSizeOrder.indexOf(this.currentFontSize) > 0;
  }

  get canIncrease(): boolean {
    return this.fontSizeOrder.indexOf(this.currentFontSize) < this.fontSizeOrder.length - 1;
  }
}
