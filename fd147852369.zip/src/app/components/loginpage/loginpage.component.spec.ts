import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginpageComponent } from './loginpage.component';
import { FdRegistrationComponent } from '../fd-registration/fd-registration.component';

describe('LoginpageComponent', () => {
  let component: LoginpageComponent;
  let fixture: ComponentFixture<LoginpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoginpageComponent,FdRegistrationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
