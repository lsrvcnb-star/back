import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import * as forge from 'node-forge';
import { ApiService } from '../../service/api.service';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { of, Subscription } from 'rxjs';
import { CryptoService } from '../../service/Crypto.Service';
import { AuthService } from '../../service/auth.service';
import { AuthGuard } from '../../service/authGuard';
import { CookieService } from 'ngx-cookie-service';
import { AppVersion } from '../../config';
import { CustomValidator } from '../../modules/admin/Constom/validator';
import { HybridEncryptor } from '../../Services/HybridEncryptor';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgZone } from '@angular/core';
import { CustomValidatorService } from '../../service/custom-validator-service.service';
import { ViewChild, ElementRef } from '@angular/core';
import * as bootstrap from 'bootstrap';

import {
  trigger,
  state,
  style,
  animate,
  transition,
  keyframes,
} from '@angular/animations';
import { TimeFormatPipe } from '../../time-format.pipe';
import { SanitizeInputDirective } from '../../sanitize-input.directive';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { AccessibilityFontSizeComponent } from '../accessibility-font-size/accessibility-font-size.component';
import { FdCalculatorComponent } from '../../modules/admin/components/fd-calculator/fd-calculator.component';

interface AlertItem {
  severity: 'success' | 'info' | 'warn' | 'error';
  summary: string;
  detail: string;
}

@Component({
  selector: 'app-loginpage',
  standalone: true,
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.scss'],
  animations: [
    trigger('slideOut', [
      state('in', style({ transform: 'translateX(0)', opacity: 1 })),
      state('out', style({ transform: 'translateX(-100%)', opacity: 0 })),
      transition('in => out', [
        animate(
          '500ms ease-in',
          keyframes([
            style({ transform: 'translateX(0)', opacity: 1, offset: 0 }),
            style({
              transform: 'translateX(-100%)',
              opacity: 0,
              offset: 1,
            }),
          ])
        ),
      ]),
    ]),
    trigger('slideIn', [
      transition(':enter', [
        style({ transform: 'translateX(100%)', opacity: 0 }),
        animate(
          '500ms ease-in',
          keyframes([style({ transform: 'translateX(0)', opacity: 1 })])
        ),
      ]),
    ]),
  ],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
    TimeFormatPipe,
    SanitizeInputDirective,
    AccessibilityFontSizeComponent,
    FdCalculatorComponent,
  ],
})
export class LoginpageComponent implements OnInit {
  loginProcess!: FormGroup;
  encryptedData!: string;
  publicKeypemone!: forge.pki.PublicKey | null;
  emailId!: String;
  userPassWord!: String;
  emailError!: any;
  mobileOTP!: number;
  otpSucessMes!: any;
  otpSucessMesErr!: any;
  passError!: any;
  regOTPValidSentMsgErr!: any;
  regOTPValidSentMsg!: any;
  captchaValid = true;
  CaptchaVerificationMsg: any;
  userCaptcha!: any;
  systemCaptcha!: any;
  CommonError!: String;
  isVerified!: boolean;
  isVerifiedotp: boolean = true;
  showInfoMessage = false;
  showOverlay: boolean = false;
  alerts: AlertItem[] = [];
  showPassword = false;

  showBottom: Boolean = false;
  isOtpVerifyStatus: boolean = false;
  // for timer
  countdown: number = 0;
  intervalId: any;

  isCaptchaSuccess: Boolean = false;

  captchaResult: string = '';
  captchaVerified: boolean = false;
  CaptchaVerificationMsgError: string = '';

  @ViewChild('captchaCanvas', { static: true })
  captchaCanvas!: ElementRef<HTMLCanvasElement>;
  ngAfterViewInit(): void {
    this.CustomValidatorService.setCanvasRef(this.captchaCanvas);
  }

  public hybridEncryptor!: HybridEncryptor;
  subscription: Subscription = new Subscription();
  test: Date = new Date();
  appversion: string = AppVersion;
  customValidator: CustomValidator = new CustomValidator();
  userGuidePdfUrl = '/assets/FDUserGuide.pdf';
  refundPolicyPdfUrl = '/assets/Refund-and-cancellation-policy.pdf';
  userGuidePdfSafeUrl!: SafeResourceUrl;
  private userGuideWindow: Window | null = null;

  refundPolicyPdfSafeUrl!: SafeResourceUrl;
  private refundPolicyWindow: Window | null = null;

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private router: Router,
    private crypto: CryptoService,
    private authService: AuthService,
    private authGurd: AuthGuard,
    private cookieService: CookieService,
    private spinner: NgxSpinnerService,
    private ngZone: NgZone,
    private CustomValidatorService: CustomValidatorService,
    private sanitizer: DomSanitizer
  ) {

    // iframe requires SafeResourceUrl
    this.userGuidePdfSafeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
      this.userGuidePdfUrl
    );

    this.refundPolicyPdfSafeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
      this.refundPolicyPdfUrl
    );

  }

  ngOnInit(): void {
    this.hybridEncryptor = new HybridEncryptor();
    this.loginProcess = new FormGroup({
      fdUserId: new FormControl('', [
        Validators.required,
        Validators.pattern(
          /^[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]{3,}\.[a-zA-Z]{2,}$/
        ),
      ]),

      fdUserPassword: new FormControl('', [
        Validators.required,
        Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/),
      ]),
      StrFdMailActivationOptCD: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\d{1,6}$/),
      ]),
      j_captcha_response: new FormControl('', [
        Validators.required,
        // Validators.pattern(/^[A-Za-z0-9]{4}$/),
      ]),
    });

    this.getCaptcha();
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  CharacterSpacevalidator(event: any) {
    this.customValidator.CharacterSpaceValidator(event);
  }

  numberOnly(event: any) {
    this.customValidator.OnlyNumbervalidator(event);
  }

  characterSpaceNumberValidator(event: any) {
    this.customValidator.characterSpaceNumberValidator(event);
  }

  FloatValue(event: any) {
    this.customValidator.FloatValue(event);
  }

  ifsCodevalidator(event: any) {
    this.customValidator.ifsCodevalidator(event);
  }

  AddressValidator(event: any) {
    this.customValidator.AddressValidator(event);
  }

  get fdUserId() {
    return this.loginProcess.get('fdUserId');
  }

  get fdUserPassword() {
    return this.loginProcess.get('fdUserPassword');
  }

  get StrFdMailActivationOptCD() {
    return this.loginProcess.get('StrFdMailActivationOptCD');
  }

  get j_captcha_response() {
    return this.loginProcess.get('j_captcha_response');
  }

  get form() {
    return this.loginProcess.value;
  }

  getAlertClass(severity: 'success' | 'info' | 'warn' | 'error'): string {
    switch (severity) {
      case 'success':
        return 'alert-success';
      case 'info':
        return 'alert-info';
      case 'warn':
        return 'alert-warning';
      case 'error':
        return 'alert-danger';
      default:
        return 'alert-info';
    }
  }

  dismissAlert(index: number): void {
    this.alerts.splice(index, 1);
    if (this.alerts.length === 0) {
      this.showOverlay = false;
    }
  }

  getCaptcha(): void {
    this.captchaVerified = false;
    this.subscription.add(
      this.apiService.getCaptcha().subscribe({
        next: (response: any) => {
          this.captchaResult = response.systemCaptcha;
          if (this.captchaResult) {
            this.CustomValidatorService.drawCaptcha(this.captchaResult);

            // Reset captcha input field
            this.j_captcha_response?.reset();
            this.j_captcha_response?.markAsPristine();
            this.j_captcha_response?.markAsUntouched();

            // Clear error message
            this.CaptchaVerificationMsgError = '';
          }
        },
      })
    );
  }

  async onSubmit() {
    this.CommonError = '';
    if (this.loginProcess) {
      this.CommonError = '';
      const fdUserId = this.loginProcess.get('fdUserId')?.value;
      const fdUserPassword = this.loginProcess.get('fdUserPassword')?.value;
      const OTP = this.loginProcess.get('StrFdMailActivationOptCD')?.value;
      let data = {
        loginId: fdUserId,
        password: fdUserPassword,
        otp: OTP,
      };
      this.spinner.show();
      this.subscription.add(
        this.apiService
          .login(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              // Check if successResponse is present
              this.CommonError = '';
              if (response?.successResponse) {
                if (
                  response.successResponse.statusCode == '1002' &&
                  response.successResponse.message == 'Successfully Logged in'
                ) {
                  this.CommonError = '';
                  let navigatePath;
                  const token = response?.jwtToken;
                  // localStorage.setItem('jwtToken',token);
                  // this.cookieService.set('jwtToken', token);
                  let jwtToken = { jwtToken: token };
                  this.authService.setresPonse(jwtToken);

                  if (response.cifId == '0') {
                    this.spinner.hide();
                    this.gettingLocalStorageData(response.userName, true);
                  } else if (response.cifId == '123') {
                    this.gettingLocalStorageData(response.userName, false);
                    this.cookieService.set('fdUserDtlsId', response.userId); // Set the cookie first
                    setTimeout(() => {
                      this.spinner.hide();
                      this.router.navigate(['/dashboard/home']);
                    }, 2000); // Delay navigation by 100ms
                  } else {
                    this.gettingLocalStorageData(response.userName, false);
                    this.cookieService.set('fdUserDtlsId', response.userId); // Set the cookie first
                    setTimeout(() => {
                      this.spinner.hide();
                      this.router.navigate(['/dashboard/home']);
                    }, 2000); // Del
                  }
                  if (navigatePath) {
                    this.spinner.hide();
                    this.router
                      .navigate([navigatePath])
                      .then((success) => {
                        console.log('Navigation result:', success);
                      })
                      .catch((err) => {
                        this.spinner.hide();
                        console.error('Router navigation failed:', err);
                      });
                  }
                }
              }

              // Check if errorResponse is present
              if (response?.errorResponse) {
                if (response.errorResponse.statusCode == '1008') {
                  this.passError = '';
                  this.regOTPValidSentMsg = '';
                  // this.showAlert('error', 'Info', "Invalid credentials or incorrect username/password. Please try again");
                  this.spinner.hide();
                  this.showAlert(
                    'error',
                    'Info',
                    response.errorResponse.message
                  );
                }
              }
            },
            error: (error) => {
              this.spinner.hide();
              console.error('An error occurred:', error);
              this.CommonError =
                'The server is currently busy. Please try again shortly';
            },
          })
      );
    } else {
      this.spinner.hide();
      console.log('Invalid Login data or something went wrong kindly check it');
    }
  }

  verifyUser(): void {
    this.emailId = this.form.fdUserId;
    this.userPassWord = this.form.fdUserPassword;
    this.userCaptcha = this.form.j_captcha_response;
    this.systemCaptcha = this.captchaResult;

    this.otpSucessMesErr = '';
    this.spinner.show();

    // First verify captcha
    const isCaptchaValid = this.verifyCaptcha();
    if (!isCaptchaValid) {
      this.spinner.hide();
      return;
    }

    // Proceed only if captcha is valid
    if (!this.captchaVerified && this.CaptchaVerificationMsgError) {
      this.spinner.hide();
      return;
    }

    let data = {
      loginId: this.emailId,
      password: this.userPassWord,
      userCaptcha: this.userCaptcha,
      systemCaptcha: this.systemCaptcha,
    };

    this.subscription.add(
      this.apiService
        .sendOtpForLogin(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response.successResponse?.statusCode == '1002') {
              this.emailError = '';
              this.otpSucessMes = response.successResponse.message;
              this.otpSucessMesErr = '';
              this.isVerified = true;
              this.isVerifiedotp = false;
              this.showBottom = true;
              this.isOtpVerifyStatus = false;
              this.spinner.hide();
              this.showAlert('success', 'sms sent', 'OTP sent successfully!');
              this.startCountdown(180);
            }
            else if (response.errorResponse?.statusCode == '1008' && response.errorResponse?.message == 'Account is Locked Temporarily , Please try After Sometime !') {
              console.log(
                'Error occurred in OTP verification ' +
                response.errorResponse.message
              );
              this.getCaptcha();
              this.spinner.hide();
              this.showAlert(
                'error',
                'Info',
                'Account is Locked Temporarily , Please try After Sometime !'
              );


            } else {

              console.log(
                'Error occurred in OTP verification ' +
                response.errorResponse.message
              );
              this.getCaptcha();
              this.spinner.hide();
              this.showAlert(
                'error',
                'Info',
                'Invalid credentials.'
              );
            }
          },
          error: (err) => {
            this.getCaptcha();
            this.spinner.hide();
            console.log('Error occurred in OTP verification ' + err);
          },
        })
    );
  }

  onCaptchaChange(): void {
    this.CaptchaVerificationMsgError = '';
  }

  verifyCaptcha(): boolean {
    const userInput = this.j_captcha_response?.value?.trim();

    if (!userInput) {
      this.CaptchaVerificationMsgError = 'Enter Captcha';
      return false;
    }

    if (userInput !== this.captchaResult) {
      // this.CaptchaVerificationMsgError = 'Captcha verification failed';
      this.showAlert(
        'error',
        'Info',
        'The CAPTCHA you entered is incorrect. Please try again '
      );
      this.captchaVerified = false;
      this.getCaptcha(); // Reload captcha
      return false;
    }

    this.CaptchaVerificationMsgError = '';
    this.captchaVerified = true;
    return true;
  }

  gettingLocalStorageData(loginId: string, routing: boolean): void {
    // Change 'String' to 'string'
    localStorage.removeItem('UserDetails');
    let data = {
      fdUserId: loginId,
    };

    this.subscription.add(
      this.apiService
        .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response != null) {
              let encrypt = this.hybridEncryptor.encrypted(JSON.stringify(response));
              this.authService.responseData(JSON.stringify(encrypt))
              // this.authService.setresPonse(response);

              let navigatePath;
              if (routing) {
                const aadhaarVirifystsFlag =
                  response.aadhaarVirifystsFlag || '';
                const panverify_Flag = response.panverify_Flag || '';
                //   if (response.empKycFlag === 'Y') {
                //     navigatePath = '/dashboard/home';
                //   } else if (aadhaarVirifystsFlag == 'Y' && panverify_Flag == 'Y') {
                //     navigatePath = '/kycVerification';
                //   } else {
                //     navigatePath = '/kycVerification';
                //   }
                //   this.router.navigate([navigatePath]);
                // }

                if (aadhaarVirifystsFlag == 'Y' && panverify_Flag == 'Y') {
                  navigatePath = '/dashboard/home';
                } else {
                  navigatePath = '/kycVerification';
                }
                this.router.navigate([navigatePath]);
              }



            }
          },
          error: (err) => {
            console.log('Error occurred in gettingLocalStorageData' + err);
          },
        })
    );
  }

  showAlert(
    severity: 'success' | 'info' | 'warn' | 'error',
    summary: string,
    detail: string
  ) {
    const alert: AlertItem = {
      severity: severity,
      summary: summary,
      detail: detail,
    };
    this.alerts = [...this.alerts, alert];
    this.showOverlay = true;
    setTimeout(() => {
      const alertIndex = this.alerts.indexOf(alert);
      if (alertIndex > -1) {
        this.dismissAlert(alertIndex);
      }
    }, 3000);
  }

  logout() {
    this.authGurd.logout();
  }
  startCountdown(durationInSeconds: number): void {
    this.countdown = durationInSeconds;
    this.isOtpVerifyStatus = false;
    this.intervalId = setInterval(() => {
      this.countdown--;

      if (this.countdown === 0) {
        clearInterval(this.intervalId);
        this.isOtpVerifyStatus = true;
      }
    }, 1000);
  }

  login() {
    this.router.navigate(['/login']);
  }

  handleMenuClick(event?: MouseEvent, docType?: string) {
    // Prevent default anchor behavior
    event?.preventDefault();
    // ✅ User Guide open in new tab and reuse it
    if (docType == 'userGuide' && this.userGuidePdfUrl) {
      this.openOrFocusTab(this.userGuidePdfUrl, 'USER_GUIDE_TAB');
      return;
    } else if (docType == 'refundPolicy' && this.refundPolicyPdfUrl) {
      this.refundPolicyTab(this.refundPolicyPdfUrl, 'REFUND_POLICY_TAB');
      return;
    }
  }

  openOrFocusTab(url: string, tabName: string) {
    if (this.userGuideWindow && !this.userGuideWindow.closed) {
      this.userGuideWindow.focus();
      return;
    }
    this.userGuideWindow = window.open(url, tabName);
  }

  refundPolicyTab(url: string, tabName: string) {
    if (this.refundPolicyWindow && !this.refundPolicyWindow.closed) {
      this.refundPolicyWindow.focus();
      return;
    }
    this.refundPolicyWindow = window.open(url, tabName);
  }

openEnquiryTab(): void {
    // 2. Convert the 'enquiry' route name into a clean URL string
    const url = this.router.serializeUrl(
      this.router.createUrlTree(['/enquiry'])
    );
    
    // 3. Instruct the browser to open that URL in a new tab
    window.open(url, 'enquiryTab', 'noopener,noreferrer');
  }

  scrollToCalculator(): void {
  const element = document.getElementById('fdCalculatorSection');

  if (element) {
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  }
}
}

// OtpValid(): void {
//   const data = {
//     fdUserId: this.form.fdUserId,
//     otp: this.form.StrFdMailActivationOptCD,
//     functionType: 'login Page',
//   };

//   this.subscription.add(
//     this.apiService
//       .userRegistrationOtpValid(
//         this.hybridEncryptor.encrypted(JSON.stringify(data))
//       )
//       .subscribe({
//         next: (response: any) => {
//           // Check if OTP was successfully sent

//           if (response.statusCode == '1002') {
//             this.regOTPValidSentMsgErr = '';
//             this.regOTPValidSentMsg = response.statusMsg;
//           }
//           if (response.statusCode == '1008') {
//             this.regOTPValidSentMsg = '';
//             this.regOTPValidSentMsgErr = response.statusMsg;
//           }
//         },
//         error: (err) => {
//           // Handle any error during the OTP sending process
//           console.log('Error occured in OTP verification ' + err);
//           this.regOTPValidSentMsgErr =
//             'Error occurred in OTP verification try after some time.';
//         },
//       })
//   );
// }
