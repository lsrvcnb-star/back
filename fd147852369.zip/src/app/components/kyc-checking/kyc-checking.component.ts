import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from '../../modules/admin/components/navbar/navbar.component';
import { FormBuilder } from '@angular/forms';
import { ApiService } from '../../service/api.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { AuthService } from '../../service/auth.service';
import { CookieService } from 'ngx-cookie-service';
import { ChangeDetectorRef } from '@angular/core';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxSpinnerService } from 'ngx-spinner';
import { CustomValidator } from '../../modules/admin/Constom/validator';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { AuthGuard } from '../../service/authGuard';
import { EncrptionServices } from '../../Services/EncrptionServices';
import { HybridEncryptor } from '../../Services/HybridEncryptor';

@Component({
  selector: 'app-kyc-checking',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    NavbarComponent,
    ReactiveFormsModule,
    NgxSpinnerModule,
  ],
  templateUrl: './kyc-checking.component.html',
  styleUrl: './kyc-checking.component.scss',
})
export class KYCCheckingComponent implements OnInit {
  panForm!: FormGroup;
  aadhaarForm!: FormGroup;
  SupportUser: string = 'Smart Support Group';
  SupportEmail: string = 'fd@sidbi.in';
  peplist = ['Yes', 'No'];
  kycbranchName = [];
  subscription: Subscription = new Subscription();
  CommonError!: string;
  pepVal!: string;
  NewRegId!: string;
  panVerifiySucessMsg!: string;
  panverifyErrMsg!: string;
  // PAN Form data
  isDisabled = true;
  EmailId!: string;
  maxDate: string = '';
  customValidator: CustomValidator = new CustomValidator();
  maxAttempts = 3;
  panAttemptCount = 0;
  panDisabled = false;
  panAttemptMsg!: string;
  AadharAttemptOTPMsg!: string;
  AadharAttemptVerifyMsg!: string;
  aadharOTPAttemptCount = 0;
  aadharOTPDisabled = false;
  aadharVerifyAttemptCount = 0;
  aadharVerifyDisabled = false;
  private encryprionService!: EncrptionServices;
  private hybridEncryptor!: HybridEncryptor;
  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private cookieService: CookieService,
    private router: Router,
    private cdr: ChangeDetectorRef /* other dependencies */,
    private authService: AuthService,
    private spinner: NgxSpinnerService,
    private authgurd: AuthGuard
  ) {}
  ngOnInit(): void {
    const today = new Date();
    this.encryprionService = new EncrptionServices();
    this.hybridEncryptor = new HybridEncryptor();
    this.maxDate = today.toISOString().split('T')[0]; // Set maxDate
    this.panForm = this.fb.group({
      kycbranchName: ['', Validators.required],
      nameAsperOvd: [
        '',
        [Validators.required, Validators.pattern('^[A-Za-z\\s]+$')],
      ],
      dobAsPerPAN: ['', [Validators.required, this.futureDateValidator]],
      panNumber: [
        '',
        [Validators.required, Validators.pattern('^[A-Z]{5}[0-9]{4}[A-Z]{1}')],
      ],
      selectedPEP: ['', Validators.required],
      termsCond: [false, Validators.requiredTrue],
    });
    this.aadhaarForm = this.fb.group({
      aadharNumber: [
        { value: '', disabled: true },
        [Validators.required, Validators.pattern('^[0-9]{12}$')],
      ],
      aadhaarOtp: [
        { value: '', disabled: true },
        [Validators.required, Validators.pattern(/^\d{6}$/)],
      ],
    });
    this.spinner.show();
    setTimeout(() => {
      this.spinner.hide();
    }, 1000);
    this.branchList();
  }
  onDateChange(event: any) {
    const selectedDate = new Date(event.target.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time for accurate comparison
    if (selectedDate > today) {
      this.panForm.controls['dobAsPerPAN'].setValue('');
      alert('Future dates cannot be allowed.');
    }
  }
  onPanInput(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    const upperCaseValue = inputElement.value.toUpperCase();
    this.panForm.controls['panNumber'].setValue(upperCaseValue, {
      emitEvent: false,
    });
  }
  futureDateValidator(control: AbstractControl): ValidationErrors | null {
    if (!control.value) return null;
    const inputDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time to ensure accurate comparison
    return inputDate > today ? { futureDate: true } : null;
  }
  aadharOTPRequestAttempt() {
    if (this.aadharOTPAttemptCount < this.maxAttempts) {
      this.aadharOTPAttemptCount++;
      if (this.aadharOTPAttemptCount >= this.maxAttempts) {
        this.aadharOTPDisabled = true;
        this.AadharAttemptOTPMsg =
          'Max attempts reached for Aadhar Send OTP try after Some times';
        setTimeout(() => {
          this.AadharAttemptOTPMsg = '';
        }, 15000);
      }
    }
  }
  verifyAadhar() {
    if (this.aadharVerifyAttemptCount < this.maxAttempts) {
      this.aadharVerifyAttemptCount++;
      if (this.aadharVerifyAttemptCount >= this.maxAttempts) {
        this.aadharVerifyDisabled = true;
        this.AadharAttemptVerifyMsg =
          'Max attempts reached for Aadhaar verification. try after Some times';
        setTimeout(() => {
          this.AadharAttemptVerifyMsg = '';
        }, 15000);
      }
    }
  }
  verifyPan() {
    if (this.panAttemptCount < this.maxAttempts) {
      this.panAttemptCount++;
      if (this.panAttemptCount >= this.maxAttempts) {
        this.panDisabled = true;
        this.panAttemptMsg =
          'Max attempts reached for pan verification kindly try after some time';
        setTimeout(() => {
          this.panAttemptMsg = '';
        }, 15000);
      }
    }
  }

  CharacterSpaceValidator(event: any) {
    this.customValidator.CharacterSpaceValidator(event);
  }

  numberOnly(event: any) {
    this.customValidator.OnlyNumbervalidator(event);
  }

  characterSpaceNumberValidator(event: any) {
    this.customValidator.characterSpaceNumberValidator(event);
  }

  FloatValue(event: any) {
    this.customValidator.FloatValue(event);
  }

  ifsCodevalidator(event: any) {
    this.customValidator.ifsCodevalidator(event);
  }

  AddressValidator(event: any) {
    this.customValidator.AddressValidator(event);
  }

  branchList(): void {
    this.subscription.add(
      this.apiService.branchList().subscribe({
        next: (response: any) => {
          this.kycbranchName = response;
        },
      })
    );
  }

  submitPanForm() {
    this.verifyPan();
    /* alert("Thank you for submitting your PAN. Your verification is currently being processed. Please wait until it is completed."); */
    if (this.panForm.valid) {
      const data = {
        panNo: this.panForm.get('panNumber')?.value,
        branchName: this.panForm.get('kycbranchName')?.value,
        dob: this.panForm.get('dobAsPerPAN')?.value,
        nameAsperOvd: this.panForm.get('nameAsperOvd')?.value,
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        fdUserId: this.authService.getResponseValueByKey('fdUserId'),
        userName: this.authService.getResponseValueByKey('fdUserName'),
        flag: 0
      };
      const termsCont = this.panForm.get('termsCond')?.value;
      if (termsCont) {
        const termsData = {
          fdUserName: data.nameAsperOvd,
          newFdRegId: data.newRegId,
        };
        this.spinner.show();
        this.subscription.add(
          this.apiService
            .termsOfCondition(
              this.hybridEncryptor.encrypted(JSON.stringify(termsData))
            )
            .subscribe({
              next: (response: any) => {
                if (
                  response.statusCode == '1002' &&
                  response.statusMsg == 'Existing and Valid'
                ) {
                  this.panVerifiySucessMsg = response.statusMsg;
                } else if (response.statusCode == '1008') {
                  this.panverifyErrMsg = response.statusMsg;
                  this.spinner.hide();
                }
              },
            })
        );
      }
      alert('Your PAN is verified successfully');
      setTimeout(() => {
        this.spinner.hide();
        this.aadhaarForm.get('aadharNumber')?.enable();
        this.aadhaarForm.get('aadhaarOtp')?.enable();
      }, 2000);

      this.subscription.add(
        this.apiService
          .verifiyPanData(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (
                response.statusCode == '1002' &&
                response.statusMsg == 'Existing and Valid'
              ) {
                this.spinner.hide();
                this.panVerifiySucessMsg = response.statusMsg;
                this.panverifyErrMsg = '';
                this.aadhaarForm.get('aadharNumber')?.enable();
                this.aadhaarForm.get('aadhaarOtp')?.enable();
                if (this.panAttemptCount < this.maxAttempts) {
                  alert('Your PAN is verified successfully');
                }
              } else if (response.statusCode == '1008') {
                this.spinner.hide();
                this.panVerifiySucessMsg = '';
                this.panverifyErrMsg = response.statusMsg;
                this.aadhaarForm.get('aadharNumber')?.disable();
                this.aadhaarForm.get('aadhaarOtp')?.disable();
                if (this.panAttemptCount < this.maxAttempts) {
                  alert(
                    'PAN verification is incomplete. Please try again later or visit your branch.'
                  );
                  setTimeout(() => {
                    this.authgurd.logout();
                  }, 15000);
                }
              }
            },
            error: () => {
              alert('An error occurred while verifying PAN.');
            },
          })
      );
    }
  }
  PEPCheck() {
    if (this.panForm.get('selectedPEP') != null) {
    
      (this.pepVal = this.panForm.get('selectedPEP')?.value),
        (this.NewRegId =
          this.authService.getResponseValueByKey('fdUserDtlsId') || '');
      if (this.pepVal == 'Yes') {
        this.pepVal = 'Y';
      } else if (this.pepVal == 'No') {
        this.pepVal = 'N';
      }
      let data = {
        politicalExposedPerson: this.pepVal,
        newFdRegId: this.NewRegId,
      };
      this.subscription.add(
        this.apiService
          .PEPCheck(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (response != null) {
                if (response == 'Y') {
                  if (
                    confirm(
                      'Customer needs to visit the nearest BO and system should not allow acceptance of funds or application for FD creation'
                    ) == true
                  ) {
                    // this.router.navigate(['/login']);
                    this.authgurd.logout();
                  } else {
                    this.panForm.patchValue({ selectedPEP: 'No' });
                  }
                }
              }
            },
            error: (error) => {
              this.CommonError = '';
              console.error('An error occurred:', error);
              // this.CommonError = "The server is currently busy. Please try again shortly";
            },
          })
      );
    }
  }

  aadharOTPRequest() {
    this.aadharOTPRequestAttempt();
    var aadharnum = this.aadhaarForm.get('aadharNumber')?.value;
    if (aadharnum != null && aadharnum != '') {
      const data = {
        aadharno: this.aadhaarForm.get('aadharNumber')?.value,
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
      };
      this.spinner.show();
      setTimeout(() => {
        alert('Aadhaar OTP sent to register mobile number.');
        this.spinner.hide();
        // this.aadharOTPDisabled = true;
      }, 1000);
      this.subscription.add(
        this.apiService
          .eKYCRequestOTP(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == '1002') {
                alert('Aadhaar OTP sent to register mobile number.');
                this.spinner.hide();
              } else if (response.statusCode == '1008') {
                alert(
                  'The Aadhaar OTP generation is not working due to a non-valid Aadhaar number or a technical issue. Try again later.'
                );
                this.spinner.hide();
              }
            },
            error: (error) => {
              console.error('An error occurred in aadharOTPRequest:', error);
              this.CommonError =
                'The server is currently busy. Please try again shortly';
            },
          })
      );
    } else {
      alert('A 12 digit AADHAAR UID/NO is required');
    }
  }
  submitAadhaarForm() {
    //  this.verifyAadhar();
    if (this.aadhaarForm.valid) {
      // Handle Aadhaar form submission
      const data = {
        aadharno: this.aadhaarForm.get('aadharNumber')?.value,
        otp: this.aadhaarForm.get('aadhaarOtp')?.value,
        newRegId: this.authService.getResponseValueByKey('fdUserDtlsId'),
        mailId: this.authService.getResponseValueByKey('fdUserEmail'),
      };
      this.spinner.show();
      setTimeout(() => {
        this.spinner.hide();
        alert('Dear customer, thank you for completing KYC.');
        this.router.navigate(['/wudCifCreationForm']);
      });
      this.subscription.add(
        this.apiService
          .eKYCRequestdata(this.hybridEncryptor.encrypted(JSON.stringify(data)))
          .subscribe({
            next: (response: any) => {
              if (response.statusCode == '1002') {
                alert('Dear customer, thank you for completing KYC.');
                this.spinner.hide();
                this.gettingLocalStorageData(data.mailId || '');
              } else if (
                response.statusCode == '1008' &&
                response.statusMsg == 'Resident authentication failed'
              ) {
                alert('Enter Aadhaar valid OTP Number');
                this.spinner.hide();
              } else if (
                response.statusCode == '1008' &&
                response.statusMsg == 'Invalid transactionId.'
              ) {
                alert(
                  'Aadhaar Verification failed due to some technical issue try again after some time'
                );
                this.spinner.hide();
              } else if (response.statusCode == '1008') {
                alert(
                  'Aadhaar Verification failed due to some technical issue try again after some time'
                );
                this.spinner.hide();
              }
            },
            error: (error) => {
              this.spinner.hide();
              console.error('An error occurred in submitAadhaarForm:', error);
              this.CommonError =
                'The server is currently busy. Please try again shortly';
            },
          })
      );
    }
  }

  gettingLocalStorageData(loginId: string): void {
    // Change 'String' to 'string'
    localStorage.removeItem('UserDetails');
    let data = {
      fdUserId: loginId,
    };

    this.subscription.add(
      this.apiService
        .getUserDetails(this.hybridEncryptor.encrypted(JSON.stringify(data)))
        .subscribe({
          next: (response: any) => {
            if (response != null) {
              // const encrptRespon =this.crypto.encryptData(response);
              this.authService.setresPonse(response);
            }
          },
          error: (err) => {
            console.log('Error occurred in gettingLocalStorageData' + err);
          },
        })
    );
  }
}
