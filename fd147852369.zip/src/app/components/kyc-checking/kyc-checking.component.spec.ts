import { ComponentFixture, TestBed } from '@angular/core/testing';
import { KYCCheckingComponent } from './kyc-checking.component';




describe('KYCCheckingComponent', () => {
  let component: KYCCheckingComponent;
  let fixture: ComponentFixture<KYCCheckingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KYCCheckingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KYCCheckingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
