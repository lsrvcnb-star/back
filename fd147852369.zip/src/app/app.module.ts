import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { BrowserModule } from "@angular/platform-browser";
import {CookieModule } from  'ngx-cookie';
import { CookieService } from "ngx-cookie-service";
import { FdRegistrationComponent } from "./components/fd-registration/fd-registration.component";
import { SanitizeInputDirective } from "./sanitize-input.directive";


@NgModule({
    declarations: [
        
           
    ],
    imports: [
        BrowserModule,
        CookieModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        CommonModule,
        HttpClientModule,
        SanitizeInputDirective
    ],
    exports: [
        FormsModule,
        CommonModule,
        BrowserModule,
        ReactiveFormsModule,
    ],
  
    providers: [
        CookieService
            
    ],
    bootstrap: [AppComponent,


    ]
})
export class AppComponent {

}