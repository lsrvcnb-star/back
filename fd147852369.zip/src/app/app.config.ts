import {
  ApplicationConfig,
  CSP_NONCE,
  provideZoneChangeDetection,
} from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { routes } from './app-routing.module';
import { DecryptionInterceptorFn } from './interceptors/decryption.interceptors';
import { HybridEncryptor } from './Services/HybridEncryptor';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideToastr } from 'ngx-toastr';

/**
 * Reads the per-request CSP nonce that the server stamped into
 * <meta name="CSP-NONCE" content="..."> in index.html.
 *
 * Angular uses this token to add nonce="..." to every <style> element it
 * injects at runtime (component view encapsulation, animations, dynamically
 * registered library styles such as ngx-spinner, ngx-toastr).
 *
 * If the meta tag is missing or still contains the build-time placeholder
 * (__CSP_NONCE__), we return an empty string. Angular will then skip the
 * nonce attribute, which is the correct behaviour for local dev where CSP
 * is typically permissive.
 */
function readCspNonceFromMeta(): string {
  if (typeof document === 'undefined') return '';
  const meta = document.querySelector('meta[name="CSP-NONCE"]') as HTMLMetaElement | null;
  const value = meta?.content?.trim() ?? '';
  if (!value || value === '__NONCE__') return '';
  return value;
}

export const appConfig: ApplicationConfig = {
  providers: [
    // Make the per-request nonce available to Angular's style injector.
    // MUST be provided BEFORE any module that injects styles at runtime.
    { provide: CSP_NONCE, useFactory: readCspNonceFromMeta },

    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideToastr({
      positionClass: 'toast-top-center',
      closeButton: true,
      progressBar: true,
      preventDuplicates: true,
    }),

    provideHttpClient(
      withInterceptors([
        DecryptionInterceptorFn,
      ])
    ),
    provideAnimationsAsync(),
    HybridEncryptor,
  ],
};
