import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { LoginpageComponent } from './components/loginpage/loginpage.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { KYCCheckingComponent } from './components/kyc-checking/kyc-checking.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ResetPasswordProcessComponent } from './components/reset-password-process/reset-password-process.component';
import { AuthGuard } from './service/authGuard';
import { FdRegistrationComponent } from './components/fd-registration/fd-registration.component';
import { FdKycVerificationComponent } from './components/fd-kyc-verification/fd-kyc-verification.component';
import { EnquiryComponent } from './modules/admin/components/enquiry/enquiry.component';

export const routes: Routes = [
  {
    path: 'registration',
    component: FdRegistrationComponent,
    data: {
      seo: {
        title: 'Register for SIDBI Fixed Deposit | Online FD Account Opening',
        description: 'Register online for SIDBI Fixed Deposit services and start a secure FD application with digital KYC, nominee details and account verification.',
        keywords: 'SIDBI FD registration, online FD account opening, SIDBI fixed deposit registration, digital KYC FD, secure fixed deposit application',
        canonicalPath: '/registration',
      },
    },
  },
  {
    path: 'enquiry',
    component: EnquiryComponent,

    data: {
      seo: {
        title: 'SIDBI FD Customer Inquiries | Grievance and Support',
        description: 'Submit customer inquiries, grievances and support requests for SIDBI Fixed Deposit services.',
        keywords: 'SIDBI FD inquiry, grievance, customer support, FD help',
        canonicalPath: '/dashboard/enquiry',
        robots: 'noindex, nofollow',
      },
    },
  },
  {
    path: 'forgotPassword',
    component: ResetPasswordComponent,
    data: {
      seo: {
        title: 'Reset SIDBI FD Password | Fixed Deposit Login Help',
        description: 'Reset your SIDBI Fixed Deposit portal password securely and regain access to your FD application, KYC and account services.',
        keywords: 'SIDBI FD password reset, fixed deposit login help, SIDBI FD forgot password, FD portal password recovery',
        canonicalPath: '/forgotPassword',
        robots: 'noindex, follow',
      },
    },
  },
  {
    path: 'kycVerification',
    component: FdKycVerificationComponent,
    canActivate: [AuthGuard],
    data: {
      seo: {
        title: 'SIDBI FD KYC Verification | Complete Fixed Deposit KYC Online',
        description: 'Complete SIDBI Fixed Deposit KYC verification online with secure identity, PAN, Aadhaar and depositor information checks.',
        keywords: 'SIDBI FD KYC, fixed deposit KYC verification, online FD KYC, SIDBI Aadhaar verification, SIDBI PAN verification',
        canonicalPath: '/kycVerification',
      },
    },
  },
  {
    path: 'oldone',
    component: KYCCheckingComponent,
    data: {
      seo: {
        title: 'SIDBI FD KYC Status | Fixed Deposit Verification',
        description: 'Check SIDBI Fixed Deposit KYC verification status and continue secure online FD onboarding.',
        keywords: 'SIDBI FD KYC status, fixed deposit verification status, SIDBI KYC checking',
        canonicalPath: '/oldone',
        robots: 'noindex, follow',
      },
    },
  },
  {
    path: 'resetPasswordProcess',
    component: ResetPasswordProcessComponent,
    data: {
      seo: {
        title: 'SIDBI FD Password Update | Secure Account Recovery',
        description: 'Update your SIDBI Fixed Deposit portal password through a secure account recovery process.',
        keywords: 'SIDBI FD password update, fixed deposit account recovery, SIDBI secure password change',
        canonicalPath: '/resetPasswordProcess',
        robots: 'noindex, follow',
      },
    },
  },
  { path: 'login/registerPage', redirectTo: '/registration', pathMatch: 'full' },
  { path: 'login/enquiry', redirectTo: '/enquiry', pathMatch: 'full' },
  { path: 'login/resetPassword', redirectTo: '/forgotPassword', pathMatch: 'full' },
  { path: 'dashboard/resetPassword', redirectTo: '/forgotPassword', pathMatch: 'full' },
  { path: 'kycVerification/resetPassword', redirectTo: '/forgotPassword', pathMatch: 'full' },
  { path: 'kycVerification/login', redirectTo: '/login', pathMatch: 'full' },
  { path: 'kycVerification/userInfo', redirectTo: '/dashboard/userInfo', pathMatch: 'full', },
  { path: 'dashboard/login', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    component: LoginpageComponent,
    data: {
      seo: {
        title: 'SIDBI Fixed Deposit Login | Secure Online FD Portal',
        description: 'Log in to the SIDBI Fixed Deposit portal to create, track and manage fixed deposit applications, KYC verification and pre-closure services online.',
        keywords: 'SIDBI FD login, SIDBI Fixed Deposit portal, online fixed deposit login, SIDBI FD application, FD management portal',
        canonicalPath: '/login',
      },
    },
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./modules/admin/admin.module').then((m) => m.AdminModule),
    canActivate: [AuthGuard],
    data: {
      seo: {
        title: 'SIDBI FD Dashboard | Manage Fixed Deposit Applications',
        description: 'Manage SIDBI Fixed Deposit applications, account details, nominees, forms and pre-closure requests from the secure dashboard.',
        keywords: 'SIDBI FD dashboard, manage fixed deposit, FD application tracking, SIDBI account details, SIDBI pre-closure',
        canonicalPath: '/dashboard',
        robots: 'noindex, nofollow',
      },
    },
  },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }


