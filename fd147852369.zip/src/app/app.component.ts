import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxSpinnerService } from 'ngx-spinner';
import { SeoService } from './service/seo.service';
import { FdCacheService } from './service/fd-cache.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgxSpinnerModule,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit {
  title = 'FDAPP';
  constructor(
    private spinner: NgxSpinnerService,
    private seoService: SeoService,
    private fdCacheService: FdCacheService
  ) {}

  ngOnInit(): void {
    this.fdCacheService.clearCache();
    // this.spinner.show();
    //   setTimeout(() => {
    //   this.spinner.hide();
    // }, 1000);

    this.seoService.init();
  }
}
