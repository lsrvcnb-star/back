import { CookieService } from 'ngx-cookie-service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CryptoService } from './Crypto.Service';
import { Injectable } from '@angular/core';
import { HybridEncryptor } from '../Services/HybridEncryptor';





const FDUSERDTLSID = 'fdUserDtlsId';
const FDUSERID = 'fdUserId';
const FDUSEREMAIL = 'fdUserEmail';
const FDUSERMOBILE ='fdUserMobile';
const USERLASTLOGINTIM ='userLastLogintim';
const JWTTOKEN ='jwtToken';
const RESPONSEDATA ='responseData'
@Injectable({
    providedIn: 'root'
  })

export class AuthService {
    requestHeaders = new HttpHeaders({ 'No-Auth': 'True' })
    constructor(private http: HttpClient, 
      private cookieservice: CookieService, 
      private crypto: CryptoService,
      private hybridEncryptor:HybridEncryptor) { }
    private loading: boolean = false;
    setLoading(loading: boolean) {
      this.loading = loading;
    }
    getLoading(): boolean {
      return this.loading;
    }
     public getfdUserId = () => {
      return this.crypto.decryptData(this.getResponseValueByKey(FDUSERID));
    }
    
    public getfdUserDtlsId = () => {
        return this.crypto.decryptData(this.getResponseValueByKey(FDUSERDTLSID));
      }

      public getfdUserEmail= () => {
        return this.crypto.decryptData(this.getResponseValueByKey(FDUSEREMAIL));
      }

      public getfdUserMobile= () => {
        return this.crypto.decryptData(this.getResponseValueByKey(FDUSERMOBILE));
      }

      public getuserLastLogintim= () => {
        return this.crypto.decryptData(this.getResponseValueByKey(USERLASTLOGINTIM));
      }
   
public responseData = (RESPONSEDATAVal: string) => {
  const expiryTime = new Date().getTime() + 60 * 60 * 1000; // 1 hour from now
  const dataWithExpiry = {
    value: RESPONSEDATAVal,
    expiry: expiryTime
  };
  localStorage.setItem('RESPONSEDATA', JSON.stringify(dataWithExpiry));
  return true;
}


// public getResponseData = (): string | null => {
//   const item = localStorage.getItem('RESPONSEDATA');
//   if (!item) return null;
//   const parsed = JSON.parse(item);
//   if (new Date().getTime() > parsed.expiry) {
//     localStorage.removeItem('RESPONSEDATA');
//     return null;
//   }
//   return this.getsessionEncryptionValue(parsed.value);
    
// }


public getResponseValueByKey = (key: string): string | null => {
  const item = localStorage.getItem('RESPONSEDATA');
  if (!item) return null;
  try {
    const parsed = JSON.parse(item);
    if (new Date().getTime() > parsed.expiry) {
      localStorage.removeItem('RESPONSEDATA');
      return null;
    }

    const decrypted = this.getsessionEncryptionValue(parsed.value);

    // If decrypted is already an object, skip parsing
    const dataObj = typeof decrypted === 'string' ? JSON.parse(decrypted) : decrypted;

    return dataObj[key] || null;
  } catch (error) {
    console.error('Error extracting key from response:', error);
    return null;
  }
};

  public setresPonse = (responseData: Record<string, any>) => {
      // Delete previous keys if necessary
      for (const key of Object.keys(responseData)) {
        this.cookieservice.delete(key);
      }
       
  for (const [key, value] of Object.entries(responseData)) {
    this.cookieservice.set(key, value ? value.toString() : '', {
      secure: true,          // Ensures the cookie is sent over HTTPS
      sameSite: 'Strict',    // Prevents cross-site requests
      expires: new Date(new Date().getTime() + 60 * 60 * 1000),  // Set expiration for 10 minutes
    });
  }
}
     
    public getFdUserName():string{
     const fdUserName =this.getResponseValueByKey("fdUserName");
     return fdUserName || '';
      }

        public getLastloginTime():string{
        const lastloginTime =this.getResponseValueByKey("userLastLogintim") || '';
        return lastloginTime;
        }
     
 
        
    public getToken = () => {
      return this.cookieservice.get(JWTTOKEN);
    }
  
  
    public clear = () => {
      this.cookieservice.deleteAll();
    }

aadharpanSeedingStatus(panSeeding: string | null, panAadharFlag: string | null): boolean {
    const seed = (panSeeding || '').trim().toUpperCase();
    const flag = (panAadharFlag || '').trim().toUpperCase();
    if (seed === 'Y' && flag === 'Y') {
        return true;
    }
     if (
        (seed === 'N' && flag === 'Y') ||
        (seed === 'Y' && flag === 'N') ||
        (seed === 'N' && flag === 'N') ||
        (seed === '' && flag === '') ||
        (seed === 'NULL' && flag === 'NULL')
    ) {
        return false;
    }
    // Default fallback
    return false;
}



  
    public setviewFDentryId = (viewFDentryId: string) => {
          this.cookieservice.delete("viewFDentryId");
          return this.cookieservice.set(
            "viewFDentryId",
            viewFDentryId,
            new Date(new Date().getTime() + 60 * 60 * 1000), // Expires in 35 minutes
            '/', // Path (optional)
            undefined, // Domain (optional)
            true, // Secure
            'Strict' // SameSite
          );}

    public setEditFDentryId = (EditFDentryId:string) =>{
      this.cookieservice.delete("editFDentryId");
      return this.cookieservice.set(
        "editFDentryId",
        EditFDentryId,
      new Date(new Date().getTime() + 60 * 60 * 1000), // Expires in 35 minutes
      '/', // Path (optional)
      undefined, // Domain (optional)
      true, // Secure
      'Strict' // SameSite
      );
    }


  public getsessionEncryptionValue(responData: any) {
  if (responData) {
    let parsed: any;
     // Try parsing JSON
    try {
      parsed = JSON.parse(responData);
    } catch (err) {
      console.error('Invalid JSON in responseData:', err);
      parsed = {};
    }
     // Case-insensitive key retrieval
    const encryptedKey =
      parsed.encryptedKey ?? parsed.encryptedkey ?? '';
    const encryptedData =
      parsed.encryptedData ?? parsed.encrypteddata ?? '';
    const iv = parsed.iv ?? '';
    // Decrypt only if we have both values
    if (encryptedKey && encryptedData) {
      try {
        const decrypted = this.hybridEncryptor.newdecryptHybridData(
          { encryptedKey, encryptedData, iv },
          this.hybridEncryptor
        );
       return decrypted; // ✅ Return decrypted result
      } catch (decryptErr) {
        console.error('Error while decrypting:', decryptErr);
        return null;
      }
    } else {
      console.warn('Missing encryptedKey or encryptedData, skipping decryption');
      return null;
    }
  } else {
    console.warn('No responseData found in authService');
    return null;
  }
}

}