import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, switchMap, map, tap } from 'rxjs';
import { ApiService } from './api.service';
import { HybridEncryptor } from '../Services/HybridEncryptor';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class FdCacheService {
  private userDetailsCache$ = new BehaviorSubject<any>(null);
  private userFullDetailsCache$ = new BehaviorSubject<any>(null);
  private userDetailsLoading = false;
  private userFullDetailsLoading = false;
  private schemeListCache: any = null;
  private interestRateCache = new Map<string, { rate: string; ts: number }>();
  private readonly INTEREST_RATE_TTL = 3 * 60 * 1000;

  constructor(
    private apiService: ApiService,
    private authService: AuthService
  ) {}

  getUserDetails(fdUserId: any): Observable<any> {
    if (this.userDetailsCache$.value) {
      return this.userDetailsCache$.asObservable();
    }

    if (this.userDetailsLoading) {
      return this.userDetailsCache$.asObservable();
    }

    this.userDetailsLoading = true;
    const hybridEncryptor = new HybridEncryptor();
    const userDetailsObj = { fdUserId };

    return this.apiService.getUserDetails(
      hybridEncryptor.encrypted(JSON.stringify(userDetailsObj))
    ).pipe(
      tap((response: any) => {
        this.userDetailsCache$.next(response);
        this.userDetailsLoading = false;
      })
    );
  }

  getUserFullDetails(fdUserId: any): Observable<any> {
    if (this.userFullDetailsCache$.value) {
      return this.userFullDetailsCache$.asObservable();
    }

    if (this.userFullDetailsLoading) {
      return this.userFullDetailsCache$.asObservable();
    }

    this.userFullDetailsLoading = true;
    const hybridEncryptor = new HybridEncryptor();
    const data = {
      fdUserId,
      newFdRegId: this.authService.getResponseValueByKey('newFdRegId'),
      entryId: this.authService.getResponseValueByKey('entryId'),
      cif: this.authService.getResponseValueByKey('cif'),
      kycBranchName: this.authService.getResponseValueByKey('kycBranchName'),
    };

    return this.apiService.userFdDetailsView(
      hybridEncryptor.encrypted(JSON.stringify(data))
    ).pipe(
      tap((response: any) => {
        this.userFullDetailsCache$.next(response);
        this.userFullDetailsLoading = false;
      })
    );
  }

  getSchemeList(): Observable<any> {
    if (this.schemeListCache) {
      return of(this.schemeListCache);
    }
    return this.apiService.getDropdownList().pipe(
      tap((response: any) => {
        this.schemeListCache = response;
      })
    );
  }

  getInterestRate(data: any): Observable<any> {
    const cacheKey = JSON.stringify(data);
    const hit = this.interestRateCache.get(cacheKey);
    if (hit && Date.now() - hit.ts < this.INTEREST_RATE_TTL) {
      return of(hit.rate);
    }
    const hybridEncryptor = new HybridEncryptor();
    return this.apiService.intCalc(
      hybridEncryptor.encrypted(JSON.stringify(data))
    ).pipe(
      map((response: any) => {
        const rate = String(response ?? '')
          .replace(/['"]+/g, '')
          .trim();
        this.interestRateCache.set(cacheKey, { rate, ts: Date.now() });
        return rate;
      })
    );
  }

  clearCache(): void {
    this.userDetailsCache$.next(null);
    this.userFullDetailsCache$.next(null);
    this.userDetailsLoading = false;
    this.userFullDetailsLoading = false;
    this.schemeListCache = null;
    this.interestRateCache.clear();
  }
}
