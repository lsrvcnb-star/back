import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { HybridEncryptor } from '../Services/HybridEncryptor';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { FdCacheService } from './fd-cache.service';
 
@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  private inactivityTimeout: any;
  baseUrl: string = environment.url;
  public hybridEncryptor!:HybridEncryptor;
   constructor(private router: Router, private cookieService: CookieService,private https: HttpClient,
     private authService:AuthService,
     private fdCacheService: FdCacheService
   ) {}
   // Main guard logic
  canActivate(): Observable<boolean> {
    // Check if the cookie exists (indicating the user is logged in)
  const fdUserDtlsId = this.authService.getResponseValueByKey('fdUserDtlsId');
  const wudUserid = this.authService.getResponseValueByKey('fdUserId');
  const jwtToken = this.cookieService.get('jwtToken');

    if (!fdUserDtlsId || !wudUserid || !jwtToken) {
    this.router.navigate(['/login']);
    this.logout();
      return of(false);
  }
    // Reset inactivity timer on each route activation
    // this.resetInactivityTimer();
    //  // Attach event listeners to reset the timer on user activity
    // this.addInactivityListeners();
    //  return true;

   const data = {
    wudUserid: wudUserid,
    jwtToken: jwtToken
  };

   return this.veirfyTokenUserId(data).pipe(
    map((response: boolean) => {
      if (response === true) {
        this.resetInactivityTimer();
        this.addInactivityListeners();
        return true;
      } else {
         this.router.navigate(['/login']);
         this.logout();
        return false;
      }
    }),
    catchError((error) => {
      this.logout();
      this.router.navigate(['/login']);
      return of(false);
    })
  )

  }

  
 
  // Function to reset the inactivity timer
  private resetInactivityTimer() {
    clearTimeout(this.inactivityTimeout);
    // Set a new timer for 3 minutes of inactivity
    this.inactivityTimeout = setTimeout(() => {
      this.logout();
    }, 30 * 60 * 1000); // 3 minutes in milliseconds
  }
 
  // Function to add event listeners for user activity
  private addInactivityListeners() {
    // Remove any existing listeners first to avoid duplicates
    document.removeEventListener('mousemove', this.resetInactivityTimer.bind(this));
    document.removeEventListener('keydown', this.resetInactivityTimer.bind(this));
    document.removeEventListener('click', this.resetInactivityTimer.bind(this));
 
    // Add event listeners
    document.addEventListener('mousemove', this.resetInactivityTimer.bind(this));
    document.addEventListener('keydown', this.resetInactivityTimer.bind(this));
    document.addEventListener('click', this.resetInactivityTimer.bind(this));
  }
   // Logout function to clear cookies and redirect
  public logout() {
    for (const [key, value] of Object.entries(this.cookieService.getAll())) {
      this.cookieService.delete(key);
      this.clearAllcookieData();
    }
    localStorage.clear();
    sessionStorage.clear();
    this.fdCacheService.clearCache();
    this.router.navigate(['/login']);
  }
  public clearAllcookieData(){
    for (const [key, value] of Object.entries(this.cookieService.getAll())) {
      this.cookieService.delete(key);
    }
  }

  veirfyTokenUserId(data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      // 'client-id': 'SIDBI',
      'Content-Type': 'application/json'
    });
     return this.https.post(`${this.baseUrl}/users/veirfyTokenUserId`,  data, { headers });
  }



}
