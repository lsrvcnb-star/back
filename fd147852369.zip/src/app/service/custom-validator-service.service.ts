import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
 import { Subscription } from 'rxjs'
 import { ApiService } from './api.service';
 import { CookieService } from 'ngx-cookie-service';
import { environment } from '../../environments/environment';
 
@Injectable({
  providedIn: 'root',
})
export class CustomValidatorService {

 private canvasRef!: ElementRef<HTMLCanvasElement>;
 subscription: Subscription = new Subscription();
 Jwtresult: any;
 setCanvasRef(canvasRef: ElementRef<HTMLCanvasElement>): void {
  this.canvasRef = canvasRef;
}

  constructor(
    private apiService: ApiService,  
    private cookieService: CookieService
    
  ) {}
   /**
   * Validates that the input contains only letters and spaces.
   * @returns ValidatorFn
   */
  onlyLettersAllowed(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      const regex = /^[a-zA-Z\s]+$/;
      const valid = regex.test(control.value);
      return valid ? null : { notLetter: true };
    };
  }



  generateCaptcha(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let captcha = '';
    for (let i = 0; i < 6; i++) {
      captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return captcha;
  }
 
  drawCaptcha(text: string): void {
    if (!this.canvasRef) return;
 
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
 
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.font = '20px Arial';
    ctx.fillStyle = '#000';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 10, canvas.height / 2);
  }

  invalidSelectValidator():ValidatorFn {
    return (control: AbstractControl):ValidationErrors | null => {
      if (control.value === 'select' || !control.value) {
        return { invalidSelection: true };
      }
      return null;
    };
  }

  invalidSelectValidatorONE(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      return control.value === 'select' ? { invalidSelection: true } : null;
    };
  }
 
  /**
   * Validates that the input follows a valid PAN number format (e.g., ABCDE1234F).
   * @returns ValidatorFn
   */
  panNumberValidate(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      const regex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
      const valid = regex.test(control.value);
      return valid ? null : { panValid: true };
    };
  }
 
  /**
   * Validates that the date is not greater than today's date.
   * @returns ValidatorFn
   */
  dateValidate(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      const inputDate = new Date(control.value);
      const today = new Date();
 
      // Remove time portion for comparison
      inputDate.setHours(0, 0, 0, 0);
      today.setHours(0, 0, 0, 0);
 
      return inputDate > today ? { isGreater: true } : null;
    };
  }
 
  /**
   * Validates that the input contains only numeric characters.
   * @returns ValidatorFn
   */
  onlyNumbersAllowed(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      const regex = /^[0-9]+$/;
      const valid = regex.test(control.value);
      return valid ? null : { notNumber: true };
    };
  }


public generateUniqueReqId(): String {
  // Generate a random number between 1000000000 and 9999999999 (10 digits)
  const uniqueId = Math.floor(Math.random() * 9000000000) + 1000000000;
  return uniqueId.toString();
}

public getRemiterAccountNo(): string {
  const SIDBIDCVRemitAcNo =environment.remitterAccNo;
  return SIDBIDCVRemitAcNo;
}


private readonly HONORIFICS = [
    'MR', 'MRS', 'MS', 'MISS', 'DR',
    'SHRI', 'SRI', 'SMT', 'MADAM', 'SIR',
    // Tamil honorifics (optional):
    'THIRU', 'THIRUMATHI', 'திரு', 'திருமதி'
  ];

  private normalizeName(name: string): string {
    return (name || '')
      .replace(/[.,]/g, ' ')   // dots/commas out
      .replace(/\s+/g, ' ')    // collapse spaces
      .trim()
      .toUpperCase();
  }

   private tokenize(name: string): string[] {
    const tokens = this.normalizeName(name).split(' ').filter(Boolean);
    // NOTE: use this.HONORIFICS because it's a class property
    return tokens.filter(t => !this.HONORIFICS.includes(t));
  }


   private sortTokens(tokens: string[]): string[] {
    return [...tokens].sort();
  }

 private isInitial(t: string): boolean {
    return t.length === 1;
  }

 private levenshteinRatio(a: string, b: string): number {
    const m = a.length, n = b.length;
    if (m === 0 && n === 0) return 1;
    const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,     // deletion
          dp[i][j - 1] + 1,     // insertion
          dp[i - 1][j - 1] + cost // substitution
        );
      }
    }
    const dist = dp[m][n];
    const maxLen = Math.max(m, n);
    return maxLen === 0 ? 1 : 1 - dist / maxLen; // 0..1
  }

    private jaroWinkler(s1: string, s2: string): number {
    if (!s1 && !s2) return 1;
    if (!s1 || !s2) return 0;

    const m1 = s1.length, m2 = s2.length;
    const matchDistance = Math.floor(Math.max(m1, m2) / 2) - 1;

    const s1Matches = new Array(m1).fill(false);
    const s2Matches = new Array(m2).fill(false);

    let matches = 0, transpositions = 0;

    for (let i = 0; i < m1; i++) {
      const start = Math.max(0, i - matchDistance);
      const end = Math.min(i + matchDistance + 1, m2);
      for (let j = start; j < end; j++) {
        if (s2Matches[j]) continue;
        if (s1[i] !== s2[j]) continue;
        s1Matches[i] = true;
        s2Matches[j] = true;
        matches++;
        break;
      }
    }

    if (matches === 0) return 0;

    let k = 0;
    for (let i = 0; i < m1; i++) {
      if (!s1Matches[i]) continue;
      while (!s2Matches[k]) k++;
      if (s1[i] !== s2[k]) transpositions++;
      k++;
    }
    const jaro = (matches / m1 + matches / m2 + (matches - transpositions / 2) / matches) / 3;

    // Winkler bonus
    let prefix = 0;
    for (let i = 0; i < Math.min(4, Math.min(m1, m2)); i++) {
      if (s1[i] === s2[i]) prefix++;
      else break;
    }
    const scaling = 0.1;
    return jaro + prefix * scaling * (1 - jaro);
  }


    private tokenMatchScore(aTokens: string[], bTokens: string[]): number {
    if (aTokens.length === 0 || bTokens.length === 0) return 0;
    const usedB = new Array(bTokens.length).fill(false);
    let matched = 0;

    for (const a of aTokens) {
      // exact token
      let found = false;
      for (let j = 0; j < bTokens.length && !found; j++) {
        if (!usedB[j] && bTokens[j] === a) {
          usedB[j] = true;
          matched++;
          found = true;
        }
      }
      if (found) continue;

      // initials vs full
      for (let j = 0; j < bTokens.length && !found; j++) {
        if (usedB[j]) continue;
        if (this.isInitial(a) && bTokens[j][0] === a) {
          usedB[j] = true;
          matched++;
          found = true;
        } else if (this.isInitial(bTokens[j]) && a[0] === bTokens[j]) {
          usedB[j] = true;
          matched++;
          found = true;
        }
      }
    }

    return matched / Math.max(aTokens.length, bTokens.length); // 0..1
  }

   public nameMatchPercentage(payeeName: string, candidateName: string): number {
    const aTokens = this.sortTokens(this.tokenize(payeeName));
    const bTokens = this.sortTokens(this.tokenize(candidateName));

    const aJoin = aTokens.join(' ');
    const bJoin = bTokens.join(' ');

    const jw = this.jaroWinkler(aJoin, bJoin);
    const lv = this.levenshteinRatio(aJoin, bJoin);
    const tk = this.tokenMatchScore(aTokens, bTokens);

    let score = 0.55 * Math.max(jw, lv) + 0.45 * tk;
    if (tk === 1) score = Math.min(1, score + 0.05);

    return Math.round(score * 100);
  }



}