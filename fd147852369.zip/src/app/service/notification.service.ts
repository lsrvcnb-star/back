import { Injectable } from '@angular/core';
import { ToastrService, IndividualConfig } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  constructor(private toastr: ToastrService) {}

  private getConfig(position?: string): Partial<IndividualConfig> {
    return {
      
positionClass: position || 'toast-top-center',
    timeOut: 0,
    closeButton: true,
    progressBar: true,
    tapToDismiss: true,
    newestOnTop: true,
    easeTime: 300,
    extendedTimeOut: 0,
    enableHtml: true,
    toastClass: 'ngx-toastr custom-toast-width', 

    };
  }

  success(message: string, title?: string, position?: string) {
    this.toastr.success(message, title || 'Success', this.getConfig(position));
  }

  error(message: string, title?: string, position?: string) {
    this.toastr.error(message, title || 'Error', this.getConfig(position));
  }

  warning(message: string, title?: string, position?: string) {
    this.toastr.warning(message, title || 'Warning', this.getConfig(position));
  }

  info(message: string, title?: string, position?: string) {
    this.toastr.info(message, title || 'Info', this.getConfig(position));
  }
}
