import { DOCUMENT } from '@angular/common';
import { Injectable, inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Meta, Title } from '@angular/platform-browser';
import { filter } from 'rxjs';

type SeoConfig = {
  title: string;
  description: string;
  keywords: string;
  canonicalPath?: string;
  image?: string;
  robots?: string;
  type?: string;
};

@Injectable({
  providedIn: 'root',
})
export class SeoService {
  private readonly title = inject(Title);
  private readonly meta = inject(Meta);
  private readonly router = inject(Router);
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly document = inject(DOCUMENT);

  private readonly siteName = 'SIDBI Fixed Deposit';
  private readonly siteUrl = 'https://fdappl.sidbi.in';
  private readonly defaultImage = '/assets/sidbiBanner.png';
  private readonly defaultSeo: SeoConfig = {
    title: 'SIDBI Fixed Deposit | Secure Online FD Investment',
    description:
      'Open and manage SIDBI Fixed Deposits online with secure registration, KYC verification, FD application tracking, nominee details and pre-closure services.',
    keywords:
      'SIDBI Fixed Deposit, SIDBI FD, online fixed deposit, fixed deposit India, SIDBI FD application, SIDBI FD registration, FD KYC verification, secure FD investment, Small Industries Development Bank of India',
    canonicalPath: '/',
    robots: 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1',
    type: 'website',
  };

  init(): void {
    this.applySeo(this.defaultSeo);

    this.router.events
      .pipe(filter((event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe((event) => {
        this.applyRouteSeo(event.urlAfterRedirects);
      });

    setTimeout(() => this.applyRouteSeo(this.router.url));
  }

  private getDeepestRouteSeo(): Partial<SeoConfig> {
    let route = this.activatedRoute.firstChild;

    while (route?.firstChild) {
      route = route.firstChild;
    }

    return (route?.snapshot.data?.['seo'] ?? {}) as Partial<SeoConfig>;
  }

  private applyRouteSeo(url: string): void {
    const routeSeo = this.getDeepestRouteSeo();
    this.applySeo({
      ...this.defaultSeo,
      ...routeSeo,
      canonicalPath: routeSeo.canonicalPath ?? this.normalizePath(url),
    });
  }

  private applySeo(config: SeoConfig): void {
    const canonicalUrl = this.absoluteUrl(config.canonicalPath ?? '/');
    const imageUrl = this.absoluteUrl(config.image ?? this.defaultImage);
    const robots = config.robots ?? this.defaultSeo.robots;

    this.title.setTitle(config.title);

    this.updateTag('name', 'description', config.description);
    this.updateTag('name', 'keywords', config.keywords);
    this.updateTag('name', 'robots', robots);
    this.updateTag('name', 'author', 'Small Industries Development Bank of India');
    this.updateTag('name', 'application-name', this.siteName);
    this.updateTag('name', 'theme-color', '#0b5cab');
    this.updateTag('name', 'referrer', 'strict-origin-when-cross-origin');

    this.updateTag('property', 'og:site_name', this.siteName);
    this.updateTag('property', 'og:title', config.title);
    this.updateTag('property', 'og:description', config.description);
    this.updateTag('property', 'og:type', config.type ?? 'website');
    this.updateTag('property', 'og:url', canonicalUrl);
    this.updateTag('property', 'og:image', imageUrl);
    this.updateTag('property', 'og:image:alt', 'SIDBI Fixed Deposit online application portal');
    this.updateTag('property', 'og:locale', 'en_IN');

    this.updateTag('name', 'twitter:card', 'summary_large_image');
    this.updateTag('name', 'twitter:title', config.title);
    this.updateTag('name', 'twitter:description', config.description);
    this.updateTag('name', 'twitter:image', imageUrl);
    this.updateTag('name', 'twitter:image:alt', 'SIDBI Fixed Deposit online application portal');

    this.setCanonical(canonicalUrl);
    this.setStructuredData(config, canonicalUrl, imageUrl);
  }

  private updateTag(attributeName: 'name' | 'property', attributeValue: string, content: string | undefined): void {
    if (!content) return;

    this.meta.updateTag(
      {
        [attributeName]: attributeValue,
        content,
      },
      `${attributeName}="${attributeValue}"`
    );
  }

  private setCanonical(url: string): void {
    let link = this.document.querySelector<HTMLLinkElement>('link[rel="canonical"]');

    if (!link) {
      link = this.document.createElement('link');
      link.setAttribute('rel', 'canonical');
      this.document.head.appendChild(link);
    }

    link.setAttribute('href', url);
  }

  private setStructuredData(config: SeoConfig, canonicalUrl: string, imageUrl: string): void {
    const existing = this.document.querySelector<HTMLScriptElement>('script[data-seo-json-ld="true"]');
    existing?.remove();

    const script = this.document.createElement('script');
    script.type = 'application/ld+json';
    script.setAttribute('data-seo-json-ld', 'true');

    const nonce = this.getCspNonce();
    if (nonce) {
      script.setAttribute('nonce', nonce);
    }

    script.text = JSON.stringify({
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'Organization',
          '@id': `${this.siteUrl}/#organization`,
          name: 'Small Industries Development Bank of India',
          alternateName: 'SIDBI',
          url: this.siteUrl,
          logo: this.absoluteUrl('/assets/images/sidbiIconOne.png'),
        },
        {
          '@type': 'WebSite',
          '@id': `${this.siteUrl}/#website`,
          name: this.siteName,
          url: this.siteUrl,
          inLanguage: 'en-IN',
          publisher: {
            '@id': `${this.siteUrl}/#organization`,
          },
        },
        {
          '@type': 'WebApplication',
          '@id': `${canonicalUrl}#webapplication`,
          name: config.title,
          url: canonicalUrl,
          description: config.description,
          image: imageUrl,
          applicationCategory: 'FinanceApplication',
          operatingSystem: 'Web',
          inLanguage: 'en-IN',
          publisher: {
            '@id': `${this.siteUrl}/#organization`,
          },
        },
      ],
    });

    this.document.head.appendChild(script);
  }

  private absoluteUrl(pathOrUrl: string): string {
    if (/^https?:\/\//i.test(pathOrUrl)) {
      return pathOrUrl;
    }

    const path = pathOrUrl.startsWith('/') ? pathOrUrl : `/${pathOrUrl}`;
    return `${this.siteUrl}${path}`;
  }

  private normalizePath(url: string): string {
    const path = url.split('?')[0]?.split('#')[0] ?? '/';
    return path || '/';
  }

  private getCspNonce(): string {
    const meta = this.document.querySelector<HTMLMetaElement>('meta[name="CSP-NONCE"]');
    const value = meta?.content?.trim() ?? '';
    return value && value !== '__NONCE__' ? value : '';
  }
}
