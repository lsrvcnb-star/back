import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, from, Observable, of } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { FormGroup } from '@angular/forms';
import { HybridEncryptor } from '../Services/HybridEncryptor';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  baseUrl: string = environment.url;
  private iframeurl = new BehaviorSubject<String>('');
  private preClosure = this.iframeurl.asObservable();
  private viewFdApp = new BehaviorSubject<Object>({});
  private viewFdAppUrl = this.viewFdApp.asObservable();
  public triggerDownloadMenu = new BehaviorSubject<boolean>(false);

  private formSubject = new BehaviorSubject<FormGroup | null>(null);
  form$ = this.formSubject.asObservable();
  public hybridEncryptor!: HybridEncryptor;

  // Initial value for the BehaviorSubject
  private preCloseMessageSource = new BehaviorSubject<string>('');

  // Observable stream that components can subscribe to
  currentPreCloseMessage$ = this.preCloseMessageSource.asObservable();

  constructor(
    private https: HttpClient,
    private cookieService: CookieService
  ) { }

  // Method to update the BehaviorSubject's value
  changeMessage(message: string) {
    this.preCloseMessageSource.next(message);

  }

  private unfilledFieldsCount = new BehaviorSubject<number>(0);
  unfilledFieldsCount$ = this.unfilledFieldsCount.asObservable();

  updateUnfilledFieldsCount(count: number) {
    this.unfilledFieldsCount.next(count);
  }

  setForm(form: any) {
    this.formSubject.next(form);
  }

  login(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/users/login`, obj, {
      headers: headers,
    });
  }

  setPreClosure(input: String) {
    this.iframeurl.next(input);
  }
  getPreClosure(): Observable<String> {
    return this.preClosure;
  }
  setFdViewApplication(obj: Object) {
    this.viewFdApp.next(obj);
  }
  getFdViewApplication(): Observable<Object> {
    return this.viewFdAppUrl;
  }

  userRegistration(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/userRegistration`, obj, {
      headers: headers,
    });
  }

  forgotPasswordProcess(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/users/forgotPasswordProcess`, obj, {
      headers: headers,
    });
  }



  getCaptcha(): Observable<any> {
    return this.https.get(`${this.baseUrl}/users/getLoginParams`);
  }

  checkCustomerExist(obj: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(`${this.baseUrl}/checkCustomerExist`, obj, {
      headers: headers,
    });
  }

  MailOTP(regOTP: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/user/sentOtpToMailForReg`, regOTP, {
      headers: headers,
    });
  }

  sendOtpForLogin(requestData: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/users/sendOtpForLogin`,
      requestData,
      { headers: headers }
    );
  }

  branchList(): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(`${this.baseUrl}/getBranchNameList`, {
      headers: headers,
    });
  }

  userRegistrationOtpValid(regOTPdetails: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/verifyOtpForRegMail`,
      regOTPdetails,
      { headers: headers }
    );
  }
  changeSetPswrd(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/users/changeSetPswrd`, obj, {
      headers: headers,
    });
  }

  getUserDetails(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/users/getRegUserDetails`, obj, {
      headers,
    });
  }

  submitForm121(payload: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

    return this.https.post(`${this.baseUrl}/form121/submit`, payload, { headers });
  }

  getForm121BySubmissionId(submissionId: number | string): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
    });

    return this.https.get(
      `${this.baseUrl}/form121/get/${encodeURIComponent(submissionId)}`,
      { headers }
    );
  }

  getForm121ByUser(fduserRegId: string): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
    });

    return this.https.get(
      `${this.baseUrl}/form121/getCurrentFY/${encodeURIComponent(fduserRegId)}`,
      { headers }
    );
  }

  getForm121SubmissionsAll(fduserRegId: string): Observable<any> {
  const token = this.cookieService.get('jwtToken');
  const headers = new HttpHeaders({
    Authorization: `Bearer ${token}`,
    'client-id': 'SIDBI',
  });

  return this.https.get(
    `${this.baseUrl}/form121/getSubmissionsAll?fduserRegId=${encodeURIComponent(fduserRegId)}&status=SUBMITTED`,
    { headers }
  );
}

  getForm121ByUserAndStatus(
    fduserRegId: string,
    status: 'SAVED' | 'SUBMITTED'
  ): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
    });

    return this.https.get(
      `${this.baseUrl}/form121/get/${encodeURIComponent(fduserRegId)}/${encodeURIComponent(status)}`,
      { headers }
    );
  }


  verifiyPanData(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/report/pan/validation-enquiry`,
      obj,
      { headers: headers }
    );
  }



  verifiyGurdianPanData(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/report/pan/validationForHolder`,
      obj,
      { headers: headers }
    );
  }

  termsOfCondition(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/consentVerifyAgree`, obj, {
      headers: headers,
    });
  }

  eKYCRequestOTP(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/eKYCRequestOTP`, obj, {
      headers: headers,
    });
  }

  eKYCRequestdata(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/eKYCRequestdata`, obj, {
      headers: headers,
    });
  }

  PEPCheck(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/politicalExposed`, obj, {
      headers: headers,
    });
  }

  getDropdownListF(): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(`${this.baseUrl}/getDropdownListF`, {
      headers: headers,
    });
  }

  getDropdownList(): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(`${this.baseUrl}/getDropdownList`, {
      headers: headers,
    });
  }

  intCalc(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/users/calcInt`, obj, {
      headers: headers,
    });
  }

  userFdDetailsView(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/userDetailsView`, obj, {
      headers: headers,
    });
  }

  getFdEntryListDetails(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/getFdEntryListDetails`, obj, {
      headers: headers,
    });
  }

  getOfflineFdDetails(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/report/getOfflineFdDetails`, obj, {
      headers: headers,
    });
  }




  getPreclosureRequestDetails(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/report/getPreclosureRequestDetails`, obj, {
      headers: headers,
    });
  }


  getFdPrecloserDashboard(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/getFdPrecloserDashboard`, obj, {
      headers: headers,
    });
  }

  getPreClosureDetails(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/viewPreClosureUserFDDetails`, obj, {
      headers: headers,
    });
  }

  getpanEKYCMode(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

    return this.https.post(`${this.baseUrl}/users/panEKYCMode`, obj, {
      headers: headers,
    });
  }

  userDetailsView(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/userDetailsView`, obj, {
      headers: headers,
    });
  }
  getPreCloseReason(): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(`${this.baseUrl}/getPreCloseReason`, {
      headers: headers,
    });
  }

  savePreClosure(savePreClosureForm: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/savePreClosure`,
      savePreClosureForm,
      { headers: headers }
    );
  }
  getBankDetails(data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/users/bankDetails`, data, {
      headers: headers,
    });
  }

  getbankDetails(data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/report/getFdBankDetails`, data, {
      headers: headers,
    });
  }

  downloadFdrePort(fdidNum: string): Observable<any> {
    return this.https.get(
      `${this.baseUrl}/report/fdReportGenerate?fdidNum=${fdidNum}`,
      {
        responseType: 'blob' as 'json',
        observe: 'response',
      }
    );
  }

  getcity(data: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(
      `${this.baseUrl}/users/getDistricDetailsUsingStateCode`,
      data,
      { headers: headers }
    );
  }

  getstateCode(data: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(`${this.baseUrl}/users/getStateCode`, data, {
      headers: headers,
    });
  }

  getcityCode(data: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.https.post(`${this.baseUrl}/users/getDistCode`, data, {
      headers: headers,
    });
  }

  viewFdCreationDetails(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/users/changeSetPswrd`, obj, {
      headers: headers,
    });
  }

  getNomineeDetails(reqData: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/report/getUserNomineeDetails`,
      reqData,
      { headers: headers }
    );
  }

  getFdNomineeDetails(reqData: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/report/getFdNomineeDetails`,
      reqData,
      { headers: headers }
    );
  }

  getFDJointHoldersDetails(reqData: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/viewFdEntry`,
      reqData,
      { headers: headers }
    );
  }

  saveFdCreationDetails(createFDForm: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/savecreateFdEntry`, createFDForm, {
      headers: headers,
    });
  }

  pennydropCheckAccountNumber(Data: any): Observable<any> {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('client-id', 'SIDBI_INTERNAL');
    return this.https.post(
      `https://partneruat.sidbi.in/user/auth/generate-token`,
      Data,
      { headers: headers }
    );
  }

  /*   PaymentGatwaylinkGeneration(Data: any): Observable<any> {
      const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
      const headers = new HttpHeaders({
        'Authorization': `Bearer ${token}`,
        'client-id': 'SIDBI',
        'Content-Type': 'application/json'
      });
      return this.https.post(`${this.baseUrl}/report/generatePaymentLink`, Data, { headers: headers });
    }
   */
  getPennyDropStatus(Data: any, authorization: any): Observable<any> {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('client-id', 'SIDBI_INTERNAL')
      .set('Authorization', 'Bearer ' + authorization);
    return this.https.post(
      `https://partneruat.sidbi.in/online/sidbi/getPennyDropStatus`,
      Data,
      { headers: headers }
    );
  }

  pennyDropRequestDataapi(reqData: any) {

    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/report/sidbi/pennyDropRequest`,
      reqData,
      { headers: headers }
    );
  }

  getPennyDropStatusDataapi(reqData: any) {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/report/sidbi/getPennyDropStatus`,
      reqData,
      { headers: headers }
    );
  }

  getfdrNumber(): Observable<any> {
    const headers = new HttpHeaders();
    return this.https.post(`${this.baseUrl}/getfdrNumber`, {
      headers: headers,
    });
  }
  pennyDropRequest(Data: any, authorization: any): Observable<any> {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('client-id', 'SIDBI_INTERNAL')
      .set('Authorization', 'Bearer ' + authorization);
    return this.https.post(
      `https://partneruat.sidbi.in/online/sidbi/pennyDropRequest`,
      Data,
      { headers: headers }
    );
  }
  saveFdNewUserCifDetails(Data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/saveFdNewUserCifDetails`, Data, {
      headers: headers,
    });
  }

  saveNomineeDetails(reqData: any) {

    const token = this.cookieService.get('jwtToken');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/report/saveUserNomineeDetails`, reqData, { headers: headers });

  }

  doVkycProcessService(Data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/vkyc/enrollment`, Data, {
      headers: headers,
    });
  }
  saveFdBankDetails(Data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/report/saveFdBankDetails`, Data, {
      headers: headers,
    });
  }

  PaymentGatwaylinkGeneration(Data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/report/generatePaymentLink`, Data, {
      headers: headers,
    });
  }

  getStatusForPayment(reqId: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

    return this.https.post(
      `${this.baseUrl}/report/getStatusForPayment`,
      reqId,
      { headers: headers }
    );
  }

  verifyEmpCode(empCode: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

    return this.https.post(
      `${this.baseUrl}/report/getEmployeeDetails`,
      empCode,
      { headers: headers }
    );
  }

  downloadForm(formType: any, reqBody: any): Observable<Blob> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

    return this.https.post(`${this.baseUrl}/report/form${formType}`, reqBody, {
      headers: headers,
      responseType: 'blob' // 👈 This is the key fix
    }) as Observable<Blob>; // 👈 Type assertion to satisfy TypeScript
  }

  saveCustAddressDetails(Data: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/report/saveCustAddressDetails`, Data, {
      headers: headers,
    });
  }

  resetVKycFlagDirect(obj: any): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/resetVKycFlagDirect`, obj, {
      headers: headers,
    });
  }

  getHoldGuardDetails(obj: any) {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/kyc/getHoldGuardDetails`, obj, {
      headers: headers,
    });
  }

  getCombinedGuardianKycDetails(newRegId: string, jointGuardMapFlag: string): Observable<any> {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

    const url = `${this.baseUrl}/kyc/getCombinedGuardianKycDetailsByParam?newRegId=${newRegId}&jointGuardMapFlag=${jointGuardMapFlag}`;


    return this.https.post(url, {}, { headers: headers });
  }

  saveHoldGuardDetails(obj: any) {
    const token = this.cookieService.get('jwtToken'); // Get JWT from cookie
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(`${this.baseUrl}/kyc/saveHoldGuardDetails`, obj, {
      headers: headers,
    });
  }


  verifyAgentCode(agentCode: string): Observable<any> {
    return this.https.get(
      `${this.baseUrl}/getAgent/${agentCode}`

    );
  }

  ifscValidate(ifsc: string): Observable<any> {
    return this.https.get(`${this.baseUrl}/bank/ifsc//validate/${ifsc}`)
    // return this.https.get(`https://ifsc.razorpay.com/${ifsc}`)

  }


  ckycVerification(payload: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });
    return this.https.post(
      `${this.baseUrl}/ckyc/generate/otp`,
      payload, {
      headers: headers,
    }

    );
    /* return of({
    "statusCode": "1000",
    "statusMag": "OTP initiated successfully"
  }) */
  }

  getckycdata(payload: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

    return this.https.post(
      `${this.baseUrl}/ckyc/get/data`,
      payload, {
      headers: headers,
    }
    );

    /*    return of({
      "statusCode": "1002",
      "statusMag": "OTP initiated successfully"
    }) */
  }

  inquiryOptions() {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });



     return  this.https.get(`${this.baseUrl}/customer/inquiry/options`, { headers })

  }

  submitEnquiry(payload: any): Observable<any> {
    const token = this.cookieService.get('jwtToken');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'client-id': 'SIDBI',
      'Content-Type': 'application/json',
    });

/*     return of({
      statusCode: '1000',
      message: 'Your enquiry has been submitted successfully. Our team will get back to you shortly.',
      data: payload,
    }); */

    // TODO: Replace with actual API call
     return this.https.post(`${this.baseUrl}/customer/inquiry/create`, payload, { headers });
  }

}
