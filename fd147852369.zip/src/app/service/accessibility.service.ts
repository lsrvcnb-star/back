import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type FontSizeOption = 'small' | 'normal' | 'large' | 'extra-large';

@Injectable({
  providedIn: 'root',
})
export class AccessibilityService {
  private readonly storageKey = 'fdapp-font-size';
  private readonly defaultFontSize: FontSizeOption = 'normal';
  private readonly fontSizeSubject = new BehaviorSubject<FontSizeOption>(this.getSavedFontSize());

  readonly fontSize$ = this.fontSizeSubject.asObservable();

  constructor(@Inject(DOCUMENT) private document: Document) {
    this.applyFontSize(this.fontSizeSubject.value);
  }

  get currentFontSize(): FontSizeOption {
    return this.fontSizeSubject.value;
  }

  setFontSize(fontSize: FontSizeOption): void {
    this.saveFontSize(fontSize);
    this.applyFontSize(fontSize);
    this.fontSizeSubject.next(fontSize);
  }

  resetFontSize(): void {
    this.setFontSize(this.defaultFontSize);
  }

  private applyFontSize(fontSize: FontSizeOption): void {
    this.document.documentElement.setAttribute('data-app-font-size', fontSize);
  }

  private getSavedFontSize(): FontSizeOption {
    try {
      const savedFontSize = localStorage.getItem(this.storageKey) as FontSizeOption | null;
      if (savedFontSize && this.isFontSizeOption(savedFontSize)) {
        return savedFontSize;
      }
    } catch {
      return this.defaultFontSize;
    }

    return this.defaultFontSize;
  }

  private saveFontSize(fontSize: FontSizeOption): void {
    try {
      localStorage.setItem(this.storageKey, fontSize);
    } catch {
      // The visual change should still work if browser storage is unavailable.
    }
  }

  private isFontSizeOption(fontSize: string): fontSize is FontSizeOption {
    return ['small', 'normal', 'large', 'extra-large'].includes(fontSize);
  }
}
