import NegotiationDashboard from "negotiation-runtime/NegotiationDashboard";
import "assets/css/negotiation.css";

export default function NegotiationTool() {
  return (
    <div className="ifv-negotiation-tool">
      <NegotiationDashboard />
    </div>
  );
}
