package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class DocumentExportAuditRequest {

    @NotBlank
    @Pattern(regexp = "(?i)PDF|EXCEL|WORD|PRINT")
    private String documentType;

    @NotBlank
    @Pattern(regexp = "(?i)pdf|xlsx|docx|print")
    private String exportFormat;

    @Size(max = 500)
    private String documentName;

    @Size(max = 200)
    private String companyName;

    @Size(max = 100)
    private String dealId;

    @Size(max = 500)
    private String dealName;

    private BigDecimal warPercentage;
    private BigDecimal xirrPercentage;
    private BigDecimal irrPercentage;
    private BigDecimal mserCofPercentage;
    private BigDecimal marginBps;
    private BigDecimal minMarginBps;
    private BigDecimal discretionBps;

    @Size(max = 500)
    private String approvalStatus;

    @Size(max = 100)
    private String clientIp;

    @Size(max = 4000)
    private String browserInfo;

    @Size(max = 100)
    private String createdBy;

    @Size(max = 4000)
    private String remarks;
}


