package com.sidbi.ifv.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A single benchmark/policy rate together with the source it was scraped from.
 * Mirrors the {@code RatePoint} shape returned by the negotiation market endpoint.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class RatePointDto {

	private Double value;

	private String source;
}
