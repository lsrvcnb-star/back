package com.sidbi.ifv.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

import com.sidbi.ifv.dto.DocumentExportAuditRequest;
import com.sidbi.ifv.dto.DocumentExportAuditResponse;
import com.sidbi.ifv.entity.DocumentExportAudit;
import com.sidbi.ifv.service.impl.DocumentExportAuditService;
import com.sidbi.ifv.util.CommonUtil;

@RestController
@RequestMapping("/api/document-export-audit")
@Validated
public class DocumentExportAuditController {

        private final DocumentExportAuditService auditService;

        public DocumentExportAuditController(DocumentExportAuditService auditService) {
                this.auditService = auditService;
        }

        @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
        public ResponseEntity<AuditCreatedResponse> createAudit(
                        @Valid @RequestPart("metadata") DocumentExportAuditRequest metadata,
                        @RequestPart(value = "document", required = false) MultipartFile document,
                        @AuthenticationPrincipal UserDetails userDetails,
                        HttpServletRequest httpRequest) {

                Long auditId = auditService.recordExport(
                                metadata,
                                document,
                                userDetails,
                                CommonUtil.getClientIpAddress(httpRequest));

                return ResponseEntity.status(HttpStatus.CREATED)
                                .body(new AuditCreatedResponse(auditId));
        }

        @GetMapping("/user")
        public ResponseEntity<List<DocumentExportAuditResponse>> getAuditsByUser(
                        @AuthenticationPrincipal UserDetails userDetails) {

                List<DocumentExportAuditResponse> audits = auditService.getAuditsByUser(userDetails.getUsername());

                return ResponseEntity.ok(audits);
        }

        @GetMapping("/{auditId}/document")
        public ResponseEntity<byte[]> downloadDocument(
                        @PathVariable Long auditId) {

                DocumentExportAudit audit = auditService.getAuditById(auditId);

                if (audit.getDocumentContent() == null) {
                        return ResponseEntity.notFound().build();
                }

                return ResponseEntity.ok()
                                .header("Content-Disposition",
                                                "attachment; filename=\"" + audit.getDocumentName() + "\"")
                                .body(audit.getDocumentContent());
        }

        @GetMapping("/test")
        public ResponseEntity<String> test() {
                return ResponseEntity.ok("Document Export Audit Controller Working");
        }

        public record AuditCreatedResponse(Long auditId) {
        }
}