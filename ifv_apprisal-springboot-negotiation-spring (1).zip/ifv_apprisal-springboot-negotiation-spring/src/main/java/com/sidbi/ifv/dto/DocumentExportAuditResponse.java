package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class DocumentExportAuditResponse {

    private Long auditId;
    private String userId;
    private String userName;
    private String userEmail;

    private String documentType;
    private String exportFormat;
    private String documentName;

    private String companyName;
    private String dealId;
    private String dealName;

    private BigDecimal warPercentage;
    private BigDecimal xirrPercentage;
    private BigDecimal irrPercentage;
    private BigDecimal mserCofPercentage;
    private BigDecimal marginBps;
    private BigDecimal minMarginBps;
    private BigDecimal discretionBps;

    private String approvalStatus;
    private String clientIp;
    private String browserInfo;
    private String remarks;

    private LocalDateTime exportedAt;
}