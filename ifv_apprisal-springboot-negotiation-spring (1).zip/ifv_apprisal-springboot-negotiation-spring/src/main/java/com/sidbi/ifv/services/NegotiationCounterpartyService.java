package com.sidbi.ifv.services;

import com.sidbi.ifv.dto.CounterpartyPayloadDto;

/**
 * Serves live counterparty data (bulk deposit rate cards and recent bond
 * issuances) for the IFV negotiation pricing dashboard.
 */
public interface NegotiationCounterpartyService {

	/**
	 * @param bankId       counterparty id, e.g. {@code sbi}, {@code hdfc}
	 * @param nseSymbol    optional NSE symbol used to look up bond announcements
	 * @param rating       optional issuer rating used to filter bond issuances
	 * @param forceRefresh skip the in-memory cache and re-scrape
	 * @return the payload, with {@code cached} set to indicate cache provenance
	 */
	CounterpartyPayloadDto getPayload(String bankId, String nseSymbol, String rating, boolean forceRefresh);
}
