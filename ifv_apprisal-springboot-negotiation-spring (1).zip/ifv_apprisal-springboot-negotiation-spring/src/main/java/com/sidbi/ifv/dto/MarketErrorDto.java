package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Error body returned with HTTP 502 when the market snapshot could not be built.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MarketErrorDto {

	private String error;

	private String fetchedAt;
}
