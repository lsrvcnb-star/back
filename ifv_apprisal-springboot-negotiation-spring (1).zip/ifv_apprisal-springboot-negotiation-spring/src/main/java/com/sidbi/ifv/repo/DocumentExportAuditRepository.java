package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sidbi.ifv.entity.DocumentExportAudit;

@Repository
public interface DocumentExportAuditRepository
        extends JpaRepository<DocumentExportAudit, Long> {

    List<DocumentExportAudit> findByUserId(String userId);

}