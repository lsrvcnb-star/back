package com.sidbi.ifv.controller;

import java.time.OffsetDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.CounterpartyErrorDto;
import com.sidbi.ifv.dto.CounterpartyPayloadDto;
import com.sidbi.ifv.dto.MarketErrorDto;
import com.sidbi.ifv.dto.MarketSnapshotDto;
import com.sidbi.ifv.services.NegotiationCounterpartyService;
import com.sidbi.ifv.services.NegotiationMarketService;

/**
 * Read-only endpoints backing the IFV negotiation pricing dashboard.
 * <p>
 * Rates are scraped live from official sources (RBI, FBIL, NSE/BSE, bank rate
 * cards) and cached in memory, so these are slower than the rest of the API.
 * Both endpoints accept {@code fresh=1} to bypass the cache.
 */
@RestController
@CrossOrigin
@RequestMapping("/api/public")
public class NegotiationPublicController {

	private static final Logger logger = LoggerFactory.getLogger(NegotiationPublicController.class);

	@Autowired
	private NegotiationMarketService negotiationMarketService;

	@Autowired
	private NegotiationCounterpartyService negotiationCounterpartyService;

	/**
	 * Unified policy and benchmark rate snapshot.
	 *
	 * @param fresh set to {@code 1} to bypass the 30-minute cache
	 */
	@GetMapping("/market")
	public ResponseEntity<Object> getMarket(@RequestParam(required = false) String fresh) {
		try {
			MarketSnapshotDto snapshot = negotiationMarketService.getSnapshot("1".equals(fresh));
			return ResponseEntity.ok(snapshot);
		} catch (Exception e) {
			logger.error("getMarket() failed: {}", e.getMessage(), e);
			MarketErrorDto error = MarketErrorDto.builder().error(e.getMessage())
					.fetchedAt(OffsetDateTime.now().toString()).build();
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(error);
		}
	}

	/**
	 * Counterparty bulk deposit rate card plus recent bond issuances.
	 *
	 * @param bank    counterparty id, e.g. {@code sbi} or {@code hdfc}
	 * @param symbol  optional NSE symbol used to look up bond announcements
	 * @param rating  optional issuer rating used to filter those issuances
	 * @param fresh   set to {@code 1} to bypass the 15-minute cache
	 */
	@GetMapping("/counterparty")
	public ResponseEntity<Object> getCounterparty(@RequestParam(required = false) String bank,
			@RequestParam(required = false) String symbol, @RequestParam(required = false) String rating,
			@RequestParam(required = false) String fresh) {

		String bankId = bank == null ? "" : bank.trim().toLowerCase();
		try {
			CounterpartyPayloadDto payload = negotiationCounterpartyService.getPayload(bankId, symbol, rating,
					"1".equals(fresh));
			return ResponseEntity.ok(payload);
		} catch (Exception e) {
			logger.error("getCounterparty() failed for bank={}: {}", bankId, e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
					.body(CounterpartyErrorDto.builder().error(e.getMessage()).build());
		}
	}
}
