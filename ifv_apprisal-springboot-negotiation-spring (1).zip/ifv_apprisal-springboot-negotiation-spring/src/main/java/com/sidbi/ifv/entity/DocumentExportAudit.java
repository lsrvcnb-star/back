package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "document_export_audit")
@Getter
@Setter
public class DocumentExportAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "audit_id")
    private Long auditId;

    @Column(name = "user_id", nullable = false, length = 100)
    private String userId;

    @Column(name = "user_name", length = 200)
    private String userName;

    @Column(name = "user_email", length = 250)
    private String userEmail;

    @Column(name = "document_type", length = 50)
    private String documentType;

    @Column(name = "export_format", length = 20)
    private String exportFormat;

    @Column(name = "document_name", length = 500)
    private String documentName;

    @Column(name = "company_name", length = 200)
    private String companyName;

    @Column(name = "deal_id", length = 100)
    private String dealId;

    @Column(name = "deal_name", length = 500)
    private String dealName;

    @Column(name = "war_percentage", precision = 10, scale = 4)
    private BigDecimal warPercentage;

    @Column(name = "xirr_percentage", precision = 10, scale = 4)
    private BigDecimal xirrPercentage;

    @Column(name = "irr_percentage", precision = 10, scale = 4)
    private BigDecimal irrPercentage;

    @Column(name = "mser_cof_percentage", precision = 10, scale = 4)
    private BigDecimal mserCofPercentage;

    @Column(name = "margin_bps", precision = 10, scale = 2)
    private BigDecimal marginBps;

    @Column(name = "min_margin_bps", precision = 10, scale = 2)
    private BigDecimal minMarginBps;

    @Column(name = "discretion_bps", precision = 10, scale = 2)
    private BigDecimal discretionBps;

    @Column(name = "approval_status", length = 500)
    private String approvalStatus;

    @Column(name = "exported_at")
    private LocalDateTime exportedAt;

    @Column(name = "client_ip", length = 100)
    private String clientIp;

    @Column(name = "browser_info", columnDefinition = "text")
    private String browserInfo;

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @Column(name = "remarks", columnDefinition = "text")
    private String remarks;

    @Column(name = "document_content", columnDefinition = "bytea")
    private byte[] documentContent;
}


