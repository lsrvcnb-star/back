package com.sidbi.ifv.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.DocumentExportAuditRequest;
import com.sidbi.ifv.dto.DocumentExportAuditResponse;
import com.sidbi.ifv.entity.DocumentExportAudit;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.DocumentExportAuditRepository;
import com.sidbi.ifv.repo.IfvApiUsersRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DocumentExportAuditService {

    private final DocumentExportAuditRepository auditRepository;
    private final IfvApiUsersRepo usersRepository;

    @Transactional
    public Long recordExport(
            DocumentExportAuditRequest request,
            MultipartFile document,
            UserDetails userDetails,
            String clientIp) {

        String userId = userDetails.getUsername();

        IfvApiUsersEntity user = usersRepository.findByOfrUserId(userId);
        if (user == null) {
            throw new EntityNotFoundException("IfvApiUsersEntity", userId);
        }

        DocumentExportAudit audit = new DocumentExportAudit();

        audit.setUserId(userId);
        audit.setUserName(fullName(user));
        audit.setUserEmail(user.getOfrEmail());

        audit.setDocumentType(request.getDocumentType().toUpperCase());
        audit.setExportFormat(request.getExportFormat().toLowerCase());
        audit.setDocumentName(request.getDocumentName());

        audit.setCompanyName(request.getCompanyName());
        audit.setDealId(request.getDealId());
        audit.setDealName(request.getDealName());

        audit.setWarPercentage(request.getWarPercentage());
        audit.setXirrPercentage(request.getXirrPercentage());
        audit.setIrrPercentage(request.getIrrPercentage());
        audit.setMserCofPercentage(request.getMserCofPercentage());

        audit.setMarginBps(request.getMarginBps());
        audit.setMinMarginBps(request.getMinMarginBps());
        audit.setDiscretionBps(request.getDiscretionBps());

        audit.setApprovalStatus(request.getApprovalStatus());
        audit.setExportedAt(LocalDateTime.now());

        audit.setClientIp(clientIp);
        audit.setBrowserInfo(request.getBrowserInfo());

        audit.setCreatedBy(userId);
        audit.setRemarks(request.getRemarks());

        if (document != null && !document.isEmpty()) {
            try {
                audit.setDocumentContent(document.getBytes());
            } catch (java.io.IOException e) {
                throw new IllegalArgumentException(
                        "Unable to read exported document", e);
            }
        }

        return auditRepository.save(audit).getAuditId();
    }

    public List<DocumentExportAuditResponse> getAuditsByUser(String userId) {

        List<DocumentExportAudit> audits =
                auditRepository.findByUserId(userId);

        return audits.stream()
                .map(this::convertToResponse)
                .toList();
    }

    private DocumentExportAuditResponse convertToResponse(
            DocumentExportAudit audit) {

        DocumentExportAuditResponse response =
                new DocumentExportAuditResponse();

        response.setAuditId(audit.getAuditId());
        response.setUserId(audit.getUserId());
        response.setUserName(audit.getUserName());
        response.setUserEmail(audit.getUserEmail());

        response.setDocumentType(audit.getDocumentType());
        response.setExportFormat(audit.getExportFormat());
        response.setDocumentName(audit.getDocumentName());

        response.setCompanyName(audit.getCompanyName());
        response.setDealId(audit.getDealId());
        response.setDealName(audit.getDealName());

        response.setWarPercentage(audit.getWarPercentage());
        response.setXirrPercentage(audit.getXirrPercentage());
        response.setIrrPercentage(audit.getIrrPercentage());
        response.setMserCofPercentage(audit.getMserCofPercentage());

        response.setMarginBps(audit.getMarginBps());
        response.setMinMarginBps(audit.getMinMarginBps());
        response.setDiscretionBps(audit.getDiscretionBps());

        response.setApprovalStatus(audit.getApprovalStatus());

        response.setClientIp(audit.getClientIp());
        response.setBrowserInfo(audit.getBrowserInfo());
        response.setRemarks(audit.getRemarks());

        response.setExportedAt(audit.getExportedAt());

        return response;
    }

    private String fullName(IfvApiUsersEntity user) {

        return String.join(" ",
                java.util.stream.Stream.of(
                                user.getOfrName(),
                                user.getOfrMiddleName(),
                                user.getOfrLastName())
                        .filter(StringUtils::hasText)
                        .toList());
    }

    public DocumentExportAudit getAuditById(Long auditId) {

        return auditRepository.findById(auditId)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "DocumentExportAudit",
                                auditId.toString()));
    }
}