package com.sidbi.ifv.services;

import com.sidbi.ifv.dto.MarketSnapshotDto;

/**
 * Serves the unified market-rate snapshot backing the IFV negotiation pricing
 * dashboard. Rates are scraped from official sources (RBI, FBIL) and cached
 * in memory.
 */
public interface NegotiationMarketService {

	/**
	 * @param forceRefresh skip the in-memory cache and re-scrape all sources
	 * @return the snapshot, with {@code cached} set to indicate cache provenance
	 */
	MarketSnapshotDto getSnapshot(boolean forceRefresh);
}
