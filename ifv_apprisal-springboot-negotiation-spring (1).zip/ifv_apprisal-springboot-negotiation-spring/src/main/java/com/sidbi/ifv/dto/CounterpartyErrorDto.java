package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Error body returned with HTTP 502 when the counterparty payload could not be built.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounterpartyErrorDto {

	private String error;
}
