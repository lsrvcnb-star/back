package com.sidbi.ifv.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Bond-issuance announcement block of the counterparty payload.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnnouncementsDto {

	private List<AnnouncementDto> rows;

	private String sourceUrl;

	private String note;

	private Boolean illustrative;
}
