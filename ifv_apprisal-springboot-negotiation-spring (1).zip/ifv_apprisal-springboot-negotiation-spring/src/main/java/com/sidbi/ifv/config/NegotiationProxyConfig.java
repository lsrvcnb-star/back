package com.sidbi.ifv.config;

import java.net.InetSocketAddress;
import java.net.Proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

/**
* Outbound HTTP client for the negotiation scrapers (RBI, FBIL, SBI, HDFC, NSE, BSE).
* <p>
* On the server network those public hosts are not reachable directly: the
* connection is dropped and {@code RestTemplate} reports "Connect timed out". The
* organisation therefore mandates egress through an HTTP proxy, so this
* configuration points a dedicated {@link RestTemplate} at it.
* <p>
* The proxy is taken from the org-standard keys {@code proxy}, {@code proxyIP} and
* {@code proxyPort} used by the other IFV services, so deploying this app needs the
* same three lines in its active profile. When {@code proxyIP}/{@code proxyPort}
* are absent the scraper connects directly, which is what developer machines with
* unrestricted internet access want.
* <p>
* This bean is deliberately separate from {@link AppConfig#restTemplate}. That
* bean is injected by type into existing services (for example {@code CVWebService})
* and is left untouched, so adding proxy support here cannot change the behaviour
* of any existing API.
*/
@Configuration
public class NegotiationProxyConfig {

   private static final Logger logger = LoggerFactory.getLogger(NegotiationProxyConfig.class);

   /** Hosts the scrapers reach, logged at startup so the target set is obvious. */
   private static final String SCRAPER_HOSTS = "rbi.org.in, fbil.org.in, sbi.co.in, hdfc.bank.in, "
           + "nseindia.com, bseindia.com";

   @Value("${negotiation.proxy.enabled:}")
   private String proxyEnabledOverride;

   /** Org-standard outbound proxy, same keys the other IFV services use. */
   @Value("${proxy:}")
   private String proxyMode;

   @Value("${proxyIP:}")
   private String proxyHost;

   @Value("${proxyPort:0}")
   private int proxyPort;

   @Value("${proxy.username:}")
   private String proxyUsername;

   @Value("${negotiation.proxy.no-proxy:localhost|127.0.0.1|*.sidbi.in}")
   private String noProxyHosts;

   /**
    * Also publish the proxy as JVM system properties. Off by default: it would
    * redirect every other library in the process (JDBC drivers, other outbound
    * HTTP) through the proxy. The scrapers work without it because they use the
    * {@code RestTemplate} defined here.
    */
   @Value("${negotiation.proxy.jvm-system-properties:false}")
   private boolean applyJvmSystemProperties;

   @Value("${spring.rest-template.connect-timeout:20000}")
   private int connectTimeout;

   @Value("${spring.rest-template.read-timeout:20000}")
   private int readTimeout;

   @Bean("negotiationRestTemplate")
   RestTemplate negotiationRestTemplate(RestTemplateBuilder builder) {
       SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
       requestFactory.setConnectTimeout(connectTimeout);
       requestFactory.setReadTimeout(readTimeout);

       boolean useProxy = resolveUseProxy();
       if (useProxy) {
           requestFactory.setProxy(httpProxy(new InetSocketAddress(proxyHost, proxyPort)));
       }

       logEffectiveRoute(useProxy);

       return builder.requestFactory(() -> requestFactory).build();
   }

   /**
    * Auto mode: the scrapers go through the proxy whenever {@code proxyIP} and
    * {@code proxyPort} are configured, which is how the other IFV services are
    * deployed. {@code negotiation.proxy.enabled} can force the decision either
    * way; leaving it unset keeps the auto behaviour.
    */
   private boolean resolveUseProxy() {
       if (!StringUtils.hasText(proxyEnabledOverride)) {
           return StringUtils.hasText(proxyHost) && proxyPort > 0;
       }
       boolean explicit = Boolean.parseBoolean(proxyEnabledOverride.trim());
       if (explicit && !StringUtils.hasText(proxyHost)) {
           throw new IllegalStateException("negotiation.proxy.enabled=true but proxyIP is not set. "
                   + "Add proxyIP / proxyPort to the active profile's properties.");
       }
       return explicit;
   }

   /**
    * Proxies are configured per scheme by the JVM; HTTP is enough because
    * {@link Proxy#HTTP} issues a CONNECT tunnel for HTTPS targets.
    */
   private Proxy httpProxy(InetSocketAddress address) {
       if (StringUtils.hasText(proxyUsername)) {
           logger.warn("proxy.username is set, but SimpleClientHttpRequestFactory cannot "
                   + "authenticate to a proxy. Ask IT for a non-authenticating proxy endpoint, otherwise "
                   + "scraping will fail with 407 Proxy Authentication Required.");
       }
       return new Proxy(Proxy.Type.HTTP, address);
   }

   private void logEffectiveRoute(boolean useProxy) {
       // These are what the JVM default ProxySelector reads. If they are null then
       // every other outbound call in this process still goes straight to the
       // internet, which is the usual reason a scrape times out on the server.
       logger.info("Negotiation scrapers reach: {}", SCRAPER_HOSTS);
       logger.info("Outbound proxy config: proxy={} proxyIP={} proxyPort={} (negotiation.proxy.enabled={})",
               proxyMode, proxyHost, proxyPort, StringUtils.hasText(proxyEnabledOverride)
                       ? proxyEnabledOverride : "<auto>");
       if (!useProxy) {
           logger.warn("Negotiation outbound HTTP mode=DIRECT. RBI/FBIL/SBI/HDFC/NSE/BSE must be "
                   + "directly reachable; on a proxy-only network this will time out. Set proxy=server, "
                   + "proxyIP=<host>, proxyPort=<port> in the active profile's properties.");
           return;
       }
       logger.info("Negotiation outbound HTTP mode=PROXY via {}:{} (timeouts connect={}ms read={}ms)",
               proxyHost, proxyPort, connectTimeout, readTimeout);
       if (applyJvmSystemProperties) {
           System.setProperty("http.proxyHost", proxyHost);
           System.setProperty("http.proxyPort", String.valueOf(proxyPort));
           System.setProperty("https.proxyHost", proxyHost);
           System.setProperty("https.proxyPort", String.valueOf(proxyPort));
           System.setProperty("http.nonProxyHosts", noProxyHosts);
           System.setProperty("https.nonProxyHosts", noProxyHosts);
           logger.warn("Applied {} as JVM proxy system properties; every other outbound call in this "
                   + "process now uses them too.", proxyHost);
       } else {
           logger.info("JVM proxy system properties left unchanged "
                   + "(http.proxyHost={} https.proxyHost={}); other outbound calls are unaffected.",
                   System.getProperty("http.proxyHost"), System.getProperty("https.proxyHost"));
       }
   }
}


