package com.sidbi.ifv.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A single bulk-deposit rate row.
 * <p>
 * {@code nonCallableMin}, {@code nonCallableMax} and {@code amountBucket} are
 * omitted from the JSON when unset, matching the shape the negotiation dashboard
 * expects (it uses {@code ?? null} / {@code != null} guards on these).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DepositRowDto {

	private String tenor;

	private Double callable;

	private Double nonCallable;

	private Double nonCallableMin;

	private Double nonCallableMax;

	/** {@code "3-5"} or {@code "5+"}; absent for banks without split rate cards. */
	private String amountBucket;
}
