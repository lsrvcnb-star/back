package com.sidbi.ifv.service.impl;

import java.io.InputStream;

import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.client.FileServerFeignClient;
import com.sidbi.ifv.dto.CommonRequestDto;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.exception.FileAccessException;
import com.sidbi.ifv.services.FileStorageService;
import com.sidbi.ifv.util.CommonRimvServiceSupport;
import com.sidbi.ifv.util.ProfileService;

import feign.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Profile({ "uat", "prod" })
@RequiredArgsConstructor
public class RemoteFileStorageService implements FileStorageService {

	private final FileServerFeignClient feignClient;
	private final CommonRimvServiceSupport commonRimvServiceSupport;
	private final ProfileService profileService;

	@Override
	public ResponseEntity<StreamingResponseBody> handleFile(CommonRequestDto requestDto) {

		String sanitizedFilePath = requestDto.getFilePath();

		try {

			log.info("File download request received. action={}, filePath={}", requestDto.getAction(),
					requestDto.getFilePath());

			if (profileService.isProfileActive("prod") && sanitizedFilePath != null
					&& sanitizedFilePath.startsWith("/IFV/")) {

				sanitizedFilePath = sanitizedFilePath.replaceFirst("^/IFV", "");

				log.warn("PROD path correction applied. Original={}, Corrected={}", requestDto.getFilePath(),
						sanitizedFilePath);
			}

			log.info("Sanitized file path: {}", sanitizedFilePath);

			Response feignResponse = feignClient.fetchFile(sanitizedFilePath);

			if (feignResponse == null) {
				throw new FileAccessException("No response received from file server");
			}

			int status = feignResponse.status();

			log.info("File server response status={} for path={}", status, sanitizedFilePath);

			if (status == 404) {
				throw new EntityNotFoundException("File not found: " + sanitizedFilePath);
			}

			if (status != 200) {
				throw new FileAccessException("Unexpected response from file server. Status: " + status);
			}

			if (feignResponse.body() == null) {
				throw new FileAccessException("File server returned empty response body");
			}

			String fileName = extractFileName(sanitizedFilePath);

			MediaType mediaType = commonRimvServiceSupport.determineContentType(fileName);

			StreamingResponseBody stream = outputStream -> {
				try (InputStream in = feignResponse.body().asInputStream()) {

					log.info("Streaming file to client. fileName={}", fileName);

					in.transferTo(outputStream);
					outputStream.flush();

					log.info("File streamed successfully. fileName={}", fileName);

				} catch (Exception ex) {

					log.error("Error while streaming file. fileName={}", fileName, ex);

					throw ex;
				}
			};

			ResponseEntity.BodyBuilder responseBuilder = ResponseEntity.ok().contentType(mediaType);

			if ("download".equalsIgnoreCase(requestDto.getAction())) {

				responseBuilder.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
			}

			return responseBuilder.body(stream);

		} catch (EntityNotFoundException ex) {

			throw ex;

		} catch (Exception ex) {

			log.error("File download failed. action={}, filePath={}", requestDto.getAction(), sanitizedFilePath, ex);

			throw new FileAccessException("Failed to download file: " + sanitizedFilePath, ex);
		}
	}

	private String extractFileName(String filePath) {
		return filePath.substring(filePath.lastIndexOf("/") + 1);
	}
}
