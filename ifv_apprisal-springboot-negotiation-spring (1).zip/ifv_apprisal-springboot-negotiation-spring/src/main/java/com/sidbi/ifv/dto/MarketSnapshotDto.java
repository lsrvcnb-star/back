package com.sidbi.ifv.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Unified market-rate snapshot returned by {@code GET /api/public/market}.
 * Every field name is part of the public contract consumed by the IFV
 * negotiation dashboard and must not be renamed.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MarketSnapshotDto {

	private String fetchedAt;

	private RatePointDto repo;

	private RatePointDto reverseRepo;

	private RatePointDto sdf;

	private RatePointDto msf;

	private RatePointDto bankRate;

	private RatePointDto gsec10;

	private RatePointDto tbill3m;

	private RatePointDto cd1y;

	private RatePointDto cp1y;

	@Builder.Default
	private List<String> notes = new ArrayList<>();

	/** True when the payload was served from the in-memory TTL cache. */
	private Boolean cached;
}
