package com.sidbi.ifv.service.impl;

import java.text.NumberFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.dto.AnnouncementDto;
import com.sidbi.ifv.dto.AnnouncementsDto;
import com.sidbi.ifv.dto.CounterpartyPayloadDto;
import com.sidbi.ifv.dto.DepositRowDto;
import com.sidbi.ifv.dto.DepositsDto;
import com.sidbi.ifv.services.NegotiationCounterpartyService;
import com.sidbi.ifv.util.CreditRatingUtil;
import com.sidbi.ifv.util.HtmlTableUtil;
import com.sidbi.ifv.util.NegotiationHttpUtil;
import com.sidbi.ifv.util.NegotiationReferenceData;
import com.sidbi.ifv.util.NegotiationTtlCache;

/**
 * Pulls counterparty data for the negotiation pricing dashboard from official and
 * exchange-published sources:
 * <ul>
 * <li><b>Bulk deposits</b> — per-bank rate-card scrapers. SBI and HDFC are wired
 * up; other banks get a note plus the sample rate card.</li>
 * <li><b>Bond issuances</b> — NSE corporate announcements, falling back to the BSE
 * feed (more reachable from a datacenter than NSE), then backfilled with curated
 * deals from {@link NegotiationReferenceData}.</li>
 * </ul>
 * Everything is best-effort. When a source cannot be parsed the field is left null
 * with a note so the dashboard can show a graceful empty state and a link to the
 * official source, rather than a fabricated number.
 */
@Service
public class NegotiationCounterpartyServiceImpl implements NegotiationCounterpartyService {

	private static final Logger logger = LoggerFactory.getLogger(NegotiationCounterpartyServiceImpl.class);

	@Value("${negotiation.counterparty.cache-ttl-minutes:15}")
	private long cacheTtlMinutes;

	/** Rate points below this on a bank page are fees or floors, not deposit rates. */
	private static final double MIN_PLAUSIBLE_RATE = 5.0d;

	/** Roughly plus or minus two rating notches on the {@link CreditRatingUtil} scale. */
	private static final int RATING_TOLERANCE = 4;

	private static final int MAX_ANNOUNCEMENTS = 12;

	/**
	 * Announcements are only surfaced for the current calendar year — older filings
	 * are stale for a pricing discussion.
	 */
	private static final String ANNOUNCEMENT_YEAR = String.valueOf(OffsetDateTime.now().getYear());

	private static final String SBI_BULK_URL = "https://sbi.co.in/web/interest-rates/deposit-rates/domestic-bulk-term-deposits";
	private static final String HDFC_URL = "https://www.hdfc.bank.in/interest-rates";

	private static final String NSE_API_URL = "https://www.nseindia.com/api/corporate-announcements?index=equities&symbol=%s";
	private static final String NSE_SOURCE_URL = "https://www.nseindia.com/companies-listing/corporate-filings-announcements";
	private static final String BSE_API_URL = "https://api.bseindia.com/BseIndiaAPI/api/AnnGetData/w"
			+ "?strCat=-1&strPrevDate=%s&strScrip=%s&strSearch=P&strToDate=%s&strType=C";
	private static final String BSE_GENERIC_SOURCE_URL = "https://www.bseindia.com/corporates/ann.html";
	private static final String BSE_ATTACHMENT_BASE = "https://www.bseindia.com/xml-data/corpfiling/AttachHis/";

	private static final List<String> BOND_KEYWORDS = List.of("bond", "debenture", "ncd", " mtn", "tier ii", "tier-ii",
			"tier 2", "tier-2", "additional tier", "at1", "at-1", "at 1", "infrastructure", "green bond", "masala",
			"perpetual");

	private static final List<String> EQUITY_PLAN_KEYWORDS = List.of("esop", "esos", "esps");

	// Amount, e.g. "Rs. 5,000 crore" / "INR 500 Cr" / "₹ 3000 Lakh".
	private static final Pattern AMOUNT = Pattern.compile(
			"(?:rs\\.?|inr|₹)\\s*([0-9,]+(?:\\.[0-9]+)?)\\s*(crore|cr|lakh|billion|bn|million|mn)\\b",
			Pattern.CASE_INSENSITIVE);
	// Tenure, e.g. "10 years" / "10-year" / "5 yr".
	private static final Pattern TENURE = Pattern.compile("([0-9]{1,2}(?:\\.[0-9])?)\\s*[- ]?\\s*(?:years?|yrs?|yr)\\b",
			Pattern.CASE_INSENSITIVE);
	private static final Pattern COUPON_LABELLED = Pattern.compile(
			"(?:coupon|rate|@|at)\\s*(?:of\\s*)?([0-9]{1,2}\\.[0-9]{1,3})\\s*(?:%|per cent|percent|p\\.a\\.)",
			Pattern.CASE_INSENSITIVE);
	private static final Pattern COUPON_ANY = Pattern.compile("([0-9]{1,2}\\.[0-9]{1,3})\\s*%");

	private static final Pattern PERPETUAL = Pattern.compile("perpetual", Pattern.CASE_INSENSITIVE);
	private static final Pattern AT_ONE = Pattern.compile("additional\\s*tier|\\bat[-\\s]?1\\b", Pattern.CASE_INSENSITIVE);
	private static final Pattern TIER_TWO = Pattern.compile("tier[-\\s]?ii|tier[-\\s]?2", Pattern.CASE_INSENSITIVE);
	private static final Pattern INFRASTRUCTURE = Pattern.compile("infrastructure", Pattern.CASE_INSENSITIVE);
	private static final Pattern GREEN_BOND = Pattern.compile("green\\s*bond", Pattern.CASE_INSENSITIVE);
	private static final Pattern MASALA = Pattern.compile("masala", Pattern.CASE_INSENSITIVE);
	private static final Pattern NCD = Pattern.compile("\\bncd\\b|non[-\\s]?convertible", Pattern.CASE_INSENSITIVE);
	private static final Pattern DEBENTURE = Pattern.compile("debenture", Pattern.CASE_INSENSITIVE);
	private static final Pattern BOND = Pattern.compile("\\bbond\\b", Pattern.CASE_INSENSITIVE);
	private static final Pattern CRORE_UNIT = Pattern.compile("crore|cr", Pattern.CASE_INSENSITIVE);
	private static final Pattern LAKH_UNIT = Pattern.compile("lakh", Pattern.CASE_INSENSITIVE);
	private static final Pattern BILLION_UNIT = Pattern.compile("billion|bn", Pattern.CASE_INSENSITIVE);
	private static final Pattern TENOR_HEADER = Pattern.compile("tenor", Pattern.CASE_INSENSITIVE);

	private static final Pattern SBI_WEF = Pattern.compile("w\\.e\\.f\\.?\\s*([0-9]{2}/[0-9]{2}/[0-9]{4})",
			Pattern.CASE_INSENSITIVE);
	private static final Pattern PURE_NUMBER = Pattern.compile("^[0-9]+(\\.[0-9]+)?$");
	private static final Pattern PERCENT_VALUE = Pattern.compile("([0-9]+\\.[0-9]+)\\s*%");

	private static final Pattern HDFC_TABLE_3_TO_5 = Pattern
			.compile(">=\\s*3\\s*crore\\s*to\\s*<\\s*5\\s*crores?", Pattern.CASE_INSENSITIVE);
	private static final Pattern HDFC_TABLE_5_PLUS = Pattern
			.compile("5\\s*crore\\s*to\\s*<\\s*5\\.25\\s*crore", Pattern.CASE_INSENSITIVE);
	private static final Pattern HDFC_TABLE_5_PLUS_ALT = Pattern.compile(
			"amounts?\\s+equal\\s+&?\\s*more\\s+than\\s+(?:rs\\.?|₹)\\s*5\\s*cr", Pattern.CASE_INSENSITIVE);
	private static final Pattern HDFC_APPLICABLE_FROM = Pattern.compile(
			"applicable\\s+(?:from|for)\\s+([0-9]{1,2}(?:st|nd|rd|th)?\\s+[A-Za-z]+,?\\s+[0-9]{4})",
			Pattern.CASE_INSENSITIVE);
	private static final Pattern TENOR_LABEL_NO_DIGIT = Pattern.compile("tenor|tenure|period|crore", Pattern.CASE_INSENSITIVE);
	private static final Pattern UNDER_ONE_YEAR = Pattern.compile("<\\s*1\\s*year|less\\s+than\\s+1\\s*year",
			Pattern.CASE_INSENSITIVE);
	private static final Pattern DAY_ONLY = Pattern.compile("\\bday|\\bdays\\b", Pattern.CASE_INSENSITIVE);
	private static final Pattern YEAR_WORD = Pattern.compile("\\byear|\\byr\\b|\\byrs\\b", Pattern.CASE_INSENSITIVE);
	private static final Pattern MONTHS = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*months?", Pattern.CASE_INSENSITIVE);
	private static final Pattern RATE_COLUMN = Pattern.compile("[0-9]+(\\.[0-9]+)?");

	private static final Pattern NSE_OFFSHORE = Pattern
			.compile("offshore|usd|gift\\s*city|masala|reg[-\\s]?s|144a", Pattern.CASE_INSENSITIVE);
	private static final Pattern BSE_OFFSHORE = Pattern
			.compile("offshore|usd|gift\\s*city|masala", Pattern.CASE_INSENSITIVE);

	@Autowired
	private NegotiationHttpUtil httpUtil;

	@Autowired
	private NegotiationTtlCache cache;

	@Autowired
	private ObjectMapper objectMapper;

	@Override
	public CounterpartyPayloadDto getPayload(String bankId, String nseSymbol, String rating, boolean forceRefresh) {
		String key = bankId + ":" + (nseSymbol == null ? "" : nseSymbol) + ":" + (rating == null ? "" : rating);
		if (!forceRefresh) {
			CounterpartyPayloadDto cached = cache.get(key, Duration.ofMinutes(cacheTtlMinutes));
			if (cached != null) {
				cached.setCached(true);
				return cached;
			}
		}
		CounterpartyPayloadDto payload = build(bankId, nseSymbol, rating);
		cache.put(key, payload);
		payload.setCached(false);
		return payload;
	}

	private CounterpartyPayloadDto build(String bankId, String nseSymbol, String rating) {
		CompletableFuture<DepositsDto> deposits = CompletableFuture
				.supplyAsync(() -> scrapeDeposits(bankId == null ? "" : bankId));
		CompletableFuture<AnnouncementsDto> announcements = CompletableFuture
				.supplyAsync(() -> fetchNseAnnouncements(nseSymbol));

		DepositsDto depositsRaw = deposits.join();
		AnnouncementsDto resolved = resolveAnnouncements(bankId, nseSymbol, rating, announcements.join());

		return CounterpartyPayloadDto.builder().fetchedAt(OffsetDateTime.now().toString()).bankId(bankId)
				.bankRating(rating).deposits(finaliseDeposits(depositsRaw)).announcements(resolved).build();
	}

	// ------------------------------------------------------------------
	// Bulk deposit rate cards
	// ------------------------------------------------------------------

	private DepositsDto scrapeDeposits(String bankId) {
		try {
			switch (bankId) {
			case "sbi":
				return scrapeSbiBulk();
			case "hdfc":
				return scrapeHdfcBulk();
			default:
				return DepositsDto.builder().rows(null).sourceUrl(null).asOf(null)
						.note("Live rate card not connected for this bank.").build();
			}
		} catch (Exception e) {
			logger.debug("Deposit scrape failed for {}: {}", bankId, rootMessage(e));
			return DepositsDto.builder().rows(null).sourceUrl(null).asOf(null)
					.note("Rate card fetch failed: " + rootMessage(e)).build();
		}
	}

	/**
	 * SBI publishes callable bulk rates on a single table. The 2nd numeric column
	 * is the "Revised Rates for Public" value.
	 */
	private DepositsDto scrapeSbiBulk() {
		String html = httpUtil.tryGetText(SBI_BULK_URL, NegotiationHttpUtil.headers("Accept", "text/html"));
		if (html == null) {
			return sbiFailure("SBI page could not be reached");
		}
		String asOf = HtmlTableUtil.firstGroup(SBI_WEF, html);
		String tableHtml = HtmlTableUtil.firstTable(html);
		if (tableHtml == null) {
			return DepositsDto.builder().rows(null).sourceUrl(SBI_BULK_URL).asOf(asOf)
					.note("Rate table not found on SBI page").build();
		}

		List<DepositRowDto> parsed = new ArrayList<>();
		for (String rowHtml : HtmlTableUtil.rows(tableHtml)) {
			List<String> cells = HtmlTableUtil.cells(rowHtml, false);
			if (cells.size() < 3) {
				continue;
			}
			String tenor = cells.get(0);
			if (tenor.isEmpty() || TENOR_HEADER.matcher(tenor).find()) {
				continue;
			}
			Double revisedPublic = pickRevisedPublicRate(cells);
			if (revisedPublic == null) {
				continue;
			}
			parsed.add(DepositRowDto.builder().tenor(tenor).callable(revisedPublic).nonCallable(null).build());
		}
		if (parsed.isEmpty()) {
			return DepositsDto.builder().rows(null).sourceUrl(SBI_BULK_URL).asOf(asOf)
					.note("Could not parse rate rows").build();
		}
		return DepositsDto.builder().rows(parsed).sourceUrl(SBI_BULK_URL).asOf(asOf).note(null).build();
	}

	/** Prefers the 2nd numeric cell (Revised Rates for Public), else the 1st. */
	private Double pickRevisedPublicRate(List<String> cells) {
		List<Double> numerics = new ArrayList<>();
		for (String cell : cells.subList(1, cells.size())) {
			if (PURE_NUMBER.matcher(cell).matches()) {
				numerics.add(Double.parseDouble(cell));
			}
		}
		if (numerics.size() >= 2) {
			return numerics.get(1);
		}
		return numerics.isEmpty() ? null : numerics.get(0);
	}

	private DepositsDto sbiFailure(String note) {
		return DepositsDto.builder().rows(null).sourceUrl(SBI_BULK_URL).asOf(null).note(note).build();
	}

	/**
	 * HDFC publishes two inline tables: {@code >= 3 Cr to < 5 Cr} and
	 * {@code >= 5 Cr}. They are merged by tenor label so the dashboard can show a
	 * 3–5 Cr and a 5 Cr+ column side by side.
	 */
	private DepositsDto scrapeHdfcBulk() {
		String html = httpUtil.tryGetText(HDFC_URL, NegotiationHttpUtil.headers("Accept", "text/html"));
		if (html == null) {
			return DepositsDto.builder().rows(null).sourceUrl(HDFC_URL).asOf(null)
					.note("HDFC page could not be reached").build();
		}

		String table3To5 = null;
		String table5Plus = null;
		for (String table : HtmlTableUtil.tables(html)) {
			String text = HtmlTableUtil.decodeEntities(HtmlTableUtil.plainText(table)).toLowerCase(Locale.ROOT);
			if (table3To5 == null && HDFC_TABLE_3_TO_5.matcher(text).find()) {
				table3To5 = table;
				continue;
			}
			if (table5Plus == null && (HDFC_TABLE_5_PLUS.matcher(text).find()
					|| HDFC_TABLE_5_PLUS_ALT.matcher(text).find())) {
				table5Plus = table;
			}
		}

		List<TenorRates> rows3To5 = table3To5 == null ? List.of() : parseHdfcTable(table3To5);
		List<TenorRates> rows5Plus = table5Plus == null ? List.of() : parseHdfcTable(table5Plus);
		String asOf = parseHdfcAsOf(table5Plus, table3To5, html);

		List<DepositRowDto> merged = new ArrayList<>();
		Map<String, DepositRowDto> byTenor = new LinkedHashMap<>();
		for (TenorRates entry : rows3To5) {
			if (!isOneYearPlus(entry.tenor)) {
				continue;
			}
			// The 3-5 Cr table carries a single public rate.
			DepositRowDto row = DepositRowDto.builder().tenor(entry.tenor).callable(entry.rates.get(0))
					.nonCallable(null).amountBucket("3-5").build();
			byTenor.put(entry.tenor.toLowerCase(Locale.ROOT), row);
			merged.add(row);
		}
		for (TenorRates entry : rows5Plus) {
			if (!isOneYearPlus(entry.tenor)) {
				continue;
			}
			double min = entry.rates.stream().mapToDouble(Double::doubleValue).min().orElse(0);
			double max = entry.rates.stream().mapToDouble(Double::doubleValue).max().orElse(0);
			DepositRowDto existing = byTenor.get(entry.tenor.toLowerCase(Locale.ROOT));
			if (existing != null) {
				existing.setNonCallable(max);
				existing.setNonCallableMin(min);
				existing.setNonCallableMax(max);
			} else {
				merged.add(DepositRowDto.builder().tenor(entry.tenor).callable(null).nonCallable(max)
						.nonCallableMin(min).nonCallableMax(max).amountBucket("5+").build());
			}
		}

		if (merged.isEmpty()) {
			return DepositsDto.builder().rows(null).sourceUrl(HDFC_URL).asOf(asOf)
					.note("Could not parse HDFC rate tables").build();
		}
		return DepositsDto.builder().rows(merged).sourceUrl(HDFC_URL).asOf(asOf).note(null).build();
	}

	private List<TenorRates> parseHdfcTable(String tableHtml) {
		List<TenorRates> out = new ArrayList<>();
		for (String rowHtml : HtmlTableUtil.rows(tableHtml)) {
			List<String> cells = HtmlTableUtil.cells(rowHtml, true);
			if (cells.size() < 2) {
				continue;
			}
			String tenor = cells.get(0);
			if (tenor.isEmpty() || (TENOR_LABEL_NO_DIGIT.matcher(tenor).find() && !RATE_COLUMN.matcher(tenor).find())) {
				continue;
			}
			List<Double> rates = new ArrayList<>();
			for (String cell : cells.subList(1, cells.size())) {
				Matcher matcher = PERCENT_VALUE.matcher(cell);
				if (matcher.find()) {
					rates.add(Double.parseDouble(matcher.group(1)));
				}
			}
			// Drop premature-withdrawal floors and similar non-deposit-rate cells.
			List<Double> plausible = rates.stream().filter(value -> value >= MIN_PLAUSIBLE_RATE).collect(Collectors.toList());
			if (plausible.isEmpty()) {
				continue;
			}
			out.add(new TenorRates(tenor, plausible));
		}
		return out;
	}

	/** The dashboard only prices 1-year-and-above tenors, so filter the rest out. */
	private boolean isOneYearPlus(String tenor) {
		String t = tenor.toLowerCase(Locale.ROOT);
		if (UNDER_ONE_YEAR.matcher(t).find()) {
			return false;
		}
		boolean mentionsYears = YEAR_WORD.matcher(t).find();
		if (!mentionsYears && DAY_ONLY.matcher(t).find()) {
			return false;
		}
		List<Double> months = new ArrayList<>();
		Matcher matcher = MONTHS.matcher(t);
		while (matcher.find()) {
			months.add(Double.parseDouble(matcher.group(1)));
		}
		if (!months.isEmpty() && !mentionsYears) {
			return months.stream().anyMatch(value -> value >= 12);
		}
		return mentionsYears;
	}

	private String parseHdfcAsOf(String... chunks) {
		for (String chunk : chunks) {
			if (chunk == null) {
				continue;
			}
			String text = HtmlTableUtil.decodeEntities(HtmlTableUtil.plainText(chunk));
			String match = HtmlTableUtil.firstGroup(HDFC_APPLICABLE_FROM, text);
			if (match != null) {
				return match;
			}
		}
		return null;
	}

	/** Falls back to the sample rate card when no live rows were parsed. */
	private DepositsDto finaliseDeposits(DepositsDto depositsRaw) {
		boolean hasLive = depositsRaw.getRows() != null && !depositsRaw.getRows().isEmpty();
		List<DepositRowDto> rows = hasLive ? depositsRaw.getRows() : NegotiationReferenceData.illustrativeBulkDeposits();
		boolean hasAmountBuckets = rows.stream()
				.anyMatch(row -> row.getNonCallable() != null && row.getCallable() != null)
				|| rows.stream().anyMatch(row -> "5+".equals(row.getAmountBucket()));

		if (hasLive) {
			return DepositsDto.builder().rows(rows).sourceUrl(depositsRaw.getSourceUrl()).asOf(depositsRaw.getAsOf())
					.note(depositsRaw.getNote()).illustrative(false).hasAmountBuckets(hasAmountBuckets).build();
		}
		return DepositsDto.builder().rows(rows).sourceUrl(depositsRaw.getSourceUrl()).asOf(null).note(null)
				.illustrative(true).hasAmountBuckets(hasAmountBuckets).build();
	}

	// ------------------------------------------------------------------
	// Bond issuance announcements
	// ------------------------------------------------------------------

	/**
	 * NSE first, BSE as a fallback (more reachable from a datacenter), then curated
	 * deals backfilled in, then filtered to the issuer's rating band.
	 */
	private AnnouncementsDto resolveAnnouncements(String bankId, String nseSymbol, String rating,
			AnnouncementsDto scraped) {
		AnnouncementsDto source = scraped;
		if (scraped.getRows().isEmpty() && nseSymbol != null && !nseSymbol.isBlank()) {
			AnnouncementsDto bse = fetchBseAnnouncements(nseSymbol);
			if (!bse.getRows().isEmpty()) {
				source = bse;
			}
		}

		List<AnnouncementDto> rows = mergeCurated(source.getRows(), bankId);
		rows = filterByRating(rows, rating);

		// When curated deals replace an empty scrape, drop the "nothing found" note
		// so the dashboard does not show an empty state next to populated rows.
		String note = source.getRows().isEmpty() ? null : source.getNote();

		return AnnouncementsDto.builder().rows(rows).sourceUrl(source.getSourceUrl()).note(note).build();
	}

	/** Prepends curated deals that are not already present in the scraped feed. */
	private List<AnnouncementDto> mergeCurated(List<AnnouncementDto> scraped, String bankId) {
		List<AnnouncementDto> curated = NegotiationReferenceData.curatedAnnouncements(bankId);
		if (curated.isEmpty()) {
			return scraped;
		}
		Set<String> existing = scraped.stream().map(this::dedupeKey).collect(Collectors.toSet());
		List<AnnouncementDto> merged = new ArrayList<>();
		for (AnnouncementDto candidate : curated) {
			if (!existing.contains(dedupeKey(candidate))) {
				merged.add(candidate);
			}
		}
		merged.addAll(scraped);
		return merged;
	}

	private String dedupeKey(AnnouncementDto announcement) {
		String desc = announcement.getDesc() == null ? "" : announcement.getDesc();
		return announcement.getDate() + "|" + desc.substring(0, Math.min(40, desc.length()));
	}

	/**
	 * Keeps issues rated within {@link #RATING_TOLERANCE} of the issuer rating.
	 * AT-1 and perpetual issues typically sit one or two notches below senior, so
	 * they stay in. Untagged rows are always kept. Applied only if it does not
	 * wipe out the results entirely.
	 */
	private List<AnnouncementDto> filterByRating(List<AnnouncementDto> rows, String rating) {
		if (rating == null || rating.isBlank() || CreditRatingUtil.rank(rating) <= 0) {
			return rows;
		}
		List<AnnouncementDto> filtered = rows.stream()
				.filter(row -> row.getRating() == null || row.getRating().isBlank()
						|| CreditRatingUtil.isWithinTolerance(rating, row.getRating(), RATING_TOLERANCE))
				.collect(Collectors.toList());
		return filtered.isEmpty() ? rows : filtered;
	}

	private AnnouncementsDto fetchNseAnnouncements(String symbol) {
		if (symbol == null || symbol.isBlank()) {
			return AnnouncementsDto.builder().rows(new ArrayList<>()).sourceUrl(null)
					.note("No NSE symbol mapped for this bank.").build();
		}
		String body = httpUtil.tryGetText(String.format(NSE_API_URL, urlEncode(symbol)),
				NegotiationHttpUtil.headers("Accept", "application/json"));
		if (body == null) {
			return AnnouncementsDto.builder().rows(new ArrayList<>()).sourceUrl(NSE_SOURCE_URL)
					.note("NSE announcements could not be reached").build();
		}
		try {
			JsonNode node = objectMapper.readTree(body);
			if (!node.isArray()) {
				return AnnouncementsDto.builder().rows(new ArrayList<>()).sourceUrl(NSE_SOURCE_URL)
						.note("NSE payload not array").build();
			}
			List<AnnouncementDto> rows = new ArrayList<>();
			for (JsonNode row : node) {
				if (rows.size() >= MAX_ANNOUNCEMENTS) {
					break;
				}
				String desc = text(row, "desc");
				String combined = desc + " " + text(row, "attchmntText");
				String date = text(row, "an_dt");
				if (!isBondRelevant(combined, date)) {
					continue;
				}
				BondDetails details = extractBondDetails(combined);
				rows.add(AnnouncementDto.builder().date(truncate(date, 11)).desc(desc).amount(details.amount)
						.tenure(details.tenure).coupon(details.coupon).securityType(details.securityType)
						.market(NSE_OFFSHORE.matcher(combined).find() ? "Offshore" : "Domestic")
						.status("Issued / Active").attachmentUrl(nullableText(row, "attchmntFile")).build());
			}
			return AnnouncementsDto.builder().rows(rows).sourceUrl(NSE_SOURCE_URL)
					.note(rows.isEmpty() ? "No bond-related filings surfaced." : null).build();
		} catch (Exception e) {
			return AnnouncementsDto.builder().rows(new ArrayList<>()).sourceUrl(NSE_SOURCE_URL)
					.note("NSE fetch failed: " + rootMessage(e)).build();
		}
	}

	private AnnouncementsDto fetchBseAnnouncements(String symbol) {
		String code = NegotiationReferenceData.BSE_CODES.get(symbol.toUpperCase(Locale.ROOT));
		String sourceUrl = code == null ? BSE_GENERIC_SOURCE_URL
				: "https://www.bseindia.com/stock-share-price/-/-/" + code + "/corp-announcements/";
		if (code == null) {
			return AnnouncementsDto.builder().rows(new ArrayList<>()).sourceUrl(sourceUrl).note("No BSE code mapped.")
					.build();
		}
		LocalDate to = LocalDate.now();
		LocalDate from = to.minusYears(1);
		String url = String.format(BSE_API_URL, ddMmmyyyy(from), code, ddMmmyyyy(to));
		String body = httpUtil.tryGetText(url, NegotiationHttpUtil.headers("Accept", "application/json, text/plain, */*",
				"Referer", "https://www.bseindia.com/", "Origin", "https://www.bseindia.com"));
		if (body == null) {
			return AnnouncementsDto.builder().rows(new ArrayList<>()).sourceUrl(sourceUrl)
					.note("BSE announcements could not be reached").build();
		}
		try {
			JsonNode table = objectMapper.readTree(body).path("Table");
			List<AnnouncementDto> rows = new ArrayList<>();
			if (table.isArray()) {
				for (JsonNode row : table) {
					if (rows.size() >= MAX_ANNOUNCEMENTS) {
						break;
					}
					String headline = firstNonNull(text(row, "HEADLINE"), text(row, "NEWSSUB"));
					String combined = headline + " " + text(row, "MORE");
					String date = firstNonNull(text(row, "NEWS_DT"), text(row, "DissemDT"));
					if (!isBondRelevant(combined, date)) {
						continue;
					}
					BondDetails details = extractBondDetails(combined);
					String attachment = nullableText(row, "ATTACHMENTNAME");
					rows.add(AnnouncementDto.builder().date(truncate(date, 10)).desc(headline).amount(details.amount)
							.tenure(details.tenure).coupon(details.coupon).securityType(details.securityType)
							.market(BSE_OFFSHORE.matcher(combined).find() ? "Offshore" : "Domestic")
							.status("Issued / Active")
							.attachmentUrl(attachment == null ? null : BSE_ATTACHMENT_BASE + attachment).build());
				}
			}
			return AnnouncementsDto.builder().rows(rows).sourceUrl(sourceUrl)
					.note(rows.isEmpty() ? "No bond-related BSE filings." : null).build();
		} catch (Exception e) {
			return AnnouncementsDto.builder().rows(new ArrayList<>()).sourceUrl(sourceUrl)
					.note("BSE fetch failed: " + rootMessage(e)).build();
		}
	}

	private boolean isBondRelevant(String combined, String date) {
		String text = combined.toLowerCase(Locale.ROOT);
		if (EQUITY_PLAN_KEYWORDS.stream().anyMatch(text::contains)) {
			return false;
		}
		if (BOND_KEYWORDS.stream().noneMatch(text::contains)) {
			return false;
		}
		return date != null && date.startsWith(ANNOUNCEMENT_YEAR);
	}

	// ------------------------------------------------------------------
	// Bond detail extraction
	// ------------------------------------------------------------------

	/** Structured bond attributes pulled out of a free-text filing description. */
	private static final class BondDetails {
		private final String amount;
		private final String tenure;
		private final String coupon;
		private final String securityType;

		private BondDetails(String amount, String tenure, String coupon, String securityType) {
			this.amount = amount;
			this.tenure = tenure;
			this.coupon = coupon;
			this.securityType = securityType;
		}
	}

	/** Each field is null when the filing text does not state it. */
	private BondDetails extractBondDetails(String text) {
		String flattened = text.replaceAll("\\s+", " ");

		String amount = null;
		Matcher amountMatcher = AMOUNT.matcher(flattened);
		if (amountMatcher.find()) {
			String unit = amountUnit(amountMatcher.group(2));
			amount = "₹" + indianGrouping(amountMatcher.group(1).replace(",", "")) + " " + unit;
		}

		String tenure = null;
		Matcher tenureMatcher = TENURE.matcher(flattened);
		if (tenureMatcher.find()) {
			tenure = tenureMatcher.group(1) + "Y";
		} else if (PERPETUAL.matcher(flattened).find()) {
			tenure = "Perp";
		}

		String coupon = null;
		Matcher couponMatcher = COUPON_LABELLED.matcher(flattened);
		if (!couponMatcher.find()) {
			couponMatcher = COUPON_ANY.matcher(flattened);
			couponMatcher.find();
		}
		if (couponMatcher.groupCount() >= 1 && couponMatcher.group(1) != null) {
			coupon = String.format(Locale.ROOT, "%.2f%%", Double.parseDouble(couponMatcher.group(1)));
		}

		return new BondDetails(amount, tenure, coupon, securityType(flattened));
	}

	private String amountUnit(String rawUnit) {
		if (CRORE_UNIT.matcher(rawUnit).find()) {
			return "Cr";
		}
		if (LAKH_UNIT.matcher(rawUnit).find()) {
			return "Lakh";
		}
		if (BILLION_UNIT.matcher(rawUnit).find()) {
			return "Bn";
		}
		return "Mn";
	}

	/** Indian digit grouping, e.g. 117000 becomes "1,17,000". */
	private String indianGrouping(String number) {
		NumberFormat format = NumberFormat.getInstance(Locale.forLanguageTag("en-IN"));
		format.setMaximumFractionDigits(3);
		return format.format(Double.parseDouble(number));
	}

	/** Classified most-specific first — an AT-1 mention should not read as plain "Bond". */
	private String securityType(String text) {
		if (AT_ONE.matcher(text).find()) {
			return "AT1 Bond";
		}
		if (TIER_TWO.matcher(text).find()) {
			return "Tier II Bond";
		}
		if (INFRASTRUCTURE.matcher(text).find()) {
			return "Infra Bond";
		}
		if (GREEN_BOND.matcher(text).find()) {
			return "Green Bond";
		}
		if (MASALA.matcher(text).find()) {
			return "Masala Bond";
		}
		if (PERPETUAL.matcher(text).find()) {
			return "Perpetual Bond";
		}
		if (NCD.matcher(text).find()) {
			return "NCD";
		}
		if (DEBENTURE.matcher(text).find()) {
			return "Debenture";
		}
		if (BOND.matcher(text).find()) {
			return "Bond";
		}
		return null;
	}

	// ------------------------------------------------------------------

	private String text(JsonNode node, String field) {
		JsonNode value = node.path(field);
		return value.isMissingNode() || value.isNull() ? "" : value.asText();
	}

	private String nullableText(JsonNode node, String field) {
		JsonNode value = node.path(field);
		return value.isMissingNode() || value.isNull() || value.asText().isEmpty() ? null : value.asText();
	}

	private String firstNonNull(String first, String second) {
		return first == null || first.isEmpty() ? second : first;
	}

	private String truncate(String value, int max) {
		if (value == null) {
			return null;
		}
		return value.length() <= max ? value : value.substring(0, max);
	}

	private String ddMmmyyyy(LocalDate date) {
		return String.format(Locale.ROOT, "%02d/%02d/%04d", date.getDayOfMonth(), date.getMonthValue(),
				date.getYear());
	}

	private String urlEncode(String value) {
		return java.net.URLEncoder.encode(value, java.nio.charset.StandardCharsets.UTF_8);
	}

	private String rootMessage(Throwable throwable) {
		Throwable cause = throwable;
		while (cause.getCause() != null) {
			cause = cause.getCause();
		}
		return cause.getMessage() == null ? cause.toString() : cause.getMessage();
	}

	private static final class TenorRates {
		private final String tenor;
		private final List<Double> rates;

		private TenorRates(String tenor, List<Double> rates) {
			this.tenor = tenor;
			this.rates = rates;
		}
	}
}
