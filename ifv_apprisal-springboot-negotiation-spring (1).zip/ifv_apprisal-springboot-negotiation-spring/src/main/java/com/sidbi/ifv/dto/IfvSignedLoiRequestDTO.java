package com.sidbi.ifv.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class IfvSignedLoiRequestDTO {

	@Min(value = 0, message = "Page number must be 0 or greater")
	private int page = 0;

	@Min(value = 1, message = "Size must be at least 1")
	@Max(value = 100, message = "Size must not exceed 100")
	private int size = 10;

	private String ifvAppNo;

	private String uploadedBy;

	private String bankRefNo;

	private String bankName;

	private String cifNumber;

	private String scheme;

	private String loiNo;

	private String fileName;

	private String status;

	@Pattern(regexp = "^[a-zA-Z0-9 .,_\\-/]{0,255}$", message = "Global filter contains invalid characters")
	private String globalFilter;

	private LocalDate uploadedDateFrom;
	private LocalDate uploadedDateTo;
	private LocalDate sanctionedDateFrom;
	private LocalDate sanctionedDateTo;

	@Pattern(regexp = "^(id|loiNo|bankRefNo|scheme|sanctionedDateTime|sanctionAmount|status|uploadedDate|fileName)?$", message = "Invalid sort field")
	private String sortField;

	@Pattern(regexp = "^(asc|desc)$", flags = Pattern.Flag.CASE_INSENSITIVE, message = "sortDirection must be asc or desc")
	private String sortDirection;

	@JsonIgnore
	@AssertTrue(message = "Each date range 'from' must be on or before 'to'")
	public boolean isDateRangesValid() {
		return ok(uploadedDateFrom, uploadedDateTo) && ok(sanctionedDateFrom, sanctionedDateTo);
	}

	private static boolean ok(LocalDate f, LocalDate t) {
		return f == null || t == null || !f.isAfter(t);
	}
}