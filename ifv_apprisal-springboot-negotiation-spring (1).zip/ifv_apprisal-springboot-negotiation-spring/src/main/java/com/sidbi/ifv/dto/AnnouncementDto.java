package com.sidbi.ifv.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A bond issuance announcement (live-scraped from NSE/BSE or curated).
 * <p>
 * {@code rating} is the rating of this specific issue and may differ from the
 * issuer rating; it is omitted from the JSON when unknown.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AnnouncementDto {

	private String date;

	private String desc;

	private String amount;

	private String tenure;

	private String coupon;

	private String securityType;

	private String market;

	private String status;

	private String attachmentUrl;

	private String rating;
}
