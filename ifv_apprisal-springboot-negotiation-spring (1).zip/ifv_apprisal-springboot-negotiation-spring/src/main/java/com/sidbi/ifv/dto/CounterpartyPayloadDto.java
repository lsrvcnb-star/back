package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Full response body of {@code GET /api/public/counterparty}.
 * Every field name is part of the public contract consumed by the IFV
 * negotiation dashboard and must not be renamed.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounterpartyPayloadDto {

	private String fetchedAt;

	private String bankId;

	private String bankRating;

	private DepositsDto deposits;

	private AnnouncementsDto announcements;

	/** True when the payload was served from the in-memory TTL cache. */
	private Boolean cached;
}
