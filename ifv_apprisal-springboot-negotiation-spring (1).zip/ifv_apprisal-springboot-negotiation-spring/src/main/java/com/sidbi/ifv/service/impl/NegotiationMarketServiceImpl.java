package com.sidbi.ifv.service.impl;

import java.io.ByteArrayInputStream;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.dto.MarketSnapshotDto;
import com.sidbi.ifv.dto.RatePointDto;
import com.sidbi.ifv.services.NegotiationMarketService;
import com.sidbi.ifv.util.NegotiationHttpUtil;
import com.sidbi.ifv.util.NegotiationTtlCache;

/**
 * Scrapes policy and benchmark rates for the negotiation pricing dashboard.
 * <p>
 * Sources, all official:
 * <ul>
 * <li>RBI homepage — Policy Repo, Reverse Repo, SDF, MSF, Bank Rate, and the
 * Government Securities Market table (10Y G-Sec, 91-day T-Bill cut-off)</li>
 * <li>FBIL public JSON APIs — T-Bill (3M) and CD (12M) benchmark rates</li>
 * <li>FBIL par-yield workbook — 10-year G-Sec, used only as an RBI fallback</li>
 * </ul>
 * FBIL publishes no Commercial Paper benchmark, so {@code cp1y} is always null.
 * <p>
 * Every source is best-effort and fetched concurrently: an unreachable upstream
 * downgrades a single rate to null and adds a note rather than failing the request.
 */
@Service
public class NegotiationMarketServiceImpl implements NegotiationMarketService {

	private static final Logger logger = LoggerFactory.getLogger(NegotiationMarketServiceImpl.class);

	private static final String CACHE_KEY = "market";

	@Value("${negotiation.market.cache-ttl-minutes:30}")
	private long cacheTtlMinutes;

	private static final String RBI_URL = "https://www.rbi.org.in/";
	private static final String FBIL_TENOR_URL = "https://www.fbil.org.in/wasdm/%s/fetch?authenticated=false";
	private static final String FBIL_GSEC_LIST_URL = "https://www.fbil.org.in/wasdm/gsec/fetch?authenticated=false";
	private static final String FBIL_GSEC_DOWNLOAD_URL = "https://www.fbil.org.in/wasdm/gsec/downloadPublished?authenticated=false&date=%s";
	private static final String PAR_YIELD_SHEET = "Par Yield";
	private static final int TENOR_YEARS = 10;

	/** e.g. "6.50% GS 2035 ... : 6.72 %" — group 2 is the maturity year, group 3 the yield. */
	private static final Pattern GSEC_ROW = Pattern
			.compile("([0-9]+\\.[0-9]+)%\\s*GS\\s*(\\d{4})[\\s\\S]{0,120}?:\\s*([0-9]+\\.[0-9]+)\\s*%");

	private static final Pattern TBILL_91_DAY = Pattern
			.compile("91\\s*day\\s*T-?bills[\\s\\S]{0,400}?([0-9]+\\.[0-9]+)\\s*%", Pattern.CASE_INSENSITIVE);

	private static final Pattern RATE_AFTER_LABEL = Pattern
			.compile("[\\s\\S]{0,300}?([0-9]+\\.[0-9]+)\\s*%");

	@Autowired
	private NegotiationHttpUtil httpUtil;

	@Autowired
	private NegotiationTtlCache cache;

	@Autowired
	private ObjectMapper objectMapper;

	@Override
	public MarketSnapshotDto getSnapshot(boolean forceRefresh) {
		if (!forceRefresh) {
			MarketSnapshotDto cached = cache.get(CACHE_KEY, Duration.ofMinutes(cacheTtlMinutes));
			if (cached != null) {
				cached.setCached(true);
				return cached;
			}
		}
		MarketSnapshotDto snapshot = buildSnapshot();
		cache.put(CACHE_KEY, snapshot);
		snapshot.setCached(false);
		return snapshot;
	}

	private MarketSnapshotDto buildSnapshot() {
		List<String> notes = new ArrayList<>();
		MarketSnapshotDto snapshot = new MarketSnapshotDto();
		snapshot.setFetchedAt(OffsetDateTime.now().toString());
		snapshot.setNotes(notes);
		seed(snapshot);

		CompletableFuture<Map<String, RatePointDto>> rbi = CompletableFuture.supplyAsync(this::scrapeRbi);
		CompletableFuture<List<FbilTenorRow>> tbill = CompletableFuture
				.supplyAsync(() -> fetchFbilTenorRates("tbill"));
		CompletableFuture<List<FbilTenorRow>> cd = CompletableFuture.supplyAsync(() -> fetchFbilTenorRates("cd"));
		CompletableFuture<RatePointDto> gsec = CompletableFuture.supplyAsync(this::fetchFbilGsec10Y);

		applyRbi(snapshot, notes, rbi);

		// The RBI GSM table is authoritative for G-Sec and T-Bill; FBIL only fills gaps.
		applyTbill(snapshot, notes, tbill);
		applyCd(snapshot, notes, cd);
		applyGsec(snapshot, notes, gsec);

		notes.add("CP: FBIL does not publish a Commercial Paper benchmark; add a manual override if needed.");
		return snapshot;
	}

	private void seed(MarketSnapshotDto snapshot) {
		snapshot.setRepo(nullPoint());
		snapshot.setReverseRepo(nullPoint());
		snapshot.setSdf(nullPoint());
		snapshot.setMsf(nullPoint());
		snapshot.setBankRate(nullPoint());
		snapshot.setGsec10(nullPoint());
		snapshot.setTbill3m(nullPoint());
		snapshot.setCd1y(nullPoint());
		snapshot.setCp1y(nullPoint());
	}

	private void applyRbi(MarketSnapshotDto snapshot, List<String> notes, CompletableFuture<Map<String, RatePointDto>> rbi) {
		try {
			Map<String, RatePointDto> rates = rbi.join();
			snapshot.setRepo(rates.get("repo"));
			snapshot.setReverseRepo(rates.get("reverseRepo"));
			snapshot.setSdf(rates.get("sdf"));
			snapshot.setMsf(rates.get("msf"));
			snapshot.setBankRate(rates.get("bankRate"));
			snapshot.setGsec10(rates.get("gsec10"));
			snapshot.setTbill3m(rates.get("tbill3m"));
			notes.add("Policy rates: rbi.org.in (official).");
		} catch (Exception e) {
			notes.add("RBI fetch failed: " + rootMessage(e));
		}
	}

	private void applyTbill(MarketSnapshotDto snapshot, List<String> notes,
			CompletableFuture<List<FbilTenorRow>> tbill) {
		if (snapshot.getTbill3m().getValue() != null) {
			notes.add("T-Bill 3M: RBI GSM (91-day cut-off).");
			return;
		}
		try {
			RatePointDto point = pickTenor(tbill.join(), "3 Months");
			if (point.getValue() != null) {
				snapshot.setTbill3m(point);
				notes.add("T-Bill 3M: FBIL (fbil.org.in).");
			}
		} catch (Exception e) {
			logger.debug("FBIL T-Bill fetch failed: {}", rootMessage(e));
		}
	}

	private void applyCd(MarketSnapshotDto snapshot, List<String> notes, CompletableFuture<List<FbilTenorRow>> cd) {
		try {
			RatePointDto point = pickTenor(cd.join(), "12 Months");
			if (point.getValue() != null) {
				snapshot.setCd1y(point);
				notes.add("CD 1Y: FBIL (fbil.org.in).");
			}
		} catch (Exception e) {
			logger.debug("FBIL CD fetch failed: {}", rootMessage(e));
		}
	}

	private void applyGsec(MarketSnapshotDto snapshot, List<String> notes, CompletableFuture<RatePointDto> gsec) {
		if (snapshot.getGsec10().getValue() != null) {
			notes.add("10Y G-Sec: " + snapshot.getGsec10().getSource() + ".");
			return;
		}
		try {
			RatePointDto point = gsec.join();
			if (point.getValue() != null) {
				snapshot.setGsec10(point);
				notes.add("10Y G-Sec: FBIL Par Yield (fbil.org.in).");
			}
		} catch (Exception e) {
			notes.add("G-Sec fetch failed: " + rootMessage(e));
		}
	}

	// ------------------------------------------------------------------
	// RBI homepage
	// ------------------------------------------------------------------

	private Map<String, RatePointDto> scrapeRbi() {
		String html = httpUtil.getTextOrThrow(RBI_URL,
				NegotiationHttpUtil.headers("Accept", "text/html,application/xhtml+xml"));
		if (html == null || html.isEmpty()) {
			throw new IllegalStateException("RBI returned an empty document");
		}
		Map<String, RatePointDto> rates = new LinkedHashMap<>();
		rates.put("repo", grab(html, "Policy Repo Rate"));
		rates.put("reverseRepo", grab(html, "Reverse Repo Rate"));
		rates.put("sdf", grab(html, "Standing Deposit"));
		rates.put("msf", grab(html, "Marginal Standing"));
		rates.put("bankRate", grab(html, "Bank Rate"));
		rates.put("gsec10", pickGsec10(html));
		rates.put("tbill3m", pickTbill3m(html));
		return rates;
	}

	/** Finds the first percentage appearing within 300 chars after a labelled rate. */
	private RatePointDto grab(String html, String label) {
		Pattern pattern = Pattern.compile(label.replace(" ", "\\s+") + RATE_AFTER_LABEL.pattern());
		Matcher matcher = pattern.matcher(html);
		if (matcher.find()) {
			return RatePointDto.builder().value(Double.parseDouble(matcher.group(1))).source("RBI").build();
		}
		return nullPoint();
	}

	/** Picks the GSM row whose maturity year is nearest to today + 10 years. */
	private RatePointDto pickGsec10(String html) {
		int targetYear = OffsetDateTime.now().getYear() + TENOR_YEARS;
		Integer bestYear = null;
		Double bestYtm = null;
		Matcher matcher = GSEC_ROW.matcher(html);
		while (matcher.find()) {
			int year = Integer.parseInt(matcher.group(2));
			double ytm = Double.parseDouble(matcher.group(3));
			if (bestYear == null || Math.abs(year - targetYear) < Math.abs(bestYear - targetYear)) {
				bestYear = year;
				bestYtm = ytm;
			}
		}
		return bestYear == null ? nullPoint()
				: RatePointDto.builder().value(bestYtm).source("RBI (GS " + bestYear + ")").build();
	}

	private RatePointDto pickTbill3m(String html) {
		Matcher matcher = TBILL_91_DAY.matcher(html);
		if (matcher.find()) {
			return RatePointDto.builder().value(Double.parseDouble(matcher.group(1)))
					.source("RBI (91-day T-Bill cut-off)").build();
		}
		return nullPoint();
	}

	// ------------------------------------------------------------------
	// FBIL
	// ------------------------------------------------------------------

	private List<FbilTenorRow> fetchFbilTenorRates(String kind) {
		String body = httpUtil.tryGetText(String.format(FBIL_TENOR_URL, kind),
				NegotiationHttpUtil.headers("Accept", "application/json"));
		if (body == null) {
			return null;
		}
		try {
			JsonNode node = objectMapper.readTree(body);
			if (!node.isArray()) {
				return null;
			}
			List<FbilTenorRow> rows = new ArrayList<>();
			for (JsonNode row : node) {
				rows.add(new FbilTenorRow(row.path("tenorName").asText(null), row.path("rate").asDouble(Double.NaN),
						row.path("processRunDate").asText(null)));
			}
			return rows;
		} catch (Exception e) {
			logger.debug("FBIL {} payload not parseable: {}", kind, rootMessage(e));
			return null;
		}
	}

	/** FBIL rows carry several report dates; the latest one is first. */
	private RatePointDto pickTenor(List<FbilTenorRow> rows, String tenor) {
		if (rows == null || rows.isEmpty()) {
			return nullPoint();
		}
		String latestDate = rows.get(0).getProcessRunDate();
		for (FbilTenorRow row : rows) {
			boolean sameReportDate = Objects.equals(latestDate, row.getProcessRunDate());
			boolean sameTenor = row.getTenorName() != null
					&& row.getTenorName().trim().toLowerCase(Locale.ROOT).equals(tenor.toLowerCase(Locale.ROOT));
			if (sameReportDate && sameTenor && !Double.isNaN(row.getRate())) {
				return RatePointDto.builder().value(row.getRate()).source("FBIL").build();
			}
		}
		return nullPoint();
	}

	/**
	 * Downloads the latest FBIL par-yield workbook and reads the 10-year tenor.
	 * Falls back to the semi-annual column when the annualised column is blank.
	 */
	private RatePointDto fetchFbilGsec10Y() {
		String listing = httpUtil.tryGetText(FBIL_GSEC_LIST_URL,
				NegotiationHttpUtil.headers("Accept", "application/json"));
		if (listing == null) {
			return nullPoint();
		}
		String date = latestPublishedDate(listing);
		if (date == null) {
			return nullPoint();
		}
		byte[] workbook = httpUtil.tryGetBytes(String.format(FBIL_GSEC_DOWNLOAD_URL, date), null);
		if (workbook == null || workbook.length == 0) {
			return nullPoint();
		}
		return readParYield(workbook);
	}

	private String latestPublishedDate(String listing) {
		try {
			JsonNode node = objectMapper.readTree(listing);
			if (!node.isArray() || node.isEmpty()) {
				return null;
			}
			String runDate = node.get(0).path("processRunDate").asText(null);
			return (runDate == null || runDate.length() < 10) ? null : runDate.substring(0, 10);
		} catch (Exception e) {
			logger.debug("FBIL G-Sec listing not parseable: {}", rootMessage(e));
			return null;
		}
	}

	private RatePointDto readParYield(byte[] workbookBytes) {
		try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(workbookBytes))) {
			Sheet sheet = workbook.getSheet(PAR_YIELD_SHEET);
			if (sheet == null) {
				return nullPoint();
			}
			for (Row row : sheet) {
				Double tenor = numeric(row.getCell(0));
				if (tenor == null || tenor.intValue() != TENOR_YEARS) {
					continue;
				}
				Double annualised = numeric(row.getCell(2));
				if (annualised != null) {
					return RatePointDto.builder().value(annualised).source("FBIL").build();
				}
				Double semiAnnual = numeric(row.getCell(1));
				if (semiAnnual != null) {
					return RatePointDto.builder().value(semiAnnual).source("FBIL").build();
				}
			}
		} catch (Exception e) {
			logger.debug("FBIL par-yield workbook not parseable: {}", rootMessage(e));
		}
		return nullPoint();
	}

	private Double numeric(Cell cell) {
		return (cell != null && cell.getCellType() == CellType.NUMERIC) ? cell.getNumericCellValue() : null;
	}

	// ------------------------------------------------------------------

	private RatePointDto nullPoint() {
		return RatePointDto.builder().value(null).source(null).build();
	}

	private String rootMessage(Throwable throwable) {
		Throwable cause = throwable;
		while (cause.getCause() != null) {
			cause = cause.getCause();
		}
		return cause.getMessage() == null ? cause.toString() : cause.getMessage();
	}

	private static final class FbilTenorRow {
		private final String tenorName;
		private final double rate;
		private final String processRunDate;

		private FbilTenorRow(String tenorName, double rate, String processRunDate) {
			this.tenorName = tenorName;
			this.rate = rate;
			this.processRunDate = processRunDate;
		}

		private String getTenorName() {
			return tenorName;
		}

		private double getRate() {
			return rate;
		}

		private String getProcessRunDate() {
			return processRunDate;
		}
	}
}
