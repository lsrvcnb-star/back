package com.sidbi.ifv.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Bulk-deposit rate card block of the counterparty payload.
 * {@code rows} is null when the bank's rate card could not be parsed.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DepositsDto {

	private List<DepositRowDto> rows;

	private String sourceUrl;

	private String asOf;

	private String note;

	/** True when the rows are fallback sample data rather than a live scrape. */
	private Boolean illustrative;

	private Boolean hasAmountBuckets;
}
