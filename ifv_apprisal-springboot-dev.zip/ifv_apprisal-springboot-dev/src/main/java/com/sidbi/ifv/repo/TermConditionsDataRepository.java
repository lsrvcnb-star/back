package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.sidbi.ifv.entity.S2IFVTermConditionsDataEntity;

public interface TermConditionsDataRepository extends JpaRepository<S2IFVTermConditionsDataEntity, Long> {

	S2IFVTermConditionsDataEntity findByIfvId(Long ifvId);

	List<S2IFVTermConditionsDataEntity> findAllByIfvId(Long ifvId);
	
	@Modifying
	@Query(value = "UPDATE S2_IFV_TERMCONDITIONS_DATA set TS_RECOMMENDATION = :recommendation  WHERE IFV_ID = :ifvId ", nativeQuery = true)
	void updateRecommendation(String recommendation,Long ifvId);
	
}
