package com.sidbi.ifv.services;

import java.util.List;

import org.springframework.data.domain.Page;

import com.sidbi.ifv.dto.AlcoProposalDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;

public interface AlcoProposalService {

	List<AlcoProposalDTO> findAll();

	AlcoProposalDTO findById(Long id);

	AlcoProposalDTO save(AlcoProposalDTO alcoProposalDTO);

	AlcoProposalDTO update(Long id, AlcoProposalDTO alcoProposalDTO);

	void delete(Long id);

	List<AlcoProposalDTO> saveAll(List<AlcoProposalDTO> alcoProposalDTOs);

	TblIfvModuleFwdDTO updateDocument(String status, AlcoProposalDTO alcoProposalDTO);

	List<AlcoProposalDTO> getAlcoProposalsOnUserType(String userType);

	List<AlcoProposalDTO> findAllByAlCodeIn(List<Long> alCodes);

	List<AlcoProposalDTO> getAlcoReportData();

	Page<AlcoProposalDTO> getAlcoReportDataOnPage(int page, int size, String filters, String sorting,
			String globalFilter);

}
