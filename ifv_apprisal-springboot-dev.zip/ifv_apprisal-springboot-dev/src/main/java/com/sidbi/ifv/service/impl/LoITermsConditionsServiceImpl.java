package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.LoITermsConditionsDTO;
import com.sidbi.ifv.entity.LoITermsConditionsEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.LoITermsConditionsRepository;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.services.LoITermsConditionsService;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.NumberToWordsInCrores;

@Service
public class LoITermsConditionsServiceImpl implements LoITermsConditionsService {

	private static final Logger logger = LoggerFactory.getLogger(LoITermsConditionsServiceImpl.class);

	@Autowired
	private LoITermsConditionsRepository repository;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CommonUtil commonUtil;

	String msg = "";

	@Override
	public LoITermsConditionsDTO findById(Long id) {
		logger.info("findById() started in LoITermsConditionsServiceImpl for LoITermsConditionsEntity {} ", id);
		LoITermsConditionsEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("LOITermsConditionsEntity", id));
		return mapper.map(entity, LoITermsConditionsDTO.class);
	}

	@Override
	public List<LoITermsConditionsDTO> findAll() {
		logger.info("findAll() started in LoITermsConditionsServiceImpl of LoITermsConditionsEntity");
		try {
			List<LoITermsConditionsEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, LoITermsConditionsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all LoITermsConditionsEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all LoITermsConditionsEntities ." + msg + " ", e);
		}
	}

	@Override
	public LoITermsConditionsDTO save(LoITermsConditionsDTO dto) {
		logger.info("save() started in LoITermsConditionsServiceImpl for LoITermsConditionsEntity {} ", dto);
		try {
			LoITermsConditionsEntity entity = mapper.map(dto, LoITermsConditionsEntity.class);
			S2IFVProposedSchemaEntity entity2 = proposedSchemaRepository.findByPrId(entity.getPrId());
			entity.setFundCode(entity2.getPrFundcode());
			entity.setSchemeCode(entity2.getPrSchemecode());
			entity.setAmountInWords(NumberToWordsInCrores.numberToWordsInCrores(dto.getAmount()));
			repository.save(entity);
			return mapper.map(entity, LoITermsConditionsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating LoITermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  LoITermsConditionsEntity." + msg + " ",
					e);
		}
	}

	@Override
	public List<LoITermsConditionsDTO> saveAll(List<LoITermsConditionsDTO> dtos) {
		logger.info("saveAll() started in LoITermsConditionsServiceImpl for List of LoITermsConditionsEntity");
		try {

			List<LoITermsConditionsEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, LoITermsConditionsEntity.class)).collect(Collectors.toList());
			List<LoITermsConditionsEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, LoITermsConditionsDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all LoITermsConditionsEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all LoITermsConditionsEntities." + msg + " ", e);
		}
	}

	@Override
	public LoITermsConditionsDTO update(Long id, LoITermsConditionsDTO dto) {
		logger.info("update() started in LoITermsConditionsServiceImpl for LoITermsConditionsEntity {} {} ", id, dto);
		try {
			LoITermsConditionsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("LoITermsConditionsEntity", id));
			BeanUtils.copyProperties(dto, existingEntity, commonUtil.getNullPropertyNames(dto));
			repository.save(existingEntity);
			return mapper.map(existingEntity, LoITermsConditionsDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating LoITermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating LoITermsConditionsEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in LoITermsConditionsServiceImpl for LoITermsConditionsEntity {} ", id);
		try {
			LoITermsConditionsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("LoITermsConditionsEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting LoITermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting LoITermsConditionsEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<LoITermsConditionsDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in LoITermsConditionsServiceImpl for LoITermsConditionsEntity {} ",
				ifvId);
		try {

			List<LoITermsConditionsEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty()) ? list.stream()
					.map(restructuredAssetsEntity -> mapper.map(restructuredAssetsEntity, LoITermsConditionsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId LoITermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId LoITermsConditionsEntity of id ." + msg + " " + ifvId, e);
		}
	}

	@Override
	public List<LoITermsConditionsDTO> findAllByIfvIdAndPrId(Long ifvId, Long prId) {
		logger.info("findAllByIfvIdAndPrId() started in LoITermsConditionsServiceImpl for LoITermsConditionsDTO {} ",
				ifvId);
		try {

			List<LoITermsConditionsEntity> list = repository.findAllByIfvIdAndPrId(ifvId, prId);
			return (list != null && !list.isEmpty()) ? list.stream()
					.map(restructuredAssetsEntity -> mapper.map(restructuredAssetsEntity, LoITermsConditionsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while findAllByIfvIdAndPrId LoITermsConditionsEntity of ifvId and prId . {} {} {} ",
					msg, ifvId, prId);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvIdAndPrId LoITermsConditionsEntity of ifvId and prId ." + msg
							+ " " + ifvId + " " + prId + " ",
					e);
		}
	}

	@Override
	public LoITermsConditionsDTO findByIfvIdAndPrId(Long ifvId, Long prId) {
		logger.info("findAllByIfvIdAndPrId() started in LoITermsConditionsServiceImpl for LoITermsConditionsDTO {} ",
				ifvId);
		try {

			LoITermsConditionsEntity entity = repository.findByIfvIdAndPrId(ifvId, prId);
			if (entity == null)
				entity = new LoITermsConditionsEntity();
			return mapper.map(entity, LoITermsConditionsDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while findByIfvIdAndPrId LoITermsConditionsEntity of ifvId and prId . {} {} {} ",
					msg, ifvId, prId);
			throw new DatabaseOperationException(
					"Error Occurred while findByIfvIdAndPrId LoITermsConditionsDTO of ifvId and prId ." + msg + " "
							+ ifvId + " " + prId + " ",
					e);
		}
	}

	@Override
	public List<LoITermsConditionsDTO> findByloiId(Long loiId) {
		logger.info("findAllByIfvIdAndPrId() started in LoITermsConditionsServiceImpl for LoITermsConditionsEntity {} ",
				loiId);
		try {

			List<LoITermsConditionsEntity> list = repository.findByloiId(loiId);

			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, LoITermsConditionsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findByIfvIdAndPrId LoITermsConditionsDTO of ifvId and prId: {} {} ",
					msg, loiId);
			throw new DatabaseOperationException(
					"Error Occurred while findByIfvIdAndPrId LoITermsConditionsEntity of ifvId and prId ." + msg + " "
							+ loiId,
					e);
		}
	}

	@Override
	public LoITermsConditionsDTO findByloiIdAndPrId(Long loiId, Long prId) {
		logger.info("findAllByIfvIdAndPrId() started in LoITermsConditionsServiceImpl for LoITermsConditionsEntity {} ",
				loiId);
		try {

			LoITermsConditionsEntity entity = repository.findByloiIdAndPrId(loiId, prId);
			if (entity == null)
				entity = new LoITermsConditionsEntity();
			return mapper.map(entity, LoITermsConditionsDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while findByIfvIdAndPrId LoITermsConditionsEntity of ifvId and prId . {} {} {} ",
					msg, loiId, prId);
			throw new DatabaseOperationException(
					"Error Occurred while findByIfvIdAndPrId LoITermsConditionsEntity of ifvId and prId ." + msg + " "
							+ loiId + " " + prId + " ",
					e);
		}
	}

}
