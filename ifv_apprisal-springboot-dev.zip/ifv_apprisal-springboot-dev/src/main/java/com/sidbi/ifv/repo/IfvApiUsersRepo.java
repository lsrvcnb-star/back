package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sidbi.ifv.entity.IfvApiUsersEntity;

public interface IfvApiUsersRepo extends JpaRepository<IfvApiUsersEntity, Integer> {

	IfvApiUsersEntity findByOfrUserId(String username);

	IfvApiUsersEntity findByOfrEmpId(String empId);

	IfvApiUsersEntity findByOfrUserIdAndOfrUserActive(String username, String isActive);

	List<IfvApiUsersEntity> findAllByOfrEmpIdIn(List<String> empIds);

	@Query(value = "SELECT distinct * FROM tbl_ifv_login WHERE ofr_code IN (:officerCode)", nativeQuery = true)
	List<IfvApiUsersEntity> findByOfficerCode(List<Long> officerCode);

	List<IfvApiUsersEntity> findAllByOfrType(String ofrType);

	List<IfvApiUsersEntity> findAllByOfrTypeIn(List<String> ofrTypes);

	IfvApiUsersEntity findByOfrCode(Integer ofrCode);

	List<IfvApiUsersEntity> findAllByOfrCodeIn(List<Integer> ofrCode);

}
