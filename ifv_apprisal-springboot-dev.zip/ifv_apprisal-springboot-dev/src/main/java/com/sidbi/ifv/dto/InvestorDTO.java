package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class InvestorDTO {

	private Long kiId;

	private Long ifvId;

	private String kiHolder;

	private BigDecimal kiCount;

	private BigDecimal kiHolding;

	private BigDecimal kiPproportion;

	private String kiType;

}
