package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.SanctionTermsConditionsEntity;

public interface SanctionTermsConditionsRepository extends JpaRepository<SanctionTermsConditionsEntity, Long> {

	List<SanctionTermsConditionsEntity> findByIfvId(Long ifvId);
	
	List<SanctionTermsConditionsEntity> findAllByIfvIdAndPrId(Long ifvId, Long prId);

	SanctionTermsConditionsEntity findByIfvIdAndPrId(Long ifvId, Long prId);
	
	void deleteByPrId(Long prId);

}