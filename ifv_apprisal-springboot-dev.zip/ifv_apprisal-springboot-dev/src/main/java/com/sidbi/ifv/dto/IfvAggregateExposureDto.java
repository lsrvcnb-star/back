package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IfvAggregateExposureDto {

	private Long id;
	private Long ifvId;
	private BigDecimal capitalFunds;
	private Integer slNo;
	private String particulars;
	private BigDecimal amount;
	private String groupName;
	private LocalDateTime createdAt;
	private LocalDateTime updatedAt;
}
