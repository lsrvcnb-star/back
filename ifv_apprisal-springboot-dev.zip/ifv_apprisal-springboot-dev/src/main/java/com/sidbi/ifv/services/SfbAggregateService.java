package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.SfbAggregateDTO;

public interface SfbAggregateService {

	List<SfbAggregateDTO> findAll();

	SfbAggregateDTO findById(Long id);

	SfbAggregateDTO save(SfbAggregateDTO s2ifccSfbAggregateDTO);

	SfbAggregateDTO update(Long id, SfbAggregateDTO s2ifccSfbAggregateDTO);
	
	void delete(Long id);
}
