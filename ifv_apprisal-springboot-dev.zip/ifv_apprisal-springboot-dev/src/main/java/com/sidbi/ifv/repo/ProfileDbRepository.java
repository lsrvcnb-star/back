package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVProfileBdEntity;

public interface ProfileDbRepository extends JpaRepository<S2IFVProfileBdEntity, Long> {

	List<S2IFVProfileBdEntity> findByIfvId(Long ifvId);
}
