package com.sidbi.ifv.service.impl;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.ChiefBoardDTO;
import com.sidbi.ifv.entity.S2IFVChiefBoardEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.ChiefBoardRepository;
import com.sidbi.ifv.services.ChiefBoardService;

@Service
public class ChiefBoardServiceImpl implements ChiefBoardService {

	private static final Logger logger = LoggerFactory.getLogger(ChiefBoardServiceImpl.class);

	@Autowired
	private ChiefBoardRepository s2ifccChiefBoardRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<ChiefBoardDTO> findAll() {
		logger.info("findAll() started in ChiefBoardServiceImpl for S2IFCCChiefBoardDTO");
		try {
			List<S2IFVChiefBoardEntity> list = s2ifccChiefBoardRepository.findAll();
			return list.stream().map(ifccsfbcommon -> modelMapper.map(ifccsfbcommon, ChiefBoardDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVChiefBoardEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVChiefBoardEntities." + msg + " ", e);
		}
	}

	@Override
	public ChiefBoardDTO findById(Long id) {
		logger.info("findById() started in ChiefBoardServiceImpl for S2IFVChiefBoardEntity {} ", id);
		try {
			S2IFVChiefBoardEntity s2ifccChiefBoardEntity = s2ifccChiefBoardRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVChiefBoardEntity", id));
			return modelMapper.map(s2ifccChiefBoardEntity, ChiefBoardDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFVChiefBoardEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while fetching  S2IFVChiefBoardEntity." + msg + " ",
					e);
		}
	}

	@Override
	public ChiefBoardDTO save(ChiefBoardDTO s2ifccChiefBoardDTO) {
		logger.info("save() started in ChiefBoardServiceImpl for S2IFVChiefBoardEntity {} ", s2ifccChiefBoardDTO);
		try {
			S2IFVChiefBoardEntity s2ifccChiefBoardEntity = modelMapper.map(s2ifccChiefBoardDTO,
					S2IFVChiefBoardEntity.class);
			s2ifccChiefBoardRepository.save(s2ifccChiefBoardEntity);
			return modelMapper.map(s2ifccChiefBoardEntity, ChiefBoardDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVChiefBoardEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVChiefBoardEntity." + msg + " ",
					e);
		}
	}

	@Override
	public ChiefBoardDTO update(Long id, ChiefBoardDTO s2ifccChiefBoardDTO) {
		logger.info("update() started in ChiefBoardServiceImpl for S2IFVChiefBoardEntity {} {} ", id,
				s2ifccChiefBoardDTO);
		try {
			S2IFVChiefBoardEntity existingS2ifccChiefBoardEntity = s2ifccChiefBoardRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVChiefBoardEntity", id));
			BeanUtils.copyProperties(s2ifccChiefBoardDTO, existingS2ifccChiefBoardEntity);
			s2ifccChiefBoardRepository.save(existingS2ifccChiefBoardEntity);
			return modelMapper.map(existingS2ifccChiefBoardEntity, ChiefBoardDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVChiefBoardEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVChiefBoardEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in ChiefBoardServiceImpl for S2IFVChiefBoardEntity {} ", id);
		try {
			S2IFVChiefBoardEntity existingS2ifccChiefBoardEntity = s2ifccChiefBoardRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVChiefBoardEntity", id));
			s2ifccChiefBoardRepository.delete(existingS2ifccChiefBoardEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVChiefBoardEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVChiefBoardEntity of id." + id + " " + msg + " ", e);
		}

	}

	@Override
	public List<ChiefBoardDTO> saveAll(List<ChiefBoardDTO> listChiefBoardDTO) {
		logger.info("saveAll() started in ChiefBoardServiceImpl for List of S2IFVChiefBoardEntity");
		try {
			List<S2IFVChiefBoardEntity> chiefBoardEntitiesToSave = listChiefBoardDTO.stream()
					.map(chiefBoardDTO -> modelMapper.map(chiefBoardDTO, S2IFVChiefBoardEntity.class))
					.collect(Collectors.toList());
			List<S2IFVChiefBoardEntity> savedChiefBoardEntities = s2ifccChiefBoardRepository
					.saveAll(chiefBoardEntitiesToSave);

			return savedChiefBoardEntities.stream()
					.map(chiefBoardEntity -> modelMapper.map(chiefBoardEntity, ChiefBoardDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVChiefBoardEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all S2IFVChiefBoardEntities." + msg + " ",
					e);

		}
	}

	@Override
	public List<ChiefBoardDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in ChiefBoardServiceImpl ");
		try {
			List<S2IFVChiefBoardEntity> listChiefBoardEntities = s2ifccChiefBoardRepository.findByIfvId(ifvId);
			return listChiefBoardEntities.stream().sorted(Comparator.comparing(S2IFVChiefBoardEntity::getCbId))
					.map(chiefBoardEntity -> modelMapper.map(chiefBoardEntity, ChiefBoardDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVChiefBoardEntities based on IfvId. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVChiefBoardEntities based on IfvId." + msg + " ", e);

		}
	}

}
