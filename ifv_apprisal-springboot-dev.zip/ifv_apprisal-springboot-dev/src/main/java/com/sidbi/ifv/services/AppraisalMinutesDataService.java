package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;

public interface AppraisalMinutesDataService extends CrudService<AppraisalMinutesDataDTO, Long> {

	Boolean saveAllAppraisalMinutesData(List<AppraisalMinutesDataDTO> data);

	List<AppraisalMinutesDataDTO> getAllAppraisalMinutesDataBySancDtlCode(Long sancDtlCode);

	List<AppraisalMinutesDataDTO> getAllAppraisalMinutesDataByAgendaIdAndAppId(String agendaId, String appId);

	AppraisalMinutesDataDTO findBySancDtlCodeAppIdPrId(Long sancDtlCode, String appId, Long prId);

	List<AppraisalMinutesDataDTO> findByAgendaId(String agendaId);

}
