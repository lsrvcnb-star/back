package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_RATING_REPOSITORY")
public class S2IFVRatingRepositoryEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "rt_code")
	private Long rtCode;
	
	@Column(name = "ifv_id")
	private Long ifvId;
	
	@Column(name = "rt_type")
	private String rtType;
	
	@Column(name = "rt_particulars1")
	private String rtParticulars1;
	
	@Column(name = "rt_remarks")
	private String rtRemarks;
	
	@Column(name = "rt_order")
	private String rtOrder;
	
	@Column(name = "rt_flg")
	private String rtFlg;
	
	@Column(name = "date_of_action")
	private Date dateOfAction;

}
