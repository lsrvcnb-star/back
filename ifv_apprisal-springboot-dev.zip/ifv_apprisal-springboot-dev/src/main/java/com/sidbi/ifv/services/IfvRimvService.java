package com.sidbi.ifv.services;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.IfvRimvAppDto;
import com.sidbi.ifv.dto.IfvRimvAppForwardDto;
import com.sidbi.ifv.dto.IfvRimvDocDto;
import com.sidbi.ifv.dto.RimvValidatedRequestDto;

public interface IfvRimvService {

	Map<String, Long> getCountOfRimvApps();

	Page<IfvRimvAppDto> fetchIfvRimvApps(Pageable pageable, String filters, String sorting, String globalFilter);

	boolean saveIfvRimvApp(IfvRimvAppDto request);

	List<IfvRimvDocDto> getAllDocsOnIfvRimvAppId(Long ifvRimvAppId);

	IfvRimvDocDto uploadRimvDocument(MultipartFile file, Long ifvRimvAppId, String remarks);

	IfvRimvDocDto findById(Long documentId);

	void deleteRimvDocument(Long documentId);

	boolean forwardDocumentsToRimv(IfvRimvAppForwardDto ifvRimvAppForwardDto);

	Page<IfvRimvAppForwardDto> fetchIfvRimvDocsGrouped(int page, int size);

	boolean updateIfvRimvDocsStatus(RimvValidatedRequestDto dto);

	boolean deleteIfvRimvApp(Long id);

}
