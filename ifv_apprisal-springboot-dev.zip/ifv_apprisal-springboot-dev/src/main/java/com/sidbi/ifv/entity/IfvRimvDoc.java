package com.sidbi.ifv.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ifv_rimv_docs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IfvRimvDoc {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "ifv_rimv_app_id", nullable = false)
	private Long ifvRimvAppId;

	@Column(name = "file_module", nullable = false, length = 150)
	private String fileModule;

	@Column(name = "file_sub_module", nullable = false, length = 150)
	private String fileSubModule;

	@Column(name = "file_name", nullable = false, length = 150)
	private String fileName;

	@Column(name = "file_type", nullable = false, length = 100)
	private String fileType;

	@Column(name = "file_path", nullable = false, length = 150)
	private String filePath;

	@Column(name = "uploaded_date_time", nullable = false)
	private LocalDateTime uploadedDateTime;

	@Column(name = "remarks", length = 4000)
	private String remarks;
}
