package com.sidbi.ifv.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TimeZone;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.modelmapper.internal.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.AssistanceAppliedForDto;
import com.sidbi.ifv.dto.CreateProposalRequest;
import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.IFVProposalCheckerDetailDTO;
import com.sidbi.ifv.dto.IfvAggregateExposureDto;
import com.sidbi.ifv.dto.IfvAppReportDTO;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.entity.AssistanceAppliedForEntity;
import com.sidbi.ifv.entity.IFVDocumnetHistoryEntity;
import com.sidbi.ifv.entity.IFVProposalCheckerDetail;
import com.sidbi.ifv.entity.IfvAggregateExposure;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.entity.IfvBankRefinanceApplication;
import com.sidbi.ifv.entity.IfvBankRefinanceProposal;
import com.sidbi.ifv.entity.LoIDetailEntity;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVAssOutstandingEntity;
import com.sidbi.ifv.entity.S2IFVAssPastdisbEntity;
import com.sidbi.ifv.entity.S2IFVAssRepaymentsEntity;
import com.sidbi.ifv.entity.S2IFVEligibilityEntity;
import com.sidbi.ifv.entity.S2IFVFinancialHighlightsEntity;
import com.sidbi.ifv.entity.S2IFVPrincipalEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.entity.S2IFVTermConditionsDataEntity;
import com.sidbi.ifv.entity.SanctionTermsConditionsEntity;
import com.sidbi.ifv.entity.TblIfvModuleFwdEntity;
import com.sidbi.ifv.enums.AppStatusEnum;
import com.sidbi.ifv.enums.CheckerStatus;
import com.sidbi.ifv.enums.ModuleIdEnum;
import com.sidbi.ifv.enums.UserDesignationEnum;
import com.sidbi.ifv.enums.UserTypeEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.model.ApplicationSummaryModel;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.AssOutstandingRepository;
import com.sidbi.ifv.repo.AssPastdisbRepository;
import com.sidbi.ifv.repo.AssRepaymentsRepository;
import com.sidbi.ifv.repo.AssistanceAppliedForRepository;
import com.sidbi.ifv.repo.EligibilityRepository;
import com.sidbi.ifv.repo.FinancialHighlightsRepository;
import com.sidbi.ifv.repo.IFVDocumnetHistoryRepo;
import com.sidbi.ifv.repo.IFVProposalCheckerDetailRepo;
import com.sidbi.ifv.repo.IfvAggregateExposureRepository;
import com.sidbi.ifv.repo.IfvApiUsersRepo;
import com.sidbi.ifv.repo.IfvBankRefinanceApplicationRepository;
import com.sidbi.ifv.repo.IfvBankRefinanceProposalRepository;
import com.sidbi.ifv.repo.LoIDetailRepo;
import com.sidbi.ifv.repo.PrincipalRepository;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.repo.SanctionTermsConditionsRepository;
import com.sidbi.ifv.repo.TblIfvModuleFwdRepository;
import com.sidbi.ifv.repo.TermConditionsDataRepository;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.FileRepositoryService;
import com.sidbi.ifv.services.MasterCommonAPIClient;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.services.ProposedSchemaService;
import com.sidbi.ifv.services.ReportService;
import com.sidbi.ifv.util.ApplicationSummaryModelSorter;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.GenericSpecification;
import com.sidbi.ifv.util.NumberToWordsInCrores;
import com.sidbi.ifv.util.ProfileService;
import com.sidbi.ifv.util.SortingUtil;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import jakarta.transaction.Transactional;

@Service
public class ApplicationServiceImpl implements ApplicationService {

	private static final Logger logger = LoggerFactory.getLogger(ApplicationServiceImpl.class);

	@Autowired
	private ApplicationRepository ifccApplicationRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private TblIfvModuleFwdRepository ifvModuleFwdRepository;

	@Autowired
	private IFVDocumnetHistoryRepo docHistoryRepo;

	@Autowired
	private ProposedSchemaService proposedSchemaService;

	@Autowired
	private SanctionTermsConditionsRepository sanctionTermsConditionsRepository;

	@Autowired
	private PrincipalRepository principalRepository;

	@Autowired
	private IfvApiUsersRepo ifvApiUsersRepo;

	@Autowired
	private MasterDbService service;

	@Autowired
	private MasterCommonAPIClient masterCommonAPIClient;

	@Autowired
	private TermConditionsDataRepository conditionsDataRepository;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	@Autowired
	private FinancialHighlightsRepository financialHighlightsRepository;

	@Autowired
	private AssPastdisbRepository pastdisbRepository;

	@Autowired
	private AssOutstandingRepository outstandingRepository;

	@Autowired
	private AssRepaymentsRepository repaymentsRepository;

	String msg = "";

	@Autowired
	private EmailService emailService;

	@Autowired
	private ProfileService profileService;

	@Autowired
	private EligibilityRepository eligibilityRepository;

	@Autowired
	private FileRepositoryService fileRepositoryService;

	@Autowired
	private AssistanceAppliedForRepository assistanceAppliedForRepository;

	@Autowired
	private LoIDetailRepo loIDetailRepo;

	@Autowired
	private IFVProposalCheckerDetailRepo checkerDetailRepo;

	@Autowired
	@Lazy
	private ReportService reportService;

	@Autowired
	private IfvAggregateExposureRepository aggregateExposureRepository;

	@Autowired
	private IfvBankRefinanceApplicationRepository ifvBankRefinanceApplicationRepository;

	@Autowired
	private IfvBankRefinanceProposalRepository ifvBankRefinanceProposalRepository;

	private static final ObjectMapper objectMapper = new ObjectMapper();

	private static final String PROFILE_NAME = "local";
	private static final String IFV_ID = "ifvId";
	private static final String APP_STATUS = "appStatus";
	private static final String DATE_FORMAT = "dd-MM-yyyy";
	private static final String IFV_NAME = "ifvName";
	private static final String APP_NUMBER = "appNumber";
	private static final String CREATED_DATE = "createdDate";

	@Override
	public List<ApplicationDTO> findAll() {
		logger.info("findAll() started in ApplicationServiceImpl for S2IFVApplicationEntity");
		try {
			List<S2IFVApplicationEntity> list = ifccApplicationRepo.findAll();
			return list.stream().map(m -> modelMapper.map(m, ApplicationDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all ApplicationDTO {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all data" + msg + " ", e);
		}
	}

	@Override
	public ApplicationDTO findById(Long id) {
		logger.info("findById() started in ApplicationServiceImpl for S2IFVApplicationEntity {} ", id);
		try {
			Optional<S2IFVApplicationEntity> ifccApplication = ifccApplicationRepo.findById(id);
			if (ifccApplication.isPresent()) {
				List<ProposedSchemaDTO> dtos = proposedSchemaService.findAllByIfvId(id);
				S2IFVApplicationEntity applicationEntity = ifccApplication.get();
				ApplicationDTO applicationDTO = modelMapper.map(applicationEntity, ApplicationDTO.class);
				applicationDTO.setProposedSchemaDTOs(dtos);

				List<AssistanceAppliedForDto> assistanceAppliedForDtos = proposedSchemaService
						.findAllAssistanceByIfvId(id);
				applicationDTO.setAssistanceAppliedFor(assistanceAppliedForDtos);

				List<IfvAggregateExposureDto> aggregateExposureDtos = proposedSchemaService
						.findAggregateExposureByIfvId(id);
				applicationDTO.setAggregateExposure(aggregateExposureDtos);

				return applicationDTO;
			} else {
				logger.error("Error Occurred while fetching  S2IFVApplicationEntity entity.");
				throw new EntityNotFoundException("s2IFVApplicationEntity", id);
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching data {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all data" + msg + "", e);
		}

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public ApplicationDTO save(ApplicationDTO ifccApplicationDTO) {
		ifccApplicationDTO.setCreatedDate(new Date());

		logger.info("save() started in S2IfccApplicationServiceImpl for S2IfccApplicationDTO {} ", ifccApplicationDTO);
		try {

			int nextAppId = getNextAppIdForCurrentFinancialYear();
			String appNo = createAppNo(nextAppId);
			ifccApplicationDTO.setAppNumber(appNo);

			String bankType = service.getBankType(ifccApplicationDTO.getCifNumber());

			setBankType(ifccApplicationDTO, bankType);

			String shortName = masterCommonAPIClient.getBankShortName(ifccApplicationDTO.getCifNumber());
			ifccApplicationDTO.setIfvShortName(shortName);

			S2IFVApplicationEntity s2IFVApplicationEntity = modelMapper.map(ifccApplicationDTO,
					S2IFVApplicationEntity.class);

			List<String> bankAppRefNos = ifccApplicationDTO.getBankAppRefNos();

			if (!CollectionUtils.isEmpty(bankAppRefNos)) {

				s2IFVApplicationEntity.setBankAppRefNos(objectMapper.writeValueAsString(bankAppRefNos));
			}

			s2IFVApplicationEntity = ifccApplicationRepo.save(s2IFVApplicationEntity);

			if (ifccApplicationDTO.getProposedSchemaDTOs() != null
					&& !ifccApplicationDTO.getProposedSchemaDTOs().isEmpty()) {
				Long ifvId = s2IFVApplicationEntity.getIfvId();
				List<ProposedSchemaDTO> dtos = ifccApplicationDTO.getProposedSchemaDTOs();
				dtos.forEach(dto -> dto.setIfvId(ifvId));

				proposedSchemaService.saveAll(dtos);
			}

			if (ifccApplicationDTO.getAssistanceAppliedFor() != null
					&& !ifccApplicationDTO.getAssistanceAppliedFor().isEmpty()) {
				Long ifvId = s2IFVApplicationEntity.getIfvId();
				List<AssistanceAppliedForDto> dtos = ifccApplicationDTO.getAssistanceAppliedFor();
				dtos.forEach(dto -> dto.setIfvId(ifvId));

				List<AssistanceAppliedForEntity> entitiesToSave = dtos.stream()
						.map(dto -> modelMapper.map(dto, AssistanceAppliedForEntity.class))
						.collect(Collectors.toList());

				assistanceAppliedForRepository.saveAll(entitiesToSave);
			}

			if (ifccApplicationDTO.getAggregateExposure() != null
					&& !ifccApplicationDTO.getAggregateExposure().isEmpty()) {
				Long ifvId = s2IFVApplicationEntity.getIfvId();
				List<IfvAggregateExposureDto> dtos = ifccApplicationDTO.getAggregateExposure();

				BigDecimal capitalFunds = dtos.stream().map(IfvAggregateExposureDto::getCapitalFunds)
						.filter(Objects::nonNull).findFirst().orElse(null);

				dtos.forEach(dto -> {
					dto.setIfvId(ifvId);
					dto.setCapitalFunds(capitalFunds);
				});

				List<IfvAggregateExposure> entitiesToSave = dtos.stream()
						.map(dto -> modelMapper.map(dto, IfvAggregateExposure.class)).collect(Collectors.toList());

				aggregateExposureRepository.saveAll(entitiesToSave);
			}

			Date currentDate = new Date();

			IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo
					.findByOfrCode(ifccApplicationDTO.getOfrCode().intValue());

			String designation = UserDesignationEnum.getNameByCode(apiUsersEntity.getOfrDesgCode());

			TblIfvModuleFwdEntity fwdEntity = new TblIfvModuleFwdEntity();
			fwdEntity.setIfvId(s2IFVApplicationEntity.getIfvId());
			fwdEntity.setModuleId(ModuleIdEnum.APPRAISAL.getModuleId());
			fwdEntity.setAppOfficerCode(ifccApplicationDTO.getOfrCode());
			fwdEntity.setAppCurrentOfficerCode(ifccApplicationDTO.getOfrCode());
			fwdEntity.setAppStatus(AppStatusEnum.NEW.getShortName());
			fwdEntity.setCreatedDate(currentDate);
			fwdEntity.setCreatedModifiedDate(currentDate);
			fwdEntity.setCreatedBy(ifccApplicationDTO.getOfrName());
			fwdEntity.setIpAddress(ifccApplicationDTO.getIpAddress());
			fwdEntity.setMakerDesignation(designation);
			ifvModuleFwdRepository.save(fwdEntity);

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();
			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(ifccApplicationDTO.getOfrName());
			docHistoryEntity.setCreatedDate(currentDate);
			docHistoryEntity.setGstStatus(AppStatusEnum.NEW.getShortName());
			docHistoryEntity.setHstCurrOfficerCode(ifccApplicationDTO.getOfrCode());
			docHistoryEntity.setHstComments(AppStatusEnum.NEW.getFullName());
			docHistoryEntity.setIpAddress(ifccApplicationDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);

			if (!CollectionUtils.isEmpty(bankAppRefNos)) {

				int updatedCount = ifvBankRefinanceApplicationRepository
						.updateApplicationStatusForAppRefIds(bankAppRefNos, "IN_PROGRESS");

				if (updatedCount != bankAppRefNos.size()) {
					throw new DatabaseOperationException(String.format(
							"Expected to update %d applications but updated %d", bankAppRefNos.size(), updatedCount));
				}
			}

			ApplicationDTO dto = modelMapper.map(s2IFVApplicationEntity, ApplicationDTO.class);

			if (StringUtils.hasText(s2IFVApplicationEntity.getBankAppRefNos())) {

				dto.setBankAppRefNos(objectMapper.readValue(s2IFVApplicationEntity.getBankAppRefNos(),
						new TypeReference<List<String>>() {
						}));
			}

			return dto;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVApplicationEntity." + msg + " ",
					e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public ApplicationDTO update(Long id, ApplicationDTO s2IfccApplicationDTO) {
		logger.info("updateIfccApp() started in S2IFCCApplicationServiceImpl for S2IfccApplicationDTO {} {} ", id,
				s2IfccApplicationDTO);
		try {

			S2IFVApplicationEntity applicationEntity = ifccApplicationRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("IFVApplicationEntity", id));

			s2IfccApplicationDTO.setModifiedDate(new Date());
			s2IfccApplicationDTO.setIfvName(applicationEntity.getIfvName());

			String shortName = masterCommonAPIClient.getBankShortName(applicationEntity.getCifNumber());

			s2IfccApplicationDTO.setIfvShortName(shortName);

			String bankType = service.getBankType(s2IfccApplicationDTO.getCifNumber());

			setBankType(s2IfccApplicationDTO, bankType);

			BeanUtils.copyProperties(s2IfccApplicationDTO, applicationEntity,
					commonUtil.getNullPropertyNames(s2IfccApplicationDTO));

			ifccApplicationRepo.save(applicationEntity);

			if (s2IfccApplicationDTO.getProposedSchemaDTOs() != null
					&& !s2IfccApplicationDTO.getProposedSchemaDTOs().isEmpty()) {

				List<ProposedSchemaDTO> dtos = s2IfccApplicationDTO.getProposedSchemaDTOs();
				S2IFVEligibilityEntity eligibilityEntity = eligibilityRepository.getByIfvId(id);
				if (eligibilityEntity != null && eligibilityEntity.getEcId() > 0) {
					boolean isRMSE = dtos.stream().map(ProposedSchemaDTO::getPrFundname)
							.anyMatch(e -> e.contains("RMSE"));
					if (isRMSE) {
						List<String> rmseRegular = dtos.stream().map(ProposedSchemaDTO::getPrFundname)
								.filter(fundName -> fundName.contains("RMSE") && !fundName.contains("ICDD"))
								.collect(Collectors.toList());
						String findICDD = determineICDDData(eligibilityEntity);
						updateRMSEData(eligibilityEntity, rmseRegular.size(), findICDD);
						eligibilityRepository.save(eligibilityEntity);
					}
				}

				setSanctionTermsAndPrincRepayment(id, dtos);

				S2IFVTermConditionsDataEntity conditionsDataDTO = conditionsDataRepository.findByIfvId(id);
				setTermsAndConditions(applicationEntity, dtos, conditionsDataDTO);

				proposedSchemaService.saveAll(dtos);
			}

			if (s2IfccApplicationDTO.getAssistanceAppliedFor() != null
					&& !s2IfccApplicationDTO.getAssistanceAppliedFor().isEmpty()) {
				List<AssistanceAppliedForDto> dtos = s2IfccApplicationDTO.getAssistanceAppliedFor();

				List<AssistanceAppliedForEntity> entitiesToSave = dtos.stream()
						.map(dto -> modelMapper.map(dto, AssistanceAppliedForEntity.class))
						.collect(Collectors.toList());

				assistanceAppliedForRepository.saveAll(entitiesToSave);
			}

			saveAggregateExposure(s2IfccApplicationDTO);

			Date date = new Date();

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(id);
			if (fwdEntity != null) {
				fwdEntity.setAppCurrentOfficerCode(s2IfccApplicationDTO.getOfrCode());
				fwdEntity.setModifiedDate(date);
				fwdEntity.setCreatedModifiedDate(date);

				IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo
						.findByOfrCode(s2IfccApplicationDTO.getOfrCode().intValue());
				if (apiUsersEntity.getOfrType().equals(UserTypeEnum.MAKER.getUserType())) {
					fwdEntity.setModifiedBy(s2IfccApplicationDTO.getOfrName());
					String designation = UserDesignationEnum.getNameByCode(apiUsersEntity.getOfrDesgCode());
					fwdEntity.setMakerDesignation(designation);
				}

				fwdEntity.setIpAddress(s2IfccApplicationDTO.getIpAddress());
				ifvModuleFwdRepository.save(fwdEntity);
			}

			return modelMapper.map(applicationEntity, ApplicationDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVApplicationEntity of id ." + id + " " + msg + " ", e);
		}
	}

	private void saveAggregateExposure(ApplicationDTO s2IfccApplicationDTO) {
		if (s2IfccApplicationDTO.getAggregateExposure() != null
				&& !s2IfccApplicationDTO.getAggregateExposure().isEmpty()) {
			Long ifvId = s2IfccApplicationDTO.getIfvId();
			List<IfvAggregateExposureDto> dtos = s2IfccApplicationDTO.getAggregateExposure();
			BigDecimal capitalFunds = dtos.stream().map(IfvAggregateExposureDto::getCapitalFunds)
					.filter(Objects::nonNull).findFirst().orElse(null);

			dtos.forEach(dto -> {
				dto.setIfvId(ifvId);
				dto.setCapitalFunds(capitalFunds);
			});

			List<IfvAggregateExposure> entitiesToSave = dtos.stream()
					.map(dto -> modelMapper.map(dto, IfvAggregateExposure.class)).collect(Collectors.toList());

			aggregateExposureRepository.saveAll(entitiesToSave);
		}
	}

	private void setTermsAndConditions(S2IFVApplicationEntity applicationEntity, List<ProposedSchemaDTO> dtos,
			S2IFVTermConditionsDataEntity conditionsDataDTO) {
		if (conditionsDataDTO != null && conditionsDataDTO.getIfvId() > 0) {
			var note = "The proposal does not involve any relaxation.\nIFCC-CGM is requested to approve sanction of Rs. ";
			BigDecimal sum = BigDecimal.ZERO;

			int dtoSize = dtos.size();
			int count = 0;

			if (dtoSize > 1) {
				note = setSmallNote(applicationEntity, dtos, note, sum, dtoSize, count);
			} else {
				note = setNote(applicationEntity, dtos, note, sum);

			}

			conditionsDataDTO.setTsRecommendation(note);

			conditionsDataRepository.save(conditionsDataDTO);
		}
	}

	private String setSmallNote(S2IFVApplicationEntity applicationEntity, List<ProposedSchemaDTO> dtos, String note,
			BigDecimal sum, int dtoSize, int count) {

		StringBuilder smallNoteBuilder = new StringBuilder();
		String appendixVal = "";

		for (ProposedSchemaDTO dto : dtos) {
			sum = sum.add(dto.getPrAmount());

			String schemeName = dto.getPrSchemeName();
			if (schemeName != null && schemeName.toUpperCase().contains("RMSE")) {
				schemeName = this.getSchemeName(dto.getPrFundname());
			}

			smallNoteBuilder.append("Rs. ").append(dto.getPrAmount()).append(" crore under ").append(schemeName);

			if (dtoSize - 1 != count) {
				smallNoteBuilder.append(" and ");
			} else {
				smallNoteBuilder.append(" ");
			}

			count++;
		}

		switch (dtoSize) {
		case 2:
			appendixVal = "Appendix-I and Appendix-II";
			break;
		case 3:
			appendixVal = "Appendix-I and Appendix-II and Appendix-III";
			break;
		case 4:
			appendixVal = "Appendix-I and Appendix-II and Appendix-III and Appendix-IV";
			break;
		default:
			appendixVal = "";
		}

		StringBuilder noteBuilder = new StringBuilder(note);
		noteBuilder.append(sum).append(" crore comprising ").append(smallNoteBuilder).append("Scheme to ")
				.append(applicationEntity.getIfvName()).append(", as per the terms and conditions given in ")
				.append(appendixVal);

		return noteBuilder.toString();
	}

	private String setNote(S2IFVApplicationEntity applicationEntity, List<ProposedSchemaDTO> dtos, String note,
			BigDecimal sum) {

		StringBuilder sb = new StringBuilder(note == null ? "" : note);

		for (ProposedSchemaDTO dto : dtos) {
			sum = sum.add(dto.getPrAmount());

			String schemeName = dto.getPrSchemeName();
			if (schemeName.toUpperCase().contains("RMSE")) {
				schemeName = this.getSchemeName(dto.getPrFundname());
			}

			sb.append(dto.getPrAmount()).append(" crore under ").append(schemeName).append(" Scheme to ")
					.append(applicationEntity.getIfvName());

			sb.append(", as per the terms and conditions given in Appendix.");
		}

		return sb.toString();
	}

	private void setBankType(ApplicationDTO s2IfccApplicationDTO, String bankType) {
		if (bankType != null && bankType.trim().toUpperCase().contains("URBAN COOPERATIVE")) {
			s2IfccApplicationDTO.setIfvBankType("UCB");
			s2IfccApplicationDTO.setSfb("Y");
		} else if (bankType != null && bankType.trim().toUpperCase().contains("REGIONAL RURAL")) {
			s2IfccApplicationDTO.setIfvBankType("RRB");
			s2IfccApplicationDTO.setSfb("Y");
		} else if (bankType != null && bankType.trim().toUpperCase().contains("SMALL FINANCE BANK")) {
			s2IfccApplicationDTO.setIfvBankType("SFB");
			s2IfccApplicationDTO.setSfb("Y");
		} else {
			s2IfccApplicationDTO.setSfb("N");
		}
	}

	private void setSanctionTermsAndPrincRepayment(Long id, List<ProposedSchemaDTO> dtos) {
		dtos.forEach(e -> {
			e.setIfvId(id);
			Long prId = e.getPrId();
			if (prId != null && prId > 0) {
				SanctionTermsConditionsEntity sanc = sanctionTermsConditionsRepository.findByIfvIdAndPrId(id, prId);

				if (sanc != null && sanc.getId() > 0) {

					sanc.setSchemeCode(e.getPrSchemecode());
					sanc.setSchemeName(e.getPrSchemeName());
					sanc.setFundCode(e.getPrFundcode());
					sanc.setFundName(e.getPrFundname());
					sanc.setTsRAteInterest(e.getPrRoi());
					sanc.setTsTenurePeriod(e.getPrTenure());
					sanc.setAmountInWords(NumberToWordsInCrores.numberToWordsInCrores(e.getPrAmount()));
					sanc.setAmount(e.getPrAmount());

					sanc.setBenchMark(e.getBenchMark());
					sanc.setInterestReset(e.getInterestReset());
					sanc.setInterestType(e.getInterestType());
					sanc.setSpread(e.getSpread());

					sanctionTermsConditionsRepository.save(sanc);
				}

				S2IFVPrincipalEntity principalEntity = principalRepository.findByIfvIdAndPrId(id, prId);
				if (principalEntity != null && principalEntity.getPlId() > 0) {
					principalEntity.setPlScheme(e.getPrSchemeName());
					principalRepository.save(principalEntity);
				}
			}

		});
	}

	private String determineICDDData(S2IFVEligibilityEntity eligibilityEntity) {
		if (StringUtils.hasText(eligibilityEntity.getRmse5Data())) {
			return eligibilityEntity.getRmse5Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse4Data())) {
			return eligibilityEntity.getRmse4Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse3Data())) {
			return eligibilityEntity.getRmse3Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse2Data())) {
			return eligibilityEntity.getRmse2Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse1Data())) {
			return eligibilityEntity.getRmse1Data();
		} else {
			return "Availability of assets in the 196 identified credit deficient districts.";
		}
	}

	private void updateRMSEData(S2IFVEligibilityEntity entity, int rmseRegularSize, String icddData) {
		String defaultEligibilityText = "Eligibility as per RBI letter dated _________, for having achived PSL target for lending to Micro enterprise in FY _____.";
		if (rmseRegularSize == 0) {
			entity.setRmse1Data(icddData);
			entity.setRmse2Data("");
			entity.setRmse3Data("");
			entity.setRmse4Data("");
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 1) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(icddData);
			entity.setRmse3Data("");
			entity.setRmse4Data("");
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 2) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(getOrDefaultText(entity.getRmse2Data(), defaultEligibilityText));
			entity.setRmse3Data(icddData);
			entity.setRmse4Data("");
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 3) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(getOrDefaultText(entity.getRmse2Data(), defaultEligibilityText));
			entity.setRmse3Data(getOrDefaultText(entity.getRmse3Data(), defaultEligibilityText));
			entity.setRmse4Data(icddData);
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 4) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(getOrDefaultText(entity.getRmse2Data(), defaultEligibilityText));
			entity.setRmse3Data(getOrDefaultText(entity.getRmse3Data(), defaultEligibilityText));
			entity.setRmse4Data(getOrDefaultText(entity.getRmse4Data(), defaultEligibilityText));
			entity.setRmse5Data(icddData);
		}
	}

	private String getOrDefaultText(String currentText, String defaultText) {
		return (!StringUtils.hasText(currentText) || currentText.contains("Availability")) ? defaultText : currentText;
	}

	public String getSchemeName(String schemeName) {
		String wordToFind = "FUND";
		int index = schemeName.indexOf(wordToFind);
		if (index != -1) {
			return schemeName.substring(0, index).trim();
		}
		return schemeName;
	}

	@Override
	public void delete(Long id) {
		logger.info("deleteIfccApp() started in ApplicationServiceImpl for S2IFCCApplicationDTO {} ", id);
		try {
			S2IFVApplicationEntity applicationEntity = ifccApplicationRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVApplicationEntity", id));
			ifccApplicationRepo.delete(applicationEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVApplicationEntity of id ." + id + " " + msg + " ", e);
		}

	}

	@Override
	@org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
	public TblIfvModuleFwdDTO lockDocument(ApplicationDTO applicationDTO) {
		logger.info("lock() started in ApplicationServiceImpl for ApplicationDTO {} ", applicationDTO.getIfvId());
		try {
			S2IFVApplicationEntity ifccApplication = ifccApplicationRepo.findById(applicationDTO.getIfvId())
					.orElseThrow(
							() -> new EntityNotFoundException("S2IFVApplicationEntity", applicationDTO.getIfvId()));
			ifccApplication.setCheckerId(applicationDTO.getCheckerId());
			ifccApplicationRepo.save(ifccApplication);

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(applicationDTO.getIfvId());
			fwdEntity.setAppCurrentOfficerCode(applicationDTO.getOfrCode());
			fwdEntity.setCurrentFwdCheckerName(applicationDTO.getOfrName());
			fwdEntity.setAppStatus(AppStatusEnum.LOCK.getShortName());

			IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo.findByOfrCode(applicationDTO.getCheckerId());

			IfvApiUsersEntity apiCurrentUsersEntity = ifvApiUsersRepo
					.findByOfrCode(applicationDTO.getOfrCode().intValue());

			String ofrName = apiUsersEntity.getOfrName();
			if (apiUsersEntity.getOfrShortName() != null && !apiUsersEntity.getOfrShortName().isEmpty()) {
				ofrName = apiUsersEntity.getOfrShortName();
			}

			LocalDateTime localDateTime = LocalDateTime.now();
			String forwardComment = applicationDTO.getIfvBackground();

			IFVProposalCheckerDetail detail = new IFVProposalCheckerDetail();
			detail.setIfvId(applicationDTO.getIfvId());
			detail.setStatus(CheckerStatus.FORWARD.getStatusFlag());
			detail.setCurrentUserComment(forwardComment);
			detail.setCurrentUserId(applicationDTO.getOfrCode());
			detail.setCurrentUserName(applicationDTO.getOfrName());
			detail.setCurrentUserDesignation(
					UserDesignationEnum.getNameByCode(apiCurrentUsersEntity.getOfrDesgCode().intValue()));
			detail.setCurrentUserAction("Accept and Forward");
			detail.setDateTimeOfAction(localDateTime);

			IFVProposalCheckerDetail detail2 = checkerDetailRepo
					.findTop1ByIfvIdOrderByIdDesc(applicationDTO.getIfvId());

			if (detail2 != null && detail2.getDateTimeOfAction() != null) {
				detail.setDateTimeOfReceipt(detail2.getDateTimeOfAction());
			} else {
				detail.setDateTimeOfReceipt(localDateTime);
			}

			switch (apiCurrentUsersEntity.getOfrDesgCode().intValue()) {
			case 229 -> {
				fwdEntity.setLockedDateTime(localDateTime);
				fwdEntity.setLockComment(forwardComment);
				detail.setCurrentUserAction("Originator");
			}
			case 41 -> {
				fwdEntity.setLockedDateTime(localDateTime);
				fwdEntity.setLockComment(forwardComment);
				detail.setCurrentUserAction("Originator");
			}
			case 26 -> {
				fwdEntity.setChecker1FwdDate(localDateTime);
				fwdEntity.setChecker1Comment(forwardComment);
			}
			case 20 -> {
				fwdEntity.setChecker2FwdDate(localDateTime);
				fwdEntity.setChecker2Comment(forwardComment);
			}
			case 12 -> {
				fwdEntity.setChecker3FwdDate(localDateTime);
				fwdEntity.setChecker3Comment(forwardComment);
			}
			default -> {
				// No action needed
			}
			}

			detail.setForwardedUserId(applicationDTO.getCheckerId().longValue());
			detail.setForwardedUserName(ofrName);
			detail.setForwardedUserDesignation(
					UserDesignationEnum.getNameByCode(apiUsersEntity.getOfrDesgCode().intValue()));

			switch (apiUsersEntity.getOfrDesgCode().intValue()) {

			case 26:
				fwdEntity.setChecker1Desg(UserDesignationEnum.getNameByCode(26));
				fwdEntity.setChecker1Id(applicationDTO.getCheckerId());
				fwdEntity.setChecker1Name(ofrName);
				break;

			case 20:
				fwdEntity.setChecker2Desg(UserDesignationEnum.getNameByCode(20));
				fwdEntity.setChecker2Id(applicationDTO.getCheckerId());
				fwdEntity.setChecker2Name(ofrName);
				break;

			case 12:
				fwdEntity.setChecker3Desg(UserDesignationEnum.getNameByCode(12));
				fwdEntity.setChecker3Id(applicationDTO.getCheckerId());
				fwdEntity.setChecker3Name(ofrName);
				break;

			case 9:
				fwdEntity.setChecker4Desg(UserDesignationEnum.getNameByCode(9));
				fwdEntity.setChecker4Id(applicationDTO.getCheckerId());
				fwdEntity.setChecker4Name(ofrName);
				break;

			default:
				break;
			}

			ifvModuleFwdRepository.save(fwdEntity);

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();
			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(applicationDTO.getOfrName());
			docHistoryEntity.setCreatedDate(new Date());
			docHistoryEntity.setGstStatus(AppStatusEnum.LOCK.getShortName());
			docHistoryEntity.setHstCurrOfficerCode(applicationDTO.getOfrCode());
			docHistoryEntity.setHstComments(AppStatusEnum.LOCK.getFullName());
			docHistoryEntity.setIpAddress(applicationDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);

			checkerDetailRepo.save(detail);

			ApplicationDTO applicationDTO2 = modelMapper.map(ifccApplication, ApplicationDTO.class);
			TblIfvModuleFwdDTO fwdDTO = modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

			if (!profileService.isProfileActive(PROFILE_NAME)) {
				emailService.sendEmailWithRetry("LOCK", applicationDTO2, fwdDTO, null, null);
			}

			return fwdDTO;
		} catch (Exception e) {
			throw new DatabaseOperationException("Unable to forward the document due to unexpected error", e);
		}
	}

	@Override
	public boolean checkIfvIdExistsInChildTables(Long ifvId) {
		logger.info("Started checkIfvIdExistsInChildTables() in ApplicationServiceImpl with ifvId {} ", ifvId);
		boolean check = false;
		try {
			List<Boolean> results = ifccApplicationRepo.checkIfvIdExistsInChildTables(ifvId);
			check = results.stream().allMatch(Boolean::booleanValue);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing checkIfvIdExistsInChildTables {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while executing checkIfvIdExistsInChildTables " + msg + " ", e);

		}
		return check;
	}

	@Override
	public List<ApplicationDTO> getAllOnUserType(String userType, Long ofrCode) {
		logger.info("Started getAllOnUserType() in ApplicationServiceImpl with ifvId {} ", userType);
		List<S2IFVApplicationEntity> list = ifccApplicationRepo.findAll();
		if (list.isEmpty()) {
			return new ArrayList<>();
		} else {
			List<ApplicationDTO> applicationDTOs = list.stream()
					.sorted(Comparator.comparing(S2IFVApplicationEntity::getCreatedDate).reversed())
					.map(applicationEntity -> modelMapper.map(applicationEntity, ApplicationDTO.class))
					.collect(Collectors.toList());

			List<TblIfvModuleFwdEntity> entities = ifvModuleFwdRepository.findAll();

			Map<Long, TblIfvModuleFwdEntity> m = entities.stream()
					.collect(Collectors.toMap(TblIfvModuleFwdEntity::getIfvId, Function.identity(), (e1, e2) -> e1));

			applicationDTOs.forEach(e -> {
				TblIfvModuleFwdEntity obj = m.get(e.getIfvId());
				if (obj != null) {

					e.setMakerName(obj.getCreatedBy());
					e.setStatus(AppStatusEnum.getFullNameByShortName(obj.getAppStatus()));
				}

			});

			switch (userType) {

			// Maker
			case "9092":
				break;

			// Checker
			case "9128":
			case "9093":
			case "9095":
			case "10489":
			case "11314":
				List<Long> approvedIds = entities.stream()
						.filter(moduleFwdEntity -> moduleFwdEntity.getAppStatus()
								.equalsIgnoreCase(AppStatusEnum.APPROVE.getShortName()))
						.map(TblIfvModuleFwdEntity::getIfvId).collect(Collectors.toList());

				applicationDTOs = applicationDTOs.stream()
						.filter(e -> (e.getCheckerId() != null && e.getCheckerId().intValue() == ofrCode.intValue())
								|| approvedIds.contains(e.getIfvId()))
						.collect(Collectors.toList());
				break;

			default:
				applicationDTOs = new ArrayList<>();
				break;
			}
			applicationDTOs.sort(Comparator.comparing(ApplicationDTO::getCreatedDate).reversed());
			return applicationDTOs;
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public TblIfvModuleFwdDTO confirmDocument(ApplicationDTO applicationDTO) {

		logger.info("lock() started in ApplicationServiceImpl for S2IFCCApplicationDTO {} ", applicationDTO.getIfvId());
		try {

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(applicationDTO.getIfvId());
			fwdEntity.setAppCurrentOfficerCode(applicationDTO.getOfrCode());
			fwdEntity.setAppStatus(AppStatusEnum.CONFIRM.getShortName());

			ifvModuleFwdRepository.save(fwdEntity);

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();
			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(applicationDTO.getOfrName());
			docHistoryEntity.setCreatedDate(new Date());
			docHistoryEntity.setGstStatus(AppStatusEnum.CONFIRM.getShortName());
			docHistoryEntity.setHstCurrOfficerCode(applicationDTO.getOfrCode());
			docHistoryEntity.setHstComments(AppStatusEnum.CONFIRM.getFullName());
			docHistoryEntity.setIpAddress(applicationDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);

			return modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while lockDocument S2IFVApplicationEntity entity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while lockDocument S2IFVApplicationEntity entity of id ."
							+ applicationDTO.getIfvId() + " " + msg + " ",
					e);
		}

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public TblIfvModuleFwdDTO unlockDocument(ApplicationDTO applicationDTO) {

		logger.info("unlockDocument() started in ApplicationServiceImpl for S2IFCCApplicationDTO {} ",
				applicationDTO.getIfvId());
		try {

			S2IFVApplicationEntity ifccApplication = ifccApplicationRepo.findById(applicationDTO.getIfvId())
					.orElse(null);
			ifccApplication.setCheckerId(applicationDTO.getCheckerId());
			ifccApplicationRepo.save(ifccApplication);

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(applicationDTO.getIfvId());
			IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo.findByOfrCode(applicationDTO.getCheckerId());

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();

			if (apiUsersEntity.getOfrType().equalsIgnoreCase(UserTypeEnum.MAKER.getUserType())) {
				fwdEntity.setAppStatus(AppStatusEnum.NEW.getShortName());
				docHistoryEntity.setGstStatus(AppStatusEnum.NEW.getShortName());
				docHistoryEntity.setHstComments(AppStatusEnum.NEW.getFullName());
			} else {
				docHistoryEntity.setGstStatus(AppStatusEnum.LOCK.getShortName());
				docHistoryEntity.setHstComments(AppStatusEnum.LOCK.getFullName());
			}
			fwdEntity.setAppCurrentOfficerCode(applicationDTO.getOfrCode());
			fwdEntity.setCurrentFwdCheckerName(applicationDTO.getOfrName());

			IfvApiUsersEntity apiCurrentUsersEntity = ifvApiUsersRepo
					.findByOfrCode(applicationDTO.getOfrCode().intValue());
			IFVProposalCheckerDetail detail = new IFVProposalCheckerDetail();
			detail.setIfvId(applicationDTO.getIfvId());
			detail.setStatus(CheckerStatus.REJECT.getStatusFlag());
			detail.setCurrentUserComment(applicationDTO.getIfvBackground());
			detail.setCurrentUserId(applicationDTO.getOfrCode());
			detail.setCurrentUserName(applicationDTO.getOfrName());
			detail.setCurrentUserDesignation(
					UserDesignationEnum.getNameByCode(apiCurrentUsersEntity.getOfrDesgCode().intValue()));
			detail.setCurrentUserAction("Reject");
			detail.setForwardedUserId(applicationDTO.getCheckerId().longValue());
			detail.setForwardedUserName(apiUsersEntity.getOfrName());
			detail.setForwardedUserDesignation(
					UserDesignationEnum.getNameByCode(apiUsersEntity.getOfrDesgCode().intValue()));

			LocalDateTime localDateTime = LocalDateTime.now();

			detail.setDateTimeOfAction(localDateTime);

			IFVProposalCheckerDetail detail2 = checkerDetailRepo
					.findTop1ByIfvIdOrderByIdDesc(applicationDTO.getIfvId());

			if (detail2 != null && detail2.getDateTimeOfAction() != null) {
				detail.setDateTimeOfReceipt(detail2.getDateTimeOfAction());
			} else {
				detail.setDateTimeOfReceipt(localDateTime);
			}

			switch (apiUsersEntity.getOfrDesgCode().intValue()) {

			case 41:
			case 229:
				fwdEntity.setChecker1Desg(null);
				fwdEntity.setChecker1Id(null);
				fwdEntity.setChecker1Name(null);

				fwdEntity.setChecker2Desg(null);
				fwdEntity.setChecker2Id(null);
				fwdEntity.setChecker2Name(null);

				fwdEntity.setChecker3Desg(null);
				fwdEntity.setChecker3Id(null);
				fwdEntity.setChecker3Name(null);

				fwdEntity.setChecker4Desg(null);
				fwdEntity.setChecker4Id(null);
				fwdEntity.setChecker4Name(null);

				fwdEntity.setLockedDateTime(null);
				fwdEntity.setLockComment(null);

				fwdEntity.setChecker1FwdDate(null);
				fwdEntity.setChecker1Comment(null);

				fwdEntity.setChecker2FwdDate(null);
				fwdEntity.setChecker2Comment(null);

				fwdEntity.setChecker3FwdDate(null);
				fwdEntity.setChecker3Comment(null);

				fwdEntity.setApprovedDateTime(null);
				fwdEntity.setChecker4Comment(null);

				fwdEntity.setCurrentFwdCheckerDesg(null);
				fwdEntity.setCurrentFwdCheckerName(null);
				break;

			case 26:

				fwdEntity.setChecker2Desg(null);
				fwdEntity.setChecker2Id(null);
				fwdEntity.setChecker2Name(null);

				fwdEntity.setChecker3Desg(null);
				fwdEntity.setChecker3Id(null);
				fwdEntity.setChecker3Name(null);

				fwdEntity.setChecker4Desg(null);
				fwdEntity.setChecker4Id(null);
				fwdEntity.setChecker4Name(null);

				fwdEntity.setChecker1FwdDate(null);
				fwdEntity.setChecker1Comment(null);

				fwdEntity.setChecker2FwdDate(null);
				fwdEntity.setChecker2Comment(null);

				fwdEntity.setChecker3FwdDate(null);
				fwdEntity.setChecker3Comment(null);

				fwdEntity.setApprovedDateTime(null);
				fwdEntity.setChecker4Comment(null);
				break;

			case 20:

				fwdEntity.setChecker3Desg(null);
				fwdEntity.setChecker3Id(null);
				fwdEntity.setChecker3Name(null);

				fwdEntity.setChecker4Desg(null);
				fwdEntity.setChecker4Id(null);
				fwdEntity.setChecker4Name(null);

				fwdEntity.setChecker2FwdDate(null);
				fwdEntity.setChecker2Comment(null);

				fwdEntity.setChecker3FwdDate(null);
				fwdEntity.setChecker3Comment(null);

				fwdEntity.setApprovedDateTime(null);
				fwdEntity.setChecker4Comment(null);
				break;

			case 12:

				fwdEntity.setChecker4Desg(null);
				fwdEntity.setChecker4Id(null);
				fwdEntity.setChecker4Name(null);

				fwdEntity.setChecker3FwdDate(null);
				fwdEntity.setChecker3Comment(null);

				fwdEntity.setApprovedDateTime(null);
				fwdEntity.setChecker4Comment(null);
				break;

			default:
				break;
			}

			ifvModuleFwdRepository.save(fwdEntity);

			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(applicationDTO.getOfrName());
			docHistoryEntity.setCreatedDate(new Date());
			docHistoryEntity.setHstCurrOfficerCode(applicationDTO.getOfrCode());
			docHistoryEntity.setIpAddress(applicationDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);
			checkerDetailRepo.save(detail);

			ApplicationDTO applicationDTO2 = modelMapper.map(ifccApplication, ApplicationDTO.class);
			TblIfvModuleFwdDTO fwdDTO = modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

			if (!profileService.isProfileActive(PROFILE_NAME)) {
				emailService.sendEmailWithRetry("UNLOCK", applicationDTO2, fwdDTO, null, null);
			}

			return modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while unlockDocument S2IFVApplicationEntity entity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while unlockDocument S2IFVApplicationEntity entity of id ."
							+ applicationDTO.getIfvId() + " " + msg + " ",
					e);
		}

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public TblIfvModuleFwdDTO approveDocument(ApplicationDTO applicationDTO) {
		Long ifvId = applicationDTO.getIfvId();
		logger.info("approveDocument() started in ApplicationServiceImpl for S2IFCCApplicationDTO {} ",
				applicationDTO.getIfvId());
		try {

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(ifvId);
			fwdEntity.setAppCurrentOfficerCode(applicationDTO.getOfrCode());
			fwdEntity.setAppStatus(AppStatusEnum.APPROVE.getShortName());

			IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo.findByOfrCode(applicationDTO.getOfrCode().intValue());

			LocalDateTime localDateTime = LocalDateTime.now();
			String forwardComment = applicationDTO.getIfvBackground();

			IFVProposalCheckerDetail detail = new IFVProposalCheckerDetail();
			detail.setIfvId(ifvId);
			detail.setStatus(CheckerStatus.APPROVE.getStatusFlag());
			detail.setCurrentUserComment(applicationDTO.getIfvBackground());
			detail.setCurrentUserId(applicationDTO.getOfrCode());
			detail.setCurrentUserName(applicationDTO.getOfrName());
			detail.setCurrentUserDesignation(
					UserDesignationEnum.getNameByCode(apiUsersEntity.getOfrDesgCode().intValue()));
			detail.setCurrentUserAction("Approved");
			detail.setDateTimeOfAction(localDateTime);
			IFVProposalCheckerDetail detail2 = checkerDetailRepo.findTop1ByIfvIdOrderByIdDesc(ifvId);

			if (detail2 != null && detail2.getDateTimeOfAction() != null) {
				detail.setDateTimeOfReceipt(detail2.getDateTimeOfAction());
			} else {
				detail.setDateTimeOfReceipt(localDateTime);
			}

			switch (apiUsersEntity.getOfrDesgCode().intValue()) {

			case 26:
				fwdEntity.setChecker1FwdDate(localDateTime);
				fwdEntity.setChecker1Comment(forwardComment);
				break;

			case 20:
				fwdEntity.setChecker2FwdDate(localDateTime);
				fwdEntity.setChecker2Comment(forwardComment);
				break;

			case 12:
				fwdEntity.setChecker3FwdDate(localDateTime);
				fwdEntity.setChecker3Comment(forwardComment);
				break;

			case 9:
				fwdEntity.setApprovedDateTime(localDateTime);
				fwdEntity.setChecker4Comment(forwardComment);
				break;

			default:
				break;
			}

			ifvModuleFwdRepository.save(fwdEntity);

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();
			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(applicationDTO.getOfrName());
			docHistoryEntity.setCreatedDate(new Date());
			docHistoryEntity.setGstStatus(AppStatusEnum.APPROVE.getShortName());
			docHistoryEntity.setHstCurrOfficerCode(applicationDTO.getOfrCode());
			docHistoryEntity.setHstComments(AppStatusEnum.APPROVE.getFullName());
			docHistoryEntity.setIpAddress(applicationDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);
			checkerDetailRepo.save(detail);

			return modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while approveDocument S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while approveDocument S2IFVApplicationEntity of id ."
					+ applicationDTO.getIfvId() + " " + msg + " ", e);
		}

	}

	public int getNextAppIdForCurrentFinancialYear() {
		logger.info("Getting next app ID for current financial year");
		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"));
		int currentMonth = cal.get(Calendar.MONTH) + 1; // Calendar months are 0-based
		int currentYear = cal.get(Calendar.YEAR);
		cal.clear();
		if (currentMonth >= 4) {
			cal.set(currentYear, Calendar.APRIL, 1, 0, 0, 0);
		} else {
			cal.set(currentYear - 1, Calendar.APRIL, 1, 0, 0, 0);
		}
		cal.set(Calendar.MILLISECOND, 0);
		Date financialYearStart = cal.getTime();
		logger.info("Financial year start date: {}", financialYearStart);
		// Find the latest application number created after financial year start
		String latestAppNo = ifccApplicationRepo.findLatestAppNoFromDate(financialYearStart);
		logger.info("Latest application number found: {}", latestAppNo);
		if (latestAppNo == null) {
			logger.info("No applications found in current financial year, starting from 1");
			return 1;
		}
		// Extract the last 4 digits from the application number
		String numberPart = latestAppNo.substring(latestAppNo.length() - 4);
		int nextId = Integer.parseInt(numberPart) + 1;
		logger.info("Next application ID will be: {}", nextId);
		return nextId;
	}

	@Override
	public String createAppNo(int appId) {
		logger.info("Started createAppNo() with appId {} ", appId);
		try {
			String prefix = "IFV";
			int year = Year.now().getValue() % 100;
			String yearStr = "" + year;

			int month = LocalDate.now().getMonthValue();
			if (month >= 4) {
				yearStr = "F" + (year + 1);
			}

			String id = String.format("%04d", appId);
			return prefix + yearStr + id;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating createAppNo. {}", msg);
			throw new DatabaseOperationException("Error Occurred while creating createAppNo " + msg, e);
		}
	}

	public List<Long> getIdsOnType(String type) {
		List<TblIfvModuleFwdEntity> fwdEntities = ifvModuleFwdRepository.findAll();
		return fwdEntities.stream().filter(moduleFwdEntity -> moduleFwdEntity.getAppStatus().equalsIgnoreCase(type))
				.map(TblIfvModuleFwdEntity::getIfvId).collect(Collectors.toList());

	}

	@Override
	public List<ApplicationDTO> findAllByIfvIdIn(List<Long> ifvIds) {
		logger.info("findAllByIfvIdIn() started in ApplicationServiceImpl for S2IFCCApplicationDTO {} ", ifvIds);
		List<S2IFVApplicationEntity> list = ifccApplicationRepo.findAllByIfvIdIn(ifvIds);
		return !list.isEmpty()
				? list.stream().map(applicationEntity -> modelMapper.map(applicationEntity, ApplicationDTO.class))
						.collect(Collectors.toList())
				: new ArrayList<>();
	}

	@Override
	public List<IfvAppReportDTO> getIfvAppsReportData() {
		logger.info("getIfvAppsReportData() started in ApplicationServiceImpl for S2IFVApplicationEntity");
		try {

			List<S2IFVApplicationEntity> list = ifccApplicationRepo.findAll();

			List<IfvAppReportDTO> appReportDTOs = list.stream().map(m -> modelMapper.map(m, IfvAppReportDTO.class))
					.sorted(Comparator.comparing(IfvAppReportDTO::getCreatedDate).reversed())
					.collect(Collectors.toList());

			List<Long> ids = list.stream().map(S2IFVApplicationEntity::getIfvId).collect(Collectors.toList());
			List<TblIfvModuleFwdEntity> entities = ifvModuleFwdRepository.findByIfvIdIn(ids);

			Map<Long, TblIfvModuleFwdEntity> m = entities.stream()
					.collect(Collectors.toMap(TblIfvModuleFwdEntity::getIfvId, Function.identity(), (e1, e2) -> e1));

			appReportDTOs.forEach(e -> {
				TblIfvModuleFwdEntity obj = m.get(e.getIfvId());
				if (obj != null) {

					e.setMakerName(obj.getCreatedBy());
					e.setStatus(AppStatusEnum.getFullNameByShortName(obj.getAppStatus()));
				}

			});

			return appReportDTOs;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVApplicationEntities. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVApplicationEntities." + msg + " ", e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public TblIfvModuleFwdDTO revertApprovedDocument(ApplicationDTO applicationDTO) {
		logger.info("revertApprovedDocument() started in ApplicationServiceImpl for S2IFCCApplicationDTO {} ",
				applicationDTO.getIfvId());
		try {

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(applicationDTO.getIfvId());

			Long approvedOfrCode = fwdEntity.getAppCurrentOfficerCode();

			fwdEntity.setAppCurrentOfficerCode(applicationDTO.getOfrCode());
			fwdEntity.setAppStatus(AppStatusEnum.LOCK.getShortName());
			fwdEntity.setApprovedDateTime(null);

			ifvModuleFwdRepository.save(fwdEntity);

			S2IFVApplicationEntity ifccApplication = ifccApplicationRepo.findById(applicationDTO.getIfvId())
					.orElse(null);
			if (ifccApplication != null) {
				ifccApplication.setCheckerId(approvedOfrCode.intValue());
				ifccApplicationRepo.save(ifccApplication);
			}

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();
			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(applicationDTO.getOfrName());
			docHistoryEntity.setCreatedDate(new Date());
			docHistoryEntity.setGstStatus(AppStatusEnum.UN_LOCK.getShortName());
			docHistoryEntity.setHstCurrOfficerCode(applicationDTO.getOfrCode());
			docHistoryEntity.setHstComments(AppStatusEnum.UN_LOCK.getFullName());
			docHistoryEntity.setIpAddress(applicationDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);

			ifccApplicationRepo.deleteApprovedRecordFromProposalCheckerDetail(applicationDTO.getIfvId());

			return modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while revertApprovedDocument S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while revertApprovedDocument S2IFVApplicationEntity of id ."
							+ applicationDTO.getIfvId() + " " + msg + " ",
					e);
		}
	}

	@Override
	public Object findBankDetailsByAppNumber(String appNo) {
		logger.info("Started findBankDetailsByAppNumber() in MasterDbServiceImpl {} ", appNo);
		try {

			S2IFVApplicationEntity ifccApplication = ifccApplicationRepo.findByAppNumber(appNo).get(0);

			return masterCommonAPIClient.findBankDetailsByCifNumber(ifccApplication.getCifNumber());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in findBankDetailsByAppNumber() in ApplicationServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in findBankDetailsByAppNumber() in ApplicationServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public ApplicationDTO findByCifNumber(String cifNo) {
		logger.info("findByCifNumber() started in ApplicationServiceImpl for S2IFVApplicationEntity {} ", cifNo);
		try {
			Optional<S2IFVApplicationEntity> applicationEntity = ifccApplicationRepo.findByCifNumber(cifNo);
			if (applicationEntity.isPresent()) {
				List<ProposedSchemaDTO> dtos = proposedSchemaService.findAllByIfvId(applicationEntity.get().getIfvId());
				ApplicationDTO applicationDTO = modelMapper.map(applicationEntity, ApplicationDTO.class);
				dtos.forEach(e -> {
					e.setIfvId(null);
					e.setPrId(null);
				});
				applicationDTO.setProposedSchemaDTOs(dtos);
				List<AssistanceAppliedForDto> assistanceAppliedForDtos = proposedSchemaService
						.findAllAssistanceByIfvId(applicationEntity.get().getIfvId());
				assistanceAppliedForDtos.forEach(e -> {
					e.setIfvId(null);
					e.setId(null);
				});
				applicationDTO.setAssistanceAppliedFor(assistanceAppliedForDtos);
				applicationDTO.setIfvId(null);
				return applicationDTO;
			} else {
				return new ApplicationDTO();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching S2IFVApplicationEntity." + msg + "", e);
		}

	}

	@Override
	public Page<ApplicationDTO> getApplicationOnPage(int page, int size, String filters, String sorting) {
		logger.info("getApplicationOnPage() started in ApplicationServiceImpl for S2IFVApplicationEntity");
		try {

			Pageable pageable = PageRequest.of(page, size, SortingUtil.parseSort(sorting));

			Specification<S2IFVApplicationEntity> spec = new GenericSpecification<>(filters);

			Page<S2IFVApplicationEntity> entityPage = ifccApplicationRepo.findAll(spec, pageable);

			return entityPage.map(m -> modelMapper.map(m, ApplicationDTO.class));

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVApplicationEntities. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVApplicationEntities." + msg + " ", e);
		}

	}

	public Specification<S2IFVApplicationEntity> filterByStatusOrCheckerId(Long checkerId) {
		return (root, query, cb) -> {
			// Join S2IFVApplicationEntity with TblIfvModuleFwdEntity manually
			query.distinct(true); // Ensure distinct results
			// Join condition based on ifv_id, assuming ifv_id exists in both tables
			Root<TblIfvModuleFwdEntity> tblIfvModuleFwdRoot = query.from(TblIfvModuleFwdEntity.class);
			Predicate joinPredicate = cb.equal(root.get(IFV_ID), tblIfvModuleFwdRoot.get(IFV_ID));
			// Apply filtering predicates
			Predicate statusPredicate = cb.equal(tblIfvModuleFwdRoot.get(APP_STATUS), "AP");
			Predicate checkerIdPredicate = cb.equal(root.get("checkerId"), checkerId);
			// Combine predicates with OR condition
			return cb.and(joinPredicate, cb.or(statusPredicate, checkerIdPredicate));
		};
	}

	@Override
	public String getAddressByCifNumber(String appNo) {
		logger.info("Started getAddressByCifNumber() for application number: {}", appNo);
		try {
			return Optional.ofNullable(appNo).map(number -> ifccApplicationRepo.findByAppNumber(number))
					.filter(applications -> !applications.isEmpty()).map(applications -> applications.get(0))
					.map(application -> {
						var ifvName = application.getIfvName();
						var loiDetail = loIDetailRepo.findTop1ByIfvNameOrderByIdDesc(ifvName);
						return Optional.ofNullable(loiDetail).map(LoIDetailEntity::getAddressOfTheBank)
								.filter(StringUtils::hasText).orElseGet(
										() -> masterCommonAPIClient.getAddressByCifNumber(application.getCifNumber()));
					}).orElseThrow(() -> new DatabaseOperationException(
							"No application found for application number: " + appNo));
		} catch (Exception e) {
			throw new DatabaseOperationException("Error retrieving address for application number: " + appNo, e);
		}
	}

	private Pageable createPageable(int page, int size, String sorting) {
		Sort sort = parseSort(sorting);
		return PageRequest.of(page, size, sort);
	}

	private Sort parseSort(String sorting) {
		try {
			JsonNode sortNode = objectMapper.readTree(sorting);
			List<Sort.Order> orders = new ArrayList<>();
			if (sortNode.size() > 0) {
				for (JsonNode sortObject : sortNode) {
					String field = sortObject.get("id").asText();
					boolean descending = sortObject.has("desc") && sortObject.get("desc").asBoolean();
					orders.add(new Sort.Order(descending ? Sort.Direction.DESC : Sort.Direction.ASC, field));
				}
			} else {
				orders.add(Sort.Order.desc(IFV_ID));
			}

			return Sort.by(orders);
		} catch (JsonProcessingException e) {
			logger.error("Error parsing sort JSON", e);
			return Sort.unsorted();
		}
	}

	@Override
	public Page<ApplicationSummaryModel> getAllOnUserTypeOnPage(String userType, Long ofrCode, int page, int size,
			String filters, String sorting, String globalFilter, String status) {
		logger.info("getApplicationOnPage() started for userType: {}", userType);
		try {
			Pageable pageable = createPageable(page, size, sorting);
			Specification<S2IFVApplicationEntity> spec = createSpecification(filters, globalFilter, userType, ofrCode,
					status);
			Page<S2IFVApplicationEntity> entityPage = ifccApplicationRepo.findAll(spec, pageable);
			if (entityPage.isEmpty()) {
				return new PageImpl<>(Collections.emptyList(), pageable, 0);
			}
			Map<Long, TblIfvModuleFwdEntity> moduleMap = fetchModuleMap(entityPage);
			return mapToApplicationSummaryModel(entityPage, moduleMap, status);
		} catch (Exception e) {
			throw new DatabaseOperationException("Error fetching applications: " + e.getMessage(), e);
		}
	}

	private Map<Long, TblIfvModuleFwdEntity> fetchModuleMap(Page<S2IFVApplicationEntity> entityPage) {
		List<Long> ifvIds = entityPage.getContent().stream().map(S2IFVApplicationEntity::getIfvId)
				.collect(Collectors.toList());
		return ifvModuleFwdRepository.findByIfvIdIn(ifvIds).stream()
				.collect(Collectors.toMap(TblIfvModuleFwdEntity::getIfvId, Function.identity(), (e1, e2) -> e1));
	}

	private Page<ApplicationSummaryModel> mapToApplicationSummaryModel(Page<S2IFVApplicationEntity> entityPage,
			Map<Long, TblIfvModuleFwdEntity> moduleMap, String status) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);

		Set<Long> sIfvIds = entityPage.getContent().stream().map(S2IFVApplicationEntity::getIfvId)
				.collect(Collectors.toSet());

		List<S2IFVProposedSchemaEntity> proposedSchemaEntities = proposedSchemaRepository.findAllByIfvIdIn(sIfvIds);

		List<ApplicationSummaryModel> summaryModels = entityPage.getContent().stream()
				.map(projection -> createApplicationSummaryModel(projection, moduleMap, formatter,
						proposedSchemaEntities, status))
				.collect(Collectors.toList());

		if ("AP".equalsIgnoreCase(status)) {
			ApplicationSummaryModelSorter.sortByCreatedDateDesc(summaryModels);
		}

		return new PageImpl<>(summaryModels, entityPage.getPageable(), entityPage.getTotalElements());
	}

	private ApplicationSummaryModel createApplicationSummaryModel(S2IFVApplicationEntity projection,
			Map<Long, TblIfvModuleFwdEntity> moduleMap, DateTimeFormatter formatter,
			List<S2IFVProposedSchemaEntity> proposedSchemaEntities, String status) {

		ApplicationSummaryModel model = new ApplicationSummaryModel();
		model.setIfvId(projection.getIfvId());
		model.setIfvName(projection.getIfvName());
		model.setAppNumber(projection.getAppNumber());
		model.setSfb(determineBankType(projection));
		model.setSchemeName(getSchemeNameString(proposedSchemaEntities.stream()
				.filter(e -> e.getIfvId().equals(projection.getIfvId())).collect(Collectors.toList())));
		model.setCifNumber(projection.getCifNumber());
		TblIfvModuleFwdEntity moduleEntity = moduleMap.get(projection.getIfvId());
		if (moduleEntity != null) {
			updateModelWithModuleData(model, moduleEntity, projection.getCheckerId(), status, formatter);
		}
		return model;
	}

	private String determineBankType(S2IFVApplicationEntity projection) {
		if (projection.getIfvBankType() != null && projection.getIfvBankType().equalsIgnoreCase("UCB")) {
			return "UCB";
		} else if (projection.getIfvBankType() != null && projection.getIfvBankType().equalsIgnoreCase("RRB")) {
			return "RRB";
		} else if (projection.getSfb() != null && projection.getSfb().equalsIgnoreCase("Y")) {
			return "SFB";
		} else {
			return "Non SFB";
		}
	}

	private String getSchemeNameString(List<S2IFVProposedSchemaEntity> schemas) {
		return schemas.stream()
				.map(item -> item.getPrSchemeName() + " / " + item.getPrAmount().stripTrailingZeros().toPlainString())
				.collect(Collectors.joining(";   "));
	}

	private void updateModelWithModuleData(ApplicationSummaryModel model, TblIfvModuleFwdEntity obj, Integer checkerId,
			String status, DateTimeFormatter formatter) {
		model.setMakerName(obj.getCreatedBy());
		model.setStatus(AppStatusEnum.getFullNameByShortName(obj.getAppStatus()));
		String pendingWith = Stream
				.of(Pair.of(obj.getChecker1Id(), obj.getChecker1Name()),
						Pair.of(obj.getChecker2Id(), obj.getChecker2Name()),
						Pair.of(obj.getChecker3Id(), obj.getChecker3Name()),
						Pair.of(obj.getChecker4Id(), obj.getChecker4Name()))
				.filter(pair -> pair.getLeft() != null && pair.getLeft().equals(checkerId)).map(Pair::getRight)
				.findFirst().orElse("");
		model.setChecker(pendingWith);
		model.setChecker1(obj.getChecker1Name());
		model.setChecker2(obj.getChecker2Name());
		model.setChecker3(obj.getChecker3Name());
		model.setChecker4(obj.getChecker4Name());
		model.setApprovedBy("AP".equals(obj.getAppStatus()) ? pendingWith : "");

		if ("AP".equalsIgnoreCase(status)) {
			Date date = null;
			if (obj.getApprovedDateTime() != null) {
				date = Date.from(obj.getApprovedDateTime().atZone(ZoneId.systemDefault()).toInstant());
			} else if (obj.getChecker3FwdDate() != null) {
				date = Date.from(obj.getChecker3FwdDate().atZone(ZoneId.systemDefault()).toInstant());
			} else if (obj.getChecker2FwdDate() != null) {
				date = Date.from(obj.getChecker2FwdDate().atZone(ZoneId.systemDefault()).toInstant());
			} else if (obj.getChecker1FwdDate() != null) {
				date = Date.from(obj.getChecker1FwdDate().atZone(ZoneId.systemDefault()).toInstant());
			} else {
				date = obj.getCreatedDate();
			}
			model.setCreatedDate(formatDate(date, formatter));
		} else {
			model.setCreatedDate(formatDate(obj.getCreatedDate(), formatter));
		}

	}

	private String formatDate(Date date, DateTimeFormatter formatter) {
		return date == null ? "" : date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(formatter);
	}

	private Subquery<Long> createSchemeNameSubquery(CriteriaQuery<?> query, CriteriaBuilder cb, String likePattern) {
		Subquery<Long> subquery = query.subquery(Long.class);
		Root<S2IFVProposedSchemaEntity> schemaRoot = subquery.from(S2IFVProposedSchemaEntity.class);
		return subquery.select(schemaRoot.get(IFV_ID))
				.where(cb.or(cb.like(cb.lower(schemaRoot.get("prSchemeName")), likePattern),
						cb.like(cb.lower(schemaRoot.get("prAmount").as(String.class)), likePattern)));
	}

	private Specification<S2IFVApplicationEntity> createFilterPredicate(String field, String value, String status) {
		return (root, query, cb) -> {
			query.distinct(true);
			switch (field) {
			case IFV_NAME:
				return cb.like(cb.lower(root.get(IFV_NAME)), "%" + value.toLowerCase() + "%");
			case APP_NUMBER:
				return cb.like(cb.lower(root.get(APP_NUMBER)), "%" + value.toLowerCase() + "%");
			case CREATED_DATE:
				return handleDateFilter(root, cb, value, status, query);
			case "schemeName":
				return handleSchemeNameFilter(root, query, cb, value);
			case "status":
				return handleStatusFilter(root, query, cb, value);
			default:
				logger.warn("Unsupported filter field: {}", field);
				return null;
			}
		};
	}

	private Predicate handleDateFilter(Root<S2IFVApplicationEntity> root, CriteriaBuilder cb, String value,
			String status, CriteriaQuery<?> query) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
			Date parsedDate = dateFormat.parse(value);
			// Create Calendar instances for start and end of the day
			Calendar startCalendar = Calendar.getInstance();
			startCalendar.setTime(parsedDate);
			startCalendar.set(Calendar.HOUR_OF_DAY, 0);
			startCalendar.set(Calendar.MINUTE, 0);
			startCalendar.set(Calendar.SECOND, 0);
			startCalendar.set(Calendar.MILLISECOND, 0);
			Calendar endCalendar = (Calendar) startCalendar.clone();
			endCalendar.add(Calendar.DAY_OF_MONTH, 1);
			endCalendar.add(Calendar.MILLISECOND, -1);
			Date startDate = startCalendar.getTime();
			Date endDate = endCalendar.getTime();
			if ("AP".equalsIgnoreCase(status)) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
				LocalDate localDate = LocalDate.parse(value, formatter);
				LocalDateTime startDate1 = localDate.atStartOfDay();
				LocalDateTime endDate1 = localDate.atTime(23, 59, 59);
				Subquery<Long> subquery = query.subquery(Long.class);
				Root<TblIfvModuleFwdEntity> moduleRoot = subquery.from(TblIfvModuleFwdEntity.class);
				Predicate approvedDateTimeCheck = cb.between(moduleRoot.get("approvedDateTime"), startDate1, endDate1);
				Predicate approvedDateTimeNull = cb.isNull(moduleRoot.get("approvedDateTime"));
				Predicate checker3DateCheck = cb.between(moduleRoot.get("checker3FwdDate"), startDate1, endDate1);
				Predicate checker3DateNull = cb.isNull(moduleRoot.get("checker3FwdDate"));
				Predicate checker2DateCheck = cb.between(moduleRoot.get("checker2FwdDate"), startDate1, endDate1);
				Predicate checker2DateNull = cb.isNull(moduleRoot.get("checker2FwdDate"));
				Predicate checker1DateCheck = cb.between(moduleRoot.get("checker1FwdDate"), startDate1, endDate1);
				Predicate dateCondition = cb.or(approvedDateTimeCheck,
						cb.and(approvedDateTimeNull, cb.or(checker3DateCheck, cb.and(checker3DateNull,
								cb.or(checker2DateCheck, cb.and(checker2DateNull, checker1DateCheck))))));
				subquery.select(moduleRoot.get(IFV_ID)).where(cb.and(cb.equal(moduleRoot.get(IFV_ID), root.get(IFV_ID)),
						cb.equal(moduleRoot.get(APP_STATUS), "AP"), dateCondition));
				return cb.exists(subquery);
			} else {
				return cb.between(root.get(CREATED_DATE), startDate, endDate);
			}
		} catch (ParseException e) {
			logger.error("Invalid date format: {}", value);
			return cb.conjunction();
		}
	}

	private Predicate handleSchemeNameFilter(Root<S2IFVApplicationEntity> root, CriteriaQuery<?> query,
			CriteriaBuilder cb, String value) {
		Subquery<Long> subquery = query.subquery(Long.class);
		Root<S2IFVProposedSchemaEntity> schemaRoot = subquery.from(S2IFVProposedSchemaEntity.class);
		subquery.select(schemaRoot.get(IFV_ID)).where(cb.or(
				cb.like(cb.lower(schemaRoot.get("prSchemeName")), "%" + value.toLowerCase() + "%"),
				cb.like(cb.lower(schemaRoot.get("prAmount").as(String.class)), "%" + value.toLowerCase() + "%")));
		return cb.in(root.get(IFV_ID)).value(subquery);
	}

	private Specification<S2IFVApplicationEntity> createGlobalFilterPredicate(String globalFilter) {
		return (root, query, cb) -> {
			query.distinct(true);
			String likePattern = "%" + globalFilter.toLowerCase() + "%";
			return cb.or(cb.like(cb.lower(root.get(IFV_NAME)), likePattern),
					cb.like(cb.lower(root.get(APP_NUMBER)), likePattern),
					cb.like(cb.lower(
							cb.function("TO_CHAR", String.class, root.get(CREATED_DATE), cb.literal(DATE_FORMAT))),
							likePattern),
					cb.exists(createSchemeNameSubquery(query, cb, likePattern)),
					cb.exists(createStatusSubquery(query, cb, likePattern)));
		};
	}

	private Subquery<Long> createStatusSubquery(CriteriaQuery<?> query, CriteriaBuilder cb, String likePattern) {
		Subquery<Long> subquery = query.subquery(Long.class);
		Root<TblIfvModuleFwdEntity> moduleRoot = subquery.from(TblIfvModuleFwdEntity.class);
		return subquery.select(moduleRoot.get(IFV_ID))
				.where(cb.like(cb.lower(moduleRoot.get(APP_STATUS)), likePattern));
	}

	private Specification<S2IFVApplicationEntity> createSpecification(String filters, String globalFilter,
			String userType, Long ofrCode, String status) {
		Specification<S2IFVApplicationEntity> spec = Specification.where(null);
		// Add global filter
		if (StringUtils.hasText(globalFilter)) {
			spec = spec.and(createGlobalFilterPredicate(globalFilter));
		}
		// Add specific filters
		if (StringUtils.hasText(filters)) {
			try {
				JsonNode filterArray = objectMapper.readTree(filters);
				for (JsonNode filter : filterArray) {
					String field = filter.get("id").asText();
					String value = filter.get("value").asText();
					Specification<S2IFVApplicationEntity> fieldSpec = createFilterPredicate(field, value, status);
					if (fieldSpec != null) {
						spec = spec.and(fieldSpec);
					}
				}
			} catch (JsonProcessingException e) {
				logger.error("Error parsing filter JSON", e);
			}
		}
		// Add status filter
		if (StringUtils.hasText(status)) {
			spec = spec.and((root, query, cb) -> handleStatusFilter(root, query, cb, status));
		}
		// Add userType specific filters
		if ("9092".equals(userType)) {
			// No additional filter needed for this userType
		} else if (Arrays.asList("9128", "9093", "9095", "10489", "11314").contains(userType)) {
			spec = spec.and(filterByStatusOrCheckerId(ofrCode));
		} else {
			logger.warn("Unhandled userType: {}", userType);
		}
		return spec;
	}

	private Predicate handleStatusFilter(Root<S2IFVApplicationEntity> root, CriteriaQuery<?> query, CriteriaBuilder cb,
			String status) {
		Subquery<Long> subquery = query.subquery(Long.class);
		Root<TblIfvModuleFwdEntity> moduleRoot = subquery.from(TblIfvModuleFwdEntity.class);
		subquery.select(moduleRoot.get(IFV_ID)).where(cb.equal(moduleRoot.get(IFV_ID), root.get(IFV_ID)));
		if ("AP".equalsIgnoreCase(status)) {
			// If status is AP, get all values with AP status
			subquery.where(cb.and(cb.equal(moduleRoot.get(IFV_ID), root.get(IFV_ID)),
					cb.equal(moduleRoot.get(APP_STATUS), "AP")));
			return cb.exists(subquery);
		} else {
			// If status is not AP, get all values except AP
			subquery.where(cb.and(cb.equal(moduleRoot.get(IFV_ID), root.get(IFV_ID)),
					cb.notEqual(moduleRoot.get(APP_STATUS), "AP")));
			return cb.exists(subquery);
		}
	}

	@Override
	public String getDetailsOfEmptyData(Long ifvNo) {
		logger.info("getDetailsOfEmptyData() started in ApplicationServiceImpl for S2IFVApplicationEntity");
		try {

			StringBuilder message = new StringBuilder("");

			List<S2IFVFinancialHighlightsEntity> financialHighlightsEntities = financialHighlightsRepository
					.findByIfvId(ifvNo);
			if (CollectionUtils.isEmpty(financialHighlightsEntities)) {
				message.append("Financial Highlights, ");

			}

			List<S2IFVAssPastdisbEntity> assPastdisbEntities = pastdisbRepository.findByIfvId(ifvNo);
			if (CollectionUtils.isEmpty(assPastdisbEntities)) {
				message.append("Past Disbursements, ");

			}
			List<S2IFVAssOutstandingEntity> assOutstandingEntities = outstandingRepository.findByIfvId(ifvNo);
			if (CollectionUtils.isEmpty(assOutstandingEntities)) {
				message.append("Outstanding, ");

			}

			List<S2IFVAssRepaymentsEntity> repaymentsEntities = repaymentsRepository.findByIfvId(ifvNo);
			if (CollectionUtils.isEmpty(repaymentsEntities)) {
				message.append("Future Repayments of Existing Outstanding, ");

			}

			S2IFVTermConditionsDataEntity conditionsDataEntity = conditionsDataRepository.findByIfvId(ifvNo);
			if (conditionsDataEntity == null) {
				message.append("Major Terms and Conditions, ");

			}

			List<S2IFVPrincipalEntity> principalEntities = principalRepository.findByIfvId(ifvNo);
			if (CollectionUtils.isEmpty(principalEntities)) {
				message.append("Principal Repayment, ");

			}

			List<S2IFVProposedSchemaEntity> proposedSchemaEntities = proposedSchemaRepository.findByIfvId(ifvNo);

			proposedSchemaEntities.forEach(e -> {
				SanctionTermsConditionsEntity sanctionTermsConditionsEntity = sanctionTermsConditionsRepository
						.findByIfvIdAndPrId(ifvNo, e.getPrId());
				if (sanctionTermsConditionsEntity == null) {
					message.append("Terms and Conditions of Sanction for " + e.getPrSchemeName() + ", ");
				}

			});

			return message.toString();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while validating data. {}", msg);
			throw new DatabaseOperationException("Error Occurred while validating data.." + msg + " ", e);
		}
	}

	@Override
	public ApplicationDTO findSecondHighestByIfvId(Long ifvId) {
		logger.info("findSecondHighestByIfvId() started in ApplicationServiceImpl for S2IFVApplicationEntity {} ",
				ifvId);
		try {
			Optional<S2IFVApplicationEntity> applicationEntity = ifccApplicationRepo.findSecondHighestByIfvId(ifvId);
			if (applicationEntity.isPresent()) {
				List<ProposedSchemaDTO> dtos = proposedSchemaService.findAllByIfvId(applicationEntity.get().getIfvId());
				ApplicationDTO applicationDTO = modelMapper.map(applicationEntity, ApplicationDTO.class);
				applicationDTO.setProposedSchemaDTOs(dtos);
				return applicationDTO;
			} else {
				return new ApplicationDTO();
			}

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching S2IFVApplicationEntity." + msg + "", e);
		}

	}

	@Override
	public Map<String, Long> getStatusCounts(String userType, Long userCode) {

		logger.info("getStatusCounts() started in ApplicationServiceImpl for userCode");
		try {
			ApplicationRepository.StatusCount counts;
			if (!UserTypeEnum.MAKER.getUserType().equals(userType)) {
				counts = ifccApplicationRepo.getStatusCounts(userCode);
			} else {
				counts = ifccApplicationRepo.getStatusCounts();
			}

			return Map.of("APP", counts.getApprovedCount(), "NON", counts.getNonApprovedCount());
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while getStatusCounts S2IFVApplicationEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while getStatusCounts S2IFVApplicationEntity of id: " + msg + " ", e);
		}

	}

	@Override
	public List<IFVProposalCheckerDetailDTO> findAllCheckerDetailsByIfvId(Long ifvId) {
		logger.debug("Finding all IFVProposalCheckerDetail for ifvId: {}", ifvId);
		try {
			return Optional.ofNullable(checkerDetailRepo.findAllByIfvIdOrderByIdAsc(ifvId)).orElse(List.of()).stream()
					.map(detail -> modelMapper.map(detail, IFVProposalCheckerDetailDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			var errorMessage = String.format("Failed to fetch IFVProposalCheckerDetail for ifvId: %d", ifvId);
			throw new DatabaseOperationException(errorMessage, e);
		}
	}

	@Override
	public void sendEmail(Long ifvId) {

		byte[] fileData = reportService.generateAppraisalReportData(ifvId);
		FileRepositoryDTO fileRepositoryDTO = fileRepositoryService.findByFileIfvIdAndFileModule(ifvId, null);

		S2IFVApplicationEntity ifccApplication = ifccApplicationRepo.findById(ifvId).orElse(null);
		TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(ifvId);

		ApplicationDTO applicationDTO2 = modelMapper.map(ifccApplication, ApplicationDTO.class);
		TblIfvModuleFwdDTO fwdDTO = modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

		if (!profileService.isProfileActive(PROFILE_NAME)) {
			emailService.sendEmailWithRetry("APPROVE", applicationDTO2, fwdDTO, fileRepositoryDTO.getFileName(),
					fileData);
		}
	}

	@Override
	public ApplicationDTO findByIfvId(Long id) {
		logger.info("findByIfvId() started in ApplicationServiceImpl for S2IFVApplicationEntity {} ", id);
		try {
			List<S2IFVApplicationEntity> entities = ifccApplicationRepo.findByIfvId(id);
			if (CollectionUtils.isEmpty(entities)) {
				logger.error("Error Occurred while fetching  S2IFVApplicationEntity entity.");
				throw new EntityNotFoundException("s2IFVApplicationEntity", id);
			} else {
				S2IFVApplicationEntity applicationEntity = entities.get(0);
				return modelMapper.map(applicationEntity, ApplicationDTO.class);
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching data {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching Data " + msg + "", e);
		}

	}

	@Override
	public ApplicationDTO loadProposalData(CreateProposalRequest request) {

		logger.info("loadProposalData started for CIF : {}", request.getCifNumber());

		try {

			Optional<S2IFVApplicationEntity> applicationEntity = ifccApplicationRepo
					.findByCifNumber(request.getCifNumber());

			ApplicationDTO applicationDTO = applicationEntity.map(entity -> {
				ApplicationDTO dto = modelMapper.map(entity, ApplicationDTO.class);
				dto.setIfvId(null);
				dto.setBankAppRefNos(null);
				return dto;
			}).orElse(new ApplicationDTO());

			if (CollectionUtils.isEmpty(request.getAppRefIds())) {
				return populateExistingProposalData(applicationDTO, applicationEntity);
			}

			return populateAcceptedApplicationData(applicationDTO, request);

		} catch (Exception e) {

			logger.error("Error occurred while fetching proposal data", e);

			throw new DatabaseOperationException("Error occurred while fetching proposal data", e);
		}
	}

	private ApplicationDTO populateExistingProposalData(ApplicationDTO applicationDTO,
			Optional<S2IFVApplicationEntity> applicationEntity) {

		if (applicationEntity.isEmpty()) {
			return applicationDTO;
		}

		Long ifvId = applicationEntity.get().getIfvId();

		List<ProposedSchemaDTO> proposedSchemes = proposedSchemaService.findAllByIfvId(ifvId);

		proposedSchemes.forEach(e -> {
			e.setIfvId(null);
			e.setPrId(null);
		});

		applicationDTO.setProposedSchemaDTOs(proposedSchemes);

		List<AssistanceAppliedForDto> assistanceAppliedForDtos = proposedSchemaService.findAllAssistanceByIfvId(ifvId);

		assistanceAppliedForDtos.forEach(e -> {
			e.setIfvId(null);
			e.setId(null);
		});

		applicationDTO.setAssistanceAppliedFor(assistanceAppliedForDtos);

		return applicationDTO;
	}

	private ApplicationDTO populateAcceptedApplicationData(ApplicationDTO applicationDTO,
			CreateProposalRequest request) {

		List<IfvBankRefinanceApplication> bankApplications = ifvBankRefinanceApplicationRepository
				.findByAppRefIdIn(request.getAppRefIds());

		if (bankApplications.isEmpty()) {
			return applicationDTO;
		}

		List<Long> applicationIds = bankApplications.stream().map(IfvBankRefinanceApplication::getId).toList();

		Map<Long, List<IfvBankRefinanceProposal>> proposalMap = ifvBankRefinanceProposalRepository
				.findByApplicationIdIn(applicationIds).stream()
				.collect(Collectors.groupingBy(IfvBankRefinanceProposal::getApplicationId));

		List<ProposedSchemaDTO> proposedSchemas = new ArrayList<>();

		Map<String, AssistanceAppliedForDto> assistanceMap = new LinkedHashMap<>();

		for (IfvBankRefinanceApplication application : bankApplications) {

			List<IfvBankRefinanceProposal> proposals = proposalMap.getOrDefault(application.getId(),
					Collections.emptyList());

			for (IfvBankRefinanceProposal proposal : proposals) {

				ProposedSchemaDTO schemeDto = new ProposedSchemaDTO();

				schemeDto.setIfvId(null);
				schemeDto.setPrId(null);

				schemeDto.setPrSchemeName(application.getCustomSchemeName());
				schemeDto.setPrSchemecode(application.getSchemeCode());
				schemeDto.setSchemeShortName(application.getSchemeShortName());

				schemeDto.setPrFundcode(application.getFundCode());
				schemeDto.setPrFundname(application.getFundDescription());

				schemeDto.setPrAmount(proposal.getRefinanceAmount());

				schemeDto.setPrRoi(proposal.getRateOfInterest());

				if (proposal.getTenureInMonths() != null) {
					schemeDto.setPrTenure(BigDecimal.valueOf(proposal.getTenureInMonths()));
				}

				schemeDto.setPrPrincipalRepayment(proposal.getPrincipalRepayment());

				schemeDto.setPrMoratoriumPeriod(proposal.getMoratoriumMonths());

				schemeDto.setInterestType(proposal.getRateType());

				schemeDto.setBenchMark(proposal.getBenchmark());

				schemeDto.setInterestReset(proposal.getInterestReset());

				schemeDto.setPrMaturityDate(
						proposal.getMaturityDate() != null ? java.sql.Date.valueOf(proposal.getMaturityDate()) : null);

				if (proposal.getSpread() != null) {
					schemeDto.setSpread(proposal.getSpread().stripTrailingZeros().toPlainString());
				}

				proposedSchemas.add(schemeDto);

				// Asistance Applied
				String assistanceKey = application.getFundCode() + "_" + application.getSchemeCode();

				AssistanceAppliedForDto assistanceDto = assistanceMap.computeIfAbsent(assistanceKey, key -> {

					AssistanceAppliedForDto dto = new AssistanceAppliedForDto();

					dto.setId(null);
					dto.setIfvId(null);

					dto.setSchemeCode(application.getSchemeCode());
					dto.setSchemeName(application.getCustomSchemeName());

					dto.setFundCode(application.getFundCode());
					dto.setFundName(application.getFundDescription());

					dto.setAmount(BigDecimal.ZERO);

					return dto;
				});

				assistanceDto.setAmount(assistanceDto.getAmount()
						.add(proposal.getRefinanceAmount() == null ? BigDecimal.ZERO : proposal.getRefinanceAmount()));
			}
		}

		applicationDTO.setProposedSchemaDTOs(proposedSchemas);
		applicationDTO.setAssistanceAppliedFor(new ArrayList<>(assistanceMap.values()));

		IfvBankRefinanceApplication firstApplication = bankApplications.get(0);

		applicationDTO.setCifNumber(firstApplication.getCifNumber());

		applicationDTO.setIfvBankType(firstApplication.getTypeOfBank());

		applicationDTO.setBankAppRefNos(request.getAppRefIds());

		return applicationDTO;
	}
}