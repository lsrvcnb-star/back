package com.sidbi.ifv.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.MinutesColendingLimitDTO;
import com.sidbi.ifv.dto.MinutesInterestResetDTO;
import com.sidbi.ifv.dto.MinutesOtherItemsDTO;
import com.sidbi.ifv.entity.MinutesColendingLimit;
import com.sidbi.ifv.service.impl.MinutesAdditionalDetailService;

import lombok.RequiredArgsConstructor;

@RestController
@CrossOrigin
@RequestMapping("/minutes/additional-details/")
@RequiredArgsConstructor
public class MinutesAdditionalDetailController {

	private final MinutesAdditionalDetailService service;

	@GetMapping("getColendingLimits/{minuteSanctionId}")
	public ResponseEntity<List<MinutesColendingLimitDTO>> getColendingLimits(@PathVariable Integer minuteSanctionId) {

		List<MinutesColendingLimitDTO> limits = service.getByMinuteSanctionId(minuteSanctionId);

		return ResponseEntity.ok(limits);
	}

	@PostMapping("saveColendingLimits/{minuteSanctionId}")
	public ResponseEntity<String> saveColendingLimits(@PathVariable Integer minuteSanctionId,
			@RequestBody List<MinutesColendingLimitDTO> limits) {

		service.saveColendingLimits(minuteSanctionId, limits);
		return ResponseEntity.ok("Colending limits saved successfully");
	}

	@DeleteMapping("deleteColendingLimits/{id}")
	public ResponseEntity<String> deleteColendingLimits(@PathVariable Long id) {

		service.deleteById(id);
		return ResponseEntity.ok("Colending limits deleted successfully");
	}

	@PostMapping("saveInterestResets/{minuteSanctionId}")
	public ResponseEntity<String> saveInterestResets(@PathVariable Integer minuteSanctionId,
			@RequestBody List<MinutesInterestResetDTO> resets) {

		service.saveInterestResets(minuteSanctionId, resets);
		return ResponseEntity.ok("Interest reset details saved successfully");
	}

	@GetMapping("getInterestResets/{minuteSanctionId}")
	public ResponseEntity<List<MinutesInterestResetDTO>> getInterestResets(@PathVariable Integer minuteSanctionId) {

		return ResponseEntity.ok(service.getInterestResetsByMinuteSanctionId(minuteSanctionId));
	}

	@DeleteMapping("deleteInterestReset/{id}")
	public ResponseEntity<String> deleteInterestReset(@PathVariable Long id) {
		service.deleteInterestResetsById(id);
		return ResponseEntity.ok("Interest reset record deleted successfully");
	}

	@PostMapping("saveOtherItems/{minuteSanctionId}")
	public ResponseEntity<String> saveOtherItems(@PathVariable Integer minuteSanctionId,
			@RequestBody List<MinutesOtherItemsDTO> dtos) {

		service.saveOtherItems(minuteSanctionId, dtos);
		return ResponseEntity.ok("Other items saved successfully");
	}

	@GetMapping("fetchOtherItems/{minuteSanctionId}")
	public ResponseEntity<List<MinutesOtherItemsDTO>> fetch(@PathVariable Integer minuteSanctionId) {

		return ResponseEntity.ok(service.fetchOtherItems(minuteSanctionId));
	}

	@DeleteMapping("deleteOtherItemsById/{id}")
	public ResponseEntity<String> deleteOtherItemsById(@PathVariable Long id) {

		service.deleteOtherItemsById(id);
		return ResponseEntity.ok("Other item deleted successfully");
	}

}
