package com.sidbi.ifv.services;

import java.util.List;

import org.springframework.data.domain.Page;

import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.IfvProposalLoIDto;

public interface IfvProposalLoIService extends CrudService<IfvProposalLoIDto, Long> {

	List<IfvProposalLoIDto> findAllByIfvId(Long ifvId);

	Page<IfvProposalLoIDto> getAllOnUserTypeOnPage(String userType, String userCode, int page, int size, String filters,
			String sorting, String globalFilter, String status);

	FileRepositoryDTO getLoIDocumentByPropLoIId(Long id);

	List<IfvProposalLoIDto> fetchLoIDetailsByPropId(Long id);

	Long getCountOfLoIs();

}
