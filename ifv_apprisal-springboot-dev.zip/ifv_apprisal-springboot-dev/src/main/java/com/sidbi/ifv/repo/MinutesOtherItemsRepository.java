package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.MinutesOtherItems;

public interface MinutesOtherItemsRepository extends JpaRepository<MinutesOtherItems, Long> {

	List<MinutesOtherItems> findByMinuteSanctionId(Integer minuteSanctionId);

	void deleteByMinuteSanctionId(Integer minuteSanctionId);
}