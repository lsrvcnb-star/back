package com.sidbi.ifv.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplianceResponseDto {

	private String uploadByEmail;

	private String bankName;

	private String cifNumber;

	private String appRefNo;

	private String complianceType;

	private String fileName;

}
