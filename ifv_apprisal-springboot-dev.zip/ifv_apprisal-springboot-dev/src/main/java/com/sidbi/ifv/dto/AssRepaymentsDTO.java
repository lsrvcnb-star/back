package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class AssRepaymentsDTO {

	private Long rpId;

	private Long ifvId;

	private String rpRefinanceAcc;

	private String rpRepaymentTrack;

	private Integer rpPeriodfy;

	private BigDecimal rpQ1;

	private BigDecimal rpQ2;

	private BigDecimal rpQ3;

	private BigDecimal rpQ4;

	private BigDecimal rpTotal;

	private String rpType;

}
