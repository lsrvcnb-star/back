package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.SfbAggregateDTO;
import com.sidbi.ifv.services.SfbAggregateService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcaggr")
public class SfbAggregateController {
	
	private static final Logger logger = LoggerFactory.getLogger(SfbAggregateController.class);

	@Autowired
	private SfbAggregateService s2ifccSfbAggregateService ;
	
	@GetMapping("/get/{id}")
	public ResponseEntity<SfbAggregateDTO> findById(@PathVariable Long id) {
		logger.info("findById() started SfbAggregateController {} ",id);
		SfbAggregateDTO s2ifccSfbAggregateDTO = s2ifccSfbAggregateService.findById(id);
		return ResponseEntity.ok(s2ifccSfbAggregateDTO);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<SfbAggregateDTO>> findAll() {
		logger.info("findAll() started SfbAggregateController ");
		List<SfbAggregateDTO> list = s2ifccSfbAggregateService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<SfbAggregateDTO> save(@RequestBody SfbAggregateDTO s2ifccSfbAggregateDTO) {
		logger.info("save() started SfbAggregateController {} ",s2ifccSfbAggregateDTO);
		SfbAggregateDTO savedS2ifccSfbAggregateDTO  = s2ifccSfbAggregateService.save(s2ifccSfbAggregateDTO);
        return ResponseEntity.ok(savedS2ifccSfbAggregateDTO);
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<SfbAggregateDTO> update(@PathVariable Long id,
                                                               @RequestBody SfbAggregateDTO s2ifccSfbAggregateDTO) {
    	logger.info("update() started SfbAggregateController {} ",s2ifccSfbAggregateDTO);
    	SfbAggregateDTO updatedS2ifccSfbAggregateDTO  = s2ifccSfbAggregateService.update(id, s2ifccSfbAggregateDTO);
        return ResponseEntity.ok(updatedS2ifccSfbAggregateDTO);
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
    	logger.info("delete() started SfbAggregateController {} ",id);
    	s2ifccSfbAggregateService.delete(id);
        return ResponseEntity.noContent().build();
    }
	

}
