package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.SchemaDTO;
import com.sidbi.ifv.entity.S2IFVSchemaEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.SchemaRepository;
import com.sidbi.ifv.services.SchemaService;

@Service
public class SchemaServiceImpl implements SchemaService {

	private static final Logger logger = LoggerFactory.getLogger(SchemaServiceImpl.class);

	@Autowired
	private SchemaRepository s2ifccSchemaRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<SchemaDTO> findAll() {
		logger.info("findAll() started in SchemaServiceImpl for S2IFVSchemaEntity");
		try {
			List<S2IFVSchemaEntity> list = s2ifccSchemaRepository.findAll();
			return list.stream().map(ifccsfbcommon -> modelMapper.map(ifccsfbcommon, SchemaDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVSchemaEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVSchemaEntity entities." + msg + " ", e);
		}
	}

	@Override
	public SchemaDTO findById(Integer id) {
		logger.info("findById() started in SchemaServiceImpl for S2IFVSchemaEntity {} ", id);
		try {
			S2IFVSchemaEntity s2ifccSchemaEntity = s2ifccSchemaRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVSchemaEntity", id));
			return modelMapper.map(s2ifccSchemaEntity, SchemaDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFVSchemaEntity entity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while fetching  S2IFVSchemaEntity entity." + msg + " ",
					e);
		}
	}

	@Override
	public SchemaDTO save(SchemaDTO s2ifccSchemaDTO) {
		logger.info("save() started in SchemaServiceImpl for S2IFVSchemaEntity {} ", s2ifccSchemaDTO);
		try {
			S2IFVSchemaEntity s2ifccSchemaEntity = modelMapper.map(s2ifccSchemaDTO, S2IFVSchemaEntity.class);
			s2ifccSchemaRepository.save(s2ifccSchemaEntity);
			return modelMapper.map(s2ifccSchemaEntity, SchemaDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVSchemaEntity entity.{} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVSchemaEntity entity." + msg + " ",
					e);
		}
	}

	@Override
	public SchemaDTO update(Integer id, SchemaDTO s2ifccSchemaDTO) {
		logger.info("update() started in SchemaServiceImpl for S2IFVSchemaEntity {} {} ", id, s2ifccSchemaDTO);
		try {
			S2IFVSchemaEntity existings2ifccSchemaEntity = s2ifccSchemaRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVSchemaEntity", id));
			BeanUtils.copyProperties(s2ifccSchemaDTO, existings2ifccSchemaEntity);
			s2ifccSchemaRepository.save(existings2ifccSchemaEntity);
			return modelMapper.map(existings2ifccSchemaEntity, SchemaDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVSchemaEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVSchemaEntity entity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Integer id) {
		logger.info("delete() started in SchemaServiceImpl for S2IFVSchemaEntity {} ", id);
		try {
			S2IFVSchemaEntity existings2ifccSchemaEntity = s2ifccSchemaRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVSchemaEntity", id));
			s2ifccSchemaRepository.delete(existings2ifccSchemaEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVSchemaEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVSchemaEntity entity of id ." + id + " " + msg + " ", e);
		}

	}
}