package com.sidbi.ifv.dto;

import java.time.LocalDateTime;
import java.util.Map;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class FetchBeneficiaryRequest {

	@Min(value = 0, message = "Page number must be 0 or greater")
	private int page = 0;

	@Min(value = 1, message = "Size must be at least 1")
	@Max(value = 100, message = "Size must not exceed 100")
	private int size = 10;

	@Pattern(regexp = "^[a-zA-Z0-9]{0,10}$", message = "CIF number must be alphanumeric and up to 10 characters")
	private String cifNumber;

	@Pattern(regexp = "^[a-zA-Z0-9./_()\\- ]*$", message = "Bank name can contain alphanumeric characters and . / - _ ( ) only")
	@Size(max = 100, message = "Bank name must not exceed 100 characters")
	private String bankName;

	private String bnRefNo;

	private String fileName;

	private String status;

	private LocalDateTime uploadDateTime;

	private String sortField = "uploadDateTime";

	private String sortDirection = "desc";

	@Pattern(regexp = "^[a-zA-Z0-9./_()\\- ]*$", message = "Global filter can contain alphanumeric characters and . / - _ ( ) only")
	@Size(max = 255, message = "Global filter must not exceed 255 characters")
	private String globalFilter;

	private Map<String, String> filters;
}