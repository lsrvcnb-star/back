package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.UcbCriteriaParameterDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.UcbCriteriaParameterService;

@RestController
@CrossOrigin
@RequestMapping("/ucb-criteria-parameter")
public class UcbCriteriaParameterController extends CrudController<UcbCriteriaParameterDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(UcbCriteriaParameterController.class);

	@Autowired
	private UcbCriteriaParameterService service;

	@Override
	public CrudService<UcbCriteriaParameterDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<UcbCriteriaParameterDTO>> getUcbCriteriaIfvId(@PathVariable Long ifvId) {
		logger.info("getUcbFincOnIfvId() started in UcbCriteriaParameterController ");
		List<UcbCriteriaParameterDTO> dtos = service.findAllByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}
}
