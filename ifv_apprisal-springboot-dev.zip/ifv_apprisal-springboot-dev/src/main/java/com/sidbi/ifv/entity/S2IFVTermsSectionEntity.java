package com.sidbi.ifv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="S2_IFV_TERMSSECTION")
public class S2IFVTermsSectionEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TERM_ID")
	private Long termId;
	
	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "TERM_SANCTION_CODE")
	private String termSectionCode;
	
	@Column(name = "TERM_SANCTION_DESC")
	private String termSectionDesc;
	
	@Column(name = "TERM_SANCTIONLIST_TYPE")
	private String termSectionlistType;
	
	@Column(name = "TERMS_SANCTION_CONDITION_ORDER")
	private String termsSanctionConditionOrder;
	
	@Column(name = "TERMS_EDITABLE_FLAG")
	private String termsEditableFlag;
	
	@Column(name = "TERMS_CONDITION_ORDER")
	private String termsConditionOrder;
	
	@Column(name = "TERM_CONDITION_ORDER")
	private String termConditionOrder;
	
	@Column(name = "TERM_EDITABLE_FLAG")
	private String termEditableFlag;
	
	@Column(name = "TERM_SANCTION_CONDITION_ORDER")
	private String termSectionlistConditionOrder;

}