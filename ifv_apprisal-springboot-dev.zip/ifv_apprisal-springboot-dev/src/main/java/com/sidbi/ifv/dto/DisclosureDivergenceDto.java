package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class DisclosureDivergenceDto {

	private Long id;

	private Long ifvId;

	private String particulars;

	private BigDecimal amount;

	private String disType;

	private String remarks;
}
