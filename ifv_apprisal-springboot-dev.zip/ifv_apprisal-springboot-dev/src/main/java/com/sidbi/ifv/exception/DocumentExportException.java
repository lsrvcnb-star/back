package com.sidbi.ifv.exception;

public class DocumentExportException extends Exception {
	private static final long serialVersionUID = 1L;

	public DocumentExportException(String message, Throwable cause) {
		super(message, cause);
	}
}