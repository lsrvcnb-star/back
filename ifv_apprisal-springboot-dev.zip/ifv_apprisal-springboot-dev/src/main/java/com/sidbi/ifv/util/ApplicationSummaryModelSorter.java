package com.sidbi.ifv.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.sidbi.ifv.model.ApplicationSummaryModel;

public class ApplicationSummaryModelSorter {

	private ApplicationSummaryModelSorter() {
	}

	// Comparator for sorting ApplicationSummaryModel by createdDate
	public static final Comparator<ApplicationSummaryModel> CREATED_DATE_DESC = new Comparator<ApplicationSummaryModel>() {
		private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

		@Override
		public int compare(ApplicationSummaryModel app1, ApplicationSummaryModel app2) {
			try {
				// Handle null dates
				if (app1.getCreatedDate() == null && app2.getCreatedDate() == null) {
					return 0;
				}
				if (app1.getCreatedDate() == null) {
					return 1;
				}
				if (app2.getCreatedDate() == null) {
					return -1;
				}
				// Parse and compare dates
				return dateFormat.parse(app2.getCreatedDate()).compareTo(dateFormat.parse(app1.getCreatedDate()));
			} catch (ParseException e) {
				throw new IllegalArgumentException("Invalid date format. Expected dd-MM-yyyy", e);
			}
		}
	};

	public static void sortByCreatedDateDesc(List<ApplicationSummaryModel> applications) {
		Collections.sort(applications, CREATED_DATE_DESC);
	}

}