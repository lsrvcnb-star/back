package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.services.CrudService;

@RestController
@CrossOrigin
public abstract class CrudController<E, I> {

	private Logger logger = LoggerFactory.getLogger(CrudController.class);

	@Autowired
	private CrudService<E, I> crudService;

	public abstract CrudService<E, I> getCrudService();

	@GetMapping("/get/{id}")
	public ResponseEntity<E> findById(@PathVariable I id) {
		logger.info("findById() started CrudController {} ", id);
		return ResponseEntity.ok(crudService.findById(id));
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<E>> findAll() {
		logger.info("findAll() started CrudController ");
		List<E> list = crudService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<E> save(@RequestBody E dto) {
		logger.info("save() started CrudController {} ", dto);
		E savefDto = crudService.save(dto);
		return ResponseEntity.ok(savefDto);

	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<E>> saveAll(@RequestBody List<E> dtos) {
		logger.info("save() started CrudController {} ", dtos);
		List<E> savefDtos = crudService.saveAll(dtos);
		return ResponseEntity.ok(savefDtos);

	}

	@PostMapping("/update/{id}")
	public ResponseEntity<E> update(@PathVariable I id, @RequestBody E dto) {
		logger.info("update() started CrudController {} ", dto);
		E updatedDto = crudService.update(id, dto);
		return ResponseEntity.ok(updatedDto);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable I id) {
		logger.info("delete() started CrudController {} ", id);
		crudService.delete(id);
		return ResponseEntity.noContent().build();
	}

}