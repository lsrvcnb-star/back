package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.ProfileBdDTO;
import com.sidbi.ifv.entity.S2IFVProfileBdEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.ProfileDbRepository;
import com.sidbi.ifv.services.ProfileDbService;

@Service
public class ProfileDbServiceImpl implements ProfileDbService {

	private static final Logger logger = LoggerFactory.getLogger(ProfileDbServiceImpl.class);

	@Autowired
	private ProfileDbRepository profileDbRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<ProfileBdDTO> findAll() {
		logger.info("findAll() started in ProfileDbServiceImpl of S2IFVProfileDbEntity");
		try {
			List<S2IFVProfileBdEntity> list = profileDbRepository.findAll();
			return !list.isEmpty()
					? list.stream().map(profileDbEntity -> modelMapper.map(profileDbEntity, ProfileBdDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVProfileDbEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVProfileDbEntities." + msg + " ", e);
		}
	}

	@Override
	public ProfileBdDTO findById(Long id) {
		logger.info("findById() started in ProfileDbServiceImpl for S2IFVProfileDbEntity {} ", id);
		S2IFVProfileBdEntity s2ifvProfileDbEntity = profileDbRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("s2IFVProfileDbEntity", id));
		return modelMapper.map(s2ifvProfileDbEntity, ProfileBdDTO.class);
	}

	@Override
	public ProfileBdDTO save(ProfileBdDTO profileDbDTO) {

		logger.info("save() started in ProfileDbServiceImpl for S2IFVProfileDbEntity {} ", profileDbDTO);
		try {
			profileDbDTO.setDateOfAction(new Date());
			S2IFVProfileBdEntity s2ifvProfileDbEntity = modelMapper.map(profileDbDTO, S2IFVProfileBdEntity.class);
			profileDbRepository.save(s2ifvProfileDbEntity);
			return modelMapper.map(s2ifvProfileDbEntity, ProfileBdDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVProfileDbEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVProfileDbEntity." + msg + " ", e);
		}
	}

	@Override
	public ProfileBdDTO update(Long id, ProfileBdDTO profileDbDTO) {
		logger.info("update() started in ProfileDbServiceImpl for S2IFVProfileDbEntity {} {} ", id, profileDbDTO);
		try {
			S2IFVProfileBdEntity existings2ifvProfileDbEntity = profileDbRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVProfileDbEntity", id));
			BeanUtils.copyProperties(profileDbDTO, existings2ifvProfileDbEntity);
			profileDbRepository.save(existings2ifvProfileDbEntity);
			return modelMapper.map(existings2ifvProfileDbEntity, ProfileBdDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVProfileDbEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVProfileDbEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in ProfileDbServiceImpl for S2IFVProfileDbEntity {} ", id);
		try {
			S2IFVProfileBdEntity existings2ifvProfileDbEntity = profileDbRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVProfileDbEntity", id));
			profileDbRepository.delete(existings2ifvProfileDbEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVProfileDbEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVProfileDbEntity of id ." + id + " " + msg, e);
		}
	}

	@Override
	public List<ProfileBdDTO> saveAll(List<ProfileBdDTO> profileDbDTOs) {
		logger.info("saveAll() started in ProfileDbServiceImpl for List of S2IFVProfileDbEntity");
		try {
			Date currentDate = new Date();
			profileDbDTOs.forEach(profileDto -> profileDto.setDateOfAction(currentDate));
			List<S2IFVProfileBdEntity> profileDbEntitiesToSave = profileDbDTOs.stream()
					.map(profileDbDTO -> modelMapper.map(profileDbDTO, S2IFVProfileBdEntity.class))
					.collect(Collectors.toList());
			List<S2IFVProfileBdEntity> savedProfileDbEntities = profileDbRepository.saveAll(profileDbEntitiesToSave);

			return savedProfileDbEntities.stream()
					.map(profileDbEntity -> modelMapper.map(profileDbEntity, ProfileBdDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVProfileDbEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all S2IFVProfileDbEntities." + msg + " ",
					e);
		}
	}

	@Override
	public List<ProfileBdDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in ProfileDbServiceImpl ");
		try {
			List<S2IFVProfileBdEntity> listProfileDbEntities = profileDbRepository.findByIfvId(ifvId);
			return (listProfileDbEntities != null && !listProfileDbEntities.isEmpty())
					? listProfileDbEntities.stream().sorted(Comparator.comparing(S2IFVProfileBdEntity::getPrCode))
							.map(profileDbEntity -> modelMapper.map(profileDbEntity, ProfileBdDTO.class)).collect(
									Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVProfileDbEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVProfileDbEntities  based on IfvId." + ifvId + " " + msg, e);

		}
	}

}
