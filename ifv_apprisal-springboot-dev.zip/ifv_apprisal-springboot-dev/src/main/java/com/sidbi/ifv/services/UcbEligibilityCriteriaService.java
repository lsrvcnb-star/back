package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.UcbEligibilityCriteriaDTO;

public interface UcbEligibilityCriteriaService extends CrudService<UcbEligibilityCriteriaDTO, Long> {

	List<UcbEligibilityCriteriaDTO> findAllByIfvId(Long ifvId);

}
