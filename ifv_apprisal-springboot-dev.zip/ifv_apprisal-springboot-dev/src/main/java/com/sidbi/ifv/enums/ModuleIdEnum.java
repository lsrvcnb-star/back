package com.sidbi.ifv.enums;

public enum ModuleIdEnum {

	
	APPRAISAL(1000101, "Appraisal"), ALCO(1000102, "Alco"), MINUTES(1000103, "Minutes");

	private final long moduleId;

	private final String moduleName;

	ModuleIdEnum(long moduleId, String moduleName) {
		this.moduleId = moduleId;
		this.moduleName = moduleName;
	}

	public long getModuleId() {
		return moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

}
