package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.DisclosureDivergenceDto;

public interface DisclosureDivergenceService extends CrudService<DisclosureDivergenceDto, Long> {
	List<DisclosureDivergenceDto> findByIfvId(Long ifvId);
}
