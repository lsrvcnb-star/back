package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.MasterRepositoryDTO;

public interface MasterRepositoryService {
	
	List<MasterRepositoryDTO> findAll();

	MasterRepositoryDTO findById(Long id);

	MasterRepositoryDTO save(MasterRepositoryDTO masterRepositoryDTO);

	MasterRepositoryDTO update(Long id, MasterRepositoryDTO masterRepositoryDTO);
	
	void delete(Long id);

	List<MasterRepositoryDTO> saveAll(List<MasterRepositoryDTO> masterRepositoryDTOs);

	List<MasterRepositoryDTO> findAllByIfvId(Long ifvId);

	List<MasterRepositoryDTO> findAllByMstParticulars(String mstParticulars);	

}
