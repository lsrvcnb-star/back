package com.sidbi.ifv.controller;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.config.JwtTokenUtil;
import com.sidbi.ifv.dto.BeneficiaryDocsResponse;
import com.sidbi.ifv.dto.BeneficiaryLoginData;
import com.sidbi.ifv.dto.BeneficiaryLoginRequestDTO;
import com.sidbi.ifv.dto.BeneficiarySummaryResponse;
import com.sidbi.ifv.dto.CommonRequestDto;
import com.sidbi.ifv.dto.CustomerDto;
import com.sidbi.ifv.dto.FetchBeneficiaryRequest;
import com.sidbi.ifv.dto.FetchDsfSubmittedBeneficiaryRequest;
import com.sidbi.ifv.dto.IfvBeneficiaryAppDto;
import com.sidbi.ifv.dto.IfvBeneficiaryDetailsDto;
import com.sidbi.ifv.dto.ReturnBankForwardedDocumentRequest;
import com.sidbi.ifv.dto.UploadAndValidateBeneficiaryRequestDTO;
import com.sidbi.ifv.dto.UploadJobResponse;
import com.sidbi.ifv.dto.ValidationError;
import com.sidbi.ifv.dto.ValidationJobStatusResponse;
import com.sidbi.ifv.dto.VerticalDto;
import com.sidbi.ifv.model.JwtResponse;
import com.sidbi.ifv.service.impl.BeneficiaryValidateService;
import com.sidbi.ifv.services.BenificiaryService;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.FileStorageService;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.util.ApiResponse;
import com.sidbi.ifv.util.CryptoUtil;
import com.sidbi.ifv.util.JobIdGenerator;
import com.sidbi.ifv.util.ProfileService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin
@RequestMapping("/beneficiary")
@Slf4j
public class BeneficiaryDetailsController {

	@Autowired
	private BenificiaryService benificiaryService;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private MasterDbService masterDbService;

	@Autowired
	private CryptoUtil cryptoUtil;

	@Autowired
	private FileStorageService fileStorageService;

	@Autowired
	private JobIdGenerator jobIdGenerator;

	@Autowired
	private BeneficiaryValidateService beneficiaryValidateService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private ProfileService profileService;

	@PostMapping("/bankLogin")
	public ResponseEntity<JwtResponse> login(@Valid @RequestBody BeneficiaryLoginRequestDTO loginRequest) {
		BeneficiaryLoginData loginData = benificiaryService.authenticate(loginRequest);

		String token = jwtTokenUtil.generateTokenByUserName(loginData.getUserId());

		JwtResponse response = new JwtResponse(token, loginData, "Login successful");

		return ResponseEntity.ok(response);
	}

	@PostMapping("/forwardBeneficiaryData")
	public ResponseEntity<ApiResponse<Object>> forwardBeneficiaryDataToDFS(@RequestParam String jobId) {

		ApiResponse<Object> response = new ApiResponse<>();

		// async processing
		benificiaryService.forwardBeneficiaryDataToDFS(jobId);

		response.setSuccess(true);
		response.setMessage(jobId);

		return ResponseEntity.ok(response);
	}

	@GetMapping("/processingStatus/{jobId}")
	public ResponseEntity<Map<String, Object>> getProcessingStatus(@PathVariable String jobId) {

		Map<String, Object> response = masterDbService.processingStatus(jobId);

		String status = (String) response.get("status");

		if ("COMPLETED".equalsIgnoreCase(status)) {

			benificiaryService.updateDocumentToSubmittedByJobId(jobId);
		}

		return ResponseEntity.ok(response);
	}

	@GetMapping("/fetchBenificiaryDetails")
	public ResponseEntity<Page<IfvBeneficiaryDetailsDto>> getBenificiaryList(
			@RequestParam(defaultValue = "0") int start, @RequestParam(defaultValue = "10") int size,
			@RequestParam(required = false) String filters, @RequestParam(required = false) String sorting,
			@RequestParam(required = false) String globalFilter) {

		Pageable pageable = PageRequest.of(start, size);
		Page<IfvBeneficiaryDetailsDto> result = benificiaryService.getBenificiaryList(pageable, filters, sorting,
				globalFilter);

		return ResponseEntity.ok(result);
	}

	@GetMapping("/fetchBenificiaryDetailsByCifNo/{cifNumber}")
	public ResponseEntity<Page<IfvBeneficiaryDetailsDto>> fetchBenificiaryDetailsByCifNo(@PathVariable String cifNumber,
			@RequestParam(defaultValue = "0") int start, @RequestParam(defaultValue = "10") int size,
			@RequestParam(required = false) String filters, @RequestParam(required = false) String sorting,
			@RequestParam(required = false) String globalFilter) {

		Pageable pageable = PageRequest.of(start, size);
		Page<IfvBeneficiaryDetailsDto> result = benificiaryService.fetchBenificiaryDetailsByCifNo(cifNumber, pageable,
				filters, sorting, globalFilter);

		return ResponseEntity.ok(result);
	}

	@GetMapping("/getBenificiaryById/{id}")
	public ResponseEntity<IfvBeneficiaryDetailsDto> getBenificiaryById(@PathVariable Long id) {

		IfvBeneficiaryDetailsDto dto = benificiaryService.getBenificiaryById(id);
		return ResponseEntity.ok(dto);
	}

	@DeleteMapping("/deleteBenificiary/{id}")
	public ResponseEntity<Boolean> deleteBenificiary(@PathVariable Long id) {

		boolean success = benificiaryService.deleteBenificiary(id);
		return ResponseEntity.ok(success);
	}

	@GetMapping("/viewBeneficiaryDoc/{filePath}")
	public ResponseEntity<Resource> viewBeneficiaryDoc(@PathVariable String filePath) {
		try {
			Path path = Paths.get(filePath);
			Resource resource = new UrlResource(path.toUri());

			if (resource.exists() && resource.isReadable()) {
				return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
						.header(HttpHeaders.CONTENT_DISPOSITION,
								"inline; filename=\"" + path.getFileName().toString() + "\"")
						.body(resource);
			} else {
				return ResponseEntity.notFound().build();
			}
		} catch (Exception e) {
			return ResponseEntity.internalServerError().build();
		}
	}

	@GetMapping("/downloadBeneficiaryDoc/{id}")
	public ResponseEntity<Resource> downloadBeneficiaryDoc(@PathVariable Long id) {
		try {
			IfvBeneficiaryDetailsDto dto = benificiaryService.getBenificiaryById(id);
			Path path = Paths.get(dto.getFilePath());

			if (!Files.exists(path)) {
				return ResponseEntity.notFound().build();
			}

			Resource resource = new UrlResource(path.toUri());

			if (resource.exists() && resource.isReadable()) {
				return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
						.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dto.getFileName() + "\"")
						.body(resource);
			} else {
				return ResponseEntity.notFound().build();
			}
		} catch (Exception e) {
			return ResponseEntity.internalServerError().build();
		}
	}

	@GetMapping("/fetchLoanAccNoOnCif")
	public ResponseEntity<List<String>> fetchLoanAccNoOnCif(@RequestParam String cifNumber) {
		return ResponseEntity.ok(masterDbService.fetchLoanAccNoOnCif(cifNumber));
	}

	@GetMapping("/fetchBenificiaryApps")
	public ResponseEntity<Page<IfvBeneficiaryAppDto>> fetchBenificiaryApps(@RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter) {

		Pageable pageable = PageRequest.of(start, size);
		Page<IfvBeneficiaryAppDto> result = benificiaryService.fetchBenificiaryApps(pageable, filters, sorting,
				globalFilter);

		return ResponseEntity.ok(result);
	}

	@PostMapping("/uploadBenificiaryAppDoc")
	public ResponseEntity<Boolean> uploadBenificiaryAppDoc(@RequestPart MultipartFile file,
			@RequestPart IfvBeneficiaryAppDto request) {

		boolean success = benificiaryService.uploadBenificiaryAppDoc(file, request);
		return ResponseEntity.ok(success);
	}

	@PostMapping("/downloadBeneficiaryAppDoc")
	public ResponseEntity<StreamingResponseBody> handleFile(@RequestBody CommonRequestDto requestDto) {
		return fileStorageService.handleFile(requestDto);
	}

	@DeleteMapping("/deleteBenificiaryApp/{encId}")
	public ResponseEntity<Boolean> deleteBenificiaryApp(@PathVariable String encId) {
		Long id = Long.parseLong(cryptoUtil.decrypt(encId));
		boolean success = benificiaryService.deleteBenificiaryApp(id);
		return ResponseEntity.ok(success);
	}

	@GetMapping("/fetchDisbDateOnAccNo")
	public ResponseEntity<List<String>> fetchDisbDateOnAccNo(@RequestParam("accNo") String accNo) {
		return ResponseEntity.ok(masterDbService.fetchDisbDateOnAccNo(accNo));
	}

	@GetMapping("/getIfvVerticals")
	public ResponseEntity<List<VerticalDto>> getIfvVerticals() {
		return ResponseEntity.ok(masterDbService.getIfvVerticals());
	}

	@GetMapping("/fetchCustomersOnVertical")
	public ResponseEntity<List<CustomerDto>> fetchCustomersOnVertical(@RequestParam("vertical") String vertical) {
		return ResponseEntity.ok(masterDbService.fetchCustomersOnVertical(vertical));
	}

	@PostMapping("/fetchBeneficiaryDataFromService")
	public ResponseEntity<Page<BeneficiarySummaryResponse>> fetchBeneficiaryDataFromService(
			@Valid @RequestBody FetchBeneficiaryRequest request) {
		log.info("Started fetchBeneficiaryDataFromService..");
		return benificiaryService.fetchBeneficiaryDataFromService(request);
	}

	@PostMapping("/fetchBeneficiaryDocsByCif")
	public ResponseEntity<Page<BeneficiaryDocsResponse>> fetchBeneficiaryDocsByCif(
			@Valid @RequestBody FetchBeneficiaryRequest request) {

		return benificiaryService.fetchBeneficiaryDocsByCif(request);
	}

	@Operation(summary = "Upload Beneficiary Document", description = """
			Uploads a beneficiary Excel document, stores metadata,
			creates a validation job in IFV Master and returns a Job ID.
			Validation is processed asynchronously.
			Use the Job ID to track the validation progress.
			""")
	@PostMapping(value = "/uploadAndValidateBeneficiary", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<ApiResponse<UploadJobResponse>> uploadAndValidateBeneficiary(
			@RequestPart(required = false) MultipartFile file,
			@RequestPart UploadAndValidateBeneficiaryRequestDTO request, HttpServletRequest httpRequest) {

		log.info("Started beneficiary upload");

		benificiaryService.validateBeneficiaryFile(file);

		String jobId = jobIdGenerator.generateJobId();

		request.setJobId(jobId);

		ApiResponse<Void> uploadResponse = benificiaryService.uploadBenificiaryDoc(file, request);

		if (!uploadResponse.isSuccess()) {

			return ResponseEntity.badRequest().body(ApiResponse.<UploadJobResponse>builder().success(false)
					.message(uploadResponse.getMessage()).errors(uploadResponse.getErrors()).build());
		}

		try {

			UploadJobResponse jobResponse = benificiaryService.startValidationIfRequired(file, request);

			return ResponseEntity.ok(ApiResponse.<UploadJobResponse>builder().success(true)
					.message("Beneficiary upload initiated successfully").data(jobResponse).build());

		} catch (Exception ex) {

			//benificiaryService.deleteDocumentByJobId(jobId);

			throw ex;
		}
	}

	@Operation(summary = "Get Validation Job Status", description = """
			Retrieves the current validation status of a beneficiary upload job.

			Possible statuses:
			- PENDING
			- IN_PROGRESS
			- COMPLETED
			- FAILED

			When COMPLETED, the beneficiary document status is automatically
			updated to SUBMITTED.
			""")
	@GetMapping("/getBeneficiaryUploadStatus/{jobId}")
	public ResponseEntity<ValidationJobStatusResponse> getStatus(@PathVariable String jobId) {

		ValidationJobStatusResponse response = beneficiaryValidateService.getJobStatus(jobId);

		if ("COMPLETED".equals(response.getStatus())) {
			benificiaryService.updateDocumentStatusByJobId(jobId);
		}

		return ResponseEntity.ok(response);
	}

	@Operation(summary = "Get Validation Errors", description = """
			Retrieves validation errors for a failed beneficiary validation job.

			If validation errors exist, the uploaded document metadata
			and file are deleted.
			""")
	@GetMapping("/getValidationErrors/{jobId}")
	public ResponseEntity<List<ValidationError>> getValidationErrors(@PathVariable String jobId) {

		List<ValidationError> errors = beneficiaryValidateService.getValidationErrors(jobId);

		errors = errors != null ? errors : Collections.emptyList();

		if (!errors.isEmpty()) {

			//benificiaryService.deleteDocumentByJobId(jobId);
		}

		return ResponseEntity.ok(errors);
	}

	@PostMapping("/bank/saveBankForwardedDocument")
	public ResponseEntity<ApiResponse<String>> saveBankForwardedDocument(
			@RequestBody BeneficiaryDocsResponse docsResponse) {

		try {

			benificiaryService.saveFwdDocFromBanks(docsResponse);

			ApiResponse<String> response = ApiResponse.<String>builder().success(true).data("SUCCESS")
					.message("Document saved successfully").errors(Collections.emptyList()).build();

			return ResponseEntity.ok(response);

		} catch (Exception e) {

			ApiResponse<String> response = ApiResponse.<String>builder().success(false).data(null)
					.message("Failed to save document").errors(List.of(e.getMessage())).build();

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	@PostMapping("/fetchBeneficiaryUploadsForAllBanks")
	public ResponseEntity<Page<IfvBeneficiaryDetailsDto>> fetchBeneficiaryUploadsForAllBanks(
			@Valid @RequestBody FetchBeneficiaryRequest request) {
		log.info("Started fetchBeneficiaryUploadsForAllBanks..");
		return ResponseEntity.ok(benificiaryService.fetchBeneficiaryUploadsForAllBanks(request));
	}

	@PostMapping("/returnForwardedApplication")
	public ResponseEntity<ApiResponse<String>> returnForwardedApplication(
			@RequestBody ReturnBankForwardedDocumentRequest request) {

		try {

			IfvBeneficiaryDetailsDto dto = benificiaryService.returnForwardedApplication(request);

			ApiResponse<String> response = ApiResponse.<String>builder().success(true).data("SUCCESS")
					.message("Application returned successfully").errors(Collections.emptyList()).build();
			if (!profileService.isProfileActive("local")) {
				emailService.sendApplicationReturnedForCorrectionEmail(dto);
			}
			return ResponseEntity.ok(response);

		} catch (Exception e) {

			ApiResponse<String> response = ApiResponse.<String>builder().success(false).data(null)
					.message("Failed to return application").errors(List.of(e.getMessage())).build();

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	@PostMapping("/fetchDfsSubmittedBeneficiaries")
	public ResponseEntity<Page<IfvBeneficiaryDetailsDto>> fetchDfsSubmittedBeneficiaries(
			@Valid @RequestBody FetchDsfSubmittedBeneficiaryRequest request) {
		log.info("Started fetchDfsSubmittedBeneficiaries..");
		return ResponseEntity.ok(benificiaryService.fetchDfsSubmittedBeneficiaries(request));
	}

}