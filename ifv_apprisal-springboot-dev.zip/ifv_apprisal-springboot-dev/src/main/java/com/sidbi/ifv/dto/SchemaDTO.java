package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class SchemaDTO {

	private Integer scId;

	private Long ifvId;

	private String scSchemeName;

	private BigDecimal scAmount;

	private BigDecimal scRoi;

	private String scTenure;

	private String principalRepayment;

	private String interestPayment;
	
	private String fundCode;

}
