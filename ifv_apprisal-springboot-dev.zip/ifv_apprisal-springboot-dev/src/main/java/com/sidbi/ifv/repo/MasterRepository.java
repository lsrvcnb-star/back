package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVMasterRepositoryEntity;

public interface MasterRepository extends JpaRepository<S2IFVMasterRepositoryEntity, Long> {

	List<S2IFVMasterRepositoryEntity> findByIfvId(Long ifvId);

	List<S2IFVMasterRepositoryEntity> findAllByMstParticulars(String mstParticulars);
}
