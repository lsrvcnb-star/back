package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.MinutesInterestReset;

public interface MinutesInterestResetRepository extends JpaRepository<MinutesInterestReset, Long> {

	List<MinutesInterestReset> findByMinuteSanctionId(Integer minuteSanctionId);

	void deleteByMinuteSanctionId(Integer minuteSanctionId);
}