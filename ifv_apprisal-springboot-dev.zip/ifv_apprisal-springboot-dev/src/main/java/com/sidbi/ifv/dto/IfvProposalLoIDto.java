package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class IfvProposalLoIDto {

	private Long id;

	private Long ifvId;

	private String ifvName;

	private String appNumber;

	private String prIds;

	private String loiNo;

	private Date loiDate;

	private BigDecimal amount;

	private String amountInWords;

	private String fundName;

	private String schemeName;

	private Date ifvAppDated;

	private String headerNote;

	private String addressOfTheBank;

	private String note1;

	private String note2;

	private String note2Subnote1;

	private String note2Subnote2;

	private String note3;

	private Integer loiUser;

	private String nameOfDocuments;

	private Date documentDated;

	private String sectionOrClauseNo;

	private String sectionMode;

	private String kycDocuments;
}
