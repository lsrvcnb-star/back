package com.sidbi.ifv.services;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.IFVMinutesCheckerDetailDTO;
import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.dto.MinutesDocumentsDto;
import com.sidbi.ifv.dto.MinutesForwardRequest;
import com.sidbi.ifv.dto.SanctionMinutesDTO;

public interface SanctionMinutesService extends CrudService<SanctionMinutesDTO, Long> {

	Long getCount(Integer committeeCode);

	Long saveSanctionMinutes(CommonDTO commonDTO);

	Long circulateAllInOne(Long sancMinId);

	SanctionMinutesDTO approveSanction(String status, Long id);

	Long checkMeetingNoExistence(Integer meetingNo, Integer committee);

	List<AppraisalMinutesDataDTO> getAllAppraisalMinutesDataBySancId(Long sancId);

	String getAppraisalDateByAppId(String appNo, Long minuteId);

	Long forwardMinutes(Long sancMinId, int stage, String empId);

	Long rejectMinutes(Long sancMinId);

	Page<SanctionMinutesDTO> getAllOnUserTypeOnPage(String userType, String userCode, int page, int size,
			String filters, String sorting, String globalFilter, String status);

	Map<String, Long> getStatusCounts(String userType, Long userCode);

	MinutesDocumentsDto saveOrUpdateDocument(MinutesDocumentsDto dto);

	MinutesDocumentsDto getDocumentByMinuteId(Long minuteId);

	MinutesDocumentsDto getDocumentById(Long id);

	void deleteDocument(Long id);

	Map<Long, Long> getMinuteIdByLoiIdAndPrId(Long loiId, Long prId);

	List<Long> approveSanctionMinutes(Long mtCode, Integer userId);

	Boolean fwdOrRejMinutes(MinutesForwardRequest forwardRequest);

	List<IFVMinutesCheckerDetailDTO> getMinutesFwdRejDetails(Long minuteId);

	List<IfvApiUsersDTO> getUserListForRejectingMinutes(Long minuteId);

	void sendMail(Long mtCode);

	void createCompliances(List<Long> minuteIds);

}
