package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_CMT_MEMBER_MASTER")
public class CmtMemberMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cmt_member_code")
	private Long cmtMemberCode;

	@Column(name = "member_code")
	private String memberCode;

	@Column(name = "cmt_member_role")
	private String cmtMemberRole;

	@Column(name = "cmt_code")
	private BigDecimal cmtCode;

	@Column(name = "cmt_type")
	private String cmtType;

	@Column(name = "cmt_remark")
	private String cmtRemark;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "enable_flag")
	private Character enableFlag;

	@Column(name = "member_name")
	private String memberName;

	@Column(name = "member_vertical")
	private String memberVertical;

	@Column(name = "member_short_name")
	private String memberShortName;

	@Column(name = "member_mail_id")
	private String memberMailId;

}