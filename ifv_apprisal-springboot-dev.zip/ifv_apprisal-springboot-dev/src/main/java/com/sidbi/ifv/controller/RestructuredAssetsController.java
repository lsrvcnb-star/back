package com.sidbi.ifv.controller;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.RestructuredAssetsDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.RestructuredAssetsService;

@RestController
@CrossOrigin
@RequestMapping("/api/restructured-assets")
public class RestructuredAssetsController extends CrudController<RestructuredAssetsDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(RestructuredAssetsController.class);

	@Autowired
	private RestructuredAssetsService service;

	@Autowired
	private ApplicationService applicationService;

	@Override
	public CrudService<RestructuredAssetsDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<RestructuredAssetsDTO>> getAllOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllOnIfvId() started in RestructuredAssetsController ");
		List<RestructuredAssetsDTO> dtos = service.findAllByIfvId(ifvId);

		if (CollectionUtils.isEmpty(dtos)) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				List<RestructuredAssetsDTO> dtos2 = service.findAllByIfvId(applicationDTO.getIfvId());
				if (!CollectionUtils.isEmpty(dtos2)) {
					dtos2.sort(Comparator.comparing(RestructuredAssetsDTO::getId));
					dtos2.forEach(dto -> {
						dto.setIfvId(ifvId);
						dto.setId(null);
					});
					return ResponseEntity.ok(dtos2);
				}
			}
			return ResponseEntity.ok(Collections.emptyList());
		} else {
			dtos.sort(Comparator.comparing(RestructuredAssetsDTO::getId));
			return ResponseEntity.ok(dtos);
		}

	}
}
