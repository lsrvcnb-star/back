package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BankRefinanceAppResponse {

	private Long id;

	private String appRefId;

	private String nameOfBank;

	private String cifNumber;

	private String schemeCode;

	private String customSchemeName;

	private String applicationStatus;

	private String submittedBy;

	private LocalDateTime submittedDateTime;

	private String refinanceAppFilePath;

	private String refinanceAppFileName;

	private String returnRemarks;

	private String returnBy;

	private String submitByEmail;

}
