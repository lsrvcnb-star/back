package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_MASTER_REPOSITORY")
public class S2IFVMasterRepositoryEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mst_code")
	private Long mstCode;
	
	@Column(name = "ifv_id")
	private Long ifvId;
	
	@Column(name = "mst_particulars")
	private String mstParticulars;
	
	@Column(name = "mst_remarks")
	private String mstRemarks;
	
	@Column(name = "mst_order")
	private String mstOrder;
	
	@Column(name = "mst_flg")
	private String mstFlg;
	
	@Column(name = "date_of_action")
	private Date dateOfAction;
	

}
