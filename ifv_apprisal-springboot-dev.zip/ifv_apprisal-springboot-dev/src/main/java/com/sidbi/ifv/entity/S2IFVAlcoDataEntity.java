package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_ALCO_DATA")
public class S2IFVAlcoDataEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "dt_code")
	private Long dtCode;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "dt_appl")
	private String dtAppl;

	@Column(name = "dt_bankname")
	private String dtBankname;

	@Column(name = "dt_amount")
	private BigDecimal dtAmount;

	@Column(name = "dt_scheme")
	private String dtScheme;

	@Column(name = "dt_period")
	private BigDecimal dtPeriod;

	@Column(name = "dt_roi")
	private BigDecimal dtRoi;

	@Column(name = "dt_cost_of_funds")
	private BigDecimal dtCostOfFunds;

	@Column(name = "dt_speedmargin")
	private BigDecimal dtSpeedmargin;

	@Column(name = "dt_prinicipal_rep")
	private String dtPrinicipalRep;

	@Column(name = "date_of_action")
	private Date dateOfAction;

	@Column(name = "al_code")
	private Long alCode;

	@Column(name = "fund_code")
	private String fundCode;

	@Column(name = "pr_id")
	private Long prId;

	@Column(name = "scheme_code")
	private String schemeCode;

}