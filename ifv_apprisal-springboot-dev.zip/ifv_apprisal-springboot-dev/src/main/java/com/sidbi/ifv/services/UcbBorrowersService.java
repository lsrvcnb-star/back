package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.UcbTop10BorrowersDTO;

public interface UcbBorrowersService extends CrudService<UcbTop10BorrowersDTO, Long> {

	List<UcbTop10BorrowersDTO> findAllByIfvId(Long ifvId);

}
