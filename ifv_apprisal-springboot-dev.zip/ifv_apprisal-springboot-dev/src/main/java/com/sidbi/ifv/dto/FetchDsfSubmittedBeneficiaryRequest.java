package com.sidbi.ifv.dto;

import java.time.LocalDate;
import java.util.Map;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class FetchDsfSubmittedBeneficiaryRequest {

	@Min(value = 0, message = "Page number must be 0 or greater")
	private int page = 0;

	@Min(value = 1, message = "Size must be at least 1")
	@Max(value = 100, message = "Size must not exceed 100")
	private int size = 10;

	@Pattern(regexp = "^[a-zA-Z0-9./_()\\- ]*$", message = "Bank name can contain alphanumeric characters and . / - _ ( ) only")
	@Size(max = 100, message = "Bank name must not exceed 100 characters")
	private String bankName;

	private String bnRefNo;

	private String fileName;

	private String ifvSubmitBy;

	private LocalDate ifvSubmittedDateFrom;

	private LocalDate ifvSubmittedDateTo;

	private String sortField = "ifvSubmittedDate";

	private String sortDirection = "asc";

	@Pattern(regexp = "^[a-zA-Z0-9./_()\\- ]*$", message = "Global filter can contain alphanumeric characters and . / - _ ( ) only")
	@Size(max = 255, message = "Global filter must not exceed 255 characters")
	private String globalFilter;

	private Map<String, String> filters;
}
