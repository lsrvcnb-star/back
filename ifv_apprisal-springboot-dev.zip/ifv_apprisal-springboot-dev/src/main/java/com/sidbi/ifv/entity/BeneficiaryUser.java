package com.sidbi.ifv.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "beneficiary_users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryUser {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "user_id", nullable = false, unique = true, length = 20)
	private String userId;

	@Column(name = "password", length = 500)
	private String password;

	@Column(name = "user_type", length = 10)
	private String userType;

	@Column(name = "user_name", length = 150)
	private String userName;

	@Column(name = "user_short_name", length = 150)
	private String userShortName;

	@Column(name = "user_active", length = 1, columnDefinition = "char(1) default 'Y'")
	private String userActive = "Y";

	@Column(name = "user_lock")
	private Short userLock;

	@Column(name = "user_lock_date_time")
	private LocalDateTime userLockDateTime;

	@Column(name = "created_date_time", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDateTime;

	@Column(name = "created_by", length = 150)
	private String createdBy = "ADMIN";

	@PrePersist
	protected void onCreate() {
		if (userActive == null) {
			userActive = "Y";
		}
		if (createdBy == null) {
			createdBy = "ADMIN";
		}
	}
}