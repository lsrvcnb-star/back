package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class SfbCommondtDTO {

	private Long sfbId;

	private Long ifvId;

	private Date sfbShareportfoliodate;

	private String sfbAoNetwork;

	private String sfbAoBranches;

	private Date sfbAoDate;

	private String sfbAoMajorityBranches;

	private Date sfShareholdingpattern;

	private String auditComments;

	private String alcoOrSubalco;

	private String discretionInvolved;

	private String discretionInvolvedReason;

	private String cmMsersData;

	private String cmRmseData;

	private String cmRsfbData;

	private String cmFabiaData;

	private String cmRampeData;

	private String cmChiefFuncNote;

	private String cmGeoAreaNote;

	private String cmKeyInvestorsNote;

	private String ucsRegulatoryEnvironment;

	private String ucsBriefParticulars;

	private String ucsDirectorExposure;

	private String ucsInstitutionalBorrowings;

	private Date ucbSegPortfolioDate;

	private Date ucbSeg2PortfolioDate;

	private String ucbSeg2Note;

	private String pastDisbNote;

	private String outstandingsNote;

	private String futureRepNote;

	private String interestReset;
}
