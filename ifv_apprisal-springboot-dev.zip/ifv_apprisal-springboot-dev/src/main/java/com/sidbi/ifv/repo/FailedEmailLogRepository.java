package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sidbi.ifv.entity.FailedEmailLog;

@Repository
public interface FailedEmailLogRepository extends JpaRepository<FailedEmailLog, Long> {
	List<FailedEmailLog> findByIfvId(Long ifvId);
}
