package com.sidbi.ifv.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryLoginRequestDTO {

	@NotBlank(message = "Username is required")
	@Size(min = 8, max = 256, message = "Username length must be between 8 and 256")
	private String userName;

	@Size(min = 8, max = 256, message = "Password length must be between 8 and 256")
	private String password; // encrypted password

	@NotBlank(message = "Captcha is required")
	@Size(min = 4, max = 4, message = "Captcha must be 4 characters")
	@Pattern(regexp = "^[A-Za-z0-9]+$", message = "Captcha must be alphanumeric")
	private String captcha;

	@NotBlank(message = "Encrypted captcha is required")
	private String encryptedCaptcha;
}