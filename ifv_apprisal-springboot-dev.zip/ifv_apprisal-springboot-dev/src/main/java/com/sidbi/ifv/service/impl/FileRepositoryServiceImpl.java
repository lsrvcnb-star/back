package com.sidbi.ifv.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVFileRepositoryEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.FileRepository;
import com.sidbi.ifv.services.FileRepositoryService;

@Service
public class FileRepositoryServiceImpl implements FileRepositoryService {

	private static final Logger logger = LoggerFactory.getLogger(FileRepositoryServiceImpl.class);

	@Autowired
	private FileRepository fileRepository;

	String msg = "";

	private static final String FLASH_MINUTES = "FLASH MINUTES";

	@Override
	public FileRepositoryDTO findById(Long id) {
		logger.info("Started save() in FileRepositoryServiceImpl {} ", id);
		S2IFVFileRepositoryEntity fileRepositoryEntity = fileRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("IFVFileRepositoryEntity", id));
		return ifvFileRepositoryEntityToDTO(fileRepositoryEntity);
	}

	@Override
	public FileRepositoryDTO save(FileRepositoryDTO fileRepositoryDTO) {
		logger.info("Started save() in FileRepositoryServiceImpl {} ", fileRepositoryDTO);
		try {
			S2IFVFileRepositoryEntity s2ifvFileRepositoryEntity = null;

			if (fileRepositoryDTO.getFileIfvId() != null && fileRepositoryDTO.getFileIfvId() > 0
					&& fileRepositoryDTO.getFileModule().trim().equalsIgnoreCase("Annexure-II")) {

				s2ifvFileRepositoryEntity = fileRepository.findByFileIfvIdAndFileModule(
						fileRepositoryDTO.getFileIfvId(), fileRepositoryDTO.getFileModule()).orElse(null);

			} else if (fileRepositoryDTO.getFileIfvId() != null && fileRepositoryDTO.getFileIfvId() > 0
					&& fileRepositoryDTO.getFileModule().trim().equalsIgnoreCase("UCB-Annexure-I")) {

				s2ifvFileRepositoryEntity = fileRepository.findByFileIfvIdAndFileModule(
						fileRepositoryDTO.getFileIfvId(), fileRepositoryDTO.getFileModule()).orElse(null);

			} else if (fileRepositoryDTO.getFileIfvId() != null && fileRepositoryDTO.getFileIfvId() > 0
					&& fileRepositoryDTO.getFileModule().trim().equalsIgnoreCase("UCB-Annexure-VIII")) {

				s2ifvFileRepositoryEntity = fileRepository.findByFileIfvIdAndFileModule(
						fileRepositoryDTO.getFileIfvId(), fileRepositoryDTO.getFileModule()).orElse(null);

			} else {
				s2ifvFileRepositoryEntity = fileRepository
						.findBySancMinDetailIdAndFileModule(fileRepositoryDTO.getSancMinDetailId()).orElse(null);
			}

			Long fileCode = s2ifvFileRepositoryEntity != null ? s2ifvFileRepositoryEntity.getFileCode() : null;

			s2ifvFileRepositoryEntity = S2IFVFileRepositoryEntity.fromDTO(fileRepositoryDTO);

			if (fileCode != null && fileCode > 0) {
				s2ifvFileRepositoryEntity.setFileCode(fileCode);
			}

			S2IFVFileRepositoryEntity savedFileRepositoryEntity = fileRepository.save(s2ifvFileRepositoryEntity);

			return ifvFileRepositoryEntityToDTO(savedFileRepositoryEntity);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error occurred while saving S2IFVFileRepositoryEntity {} ", msg);
			throw new DatabaseOperationException("Error occurred while saving S2IFVFileRepositoryEntity " + msg + "",
					e);
		}
	}

	@Override
	public List<FileRepositoryDTO> findAllBySancMinDetailIdIn(List<Long> sancMinDetailIds) {
		logger.info("Started findBySancMinDetailId() in FileRepositoryServiceImpl {} ", sancMinDetailIds);
		List<S2IFVFileRepositoryEntity> entities = fileRepository.findAllBySancMinDetailIdIn(sancMinDetailIds);
		return entities.isEmpty() ? new ArrayList<>()
				: entities.stream().map(this::ifvFileRepositoryEntityToDTO).collect(Collectors.toList());
	}

	public FileRepositoryDTO ifvFileRepositoryEntityToDTO(S2IFVFileRepositoryEntity s2ifvFileRepositoryEntity) {
		FileRepositoryDTO fileRepositoryDTO2 = new FileRepositoryDTO();
		fileRepositoryDTO2.setFileCode(s2ifvFileRepositoryEntity.getFileCode());
		fileRepositoryDTO2.setFileIfvId(s2ifvFileRepositoryEntity.getFileIfvId());
		fileRepositoryDTO2.setFileDomain(s2ifvFileRepositoryEntity.getFileDomain());
		fileRepositoryDTO2.setDateOfAction(s2ifvFileRepositoryEntity.getDateOfAction());
		fileRepositoryDTO2.setFileDataBytea(s2ifvFileRepositoryEntity.getFileData());
		fileRepositoryDTO2.setFileName(s2ifvFileRepositoryEntity.getFileName());
		fileRepositoryDTO2.setFileModule(s2ifvFileRepositoryEntity.getFileModule());
		fileRepositoryDTO2.setFileContentType(s2ifvFileRepositoryEntity.getFileContentType());
		fileRepositoryDTO2.setFileType(s2ifvFileRepositoryEntity.getFileType());
		fileRepositoryDTO2.setSancMinDetailId(s2ifvFileRepositoryEntity.getSancMinDetailId());
		fileRepositoryDTO2.setFileAlcoId(s2ifvFileRepositoryEntity.getFileAlcoId());
		fileRepositoryDTO2.setLoiId(s2ifvFileRepositoryEntity.getLoiId());
		fileRepositoryDTO2.setPropLoiId(s2ifvFileRepositoryEntity.getPropLoiId());
		return fileRepositoryDTO2;
	}

	@Override
	public FileRepositoryDTO update(Long id, FileRepositoryDTO fileRepositoryDTO) {
		logger.info("update() started in FileRepositoryServiceImpl for S2IFVFileRepositoryEntity {}", id);
		try {
			S2IFVFileRepositoryEntity entity = fileRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("IFVFileRepositoryEntity", id));

			entity.setFileData(convertMultipartToByteArray(fileRepositoryDTO.getFileData()));
			entity.setFileContentType(fileRepositoryDTO.getFileData().getContentType());
			entity.setFileType(determineFileType(fileRepositoryDTO.getFileData()));
			entity.setFileName(fileRepositoryDTO.getFileData().getOriginalFilename());
			entity.setDateOfAction(new Date());
			entity.setFileModule(fileRepositoryDTO.getFileModule());
			entity.setFileDomain(fileRepositoryDTO.getFileDomain());
			entity.setFileIfvId(fileRepositoryDTO.getFileIfvId());
			entity.setSancMinDetailId(fileRepositoryDTO.getSancMinDetailId());
			entity.setFileAlcoId(fileRepositoryDTO.getFileAlcoId());
			entity.setLoiId(fileRepositoryDTO.getLoiId());
			entity.setPropLoiId(fileRepositoryDTO.getPropLoiId());
			entity.setFileCode(fileRepositoryDTO.getFileCode());

			fileRepository.save(entity);
			return ifvFileRepositoryEntityToDTO(entity);

		} catch (Exception e) {
			throw new DatabaseOperationException("Error occurred while updating S2IFVFileRepositoryEntity", e);
		}
	}

	private static byte[] convertMultipartToByteArray(MultipartFile file) throws IOException {
		return file.getBytes();
	}

	private static String determineFileType(MultipartFile file) {
		String contentType = file.getContentType();
		String originalFileName = file.getOriginalFilename();
		if (contentType != null && contentType.startsWith("image")) {
			return "image";
		} else if (originalFileName != null && originalFileName.toLowerCase().endsWith(".pdf")) {
			return "pdf";
		} else if (originalFileName != null && (originalFileName.toLowerCase().endsWith(".doc")
				|| originalFileName.toLowerCase().endsWith(".docx"))) {
			return "document";
		} else {
			return "unknown";
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in FileRepositoryServiceImpl for S2IFVFileRepositoryEntity {} ", id);
		try {
			S2IFVFileRepositoryEntity existingEntity = fileRepository.findBySancMinDetailIdAndFileModule(id)
					.orElseThrow(() -> new EntityNotFoundException("SIFVFileRepositoryEntity", id));
			fileRepository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVFileRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVFileRepositoryEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public FileRepositoryDTO findBySancMinDetailId(Long sancMinDetailId) {
		logger.info("findBySancMinDetailId() started in FileRepositoryServiceImpl for S2IFVFileRepositoryEntity {} ",
				sancMinDetailId);
		try {
			FileRepositoryDTO dto = new FileRepositoryDTO();
			S2IFVFileRepositoryEntity existingEntity = fileRepository
					.findBySancMinDetailIdAndFileModule(sancMinDetailId).orElse(null);
			if (existingEntity != null) {
				dto = ifvFileRepositoryEntityToDTO(existingEntity);
			}
			return dto;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findBySancMinDetailId S2IFVFileRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findBySancMinDetailId S2IFVFileRepositoryEntity of id ." + msg + " "
							+ sancMinDetailId,
					e);
		}
	}

	@Override
	public FileRepositoryDTO savePDF(byte[] fileData, Long id, String fileName, String type, String filePath,
			S2IFVApplicationEntity entity2) {
		logger.info("savePDF() started in FileRepositoryServiceImpl for S2IFVFileRepositoryEntity {} {} ", id,
				fileName);
		S2IFVFileRepositoryEntity entity = null;
		try {
			if (type.equalsIgnoreCase("appraisal")) {
				entity = fileRepository.findByFileIfvIdAndFileModule(id).orElse(null);
			} else if (type.equalsIgnoreCase("alco")) {
				entity = fileRepository.findByFileAlcoId(id);
			} else if (type.equalsIgnoreCase("minutes")) {
				entity = fileRepository.findBySancMinDetailIdAndFileModule(id, "FINAL MINUTES").orElse(null);
			} else if (type.equalsIgnoreCase("loi")) {
				entity = fileRepository.findByLoiId(id).orElse(null);
			} else if (type.equalsIgnoreCase("PropLoI")) {
				entity = fileRepository.findByPropLoiId(id).orElse(null);
			} else if (type.equalsIgnoreCase(FLASH_MINUTES)) {
				entity = fileRepository.findBySancMinDetailIdAndFileModule(id, FLASH_MINUTES).orElse(null);
			}
			if (entity == null) {
				entity = new S2IFVFileRepositoryEntity();
			}

			if (type.equalsIgnoreCase("appraisal")) {
				entity.setFileIfvId(id);
			} else if (type.equalsIgnoreCase("alco")) {
				entity.setFileAlcoId(id);
			} else if (type.equalsIgnoreCase("minutes")) {
				entity.setSancMinDetailId(id);
				entity.setFileModule("FINAL MINUTES");
			} else if (type.equalsIgnoreCase("loi")) {
				entity.setLoiId(id);
			} else if (type.equalsIgnoreCase("PropLoI")) {
				entity.setPropLoiId(id);
			} else if (type.equalsIgnoreCase(FLASH_MINUTES)) {
				entity.setSancMinDetailId(id);
				entity.setFileModule(FLASH_MINUTES);
			}

			entity.setFileData(fileData);
			entity.setDateOfAction(new Date());
			entity.setFileType("pdf");
			entity.setFileName(fileName);
			entity.setFilePath(filePath);
			S2IFVFileRepositoryEntity savedFileRepositoryEntity = fileRepository.save(entity);
			return ifvFileRepositoryEntityToDTO(savedFileRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error occurred while executing savePDF S2IFVFileRepositoryEntity {} {} {} ", msg, id,
					fileName);
			throw new DatabaseOperationException(
					"Error occurred while executing savePDF S2IFVFileRepositoryEntity " + msg + "", e);
		}

	}

	@Override
	public FileRepositoryDTO findByFileIfvIdAndFileModule(Long ifvId, String fileModule) {
		logger.info("Started findByFileIfvIdAndFileModule() in FileRepositoryServiceImpl {} ", ifvId);
		try {
			S2IFVFileRepositoryEntity fileRepositoryEntity = null;
			if (fileModule != null && !fileModule.equals("null")) {
				fileRepositoryEntity = fileRepository.findByFileIfvIdAndFileModule(ifvId, fileModule)
						.orElse(new S2IFVFileRepositoryEntity());
			} else {
				fileRepositoryEntity = fileRepository.findByFileIfvIdAndFileModule(ifvId)
						.orElse(new S2IFVFileRepositoryEntity());
			}

			return ifvFileRepositoryEntityToDTO(fileRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while finding IFVFileRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while finding S2IFVFileRepositoryEntity of id " + msg + " " + ifvId, e);
		}

	}

	@Override
	public void deleteByFileCode(Long id) {
		logger.info("deleteByFileCode() started in FileRepositoryServiceImpl for S2IFVFileRepositoryEntity {} ", id);
		try {
			S2IFVFileRepositoryEntity existingEntity = fileRepository.findByFileCode(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVFileRepositoryEntity", id));
			fileRepository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVFileRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVFileRepositoryEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public FileRepositoryDTO findByFileModule(String fileModule) {
		logger.info("Started findByFileModule() in FileRepositoryServiceImpl {} ", fileModule);
		try {
			S2IFVFileRepositoryEntity fileRepositoryEntity = fileRepository.findByFileModule(fileModule);
			return ifvFileRepositoryEntityToDTO(fileRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while finding iFileRepositoryEntity {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while finding S2IFVFileRepositoryEntity of id: " + msg + " " + fileModule, e);
		}

	}

	@Override
	public FileRepositoryDTO findByFileAlcoId(Long alcoId) {
		logger.info("Started findByFileAlcoId() in FileRepositoryServiceImpl {} ", alcoId);
		try {
			S2IFVFileRepositoryEntity fileRepositoryEntity = fileRepository.findByFileAlcoId(alcoId);
			return ifvFileRepositoryEntityToDTO(fileRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while finding S2IFVFileRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while finding S2IFVFileRepositoryEntity of id ." + msg + " " + alcoId, e);
		}

	}

	@Override
	public FileRepositoryDTO findByLoiId(Long id) {
		logger.info("Started findByLoiId() in FileRepositoryServiceImpl {} ", id);
		try {
			S2IFVFileRepositoryEntity fileRepositoryEntity = fileRepository.findByLoiId(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVFileRepositoryEntity", id));
			return ifvFileRepositoryEntityToDTO(fileRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while finding S2IFVFileRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while finding S2IFVFileRepositoryEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public ResponseEntity<Resource> viewOrDownloadDoc(Long ifvId, String module, boolean download) {

		logger.info("Started viewOrDownloadDoc() in FileRepositoryServiceImpl with ifvId: {} and module: {}", ifvId,
				module);

		try {
			S2IFVFileRepositoryEntity fileRepositoryEntity = fileRepository.findByFileIfvIdAndFileModule(ifvId)
					.orElseThrow(() -> new EntityNotFoundException("No file record found for IFV ID: ", ifvId));

			String storedFilePath = fileRepositoryEntity.getFilePath();
			Path filePath = Paths.get(storedFilePath);

			if (!Files.exists(filePath)) {
				throw new EntityNotFoundException("File not found at path: ", filePath);
			}

			Resource resource = new UrlResource(filePath.toUri());
			if (!resource.exists() || !resource.isReadable()) {
				throw new EntityNotFoundException("Unable to read file at: ", filePath);
			}

			String contentType = Files.probeContentType(filePath);
			if (contentType == null) {
				contentType = "application/octet-stream";
			}

			HttpHeaders headers = new HttpHeaders();
			if (download) {
				headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
			} else {
				headers.add(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + resource.getFilename() + "\"");
			}

			logger.info("File ready to be served: {}", resource.getFilename());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType)).headers(headers)
					.body(resource);

		} catch (EntityNotFoundException e) {
			logger.error("File not found for IFV ID: {}", ifvId);
			throw e;
		} catch (Exception e) {
			throw new DatabaseOperationException(
					"Exception occurred while executing viewOrDownloadDoc: " + e.getMessage());
		}
	}

}