package com.sidbi.ifv.config;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;

@Configuration
public class ServiceAuthConfig {

	@Value("${service.auth.secret}")
	private String serviceSecret;

	@Value("${service.auth.issuer}")
	private String serviceIssuer;

	@Value("${service.auth.token-validity-ms}")
	private long tokenValidityMs;

	private SecretKey signingKey;

	@PostConstruct
	public void init() {
		this.signingKey = Keys.hmacShaKeyFor(serviceSecret.getBytes(StandardCharsets.UTF_8));
	}

	/**
	 * Generate a service-to-service JWT token. This token is used to authenticate
	 * inter-service communication.
	 */
	public String generateServiceToken() {
		long now = System.currentTimeMillis();

		return Jwts.builder().subject("service-account").issuer(serviceIssuer).issuedAt(new Date(now))
				.expiration(new Date(now + tokenValidityMs)).claim("scope", "service-to-service")
				.claim("service", serviceIssuer).signWith(signingKey).compact();
	}

	/**
	 * Get the signing key for token validation. Used by ServiceTokenFilter.
	 */
	public SecretKey getSigningKey() {
		return signingKey;
	}

	public String getServiceIssuer() {
		return serviceIssuer;
	}
}
