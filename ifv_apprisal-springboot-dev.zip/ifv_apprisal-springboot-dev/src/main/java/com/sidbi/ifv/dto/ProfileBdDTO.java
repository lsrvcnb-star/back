package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class ProfileBdDTO {

	private Long prCode;

	private Long ifvId;

	private String prFirstName;

	private String prDesignation;

	private String prBriefProfile;
	
	private Date dateOfAction;

}
