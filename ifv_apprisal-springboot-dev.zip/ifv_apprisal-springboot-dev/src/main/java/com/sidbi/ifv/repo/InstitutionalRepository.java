package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVInstitutionalEntity;

public interface InstitutionalRepository extends JpaRepository<S2IFVInstitutionalEntity, Long>{

	List<S2IFVInstitutionalEntity> findByIfvId(Long ifvId);

}
