package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class RestructuredAssetsDTO {

	private Long id;

	private Long ifvId;

	private Date rsDate;

	private Integer noOfAccounts;

	private BigDecimal rsAmount;

}
