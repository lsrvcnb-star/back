package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class UcbEligibilityCriteriaDTO {

	private Long id;

	private Long ifvId;

	private String particulars;

	private String bfsNorm;

	private String complianceStatus;

	private String complianceStatusYear;

	private String eligibilityType;
	
	private String relaxationCap;

}
