package com.sidbi.ifv.enums;

import java.util.Arrays;

public enum RiMVStatusFlagEnum {

	CREATED("N", "Created"), PENDING("P", "Pending"), REJECTED("R", "Rejected"), APPROVED("A", "Approved");

	private final String shortName;
	private final String fullName;

	RiMVStatusFlagEnum(String shortName, String fullName) {
		this.shortName = shortName;
		this.fullName = fullName;
	}

	public String getShortName() {
		return shortName;
	}

	public String getFullName() {
		return fullName;
	}

	public static String getFullNameByShortName(String shortName) {
		return Arrays.stream(RiMVStatusFlagEnum.values()).filter(e -> e.getShortName().equalsIgnoreCase(shortName))
				.findFirst().map(RiMVStatusFlagEnum::getFullName).orElseThrow(
						() -> new IllegalArgumentException("No matching status found for short name: " + shortName));
	}
}
