package com.sidbi.ifv.service.impl;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.dto.CVRequest;
import com.sidbi.ifv.model.CVWebLoginRequest;
import com.sidbi.ifv.model.CVWebResponse;
import com.sidbi.ifv.util.CVIndiceListBuilder;

@Service
public class CVWebService {
	private static final Logger logger = LoggerFactory.getLogger(CVWebService.class);
	private static final Map<Integer, String> ERROR_CODES = new HashMap<>();
	static {
		ERROR_CODES.put(-800, "Login count exceeded");
		ERROR_CODES.put(-19, "No More License Seats");
		ERROR_CODES.put(-100, "Failed to Authenticate user");
		ERROR_CODES.put(-799, "Access denied");
		ERROR_CODES.put(-45, "User Does Not Exist In DB");
		ERROR_CODES.put(-110, "Invalid Password");
		ERROR_CODES.put(-13, "Server Not Found");
		ERROR_CODES.put(-33, "Not Allowed Connections");
		ERROR_CODES.put(-1000, "Already session is active");
		ERROR_CODES.put(-36, "Server In-active");
	}
	@Autowired
	private RestTemplate restTemplate;

	@Value("${cvweb.api.base-url}")
	private String baseUrl;

	@Value("${cvweb.api.default-server}")
	private String servername;

	@Value("${cvweb.api.default-room}")
	private String roomname;

	public CVWebResponse login(CVWebLoginRequest loginRequest) {
		String url = UriComponentsBuilder.fromUriString(baseUrl).path("login").queryParam("servername", servername)
				.queryParam("roomname", roomname).queryParam("username", loginRequest.getUsername())
				.queryParam("password", loginRequest.getPassword())
				.queryParam("localAddresss", loginRequest.getLocalAddress()).build().toUriString();
		logger.info("Calling CVWeb API: {}", url);
		try {
			String response = restTemplate.postForObject(url, null, String.class);
			logger.info("CVWeb API response: {}", response);
			return parseResponse(response);
		} catch (RestClientException e) {
			logger.error("Failed to connect to CVWeb API: {}", e.getMessage());
			return CVWebResponse.builder().success(false)
					.errorMessage("Failed to connect to CVWeb API: " + e.getMessage()).build();
		}
	}

	private CVWebResponse parseResponse(String response) {
		if (response == null) {
			return CVWebResponse.builder().success(false).errorMessage("No response received").build();
		}

		try {
			// Check if the response is an error code
			response = response.trim().replaceAll("^\"|\"$", "");
			if (response.startsWith("-")) {
				int errorCode = Integer.parseInt(response);
				if (errorCode == -1000) {
					return CVWebResponse.builder().success(true).sessionId("ACTIVE").build();
				}

				String errorMessage = ERROR_CODES.getOrDefault(errorCode, "Unknown error");
				return CVWebResponse.builder().success(false).errorCode(errorCode).errorMessage(errorMessage).build();
			} else {
				// Successful response - check if it contains session ID
				if (response.contains("~cvweb")) {
					return CVWebResponse.builder().success(true).sessionId(response).build();
				} else {
					return CVWebResponse.builder().success(false).errorMessage("Unexpected response format")
							.responseText(response).build();
				}
			}
		} catch (NumberFormatException e) {
			return CVWebResponse.builder().success(false).errorMessage("Failed to parse response")
					.responseText(response).build();
		}
	}

	public CVWebResponse cvappCreateNewDocumentWS(CVRequest cvWebRequest) {
		String sessionId = cvWebRequest.getSessionId();
		String indiceList = CVIndiceListBuilder.buildIndiceList(cvWebRequest);
		String rawUrl = baseUrl + "cvappCreateNewDocumentWS" + "?sessionId=" + cvWebRequest.getSessionId()
				+ "&userName=" + cvWebRequest.getUsername() + "&encryptionLogic=2" + "&roomName=" + roomname
				+ "&parentId=" + cvWebRequest.getFolderId() + "&docTypeId=901" + "&totalIndexCount=4" + "&indiceList="
				+ indiceList;

		logger.info("Calling CVWeb API: {}", rawUrl);
		RequestEntity<Void> request = RequestEntity.post(URI.create(rawUrl))
				.header("Content-Type", "application/x-www-form-urlencoded").build();
		try {
			ResponseEntity<String> responseEntity = restTemplate.exchange(request, String.class);
			String response = responseEntity.getBody();
			logger.info("cvappCreateNewDocumentWS API response: {}", response);
			if (response == null || response.trim().isEmpty()) {
				return CVWebResponse.builder().success(false).sessionId(sessionId)
						.errorMessage("Empty response received").build();
			}
			return processApiResponse(response, sessionId, cvWebRequest.getUsername());
		} catch (RestClientException e) {
			logger.error("Failed to connect to cvappCreateNewDocumentWS API: {}", e.getMessage());
			return CVWebResponse.builder().success(false)
					.errorMessage("Failed to connect to cvappCreateNewDocumentWS API: " + e.getMessage()).build();
		}
	}

	private CVWebResponse processApiResponse(String response, String sessionId, String username) {
		try {
			int responseInt = Integer.parseInt(response.trim());
			if (responseInt <= 0) {
				return CVWebResponse.builder().success(false).sessionId(sessionId)
						.errorMessage("Received error code: " + responseInt).responseText(response).build();
			} else {
				return documentIndices(response, sessionId, username);
			}
		} catch (NumberFormatException nfe) {
			logger.error("Response is not a number: {}", response);
			return CVWebResponse.builder().success(false).sessionId(sessionId)
					.errorMessage("Response is not a number: " + response).build();
		}
	}

	public CVWebResponse documentIndices(String documentId, String sessionId, String username) {
		String url = UriComponentsBuilder.fromUriString(baseUrl).path("documentIndices")
				.queryParam("selecteddocid", documentId).queryParam("roomname", roomname)
				.queryParam("sessionId", sessionId).queryParam("userName", username)
				.queryParam("globalLogEnableVal", "Disable").queryParam("globalLogLevelVal", "Info").build()
				.toUriString();
		logger.info("Calling documentIndices API: {}", url);
		try {
			String response = restTemplate.getForObject(url, String.class);
			logger.info("documentIndices API response: {}", response);
			ObjectMapper mapper = new ObjectMapper();
			JsonNode jsonArray = mapper.readTree(response);
			String outwardNo = null;
			if (jsonArray.isArray()) {
				for (JsonNode item : jsonArray) {
					if (item.has("id") && item.get("id").asInt() == 200) {
						outwardNo = item.get("value").asText();
						break;
					}
				}
			}
			if (outwardNo != null) {

				String url2 = UriComponentsBuilder.fromUriString(baseUrl).path("logout")
						.queryParam("sessionid", sessionId).build().toUriString();

				restTemplate.getForObject(url2, String.class);

				return CVWebResponse.builder().success(true).sessionId(sessionId).documentId(outwardNo).build();
			} else {
				return CVWebResponse.builder().success(false).sessionId(sessionId)
						.errorMessage("Could not find field with ID 200 in response").responseText(response).build();
			}
		} catch (Exception e) {
			logger.error("Failed to process documentIndices API response: {}", e.getMessage());
			return CVWebResponse.builder().success(false)
					.errorMessage("Failed to process documentIndices API response: " + e.getMessage()).build();
		}
	}

}
