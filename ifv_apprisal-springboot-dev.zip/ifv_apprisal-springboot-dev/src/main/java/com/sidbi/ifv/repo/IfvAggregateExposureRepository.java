package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sidbi.ifv.entity.IfvAggregateExposure;

@Repository
public interface IfvAggregateExposureRepository extends JpaRepository<IfvAggregateExposure, Long> {

	List<IfvAggregateExposure> findByIfvId(Long id, Sort by);
}
