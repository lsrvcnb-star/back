package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.AlcoMinutesDataDTO;
import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.dto.SanctionMinutesDtlDTO;
import com.sidbi.ifv.services.AlcoMinutesDataService;
import com.sidbi.ifv.services.AppraisalMinutesDataService;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.SanctionMinutesDtlService;

@RestController
@CrossOrigin
@RequestMapping("/api/sanction-minutes-dtl")
public class SanctionMinutesDtlController extends CrudController<SanctionMinutesDtlDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(SanctionMinutesDtlController.class);

	@Autowired
	private SanctionMinutesDtlService service;

	@Autowired
	private AppraisalMinutesDataService appraisalMinutesDataService;

	@Autowired
	private AlcoMinutesDataService alcoMinutesDataService;

	@Override
	public CrudService<SanctionMinutesDtlDTO, Long> getCrudService() {
		return service;
	}

	@PostMapping("/circulateAgenda/{sancMinDtlId}")
	public ResponseEntity<Long> circulateAllInOne(@PathVariable Long sancMinDtlId) {
		logger.info("Started circulateAgenda() in SanctionMinutesDtlController: {} ", sancMinDtlId);
		return ResponseEntity.ok(service.circulateAgenda(sancMinDtlId));
	}

	@PostMapping("/saveAllAlcoMinutesData")
	public ResponseEntity<Boolean> saveAllAlcoMinutesData(@RequestBody List<AlcoMinutesDataDTO> data) {
		logger.info("Started saveAllAlcoMinutesData() in SanctionMinutesDtlController");
		return ResponseEntity.ok(service.saveAllAlcoMinutesData(data));
	}

	@GetMapping("/getAllAlcoMinutesDataBySancDtlCode/{sancDtlCode}")
	public ResponseEntity<List<AlcoMinutesDataDTO>> getAllAlcoMinutesDataBySancDtlCode(@PathVariable Long sancDtlCode) {
		logger.info("Started getAllAlcoMinutesDataBySancDtlCode() in SanctionMinutesDtlController {}", sancDtlCode);
		return ResponseEntity.ok(service.getAllAlcoMinutesDataBySancDtlCode(sancDtlCode));
	}

	@PostMapping("/saveAllAppraisalMinutesData")
	public ResponseEntity<Boolean> saveAllAppraisalMinutesData(@RequestBody List<AppraisalMinutesDataDTO> data) {
		logger.info("Started saveAllAlcoMinutesData() in SanctionMinutesDtlController");
		return ResponseEntity.ok(appraisalMinutesDataService.saveAllAppraisalMinutesData(data));
	}

	@GetMapping("/getAllAppraisalMinutesDataBySancDtlCode/{sancDtlCode}")
	public ResponseEntity<List<AppraisalMinutesDataDTO>> getAllAppraisalMinutesDataBySancDtlCode(
			@PathVariable Long sancDtlCode) {
		logger.info("Started getAllAlcoMinutesDataBySancDtlCode() in SanctionMinutesDtlController");
		return ResponseEntity.ok(appraisalMinutesDataService.getAllAppraisalMinutesDataBySancDtlCode(sancDtlCode));
	}

	@GetMapping("/getAllAppraisalMinutesDataByAgendaIdAndAppId/{agendaId}/{appId}")
	public ResponseEntity<List<AppraisalMinutesDataDTO>> getAllAppraisalMinutesDataByAgendaIdAndAppId(
			@PathVariable String agendaId, @PathVariable String appId) {
		logger.info("Started getAllAppraisalMinutesDataByAgendaIdAndAppId() in SanctionMinutesDtlController{} {} ",
				agendaId, appId);
		return ResponseEntity
				.ok(appraisalMinutesDataService.getAllAppraisalMinutesDataByAgendaIdAndAppId(agendaId, appId));
	}

	@GetMapping("/getAllAlcoMinutesDataByAgendaIdAndAppId/{agendaId}/{appId}")
	public ResponseEntity<List<AlcoMinutesDataDTO>> getAllAlcoMinutesDataByAgendaIdAndAppId(
			@PathVariable String agendaId, @PathVariable String appId) {
		logger.info("Started getAllAlcoMinutesDataByAgendaIdAndAppId() in SanctionMinutesDtlController{} {} ", agendaId,
				appId);
		return ResponseEntity.ok(alcoMinutesDataService.getAllAlcoMinutesDataByAgendaIdAndAppId(agendaId, appId));
	}

}