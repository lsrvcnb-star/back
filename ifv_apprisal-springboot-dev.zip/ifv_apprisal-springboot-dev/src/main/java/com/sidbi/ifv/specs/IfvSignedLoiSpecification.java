package com.sidbi.ifv.specs;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.IfvSignedLoiRequestDTO;
import com.sidbi.ifv.entity.IfvLoiDocuments;

import jakarta.persistence.criteria.Predicate;

public class IfvSignedLoiSpecification {

	private IfvSignedLoiSpecification() {
	}

	public static Specification<IfvLoiDocuments> filter(IfvSignedLoiRequestDTO request) {

		return (root, query, cb) -> {

			List<Predicate> predicates = new ArrayList<>();

			if (StringUtils.hasText(request.getIfvAppNo())) {
				predicates
						.add(cb.like(cb.upper(root.get("ifvAppNo")), "%" + request.getIfvAppNo().toUpperCase() + "%"));
			}

			if (StringUtils.hasText(request.getBankRefNo())) {
				predicates.add(
						cb.like(cb.upper(root.get("bankRefNo")), "%" + request.getBankRefNo().toUpperCase() + "%"));
			}
			
			if (StringUtils.hasText(request.getCifNumber())) {
				predicates.add(
						cb.like(cb.upper(root.get("cifNumber")), "%" + request.getCifNumber().toUpperCase() + "%"));
			}

			if (StringUtils.hasText(request.getScheme())) {
				predicates.add(cb.like(cb.upper(root.get("scheme")), "%" + request.getScheme().toUpperCase() + "%"));
			}

			if (StringUtils.hasText(request.getLoiNo())) {
				predicates.add(cb.like(cb.upper(root.get("loiNo")), "%" + request.getLoiNo().toUpperCase() + "%"));
			}

			if (StringUtils.hasText(request.getFileName())) {
				predicates
						.add(cb.like(cb.upper(root.get("fileName")), "%" + request.getFileName().toUpperCase() + "%"));
			}

			if (StringUtils.hasText(request.getStatus())) {
				predicates.add(cb.equal(cb.upper(root.get("status")), request.getStatus().toUpperCase()));
			}

			if (StringUtils.hasText(request.getUploadedBy())) {
				predicates.add(
						cb.like(cb.upper(root.get("uploadedBy")), "%" + request.getUploadedBy().toUpperCase() + "%"));
			}

			if (request.getUploadedDateFrom() != null) {

				predicates.add(cb.greaterThanOrEqualTo(root.get("uploadedDate"),
						request.getUploadedDateFrom().atStartOfDay()));
			}

			if (request.getUploadedDateTo() != null) {

				predicates.add(
						cb.lessThanOrEqualTo(root.get("uploadedDate"), request.getUploadedDateTo().atTime(23, 59, 59)));
			}

			return cb.and(predicates.toArray(new Predicate[0]));
		};
	}
}