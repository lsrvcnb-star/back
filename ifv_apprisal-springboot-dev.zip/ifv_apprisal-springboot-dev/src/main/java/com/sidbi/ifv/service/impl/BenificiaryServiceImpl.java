package com.sidbi.ifv.service.impl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.client.BankPortalClient;
import com.sidbi.ifv.dto.BankPortalApiResponse;
import com.sidbi.ifv.dto.BeneficiaryDocValError;
import com.sidbi.ifv.dto.BeneficiaryDocValResponse;
import com.sidbi.ifv.dto.BeneficiaryDocsResponse;
import com.sidbi.ifv.dto.BeneficiaryLoginData;
import com.sidbi.ifv.dto.BeneficiaryLoginRequestDTO;
import com.sidbi.ifv.dto.BeneficiarySummaryResponse;
import com.sidbi.ifv.dto.FetchBeneficiaryRequest;
import com.sidbi.ifv.dto.FetchDsfSubmittedBeneficiaryRequest;
import com.sidbi.ifv.dto.IfvBeneficiaryAppDto;
import com.sidbi.ifv.dto.IfvBeneficiaryDetailsDto;
import com.sidbi.ifv.dto.IfvIntBeneficiaryDetailRequest;
import com.sidbi.ifv.dto.ReturnBankForwardedDocumentRequest;
import com.sidbi.ifv.dto.UploadAndValidateBeneficiaryRequestDTO;
import com.sidbi.ifv.dto.UploadJobResponse;
import com.sidbi.ifv.entity.BeneficiaryUser;
import com.sidbi.ifv.entity.IfvBeneficiaryApp;
import com.sidbi.ifv.entity.IfvBeneficiaryDetails;
import com.sidbi.ifv.enums.FileModule;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.exception.FileUploadException;
import com.sidbi.ifv.exception.UnauthorisedException;
import com.sidbi.ifv.repo.BeneficiaryUserRepository;
import com.sidbi.ifv.repo.BenificiaryRepository;
import com.sidbi.ifv.repo.IfvBeneficiaryAppRepo;
import com.sidbi.ifv.services.BenificiaryService;
import com.sidbi.ifv.services.MasterCommonAPIClient;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.specs.IfvBeneficiarySpecification;
import com.sidbi.ifv.util.ApiResponse;
import com.sidbi.ifv.util.CryptoUtil;
import com.sidbi.ifv.util.FileUploadUtility;
import com.sidbi.ifv.util.GenericSpecification;

import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BenificiaryServiceImpl implements BenificiaryService {

	private static final Logger logger = LoggerFactory.getLogger(BenificiaryServiceImpl.class);

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private FileUploadUtility fileUploadUtil;

	private final BenificiaryRepository beneficiaryRepository;
	private final BeneficiaryUserRepository beneficiaryUserRepository;
	private final CryptoUtil cryptoUtil;
	private final PasswordEncoder passwordEncoder;
	private final IfvBeneficiaryAppRepo ifvBeneficiaryAppRepo;
	private final MasterCommonAPIClient masterCommonAPIClient;
	private final BankPortalClient bankPortalClient;
	private final MasterDbService masterDbService;
	private final BeneficiaryValidateService beneficiaryValidateService;

	private static final int MAX_LOCK_ATTEMPTS = 5;

	private static final long MAX_FILE_SIZE = 50 * 1024 * 1024; // 50 MB

	private static final String XLSX_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

	private static final Pattern XLSX_FILE_PATTERN = Pattern.compile("^[a-zA-Z0-9 _-]{1,100}\\.xlsx$");

	@Override
	@Transactional
	public BeneficiaryLoginData authenticate(BeneficiaryLoginRequestDTO loginRequest) {
		logger.info("Beneficiary login attempt started");
		String decryptedCaptcha = cryptoUtil.decrypt(loginRequest.getEncryptedCaptcha());
		if (!loginRequest.getCaptcha().trim().equalsIgnoreCase(decryptedCaptcha.trim())) {
			throw new IllegalArgumentException("Invalid captcha");
		}

		String decryptedUserName = cryptoUtil.decrypt(loginRequest.getUserName());
		String decryptedPassword = cryptoUtil.decrypt(loginRequest.getPassword());

		BeneficiaryUser user = validateUserAndCredentials(decryptedUserName, decryptedPassword);

		resetLockCounter(user);
		logger.info("Successful login for user: {}", user.getUserId());

		return mapToLoginData(user);
	}

	private BeneficiaryUser validateUserAndCredentials(String userName, String password) {
		BeneficiaryUser user = beneficiaryUserRepository.findByUserId(userName).orElseThrow(() -> {
			logger.warn("Login attempt with invalid username: {}", userName);
			return new UnauthorisedException("Invalid username or password");
		});

		// Check if user is locked FIRST (before checking active status or password)
		if (user.getUserLock() != null && user.getUserLock() >= MAX_LOCK_ATTEMPTS) {
			logger.warn("Login attempt for locked user: {}", userName);
			throw new UnauthorisedException(
					"Your account has been locked due to multiple failed login attempts. Please contact the administrator.");
		}

		// Check if user is active
		if (!"Y".equals(user.getUserActive())) {
			logger.warn("Login attempt for inactive user: {}", userName);
			throw new UnauthorisedException("Your account is inactive. Please contact the administrator.");
		}

		// Validate password using BCrypt
		if (!passwordEncoder.matches(password, user.getPassword())) {
			logger.warn("Invalid password attempt for user: {}", userName);
			handleFailedLogin(user);
		}

		return user;
	}

	private void handleFailedLogin(BeneficiaryUser user) {
		Short currentLock = user.getUserLock() != null ? user.getUserLock() : 0;
		user.setUserLock((short) (currentLock + 1));

		int remainingAttempts = MAX_LOCK_ATTEMPTS - user.getUserLock();

		if (user.getUserLock() >= MAX_LOCK_ATTEMPTS) {
			user.setUserLockDateTime(LocalDateTime.now());
			beneficiaryUserRepository.save(user);
			logger.warn("User account locked after {} failed attempts: {}", MAX_LOCK_ATTEMPTS, user.getUserId());
			throw new UnauthorisedException(
					"Your account has been locked due to multiple failed login attempts. Please contact the administrator.");
		}

		beneficiaryUserRepository.save(user);
		logger.warn("Failed login attempt for user: {}. {} attempts remaining.", user.getUserId(), remainingAttempts);

		throw new UnauthorisedException(
				"Invalid username or password. You have " + remainingAttempts + " attempt(s) remaining.");
	}

	private void resetLockCounter(BeneficiaryUser user) {
		if (user.getUserLock() != null && user.getUserLock() > 0) {
			logger.info("Resetting lock counter for user: {} (was at {} attempts)", user.getUserId(),
					user.getUserLock());
			user.setUserLock((short) 0);
			user.setUserLockDateTime(null);
			beneficiaryUserRepository.save(user);
		}
	}

	private BeneficiaryLoginData mapToLoginData(BeneficiaryUser user) {
		BeneficiaryLoginData data = new BeneficiaryLoginData();
		data.setId(user.getId());
		data.setUserId(user.getUserId());
		data.setUserName(user.getUserName());
		data.setUserShortName(user.getUserShortName());
		data.setUserType(user.getUserType());
		data.setUserActive(user.getUserActive());
		data.setUserLock(user.getUserLock());
		return data;
	}

	@Override
	public UploadJobResponse startValidationIfRequired(MultipartFile file, UploadAndValidateBeneficiaryRequestDTO dto) {

		IfvBeneficiaryDetails entity = beneficiaryRepository.findByBenRefNo(dto.getBenRefNo())
				.orElseThrow(() -> new EntityNotFoundException("IfvBeneficiaryDetail", dto.getBenRefNo()));

		// CASE 1
		// Proceed with already uploaded bank file

		if ("Y".equalsIgnoreCase(dto.getProceedWithBankUploadFile())) {

			// Already validated by bank upload

			if ("Y".equalsIgnoreCase(entity.getValidated())) {

				logger.info("Skipping validation. Bank uploaded file already validated. Ref No={}", dto.getBenRefNo());

				beneficiaryRepository.updateDocumentStatusToValidatedByRefId(dto.getBenRefNo());

				return UploadJobResponse.builder().jobId(dto.getJobId()).status("VALIDATED").build();
			}

			// Need validation using already uploaded bank file

			return beneficiaryValidateService.requestValidationFromMaster(entity.getFilePath(), dto.getJobId());
		}

		// CASE 2
		// New IFV uploaded file

		return beneficiaryValidateService.requestValidationFromMaster(file, dto.getJobId());
	}

	@Override
	@Transactional
	public ApiResponse<Void> uploadBenificiaryDoc(MultipartFile file, UploadAndValidateBeneficiaryRequestDTO dto) {

		if (dto == null) {
			logger.error("uploadBeneficiaryDoc failed: Request DTO is null");
			throw new IllegalArgumentException("Request data cannot be null");
		}

		String bankBenRefNo = dto.getBenRefNo();

		logger.info("uploadBeneficiaryDoc started for Ben Ref No : {}", bankBenRefNo);

		try {

			IfvBeneficiaryDetails entity = beneficiaryRepository.findByBenRefNo(bankBenRefNo).orElseThrow(() -> {

				logger.warn("Beneficiary not found with Ref No : {}", bankBenRefNo);

				return new EntityNotFoundException("IfvBeneficiaryDetail", bankBenRefNo);
			});

			if (!"Y".equalsIgnoreCase(dto.getBenPreDisbFlag())) {

				ApiResponse<Void> validationResponse = validateAndCheckDuplicateLoanAccount(dto, entity.getCifNumber());

				if (!validationResponse.isSuccess()) {
					return validationResponse;
				}
			}

			String filePath = null;

			/*
			 * CASE 1 User selected: Proceed With Bank Upload File = YES
			 */

			if ("Y".equalsIgnoreCase(dto.getProceedWithBankUploadFile())) {

				/*
				 * Re-use previously uploaded bank file
				 */

				// entity.setIfvFileName(entity.getFileName());

				// entity.setIfvFilePath(entity.getFilePath());

				logger.info("Proceeding with previously uploaded bank file. Ref No={}", bankBenRefNo);

			}

			/*
			 * CASE 2 User uploaded new IFV file
			 */
			else if (file != null) {

				String originalFilename = file.getOriginalFilename();

				filePath = fileUploadUtil.uploadIfvBenificiaryFile(file, originalFilename, FileModule.BENEFICIARY,
						entity.getCifNumber(), bankBenRefNo);

				entity.setIfvFileName(originalFilename);

				entity.setIfvFilePath(filePath);

				logger.info("New IFV beneficiary file uploaded. Ref No={}", bankBenRefNo);
			}

			if ("Y".equalsIgnoreCase(dto.getBenPreDisbFlag())) {
				entity.setRefDate(LocalDateTime.now());
			}

			entity.setJobId(dto.getJobId());

			entity.setBenPreDisbFlag(dto.getBenPreDisbFlag());

			entity.setLoanAccountNo(dto.getLoanAccountNo());

			entity.setDisbDate(dto.getDisbDate());

			entity.setIfvRemarks(dto.getRemarks());

			entity.setIfvSubmitBy(dto.getSubmitBy());

			entity.setProceedBankUpload(dto.getProceedWithBankUploadFile());

			beneficiaryRepository.save(entity);

			logger.info("uploadBeneficiaryDoc completed successfully for Ref No={}", bankBenRefNo);

			return ApiResponse.<Void>builder().success(true).message("Beneficiary document saved successfully").build();

		} catch (IllegalArgumentException e) {

			logger.error("Validation error for Ref No={} : {}", bankBenRefNo, e.getMessage());

			return ApiResponse.<Void>builder().success(false).message(e.getMessage()).errors(List.of(e.getMessage()))
					.build();

		} catch (IOException e) {

			throw new FileUploadException("Failed to upload beneficiary document due to I/O error", e);

		} catch (Exception e) {

			throw new DatabaseOperationException("Failed to save beneficiary document", e);
		}
	}

	private ApiResponse<Void> validateAndCheckDuplicateLoanAccount(UploadAndValidateBeneficiaryRequestDTO dto,
			String cifNumber) {

		List<String> errors = new ArrayList<>();

		if (!StringUtils.hasText(dto.getLoanAccountNo())) {
			errors.add("Loan account number is mandatory");
		}

		if (!StringUtils.hasText(dto.getDisbDate())) {
			errors.add("Disbursement date is mandatory");
		}

		if (!errors.isEmpty()) {
			logger.warn("Loan account validation failed | errors={}", errors);

			return ApiResponse.<Void>builder().success(false).message("Validation failed").errors(errors).build();
		}

		long count = masterCommonAPIClient.countByAcctNoAndDisbDtAndCifNo(dto.getLoanAccountNo(), dto.getDisbDate(),
				cifNumber);

		if (count > 0) {
			logger.warn("Duplicate loan account number for CIF: {}", cifNumber);

			return ApiResponse.<Void>builder().success(false).message("Loan account number already exists")
					.errors(List.of("Loan account number already exists")).build();
		}

		return ApiResponse.<Void>builder().success(true).message("Validation successful").build();
	}

	@Override
	public Page<IfvBeneficiaryDetailsDto> getBenificiaryList(Pageable pageable, String filters, String sorting,
			String globalFilter) {

		logger.info("getBenificiaryList called | Page: {} Size: {}", pageable.getPageNumber(), pageable.getPageSize());

		try {

			Specification<IfvBeneficiaryDetails> spec = new GenericSpecification<>(filters);

			Specification<IfvBeneficiaryDetails> submittedSpec = (root, query, cb) -> cb
					.equal(cb.upper(cb.trim(root.get("status"))), "SUBMITTED");

			spec = Specification.where(submittedSpec).and(spec);

			Pageable pageableWithSort = applySorting(pageable, sorting);

			Page<IfvBeneficiaryDetails> entityPage = beneficiaryRepository.findAll(applyDistinctOnCifNumber(spec),
					pageableWithSort);

			logger.info("Fetched {} beneficiary records", entityPage.getTotalElements());

			return entityPage.map(entity -> modelMapper.map(entity, IfvBeneficiaryDetailsDto.class));

		} catch (Exception e) {
			throw new DatabaseOperationException("Error fetching beneficiary list", e);
		}
	}

	@Override
	public Page<IfvBeneficiaryDetailsDto> fetchBenificiaryDetailsByCifNo(String cifNumber, Pageable pageable,
			String filters, String sorting, String globalFilter) {

		logger.info("fetchBenificiaryDetailsByCifNo called for CIF: {}", cifNumber);

		try {

			Specification<IfvBeneficiaryDetails> spec = new GenericSpecification<>(filters);

			spec = spec.and((root, query, cb) -> cb.equal(root.get("cifNumber"), cifNumber))
					.and((root, query, cb) -> cb.equal(cb.upper(cb.trim(root.get("status"))), "SUBMITTED"));

			Pageable pageableWithSort = applySorting(pageable, sorting);

			Page<IfvBeneficiaryDetails> entityPage = beneficiaryRepository.findAll(spec, pageableWithSort);

			logger.info("Fetched {} records for CIF: {}", entityPage.getTotalElements(), cifNumber);

			return entityPage.map(entity -> modelMapper.map(entity, IfvBeneficiaryDetailsDto.class));

		} catch (Exception e) {
			throw new DatabaseOperationException("Error fetching beneficiary list by CIF number", e);
		}
	}

	@Override
	public IfvBeneficiaryDetailsDto getBenificiaryById(Long id) {

		logger.info("getBenificiaryById called with ID: {}", id);

		IfvBeneficiaryDetails entity = beneficiaryRepository.findById(id).orElseThrow(() -> {
			logger.warn("Beneficiary is not found with ID: {}", id);
			return new EntityNotFoundException("IfvBeneficiaryDetails", id);
		});

		return modelMapper.map(entity, IfvBeneficiaryDetailsDto.class);
	}

	@Override
	public boolean deleteBenificiary(Long id) {

		logger.info("deleteBenificiary called with ID: {}", id);

		try {
			IfvBeneficiaryDetails entity = beneficiaryRepository.findById(id).orElseThrow(() -> {
				logger.warn("Beneficiary not found with ID: {}", id);
				return new EntityNotFoundException("IfvBeneficiaryDetails", id);
			});

			fileUploadUtil.deleteFile(entity.getIfvFilePath());

			beneficiaryRepository.deleteById(id);

			logger.info("Beneficiary deleted successfully with ID: {}", id);
			return true;

		} catch (EntityNotFoundException e) {
			throw e;

		} catch (Exception e) {
			throw new DatabaseOperationException("Error deleting beneficiary", e);
		}
	}

	private Specification<IfvBeneficiaryDetails> applyDistinctOnCifNumber(
			Specification<IfvBeneficiaryDetails> baseSpec) {

		return (root, query, cb) -> {

			query.distinct(true);

			Subquery<Long> subquery = query.subquery(Long.class);
			Root<IfvBeneficiaryDetails> subRoot = subquery.from(IfvBeneficiaryDetails.class);

			subquery.select(cb.max(subRoot.get("id")));

			subquery.where(cb.equal(subRoot.get("status"), "SUBMITTED"));

			subquery.groupBy(subRoot.get("cifNumber"));

			return cb.and(baseSpec == null ? cb.conjunction() : baseSpec.toPredicate(root, query, cb),
					root.get("id").in(subquery));
		};
	}

	private Pageable applySorting(Pageable pageable, String sorting) {

		if (!StringUtils.hasText(sorting) || "[]".equals(sorting.trim())) {
			return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("id").descending());
		}

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(sorting);

			if (rootNode.isArray()) {

				if (rootNode.isEmpty()) {
					return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("id").descending());
				}

				JsonNode sortNode = rootNode.get(0);

				String field = sortNode.path("id").asText(null);
				Boolean isDesc = sortNode.path("desc").asBoolean(false);

				if (field == null) {
					logger.warn("Sorting JSON missing 'id': {}", sorting);
					return pageable;
				}

				Sort sort = isDesc ? Sort.by(field).descending() : Sort.by(field).ascending();

				return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
			}

			String field = rootNode.path("id").asText(null);
			boolean isDesc = rootNode.path("desc").asBoolean(false);

			if (field == null) {
				logger.warn("Sorting JSON missing 'id': {}", sorting);
				return pageable;
			}

			Sort sort = isDesc ? Sort.by(field).descending() : Sort.by(field).ascending();

			return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);

		} catch (Exception e) {
			logger.warn("Invalid sorting JSON received: {}", sorting, e);
			return pageable;
		}
	}

	@Override
	public Page<IfvBeneficiaryAppDto> fetchBenificiaryApps(Pageable pageable, String filters, String sorting,
			String globalFilter) {

		logger.info("fetchBenificiaryApps called | Page: {} Size: {}", pageable.getPageNumber(),
				pageable.getPageSize());

		try {
			Specification<IfvBeneficiaryApp> spec = new GenericSpecification<>(filters);

			Pageable pageableWithSort = applySorting(pageable, sorting);

			Page<IfvBeneficiaryApp> entityPage = ifvBeneficiaryAppRepo.findAll(spec, pageableWithSort);

			logger.info("Fetched {} fetchBenificiaryApps records", entityPage.getTotalElements());

			return entityPage.map(entity -> modelMapper.map(entity, IfvBeneficiaryAppDto.class));

		} catch (Exception e) {
			throw new DatabaseOperationException("Error fetchBenificiaryApps list", e);
		}
	}

	@Override
	public boolean uploadBenificiaryAppDoc(MultipartFile file, IfvBeneficiaryAppDto dto) {

		if (dto == null) {
			logger.error("uploadBenificiaryAppDoc failed: Request DTO is null");
			throw new IllegalArgumentException("Request data cannot be null");
		}

		if (file == null) {
			logger.error("uploadBenificiaryAppDoc failed: Uploaded file is null");
			throw new IllegalArgumentException("Uploaded file is mandatory");
		}

		logger.info("uploadBenificiaryAppDoc started");

		try {
			final long MAX_SIZE_BYTES = 50L * 1024 * 1024; // 50 MB

			String originalFilename = file.getOriginalFilename();
			if (originalFilename == null || originalFilename.isBlank()) {
				logger.warn("Invalid or empty filename uploaded");
				throw new IllegalArgumentException("Filename cannot be empty");
			}

			String lowerName = originalFilename.toLowerCase().trim();

			// Reject if it is neither .xls nor .xlsx
			boolean hasXls = lowerName.endsWith(".xls");
			boolean hasXlsx = lowerName.endsWith(".xlsx");
			if (!(hasXls || hasXlsx)) {
				logger.warn("Invalid file type uploaded File: {}", originalFilename);
				throw new IllegalArgumentException("Only XLS, XLSX files are allowed");
			}

			if (file.isEmpty()) {
				logger.warn("Empty file uploaded");
				throw new IllegalArgumentException("File cannot be empty");
			}

			// Size check: ≤ 50 MB
			long size = file.getSize();
			if (size > MAX_SIZE_BYTES) {
				logger.warn("Oversized file uploaded | Size: {} bytes | File: {}", size, originalFilename);
				throw new IllegalArgumentException("File is too large. Max allowed size is 50 MB");
			}

			String contentType = file.getContentType();

			String DDMMYYHHMMSS = LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddMMyyHHmmss"));
			String refNo = "IFVBN" + DDMMYYHHMMSS;

			String filePath = fileUploadUtil.uploadBenificiaryFile(file, originalFilename, FileModule.BENEFICIARY,
					refNo);

			dto.setFileName(originalFilename);
			dto.setFilePath(filePath);
			dto.setFileType(contentType);
			dto.setUploadDateTime(LocalDateTime.now());
			dto.setBnRefNo(refNo);

			IfvBeneficiaryApp entity = modelMapper.map(dto, IfvBeneficiaryApp.class);
			ifvBeneficiaryAppRepo.save(entity);

			logger.info("uploadBenificiaryAppDoc completed successfully ");
			return true;

		} catch (IllegalArgumentException e) {
			throw e;

		} catch (IOException e) {
			throw new FileUploadException("I/O failure while uploading uploadBenificiaryAppDoc", e);

		} catch (Exception e) {
			throw new DatabaseOperationException("Unexpected error while saving uploadBenificiaryAppDoc App", e);
		}

	}

	@Override
	public IfvBeneficiaryAppDto getBenificiaryAppById(Long id) {

		logger.info("getBenificiaryById called with ID: {}", id);

		IfvBeneficiaryApp entity = ifvBeneficiaryAppRepo.findById(id).orElseThrow(() -> {
			logger.warn("Beneficiary app not found with ID: {}", id);
			return new EntityNotFoundException("IfvBeneficiaryApp", id);
		});

		return modelMapper.map(entity, IfvBeneficiaryAppDto.class);

	}

	@Override
	public boolean deleteBenificiaryApp(Long id) {

		logger.info("deleteBenificiary called with ID: {}", id);

		try {
			IfvBeneficiaryApp entity = ifvBeneficiaryAppRepo.findById(id).orElseThrow(() -> {
				logger.warn("Beneficiary not found with ID: {}", id);
				return new EntityNotFoundException("IfvBeneficiaryApp", id);
			});

			fileUploadUtil.deleteFile(entity.getFilePath());

			ifvBeneficiaryAppRepo.deleteById(id);

			logger.info("Beneficiary app deleted successfully with ID: {}", id);
			return true;

		} catch (EntityNotFoundException e) {
			throw e;

		} catch (Exception e) {
			throw new DatabaseOperationException("Error deleting beneficiary app", e);
		}
	}

	@Override
	public BeneficiaryDocValResponse validateBeneficiaryDoc(MultipartFile file) {

		BeneficiaryDocValResponse response = new BeneficiaryDocValResponse();

		if (file == null || file.isEmpty()) {
			response.addError(new BeneficiaryDocValError(0, "file", "File cannot be empty", ""));
			response.setInvalidRecords(1);
			return response;
		}

		try {

			String originalFilename = file.getOriginalFilename();

			if (originalFilename == null || originalFilename.isBlank()) {
				response.addError(new BeneficiaryDocValError(0, "fileName", "Filename cannot be empty", ""));
				response.setInvalidRecords(1);
				return response;
			}

			String lowerName = originalFilename.toLowerCase();

			if (!lowerName.endsWith(".xls") && !lowerName.endsWith(".xlsx")) {
				response.addError(
						new BeneficiaryDocValError(0, "fileType", "Only XLS and XLSX files allowed", lowerName));
				response.setInvalidRecords(1);
				return response;
			}

			final long MAX_SIZE_BYTES = 50L * 1024 * 1024;

			if (file.getSize() > MAX_SIZE_BYTES) {
				response.addError(new BeneficiaryDocValError(0, "fileSize", "File exceeds 50MB limit", ""));
				response.setInvalidRecords(1);
				return response;
			}

			// Call master validation API
			return masterCommonAPIClient.validateBeneficiaryDoc(file);

		} catch (Exception e) {
			throw new DatabaseOperationException("File validation failed", e);
		}
	}

	@Override
	public ResponseEntity<Page<BeneficiarySummaryResponse>> fetchBeneficiaryDataFromService(
			FetchBeneficiaryRequest request) {

		logger.info("Connecting bank portal.. Request: {}", request);

		ResponseEntity<Page<BeneficiarySummaryResponse>> response = bankPortalClient
				.fetchBeneficiaryDataFromService(request);

		Page<BeneficiarySummaryResponse> body = response.getBody();

		return ResponseEntity.status(response.getStatusCode()).body(body);
	}

	@Override
	public ResponseEntity<Page<BeneficiaryDocsResponse>> fetchBeneficiaryDocsByCif(FetchBeneficiaryRequest request) {

		logger.info("Connecting bank portal by Cif.. Request: {}", request);

		ResponseEntity<Page<BeneficiaryDocsResponse>> response = bankPortalClient.fetchBeneficiaryDocsByCif(request);

		Page<BeneficiaryDocsResponse> body = response.getBody();
		return ResponseEntity.status(response.getStatusCode()).body(body);
	}

	@Override
	public void deleteDocumentByJobId(String jobId) {
		IfvBeneficiaryDetails entity = beneficiaryRepository.findByJobId(jobId);

		String filePath = entity != null ? entity.getIfvFilePath() : null;

		int rows = beneficiaryRepository.deleteDocumentByJobId(jobId);

		if (rows > 0) {
			logger.info("Deleted beneficiary document for jobId={}", jobId);
		}

		if (StringUtils.hasText(filePath)) {
			fileUploadUtil.deleteFile(filePath);
		}

	}

	@Override
	public void updateDocumentStatusByJobId(String jobId) {

		int rows = beneficiaryRepository.updateStatusToValidated(jobId);

		if (rows > 0) {
			logger.info("Document submitted for jobId={}", jobId);
		}
	}

	@Override
	public void forwardBeneficiaryDataToDFS(String jobId) {

		IfvBeneficiaryDetails request = beneficiaryRepository.findByJobId(jobId);

		if (request == null) {
			throw new DatabaseOperationException("No beneficiary record found for Job Id : " + jobId);
		}

		if (!"VALIDATED".equalsIgnoreCase(request.getStatus())) {
			throw new DatabaseOperationException(
					"Beneficiary record is not in VALIDATED status. Current status : " + request.getStatus());
		}

		IfvIntBeneficiaryDetailRequest beneficiaryDetailRequest = new IfvIntBeneficiaryDetailRequest();
		beneficiaryDetailRequest.setJobId(jobId);
		beneficiaryDetailRequest.setBbdUserId(request.getUploadBy());
		beneficiaryDetailRequest.setBenPreDisbFlag(request.getBenPreDisbFlag());
		beneficiaryDetailRequest.setBenRefNo(request.getBenRefNo());
		beneficiaryDetailRequest.setLoanAccountNo(request.getLoanAccountNo());

		beneficiaryDetailRequest
				.setFilePath("Y".equalsIgnoreCase(request.getProceedBankUpload()) ? request.getFilePath()
						: request.getIfvFilePath());

		beneficiaryDetailRequest.setRefDate(request.getRefDate());
		beneficiaryDetailRequest.setDisbDate(request.getDisbDate());
		beneficiaryDetailRequest.setCifNumber(request.getCifNumber());
		// Aync call
		masterDbService.saveIfvBeneficiaryDetailsAsync(beneficiaryDetailRequest);

	}

	@Override
	public void updateDocumentToSubmittedByJobId(String jobId) {
		int rows = beneficiaryRepository.updateStatusToSubmitted(jobId);

		if (rows > 0) {
			logger.info("Document submitted for jobId={}", jobId);
		}

	}

	@Override
	public void saveFwdDocFromBanks(BeneficiaryDocsResponse docsResponse) {

		IfvBeneficiaryDetails entity = beneficiaryRepository.findByBenRefNo(docsResponse.getBnRefNo())
				.orElseGet(IfvBeneficiaryDetails::new);

		entity.setBankName(docsResponse.getBankName());
		entity.setCifNumber(docsResponse.getCifNumber());
		entity.setBenRefNo(docsResponse.getBnRefNo());

		entity.setFileName(docsResponse.getFileName());
		entity.setFilePath(docsResponse.getFilePath());
		entity.setFileType(docsResponse.getFileType());

		entity.setUploadDateTime(
				docsResponse.getUploadDateTime() != null ? docsResponse.getUploadDateTime() : LocalDateTime.now());

		entity.setUploadBy(docsResponse.getUploadBy());
		entity.setRemarks(docsResponse.getRemarks());
		entity.setValidated(docsResponse.getValidated());
		entity.setStatus("PENDING");
		entity.setUploadByEmail(docsResponse.getUploadByEmail());
		// entity.setScheme(docsResponse.getScheme());
		// entity.setRefinanceAmount(docsResponse.getRefinanceAmount());

		beneficiaryRepository.save(entity);
	}

	@Override
	public Page<IfvBeneficiaryDetailsDto> fetchBeneficiaryUploadsForAllBanks(FetchBeneficiaryRequest request) {

		logger.info("fetchBeneficiaryUploadsForAllBanks called");

		try {

			Pageable pageable = getPageable(request);

			Specification<IfvBeneficiaryDetails> spec = IfvBeneficiarySpecification.filter(request);

			Specification<IfvBeneficiaryDetails> pendingOrReturnedSpec = (root, query, cb) -> cb
					.upper(cb.trim(root.get("status"))).in("PENDING", "RETURNED", "VALIDATED");

			spec = Specification.where(pendingOrReturnedSpec).and(spec);

			Page<IfvBeneficiaryDetails> entityPage = beneficiaryRepository.findAll(spec, pageable);

			return entityPage.map(entity -> modelMapper.map(entity, IfvBeneficiaryDetailsDto.class));

		} catch (Exception e) {

			throw new DatabaseOperationException("Error fetching beneficiary uploads", e);
		}
	}

	private Pageable getPageable(FetchBeneficiaryRequest request) {

		String sortField = StringUtils.hasText(request.getSortField()) ? request.getSortField() : "uploadDateTime";

		Sort.Direction direction = "asc".equalsIgnoreCase(request.getSortDirection()) ? Sort.Direction.ASC
				: Sort.Direction.DESC;

		return PageRequest.of(request.getPage(), request.getSize(), Sort.by(direction, sortField));
	}

	@Override
	@Transactional
	public IfvBeneficiaryDetailsDto returnForwardedApplication(ReturnBankForwardedDocumentRequest request) {

		IfvBeneficiaryDetails entity = beneficiaryRepository.findByBenRefNo(request.getBenRefNo()).orElseThrow(() -> {
			logger.warn("Beneficiary is not found with ID: {}", request.getBenRefNo());
			return new EntityNotFoundException("IfvBeneficiaryDetails", request.getBenRefNo());
		});

		ResponseEntity<BankPortalApiResponse<String>> response = bankPortalClient.returnForwardedApplication(request);

		if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null
				|| !response.getBody().isSuccess()) {

			throw new DatabaseOperationException("Failed to return application in Bank Portal");
		}

		entity.setStatus("RETURNED");
		entity.setReturnRemarks(request.getReturnRemarks());
		entity.setReturnBy(request.getReturnBy());

		beneficiaryRepository.save(entity);

		return modelMapper.map(entity, IfvBeneficiaryDetailsDto.class);
	}

	@Override
	public Page<IfvBeneficiaryDetailsDto> fetchDfsSubmittedBeneficiaries(FetchDsfSubmittedBeneficiaryRequest request) {

		logger.info("fetchDfsSubmittedBeneficiaries called");

		try {

			Pageable pageable = getPageable(request);

			Specification<IfvBeneficiaryDetails> spec = IfvBeneficiarySpecification.filter(request);

			Specification<IfvBeneficiaryDetails> submittedSpec = (root, query, cb) -> cb.and(
					cb.equal(cb.upper(cb.trim(root.get("status"))), "SUBMITTED"),
					cb.isNotNull(root.get("ifvSubmittedDate")));

			spec = Specification.where(submittedSpec).and(spec);

			Page<IfvBeneficiaryDetails> entityPage = beneficiaryRepository.findAll(spec, pageable);

			return entityPage.map(entity -> modelMapper.map(entity, IfvBeneficiaryDetailsDto.class));

		} catch (Exception e) {

			throw new DatabaseOperationException("Error fetching DFS submitted beneficiaries", e);
		}
	}

	private Pageable getPageable(FetchDsfSubmittedBeneficiaryRequest request) {

		String sortField = StringUtils.hasText(request.getSortField()) ? request.getSortField() : "ifvSubmittedDate";

		Sort.Direction direction = "asc".equalsIgnoreCase(request.getSortDirection()) ? Sort.Direction.ASC
				: Sort.Direction.DESC;

		return PageRequest.of(request.getPage(), request.getSize(), Sort.by(direction, sortField));
	}

	@Override
	public void validateBeneficiaryFile(MultipartFile file) {

		if (file == null || file.isEmpty()) {
			return;
		}

		String fileName = file.getOriginalFilename();

		if (!StringUtils.hasText(fileName)) {
			throw new IllegalArgumentException("File name is missing");
		}

		if (!XLSX_FILE_PATTERN.matcher(fileName).matches()) {
			throw new IllegalArgumentException(
					"Invalid file name. Only letters, numbers, spaces, '_' and '-' are allowed.");
		}

		if (!fileName.toLowerCase().endsWith(".xlsx")) {
			throw new IllegalArgumentException("Only XLSX files are allowed");
		}

		if (!XLSX_CONTENT_TYPE.equals(file.getContentType())) {
			throw new IllegalArgumentException("Invalid file type. Only XLSX files are allowed");
		}

		if (file.getSize() > MAX_FILE_SIZE) {
			throw new IllegalArgumentException("File size must not exceed 50 MB");
		}
	}

}
