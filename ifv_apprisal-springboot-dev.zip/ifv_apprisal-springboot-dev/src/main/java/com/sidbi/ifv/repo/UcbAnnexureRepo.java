package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.UcbAnnexureEntity;

public interface UcbAnnexureRepo extends JpaRepository<UcbAnnexureEntity, Long> {

	List<UcbAnnexureEntity> findByIfvIdAndAnnexureNo(Long ifvId, Integer annexureNo);

	List<UcbAnnexureEntity> findByIfvId(Long ifvId);

}
