package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class ValidationJobStatusResponse {

	private String jobId;
	private String status;

	private Integer totalRowsInFile;
	private Integer processedRows;
	private Integer progressPercentage;

	private Integer totalRecords;
	private Integer validRecords;
	private Integer invalidRecords;
	private Integer errorCount;

	private String errorMessage;
}
