package com.sidbi.ifv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.SanctionStatusDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.SanctionStatusService;

@RestController
@CrossOrigin
@RequestMapping("/api/sanction-status")
public class SanctionStatusController extends CrudController<SanctionStatusDTO, Long> {

	@Autowired
	private SanctionStatusService service;

	@Override
	public CrudService<SanctionStatusDTO, Long> getCrudService() {
		return service;
	}

}
