package com.sidbi.ifv.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.AlcoProposalDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.services.AlcoProposalService;
import com.sidbi.ifv.services.TblIfvModuleFwdService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/alcoproposal")
public class AlcoProposalController {

	private static final Logger logger = LoggerFactory.getLogger(AlcoProposalController.class);

	@Autowired
	private AlcoProposalService alcoProposalService;

	@Autowired
	private TblIfvModuleFwdService tblIfvModuleFwdService;

	@GetMapping("/get/{id}")
	public ResponseEntity<AlcoProposalDTO> findById(@PathVariable Long id) {
		logger.info("findById() started AlcoProposalController {} ", id);
		AlcoProposalDTO masterRepositoryDTO = alcoProposalService.findById(id);
		return ResponseEntity.ok(masterRepositoryDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<AlcoProposalDTO>> findAll() {
		logger.info("findAll() started AlcoProposalController ");
		List<AlcoProposalDTO> list = alcoProposalService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<AlcoProposalDTO> save(@RequestBody AlcoProposalDTO masterRepositoryDTO) {
		logger.info("save() started AlcoProposalController {} ", masterRepositoryDTO);
		AlcoProposalDTO savedAlcoProposalDTO = alcoProposalService.save(masterRepositoryDTO);
		return ResponseEntity.ok(savedAlcoProposalDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<AlcoProposalDTO>> saveAll(@RequestBody List<AlcoProposalDTO> listAlcoProposalDTO) {
		logger.info("saveAll() started in AlcoProposalController ");
		List<AlcoProposalDTO> savedAlcoProposalDTOs = alcoProposalService.saveAll(listAlcoProposalDTO);
		return ResponseEntity.ok(savedAlcoProposalDTOs);
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<AlcoProposalDTO> update(@PathVariable Long id, @RequestBody AlcoProposalDTO alcoProposalDTO) {
		logger.info("update() started AlcoProposalController {} ", alcoProposalDTO);
		AlcoProposalDTO updatedAlcoProposalDTO = alcoProposalService.update(id, alcoProposalDTO);
		return ResponseEntity.ok(updatedAlcoProposalDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started AlcoProposalController {} ", id);
		alcoProposalService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@PostMapping("/updateDocument/{status}")
	public ResponseEntity<TblIfvModuleFwdDTO> updateDocument(@PathVariable String status,
			@RequestBody AlcoProposalDTO alcoProposalDTO) {
		logger.info("updateDocument() started AlcoProposalController {} ", alcoProposalDTO);
		TblIfvModuleFwdDTO ifvModuleFwdDTO = alcoProposalService.updateDocument(status, alcoProposalDTO);
		return ResponseEntity.ok(ifvModuleFwdDTO);
	}

	@GetMapping("/getAlcoProposalsOnUserType/{userType}")
	public ResponseEntity<List<AlcoProposalDTO>> getAlcoProposalsOnUserType(@PathVariable String userType) {
		logger.info("getAlcoProposalsOnUserType() started AlcoProposalController {} ", userType);
		List<AlcoProposalDTO> list = alcoProposalService.getAlcoProposalsOnUserType(userType);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getAllOnAppStatusAndAlCode/{status}")
	public ResponseEntity<List<AlcoProposalDTO>> getAllIfvAppsOnStatus(@PathVariable String status) {
		logger.info("getAllOnAppStatusAndAlCode() started in AlcoProposalController {} ", status);
		List<TblIfvModuleFwdDTO> tblIfvModuleFwdDTOs = tblIfvModuleFwdService.findAllByAppStatusAndAlCode(status);
		if (tblIfvModuleFwdDTOs.isEmpty()) {
			return ResponseEntity.ok(new ArrayList<>());
		} else {
			List<Long> alCodes = tblIfvModuleFwdDTOs.stream().map(TblIfvModuleFwdDTO::getAlCode)
					.collect(Collectors.toList());
			List<AlcoProposalDTO> alcoProposalDTOs = alcoProposalService.findAllByAlCodeIn(alCodes);
			return ResponseEntity.ok(alcoProposalDTOs);
		}
	}

	@GetMapping("/getAlcoReportData")
	public ResponseEntity<List<AlcoProposalDTO>> getAlcoReportData() {
		logger.info("getIfvAppsReportData() started ApplicationController ");
		List<AlcoProposalDTO> list = alcoProposalService.getAlcoReportData();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getAlcoReportDataOnPage")
	public ResponseEntity<Page<AlcoProposalDTO>> getAlcoReportDataOnPage(@RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter) {
		logger.info("getIfvAppsReportData() started ApplicationController ");

		int page = start / size;

		Page<AlcoProposalDTO> list = alcoProposalService.getAlcoReportDataOnPage(page, size, filters, sorting,
				globalFilter);
		return ResponseEntity.ok(list);
	}
}
