package com.sidbi.ifv.services;

import com.sidbi.ifv.dto.ReportResponseJsonDTO;

public interface ReportService {

	ReportResponseJsonDTO finalMinutesReport(Long sanctDetailCode);

	ReportResponseJsonDTO generateFInalMinutesWord(Long sanctDetailCode);

	byte[] generateAppraisalReportData(Long ifvId);

}
