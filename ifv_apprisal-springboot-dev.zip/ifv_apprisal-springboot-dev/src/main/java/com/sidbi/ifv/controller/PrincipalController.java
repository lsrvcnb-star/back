package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.PrincipalDTO;
import com.sidbi.ifv.services.PrincipalService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcprin")
public class PrincipalController {

	private static final Logger logger = LoggerFactory.getLogger(PrincipalController.class);

	@Autowired
	private PrincipalService s2ifccPrincipalService;
	
	@GetMapping("/get/{id}")
	public ResponseEntity<PrincipalDTO> findById(@PathVariable Long id) {
		logger.info("findById() started PrincipalController {} ",id);
		PrincipalDTO s2ifccPrincipalDTO = s2ifccPrincipalService.findById(id);
		return ResponseEntity.ok(s2ifccPrincipalDTO);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<PrincipalDTO>> findAll() {
		logger.info("findAll() started PrincipalController ");
		List<PrincipalDTO> list = s2ifccPrincipalService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<PrincipalDTO> save(@RequestBody PrincipalDTO s2ifccPrincipalDTO) {
		logger.info("save() started PrincipalController {} ",s2ifccPrincipalDTO);
		PrincipalDTO savedS2ifccPrincipalDTO = s2ifccPrincipalService.save(s2ifccPrincipalDTO);
        return ResponseEntity.ok(savedS2ifccPrincipalDTO);
    }
	
	@PostMapping("/saveAll")
	public ResponseEntity<List<PrincipalDTO>> saveAll(@RequestBody List<PrincipalDTO> listPrincipalDTO) {
		logger.info("saveAll() started in PrincipalController ");
		List<PrincipalDTO> savedPrincipalDTOs = s2ifccPrincipalService.saveAll(listPrincipalDTO);
		return ResponseEntity.ok(savedPrincipalDTOs);
	}
	
    @PutMapping("/update/{id}")
    public ResponseEntity<PrincipalDTO> update(@PathVariable Long id,
                                                               @RequestBody PrincipalDTO s2ifccPrincipalDTO) {
    	logger.info("update() started PrincipalController {} ",s2ifccPrincipalDTO);
    	PrincipalDTO updatedS2ifccPrincipalDTO = s2ifccPrincipalService.update(id, s2ifccPrincipalDTO);
        return ResponseEntity.ok(updatedS2ifccPrincipalDTO);
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
    	logger.info("delete() started PrincipalController {} ",id);
    	s2ifccPrincipalService.delete(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/getAllOnIfvId/{ifvId}")
	 public ResponseEntity<List<PrincipalDTO>> getAllS2IFVPrincipalEntityOnIfvId(@PathVariable Long ifvId) {
		 logger.info("getAllS2IFVPrincipalEntityOnIfvId() started in PrincipalController ");
		 List<PrincipalDTO> principalDTOs = s2ifccPrincipalService.findAllByIfvId(ifvId);
		 return ResponseEntity.ok(principalDTOs);
	 }

}
