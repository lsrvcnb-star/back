package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.AppraisalMinutesDataEntity;

public interface AppraisalMinutesDataRepository extends JpaRepository<AppraisalMinutesDataEntity, Long> {

	List<AppraisalMinutesDataEntity> findBySancDtlCode(Long sancDtlCode);

	List<AppraisalMinutesDataEntity> findByAgendaIdAndAppId(String agendaId, String appId);

	List<AppraisalMinutesDataEntity> findByAgendaId(String agendaId);

	AppraisalMinutesDataEntity findBySancDtlCodeAndAppIdAndPrId(Long sancDtlCode, String appId, Long prId);

	AppraisalMinutesDataEntity findBySancDtlCodeAndAgendaIdAndAppIdAndPrId(Long sancDtlCode, String agendaId,
			String appId, Long prId);

	@Query("""
			select distinct a.appId
			from AppraisalMinutesDataEntity a
			where a.id in :minuteIds
			""")
	List<String> findDistinctAppIdsByIdIn(@Param("minuteIds") List<Long> minuteIds);

}