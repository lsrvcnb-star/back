package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "S2_IFV_KYC")
public class S2IFVKycEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "KYC_ID")
	private Long kycId;

	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "KYC_PRODUCT_NAME")
	private String kycProductName;

	@Column(name = "KYC_AMOUNT")
	private BigDecimal kycAmount;
	
	@Column(name = "KYC_SHAREPROFILE")
	private BigDecimal kycShareProfile;

	@Column(name = "KYC_TYPE")
	private String kycType;

}
