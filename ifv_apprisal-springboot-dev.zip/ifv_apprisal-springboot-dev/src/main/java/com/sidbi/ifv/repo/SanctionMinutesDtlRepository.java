package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.SanctionMinutesDtlEntity;

public interface SanctionMinutesDtlRepository extends JpaRepository<SanctionMinutesDtlEntity, Long> {

	List<SanctionMinutesDtlEntity> findBySanctStatusCode(Long sanctStatusCode);

	SanctionMinutesDtlEntity findByAgendaId(String agendaNumber);

	List<SanctionMinutesDtlEntity> getByAgendaId(String agendaNumber);

	SanctionMinutesDtlEntity findBySancDtlCode(Long id);

}
