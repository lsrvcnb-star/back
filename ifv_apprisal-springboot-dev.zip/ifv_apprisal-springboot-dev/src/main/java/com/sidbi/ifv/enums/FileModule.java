package com.sidbi.ifv.enums;

public enum FileModule {
	APPRAISAL("APPRAISAL"), FLASH_MINUTES("FLASH_MINUTES"), BENEFICIARY("BENEFICIARY"), IFV_RIMV("IFV_RIMV"),
	LOI("LOI");

	private final String folderName;

	FileModule(String folderName) {
		this.folderName = folderName;
	}

	public String getFolderName() {
		return folderName;
	}

}
