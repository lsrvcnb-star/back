package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.UcbFinancialPerformanceDTO;
import com.sidbi.ifv.entity.UcbFinancialPerformanceEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.UcbFinancialPerformanceRepo;
import com.sidbi.ifv.services.UcbFinancialPerformanceService;

@Service
public class UcbFinancialPerformanceServiceImpl implements UcbFinancialPerformanceService {

	private static final Logger logger = LoggerFactory.getLogger(UcbFinancialPerformanceServiceImpl.class);

	@Autowired
	private UcbFinancialPerformanceRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public UcbFinancialPerformanceDTO findById(Long id) {
		logger.info("findById() started in UcbFinancialPerformanceServiceImpl for UcbFinancialPerformanceEntity {} ",
				id);
		UcbFinancialPerformanceEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("UCBFinancialPerformanceEntity", id));
		return mapper.map(entity, UcbFinancialPerformanceDTO.class);
	}

	@Override
	public List<UcbFinancialPerformanceDTO> findAll() {
		logger.info("findAll() started in UcbFinancialPerformanceServiceImpl of UcbFinancialPerformanceEntity");
		try {
			List<UcbFinancialPerformanceEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, UcbFinancialPerformanceDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all UcbFinancialPerformanceEntity .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all UcbFinancialPerformanceEntity ." + msg + " ", e);
		}
	}

	@Override
	public UcbFinancialPerformanceDTO save(UcbFinancialPerformanceDTO dto) {
		logger.info("save() started in UcbFinancialPerformanceServiceImpl for UcbFinancialPerformanceEntity {} ", dto);
		try {
			UcbFinancialPerformanceEntity entity = mapper.map(dto, UcbFinancialPerformanceEntity.class);
			repository.save(entity);
			return mapper.map(entity, UcbFinancialPerformanceDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating UcbFinancialPerformanceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  UcbFinancialPerformanceEntity." + msg + " ", e);
		}
	}

	@Override
	public List<UcbFinancialPerformanceDTO> saveAll(List<UcbFinancialPerformanceDTO> dtos) {
		logger.info(
				"saveAll() started in UcbFinancialPerformanceServiceImpl for List of UcbFinancialPerformanceEntity");
		try {

			List<UcbFinancialPerformanceEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, UcbFinancialPerformanceEntity.class)).collect(Collectors.toList());
			List<UcbFinancialPerformanceEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, UcbFinancialPerformanceDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all UcbFinancialPerformanceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all UcbFinancialPerformanceEntity." + msg + " ", e);
		}
	}

	@Override
	public UcbFinancialPerformanceDTO update(Long id, UcbFinancialPerformanceDTO dto) {
		logger.info("update() started in UcbFinancialPerformanceServiceImpl for UcbFinancialPerformanceEntity {} {} ",
				id, dto);
		try {
			UcbFinancialPerformanceEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbFinancialPerformanceEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, UcbFinancialPerformanceDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating UcbFinancialPerformanceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating UcbFinancialPerformanceEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in UcbFinancialPerformanceServiceImpl for UcbFinancialPerformanceEntity {} ", id);
		try {
			UcbFinancialPerformanceEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbFinancialPerformanceEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting UcbFinancialPerformanceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting UcbFinancialPerformanceEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<UcbFinancialPerformanceDTO> findAllByIfvId(Long ifvId) {
		logger.info(
				"findAllByIfvId() started in UcbFinancialPerformanceServiceImpl for UcbFinancialPerformanceEntity {} ",
				ifvId);
		try {

			List<UcbFinancialPerformanceEntity> list = repository.findByIfvId(ifvId);
			return (list != null
					&& !list.isEmpty())
							? list.stream()
									.map(UcbFinancialPerformanceEntity -> mapper.map(UcbFinancialPerformanceEntity,
											UcbFinancialPerformanceDTO.class))
									.collect(Collectors.toList())
							: new ArrayList<>();

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId UcbFinancialPerformanceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId UcbFinancialPerformanceEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
