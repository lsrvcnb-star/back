package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.IFVMinutesCheckerDetail;

public interface IFVMinutesCheckerDetailRepo extends JpaRepository<IFVMinutesCheckerDetail, Long> {

	IFVMinutesCheckerDetail findTop1ByMinuteIdOrderByIdDesc(Long minuteId);

	List<IFVMinutesCheckerDetail> findAllByMinuteId(Long minuteId);

}
