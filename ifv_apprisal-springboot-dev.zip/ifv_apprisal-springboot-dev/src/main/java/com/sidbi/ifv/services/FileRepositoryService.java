package com.sidbi.ifv.services;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;

public interface FileRepositoryService {

	FileRepositoryDTO findById(Long id);

	FileRepositoryDTO save(FileRepositoryDTO fileRepositoryDTO);

	List<FileRepositoryDTO> findAllBySancMinDetailIdIn(List<Long> sancMinDetailIds);

	FileRepositoryDTO findBySancMinDetailId(Long sancMinDetailId);

	FileRepositoryDTO update(Long id, FileRepositoryDTO fileRepositoryDTO);

	void delete(Long id);

	FileRepositoryDTO savePDF(byte[] fileData, Long ifvId, String fileName, String type, String filePath,
			S2IFVApplicationEntity entity);

	FileRepositoryDTO findByFileIfvIdAndFileModule(Long ifvId, String fileModule);

	void deleteByFileCode(Long id);

	FileRepositoryDTO findByFileModule(String fileModule);

	FileRepositoryDTO findByFileAlcoId(Long alcoId);

	FileRepositoryDTO findByLoiId(Long id);

	ResponseEntity<Resource> viewOrDownloadDoc(Long ifvId, String module, boolean download);

}
