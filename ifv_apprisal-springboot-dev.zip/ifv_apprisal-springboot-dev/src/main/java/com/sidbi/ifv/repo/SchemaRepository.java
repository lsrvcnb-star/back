package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVSchemaEntity;

public interface SchemaRepository extends JpaRepository<S2IFVSchemaEntity, Integer>{

	List<S2IFVSchemaEntity> findByIfvId(Long ifvId);

}
