package com.sidbi.ifv.service.impl;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.BankRefinanceAppResponse;
import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.dto.IfvBeneficiaryDetailsDto;
import com.sidbi.ifv.dto.IfvRimvAppForwardDto;
import com.sidbi.ifv.dto.LoiEmailNotificationDTO;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.dto.SanctionMinutesDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.dto.UserEmailDto;
import com.sidbi.ifv.entity.FailedEmailLog;
import com.sidbi.ifv.entity.IfvRimvApp;
import com.sidbi.ifv.enums.CommitteeEnum;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.FailedEmailLogRepository;
import com.sidbi.ifv.repo.IfvRimvAppRepo;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.IfvApiUsersService;
import com.sidbi.ifv.services.ProposedSchemaService;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.ProfileService;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailServiceImpl implements EmailService {

	private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

	private static final int MAX_RETRY_ATTEMPTS = 3;
	private static final long INITIAL_RETRY_DELAY = 1000; // 1 second

	@Autowired
	private IfvApiUsersService ifvApiUsersService;

	@Autowired
	private FailedEmailLogRepository failedEmailLogRepository;

	@Autowired
	private ProposedSchemaService proposedSchemaService;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	@Lazy
	private ProfileService profileService;

	@Autowired
	private IfvRimvAppRepo ifvRimvAppRepo;

	@Value("${fromEmailId}")
	private String fromEmailId;

	@Value("${noReplyEmailId}")
	private String noReplyEmailId;

	@Value("${ifvRefinanceMailId}")
	private String ifvRefinanceMailId;

	@Value("${rimvRatingsMailId}")
	private String rimvRatingsMailId;

	private void sendMail(UserEmailDto dto, String subject, String htmlBody, String fileName, byte[] fileData)
			throws MessagingException {
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			helper.setFrom(fromEmailId);
			// Set TO recipients
			if (dto.getToEmailIds() != null && !dto.getToEmailIds().isEmpty()) {
				String[] toAddresses = dto.getToEmailIds().stream().filter(Objects::nonNull)
						.filter(email -> !email.trim().isEmpty()).toArray(String[]::new);
				if (toAddresses.length > 0) {
					helper.setTo(toAddresses);
				}
			}
			// Set CC recipients
			if (dto.getCcEmailIds() != null && !dto.getCcEmailIds().isEmpty()) {
				String[] ccAddresses = dto.getCcEmailIds().stream().filter(Objects::nonNull)
						.filter(email -> !email.trim().isEmpty()).toArray(String[]::new);
				if (ccAddresses.length > 0) {
					helper.setCc(ccAddresses);
				}
			}
			// Set BCC recipients
			if (dto.getBccEmailIds() != null && !dto.getBccEmailIds().isEmpty()) {
				String[] bccAddresses = dto.getBccEmailIds().stream().filter(Objects::nonNull)
						.filter(email -> !email.trim().isEmpty()).toArray(String[]::new);
				if (bccAddresses.length > 0) {
					helper.setBcc(bccAddresses);
				}
			}
			helper.setSubject(subject);
			// Add UAT environment banner to email body if in UAT
			String finalBody = addUATBannerIfNeeded(htmlBody);
			helper.setText(finalBody, true);
			// Add PDF attachment
			if (fileName != null && fileData != null && fileData.length > 0) {
				ByteArrayResource resource = new ByteArrayResource(fileData) {
					@Override
					public String getFilename() {
						return fileName;
					}
				};
				helper.addAttachment(fileName, resource);
			}
			mailSender.send(message);
		} catch (MessagingException e) {
			throw e;
		}
	}

	record MailContent(String subject, String htmlBody) {

	}

	private record EmailContext(Long ifvId, String module, UserEmailDto userEmailDto, MailContent mailContent) {
	}

	@Override
	public void sendEmailWithRetry(String module, ApplicationDTO applicationDTO, TblIfvModuleFwdDTO fwdDTO,
			String fileName, byte[] fileData) {
		int retryCount = 0;
		Exception lastException = null;
		Long ifvId = applicationDTO.getIfvId();
		EmailContext emailContext;
		try {
			emailContext = prepareEmailContext(module, applicationDTO, fwdDTO);
		} catch (Exception e) {
			logger.error("Failed to prepare email context for ifvId: {}", ifvId, e);
			logFailedEmail(null, e, 0);
			return;
		}
		if (!isValidEmailContext(emailContext)) {
			logger.warn("Invalid email context (empty recipient) for ifvId: {}", ifvId);
			logFailedEmail(emailContext, new IllegalArgumentException("Invalid email context - empty recipient"), 0);
			return;
		}
		while (retryCount < MAX_RETRY_ATTEMPTS) {
			try {
				if (retryCount > 0) {
					long delay = INITIAL_RETRY_DELAY * (long) Math.pow(2, retryCount - 1);
					Thread.sleep(delay);
				}
				sendMail(emailContext.userEmailDto(), emailContext.mailContent().subject(),
						emailContext.mailContent().htmlBody(), fileName, fileData);
				logger.info("Email sent successfully after {} attempts for ifvId: {}", retryCount + 1, ifvId);
				return;
			} catch (Exception e) {
				lastException = e;
				retryCount++;
				if (retryCount < MAX_RETRY_ATTEMPTS) {
					logger.warn("Email sending attempt {} failed for ifvId: {}, will retry. Error: {}", retryCount,
							ifvId, e.getMessage());
				} else {
					logger.error("Email sending failed after {} attempts for ifvId: {}", MAX_RETRY_ATTEMPTS, ifvId, e);
				}
			}
		}
		logFailedEmail(emailContext, lastException, retryCount);
		return;
	}

	private String buildDocSubject(String ifvShortName, List<ProposedSchemaDTO> schemaDTOs) {
		return "IFV Document " + ifvShortName + " Proposal "
				+ schemaDTOs.stream()
						.map(e -> "Rs." + e.getPrAmount().stripTrailingZeros().toPlainString() + " Cr_"
								+ CommonUtil.processSchemeName(e.getPrSchemeName(), e.getPrFundname()))
						.collect(Collectors.joining(" & "));
	}

	private MailContent buildLockUnlockMailContent(String docSubject) {
		String subject = docSubject + " has to be reviewed by you.";
		String htmlBody = """
				<html><body>
				<p>%s is pending for review.</p>
				<p>To access the document:</p>
				<ul>
				<li>Log in to IFV Digilending</li>
				<li>Go to the Dashboard/Existing Proposals</li>
				</ul>
				<p>This is an auto-generated notification from IFV</p>
				</body></html>
				""".formatted(docSubject);
		return new MailContent(subject, htmlBody);
	}

	private boolean isUATEnv() {
		return profileService.isProfileActive("uat");
	}

	private String addUATBannerIfNeeded(String htmlBody) {
		if (!isUATEnv()) {
			return htmlBody;
		}

		String uatBanner = """
				<div style="background-color: #FFF3CD; border: 2px solid #FFC107; padding: 10px; margin-bottom: 20px; text-align: center;">
				    <strong style="color: #856404;">UAT ENVIRONMENT - This email is from a test environment</strong>
				</div>
				""";

		// Insert UAT banner after <body> tag
		return htmlBody.replaceFirst("(<body[^>]*>)", "$1" + uatBanner);
	}

	private MailContent buildApproveMailContent(String docSubject) {
		String subject = "WorkFLow Ended for " + docSubject;
		String htmlBody = """
				<html><body>
				<p>WorkFLow Ended for %s</p>
				<p>To access the document:</p>
				<ul>
				<li>Log in to IFV Digilending</li>
				<li>Go to the Dashboard/Approved Proposals</li>
				</ul>
				<p>This is an auto-generated notification from IFV</p>
				</body></html>
				""".formatted(docSubject);
		return new MailContent(subject, htmlBody);
	}

	private UserEmailDto buildUserEmailDto(String module, ApplicationDTO applicationDTO, TblIfvModuleFwdDTO fwdDTO,
			List<IfvApiUsersDTO> apiUsersDTOs, List<Integer> ccMailIdsCode) {
		Integer toMailIdCode = (module.equals("APPROVE")) ? fwdDTO.getAppOfficerCode().intValue()
				: applicationDTO.getCheckerId();
		String toMailId = apiUsersDTOs.stream().filter(e -> e.getOfrCode().equals(toMailIdCode)).findFirst()
				.map(IfvApiUsersDTO::getOfrEmail).orElse(null);
		Set<String> ccMailIds = apiUsersDTOs.stream()
				.filter(e -> !e.getOfrCode().equals(toMailIdCode) && ccMailIdsCode.contains(e.getOfrCode()))
				.map(IfvApiUsersDTO::getOfrEmail).collect(Collectors.toSet());
		UserEmailDto userEmailDto = new UserEmailDto();
		Set<String> toEmailIds = new HashSet<>();
		toEmailIds.add(toMailId);
		userEmailDto.setToEmailIds(toEmailIds);
		userEmailDto.setCcEmailIds(ccMailIds);
		return userEmailDto;
	}

	private EmailContext prepareEmailContext(String module, ApplicationDTO applicationDTO, TblIfvModuleFwdDTO fwdDTO)
			throws Exception {
		String ifvShortName = Optional.ofNullable(applicationDTO.getIfvShortName()).filter(s -> !s.isBlank())
				.orElse(applicationDTO.getIfvName());
		List<ProposedSchemaDTO> schemaDTOs = proposedSchemaService.findAllByIfvId(applicationDTO.getIfvId());
		List<Integer> ccMailIdsCode = Stream
				.of(Optional.ofNullable(fwdDTO.getAppOfficerCode()).map(Long::intValue).orElse(null),
						applicationDTO.getCheckerId(), fwdDTO.getChecker1Id(), fwdDTO.getChecker2Id(),
						fwdDTO.getChecker3Id(), fwdDTO.getChecker4Id())
				.filter(Objects::nonNull).toList();
		List<IfvApiUsersDTO> apiUsersDTOs = ifvApiUsersService.findAllOnOfrCode(ccMailIdsCode);
		String docSubject = buildDocSubject(ifvShortName, schemaDTOs);
		MailContent mailContent = switch (module) {
		case "LOCK", "UNLOCK" -> buildLockUnlockMailContent(docSubject);
		case "APPROVE" -> buildApproveMailContent(docSubject);
		default -> null;
		};

		UserEmailDto userEmailDto = buildUserEmailDto(module, applicationDTO, fwdDTO, apiUsersDTOs, ccMailIdsCode);
		return new EmailContext(applicationDTO.getIfvId(), module, userEmailDto, mailContent);
	}

	private boolean isValidEmailContext(EmailContext emailContext) {
		if (emailContext == null || emailContext.userEmailDto() == null) {
			return false;
		}
		return !CollectionUtils.isEmpty(emailContext.userEmailDto().getToEmailIds());
	}

	private void logFailedEmail(EmailContext emailContext, Exception lastException, int retryCount) {
		try {

			FailedEmailLog failedLog = new FailedEmailLog();

			failedLog.setRetryAttempts(retryCount);
			failedLog.setErrorMessage(lastException != null ? lastException.getMessage() : "Unknown error");

			if (emailContext != null) {
				failedLog.setIfvId(emailContext.ifvId());
				failedLog.setModule(emailContext.module());

				Map<String, Object> recipientDetails = new HashMap<>();
				if (emailContext.userEmailDto() != null) {
					recipientDetails.put("toEmail", emailContext.userEmailDto().getToEmailIds());
					recipientDetails.put("ccEmails", emailContext.userEmailDto().getCcEmailIds());
					recipientDetails.put("bccEmails", emailContext.userEmailDto().getBccEmailIds());
				}
				failedLog.setRecipientDetails(recipientDetails.toString());

				if (emailContext.mailContent() != null) {
					failedLog.setEmailContent(String.format("Subject: %s\nBody: %s",
							emailContext.mailContent().subject(), emailContext.mailContent().htmlBody()));
				}
			}

			failedEmailLogRepository.save(failedLog);
			logger.info("Failed email log saved");
		} catch (Exception e) {
			logger.error("Error while logging failed email: {}", e.getMessage());
		}
	}

	@Override
	public void sendEmailWithRetryForMinutes(SanctionMinutesDTO sanctionMinutesDTO, UserEmailDto userEmailDto,
			String fileName, byte[] fileData) {
		int retryCount = 0;
		Exception lastException = null;
		EmailContext emailContext;
		try {
			emailContext = prepareEmailContextForMinutes(sanctionMinutesDTO, userEmailDto);
		} catch (Exception e) {
			logger.error("Failed to prepare email context for Meeting No: {}", sanctionMinutesDTO.getMeetingNo(), e);
			return;
		}
		if (!isValidEmailContext(emailContext)) {
			logger.warn("Invalid email context (empty recipient) for ifvId: {}", sanctionMinutesDTO.getMeetingNo());
			return;
		}
		while (retryCount < MAX_RETRY_ATTEMPTS) {
			try {
				if (retryCount > 0) {
					long delay = INITIAL_RETRY_DELAY * (long) Math.pow(2, retryCount - 1);
					Thread.sleep(delay);
				}
				sendMail(emailContext.userEmailDto(), emailContext.mailContent().subject(),
						emailContext.mailContent().htmlBody(), fileName, fileData);
				logger.info("Email sent successfully after {} attempts", retryCount + 1);
				return;
			} catch (Exception e) {
				lastException = e;
				retryCount++;
				if (retryCount < MAX_RETRY_ATTEMPTS) {
					logger.warn("Email sending attempt {} failed, will retry. Error: {}", retryCount, e.getMessage());
				} else {
					logger.error("Email sending failed after {} attempts", MAX_RETRY_ATTEMPTS, e);
				}
			}
		}
		logFailedEmail(emailContext, lastException, retryCount);
		return;
	}

	public EmailContext prepareEmailContextForMinutes(SanctionMinutesDTO sanctionMinutesDTO,
			UserEmailDto userEmailDto) {
		Objects.requireNonNull(sanctionMinutesDTO, "SanctionMinutesDTO cannot be null");
		Objects.requireNonNull(userEmailDto, "UserEmailDto cannot be null");
		String formattedDate = formatMeetingDate(sanctionMinutesDTO.getMeetingDate());
		String committeeName = CommitteeEnum.getCommitteeNameByCode(sanctionMinutesDTO.getCommiteeCode());
		String meetingNo = sanctionMinutesDTO.getMeetingNo().toString();
		String meetingNoWithFinancialYear = buildMeetingNumberWithFinancialYear(meetingNo);
		String subject = String.format("Flash Minutes - %s Meeting no. %s dated %s", committeeName, meetingNo,
				formattedDate);
		String htmlBodyNote = String.format("%s Meeting no. %s held on %s", committeeName, meetingNoWithFinancialYear,
				formattedDate);
		String htmlBody = """
				<html><body>
				<p>Dear Sir / Madam,</p>
				<p>Pl. find attached herewith the scan/approved copy of the flash minutes of the %s for your information.</p>
				<p>Detailed minutes are being uploaded in the DMS system for signatures.</p>
				</body></html>
				"""
				.formatted(htmlBodyNote);
		return new EmailContext(null, null, userEmailDto, new MailContent(subject, htmlBody));
	}

	private String formatMeetingDate(Date meetingDate) {
		LocalDate localDate = meetingDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH));
	}

	private String buildMeetingNumberWithFinancialYear(String meetingNo) {
		LocalDate now = LocalDate.now();
		int currentYear = now.getYear();
		int nextYearSuffix = (currentYear + 1) % 100;
		int previousYearSuffix = currentYear % 100;
		String yearRange = now.getMonthValue() >= 3 ? String.format("%d-%02d", currentYear, nextYearSuffix)
				: String.format("%d-%02d", currentYear - 1, previousYearSuffix);
		return meetingNo + " / " + yearRange;
	}

	@Override
	public void sendFwdEmailToRimv(IfvRimvAppForwardDto ifvRimvAppForwardDto) {
		Long ifvRimvAppId = ifvRimvAppForwardDto.getIfvRimvAppId();
		logger.info("Preparing forward notification email to RiMV for ifvRimvAppId: {}", ifvRimvAppId);

		IfvRimvApp app = ifvRimvAppRepo.findById(ifvRimvAppId)
				.orElseThrow(() -> new EntityNotFoundException("IfvRimvApp", ifvRimvAppId));
		Integer fwdUserId = ifvRimvAppForwardDto.getFwdUserId().intValue();
		List<String> lCcIds = ifvApiUsersService.findAllOnOfrCode(List.of(fwdUserId)).stream().map(e -> e.getOfrEmail())
				.filter(Objects::nonNull).distinct().collect(Collectors.toCollection(ArrayList::new));

		if (isUATEnv()) {
			lCcIds.add("nisg_vignesha@sidbi.in");
			lCcIds.add("nisg_narayan@sidbi.in");
		}

		UserEmailDto userEmailDto = new UserEmailDto();
		userEmailDto.setToEmailIds(new HashSet<>(List.of(rimvRatingsMailId)));
		userEmailDto.setCcEmailIds(new HashSet<>(lCcIds));

		String subject = String.format("Application Forwarded for Rating Validation - %s", app.getBankName());
		String rimvSiteUrl = isUATEnv() ? "https://uat-riskassessment.sidbi.in" : "https://riskassessment.sidbi.in";

		String htmlBody = """
				<html><body>
				<p>Dear Sir / Madam,</p>
				<p>This is to inform you that the following application has been forwarded by IFV to RiMV for validation:</p>
				<table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;">
				  <tr><td><strong>RiMV Reference ID</strong></td><td>%s</td></tr>
				  <tr><td><strong>CIF Number</strong></td><td>%s</td></tr>
				  <tr><td><strong>Bank Name</strong></td><td>%s</td></tr>
				  <tr><td><strong>Forwarded By</strong></td><td>%s</td></tr>
				  <tr><td><strong>Forwarded On</strong></td><td>%s</td></tr>
				</table>
				<br/>
				<p>Kindly review and validate the application at your earliest convenience.</p>
				<p>This is auto generated mail from IFV Application.</p>
				<p> Regards,<br/>
				    <strong>SMART Support</strong><br/>
				</p>
				</body></html>
				"""
				.formatted(app.getRimvRefId(), app.getCifNumber(), app.getBankName(), app.getFwdBy(),
						app.getForwardedDateTime() != null
								? app.getForwardedDateTime().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm"))
								: "N/A",
						rimvSiteUrl, rimvSiteUrl);

		MailContent mailContent = new MailContent(subject, htmlBody);

		EmailContext emailContext = new EmailContext(ifvRimvAppId, "FWD_TO_RIMV", userEmailDto, mailContent);

		if (!isValidEmailContext(emailContext)) {
			logger.warn("Invalid email context (empty recipient) for ifvRimvAppId: {}", ifvRimvAppId);
			logFailedEmail(emailContext, new IllegalArgumentException("Invalid email context - empty recipient"), 0);
			return;
		}

		int retryCount = 0;
		Exception lastException = null;

		while (retryCount < MAX_RETRY_ATTEMPTS) {
			try {
				if (retryCount > 0) {
					long delay = INITIAL_RETRY_DELAY * (long) Math.pow(2, retryCount - 1);
					Thread.sleep(delay);
				}
				sendMail(userEmailDto, mailContent.subject(), mailContent.htmlBody(), null, null);
				logger.info(
						"RiMV forward notification email sent successfully after {} attempt(s) for ifvRimvAppId: {}",
						retryCount + 1, ifvRimvAppId);
				return;
			} catch (Exception e) {
				lastException = e;
				retryCount++;
				if (retryCount < MAX_RETRY_ATTEMPTS) {
					logger.warn("RiMV forward email attempt {} failed for ifvRimvAppId: {}, will retry. Error: {}",
							retryCount, ifvRimvAppId, e.getMessage());
				} else {
					logger.error("RiMV forward email failed after {} attempts for ifvRimvAppId: {}", MAX_RETRY_ATTEMPTS,
							ifvRimvAppId, e);
				}
			}
		}

		logFailedEmail(emailContext, lastException, retryCount);
	}

	private void sendMail(String fromEmail, UserEmailDto dto, String subject, String htmlBody, String fileName,
			byte[] fileData) throws MessagingException {

		MimeMessage message = mailSender.createMimeMessage();

		MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
				StandardCharsets.UTF_8.name());

		helper.setFrom(fromEmail);

		if (dto.getToEmailIds() != null && !dto.getToEmailIds().isEmpty()) {
			helper.setTo(dto.getToEmailIds().toArray(String[]::new));
		}

		if (dto.getCcEmailIds() != null && !dto.getCcEmailIds().isEmpty()) {
			helper.setCc(dto.getCcEmailIds().toArray(String[]::new));
		}

		if (dto.getBccEmailIds() != null && !dto.getBccEmailIds().isEmpty()) {
			helper.setBcc(dto.getBccEmailIds().toArray(String[]::new));
		}

		helper.setSubject(subject);
		helper.setText(addUATBannerIfNeeded(htmlBody), true);

		if (fileName != null && fileData != null && fileData.length > 0) {
			helper.addAttachment(fileName, new ByteArrayResource(fileData));
		}

		mailSender.send(message);
	}

	private MailContent buildApplicationReturnedForCorrectionMailContent(String applicationRefNo, String cifNumber,
			String bankName, String returnedBy, String returnedOn, String remarks) {

		String subject = String.format("Refinance Application Returned for Correction - %s", bankName);

		String htmlBody = """
				<html>
				<body style="font-family: Arial, sans-serif; font-size:14px; color:#222; line-height:1.6;">

				    <p>Dear Sir / Madam,</p>

				    <p>
				        This is to inform you that the application submitted through the
				        Bank Portal has been returned for correction. Kindly review the
				        remarks provided and resubmit the application after making the
				        necessary corrections.
				    </p>

				    <p><b>Details are as below:</b></p>

				    <table style="border-collapse: collapse; margin:16px 0; width:70%%;">
				        <tr>
				            <td style="border:1px solid #ddd; padding:8px;"><b>Application Ref No:</b></td>
				            <td style="border:1px solid #ddd; padding:8px;">%s</td>
				        </tr>

				        <tr>
				            <td style="border:1px solid #ddd; padding:8px;"><b>CIF Number:</b></td>
				            <td style="border:1px solid #ddd; padding:8px;">%s</td>
				        </tr>

				        <tr>
				            <td style="border:1px solid #ddd; padding:8px;"><b>Bank Name:</b></td>
				            <td style="border:1px solid #ddd; padding:8px;">%s</td>
				        </tr>

				        <tr>
				            <td style="border:1px solid #ddd; padding:8px;"><b>Returned By:</b></td>
				            <td style="border:1px solid #ddd; padding:8px;">%s</td>
				        </tr>

				        <tr>
				            <td style="border:1px solid #ddd; padding:8px;"><b>Returned On:</b></td>
				            <td style="border:1px solid #ddd; padding:8px;">%s</td>
				        </tr>

				        <tr>
				            <td style="border:1px solid #ddd; padding:8px;"><b>Remarks:</b></td>
				            <td style="border:1px solid #ddd; padding:8px;">%s</td>
				        </tr>
				    </table>

				    <p>
				        Kindly take the necessary action and resubmit the application through
				        the Bank Portal at the earliest.
				    </p>

				    <p>
				        Regards,<br/>
				        <b>SIDBI Support</b>
				    </p>

				    <p style="font-size:12px; color:gray;">
				        Note : This is an auto generated mail. Please do not reply.
				    </p>

				</body>
				</html>
				""".formatted(applicationRefNo, cifNumber, bankName, returnedBy != null ? returnedBy : "-", returnedOn,
				remarks != null ? remarks : "-");

		return new MailContent(subject, htmlBody);
	}

	@Override
	public void sendApplicationReturnedForCorrectionEmail(IfvBeneficiaryDetailsDto dto) {

		String returnedOn = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm a"));

		UserEmailDto userEmailDto = new UserEmailDto();

		userEmailDto.setToEmailIds(Set.of(dto.getUploadByEmail()));

		userEmailDto.setCcEmailIds(Set.of(ifvRefinanceMailId));

		MailContent mailContent = buildApplicationReturnedForCorrectionMailContent(dto.getBenRefNo(),
				dto.getCifNumber(), dto.getBankName(), dto.getReturnBy(), returnedOn, dto.getReturnRemarks());

		EmailContext emailContext = new EmailContext(null, "RETURN_FOR_CORRECTION", userEmailDto, mailContent);

		int retryCount = 0;
		Exception lastException = null;

		while (retryCount < MAX_RETRY_ATTEMPTS) {
			try {

				if (retryCount > 0) {
					long delay = INITIAL_RETRY_DELAY * (long) Math.pow(2, retryCount - 1);
					Thread.sleep(delay);
				}

				sendMail(noReplyEmailId, userEmailDto, mailContent.subject(), mailContent.htmlBody(), null, null);

				logger.info("Application return for correction email sent successfully to {}", dto.getUploadByEmail());

				return;

			} catch (Exception e) {

				lastException = e;
				retryCount++;

				if (retryCount < MAX_RETRY_ATTEMPTS) {
					logger.warn("Application return email attempt {} failed. Error: {}", retryCount, e.getMessage());
				} else {
					logger.error("Application return email failed after {} attempts", MAX_RETRY_ATTEMPTS, e);
				}
			}
		}

		logFailedEmail(emailContext, lastException, retryCount);
	}

	@Override
	public void sendBankAppReturnEmail(BankRefinanceAppResponse dto) {

		String returnedOn = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm a"));

		UserEmailDto userEmailDto = new UserEmailDto();

		userEmailDto.setToEmailIds(Set.of(dto.getSubmitByEmail()));

		userEmailDto.setCcEmailIds(Set.of(ifvRefinanceMailId));

		MailContent mailContent = buildApplicationReturnedForCorrectionMailContent(dto.getAppRefId(),
				dto.getCifNumber(), dto.getNameOfBank(), dto.getReturnBy(), returnedOn, dto.getReturnRemarks());

		EmailContext emailContext = new EmailContext(null, "RETURN_FOR_CORRECTION", userEmailDto, mailContent);

		int retryCount = 0;
		Exception lastException = null;

		while (retryCount < MAX_RETRY_ATTEMPTS) {
			try {

				if (retryCount > 0) {
					long delay = INITIAL_RETRY_DELAY * (long) Math.pow(2, retryCount - 1);
					Thread.sleep(delay);
				}

				sendMail(noReplyEmailId, userEmailDto, mailContent.subject(), mailContent.htmlBody(), null, null);

				logger.info("Application return for correction email sent successfully to {}", dto.getSubmitByEmail());

				return;

			} catch (Exception e) {

				lastException = e;
				retryCount++;

				if (retryCount < MAX_RETRY_ATTEMPTS) {
					logger.warn("Application return email attempt {} failed. Error: {}", retryCount, e.getMessage());
				} else {
					logger.error("Application return email failed after {} attempts", MAX_RETRY_ATTEMPTS, e);
				}
			}
		}

		logFailedEmail(emailContext, lastException, retryCount);
	}

	@Override
	public void signedLoiSubmissionNotification(LoiEmailNotificationDTO dto) {

		logger.info("Email dto AppRefId={}, Email={}", dto.getAppRefNo(), dto.getBankEmailId());

		UserEmailDto userEmailDto = new UserEmailDto();

		userEmailDto.setToEmailIds(Set.of(dto.getBankEmailId()));

		userEmailDto.setCcEmailIds(Set.of(ifvRefinanceMailId));

		MailContent mailContent = buildLoiIssuedMailContent(dto);

		EmailContext emailContext = new EmailContext(null, "LOI_ISSUED", userEmailDto, mailContent);

		int retryCount = 0;
		Exception lastException = null;

		while (retryCount < MAX_RETRY_ATTEMPTS) {

			try {

				if (retryCount > 0) {
					long delay = INITIAL_RETRY_DELAY * (long) Math.pow(2, retryCount - 1);

					Thread.sleep(delay);
				}

				sendMail(noReplyEmailId, userEmailDto, mailContent.subject(), mailContent.htmlBody(), null, null);

				logger.info("LOI issuance notification sent successfully. appRefNo={}", dto.getAppRefNo());

				return;

			} catch (Exception e) {

				lastException = e;
				retryCount++;

				if (retryCount < MAX_RETRY_ATTEMPTS) {

					logger.warn("LOI notification attempt {} failed. Error: {}", retryCount, e.getMessage());

				} else {

					logger.error("LOI notification failed after {} attempts", MAX_RETRY_ATTEMPTS, e);
				}
			}
		}

		logFailedEmail(emailContext, lastException, retryCount);
	}

	private MailContent buildLoiIssuedMailContent(LoiEmailNotificationDTO dto) {

		String subject = String.format("LOI Issued by SIDBI | %s", dto.getBankName());

		String htmlBody = """
				<html>
				<body style="margin:0;padding:0;background-color:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;">

				<table width="100%%" cellpadding="0" cellspacing="0"
				       style="background-color:#f4f6f9;padding:30px 0;">

				    <tr>
				        <td align="center">

				            <table width="700" cellpadding="0" cellspacing="0"
				                   style="background:#ffffff;border-radius:8px;
				                   overflow:hidden;
				                   box-shadow:0 2px 8px rgba(0,0,0,0.08);">

				                <!-- Header -->
				                <tr>
				                    <td style="background:#003366;
				                               color:#ffffff;
				                               padding:20px 30px;
				                               font-size:22px;
				                               font-weight:600;">
				                        SIDBI | Bank Portal
				                    </td>
				                </tr>

				                <!-- Banner -->
				                <tr>
				                    <td style="padding:30px 30px 10px 30px;">

				                        <div style="background:#edfdf2;
				                                    border-left:5px solid #22c55e;
				                                    padding:16px;
				                                    border-radius:4px;">

				                            <span style="font-size:18px;
				                                         font-weight:600;
				                                         color:#166534;">
				                                Letter of Intent (LOI) Issued
				                            </span>

				                        </div>

				                    </td>
				                </tr>

				                <!-- Greeting -->
				                <tr>
				                    <td style="padding:20px 30px 0 30px;
				                               color:#333333;
				                               font-size:15px;">
				                        Dear Sir / Madam,
				                    </td>
				                </tr>

				                <!-- Message -->
				                <tr>
				                    <td style="padding:15px 30px;
				                               color:#444444;
				                               font-size:15px;
				                               line-height:1.7;">

				                        This is to inform you that the
				                        <b>Letter of Intent (LOI)</b>
				                        has been issued and signed by SIDBI
				                        for the refinance application
				                        mentioned below.

				                    </td>
				                </tr>

				                <!-- Details Header -->
				                <tr>
				                    <td style="padding:10px 30px;">

				                        <h3 style="margin:0;
				                                   color:#003366;
				                                   font-size:18px;">
				                            LOI Details
				                        </h3>

				                    </td>
				                </tr>

				                <!-- Details Table -->
				                <tr>
				                    <td style="padding:10px 30px 25px 30px;">

				                        <table width="100%%"
				                               cellpadding="0"
				                               cellspacing="0"
				                               style="border-collapse:collapse;
				                                      border:1px solid #e5e7eb;">

				                            <tr style="background:#f8fafc;">
				                                <td style="padding:12px;
				                                           font-weight:600;
				                                           border:1px solid #e5e7eb;
				                                           width:35%%;">
				                                    Application Ref No
				                                </td>

				                                <td style="padding:12px;
				                                           border:1px solid #e5e7eb;">
				                                    %s
				                                </td>
				                            </tr>

				                            <tr>
				                                <td style="padding:12px;
				                                           font-weight:600;
				                                           border:1px solid #e5e7eb;">
				                                    Bank Name
				                                </td>

				                                <td style="padding:12px;
				                                           border:1px solid #e5e7eb;">
				                                    %s
				                                </td>
				                            </tr>

				                            <tr style="background:#f8fafc;">
				                                <td style="padding:12px;
				                                           font-weight:600;
				                                           border:1px solid #e5e7eb;">
				                                    LOI Number
				                                </td>

				                                <td style="padding:12px;
				                                           border:1px solid #e5e7eb;">
				                                    %s
				                                </td>
				                            </tr>

				                        </table>

				                    </td>
				                </tr>

				                <!-- Action Required -->
				                <tr>
				                    <td style="padding:0 30px 25px 30px;">

				                        <div style="background:#fff7ed;
				                                    border-left:5px solid #f97316;
				                                    padding:15px;
				                                    border-radius:4px;">

				                            <div style="font-weight:600;
				                                        color:#c2410c;
				                                        margin-bottom:10px;">
				                                Action Required
				                            </div>

				                            <div style="color:#444444;
				                                        line-height:1.7;">

				                                Please log in to the
				                                <b>Bank Portal</b> and review
				                                the issued LOI.

				                                <br/><br/>

				                                Kindly countersign the LOI
				                                and upload the signed document
				                                through the Bank Portal for
				                                SIDBI review and further
				                                processing.

				                            </div>

				                        </div>

				                    </td>
				                </tr>

				                <!-- Footer -->
				                <tr>
				                    <td style="background:#fafafa;
				                               border-top:1px solid #e5e7eb;
				                               padding:25px 30px;
				                               color:#555555;">

				                        <strong>Regards,</strong><br/>
				                        SIDBI Support Team

				                    </td>
				                </tr>

				                <!-- Disclaimer -->
				                <tr>
				                    <td style="background:#fafafa;
				                               padding:0 30px 25px 30px;
				                               font-size:12px;
				                               color:#808080;">

				                        This is a system-generated email.
				                        Please do not reply to this email.

				                    </td>
				                </tr>

				            </table>

				        </td>
				    </tr>

				</table>

				</body>
				</html>
				""".formatted(dto.getAppRefNo(), dto.getBankName(), dto.getLoiNo());

		return new MailContent(subject, htmlBody);
	}

	@Override
	public void counterSignedLoiSubmissionNotification(LoiEmailNotificationDTO dto) {

		UserEmailDto userEmailDto = new UserEmailDto();

		// Notify SIDBI team
		userEmailDto.setToEmailIds(Set.of(ifvRefinanceMailId));

		// Optional CC bank for acknowledgement
		if (StringUtils.hasText(dto.getBankEmailId())) {
			userEmailDto.setCcEmailIds(Set.of(dto.getBankEmailId()));
		}

		MailContent mailContent = buildCounterSignedLoiMailContent(dto);

		EmailContext emailContext = new EmailContext(null, "COUNTER_SIGNED_LOI", userEmailDto, mailContent);

		int retryCount = 0;
		Exception lastException = null;

		while (retryCount < MAX_RETRY_ATTEMPTS) {
			try {

				if (retryCount > 0) {
					long delay = INITIAL_RETRY_DELAY * (long) Math.pow(2, retryCount - 1);

					Thread.sleep(delay);
				}

				sendMail(noReplyEmailId, userEmailDto, mailContent.subject(), mailContent.htmlBody(), null, null);

				logger.info("Counter signed LOI notification sent successfully. appRefNo={}", dto.getAppRefNo());

				return;

			} catch (Exception e) {

				lastException = e;
				retryCount++;

				if (retryCount < MAX_RETRY_ATTEMPTS) {
					logger.warn("Counter signed LOI email attempt {} failed. Error: {}", retryCount, e.getMessage());
				} else {
					logger.error("Counter signed LOI email failed after {} attempts", MAX_RETRY_ATTEMPTS, e);
				}
			}
		}

		logFailedEmail(emailContext, lastException, retryCount);
	}

	private MailContent buildCounterSignedLoiMailContent(LoiEmailNotificationDTO dto) {

		String subject = String.format("Counter Signed LOI Received | %s", dto.getBankName());

		String submissionDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm a"));

		String htmlBody = """
				<html>
				<body style="margin:0;padding:0;background-color:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;">

				<table width="100%%" cellpadding="0" cellspacing="0"
				       style="background-color:#f4f6f9;padding:30px 0;">

				    <tr>
				        <td align="center">

				            <table width="700" cellpadding="0" cellspacing="0"
				                   style="background:#ffffff;border-radius:8px;
				                   overflow:hidden;
				                   box-shadow:0 2px 8px rgba(0,0,0,0.08);">

				                <!-- Header -->
				                <tr>
				                    <td style="background:#003366;
				                               color:#ffffff;
				                               padding:20px 30px;
				                               font-size:22px;
				                               font-weight:600;">
				                        SIDBI | Bank Portal
				                    </td>
				                </tr>

				                <!-- Banner -->
				                <tr>
				                    <td style="padding:30px 30px 10px 30px;">

				                        <div style="background:#edfdf2;
				                                    border-left:5px solid #22c55e;
				                                    padding:16px;
				                                    border-radius:4px;">

				                            <span style="font-size:18px;
				                                         font-weight:600;
				                                         color:#166534;">
				                                Counter Signed LOI Received
				                            </span>

				                        </div>

				                    </td>
				                </tr>

				                <!-- Greeting -->
				                <tr>
				                    <td style="padding:20px 30px 0 30px;
				                               color:#333333;
				                               font-size:15px;">
				                        Dear Sir / Madam,
				                    </td>
				                </tr>

				                <!-- Message -->
				                <tr>
				                    <td style="padding:15px 30px;
				                               color:#444444;
				                               font-size:15px;
				                               line-height:1.7;">

				                        This is to inform you that the Bank has
				                        successfully countersigned the
				                        <b>Letter of Intent (LOI)</b> and submitted
				                        it through the Bank Portal.

				                    </td>
				                </tr>

				                <!-- Details Header -->
				                <tr>
				                    <td style="padding:10px 30px;">

				                        <h3 style="margin:0;
				                                   color:#003366;
				                                   font-size:18px;">
				                            Counter Signed LOI Details
				                        </h3>

				                    </td>
				                </tr>

				                <!-- Details Table -->
				                <tr>
				                    <td style="padding:10px 30px 25px 30px;">

				                        <table width="100%%"
				                               cellpadding="0"
				                               cellspacing="0"
				                               style="border-collapse:collapse;
				                                      border:1px solid #e5e7eb;">

				                            <tr style="background:#f8fafc;">
				                                <td style="padding:12px;
				                                           font-weight:600;
				                                           border:1px solid #e5e7eb;
				                                           width:35%%;">
				                                    Application Ref No
				                                </td>

				                                <td style="padding:12px;
				                                           border:1px solid #e5e7eb;">
				                                    %s
				                                </td>
				                            </tr>

				                            <tr>
				                                <td style="padding:12px;
				                                           font-weight:600;
				                                           border:1px solid #e5e7eb;">
				                                    Bank Name
				                                </td>

				                                <td style="padding:12px;
				                                           border:1px solid #e5e7eb;">
				                                    %s
				                                </td>
				                            </tr>

				                            <tr style="background:#f8fafc;">
				                                <td style="padding:12px;
				                                           font-weight:600;
				                                           border:1px solid #e5e7eb;">
				                                    LOI Number
				                                </td>

				                                <td style="padding:12px;
				                                           border:1px solid #e5e7eb;">
				                                    %s
				                                </td>
				                            </tr>

				                            <tr>
				                                <td style="padding:12px;
				                                           font-weight:600;
				                                           border:1px solid #e5e7eb;">
				                                    Submission Date
				                                </td>

				                                <td style="padding:12px;
				                                           border:1px solid #e5e7eb;">
				                                    %s
				                                </td>
				                            </tr>

				                        </table>

				                    </td>
				                </tr>

				                <!-- Action Box -->
				                <tr>
				                    <td style="padding:0 30px 25px 30px;">

				                        <div style="background:#fff7ed;
				                                    border-left:5px solid #f97316;
				                                    padding:15px;
				                                    border-radius:4px;">

				                            <div style="font-weight:600;
				                                        color:#c2410c;
				                                        margin-bottom:10px;">
				                                Next Action
				                            </div>

				                            <div style="color:#444444;
				                                        line-height:1.7;">

				                                The Bank has countersigned the LOI
				                                and submitted it through the Bank Portal.

				                                <br/><br/>

				                                Kindly review the submitted LOI and
				                                proceed with the subsequent processing
				                                as per the applicable workflow.

				                            </div>

				                        </div>

				                    </td>
				                </tr>

				                <!-- Footer -->
				                <tr>
				                    <td style="background:#fafafa;
				                               border-top:1px solid #e5e7eb;
				                               padding:25px 30px;
				                               color:#555555;">

				                        <strong>Regards,</strong><br>
				                        SIDBI Support Team

				                    </td>
				                </tr>

				                <!-- Disclaimer -->
				                <tr>
				                    <td style="background:#fafafa;
				                               padding:0 30px 25px 30px;
				                               font-size:12px;
				                               color:#808080;">

				                        This is a system-generated email.
				                        Please do not reply to this email.

				                    </td>
				                </tr>

				            </table>

				        </td>
				    </tr>

				</table>

				</body>
				</html>
				""".formatted(dto.getAppRefNo(), dto.getBankName(), dto.getLoiNo(), submissionDate);

		return new MailContent(subject, htmlBody);
	}

}