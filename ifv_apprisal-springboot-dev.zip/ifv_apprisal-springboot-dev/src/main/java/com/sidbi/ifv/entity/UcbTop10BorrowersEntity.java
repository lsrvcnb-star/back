package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ucb_top_10_borrowers")
public class UcbTop10BorrowersEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "total_os")
	private BigDecimal totalOs;

	@Column(name = "nature_of_activity")
	private String natureOfActivity;

	@Column(name = "borrowerNote")
	private String borrowerNote;

}
