package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.IfvRimvDocDto;
import com.sidbi.ifv.dto.IfvRimvAppForwardDto;
import com.sidbi.ifv.dto.RimvValidatedRequestDto;
import com.sidbi.ifv.services.IfvRimvService;

@RestController
@CrossOrigin
@RequestMapping("/internal/rimv")
public class RimvWorkFlowController {

	private static final Logger logger = LoggerFactory.getLogger(RimvWorkFlowController.class);

	@Autowired
	private IfvRimvService ifvRimvService;

	@GetMapping("/fetchIfvRimvDocs")
	public ResponseEntity<Page<IfvRimvAppForwardDto>> fetchIfvRimvDocs(@RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size) {

		logger.info("fetchIfvRimvDocs() started RimvWorkFlowController");

		int page = start / size;
		return ResponseEntity.ok(ifvRimvService.fetchIfvRimvDocsGrouped(page, size));
	}

	@GetMapping("/fetchIfvRimvDocsOnIfvRimvAppId")
	public ResponseEntity<List<IfvRimvDocDto>> fetchIfvRimvDocsOnIfvRimvAppId(@RequestParam Long ifvRimvAppId) {

		logger.info("fetchIfvRimvDocsOnIfvRimvAppId() started RimvWorkFlowController {} : ", ifvRimvAppId);

		return ResponseEntity.ok(ifvRimvService.getAllDocsOnIfvRimvAppId(ifvRimvAppId));
	}

	@PostMapping("/updateIfvRimvDocsStatus")
	public ResponseEntity<Boolean> updateIfvRimvDocsStatus(@RequestBody RimvValidatedRequestDto dto) {

		logger.info("fetchIfvRimvDocsOnIfvId() started RimvWorkFlowController {} : ", dto.getIfvRimvAppId());

		return ResponseEntity.ok(ifvRimvService.updateIfvRimvDocsStatus(dto));
	}
}
