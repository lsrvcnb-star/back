package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "loi_details")
public class LoIDetailEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "sanc_id")
	private Long sancId;

	@Column(name = "sanc_detail_id")
	private Long sancDetailId;

	@Column(name = "appraisal_minute_id")
	private Long appraisalMnuteId;

	@Column(name = "ifv_name")
	private String ifvName;

	@Column(name = "ifv_no")
	private String ifvNo;

	@Column(name = "ifv_date")
	private Date ifvDate;

	@Column(name = "address_of_the_bank")
	private String addressOfTheBank;

	@Column(name = "note1")
	private String note1;

	@Column(name = "note2")
	private String note2;

	@Column(name = "note2_subnote1")
	private String note2Subnote1;

	@Column(name = "note2_subnote2")
	private String note2Subnote2;

	@Column(name = "note3")
	private String note3;

	@Column(name = "loi_user")
	private String loiUser;

	@Column(name = "user_designation")
	private String userDesignation;

	@Column(name = "header_note")
	private String headerNote;

	@Column(name = "name_of_documents")
	private String nameOfDocuments;

	@Column(name = "document_dated")
	private Date documentDated;

	@Column(name = "section_or_clause_no")
	private String sectionOrClauseNo;

	@Column(name = "section_mode")
	private String sectionMode;

	@Column(name = "kyc_documents")
	private String kycDocuments;

	@Column(name = "cv_language")
	private String cvLanguage;

	@Column(name = "cv_region")
	private String cvRegion;
}
