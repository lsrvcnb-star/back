package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVFinancialHighlightsEntity;

public interface FinancialHighlightsRepository extends JpaRepository<S2IFVFinancialHighlightsEntity, Long>{

	List<S2IFVFinancialHighlightsEntity> findByIfvId(Long ifvId);

}
