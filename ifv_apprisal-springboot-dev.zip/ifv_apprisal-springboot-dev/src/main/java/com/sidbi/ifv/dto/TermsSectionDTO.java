package com.sidbi.ifv.dto;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class TermsSectionDTO {

	
	private Long termId;
	
	private Long ifvId;
	
	private String termSectionCode;
	
	private String termSectionDesc;
	
	private String termSectionlistType;
	
	private String termsSanctionConditionOrder;
	
	private String termsEditableFlag;
	
	private String termsConditionOrder;
	
	private String termConditionOrder;
	
	private String termEditableFlag;
	
	private String termSectionlistConditionOrder;

}
