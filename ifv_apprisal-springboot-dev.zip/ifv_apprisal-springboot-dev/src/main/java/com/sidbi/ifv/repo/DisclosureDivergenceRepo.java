package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.DisclosureDivergenceEntity;

public interface DisclosureDivergenceRepo extends JpaRepository<DisclosureDivergenceEntity, Long> {

	List<DisclosureDivergenceEntity> findByIfvId(Long ifvId);

}
