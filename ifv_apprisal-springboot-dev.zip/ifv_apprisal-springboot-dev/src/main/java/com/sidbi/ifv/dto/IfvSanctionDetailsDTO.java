package com.sidbi.ifv.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class IfvSanctionDetailsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	private String bnlRequestNo;

	private BigDecimal bnaApplAmt;

	private Date bnaApplSubmitDt;

	private String bnaApplProjDesc;

	private String bnaSancRemarks;

	private BigDecimal bnaPrjctCost;

	private String bnaSancAuth;

	private String bnlCustCd;

	private Date bnlSanctDt;

	private BigDecimal bnlSanctAmt;

	private BigDecimal bnlDocRate;

	private BigDecimal bnlFiRate;

	private BigDecimal bnlLdRate;

	private String bnlIntFreq;

	private String bnlFundCd;

	private Date bnlCutOffDate;

	private String bnlSchCd;

	private BigDecimal bnlMoratorium;

	private String bnlCurrency;

	private BigDecimal bnlDealwiseAverage;

	private BigDecimal bnlIncrementCostBorrow;

	private String bnlSlAcctNo;

	private String bnaApplNo;

	private String bnlStatus;

	private Long bnlSrNo;

	private String loiNo;

	private Date loiDate;

	private String bnlInterestType;

	private String bnlBenchmark;

	private String bnlSpread;

	private String bnlInterestReset;

	private Date bnlMaturityDate;

	private String bnlPrincipalRepayment;

	private Integer bnlTenure;

	private BigDecimal tranche;

	private String incrementalCostBorrowingType;

	private String icbFixedFloating;

	private String icbBenchMark;

	private String icbSpread;
}
