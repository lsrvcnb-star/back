package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.UcbEligibilityCriteriaDTO;
import com.sidbi.ifv.entity.UcbEligibilityCriteriaEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.UcbEligibilityCriteriaRepo;
import com.sidbi.ifv.services.UcbEligibilityCriteriaService;

@Service
public class UcbEligibilityCriteriaServiceImpl implements UcbEligibilityCriteriaService {

	private static final Logger logger = LoggerFactory.getLogger(UcbEligibilityCriteriaServiceImpl.class);

	@Autowired
	private UcbEligibilityCriteriaRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public UcbEligibilityCriteriaDTO findById(Long id) {
		logger.info("findById() started in UcbFinancialPerformanceServiceImpl for UcbEligibilityCriteriaEntity {} ",
				id);
		UcbEligibilityCriteriaEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("UCBEligibilityCriteriaEntity", id));
		return mapper.map(entity, UcbEligibilityCriteriaDTO.class);
	}

	@Override
	public List<UcbEligibilityCriteriaDTO> findAll() {
		logger.info("findAll() started in UcbFinancialPerformanceServiceImpl of UcbEligibilityCriteriaEntity");
		try {
			List<UcbEligibilityCriteriaEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, UcbEligibilityCriteriaDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all UcbEligibilityCriteriaEntity .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all UcbEligibilityCriteriaEntity ." + msg + " ", e);
		}
	}

	@Override
	public UcbEligibilityCriteriaDTO save(UcbEligibilityCriteriaDTO dto) {
		logger.info("save() started in UcbFinancialPerformanceServiceImpl for UcbEligibilityCriteriaEntity {} ", dto);
		try {
			UcbEligibilityCriteriaEntity entity = mapper.map(dto, UcbEligibilityCriteriaEntity.class);
			repository.save(entity);
			return mapper.map(entity, UcbEligibilityCriteriaDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating UcbEligibilityCriteriaEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  UcbEligibilityCriteriaEntity." + msg + " ", e);
		}
	}

	@Override
	public List<UcbEligibilityCriteriaDTO> saveAll(List<UcbEligibilityCriteriaDTO> dtos) {
		logger.info("saveAll() started in UcbFinancialPerformanceServiceImpl for List of UcbEligibilityCriteriaEntity");
		try {

			List<UcbEligibilityCriteriaEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, UcbEligibilityCriteriaEntity.class)).collect(Collectors.toList());
			List<UcbEligibilityCriteriaEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, UcbEligibilityCriteriaDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all UcbEligibilityCriteriaEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all UcbEligibilityCriteriaEntity." + msg + " ", e);
		}
	}

	@Override
	public UcbEligibilityCriteriaDTO update(Long id, UcbEligibilityCriteriaDTO dto) {
		logger.info("update() started in UcbFinancialPerformanceServiceImpl for UcbEligibilityCriteriaEntity {} {} ",
				id, dto);
		try {
			UcbEligibilityCriteriaEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbEligibilityCriteriaEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, UcbEligibilityCriteriaDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating UcbEligibilityCriteriaEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating UcbEligibilityCriteriaEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in UcbFinancialPerformanceServiceImpl for UcbEligibilityCriteriaEntity {} ", id);
		try {
			UcbEligibilityCriteriaEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbEligibilityCriteriaEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting UcbEligibilityCriteriaEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting UcbEligibilityCriteriaEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<UcbEligibilityCriteriaDTO> findAllByIfvId(Long ifvId) {
		logger.info(
				"findAllByIfvId() started in UcbFinancialPerformanceServiceImpl for UcbEligibilityCriteriaEntity {} ",
				ifvId);
		try {

			List<UcbEligibilityCriteriaEntity> list = repository.findByIfvId(ifvId);
			return (list != null
					&& !list.isEmpty())
							? list.stream().sorted(Comparator.comparing(UcbEligibilityCriteriaEntity::getId))
									.map(UcbEligibilityCriteriaEntity -> mapper.map(UcbEligibilityCriteriaEntity,
											UcbEligibilityCriteriaDTO.class))
									.collect(Collectors.toList())
							: new ArrayList<>();

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId UcbEligibilityCriteriaEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId UcbEligibilityCriteriaEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
