package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.InvestorDTO;

public interface InvestorService {

	List<InvestorDTO> findAll();

	InvestorDTO findById(Long id);

	InvestorDTO save(InvestorDTO investorDTO);

	InvestorDTO update(Long id, InvestorDTO investorDTO);

	void deleteAppraisal(Long id);
	
	List<InvestorDTO> saveAll(List<InvestorDTO> listInvestorDTO);

	List<InvestorDTO> findAllByIfvId(Long ifvId);

	CommonDTO saveCommonDTO(CommonDTO commonDTO);

	CommonDTO findCommonDTOByIfvId(Long ifvId);
}
