package com.sidbi.ifv.enums;

import java.util.Arrays;

public enum UserDesignationEnum {

	CONSULTANT_CA(229, "Consultant CA"), MANAGER(41, "Manager"),
	ASSISTANT_GENERAL_MANAGER(26, "Assistant General Manager"), DEPUTY_GENERAL_MANAGER(20, "Deputy General Manager"),
	GENERAL_MANAGER(12, "General Manager"), CHIEF_GENERAL_MANAGER(9, "Chief General Manager");

	private int code;

	private String designationName;

	private UserDesignationEnum(int code, String designationName) {
		this.code = code;
		this.designationName = designationName;
	}

	public int getCode() {
		return code;
	}

	public String getDesignationName() {
		return designationName;
	}

	public static String getNameByCode(int code) {
		return Arrays.stream(UserDesignationEnum.values()).filter(e -> e.getCode() == code).findFirst()
				.map(UserDesignationEnum::getDesignationName)
				.orElseThrow(() -> new IllegalArgumentException("No matching name found for code: " + code));
	}

}
