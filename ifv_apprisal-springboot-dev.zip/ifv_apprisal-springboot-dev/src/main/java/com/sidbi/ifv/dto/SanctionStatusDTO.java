package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class SanctionStatusDTO {

	private Long sanctStatusCode;

	private String agendaNumber;

	private Long ifvId;

	private String sanctDscnStatus;

	private String minSumryCreated;

	private String branchName;

	private String unitName;

	private String schemeName;

	private BigDecimal schemeCd;

	private String applicationNo;

	private BigDecimal loanAmount;

	private Date applicationDt;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

}
