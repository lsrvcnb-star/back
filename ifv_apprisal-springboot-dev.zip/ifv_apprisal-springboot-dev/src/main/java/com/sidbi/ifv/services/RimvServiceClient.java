package com.sidbi.ifv.services;

import org.springframework.stereotype.Service;

import com.sidbi.ifv.client.IfvRimvServiceClient;
import com.sidbi.ifv.dto.IfvRimvAppDto;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RimvServiceClient {

	private final IfvRimvServiceClient ifvRimvServiceClient;

	public Boolean forwardDocumentsToRimv(IfvRimvAppDto rimvAppDto) {
		return ifvRimvServiceClient.forwardDocumentsToRimv(rimvAppDto);
	}

}
