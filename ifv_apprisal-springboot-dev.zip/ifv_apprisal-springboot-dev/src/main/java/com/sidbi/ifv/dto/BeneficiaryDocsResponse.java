package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BeneficiaryDocsResponse {

	private Long id;
	private String bnRefNo;
	private String cifNumber;
	private String bankName;
	private String fileName;
	private String filePath;
	private String fileType;
	private LocalDateTime uploadDateTime;
	private String uploadBy;
	private String remarks;
	private String validated;
	private String uploadByEmail;
	private String scheme;
	private BigDecimal refinanceAmount;
	private String module;
}
