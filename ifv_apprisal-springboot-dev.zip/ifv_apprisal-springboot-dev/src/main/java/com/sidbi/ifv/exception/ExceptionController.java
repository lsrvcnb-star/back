package com.sidbi.ifv.exception;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.firewall.RequestRejectedException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import com.sidbi.ifv.model.CVWebResponse;
import com.sidbi.ifv.model.Response2;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class ExceptionController {

	private static final Logger log = LoggerFactory.getLogger(ExceptionController.class);

	/**
	 * Handles validation exceptions for request parameters and body
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach(error -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});
		logException(null, ex);
		return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handles Spring Boot 3's handler method validation exceptions
	 */
	@ExceptionHandler(HandlerMethodValidationException.class)
	public ResponseEntity<ErrorDetails> handleHandlerMethodValidationException(HandlerMethodValidationException ex,
			WebRequest request) {
		ErrorDetails errorDetails = buildErrorDetails(request, "Method validation failed",
				HttpStatus.BAD_REQUEST.name());
		logException(request, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handles HTTP message parsing errors
	 */
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<ErrorDetails> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex,
			WebRequest request) {
		ErrorDetails errorDetails = buildErrorDetails(request, "Malformed JSON request", HttpStatus.BAD_REQUEST.name());
		logException(request, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handles IllegalArgumentException
	 */
	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseBody
	public ResponseEntity<Response2<String>> handleIllegalArgumentException(HttpServletRequest request,
			IllegalArgumentException ex) {
		logException(null, ex);
		return Response2.generateResponse("Invalid argument: " + ex.getMessage(), HttpStatus.BAD_REQUEST, "014");
	}

	/**
	 * Handles missing request parts in multipart requests
	 */
	@ExceptionHandler(MissingServletRequestPartException.class)
	@ResponseBody
	public ResponseEntity<Response2<String>> handleMissingServletRequestPartException(HttpServletRequest request,
			MissingServletRequestPartException ex) {
		logException(null, ex);
		return Response2.generateResponse("You must select at least one file to submit", HttpStatus.BAD_REQUEST, "009");
	}

	/**
	 * Handles multipart upload errors
	 */
	@ExceptionHandler(MultipartException.class)
	@ResponseBody
	public ResponseEntity<Response2<String>> handleMultipartException(HttpServletRequest request,
			MultipartException ex) {
		logException(null, ex);
		return Response2.generateResponse("Invalid file upload request: " + ex.getMessage(), HttpStatus.BAD_REQUEST,
				"007");
	}

	/**
	 * Handles unauthorized access exceptions
	 */
	@ExceptionHandler(UnauthorisedException.class)
	@ResponseBody
	public ResponseEntity<Response2<String>> handleUnauthorisedException(HttpServletRequest request,
			UnauthorisedException ex) {
		logException(null, ex);
		return Response2.generateResponse("Request is unauthorized: " + ex.getMessage(), HttpStatus.UNAUTHORIZED,
				"013");
	}

	/**
	 * Handles username not found exceptions from Spring Security
	 */
	@ExceptionHandler(UsernameNotFoundException.class)
	@ResponseBody
	public ResponseEntity<Response2<String>> handleUsernameNotFoundException(HttpServletRequest request,
			UsernameNotFoundException ex) {
		logException(null, ex);
		return Response2.generateResponse("Invalid credentials", HttpStatus.UNAUTHORIZED, "000");
	}

	/**
	 * Handles request rejected exceptions from Spring Security
	 */
	@ExceptionHandler(RequestRejectedException.class)
	@ResponseBody
	public ResponseEntity<Response2<String>> handleRequestRejectedException(HttpServletRequest request,
			RequestRejectedException ex) {
		logException(null, ex);
		return Response2.generateResponse("Request rejected: " + ex.getMessage(), HttpStatus.UNAUTHORIZED, "000");
	}

	/**
	 * Handles entity not found exceptions
	 */
	@ExceptionHandler(EntityNotFoundException.class)
	public ResponseEntity<ErrorDetails> handleEntityNotFoundException(EntityNotFoundException ex, WebRequest request) {
		ErrorDetails errorDetails = buildErrorDetails(request, ex.getMessage(), "ENTITY_NOT_FOUND");
		logException(request, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}

	/**
	 * Handles no handler found exceptions (404)
	 */
	@ExceptionHandler({ NoHandlerFoundException.class, NoResourceFoundException.class })
	public ResponseEntity<ErrorDetails> handleNoHandlerFoundException(Exception ex, HttpServletRequest request) {
		ErrorDetails errorDetails = new ErrorDetails(LocalDateTime.now(), "The requested resource was not found",
				request.getRequestURI(), HttpStatus.NOT_FOUND.name());
		logException(null, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}

	/**
	 * Handles database operation exceptions
	 */
	@ExceptionHandler(DatabaseOperationException.class)
	public ResponseEntity<ErrorDetails> handleDatabaseOperationException(DatabaseOperationException ex,
			WebRequest request) {
		ErrorDetails errorDetails = buildErrorDetails(request, ex.getMessage(), "DATABASE_ERROR");
		logException(request, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(CryptoOperationException.class)
	public ResponseEntity<ErrorDetails> handleCryptoOperationException(CryptoOperationException ex,
			WebRequest request) {

		ErrorDetails errorDetails = buildErrorDetails(request, ex.getMessage(), "INVALID_ENCRYPTED_DATA");

		logException(request, ex);

		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handles report generation exceptions
	 */
	@ExceptionHandler(ReportGenerationException.class)
	public ResponseEntity<ErrorDetails> handleReportException(ReportGenerationException ex, WebRequest request) {
		ErrorDetails errorDetails = buildErrorDetails(request, ex.getMessage(), "REPORT_GENERATION_ERROR");
		logException(request, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Handles file upload exceptions
	 */
	@ExceptionHandler(FileUploadException.class)
	public ResponseEntity<ErrorDetails> handleFileUploadException(FileUploadException ex, WebRequest request) {
		ErrorDetails errorDetails = buildErrorDetails(request, ex.getMessage(), "FILE_UPLOAD_ERROR");
		logException(request, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Handles IO exceptions
	 */
	@ExceptionHandler(IOException.class)
	public ResponseEntity<Response2<String>> handleIOException(IOException ex, WebRequest request) {
		logException(request, ex);
		return Response2.generateResponse("I/O error occurred: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR,
				"006");
	}

	/**
	 * Handles client errors when calling external APIs
	 */
	@ExceptionHandler(HttpClientErrorException.class)
	public ResponseEntity<CVWebResponse> handleHttpClientErrorException(HttpClientErrorException ex,
			WebRequest request) {
		logException(request, ex);
		CVWebResponse response = CVWebResponse.builder().success(false)
				.errorMessage("Client error when calling external API: " + ex.getMessage())
				.errorCode(ex.getStatusCode().value()).build();
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handles server errors from external APIs
	 */
	@ExceptionHandler(HttpServerErrorException.class)
	public ResponseEntity<CVWebResponse> handleHttpServerErrorException(HttpServerErrorException ex,
			WebRequest request) {
		logException(request, ex);
		CVWebResponse response = CVWebResponse.builder().success(false)
				.errorMessage("Server error from external API: " + ex.getMessage())
				.errorCode(ex.getStatusCode().value()).build();
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Handles resource access exceptions when calling external APIs
	 */
	@ExceptionHandler(ResourceAccessException.class)
	public ResponseEntity<CVWebResponse> handleResourceAccessException(ResourceAccessException ex, WebRequest request) {
		String message = "Failed to connect to external API";

		if (ex.getCause() instanceof ConnectException) {
			message = "Connection refused to external API. Check if the server is running.";
		} else if (ex.getCause() instanceof SocketTimeoutException) {
			message = "Connection timeout when calling external API. Check network or increase timeout.";
		}

		logException(request, ex);
		CVWebResponse response = CVWebResponse.builder().success(false).errorMessage(message).build();
		return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
	}

	/**
	 * Handles general REST client exceptions
	 */
	@ExceptionHandler(RestClientException.class)
	public ResponseEntity<CVWebResponse> handleRestClientException(RestClientException ex, WebRequest request) {
		logException(request, ex);
		CVWebResponse response = CVWebResponse.builder().success(false)
				.errorMessage("Error calling external API: " + ex.getMessage()).build();
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(ExternalServiceException.class)
	public ResponseEntity<ErrorDetails> handleExternalServiceException(ExternalServiceException ex,
			WebRequest request) {
		log.error("External service failure", ex);
		ErrorDetails response = buildErrorDetails(request, ex.getMessage(), "EXTERNAL_SERVICE_ERROR");
		return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
	}

	@ExceptionHandler(EmailSendFailedException.class)
	public ResponseEntity<ErrorDetails> handleEmailSendFailed(EmailSendFailedException ex, WebRequest request) {
		ErrorDetails error = buildErrorDetails(request, ex.getMessage(), "EMAIL_SEND_FAILED");
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(error);
	}

	@ExceptionHandler(BadCredentialsException.class)
	public ResponseEntity<ErrorDetails> handleBadCredentials(BadCredentialsException ex, WebRequest request) {

		ErrorDetails error = buildErrorDetails(request, "Invalid credentials", "AUTH_FAILED");

		return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
	}

	/**
	 * Catch-all handler for any unhandled exceptions
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorDetails> handleException(Exception ex, WebRequest request) {
		ErrorDetails errorDetails = buildErrorDetails(request, "An unexpected error occurred", "INTERNAL_SERVER_ERROR");
		logException(request, ex);
		return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Helper method to build error details
	 */
	private ErrorDetails buildErrorDetails(WebRequest request, String message, String errorCode) {
		return new ErrorDetails(LocalDateTime.now(), message, request.getDescription(false), errorCode);
	}

	/**
	 * Comprehensive exception logging
	 */
	private void logException(WebRequest request, Exception ex) {
		log.error("Exception: [{}] Message: [{}]", ex.getClass().getSimpleName(), ex.getMessage());

		// Log root cause
		Throwable rootCause = ExceptionUtils.getRootCause(ex);
		if (rootCause != null && rootCause != ex) {
			log.error("Root cause: [{}] Message: [{}]", rootCause.getClass().getSimpleName(), rootCause.getMessage());
		}

		// Log request information if available
		if (request != null) {
			log.error("Request path: [{}]", request.getDescription(false));
		}

		// Log the first relevant stack trace element from our application
		for (StackTraceElement element : ex.getStackTrace()) {
			if (element.getClassName().contains("com.sidbi.ifv")) {
				log.error("At: {}.{}:{}", element.getClassName(), element.getMethodName(), element.getLineNumber());
				break;
			}
		}

		// For serious errors, log the full stack trace
		if (ex instanceof RuntimeException || ex instanceof IOException) {
			log.debug("Full stack trace:", ex);
		}
	}
}