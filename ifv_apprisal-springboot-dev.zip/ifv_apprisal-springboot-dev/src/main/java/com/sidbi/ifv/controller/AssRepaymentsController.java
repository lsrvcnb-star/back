package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.AssRepaymentsDTO;
import com.sidbi.ifv.services.AssRepaymentsService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcrepayment")
public class AssRepaymentsController {
	private static final Logger logger = LoggerFactory.getLogger(AssRepaymentsController.class);

	@Autowired
	AssRepaymentsService s2IFFCCAssRepaymentsService;

	@GetMapping("/get/{id}")
	public ResponseEntity<AssRepaymentsDTO> findById(@PathVariable Long id) {
		logger.info("findById() started AssRepaymentsController {} ",id);
		AssRepaymentsDTO s2IFFCCAssRepaymentsDTOFind = s2IFFCCAssRepaymentsService.findById(id);
		return ResponseEntity.ok(s2IFFCCAssRepaymentsDTOFind);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<AssRepaymentsDTO>> findAll() {
		logger.info("findAll() started AssRepaymentsController ");
		List<AssRepaymentsDTO> list = s2IFFCCAssRepaymentsService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<AssRepaymentsDTO> save(@RequestBody AssRepaymentsDTO applicationDTO) {
		logger.info("save() started AssRepaymentsController {} ",applicationDTO);
		AssRepaymentsDTO createdApplication = s2IFFCCAssRepaymentsService.save(applicationDTO);
		return ResponseEntity.ok(createdApplication);
	}
	
	@PostMapping("/saveAll")
	public ResponseEntity<List<AssRepaymentsDTO>> saveAll(@RequestBody List<AssRepaymentsDTO> listAssRepaymentsDTO) {
		logger.info("saveAll() started in AssRepaymentsController ");
		List<AssRepaymentsDTO> savedAssRepaymentsDTOs = s2IFFCCAssRepaymentsService.saveAll(listAssRepaymentsDTO);
		return ResponseEntity.ok(savedAssRepaymentsDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<AssRepaymentsDTO> update(@PathVariable Long id,
			@RequestBody AssRepaymentsDTO applicationDTO) {
		logger.info("update() started AssRepaymentsController {} ",applicationDTO);
		AssRepaymentsDTO updatedApplication = s2IFFCCAssRepaymentsService.update(id, applicationDTO);
		return ResponseEntity.ok(updatedApplication);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started AssRepaymentsController {} ",id);
		s2IFFCCAssRepaymentsService.delete(id);
		return ResponseEntity.noContent().build();
	}
	
	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<AssRepaymentsDTO>> getAllS2IFVAssRepaymentsEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllS2IFVAssRepaymentsEntityOnIfvId() started in AssRepaymentsController ");
		List<AssRepaymentsDTO> assRepaymentsDTOs = s2IFFCCAssRepaymentsService.findAllByIfvId(ifvId);
 
		AssRepaymentsDTO assRepaymentsDTO = assRepaymentsDTOs.stream()
				.filter(e -> e.getRpRefinanceAcc() != null && !e.getRpRefinanceAcc().isEmpty()).findFirst()
				.orElse(null);
		if (assRepaymentsDTO != null) {
			assRepaymentsDTOs.forEach(e -> {
				e.setRpRefinanceAcc(assRepaymentsDTO.getRpRefinanceAcc());
				e.setRpRepaymentTrack(assRepaymentsDTO.getRpRepaymentTrack());
			});
		}
 
		return ResponseEntity.ok(assRepaymentsDTOs);
	}
}
