package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class MinutesForwardRequest {

	private Long minuteId;

	private Character fwdRejFlag;

	private Long ofrCode;

	private String userName;

	private Long checkerId;

	private String comment;
}
