package com.sidbi.ifv.entity;

import java.io.IOException;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.FileRepositoryDTO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_FILE_REPOSITORY")
public class S2IFVFileRepositoryEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "file_code")
	private Long fileCode;

	@Column(name = "file_module")
	private String fileModule;

	@Column(name = "file_ifv_id")
	private Long fileIfvId;

	@Column(name = "file_type")
	private String fileType;

	@Column(name = "file_data")
	private byte[] fileData;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "file_content_type")
	private String fileContentType;

	@Column(name = "file_domain")
	private String fileDomain;

	@Column(name = "date_of_action")
	private Date dateOfAction;

	@Column(name = "sanc_min_detail_id")
	private Long sancMinDetailId;

	@Column(name = "file_alco_id")
	private Long fileAlcoId;

	@Column(name = "loi_id")
	private Long loiId;

	@Column(name = "prop_loi_id")
	private Long propLoiId;

	@Column(name = "file_path")
	private String filePath;

	public static S2IFVFileRepositoryEntity fromDTO(FileRepositoryDTO fileRepositoryDTO) throws IOException {
		S2IFVFileRepositoryEntity s2ifvFileRepositoryEntity = new S2IFVFileRepositoryEntity();
		s2ifvFileRepositoryEntity.setFileData(convertMultipartToByteArray(fileRepositoryDTO.getFileData()));
		s2ifvFileRepositoryEntity.setFileContentType(fileRepositoryDTO.getFileData().getContentType());
		s2ifvFileRepositoryEntity.setFileType(determineFileType(fileRepositoryDTO.getFileData()));
		s2ifvFileRepositoryEntity.setFileName(fileRepositoryDTO.getFileData().getOriginalFilename());
		s2ifvFileRepositoryEntity.setDateOfAction(new Date());
		s2ifvFileRepositoryEntity.setFileModule(fileRepositoryDTO.getFileModule());
		s2ifvFileRepositoryEntity.setFileDomain(fileRepositoryDTO.getFileDomain());
		s2ifvFileRepositoryEntity.setFileIfvId(fileRepositoryDTO.getFileIfvId());
		s2ifvFileRepositoryEntity.setSancMinDetailId(fileRepositoryDTO.getSancMinDetailId());
		s2ifvFileRepositoryEntity.setFileAlcoId(fileRepositoryDTO.getFileAlcoId());
		s2ifvFileRepositoryEntity.setLoiId(fileRepositoryDTO.getLoiId());
		s2ifvFileRepositoryEntity.setPropLoiId(fileRepositoryDTO.getPropLoiId());
		return s2ifvFileRepositoryEntity;
	}

	private static byte[] convertMultipartToByteArray(MultipartFile file) throws IOException {
		return file.getBytes();
	}

	private static String determineFileType(MultipartFile file) {
		String contentType = file.getContentType();
		String originalFileName = file.getOriginalFilename();
		if (contentType != null && contentType.startsWith("image")) {
			return "image";
		} else if (originalFileName != null && originalFileName.toLowerCase().endsWith(".pdf")) {
			return "pdf";
		} else if (originalFileName != null && (originalFileName.toLowerCase().endsWith(".doc")
				|| originalFileName.toLowerCase().endsWith(".docx"))) {
			return "document";
		} else {
			return "unknown";
		}
	}

}
