package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.DisclosureDivergenceDto;
import com.sidbi.ifv.entity.DisclosureDivergenceEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.DisclosureDivergenceRepo;
import com.sidbi.ifv.services.DisclosureDivergenceService;

@Service
public class DisclosureDivergenceServiceImpl implements DisclosureDivergenceService {

	private static final Logger logger = LoggerFactory.getLogger(DisclosureDivergenceServiceImpl.class);

	@Autowired
	private DisclosureDivergenceRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public DisclosureDivergenceDto findById(Long id) {
		logger.info("findById() started in DisclosureDivergenceServiceImpl for DisclosureDivergenceEntity {} ", id);
		DisclosureDivergenceEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("DIsclosureDivergenceEntity", id));
		return mapper.map(entity, DisclosureDivergenceDto.class);
	}

	@Override
	public List<DisclosureDivergenceDto> findAll() {
		logger.info("findAll() started in DisclosureDivergenceServiceImpl of DisclosureDivergenceEntity");
		try {
			List<DisclosureDivergenceEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, DisclosureDivergenceDto.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all UcbTop10Borrowers .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all UcbTop10Borrowers ." + msg + " ",
					e);
		}
	}

	@Override
	public DisclosureDivergenceDto save(DisclosureDivergenceDto dto) {
		logger.info("save() started in DisclosureDivergenceServiceImpl for DisclosureDivergenceEntity {} ", dto);
		try {
			DisclosureDivergenceEntity entity = mapper.map(dto, DisclosureDivergenceEntity.class);
			repository.save(entity);
			return mapper.map(entity, DisclosureDivergenceDto.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating DisclosureDivergenceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  DisclosureDivergenceEntity." + msg + " ", e);
		}
	}

	@Override
	public List<DisclosureDivergenceDto> saveAll(List<DisclosureDivergenceDto> dtos) {
		logger.info("saveAll() started in DisclosureDivergenceServiceImpl for List of DisclosureDivergenceEntity");
		try {

			List<DisclosureDivergenceEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, DisclosureDivergenceEntity.class)).collect(Collectors.toList());
			List<DisclosureDivergenceEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, DisclosureDivergenceDto.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all UcbTop10Borrowers. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all UcbTop10Borrowers." + msg + " ", e);
		}
	}

	@Override
	public DisclosureDivergenceDto update(Long id, DisclosureDivergenceDto dto) {
		logger.info("update() started in DisclosureDivergenceServiceImpl for DisclosureDivergenceEntity {} {} ", id,
				dto);
		try {
			DisclosureDivergenceEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("DisclosureDivergenceEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, DisclosureDivergenceDto.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating DisclosureDivergenceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating DisclosureDivergenceEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in DisclosureDivergenceServiceImpl for DisclosureDivergenceEntity {} ", id);
		try {
			DisclosureDivergenceEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("DisclosureDivergenceEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting DisclosureDivergenceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting DisclosureDivergenceEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<DisclosureDivergenceDto> findByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in DisclosureDivergenceServiceImpl for DisclosureDivergenceEntity {} ",
				ifvId);
		try {

			List<DisclosureDivergenceEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty()) ? list.stream().map(
					DisclosureDivergenceEntity -> mapper.map(DisclosureDivergenceEntity, DisclosureDivergenceDto.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId DisclosureDivergenceEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId DisclosureDivergenceEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
