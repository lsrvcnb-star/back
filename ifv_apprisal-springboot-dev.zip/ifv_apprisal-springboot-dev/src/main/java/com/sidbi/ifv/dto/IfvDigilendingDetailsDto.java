package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public class IfvDigilendingDetailsDto {

	private String bbdUserId;
	private Long bbdSrNo;
	private String bbdStateName;
	private String bbdStateCode;
	private Integer bbdDistrictCode;
	private String bbdAcctOfUnit;
	private String bbdNameOfUnit;
	private String bbdAddrOfUnit;
	private String bbdPanOfUnit;
	private LocalDate bbdDateOfBirthInc;
	private String bbdUrcNoOfUnit;
	private Long mobileNoLinkedUrc;
	private String newEnterpriseNos;
	private String existingEnterpriseNos;
	private String bbdNameOfActivity;
	private Integer bbdCateSc;
	private Integer bbdCateSt;
	private Integer bbdCateWe;
	private Integer bbdCateMc;
	private Integer bbdCateGen;
	private Integer bbdMicroMfgNos;
	private Integer bbdMicroServiceNos;
	private Integer bbdSmallMfgNos;
	private Integer bbdSmallServiceNos;
	private Integer bbdMediumMfgNos;
	private Integer bbdMediumServiceNos;
	private Integer bbdMicrofinanceBorrower;
	private Integer bbdEmployeeGenNo;
	private BigDecimal bbdTlLoanSanc;
	private BigDecimal bbdWcLoanSanc;
	private LocalDate dateOfDisburseLoanDisb;
	private BigDecimal bbdTlLoanDisb;
	private BigDecimal bbdWcLoanDisb;
	private BigDecimal bbdTlLoanOs;
	private BigDecimal bbdWcLoanOs;
	private BigDecimal bbdRateOfInterestChng;
	private Integer bbdProcessingFee;
	private BigDecimal bbdRefinanceClmd;
	private String bbdBackendFlag;
	private LocalDate transferDt;
	private String push2dfsStatus;
	private LocalDate push2dfsDt;
	private String acctNo;
	private LocalDate disbDt;
	private String refNo;
	private LocalDate refDate;
}
