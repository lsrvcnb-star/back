package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.FinancialHighlightsDTO;

public interface FinancialHighlightsService {

	List<FinancialHighlightsDTO> findAll();

	FinancialHighlightsDTO findById(Long id);

	FinancialHighlightsDTO save(FinancialHighlightsDTO financialHighlightsDTO);

	FinancialHighlightsDTO update(Long id, FinancialHighlightsDTO financialHighlightsDTO);

	void deleteAppraisal(Long id);

	List<FinancialHighlightsDTO> saveAll(List<FinancialHighlightsDTO> listFinancialHighlightsDTO);

	List<FinancialHighlightsDTO> findAllByIfvId(Long ifvId);

	String getDisclosureStatus(Long ifvId);
}
