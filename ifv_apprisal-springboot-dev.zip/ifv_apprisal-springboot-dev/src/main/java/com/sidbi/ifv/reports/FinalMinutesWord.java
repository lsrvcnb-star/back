package com.sidbi.ifv.reports;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTBorder;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHMerge;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTInd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTJcTable;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPBdr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTSpacing;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTbl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblBorders;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcBorders;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcMar;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTVMerge;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTVerticalJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STBorder;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STJcTable;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STMerge;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STVerticalJc;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.dto.SanctionMinutesDTO;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.entity.SanctionMinutesDtlEntity;
import com.sidbi.ifv.exception.DocumentExportException;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.util.CommonUtil;

public class FinalMinutesWord {

	private static final int DEFAULT_FONT_SIZE = 10;

	private final SanctionMinutesDTO sanctionMinutesDetails;
	private final List<SanctionMinutesDtlEntity> sanctionMinutesDtl;
	private final List<AppraisalMinutesDataDTO> appraisalMinutesDataDetails;
	private final String committeeName;
	private final List<CmtMemberMasterDTO> lCommitteeMembers;
	private final ProposedSchemaRepository proposedSchemaRepository;

	public FinalMinutesWord(SanctionMinutesDTO sanctionMinutesDetails,
			List<SanctionMinutesDtlEntity> sanctionMinutesDtl,
			List<AppraisalMinutesDataDTO> appraisalMinutesDataDetails, String committeeName,
			List<CmtMemberMasterDTO> lCommitteeMembers, ProposedSchemaRepository proposedSchemaRepository) {
		this.sanctionMinutesDetails = sanctionMinutesDetails;
		this.sanctionMinutesDtl = sanctionMinutesDtl;
		this.appraisalMinutesDataDetails = appraisalMinutesDataDetails;
		this.committeeName = committeeName;
		this.lCommitteeMembers = lCommitteeMembers;
		this.proposedSchemaRepository = proposedSchemaRepository;
	}

	public byte[] export() throws DocumentExportException {
		try (XWPFDocument document = new XWPFDocument()) {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			// Title
			XWPFParagraph title = document.createParagraph();
			title.setAlignment(ParagraphAlignment.CENTER);
			XWPFRun titleRun = title.createRun();
			titleRun.setText("बैठक का कार्यवृत्त / Minutes of Meeting");
			titleRun.setBold(true);
			titleRun.setUnderline(UnderlinePatterns.SINGLE);
			titleRun.setFontSize(DEFAULT_FONT_SIZE);
			// Create main table with padding
			XWPFTable mainTable = document.createTable(6, 3);
			setTableWidth(mainTable, 100);
			setCellPadding(mainTable);
			// Set column widths
			CTTblWidth[] colWidths = new CTTblWidth[3];
			for (int i = 0; i < 3; i++) {
				colWidths[i] = CTTblWidth.Factory.newInstance();
				colWidths[i].setType(STTblWidth.DXA);
			}
			colWidths[0].setW(BigInteger.valueOf(432));
			colWidths[1].setW(BigInteger.valueOf(4464));
			colWidths[2].setW(BigInteger.valueOf(4464));
			// Apply the column widths and center align serial numbers
			setColAlignment(mainTable, colWidths);
			// Add rows with proper line breaks
			addTableRow(mainTable, 0, "1", "समिति / Committee", committeeName);
			addTableRow(mainTable, 1, "2", "बैठक क्रमांक / Meeting No.", getMeetingNumber());
			addTableRow(mainTable, 2, "3", "बैठक की तिथि / Date of Meeting", formatMeetingDate());
			addTableRowWithFormattedMembers(mainTable, 3, "4", "उपस्थित सदस्य / Members present", "Quorum – 3",
					getMembersPresent());
			addTableRow(mainTable, 4, "5", "अनुपस्थिति की छुट्टी प्रदान करना / Grant of leave of absence",
					getLeaveOfAbsence());
			// Row 6 with merged cells
			XWPFTableRow row6 = mainTable.getRow(5);
			XWPFTableCell serialCell = row6.getCell(0);
			serialCell.setText("6");
			XWPFParagraph serialPara = serialCell.getParagraphs().get(0);
			XWPFRun run = serialPara.getRuns().get(0);
			run.setFontSize(DEFAULT_FONT_SIZE);
			serialPara.setAlignment(ParagraphAlignment.CENTER);
			serialCell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.TOP);
			// Get the cell to be merged
			XWPFTableCell mergedCell = row6.getCell(1);
			XWPFParagraph mergedPara = mergedCell.getParagraphs().get(0);
			XWPFRun mergedRun = mergedPara.createRun();
			mergedRun.setText("बैंको को वित्तीय सहायता की मंजूरी / Sanction of financial assistance to banks");
			mergedRun.setFontSize(DEFAULT_FONT_SIZE);
			mergedRun.setBold(true);
			mergedRun.setUnderline(UnderlinePatterns.SINGLE);
			mergedRun.addBreak();
			mergedRun.addBreak();
			XWPFRun slSixPara = mergedPara.createRun();
			slSixPara.setText(
					"समिति ने निम्नलिखित बैंकों को वित्तीय सहायता की मंजूरी हेतु इंगित शर्तों पर आईएफवी के प्रस्तावों पर विचार-विमर्श किया। / The Committee deliberated on IFV proposal(s) for sanction of financial assistance to the following bank(s) on the terms indicated:");
			slSixPara.setFontSize(DEFAULT_FONT_SIZE);
			createFinancialAssistanceTable(mergedCell);

			XWPFParagraph newPara = mergedCell.addParagraph();
			addResolutionText(newPara);

			// Set merged cell properties
			CTTcPr tcPr = mergedCell.getCTTc().getTcPr();
			if (tcPr == null)
				tcPr = mergedCell.getCTTc().addNewTcPr();
			CTTblWidth cellWidth = tcPr.addNewTcW();
			cellWidth.setType(STTblWidth.DXA);
			cellWidth.setW(BigInteger.valueOf(8640));
			CTHMerge hMerge = tcPr.addNewHMerge();
			hMerge.setVal(STMerge.RESTART);
			CTTcBorders borders = tcPr.isSetTcBorders() ? tcPr.getTcBorders() : tcPr.addNewTcBorders();
			CTBorder border = CTBorder.Factory.newInstance();
			border.setVal(STBorder.SINGLE);
			border.setSz(BigInteger.valueOf(4));
			borders.setLeft(border);
			borders.setRight(border);
			borders.setTop(border);
			borders.setBottom(border);
			XWPFTableCell continueCell = row6.getCell(2);
			CTTcPr continueTcPr = continueCell.getCTTc().getTcPr();
			if (continueTcPr == null)
				continueTcPr = continueCell.getCTTc().addNewTcPr();
			CTHMerge continueMerge = continueTcPr.addNewHMerge();
			continueMerge.setVal(STMerge.CONTINUE);

			addConvenorBlock(document);

			List<String> employeCodes = new LinkedList<>();
			String chairmanCode = sanctionMinutesDetails.getChairmanCode();
			if (chairmanCode != null && !chairmanCode.isEmpty()) {
				employeCodes.add(chairmanCode);
			}

			if (sanctionMinutesDetails.getMemberCode() != null && !sanctionMinutesDetails.getMemberCode().isEmpty()) {
				String[] memberList = sanctionMinutesDetails.getMemberCode().split(",");

				for (String mList : memberList) {
					employeCodes.add(mList);
				}
			}
			int memberCount = employeCodes.size();

			XWPFTable table2 = document.createTable(1, memberCount);
			table2.setWidth("100%");
			memberTable(table2, memberCount);

			addPSRADMD(document);
			addFootNote(document);

			document.write(out);
			return out.toByteArray();

		} catch (Exception e) {
			throw new DocumentExportException("Failed to export document", e);
		}
	}

	private void setColAlignment(XWPFTable mainTable, CTTblWidth[] colWidths) {
		for (XWPFTableRow row : mainTable.getRows()) {
			for (int i = 0; i < row.getTableCells().size(); i++) {
				XWPFTableCell cell = row.getCell(i);
				cell.getCTTc().addNewTcPr().setTcW(colWidths[i]);
				if (i == 0) {
					cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
					XWPFParagraph paragraph = cell.getParagraphs().get(0);
					paragraph.setAlignment(ParagraphAlignment.CENTER);
				}
			}
		}
	}

	private void setCellPadding(XWPFTable table) {
		for (XWPFTableRow row : table.getRows()) {
			setTableCellPadding(row);
		}
	}

	private void setTableCellPadding(XWPFTableRow row) {
		for (XWPFTableCell cell : row.getTableCells()) {
			CTTcPr tcPr = cell.getCTTc().getTcPr();
			if (tcPr == null)
				tcPr = cell.getCTTc().addNewTcPr();
			CTTcMar cellMargin = tcPr.isSetTcMar() ? tcPr.getTcMar() : tcPr.addNewTcMar();
			CTTblWidth left = cellMargin.isSetLeft() ? cellMargin.getLeft() : cellMargin.addNewLeft();
			left.setType(STTblWidth.DXA);
			left.setW(BigInteger.valueOf(50));
			CTTblWidth right = cellMargin.isSetRight() ? cellMargin.getRight() : cellMargin.addNewRight();
			right.setType(STTblWidth.DXA);
			right.setW(BigInteger.valueOf(10));
			CTTblWidth top = cellMargin.isSetTop() ? cellMargin.getTop() : cellMargin.addNewTop();
			top.setType(STTblWidth.DXA);
			top.setW(BigInteger.valueOf(10));
			CTTblWidth bottom = cellMargin.isSetBottom() ? cellMargin.getBottom() : cellMargin.addNewBottom();
			bottom.setType(STTblWidth.DXA);
			bottom.setW(BigInteger.valueOf(10));
		}
	}

	private void addTableRowWithFormattedMembers(XWPFTable table, int rowIndex, String serial, String label,
			String labelExtra, String content) {
		XWPFTableRow row = table.getRow(rowIndex);
		// Serial number cell
		XWPFTableCell serialCell = row.getCell(0);
		serialCell.setText(serial);
		XWPFParagraph serialPara = serialCell.getParagraphs().get(0);
		XWPFRun run = serialPara.getRuns().get(0);
		run.setFontSize(DEFAULT_FONT_SIZE);
		serialPara.setAlignment(ParagraphAlignment.CENTER);
		serialCell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.TOP);
		XWPFTableCell labelCell = row.getCell(1);
		XWPFParagraph labelPara = labelCell.getParagraphs().get(0);
		XWPFRun labelRun = labelPara.createRun();
		labelRun.setText(label);
		labelRun.addBreak();
		labelRun.addBreak();
		labelRun.setText(labelExtra);
		labelRun.setFontSize(DEFAULT_FONT_SIZE);
		XWPFTableCell contentCell = row.getCell(2);
		XWPFParagraph contentPara = contentCell.getParagraphs().get(0);
		XWPFRun headerRun = contentPara.createRun();
		headerRun.setText("सदस्य / Members: सर्वश्री / S/Shri");
		headerRun.setBold(true);
		headerRun.setUnderline(UnderlinePatterns.SINGLE);
		headerRun.setFontSize(DEFAULT_FONT_SIZE);
		headerRun.addBreak();
		String[] sections = content.split("\n");
		for (String line : sections) {
			if (line.trim().isEmpty())
				continue;
			if (line.contains("Convenor") && !line.contains("Alternate")) {
				XWPFRun breakRun = contentPara.createRun();
				breakRun.addBreak();
				XWPFRun convenorRun = contentPara.createRun();
				convenorRun.setText("संयोजक / (Convenor):");
				convenorRun.setBold(true);
				convenorRun.setFontSize(DEFAULT_FONT_SIZE);
				convenorRun.setUnderline(UnderlinePatterns.SINGLE);
				convenorRun.addBreak();
			} else if (line.contains("Alternate Convenor")) {
				XWPFRun breakRun = contentPara.createRun();
				breakRun.addBreak();
				XWPFRun altConvenorRun = contentPara.createRun();
				altConvenorRun.setText("वैकल्पिक संयोजक / (Alternate Convenor):");
				altConvenorRun.setBold(true);
				altConvenorRun.setFontSize(DEFAULT_FONT_SIZE);
				altConvenorRun.setUnderline(UnderlinePatterns.SINGLE);
				altConvenorRun.addBreak();
			} else {
				XWPFRun memberRun = contentPara.createRun();
				if (line.matches("^\\d+\\).*")) {
					memberRun.setText("    " + line);
				} else {
					memberRun.setText(line);
				}
				memberRun.setFontSize(DEFAULT_FONT_SIZE);
				memberRun.addBreak();
			}
		}
	}

	// Updated setTableWidth method
	private void setTableWidth(XWPFTable table, int percentage) {
		CTTbl ttbl = table.getCTTbl();
		CTTblPr tblPr = ttbl.getTblPr() == null ? ttbl.addNewTblPr() : ttbl.getTblPr();
		CTTblWidth tblWidth = tblPr.isSetTblW() ? tblPr.getTblW() : tblPr.addNewTblW();
		tblWidth.setType(STTblWidth.PCT);
		tblWidth.setW(BigInteger.valueOf(percentage * 50));
	}

	private void addTableRow(XWPFTable table, int rowIndex, String col1, String col2, String col3) {
		XWPFTableRow row = table.getRow(rowIndex);
		setCellTextAndFont(row.getCell(0), col1, true);
		setCellTextAndFont(row.getCell(1), col2, false);
		setCellTextAndFont(row.getCell(2), col3, false);
	}

	private void setCellTextAndFont(XWPFTableCell cell, String text, boolean isSlNoField) {
		// Clear existing paragraphs first
		while (cell.getParagraphs().size() > 0) {
			cell.removeParagraph(0);
		}
		// Create new paragraph and run
		XWPFParagraph paragraph = cell.addParagraph();
		XWPFRun run = paragraph.createRun();
		run.setText(text);
		run.setFontSize(DEFAULT_FONT_SIZE);
		if (isSlNoField) {
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.TOP);
		}

	}

	private String getMeetingNumber() {
		String meetingNo = String.valueOf(sanctionMinutesDetails.getMeetingNo());
		int year = Year.now().getValue();
		int month = LocalDate.now().getMonthValue();

		if (month >= 3) {
			return meetingNo + " / " + year + "-" + String.valueOf(year + 1).substring(2, 4);
		} else {
			return meetingNo + " / " + (year - 1) + "-" + String.valueOf(year).substring(2, 4);
		}
	}

	private String formatMeetingDate() {
		if (sanctionMinutesDetails.getMeetingDate() != null) {
			LocalDate localDate = sanctionMinutesDetails.getMeetingDate().toInstant()
					.atZone(java.time.ZoneId.systemDefault()).toLocalDate();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
			return localDate.format(formatter);
		}
		return "";
	}

	private String getMembersPresent() {
		StringBuilder result = new StringBuilder();

		String chairmanCode = sanctionMinutesDetails.getChairmanCode();
		List<String> employeCodes = new ArrayList<>();

		if (chairmanCode != null && !chairmanCode.isEmpty()) {
			employeCodes.add(chairmanCode);
		}

		if (sanctionMinutesDetails.getMemberCode() != null) {
			Collections.addAll(employeCodes, sanctionMinutesDetails.getMemberCode().split(","));
		}

		Map<String, CmtMemberMasterDTO> mCmtMaster = lCommitteeMembers.stream()
				.collect(Collectors.toMap(CmtMemberMasterDTO::getMemberCode, Function.identity()));

		setMemberDetails(result, chairmanCode, employeCodes, mCmtMaster);

		return result.toString();
	}

	private void setMemberDetails(StringBuilder result, String chairmanCode, List<String> employeCodes,
			Map<String, CmtMemberMasterDTO> mCmtMaster) {
		int count = 1;
		for (String code : employeCodes) {
			CmtMemberMasterDTO member = mCmtMaster.get(code);
			if (member != null) {
				result.append(count++).append(") ");
				result.append(member.getMemberShortName());
				result.append(", CGM, ").append(member.getMemberVertical());
				if (code.equals(chairmanCode)) {
					result.append(" (Chairman¹)");
				}
				result.append("\n");
			}
		}

		// Handling Convenor
		if (sanctionMinutesDetails.getConvenorCode() != null && !sanctionMinutesDetails.getConvenorCode().isEmpty()) {
			CmtMemberMasterDTO convenor = mCmtMaster.get(sanctionMinutesDetails.getConvenorCode());
			if (convenor != null) {
				result.append("संयोजक / (Convenor)").append("\n");
				result.append(count++).append(") ").append(convenor.getMemberShortName());
				result.append(", GM, ").append(convenor.getMemberVertical());
			}
		}

		// Handling Alternate Convenor
		if (sanctionMinutesDetails.getAlConvenorCode() != null
				&& !sanctionMinutesDetails.getAlConvenorCode().isEmpty()) {
			CmtMemberMasterDTO altConvenor = mCmtMaster.get(sanctionMinutesDetails.getAlConvenorCode());
			if (altConvenor != null) {
				result.append(" / (Alternate Convenor)").append("\n");
				result.append(count).append(") ").append(altConvenor.getMemberShortName());
				result.append(", DGM, ").append(altConvenor.getMemberVertical());
			}
		}
	}

	private String getLeaveOfAbsence() {
		List<String> lCmtMembers = lCommitteeMembers.stream()
				.filter(e -> e.getCmtType().equalsIgnoreCase("MB") || e.getCmtType().equalsIgnoreCase("CM"))
				.map(CmtMemberMasterDTO::getMemberCode).collect(Collectors.toList());

		List<String> employeCodes = new ArrayList<>();
		if (sanctionMinutesDetails.getChairmanCode() != null) {
			employeCodes.add(sanctionMinutesDetails.getChairmanCode());
		}
		if (sanctionMinutesDetails.getMemberCode() != null) {
			Collections.addAll(employeCodes, sanctionMinutesDetails.getMemberCode().split(","));
		}

		List<String> lLeaveMembers = lCmtMembers.stream().filter(e -> !employeCodes.contains(e))
				.collect(Collectors.toList());

		String leaveMembers = "";

		Map<String, CmtMemberMasterDTO> mCmtMaster = lCommitteeMembers.stream()
				.collect(Collectors.toMap(CmtMemberMasterDTO::getMemberCode, Function.identity()));
		for (String s : lLeaveMembers) {

			CmtMemberMasterDTO dto = mCmtMaster.get(s);
			if (dto != null) {
				String name = "     Shri " + dto.getMemberShortName() + ", CGM, " + dto.getMemberVertical();

				leaveMembers = leaveMembers + name + "\n";
			}

		}

		return leaveMembers;
	}

	private String getConvenorName() {
		Map<String, CmtMemberMasterDTO> mCmtMaster = lCommitteeMembers.stream()
				.collect(Collectors.toMap(CmtMemberMasterDTO::getMemberCode, Function.identity()));

		String convenorCode = sanctionMinutesDetails.getConvenorCode();
		if (convenorCode != null && mCmtMaster.containsKey(convenorCode)) {
			return mCmtMaster.get(convenorCode).getMemberShortName();
		}

		return "";
	}

	private String getALtConvenorName() {
		Map<String, CmtMemberMasterDTO> mCmtMaster = lCommitteeMembers.stream()
				.collect(Collectors.toMap(CmtMemberMasterDTO::getMemberCode, Function.identity()));

		String altConvenorCode = sanctionMinutesDetails.getAlConvenorCode();
		if (altConvenorCode != null && mCmtMaster.containsKey(altConvenorCode)) {
			return mCmtMaster.get(altConvenorCode).getMemberShortName();
		}

		return "";
	}

	private String calculateTotal() {
		BigDecimal total = sanctionMinutesDtl.stream().map(e -> {
			List<AppraisalMinutesDataDTO> lEntities = appraisalMinutesDataDetails.stream()
					.filter(e1 -> e1.getSancDtlCode().equals(e.getSancDtlCode())).toList();
			if (!lEntities.isEmpty()) {
				return lEntities.stream().map(AppraisalMinutesDataDTO::getLoanAmount).reduce(BigDecimal.ZERO,
						BigDecimal::add);
			} else {
				return proposedSchemaRepository.findByAppNo(e.getAppid()).stream()
						.map(S2IFVProposedSchemaEntity::getPrAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
			}
		}).reduce(BigDecimal.ZERO, BigDecimal::add);
		return CommonUtil.formatNumber(total.stripTrailingZeros().toPlainString());
	}

	private void createFinancialAssistanceTable(XWPFTableCell mergedCell) {
		XWPFParagraph tableParagraph = mergedCell.addParagraph();
		XWPFTable table = mergedCell.insertNewTbl(tableParagraph.getCTP().newCursor());
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		if (tblPr == null) {
			tblPr = table.getCTTbl().addNewTblPr();
		}
		CTTblWidth width = tblPr.isSetTblW() ? tblPr.getTblW() : tblPr.addNewTblW();
		width.setType(STTblWidth.PCT);
		width.setW(BigInteger.valueOf(4980));
		CTTblBorders borders = tblPr.isSetTblBorders() ? tblPr.getTblBorders() : tblPr.addNewTblBorders();
		borders.addNewTop().setVal(STBorder.SINGLE);
		borders.addNewBottom().setVal(STBorder.SINGLE);
		borders.addNewLeft().setVal(STBorder.SINGLE);
		borders.addNewRight().setVal(STBorder.SINGLE);
		borders.addNewInsideH().setVal(STBorder.SINGLE);
		borders.addNewInsideV().setVal(STBorder.SINGLE);
		int borderSize = 4;
		borders.getTop().setSz(BigInteger.valueOf(borderSize));
		borders.getBottom().setSz(BigInteger.valueOf(borderSize));
		borders.getLeft().setSz(BigInteger.valueOf(borderSize));
		borders.getRight().setSz(BigInteger.valueOf(borderSize));
		borders.getInsideH().setSz(BigInteger.valueOf(borderSize));
		borders.getInsideV().setSz(BigInteger.valueOf(borderSize));
		String[] headers = { "कार्यसूची स. / Agenda No.", "बैंक का नाम / Name of the bank", "राशि / Amount (crore)",
				"योजना / Scheme", "ब्याज दर / RoI Payable monthly (% p.a.)", "अवधि / Tenor (In months)",
				"मूलधन चुकौती / Principal repayment" };
		XWPFTableRow headerRow = table.getRow(0);
		if (headerRow == null) {
			headerRow = table.createRow();
		}
		for (int i = 0; i < headers.length; i++) {
			XWPFTableCell cell = headerRow.getCell(i);
			if (cell == null) {
				cell = headerRow.createCell();
			}
			XWPFParagraph paragraph = cell.getParagraphs().get(0);
			paragraph.setSpacingBefore(10);
			paragraph.setSpacingAfter(10);
			XWPFRun run = paragraph.createRun();
			run.setText(headers[i]);
			run.setBold(true);
			run.setFontSize(DEFAULT_FONT_SIZE);
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			CTTcPr tcPr = cell.getCTTc().addNewTcPr();
			CTTcMar tcMar = tcPr.addNewTcMar();
			CTTblWidth topMargin = tcMar.addNewTop();
			topMargin.setType(STTblWidth.DXA);
			topMargin.setW(BigInteger.valueOf(10));
			CTTblWidth bottomMargin = tcMar.addNewBottom();
			bottomMargin.setType(STTblWidth.DXA);
			bottomMargin.setW(BigInteger.valueOf(10));
			CTTblWidth leftMargin = tcMar.addNewLeft();
			leftMargin.setType(STTblWidth.DXA);
			leftMargin.setW(BigInteger.valueOf(10));
			CTTblWidth rightMargin = tcMar.addNewRight();
			rightMargin.setType(STTblWidth.DXA);
			rightMargin.setW(BigInteger.valueOf(10));
			cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
		}
		flashMinutesTable(table);
	}

	private void flashMinutesTable(XWPFTable table) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		List<AppraisalMinutesDataDTO> lAppraisalMinutesDataEntities = new ArrayList<>();
		BigDecimal total = null;

		setAppraisalMinutesData(lAppraisalMinutesDataEntities);

		if (!CollectionUtils.isEmpty(lAppraisalMinutesDataEntities)) {

			lAppraisalMinutesDataEntities.sort(Comparator.comparing(AppraisalMinutesDataDTO::getAgendaNo));
			total = this.normalizeDecimalsAndGetTotal(lAppraisalMinutesDataEntities);
			String previousAgendaNo = null;
			XWPFTableCell agendaCell = null;
			XWPFTableCell bankCell = null;
			int currentRow = 1;
			for (AppraisalMinutesDataDTO sanList : lAppraisalMinutesDataEntities) {
				XWPFTableRow row = table.getRow(currentRow) != null ? table.getRow(currentRow) : table.createRow();
				boolean isNewAgenda = !sanList.getAgendaNo().toString().equals(previousAgendaNo);
				if (isNewAgenda) {
					// Handle merged cells for Agenda No
					agendaCell = row.getCell(0);
					XWPFParagraph agendaPara = agendaCell.getParagraphs().get(0);
					XWPFRun agendaRun = agendaPara.createRun();
					agendaRun.setText(sanList.getAgendaNo().toString());
					agendaRun.setFontSize(DEFAULT_FONT_SIZE);
					agendaPara.setAlignment(ParagraphAlignment.CENTER);
					agendaCell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
					setVerticalMergeForTable(agendaCell, STMerge.RESTART);
					// Handle merged cells for Bank Name
					bankCell = row.getCell(1);
					XWPFParagraph bankPara = bankCell.getParagraphs().get(0);
					XWPFRun bankRun = bankPara.createRun();
					bankRun.setFontSize(DEFAULT_FONT_SIZE);
					bankRun.setText(sanList.getBankName());
					bankPara.setAlignment(ParagraphAlignment.LEFT);
					bankCell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
					setVerticalMergeForTable(bankCell, STMerge.RESTART);
					previousAgendaNo = sanList.getAgendaNo().toString();
				} else {
					// Continue vertical merge for existing agenda and bank cells
					setVerticalMergeForTable(row.getCell(0), STMerge.CONTINUE);
					setVerticalMergeForTable(row.getCell(1), STMerge.CONTINUE);
				}
				// Loan Amount
				setLoanAmount(sanList, row);
				// Scheme Name
				setSchemeName(sanList, row);
				// Interest Rate
				setInterestRate(sanList, row);
				// Tenure
				String month = sanList.getTenure() != null ? sanList.getTenure().toString() : "";
				setCellValue(row.getCell(5), month, ParagraphAlignment.RIGHT);
				// Principal Repayment
				setPrincRepayment(format, sanList, row);
				currentRow++;
			}
			// Add total row
			XWPFTableRow totalRow = table.createRow();
			setCellValue(totalRow.getCell(0), "", ParagraphAlignment.CENTER);
			XWPFTableCell totalLabelCell = totalRow.getCell(1);
			XWPFParagraph totalPara = totalLabelCell.getParagraphs().get(0);
			XWPFRun totalRunEnglish = totalPara.createRun();
			totalRunEnglish.setText("कुल / Total");
			totalRunEnglish.setBold(true);
			totalRunEnglish.setFontSize(DEFAULT_FONT_SIZE);
			setCellValue(totalRow.getCell(2), CommonUtil.formatNumber(total.toPlainString()), ParagraphAlignment.RIGHT);
			for (int i = 3; i < 7; i++) {
				setCellValue(totalRow.getCell(i), "", ParagraphAlignment.CENTER);
			}
		}
	}

	private void setLoanAmount(AppraisalMinutesDataDTO sanList, XWPFTableRow row) {
		setCellValue(row.getCell(2),
				sanList.getLoanAmount() != null ? CommonUtil.formatNumber(sanList.getLoanAmount().toPlainString()) : "",
				ParagraphAlignment.RIGHT);
	}

	private void setPrincRepayment(SimpleDateFormat format, AppraisalMinutesDataDTO sanList, XWPFTableRow row) {
		String princRep = sanList.getPrincipalRepayment() != null ? sanList.getPrincipalRepayment() : "";
		if (sanList.getMaturityDate() != null) {
			princRep += "\n(Maturing on " + format.format(sanList.getMaturityDate()) + ")";
		}
		setCellValue(row.getCell(6), princRep, ParagraphAlignment.CENTER);
	}

	private void setSchemeName(AppraisalMinutesDataDTO sanList, XWPFTableRow row) {
		String schemeName = sanList.getSchemeName() != null ? sanList.getSchemeName() : "";
		if (schemeName.equalsIgnoreCase("RMSE")) {
			schemeName = this.getSchemeName(sanList.getFundName());
		}
		setCellValue(row.getCell(3), schemeName, ParagraphAlignment.LEFT);
	}

	private void setInterestRate(AppraisalMinutesDataDTO sanList, XWPFTableRow row) {
		String benchMark = sanList.getBenchMark();
		if (StringUtils.hasText(benchMark)) {

			if (benchMark.toUpperCase().contains("REPO RATE")) {
				benchMark = "RBI Repo";
			}

			StringBuilder stringBuilder = new StringBuilder(benchMark);

			if (StringUtils.hasText(sanList.getSpread())) {
				stringBuilder.append(" + " + sanList.getSpread() + " bps");
			}

			if (StringUtils.hasText(sanList.getInterestType())) {
				stringBuilder.append("\n(" + sanList.getInterestType() + ")@");
			}
			setCellValue(row.getCell(4), stringBuilder.toString(), ParagraphAlignment.CENTER);
		} else {
			String roi = sanList.getInterestRate() != null ? formatRoi(sanList.getInterestRate()) : "";
			if (StringUtils.hasText(sanList.getInterestType())) {
				roi += "\n(" + sanList.getInterestType() + ")";
			}
			setCellValue(row.getCell(4), roi, ParagraphAlignment.RIGHT);
		}
	}

	private void setAppraisalMinutesData(List<AppraisalMinutesDataDTO> lAppraisalMinutesDataEntities) {
		sanctionMinutesDtl.forEach(e -> {
			List<AppraisalMinutesDataDTO> lEntities = appraisalMinutesDataDetails.stream()
					.filter(e1 -> e1.getSancDtlCode().equals(e.getSancDtlCode())).toList();

			if (!CollectionUtils.isEmpty(lEntities)) {
				lAppraisalMinutesDataEntities.addAll(lEntities);
			} else {

				List<S2IFVProposedSchemaEntity> list = proposedSchemaRepository.findByAppNo(e.getAppid());
				list.forEach(e2 -> {
					AppraisalMinutesDataDTO dto = new AppraisalMinutesDataDTO();
					dto.setBankName(e.getUnitName());
					dto.setSancDtlCode(e.getSancDtlCode());
					dto.setAgendaNo(Long.parseLong(e.getAgendaNo().toString()));
					dto.setLoanAmount(e2.getPrAmount());
					dto.setFundName(e2.getPrFundname());
					dto.setSchemeName(e2.getPrSchemeName());
					dto.setInterestRate(e2.getPrRoi());
					dto.setTenure(e2.getPrTenure().intValue());
					dto.setPrincipalRepayment(e2.getPrPrincipalRepayment());
					dto.setMaturityDate(e2.getPrMaturityDate());
					dto.setBenchMark(e2.getBenchMark());
					dto.setSpread(e2.getSpread());
					dto.setInterestReset(e2.getInterestReset());
					dto.setInterestType(e2.getInterestType());
					lAppraisalMinutesDataEntities.add(dto);
				});
			}
		});
	}

	public BigDecimal normalizeDecimalsAndGetTotal(List<AppraisalMinutesDataDTO> items) {
		int maxDecimals = items.stream().map(item -> getDecimalPlaces(item.getLoanAmount())).max(Integer::compare)
				.orElse(0);
		BigDecimal total = items.stream().map(AppraisalMinutesDataDTO::getLoanAmount).reduce(BigDecimal.ZERO,
				BigDecimal::add);
		if (maxDecimals > 0) {
			items.forEach(item -> {
				BigDecimal extendedAmount = item.getLoanAmount().stripTrailingZeros().setScale(maxDecimals);
				item.setLoanAmount(extendedAmount);
			});
			total = total.stripTrailingZeros().setScale(maxDecimals);
		} else {
			items.forEach(item -> item.setLoanAmount(item.getLoanAmount().stripTrailingZeros()));
			total = total.stripTrailingZeros();
		}
		return total;
	}

	private int getDecimalPlaces(BigDecimal number) {
		String stringValue = number.stripTrailingZeros().toPlainString();
		int index = stringValue.indexOf('.');
		return index < 0 ? 0 : stringValue.length() - index - 1;
	}

	private void setCellBordersAndPadding(XWPFTableCell cell) {
		CTTcPr tcPr = cell.getCTTc().isSetTcPr() ? cell.getCTTc().getTcPr() : cell.getCTTc().addNewTcPr();
		CTTcBorders borders = tcPr.isSetTcBorders() ? tcPr.getTcBorders() : tcPr.addNewTcBorders();
		CTBorder border = CTBorder.Factory.newInstance();
		border.setVal(STBorder.SINGLE);
		border.setSz(BigInteger.valueOf(4));
		border.setColor("000000"); // Black color
		borders.setTop(border);
		borders.setBottom(border);
		borders.setLeft(border);
		borders.setRight(border);
		CTTcMar margins = tcPr.isSetTcMar() ? tcPr.getTcMar() : tcPr.addNewTcMar();
		BigInteger padding = BigInteger.valueOf(10);
		if (!margins.isSetTop())
			margins.addNewTop().setW(padding);
		if (!margins.isSetBottom())
			margins.addNewBottom().setW(padding);
		if (!margins.isSetLeft())
			margins.addNewLeft().setW(50);
		if (!margins.isSetRight())
			margins.addNewRight().setW(50);
	}

	private void setCellValue(XWPFTableCell cell, String value, ParagraphAlignment alignment) {
		if (cell == null || value == null)
			return;
		XWPFParagraph paragraph = cell.getParagraphs().get(0);
		for (int i = paragraph.getRuns().size() - 1; i >= 0; i--) {
			paragraph.removeRun(i);
		}
		paragraph.setSpacingBefore(10);
		paragraph.setSpacingAfter(10);
		paragraph.setAlignment(alignment);
		// Handle newlines in content
		String[] lines = value.split("\n");
		for (int i = 0; i < lines.length; i++) {
			XWPFRun run = paragraph.createRun();
			run.setText(lines[i]);
			run.setFontSize(DEFAULT_FONT_SIZE);
			if (i < lines.length - 1) {
				run.addBreak();
			}
		}
		// Set cell properties
		CTTcPr tcPr = cell.getCTTc().addNewTcPr();
		// Add cell margins (padding)
		CTTcMar tcMar = tcPr.addNewTcMar();
		// Top margin
		CTTblWidth topMargin = tcMar.addNewTop();
		topMargin.setType(STTblWidth.DXA);
		topMargin.setW(BigInteger.valueOf(10));
		// Bottom margin
		CTTblWidth bottomMargin = tcMar.addNewBottom();
		bottomMargin.setType(STTblWidth.DXA);
		bottomMargin.setW(BigInteger.valueOf(10));
		// Left margin
		CTTblWidth leftMargin = tcMar.addNewLeft();
		leftMargin.setType(STTblWidth.DXA);
		leftMargin.setW(BigInteger.valueOf(50));
		// Right margin
		CTTblWidth rightMargin = tcMar.addNewRight();
		rightMargin.setType(STTblWidth.DXA);
		rightMargin.setW(BigInteger.valueOf(50));
		// Set borders for each cell
		CTTcBorders borders = tcPr.addNewTcBorders();
		borders.addNewTop().setVal(STBorder.SINGLE);
		borders.addNewBottom().setVal(STBorder.SINGLE);
		borders.addNewLeft().setVal(STBorder.SINGLE);
		borders.addNewRight().setVal(STBorder.SINGLE);
		// Set border size
		borders.getTop().setSz(BigInteger.valueOf(4));
		borders.getBottom().setSz(BigInteger.valueOf(4));
		borders.getLeft().setSz(BigInteger.valueOf(4));
		borders.getRight().setSz(BigInteger.valueOf(4));
		cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
	}

	private void setVerticalMergeForTable(XWPFTableCell cell, STMerge.Enum type) {
		CTVMerge vMerge = CTVMerge.Factory.newInstance();
		vMerge.setVal(type);
		CTTcPr tcPr = cell.getCTTc().isSetTcPr() ? cell.getCTTc().getTcPr() : cell.getCTTc().addNewTcPr();
		tcPr.setVMerge(vMerge);
		setCellBordersAndPadding(cell);
	}

	private String formatRoi(BigDecimal roi) {
		if (roi.scale() > 0) {
			return roi.setScale(2, RoundingMode.HALF_UP).toPlainString();
		}
		return roi.toPlainString();
	}

	public String getSchemeName(String schemeName) {
		String wordToFind = "FUND";
		int index = schemeName.indexOf(wordToFind);
		if (index != -1) {
			return schemeName.substring(0, index).trim();
		}
		return schemeName;
	}

	private void addResolutionText(XWPFParagraph para) {
		String total = calculateTotal();
		XWPFRun run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setText(
				"समिति ने विचार-विमर्श के बाद प्रस्तावों को मंजूरी दी और निम्नलिखित प्रस्ताव पारित किया / The Committee, after deliberations, sanctioned the proposal(s) and passed the following resolution:");
		run.addBreak();
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setText("“यह संकल्प किया जाता है कि उपर्युक्त बैंकों को ₹");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setBold(true);
		run.setText(total);
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setText(" ");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setBold(true);
		run.setText("करोड़");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setText(" की वित्तीय सहायता की मंजूरी के प्रस्ताव एतदद्वारा अनुमोदित किए जाते हैं |” / “");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setBold(true);
		run.setText("RESOLVED THAT");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setText(" the proposal(s) of financial assistance of ₹");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setBold(true);
		run.setText(total);
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setText(" ");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setBold(true);
		run.setText("crore");
		run = para.createRun();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setText(" to the above bank(s) be and are hereby sanctioned.”");
	}

	private void addConvenorBlock(XWPFDocument document) {
		XWPFParagraph signaturePara = document.createParagraph();
		signaturePara.setAlignment(ParagraphAlignment.LEFT);
		String convenorName = getConvenorName();
		String convOrAltConvText = StringUtils.hasText(convenorName) ? "(संयोजक / Convenor)"
				: "(वैकल्पिक संयोजक / Alternate Convenor)";
		String convOrAltConvName = StringUtils.hasText(convenorName) ? convenorName : getALtConvenorName();
		XWPFRun run = signaturePara.createRun();
		run.addBreak();
		run.setText("(" + convOrAltConvName + ")");
		run.addBreak();
		run.setText(convOrAltConvText);
		run.addBreak();
		run.addBreak();
		run.setFontSize(DEFAULT_FONT_SIZE);
	}

	private void memberTable(XWPFTable table, int memberCount) {
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		if (tblPr == null) {
			tblPr = table.getCTTbl().addNewTblPr();
		}
		CTJcTable jc = tblPr.addNewJc();
		jc.setVal(STJcTable.CENTER);
		String chairmanCode = sanctionMinutesDetails.getChairmanCode();
		List<String> employeCodes = new LinkedList<>();
		if (chairmanCode != null && !chairmanCode.isEmpty()) {
			employeCodes.add(chairmanCode);
		}
		if (sanctionMinutesDetails.getMemberCode() != null && !sanctionMinutesDetails.getMemberCode().isEmpty()) {
			String[] memberList = sanctionMinutesDetails.getMemberCode().split(",");
			Collections.addAll(employeCodes, memberList);
		}
		Map<String, CmtMemberMasterDTO> mCmtMaster = lCommitteeMembers.stream()
				.collect(Collectors.toMap(CmtMemberMasterDTO::getMemberCode, Function.identity()));
		Collections.reverse(employeCodes);
		XWPFTableRow nameRow = table.getRow(0);
		XWPFTableRow roleRow = table.createRow();
		table.setWidth("100%");
		CTTblWidth tblWidth = tblPr.addNewTblW();
		tblWidth.setW(BigInteger.valueOf(memberCount * 2000)); // Adjust width based on member count
		tblWidth.setType(STTblWidth.DXA);
		int cellIndex = 0;
		for (String memberCode : employeCodes) {
			CmtMemberMasterDTO dto = mCmtMaster.get(memberCode);
			if (dto != null) {
				XWPFTableCell nameCell = nameRow.getCell(cellIndex);
				if (nameCell == null) {
					nameCell = nameRow.createCell();
				}
				setCellProperties(nameCell, dto.getMemberShortName(), true);
				XWPFTableCell roleCell = roleRow.getCell(cellIndex);
				if (roleCell == null) {
					roleCell = roleRow.createCell();
				}
				String role = memberCode.equalsIgnoreCase(chairmanCode) ? "अध्यक्ष / Chairman" : "सदस्य / Member";
				setCellProperties(roleCell, role, false);
				cellIndex++;
			}
		}
	}

	private void setCellProperties(XWPFTableCell cell, String text, boolean isHeader) {
		CTTc ctTc = cell.getCTTc();
		CTTcPr tcPr = ctTc.addNewTcPr();
		CTVerticalJc va = tcPr.addNewVAlign();
		va.setVal(STVerticalJc.CENTER);
		cell.setText(""); // Clear existing content
		XWPFParagraph paragraph = cell.getParagraphs().get(0);
		paragraph.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun run = paragraph.createRun();
		run.setText(text);
		if (isHeader) {
			run.setBold(true);
			run.setFontSize(DEFAULT_FONT_SIZE);
		} else {
			run.setFontSize(9);
		}
		CTTcMar tcMar = tcPr.addNewTcMar();
		CTTblWidth top = tcMar.addNewTop();
		top.setW(BigInteger.valueOf(100));
		top.setType(STTblWidth.DXA);
		CTTblWidth bottom = tcMar.addNewBottom();
		bottom.setW(BigInteger.valueOf(100));
		bottom.setType(STTblWidth.DXA);
		CTTblWidth left = tcMar.addNewLeft();
		left.setW(BigInteger.valueOf(100));
		left.setType(STTblWidth.DXA);
		CTTblWidth right = tcMar.addNewRight();
		right.setW(BigInteger.valueOf(100));
		right.setType(STTblWidth.DXA);
	}

	private void addPSRADMD(XWPFDocument document) {
		XWPFParagraph signaturePara = document.createParagraph();
		signaturePara.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun run = signaturePara.createRun();
		run.addBreak();
		run.setText("कार्योतर मंजूरी रिपोर्टिंग प्राधिकारी / PSRA : उप प्रबंध निदेशक / DMD");
		run.addBreak();
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setBold(true);
		run.setUnderline(UnderlinePatterns.SINGLE);
	}

	private void addFootNote(XWPFDocument document) {
		XWPFParagraph paragraph = document.createParagraph();
		CTPPr ppr = paragraph.getCTP().getPPr();
		if (ppr == null) {
			ppr = paragraph.getCTP().addNewPPr();
		}
		CTSpacing spacing = ppr.isSetSpacing() ? ppr.getSpacing() : ppr.addNewSpacing();
		spacing.setBefore(BigInteger.valueOf(8000)); // Vertical position from top
		spacing.setAfter(BigInteger.valueOf(100));
		spacing.setLine(BigInteger.valueOf(240));
		// Set left indentation
		CTInd ind = ppr.isSetInd() ? ppr.getInd() : ppr.addNewInd();
		ind.setLeft(BigInteger.valueOf(144)); // 1 inch from left margin
		ind.setRight(BigInteger.valueOf(4000)); // Right indentation to limit line length
		CTBorder border = CTBorder.Factory.newInstance();
		border.setVal(STBorder.SINGLE);
		border.setSz(BigInteger.valueOf(2));
		border.setColor("000000");
		border.setSpace(BigInteger.valueOf(8));
		CTPBdr borders = ppr.isSetPBdr() ? ppr.getPBdr() : ppr.addNewPBdr();
		borders.setTop(border);
		XWPFRun run = paragraph.createRun();
		run.setText("¹Being senior most member");
		run.setFontSize(9);
	}
}