package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_ASS_REPAYMENTS")
public class S2IFVAssRepaymentsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RP_ID")
	private Long rpId;
	
	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "RP_REFINANCE_ACC")
	private String rpRefinanceAcc;
	
	@Column(name = "RP_REPAYMENT_TRACK")
	private String rpRepaymentTrack;
	
	@Column(name = "RP_PERIODFY")
	private Integer rpPeriodfy;

	@Column(name = "RP_Q1")
	private BigDecimal rpQ1;
	
	@Column(name = "RP_Q2")
	private BigDecimal rpQ2;
	
	@Column(name = "RP_Q3")
	private BigDecimal rpQ3;
	
	@Column(name = "RP_Q4")
	private BigDecimal rpQ4;
	
	@Column(name = "RP_TOTAL")
	private BigDecimal rpTotal;
	
	@Column(name = "RP_TYPE")
	private String rpType;

}
