package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_PROFILE_BD")
public class S2IFVProfileBdEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PR_CODE")
	private Long prCode;
	
	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "PR_FIRST_NAME")
	private String prFirstName;
	
	@Column(name = "PR_DESIGNATION")
	private String prDesignation;
	
	@Column(name = "PR_BRIEF_PROFILE")
	private String prBriefProfile;
	
	@Column(name = "DATE_OF_ACTION")
	private Date dateOfAction;
	

}
