package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.CollectionEfficiencyEntity;

public interface CollectionEfficiencyRepository extends JpaRepository<CollectionEfficiencyEntity, Long> {

	List<CollectionEfficiencyEntity> findByIfvId(Long ifvId);
}