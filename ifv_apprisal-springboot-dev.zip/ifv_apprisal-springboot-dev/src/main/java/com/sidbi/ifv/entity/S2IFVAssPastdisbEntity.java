package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_ASS_PASTDISB")
public class S2IFVAssPastdisbEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "AE_ID")
	private Long aeId;
	
	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "AE_PERIODFY")
	private Integer aePeriodfy;
	
	@Column(name = "AE_DATE")
	private Date aeDate;
	
	@Column(name = "AE_AMOUNT")
	private BigDecimal aeAmount;
	
	@Column(name = "AE_SCHEME")
	private String aeScheme;
	
	@Column(name = "AE_ROI")
	private BigDecimal aeRoi;
	
	@Column(name = "AE_TENURE")
	private String aeTenure;
	
	@Column(name = "AE_TYPE")
	private String aeType;

}
