package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;


@Data
public class TermConditionsDataDTO {

	private Long tsId;
	
	private Long ifvId;
	
	private String tsUpfrontFee;
	
	private BigDecimal tsMonths;
	
	private String tsDisbursement;
	
	private String tsSpecific;
	
	private String tsBorrowers;
	
	private String tsRampe;
	
	private String tsFabia;
	
	private String tsTermSanction;
	
	private String tsValiditySanction;
	
	private String tsDopSanction;
	
	private String tsDopRelaxtion;
	
	private String tsRecommendation;
	
	private String tsFacilityAmount;
	
	private BigDecimal tsRAteInterest;
	
	private BigDecimal tsTenurePeriod;
	
	private String tsRoiRepayments;
	
	private String tsPrincipalRepayment;
	
	private String tsIntrestPayment;
	
	private String tsTenureWd;
	
	private String tsExtent;
	
	private String tsEligibleMse;
	
	private String tsEligibleActivities;
	
	private String tsEventDflt;
	
	private String tsSecurity;
	
	private String tsDocumentstion;
	
	private String tsTimeFrame;
	
	private String tsDrawalloan;
	
	private String tsOtherCond;
	
	private String tsOutstandingAmount;
	
	private String tsDrawaloan;
	
	private String tsTermsection;

}
