package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.UcbTop10BorrowersDTO;
import com.sidbi.ifv.entity.UcbTop10BorrowersEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.UcbTop10BorrowersRepo;
import com.sidbi.ifv.services.UcbBorrowersService;

@Service
public class UcbBorrowersServiceImpl implements UcbBorrowersService {

	private static final Logger logger = LoggerFactory.getLogger(UcbBorrowersServiceImpl.class);

	@Autowired
	private UcbTop10BorrowersRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public UcbTop10BorrowersDTO findById(Long id) {
		logger.info("findById() started in UcbBorrowersServiceImpl for UcbTop10BorrowersEntity {} ", id);
		UcbTop10BorrowersEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("UCBTop10BorrowersEntity", id));
		return mapper.map(entity, UcbTop10BorrowersDTO.class);
	}

	@Override
	public List<UcbTop10BorrowersDTO> findAll() {
		logger.info("findAll() started in UcbBorrowersServiceImpl of UcbTop10BorrowersEntity");
		try {
			List<UcbTop10BorrowersEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, UcbTop10BorrowersDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all UcbTop10Borrowers .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all UcbTop10Borrowers ." + msg + " ",
					e);
		}
	}

	@Override
	public UcbTop10BorrowersDTO save(UcbTop10BorrowersDTO dto) {
		logger.info("save() started in UcbBorrowersServiceImpl for UcbTop10BorrowersEntity {} ", dto);
		try {
			UcbTop10BorrowersEntity entity = mapper.map(dto, UcbTop10BorrowersEntity.class);
			repository.save(entity);
			return mapper.map(entity, UcbTop10BorrowersDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating UcbTop10BorrowersEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  UcbTop10BorrowersEntity." + msg + " ",
					e);
		}
	}

	@Override
	public List<UcbTop10BorrowersDTO> saveAll(List<UcbTop10BorrowersDTO> dtos) {
		logger.info("saveAll() started in UcbBorrowersServiceImpl for List of UcbTop10BorrowersEntity");
		try {

			List<UcbTop10BorrowersEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, UcbTop10BorrowersEntity.class)).collect(Collectors.toList());
			List<UcbTop10BorrowersEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, UcbTop10BorrowersDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all UcbTop10Borrowers. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all UcbTop10Borrowers." + msg + " ", e);
		}
	}

	@Override
	public UcbTop10BorrowersDTO update(Long id, UcbTop10BorrowersDTO dto) {
		logger.info("update() started in UcbBorrowersServiceImpl for UcbTop10BorrowersEntity {} {} ", id, dto);
		try {
			UcbTop10BorrowersEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbTop10BorrowersEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, UcbTop10BorrowersDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating UcbTop10BorrowersEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating UcbTop10BorrowersEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in UcbBorrowersServiceImpl for UcbTop10BorrowersEntity {} ", id);
		try {
			UcbTop10BorrowersEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbTop10BorrowersEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting UcbTop10BorrowersEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting UcbTop10BorrowersEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<UcbTop10BorrowersDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in UcbBorrowersServiceImpl for UcbTop10BorrowersEntity {} ", ifvId);
		try {

			List<UcbTop10BorrowersEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty()) ? list.stream()
					.map(UcbTop10BorrowersEntity -> mapper.map(UcbTop10BorrowersEntity, UcbTop10BorrowersDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId UcbTop10BorrowersEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId UcbTop10BorrowersEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
