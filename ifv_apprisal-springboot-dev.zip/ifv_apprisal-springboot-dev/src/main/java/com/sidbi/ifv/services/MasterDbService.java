package com.sidbi.ifv.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.PathVariable;

import com.sidbi.ifv.dto.AggregateExposureRequestDto;
import com.sidbi.ifv.dto.AggregateExposureResponseDto;
import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.dto.CustomerDto;
import com.sidbi.ifv.dto.HrmsEmpNameDesignationDTO;
import com.sidbi.ifv.dto.IfvDigilendingDetailsDto;
import com.sidbi.ifv.dto.IfvIntBeneficiaryDetailRequest;
import com.sidbi.ifv.dto.IfvRefMasterDto;
import com.sidbi.ifv.dto.IfvSanctionDetailsDTO;
import com.sidbi.ifv.dto.StatusResponseDto;
import com.sidbi.ifv.dto.TriggerResponseDto;
import com.sidbi.ifv.dto.VerticalDto;
import com.sidbi.ifv.entity.IfvSanctionDetailsEntity;

public interface MasterDbService {

	List<Object> getAllBcmCifData();

	List<Object> getBcmSchemes();

	List<Object> getBcmLocationCodes();

	List<Object> getCustExpo(String cifNumber);

	List<Object> getCustOs(String cifNumber);

	List<Object> getPastDisbursements(String cifNumber);

	List<Object> outStandingDetails(String cifNumber);

	List<Object> bcmFundCodeDetails(String fundAvailable);

	List<Object> futureRepayOfExistingOutStandingDTO(@PathVariable String cifNumber);

	BigDecimal exposureLimitForBarwBank(@PathVariable String cifNumber);

	List<CmtMemberMasterDTO> getHrmsEmpDetails(Integer cmtCode);

	List<Object> getSchemesOnFundCd(String fundCd);

	List<Object> getFundCodeAndDesc();

	List<HrmsEmpNameDesignationDTO> getEmployeeNames(List<String> empIds);

	Object saveSanctionDt(IfvSanctionDetailsEntity sanctionDtEntity);

	List<Object> getAllSanctionDetails();

	List<String> getAllEmpNames();

	HrmsEmpNameDesignationDTO getEmpDetailsOnEmpName(String empName);

	Map<String, String> getEmpCodeAndDesc();

	String getBankType(String custCd);

	Object findBankDetailsByCifNumber(String custCd);

	List<String> getBenchmarkDetails();

	String getAddressByCifNumber(String custCd);

	String getBankShortName(String custCd);

	List<Object> getDistrictsByState(String stateCode);

	Page<IfvSanctionDetailsDTO> getSanctionDetailsOnPage(int start, int size, String filters, String sorting,
			String globalFilter, String status);

	Long getSanctionedProposalsCount();

	Boolean sendDataToDFS(List<Long> minuteIds);

	String getBenchMarkRateByName(String benchMarkName);

	List<BigDecimal> getAllTrancheOnFundCode(String fundCode);

	Page<IfvDigilendingDetailsDto> fetchBenificiaryDetails(int page, int size);

	List<String> fetchLoanAccNoOnCif(String cifNumber);

	Boolean savePreDisbData(IfvRefMasterDto ifvRefMasterDto);

	String saveIfvBeneficiaryDetails(String filePath);

	Map<String, Object> processingStatus(String jobId);

	void saveIfvBeneficiaryDetailsAsync(IfvIntBeneficiaryDetailRequest beneficiaryDetailRequest);

	List<String> fetchDisbDateOnAccNo(String accNo);

	List<VerticalDto> getIfvVerticals();

	List<CustomerDto> fetchCustomersOnVertical(String vertical);

	StatusResponseDto checkStatus(AggregateExposureRequestDto dto);

	TriggerResponseDto triggerProcedure(AggregateExposureRequestDto dto);

	AggregateExposureResponseDto getAggregateExposureData(AggregateExposureRequestDto dto);

	String getGroupNameByCif(String cifNumber);

	BigDecimal getAggregateExposureOnGroup(AggregateExposureRequestDto dto);

}
