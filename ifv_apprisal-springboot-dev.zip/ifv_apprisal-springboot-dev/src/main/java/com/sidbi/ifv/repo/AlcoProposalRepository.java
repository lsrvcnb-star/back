package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.sidbi.ifv.entity.S2IFVAlcoProposalEntity;

public interface AlcoProposalRepository
		extends JpaRepository<S2IFVAlcoProposalEntity, Long>, JpaSpecificationExecutor<S2IFVAlcoProposalEntity> {

	@Query(value = "SELECT  max(al_code) FROM s2_ifv_alco_proposal", nativeQuery = true)
	Long findMaxAlCode();

	S2IFVAlcoProposalEntity findByAlCode(Long alCode);

	List<S2IFVAlcoProposalEntity> findAllByAlCodeIn(List<Long> alCodes);
}
