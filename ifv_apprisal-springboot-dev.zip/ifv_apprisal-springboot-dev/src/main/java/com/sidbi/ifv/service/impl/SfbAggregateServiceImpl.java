package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.SfbAggregateDTO;
import com.sidbi.ifv.entity.S2IFVSfbAggregateEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.SfbAggregateRepository;
import com.sidbi.ifv.services.SfbAggregateService;

@Service
public class SfbAggregateServiceImpl implements SfbAggregateService {
	
	private static final Logger logger = LoggerFactory.getLogger(SfbAggregateServiceImpl.class);

	@Autowired
	private SfbAggregateRepository s2ifccSfbAggregateRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	String msg = "";

	@Override
	public List<SfbAggregateDTO> findAll() {
		logger.info("findAll() started in SfbAggregateServiceImpl for S2IFVSfbAggregateEntity");
		try {
			List<S2IFVSfbAggregateEntity> list = s2ifccSfbAggregateRepository.findAll();
			return list.stream().map(ifccsfbcommon -> modelMapper.map(ifccsfbcommon, SfbAggregateDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVSfbAggregateEntity entities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching all S2IFVSfbAggregateEntity entities."+msg+" ",
					e);
		}
	}

	@Override
	public SfbAggregateDTO findById(Long id) {
		logger.info("findById() started in SfbAggregateServiceImpl for S2IFVSfbAggregateEntity {} ",id);
		try {
			S2IFVSfbAggregateEntity s2ifccSfbAggregateEntity = s2ifccSfbAggregateRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVSfbAggregateEntity", id));
			return modelMapper.map(s2ifccSfbAggregateEntity, SfbAggregateDTO.class);
		} 
		catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFVSfbAggregateEntity entity. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching  S2IFVSfbAggregateEntity entity."+msg+" ", e);
		}
	}

	@Override
	public SfbAggregateDTO save(SfbAggregateDTO s2ifccSfbAggregateDTO) {
		logger.info("save() started in SfbAggregateServiceImpl for S2IFVSfbAggregateEntity {} ",s2ifccSfbAggregateDTO);
		try {
			S2IFVSfbAggregateEntity s2ifccSfbAggregateEntity = modelMapper.map(s2ifccSfbAggregateDTO,
					S2IFVSfbAggregateEntity.class);
			s2ifccSfbAggregateRepository.save(s2ifccSfbAggregateEntity);
			return modelMapper.map(s2ifccSfbAggregateEntity, SfbAggregateDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVSfbAggregateEntity entity. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVSfbAggregateEntity entity."+msg+" ", e);
		}
	}

	@Override
	public SfbAggregateDTO update(Long id, SfbAggregateDTO s2ifccSfbAggregateDTO) {
		logger.info("update() started in SfbAggregateServiceImpl for S2IFVSfbAggregateEntity {} {} ",id,s2ifccSfbAggregateDTO);
		try {
			S2IFVSfbAggregateEntity existings2ifccSfbAggregateEntity = s2ifccSfbAggregateRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVSfbAggregateEntity", id));
			BeanUtils.copyProperties(s2ifccSfbAggregateDTO, existings2ifccSfbAggregateEntity);
			s2ifccSfbAggregateRepository.save(existings2ifccSfbAggregateEntity);
			return modelMapper.map(existings2ifccSfbAggregateEntity, SfbAggregateDTO.class);
		} 
		catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVSfbAggregateEntity entity. {} ",msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVSfbAggregateEntity entity of id ." + id +" "+msg+" ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in SfbAggregateServiceImpl for S2IFVSfbAggregateEntity {} ",id);
		try {
			S2IFVSfbAggregateEntity existings2ifccSfbAggregateEntity = s2ifccSfbAggregateRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVSfbAggregateEntity", id));
			s2ifccSfbAggregateRepository.delete(existings2ifccSfbAggregateEntity);
		} 
		catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVSfbAggregateEntity. {} ",msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVSfbAggregateEntity of id ." + id+ " "+msg+" ", e);
		}
		
	}
}