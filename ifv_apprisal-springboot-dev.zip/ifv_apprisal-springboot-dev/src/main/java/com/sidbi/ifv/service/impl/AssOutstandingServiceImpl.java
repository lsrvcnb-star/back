package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AssOutstandingDTO;
import com.sidbi.ifv.entity.S2IFVAssOutstandingEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AssOutstandingRepository;
import com.sidbi.ifv.services.AssOutstandingService;

import jakarta.transaction.Transactional;

@Service
public class AssOutstandingServiceImpl implements AssOutstandingService {

	@Autowired
	private AssOutstandingRepository assOutstandingRepo;

	private static final Logger logger = LoggerFactory.getLogger(AssOutstandingServiceImpl.class);

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<AssOutstandingDTO> findAll() {
		logger.info("findAll() started in AssOutstandingServiceImpl for S2IFVAssOutstandingEntity");
		try {
			List<S2IFVAssOutstandingEntity> list = assOutstandingRepo.findAll();
			return list.stream().map(m -> modelMapper.map(m, AssOutstandingDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAssOutstandingEntities. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAssOutstandingEntities." + msg + " ", e);
		}
	}

	@Override
	public AssOutstandingDTO findById(Long id) {
		logger.info("findById() started in AssOutstandingServiceImpl for S2IFVAssOutstandingEntity {}", id);
		try {
			Optional<S2IFVAssOutstandingEntity> assOutstanding = assOutstandingRepo.findById(id);
			if (assOutstanding.isPresent()) {
				return modelMapper.map(assOutstanding.get(), AssOutstandingDTO.class);
			} else {
				logger.error("Error Occurred while fetching  S2IFVAssOutstandingEntity entity.");
				throw new EntityNotFoundException("s2IFVAssOutstandingEntity", id);
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAssOutstandingEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAssOutstandingEntity." + msg + " ", e);
		}

	}

	@Override
	public AssOutstandingDTO save(AssOutstandingDTO s2ifccAssOutstandingDTO) {

		logger.info("save() started in AssOutstandingServiceImpl for S2IFVAssOutstandingEntity {} ",
				s2ifccAssOutstandingDTO);
		try {
			S2IFVAssOutstandingEntity s2ifccApplicationEntity = modelMapper.map(s2ifccAssOutstandingDTO,
					S2IFVAssOutstandingEntity.class);
			assOutstandingRepo.save(s2ifccApplicationEntity);
			return modelMapper.map(s2ifccApplicationEntity, AssOutstandingDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVAssOutstandingEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  S2IFVAssOutstandingEntity." + msg + " ", e);
		}
	}

	@Override
	public AssOutstandingDTO update(Long id, AssOutstandingDTO s2ifccAssOutstandingDTO) {
		logger.info("update() started in AssOutstandingServiceImpl for S2IFVAssOutstandingEntity {} {} ", id,
				s2ifccAssOutstandingDTO);
		try {
			S2IFVAssOutstandingEntity applicationEntity = assOutstandingRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAssOutstandingEntity", id));
			BeanUtils.copyProperties(s2ifccAssOutstandingDTO, applicationEntity);
			assOutstandingRepo.save(applicationEntity);
			return modelMapper.map(applicationEntity, AssOutstandingDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVAssOutstandingEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVAssOutstandingEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in AssOutstandingServiceImpl for S2IFVAssOutstandingEntity {}", id);
		try {
			S2IFVAssOutstandingEntity applicationEntity = assOutstandingRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAssOutstandingEntity", id));
			assOutstandingRepo.delete(applicationEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVAssOutstandingEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVAssOutstandingEntity of id ." + id + " " + msg + " ", e);
		}

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<AssOutstandingDTO> saveAll(List<AssOutstandingDTO> listAssOutstandingDTO) {
		logger.info("saveAll() started in AssOutstandingServiceImpl for List of S2IFVAssOutstandingEntity");
		try {
			List<S2IFVAssOutstandingEntity> assOutstandingEntitiesToSave = listAssOutstandingDTO.stream()
					.map(assOutstandingDTO -> modelMapper.map(assOutstandingDTO, S2IFVAssOutstandingEntity.class))
					.collect(Collectors.toList());

			Long ifvId = listAssOutstandingDTO.stream().map(AssOutstandingDTO::getIfvId).findFirst().orElse(null);

			assOutstandingRepo.deleteByIfvId(ifvId);

			List<S2IFVAssOutstandingEntity> savedAssOutstandingEntities = assOutstandingRepo
					.saveAll(assOutstandingEntitiesToSave);

			return savedAssOutstandingEntities.stream()
					.map(assOutstandingEntity -> modelMapper.map(assOutstandingEntity, AssOutstandingDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVAssOutstandingEntities. {}", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all S2IFVAssOutstandingEntities.", e);
		}
	}

	@Override
	public List<AssOutstandingDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in AssOutstandingServiceImpl ");
		try {
			List<S2IFVAssOutstandingEntity> listAssOutstandingEntities = assOutstandingRepo.findByIfvId(ifvId);
			return listAssOutstandingEntities.stream()
					.map(assOutstandingEntity -> modelMapper.map(assOutstandingEntity, AssOutstandingDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAssOutstandingEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAssOutstandingEntities  based on IfvId." + ifvId + " " + msg
							+ " ",
					e);

		}
	}
}