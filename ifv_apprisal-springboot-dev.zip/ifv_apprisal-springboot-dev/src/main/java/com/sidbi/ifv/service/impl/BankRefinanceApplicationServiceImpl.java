package com.sidbi.ifv.service.impl;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.client.BankPortalClient;
import com.sidbi.ifv.dto.AcceptReturnComplianceRequestDto;
import com.sidbi.ifv.dto.BankPortalApiResponse;
import com.sidbi.ifv.dto.BankRefinanceAppRequest;
import com.sidbi.ifv.dto.BankRefinanceAppResponse;
import com.sidbi.ifv.dto.ComplianceResponseDto;
import com.sidbi.ifv.dto.ComplianceStatusSummaryRequest;
import com.sidbi.ifv.dto.ComplianceStatusSummaryResponse;
import com.sidbi.ifv.dto.IfvAuthorizedSignatoryDto;
import com.sidbi.ifv.dto.IfvProposalDto;
import com.sidbi.ifv.dto.IfvRefinanceApplicationRequest;
import com.sidbi.ifv.dto.ReturnBankForwardedDocumentRequest;
import com.sidbi.ifv.entity.IfvBankRefinanceApplication;
import com.sidbi.ifv.entity.IfvBankRefinanceProposal;
import com.sidbi.ifv.entity.IfvBankRefinanceSignatory;
import com.sidbi.ifv.enums.RefinanceApplicationStatus;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.IfvBankRefinanceApplicationRepository;
import com.sidbi.ifv.repo.IfvBankRefinanceProposalRepository;
import com.sidbi.ifv.repo.IfvBankRefinanceSignatoryRepository;
import com.sidbi.ifv.services.BankRefinanceApplicationService;
import com.sidbi.ifv.specs.IfvBankRefinanceApplicationSpecs;
import com.sidbi.ifv.util.ApiResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class BankRefinanceApplicationServiceImpl implements BankRefinanceApplicationService {

	private final IfvBankRefinanceApplicationRepository ifvBankRefinanceApplicationRepository;
	private final IfvBankRefinanceProposalRepository ifvBankRefinanceProposalRepository;
	private final IfvBankRefinanceSignatoryRepository ifvBankRefinanceSignatoryRepository;
	private final ModelMapper modelMapper;
	private final BankPortalClient bankPortalClient;

	@Transactional
	@Override
	public ApiResponse<String> receiveForwardedApplication(IfvRefinanceApplicationRequest request) {

		try {

			IfvBankRefinanceApplication application;

			Optional<IfvBankRefinanceApplication> existingOpt = ifvBankRefinanceApplicationRepository
					.findByAppRefId(request.getAppRefId());

			boolean resubmission = existingOpt.isPresent();

			if (resubmission) {

				application = existingOpt.get();

				application.setNameOfBank(request.getNameOfBank());
				application.setCifNumber(request.getCifNumber());
				application.setTypeOfBank(request.getTypeOfBank());

				application.setFundCode(request.getFundCode());
				application.setFundDescription(request.getFundDescription());

				application.setSchemeCode(request.getSchemeCode());
				application.setSchemeShortName(request.getSchemeShortName());
				application.setSchemeLongName(request.getSchemeLongName());
				application.setCustomSchemeName(request.getCustomSchemeName());

				application.setCurrencyType(request.getCurrencyType());
				application.setApplicationStatus(request.getApplicationStatus());

				application.setFrameworkParmTier(request.getFrameworkParmTier());
				application.setFrameworkParmCRAR(request.getFrameworkParmCRAR());
				application.setFrameworkParmCET1(request.getFrameworkParmCET1());
				application.setFrameworkParmCCB(request.getFrameworkParmCCB());

				application.setBankName(request.getBankName());
				application.setBankAccountNo(request.getBankAccountNo());
				application.setRtgsCode(request.getRtgsCode());
				application.setNeftCode(request.getNeftCode());
				application.setBankAddress(request.getBankAddress());

				application.setLegalEntityIdentifier(request.getLegalEntityIdentifier());

				application.setLeiValidity(request.getLeiValidity());

				application.setRefinanceAppFileName(request.getRefinanceAppFileName());

				application.setRefinanceAppFilePath(request.getRefinanceAppFilePath());

				application.setAuthSignFileName(request.getAuthorizedSignatoryFileName());

				application.setAuthSignFilePath(request.getAuthorizedSignatoryFilePath());

				application.setSubmittedBy(request.getSubmittedBy());

				application.setSubmittedDateTime(request.getSubmittedDateTime());

				application.setSubmitByEmail(request.getSubmitByEmail());

				application = ifvBankRefinanceApplicationRepository.save(application);

				// Remove old children

				ifvBankRefinanceProposalRepository.deleteByApplicationId(application.getId());

				ifvBankRefinanceSignatoryRepository.deleteByApplicationId(application.getId());

			} else {

				application = IfvBankRefinanceApplication.builder().appRefId(request.getAppRefId())

						.nameOfBank(request.getNameOfBank()).cifNumber(request.getCifNumber())
						.typeOfBank(request.getTypeOfBank())

						.fundCode(request.getFundCode()).fundDescription(request.getFundDescription())

						.schemeCode(request.getSchemeCode()).schemeShortName(request.getSchemeShortName())
						.schemeLongName(request.getSchemeLongName()).customSchemeName(request.getCustomSchemeName())

						.currencyType(request.getCurrencyType())

						.applicationStatus(request.getApplicationStatus())

						.frameworkParmTier(request.getFrameworkParmTier())

						.frameworkParmCRAR(request.getFrameworkParmCRAR())

						.frameworkParmCET1(request.getFrameworkParmCET1())

						.frameworkParmCCB(request.getFrameworkParmCCB())

						.bankName(request.getBankName()).bankAccountNo(request.getBankAccountNo())
						.rtgsCode(request.getRtgsCode()).neftCode(request.getNeftCode())
						.bankAddress(request.getBankAddress())

						.legalEntityIdentifier(request.getLegalEntityIdentifier())

						.leiValidity(request.getLeiValidity())

						.refinanceAppFileName(request.getRefinanceAppFileName())

						.refinanceAppFilePath(request.getRefinanceAppFilePath())

						.authSignFileName(request.getAuthorizedSignatoryFileName())

						.authSignFilePath(request.getAuthorizedSignatoryFilePath())

						.submittedBy(request.getSubmittedBy())

						.submittedDateTime(request.getSubmittedDateTime())

						.submitByEmail(request.getSubmitByEmail())

						.build();

				application = ifvBankRefinanceApplicationRepository.save(application);
			}

			Long applicationId = application.getId();

			// Save latest proposals

			List<IfvBankRefinanceProposal> proposals = request.getProposals().stream()
					.map(p -> IfvBankRefinanceProposal.builder().applicationId(applicationId)
							.refinanceAmount(p.getRefinanceAmount()).rateType(p.getRateType())
							.rateOfInterest(p.getRateOfInterest()).benchmark(p.getBenchmark()).spread(p.getSpread())
							.tenureInMonths(p.getTenureInMonths()).tenureInDays(p.getTenureInDays())
							.interestReset(p.getInterestReset()).principalRepayment(p.getPrincipalRepayment())
							.moratoriumMonths(p.getMoratoriumMonths()).maturityDate(p.getMaturityDate()).build())
					.toList();

			ifvBankRefinanceProposalRepository.saveAll(proposals);

			// Save latest signatories

			List<IfvBankRefinanceSignatory> signatories = request.getAuthorizedSignatories().stream()
					.map(s -> IfvBankRefinanceSignatory.builder().applicationId(applicationId)
							.nameOfAuthSignatory(s.getNameOfAuthSignatory()).designation(s.getDesignation())
							.email(s.getEmail()).mobileNumber(s.getMobileNumber()).build())
					.toList();

			ifvBankRefinanceSignatoryRepository.saveAll(signatories);

			return ApiResponse.<String>builder().success(true).data(request.getAppRefId())
					.message(
							resubmission ? "Application resubmitted successfully" : "Application received successfully")
					.build();

		} catch (Exception ex) {

			log.error("Failed to process refinance application. appRefId={}", request.getAppRefId(), ex);

			return ApiResponse.<String>builder().success(false).data(request.getAppRefId())
					.message("Failed to process refinance application")
					.errors(Collections.singletonList(ex.getMessage())).build();
		}
	}

	@Override
	public Page<BankRefinanceAppResponse> fetchBankApplications(BankRefinanceAppRequest request) {

		log.info("fetchBankApplications called");

		try {

			Pageable pageable = getPageable(request);

			Specification<IfvBankRefinanceApplication> spec = IfvBankRefinanceApplicationSpecs.filter(request).and(
					(root, query, cb) -> root.get("applicationStatus").in(RefinanceApplicationStatus.SUBMITTED.name(),
							RefinanceApplicationStatus.RETURNED.name()));

			Page<IfvBankRefinanceApplication> entityPage = ifvBankRefinanceApplicationRepository.findAll(spec,
					pageable);

			return entityPage.map(entity -> modelMapper.map(entity, BankRefinanceAppResponse.class));

		} catch (Exception e) {

			throw new DatabaseOperationException("Error fetching bank refinance applications", e);
		}
	}

	private Pageable getPageable(BankRefinanceAppRequest request) {

		String sortField = StringUtils.hasText(request.getSortField()) ? request.getSortField() : "submittedDateTime";

		Sort.Direction direction = "asc".equalsIgnoreCase(request.getSortDirection()) ? Sort.Direction.ASC
				: Sort.Direction.DESC;

		return PageRequest.of(request.getPage(), request.getSize(), Sort.by(direction, sortField));
	}

	@Override
	public IfvRefinanceApplicationRequest fetchBankApplicationByAppRefId(String appRefId) {

		IfvBankRefinanceApplication application = ifvBankRefinanceApplicationRepository.findByAppRefId(appRefId)
				.orElseThrow(() -> new EntityNotFoundException("Bank refinance application not found", appRefId));

		List<IfvProposalDto> proposals = ifvBankRefinanceProposalRepository.findAllByApplicationId(application.getId())
				.stream()
				.map(proposal -> IfvProposalDto.builder().refinanceAmount(proposal.getRefinanceAmount())
						.rateType(proposal.getRateType()).rateOfInterest(proposal.getRateOfInterest())
						.benchmark(proposal.getBenchmark()).spread(proposal.getSpread())
						.tenureInMonths(proposal.getTenureInMonths()).tenureInDays(proposal.getTenureInDays())
						.interestReset(proposal.getInterestReset()).principalRepayment(proposal.getPrincipalRepayment())
						.moratoriumMonths(proposal.getMoratoriumMonths()).maturityDate(proposal.getMaturityDate())
						.build())
				.toList();

		List<IfvAuthorizedSignatoryDto> signatories = ifvBankRefinanceSignatoryRepository
				.findAllByApplicationId(application.getId()).stream()
				.map(signatory -> IfvAuthorizedSignatoryDto.builder()
						.nameOfAuthSignatory(signatory.getNameOfAuthSignatory()).designation(signatory.getDesignation())
						.email(signatory.getEmail()).mobileNumber(signatory.getMobileNumber()).build())
				.toList();

		return IfvRefinanceApplicationRequest.builder()

				.appRefId(application.getAppRefId())

				.nameOfBank(application.getNameOfBank()).cifNumber(application.getCifNumber())
				.typeOfBank(application.getTypeOfBank())

				.fundCode(application.getFundCode()).fundDescription(application.getFundDescription())

				.schemeCode(application.getSchemeCode()).schemeShortName(application.getSchemeShortName())
				.schemeLongName(application.getSchemeLongName()).customSchemeName(application.getCustomSchemeName())

				.currencyType(application.getCurrencyType()).applicationStatus(application.getApplicationStatus())

				.frameworkParmTier(application.getFrameworkParmTier())
				.frameworkParmCRAR(application.getFrameworkParmCRAR())
				.frameworkParmCET1(application.getFrameworkParmCET1())
				.frameworkParmCCB(application.getFrameworkParmCCB())

				.bankName(application.getBankName()).bankAccountNo(application.getBankAccountNo())
				.rtgsCode(application.getRtgsCode()).neftCode(application.getNeftCode())

				.bankAddress(application.getBankAddress())

				.legalEntityIdentifier(application.getLegalEntityIdentifier()).leiValidity(application.getLeiValidity())

				.refinanceAppFileName(application.getRefinanceAppFileName())
				.refinanceAppFilePath(application.getRefinanceAppFilePath())

				.authorizedSignatoryFileName(application.getAuthSignFileName())
				.authorizedSignatoryFilePath(application.getAuthSignFilePath())

				.submittedBy(application.getSubmittedBy()).submittedDateTime(application.getSubmittedDateTime())
				.submitByEmail(application.getSubmitByEmail()).proposals(proposals).authorizedSignatories(signatories)

				.build();
	}

	@Override
	@Transactional
	public BankRefinanceAppResponse returnBankApplication(ReturnBankForwardedDocumentRequest request) {

		IfvBankRefinanceApplication application = ifvBankRefinanceApplicationRepository
				.findByAppRefId(request.getBenRefNo())
				.orElseThrow(() -> new EntityNotFoundException("Bank refinance application not found",
						request.getBenRefNo()));

		ResponseEntity<BankPortalApiResponse<String>> response = bankPortalClient.returnBankApplication(request);

		if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null
				|| !response.getBody().isSuccess()) {

			throw new DatabaseOperationException(response.getBody() != null ? response.getBody().getStatusMessage()
					: "Failed to return application in Bank Portal");
		}

		int rows = ifvBankRefinanceApplicationRepository.updateReturnedApplication(request.getBenRefNo(), "RETURNED",
				request.getReturnRemarks(), request.getReturnBy(), LocalDateTime.now());

		if (rows <= 0) {
			throw new DatabaseOperationException(
					"Failed to update application status for Ref No : " + request.getBenRefNo());
		}

		application.setApplicationStatus("RETURNED");
		application.setReturnRemarks(request.getReturnRemarks());
		application.setReturnBy(request.getReturnBy());
		application.setReturnDateTime(LocalDateTime.now());

		return modelMapper.map(application, BankRefinanceAppResponse.class);
	}

	@Override
	@Transactional
	public void validateBankApplication(String appRefNo) {
		int rows = ifvBankRefinanceApplicationRepository.updateApplicationStatus(appRefNo, "ACCEPTED");

		if (rows <= 0) {
			throw new DatabaseOperationException("Failed to update application status for Ref No : " + appRefNo);
		}
	}

	@Override
	public Page<BankRefinanceAppResponse> fetchActiveProposalBankApps(BankRefinanceAppRequest request) {

		log.info("fetchActiveProposalBankApps called");

		try {

			Pageable pageable = getPageable(request);

			Specification<IfvBankRefinanceApplication> spec = IfvBankRefinanceApplicationSpecs.filter(request)
					.and((root, query, cb) -> root.get("applicationStatus").in(
							RefinanceApplicationStatus.IN_PROGRESS.name(),
							RefinanceApplicationStatus.SANCTIONED.name()));

			Page<IfvBankRefinanceApplication> entityPage = ifvBankRefinanceApplicationRepository.findAll(spec,
					pageable);

			return entityPage.map(entity -> modelMapper.map(entity, BankRefinanceAppResponse.class));

		} catch (Exception e) {

			throw new DatabaseOperationException("Error fetching accepted bank refinance applications", e);
		}

	}

	@Override
	public Page<ComplianceStatusSummaryResponse> fetchComplianceSummaryForAllBanks(
			ComplianceStatusSummaryRequest request) {

		return bankPortalClient.fetchComplianceSummaryForAllBanks(request).getBody();
	}

	@Override
	public ComplianceResponseDto acceptOrReturnCompliance(AcceptReturnComplianceRequestDto request) {

		ResponseEntity<ComplianceResponseDto> response = bankPortalClient.acceptOrReturnCompliance(request);

		if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {

			throw new DatabaseOperationException("Failed to process compliance action in Bank Portal");
		}

		return response.getBody();
	}

}
