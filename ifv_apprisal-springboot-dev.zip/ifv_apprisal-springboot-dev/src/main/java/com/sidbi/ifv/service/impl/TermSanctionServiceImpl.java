package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.TermsSectionDTO;
import com.sidbi.ifv.entity.S2IFVTermsSectionEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.repo.TermsSectionRepository;
import com.sidbi.ifv.services.TermSanctionService;

@Service
public class TermSanctionServiceImpl implements TermSanctionService {

	private static final Logger logger = LoggerFactory.getLogger(TermSanctionServiceImpl.class);

	@Autowired
	private TermsSectionRepository sanctionRepository;

	@Autowired
	private ModelMapper modelMapper;
	
	String msg = "";

	@Override
	public TermsSectionDTO getTermSanctionById(Long id) {
		logger.info("getTermSanctionById() started in TermSanctionServiceImpl for S2IFVTermsSectionEntity");
		try {
			List<S2IFVTermsSectionEntity> ifccTermSanction = sanctionRepository.findByIfvId(id);
			return modelMapper.map(ifccTermSanction, TermsSectionDTO.class);
		}
		catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFCCTermSection entity. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching  S2IFVTermsSectionEntity entity."+msg+" ", e);
		}
	}

	@Override
	public List<TermsSectionDTO> getAllTermSanction() {
		logger.info("getAllTermSanction() started in TermSanctionServiceImpl for S2IFVTermsSectionEntity");
		try {
			List<S2IFVTermsSectionEntity> list = sanctionRepository.findAll();
			return list.stream().map(ifcc -> modelMapper.map(ifcc, TermsSectionDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVTermsSectionEntity entities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching all S2IFVTermsSectionEntity entities."+msg+" ",
					e);
		}
	}

}
