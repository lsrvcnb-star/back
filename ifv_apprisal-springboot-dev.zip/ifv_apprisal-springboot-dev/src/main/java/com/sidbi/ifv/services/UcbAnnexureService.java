package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.UcbAnnexureDTO;

public interface UcbAnnexureService extends CrudService<UcbAnnexureDTO, Long> {

	List<UcbAnnexureDTO> findAllByIfvIdAndAnnexureNo(Long ifvId, Integer annexureNo);

	List<UcbAnnexureDTO> findAllByIfvId(Long ifvId);

}
