package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoiStatusCountResponse {

	private long totalCount;

	private long issuedCount;

	private long stampedUploadedCount;
}