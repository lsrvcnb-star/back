package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class AlcoMinutesDataDTO {

	private Long id;

	private Long sancDtlCode;

	private Integer agendaNo;

	private String agendaId;

	private String appId;

	private String bankName;

	private String schemeName;

	private String fundName;

	private String fundCode;

	private BigDecimal amount;

	private BigDecimal tenor;

	private BigDecimal interestRate;

	private BigDecimal costOfFunds;

	private BigDecimal spreadMargin;

	private String principalRepayment;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

	private String status;

	private String schemeCode;
	
	private Long prId;
}
