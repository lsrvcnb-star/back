package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "s2_ifv_proposed_schema")
public class S2IFVProposedSchemaEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pr_id")
	private Long prId;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "pr_schemename")
	private String prSchemeName;

	@Column(name = "pr_schemecode")
	private String prSchemecode;

	@Column(name = "pr_fundname")
	private String prFundname;

	@Column(name = "pr_fundcode")
	private String prFundcode;

	@Column(name = "pr_amount")
	private BigDecimal prAmount;

	@Column(name = "pr_roi")
	private BigDecimal prRoi;

	@Column(name = "pr_tenure")
	private BigDecimal prTenure;

	@Column(name = "pr_principal_repayment")
	private String prPrincipalRepayment;

	@Column(name = "pr_maturity_date")
	private Date prMaturityDate;

	@Column(name = "interest_type")
	private String interestType;

	@Column(name = "scheme_short_name")
	private String schemeShortName;

	@Column(name = "bench_mark")
	private String benchMark;

	@Column(name = "spread")
	private String spread;

	@Column(name = "interest_reset")
	private String interestReset;

	@Column(name = "roi_note")
	private String roiNote;

	@Column(name = "incremental_cost_borrowing")
	private BigDecimal incrementalCostBorrowing;

	@Column(name = "dealwise_average")
	private BigDecimal dealwiseAverage;

	@Column(name = "tranche")
	private BigDecimal tranche;

	@Column(name = "incremental_cost_borrowing_type")
	private String incrementalCostBorrowingType;

	@Column(name = "pr_moratorium_period")
	private Integer prMoratoriumPeriod;

	@Column(name = "icb_fixed_floating")
	private String icbFixedFloating;

	@Column(name = "icb_benchmark")
	private String icbBenchMark;

	@Column(name = "icb_spread")
	private String icbSpread;

}
