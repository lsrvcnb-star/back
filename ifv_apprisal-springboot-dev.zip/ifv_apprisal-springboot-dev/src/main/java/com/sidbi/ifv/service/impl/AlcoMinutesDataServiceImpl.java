package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AlcoMinutesDataDTO;
import com.sidbi.ifv.entity.AlcoMinutesDataEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.repo.AlcoMinutesDataRepository;
import com.sidbi.ifv.services.AlcoMinutesDataService;

@Service
public class AlcoMinutesDataServiceImpl implements AlcoMinutesDataService {

	private static final Logger logger = LoggerFactory.getLogger(AlcoMinutesDataServiceImpl.class);

	@Autowired
	private AlcoMinutesDataRepository repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public AlcoMinutesDataDTO findById(Long id) {
		return null;
	}

	@Override
	public List<AlcoMinutesDataDTO> findAll() {
		return Collections.emptyList();
	}

	@Override
	public AlcoMinutesDataDTO save(AlcoMinutesDataDTO dto) {
		return null;
	}

	@Override
	public List<AlcoMinutesDataDTO> saveAll(List<AlcoMinutesDataDTO> dtos) {
		return Collections.emptyList();
	}

	@Override
	public AlcoMinutesDataDTO update(Long id, AlcoMinutesDataDTO dto) {
		return null;
	}

	@Override
	public void delete(Long id) {
		logger.info("Inside delete");
	}

	@Override
	public List<AlcoMinutesDataDTO> getAllAlcoMinutesDataByAgendaIdAndAppId(String agendaId, String appId) {
		logger.info("Started getAllAlcoMinutesDataByAgendaIdAndAppId() in AlcoMinutesDataServiceImpl {} {} ", agendaId,
				appId);
		try {
			List<AlcoMinutesDataEntity> minutesEntities = repository.findByAgendaIdAndAppId(agendaId, appId);
			if (!minutesEntities.isEmpty()) {
				return minutesEntities.stream().sorted(Comparator.comparing(AlcoMinutesDataEntity::getId))
						.map(e -> mapper.map(e, AlcoMinutesDataDTO.class)).collect(Collectors.toList());
			} else {
				return new ArrayList<>();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all AlcoMinutesDataEntity based on agendaId and appId. {} {} {}",
					agendaId, appId, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all AlcoMinutesDataEntity  based on agendaId and appId." + msg + " ",
					e);

		}
	}

}
