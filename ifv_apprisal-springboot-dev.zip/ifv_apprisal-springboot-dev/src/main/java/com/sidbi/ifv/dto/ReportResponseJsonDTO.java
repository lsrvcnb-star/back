package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class ReportResponseJsonDTO {

	private String fileName;

	private byte[] fileDataBytea;

	public ReportResponseJsonDTO(String fileName, byte[] fileDataBytea) {
		this.fileName = fileName;
		this.fileDataBytea = fileDataBytea;
	}

	public ReportResponseJsonDTO() {

	}
}
