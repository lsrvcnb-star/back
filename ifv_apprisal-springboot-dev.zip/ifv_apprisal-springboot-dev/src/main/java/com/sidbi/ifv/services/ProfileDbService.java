package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.ProfileBdDTO;

public interface ProfileDbService {
	
	List<ProfileBdDTO> findAll();

	ProfileBdDTO findById(Long id);

	ProfileBdDTO save(ProfileBdDTO profileDbDTO);

	ProfileBdDTO update(Long id, ProfileBdDTO profileDbDTO);
	
	void delete(Long id);

	List<ProfileBdDTO> saveAll(List<ProfileBdDTO> profileDbDTOs);

	List<ProfileBdDTO> findAllByIfvId(Long ifvId);

}