package com.sidbi.ifv.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import feign.Response;

@FeignClient(name = "fileServerClient", url = "${file.storage.url}")
@Profile({ "uat", "prod" })
public interface FileServerFeignClient {
	@GetMapping(value = "{filePath}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	Response fetchFile(@PathVariable("filePath") String filePath);
}