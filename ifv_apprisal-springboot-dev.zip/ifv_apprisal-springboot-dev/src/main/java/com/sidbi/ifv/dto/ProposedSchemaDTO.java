package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class ProposedSchemaDTO {

	private Long prId;

	private Long ifvId;

	private String prSchemeName;

	private String prSchemecode;

	private String prFundname;

	private String prFundcode;

	private BigDecimal prAmount;

	private BigDecimal prRoi;

	private BigDecimal prTenure;

	private String prPrincipalRepayment;

	private Date prMaturityDate;

	private String interestType;

	private String schemeShortName;

	private String benchMark;

	private String spread;

	private String interestReset;

	private String roiNote;

	private BigDecimal incrementalCostBorrowing;

	private BigDecimal dealwiseAverage;

	private BigDecimal tranche;

	private String incrementalCostBorrowingType;

	private Integer prMoratoriumPeriod;

	private String icbFixedFloating;

	private String icbBenchMark;

	private String icbSpread;

}
