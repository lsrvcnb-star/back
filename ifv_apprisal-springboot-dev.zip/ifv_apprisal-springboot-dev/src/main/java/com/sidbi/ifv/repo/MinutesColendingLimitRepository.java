package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sidbi.ifv.entity.MinutesColendingLimit;

@Repository
public interface MinutesColendingLimitRepository extends JpaRepository<MinutesColendingLimit, Long> {

	void deleteByMinuteSanctionId(Integer minuteSanctionId);

	List<MinutesColendingLimit> findByMinuteSanctionId(Integer minuteSanctionId);
}