package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IfvSignedLoiResponseDTO {

	private Long id;

	private Long loiDetailsId;

	private String ifvAppNo;

	private String bankRefNo;

	private String bankName;

	private String cifNumber;

	private String scheme;

	private BigDecimal sanctionAmount;

	private LocalDateTime sanctionedDateTime;

	private String loiNo;

	private String fileName;

	private String filePath;

	private String status;

	private String uploadedBy;

	private LocalDateTime uploadedDate;

	/* Counter Signed LoI Details */

	private String counterFileName;

	private String counterFilePath;

	private String counterUploadedBy;

	private LocalDateTime counterUploadedDate;

	private String counterRemarks;
}