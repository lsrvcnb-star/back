package com.sidbi.ifv.services;

import com.sidbi.ifv.dto.SanctionStatusDTO;

public interface SanctionStatusService extends CrudService<SanctionStatusDTO, Long> {

}
