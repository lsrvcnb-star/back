package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_ASS_OUTSTANDING")
public class S2IFVAssOutstandingEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "OS_ID")
	private Long osId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "OS_PERIODFY")
	private Integer osPeriodFy;

	@Column(name = "OS_BEGINNING_YEAR")
	private BigDecimal osYear;

	@Column(name = "OS_AMOUNTDISB")
	private BigDecimal osAmountDisb;

	@Column(name = "OS_REPAID")
	private BigDecimal osRepaid;

	@Column(name = "OS_END_PERIOD")
	private BigDecimal osEnd;

	@Column(name = "OS_TYPE")
	private String osType;
	
}

