package com.sidbi.ifv.enums;

public enum RefinanceApplicationStatus {

	SUBMITTED, RETURNED, IN_PROGRESS, SANCTIONED
}
