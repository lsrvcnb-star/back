package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.BenchmarkRepositoryDTO;
import com.sidbi.ifv.services.BenchmarkRepositoryService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/benchmark")
public class BenchmarkRepositoryController {

	private static final Logger logger = LoggerFactory.getLogger(BenchmarkRepositoryController.class);

	@Autowired
	private BenchmarkRepositoryService benchmarkRepositoryService;

	@GetMapping("/get/{id}")
	public ResponseEntity<BenchmarkRepositoryDTO> findById(@PathVariable Long id) {
		logger.info("findById() started BenchmarkRepositoryController {} ", id);
		BenchmarkRepositoryDTO benchmarkRepositoryDTO = benchmarkRepositoryService.findById(id);
		return ResponseEntity.ok(benchmarkRepositoryDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<BenchmarkRepositoryDTO>> findAll() {
		logger.info("findAll() started BenchmarkRepositoryController ");
		List<BenchmarkRepositoryDTO> list = benchmarkRepositoryService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<BenchmarkRepositoryDTO> save(@RequestBody BenchmarkRepositoryDTO benchmarkRepositoryDTO) {
		logger.info("save() started BenchmarkRepositoryController {} ", benchmarkRepositoryDTO);
		BenchmarkRepositoryDTO savedBenchmarkRepositoryDTO = benchmarkRepositoryService.save(benchmarkRepositoryDTO);
		return ResponseEntity.ok(savedBenchmarkRepositoryDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<BenchmarkRepositoryDTO>> saveAll(
			@RequestBody List<BenchmarkRepositoryDTO> listBenchmarkRepositoryDTO) {
		logger.info("saveAll() started in BenchmarkRepositoryController ");
		List<BenchmarkRepositoryDTO> savedBenchmarkRepositoryDTOs = benchmarkRepositoryService
				.saveAll(listBenchmarkRepositoryDTO);
		return ResponseEntity.ok(savedBenchmarkRepositoryDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<BenchmarkRepositoryDTO> update(@PathVariable Long id,
			@RequestBody BenchmarkRepositoryDTO benchmarkRepositoryDTO) {
		logger.info("update() started BenchmarkRepositoryController {} ", benchmarkRepositoryDTO);
		BenchmarkRepositoryDTO updatedBenchmarkRepositoryDTO = benchmarkRepositoryService.update(id,
				benchmarkRepositoryDTO);
		return ResponseEntity.ok(updatedBenchmarkRepositoryDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started BenchmarkRepositoryController {} ", id);
		benchmarkRepositoryService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<BenchmarkRepositoryDTO>> getAllS2IFVBenchmarkRepositoryEntityOnIfvId(
			@PathVariable Long ifvId) {
		logger.info("getAllS2IFVBenchmarkRepositoryEntityOnIfvId() started in BenchmarkRepositoryController ");
		List<BenchmarkRepositoryDTO> benchmarkRepositoryDTOs = benchmarkRepositoryService.findAllByIfvId(ifvId);
		return ResponseEntity.ok(benchmarkRepositoryDTOs);
	}
	
	@GetMapping("/getAllOnBankType/{bmBanktype}")
	public ResponseEntity<List<BenchmarkRepositoryDTO>> getAllS2IFVBenchmarkRepositoryEntityOnBankType(
			@PathVariable String bmBanktype) {
		logger.info("getAllS2IFVBenchmarkRepositoryEntityOnBankType() started in BenchmarkRepositoryController ");
		List<BenchmarkRepositoryDTO> benchmarkRepositoryDTOs = benchmarkRepositoryService.findAllByBmBanktype(bmBanktype);
		return ResponseEntity.ok(benchmarkRepositoryDTOs);
	}
	
	@GetMapping("/getAllOnAlCodeAndBankType/{alCode}/{bmBanktype}")
	public ResponseEntity<List<BenchmarkRepositoryDTO>> getAllS2IFVBenchmarkRepositoryEntityOnAlCodeAndBankType(
			@PathVariable Long alCode,@PathVariable String bmBanktype) {
		logger.info("getAllS2IFVBenchmarkRepositoryEntityOnAlCodeAndBankType() started in BenchmarkRepositoryController ");
		List<BenchmarkRepositoryDTO> benchmarkRepositoryDTOs = benchmarkRepositoryService.findAllByAlCodeAndBmBanktype(alCode,bmBanktype);
		return ResponseEntity.ok(benchmarkRepositoryDTOs);
	}

}