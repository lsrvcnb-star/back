package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.sidbi.ifv.dto.AssistanceAppliedForDto;
import com.sidbi.ifv.dto.ProposedSchemaDTO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_APPLICATION")
public class S2IFVApplicationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "IFV_NAME")
	private String ifvName;

	@Column(name = "IFV_ASSISTANCE")
	private String ifvAssistance;

	@Column(name = "IFV_EXPOSURE_LIMIT")
	private BigDecimal ifvExposureLimit;

	@Column(name = "IFV_EXISTING_OS")
	private BigDecimal ifvExistingOs;

	@Column(name = "IFV_PROP_EXPOSURE")
	private BigDecimal ifvPropExposure;

	@Column(name = "IFV_TOTAL_EXPOSURE")
	private BigDecimal ifvTotalExposure;

	@Column(name = "IFV_REPAYMENT_DATE")
	private Date ifvRepaymentDate;

	@Column(name = "IFV_EXTERNAL_RATING")
	private String ifvExternalRating;

	@Column(name = "IFV_EWS")
	private String ifvEws;

	@Column(name = "IFV_ADVERSE_NEWS")
	private String ifvAdverseNews;

	@Column(name = "IFV_MONETARY")
	private String ifvMonetary;

	@Column(name = "IPADDRESS")
	private String ipAddress;

	@Column(name = "MODIFIE_DATE")
	private Date modifiedDate;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "CIF_NUMBER")
	private String cifNumber;

	@Column(name = "SFB")
	private String sfb;

	@Column(name = "APP_NUMBER")
	private String appNumber;

	@Column(name = "other_remarks")
	private String otherRemarks;

	@Column(name = "ifv_remarks")
	private String ifvRemarks;

	@Column(name = "checker_id")
	private Integer checkerId;

	@Column(name = "ifv_exp_remarks")
	private String ifvExpRemarks;

	@Column(name = "ifv_undisbursed_sanction")
	private BigDecimal ifvUndisbursedSanction;

	@Column(name = "ifv_bank_type")
	private String ifvBankType;

	@Column(name = "ifv_background")
	private String ifvBackground;

	@Column(name = "internal_rating")
	private String internalRating;

	@Column(name = "ifv_short_name")
	private String ifvShortName;

	@Column(name = "bank_app_ref_nos", columnDefinition = "TEXT")
	private String bankAppRefNos;

	@Transient
	private Long ofrCode;

	@Transient
	private String ofrName;

	@Transient
	private String makerName;

	@Transient
	private String status;

	@Transient
	private List<ProposedSchemaDTO> proposedSchemaDTOs;

	@Transient
	private List<AssistanceAppliedForDto> assistanceAppliedFor;

}
