package com.sidbi.ifv.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.UcbBorrowersDetailEntity;

public interface UcbBorrowersDetailRepo extends JpaRepository<UcbBorrowersDetailEntity, Long> {

	UcbBorrowersDetailEntity findByIfvId(Long ifvId);

}
