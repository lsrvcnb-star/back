package com.sidbi.ifv.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IfvRimvAppDto {

	private Long id;
	private String rimvRefId;
	private String cifNumber;
	private String bankName;
	private Long currentUserId;
	private String currentUserName;
	private LocalDateTime createdDateTime;
	private String fwdStatus;
	private LocalDateTime forwardedDateTime;
	private String fwdComments;
	private Long fwdUserId;
	private String fwdBy;
	private String rimvComments;
	private String rimvFilePath;
	private LocalDateTime rimvUpdatedDateTime;
	private String singleScaleRating;
	private String combinedRating;
	private List<IfvRimvDocDto> ifvRimvDocs;
}
