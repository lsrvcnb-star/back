package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class AssOutstandingDTO {

	private Long osId;

	private Long ifvId;

	private Integer osPeriodFy;

	private BigDecimal osYear;

	private BigDecimal osAmountDisb;

	private BigDecimal osRepaid;

	private BigDecimal osEnd;

	private String osType;
}
