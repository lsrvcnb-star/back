package com.sidbi.ifv.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.repo.IfvApiUsersRepo;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	private IfvApiUsersRepo ifvUserRepo;

	public UserDetails loadUserByUsername(String username) {
		IfvApiUsersEntity user = ifvUserRepo.findByOfrUserId(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new User(user.getOfrUserId(), user.getOfrUserPassword(), new ArrayList<>());
	}
}