package com.sidbi.ifv.services;

import org.springframework.data.domain.Page;

import com.sidbi.ifv.dto.AcceptReturnComplianceRequestDto;
import com.sidbi.ifv.dto.BankRefinanceAppRequest;
import com.sidbi.ifv.dto.BankRefinanceAppResponse;
import com.sidbi.ifv.dto.ComplianceResponseDto;
import com.sidbi.ifv.dto.ComplianceStatusSummaryRequest;
import com.sidbi.ifv.dto.ComplianceStatusSummaryResponse;
import com.sidbi.ifv.dto.IfvRefinanceApplicationRequest;
import com.sidbi.ifv.dto.ReturnBankForwardedDocumentRequest;
import com.sidbi.ifv.util.ApiResponse;

public interface BankRefinanceApplicationService {

	ApiResponse<String> receiveForwardedApplication(IfvRefinanceApplicationRequest request);

	Page<BankRefinanceAppResponse> fetchBankApplications(BankRefinanceAppRequest request);

	IfvRefinanceApplicationRequest fetchBankApplicationByAppRefId(String appRefId);

	BankRefinanceAppResponse returnBankApplication(ReturnBankForwardedDocumentRequest request);

	void validateBankApplication(String benRefNo);

	Page<BankRefinanceAppResponse> fetchActiveProposalBankApps(BankRefinanceAppRequest request);

	Page<ComplianceStatusSummaryResponse> fetchComplianceSummaryForAllBanks(ComplianceStatusSummaryRequest request);

	ComplianceResponseDto acceptOrReturnCompliance(AcceptReturnComplianceRequestDto request);

}
