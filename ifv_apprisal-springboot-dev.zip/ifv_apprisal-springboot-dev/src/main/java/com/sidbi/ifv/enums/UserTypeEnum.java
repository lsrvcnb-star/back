package com.sidbi.ifv.enums;

import java.util.Arrays;
import java.util.Optional;

public enum UserTypeEnum {

	MAKER("9092", "Maker"), MAKER_CHECKER("9094", "Maker-Checker"), ADMIN_MAKER("9129", "Admin-Maker"),
	CHECKER("9093", "Checker"), ADMIN_CHECKER("9128", "Admin-Checker"), MAKER_CONVENER("10489", "Maker-Convener"),
	CHECKER_CONVENOR("11314", "Checker-Convener"), HIGHER_AUTHORITY("9095", "High Authority");

	private String userType;

	private String userTypeName;

	private UserTypeEnum(String userType, String userTypeName) {
		this.userType = userType;
		this.userTypeName = userTypeName;
	}

	public String getUserType() {
		return userType;
	}

	public String getUserTypeName() {
		return userTypeName;
	}

	public static Optional<UserTypeEnum> getUserTypeByCode(String value) {
		return Arrays.stream(UserTypeEnum.values())
				.filter(e -> e.userType.equals(value) || e.userTypeName.equals(value)).findFirst();
	}
}
