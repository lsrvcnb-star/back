package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.UcbBorrowersDetailDto;
import com.sidbi.ifv.entity.UcbBorrowersDetailEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.UcbBorrowersDetailRepo;
import com.sidbi.ifv.services.UcbBorrowersDetailService;

@Service
public class UcbBorrowersDetailServiceImpl implements UcbBorrowersDetailService {

	private static final Logger logger = LoggerFactory.getLogger(UcbBorrowersDetailServiceImpl.class);

	@Autowired
	private UcbBorrowersDetailRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public UcbBorrowersDetailDto findById(Long id) {
		logger.info("findById() started in UcbBorrowersDetailServiceImpl for UcbBorrowersDetailEntity {} ", id);
		UcbBorrowersDetailEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("UCBBorrowersDetailEntity", id));
		return mapper.map(entity, UcbBorrowersDetailDto.class);
	}

	@Override
	public List<UcbBorrowersDetailDto> findAll() {
		logger.info("findAll() started in UcbBorrowersDetailServiceImpl of UcbBorrowersDetailEntity");
		try {
			List<UcbBorrowersDetailEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, UcbBorrowersDetailDto.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all UcbTop10Borrowers .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all UcbTop10Borrowers ." + msg + " ",
					e);
		}
	}

	@Override
	public UcbBorrowersDetailDto save(UcbBorrowersDetailDto dto) {
		logger.info("save() started in UcbBorrowersDetailServiceImpl for UcbBorrowersDetailEntity {} ", dto);
		try {
			UcbBorrowersDetailEntity entity = mapper.map(dto, UcbBorrowersDetailEntity.class);
			repository.save(entity);
			return mapper.map(entity, UcbBorrowersDetailDto.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating UcbBorrowersDetailEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  UcbBorrowersDetailEntity." + msg + " ",
					e);
		}
	}

	@Override
	public List<UcbBorrowersDetailDto> saveAll(List<UcbBorrowersDetailDto> dtos) {
		logger.info("saveAll() started in UcbBorrowersDetailServiceImpl for List of UcbBorrowersDetailEntity");
		try {

			List<UcbBorrowersDetailEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, UcbBorrowersDetailEntity.class)).collect(Collectors.toList());
			List<UcbBorrowersDetailEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, UcbBorrowersDetailDto.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all UcbTop10Borrowers. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all UcbTop10Borrowers." + msg + " ", e);
		}
	}

	@Override
	public UcbBorrowersDetailDto update(Long id, UcbBorrowersDetailDto dto) {
		logger.info("update() started in UcbBorrowersDetailServiceImpl for UcbBorrowersDetailEntity {} {} ", id, dto);
		try {
			UcbBorrowersDetailEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbBorrowersDetailEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, UcbBorrowersDetailDto.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating UcbBorrowersDetailEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating UcbBorrowersDetailEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in UcbBorrowersDetailServiceImpl for UcbBorrowersDetailEntity {} ", id);
		try {
			UcbBorrowersDetailEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbBorrowersDetailEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting UcbBorrowersDetailEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting UcbBorrowersDetailEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public UcbBorrowersDetailDto findByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in UcbBorrowersDetailServiceImpl for UcbBorrowersDetailEntity {} ",
				ifvId);
		try {

			UcbBorrowersDetailEntity entity = repository.findByIfvId(ifvId);
			if (entity != null) {
				return mapper.map(entity, UcbBorrowersDetailDto.class);
			} else {
				return new UcbBorrowersDetailDto();
			}

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findByIfvId UcbBorrowersDetailEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findByIfvId UcbBorrowersDetailEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
