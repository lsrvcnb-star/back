package com.sidbi.ifv.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sidbi.ifv.dto.LoiStatusCountResponse;
import com.sidbi.ifv.entity.IfvLoiDocuments;

@Repository
public interface IfvLoiDocumentsRepository
		extends JpaRepository<IfvLoiDocuments, Long>, JpaSpecificationExecutor<IfvLoiDocuments> {

	Optional<IfvLoiDocuments> findByLoiDetailsId(Long loiDetailsId);

	List<IfvLoiDocuments> findByIfvAppNo(String ifvAppNo);

	List<IfvLoiDocuments> findByBankRefNo(String bankRefNo);

	@Query("""
			SELECT new com.sidbi.ifv.dto.LoiStatusCountResponse(
			    COUNT(l),
			    COALESCE(SUM(CASE WHEN l.status = 'ISSUED' THEN 1 ELSE 0 END), 0),
			    COALESCE(SUM(CASE WHEN l.status = 'COUNTER_SIGNED' THEN 1 ELSE 0 END), 0)
			)
			FROM IfvLoiDocuments l
			WHERE l.cifNumber = :cifNumber
			""")
	LoiStatusCountResponse fetchLoiStatusCounts(@Param("cifNumber") String cifNumber);

}
