package com.sidbi.ifv.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.SchemaDTO;
import com.sidbi.ifv.services.SchemaService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcsche")
public class SchemaController {

	private static final Logger logger = LoggerFactory.getLogger(SchemaController.class);

	@Autowired
	private SchemaService s2ifccSchemaService;

	@GetMapping("/get/{id}")
	public ResponseEntity<SchemaDTO> findById(@PathVariable Integer id) {
		logger.info("findById() started SchemaController {} ",id);
		SchemaDTO s2ifccSchemaDTO = s2ifccSchemaService.findById(id);
		return ResponseEntity.ok(s2ifccSchemaDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<SchemaDTO>> findAll() {
		logger.info("findAll() started SchemaController ");
		List<SchemaDTO> list = s2ifccSchemaService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<SchemaDTO> save(@RequestBody SchemaDTO s2ifccSchemaDTO) {
		logger.info("save() started SchemaController {} ",s2ifccSchemaDTO);
		SchemaDTO savedS2ifccSchemaDTO = s2ifccSchemaService.save(s2ifccSchemaDTO);
		return ResponseEntity.ok(savedS2ifccSchemaDTO);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<SchemaDTO> update(@PathVariable Integer id, @RequestBody SchemaDTO s2ifccSchemaDTO) {
		logger.info("update() started SchemaController {} ",s2ifccSchemaDTO);
		SchemaDTO updatedS2ifccSchemaDTO = s2ifccSchemaService.update(id, s2ifccSchemaDTO);
		return ResponseEntity.ok(updatedS2ifccSchemaDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Integer id) {
		logger.info("delete() started SchemaController {} ",id);
		s2ifccSchemaService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{id}")
	public ResponseEntity<List<SchemaDTO>> getAllOnIfvId(@PathVariable Long id) {
		logger.info("findAll() started SchemaController ");
		List<SchemaDTO> list = s2ifccSchemaService.findAll();
		list = list.stream().filter(e ->  e.getIfvId().equals(id)).collect(Collectors.toList());
		return ResponseEntity.ok(list);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<SchemaDTO>> saveAll(@RequestBody List<SchemaDTO> s2ifccSchemaDTO) {
		logger.info("save() started SchemaController {} ",s2ifccSchemaDTO);
		List<SchemaDTO> d = new ArrayList<>();
		s2ifccSchemaDTO.forEach(e -> {
			SchemaDTO savedS2ifccSchemaDTO = s2ifccSchemaService.save(e);
			d.add(savedS2ifccSchemaDTO);
		});
		return ResponseEntity.ok(d);
	}

}
