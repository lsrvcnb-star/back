package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IfvBeneficiaryDetailsDto {

	private Long id;
	private String bankName;
	private String cifNumber;
	private String loanAccountNo;
	private String benPreDisbFlag;
	private String benRefNo;
	private String fileName;
	private String filePath;
	private String fileType;
	private Long fileSize;
	private LocalDateTime uploadDateTime;
	private String uploadBy;
	private String userCode;
	private String remarks;
	private String disbDate;
	private LocalDateTime refDate;
	private String jobId;
	private String status;
	private String validated;
	private String returnRemarks;
	private String returnBy;
	private String uploadByEmail;
	private String ifvFileName;
	private String ifvFilePath;
	private LocalDateTime ifvSubmittedDate;
	private String ifvRemarks;
	private String ifvSubmitBy;
	private String scheme;
	private BigDecimal refinanceAmount;
}
