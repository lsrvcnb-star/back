package com.sidbi.ifv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "IFV_BANK_REFINANCE_SIGNATORY")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IfvBankRefinanceSignatory {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "APPLICATION_ID", nullable = false)
	private Long applicationId;

	@Column(name = "NAME_OF_AUTH_SIGNATORY", nullable = false, length = 255)
	private String nameOfAuthSignatory;

	@Column(name = "DESIGNATION", length = 100)
	private String designation;

	@Column(name = "EMAIL", length = 100)
	private String email;

	@Column(name = "MOBILE_NUMBER")
	private Long mobileNumber;
}
