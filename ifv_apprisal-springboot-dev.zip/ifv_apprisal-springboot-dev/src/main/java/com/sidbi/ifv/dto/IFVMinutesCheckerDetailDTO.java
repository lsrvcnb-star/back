package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IFVMinutesCheckerDetailDTO {

	private Long id;

	private Long minuteId;

	private Long minuteFileId;

	private Character status;

	private Long currentUserId;

	private String currentUserName;

	private String currentUserDesignation;

	private String currentUserAction;

	private LocalDateTime dateTimeOfReceipt;

	private LocalDateTime dateTimeOfAction;

	private String currentUserComment;

	private Long forwardedUserId;

	private String forwardedUserName;

	private String forwardedUserDesignation;

}
