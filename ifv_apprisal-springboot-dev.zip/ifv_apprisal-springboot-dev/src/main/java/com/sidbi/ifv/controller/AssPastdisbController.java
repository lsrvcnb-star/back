package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.AssPastdisbDTO;
import com.sidbi.ifv.services.AssPastdisbService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcpastdis")
public class AssPastdisbController {

	private static final Logger logger = LoggerFactory.getLogger(AssPastdisbController.class);

	@Autowired
	private AssPastdisbService s2IFFCCAssPastdisbService;

	@GetMapping("/get/{id}")
	public ResponseEntity<AssPastdisbDTO> findById(@PathVariable Long id) {
		logger.info("findById() started AssPastdisbController {} ",id);
		AssPastdisbDTO s2IFFCCAssPastdisbDTOFind = s2IFFCCAssPastdisbService.findById(id);
		return ResponseEntity.ok(s2IFFCCAssPastdisbDTOFind);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<AssPastdisbDTO>> findAll() {
		logger.info("findAll() started AssPastdisbController ");
		List<AssPastdisbDTO> list = s2IFFCCAssPastdisbService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<AssPastdisbDTO> save(@RequestBody AssPastdisbDTO s2IFFCCAssPastdisbDTO) {
		logger.info("save() started AssPastdisbController {} ",s2IFFCCAssPastdisbDTO);
		AssPastdisbDTO s2IFFCCAssPastdisbDTOSave = s2IFFCCAssPastdisbService.save(s2IFFCCAssPastdisbDTO);
		return ResponseEntity.ok(s2IFFCCAssPastdisbDTOSave);
	}
	
	@PostMapping("/saveAll")
	public ResponseEntity<List<AssPastdisbDTO>> saveAll(@RequestBody List<AssPastdisbDTO> listAssPastdisbDTO) {
		logger.info("saveAll() started in AssPastdisbController ");
		List<AssPastdisbDTO> savedAssPastdisbDTOs = s2IFFCCAssPastdisbService.saveAll(listAssPastdisbDTO);
		return ResponseEntity.ok(savedAssPastdisbDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<AssPastdisbDTO> update(@PathVariable Long id,
			@RequestBody AssPastdisbDTO applicationDTO) {
		logger.info("update() started AssPastdisbController {} ",applicationDTO);
		AssPastdisbDTO s2IFFCCAssPastdisbDTOUpdate = s2IFFCCAssPastdisbService.update(id, applicationDTO);
		return ResponseEntity.ok(s2IFFCCAssPastdisbDTOUpdate);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started AssPastdisbController {} ",id);
		s2IFFCCAssPastdisbService.delete(id);
		return ResponseEntity.noContent().build();
	}
	
	 @GetMapping("/getAllOnIfvId/{ifvId}")
	 public ResponseEntity<List<AssPastdisbDTO>> getAllS2IFVAssPastdisbEntityOnIfvId(@PathVariable Long ifvId) {
		 logger.info("getAllS2IFVAssPastdisbEntityOnIfvId() started in AssPastdisbController ");
		 List<AssPastdisbDTO> assPastdisbDTOs = s2IFFCCAssPastdisbService.findAllByIfvId(ifvId);
		 return ResponseEntity.ok(assPastdisbDTOs);
	 }

}
