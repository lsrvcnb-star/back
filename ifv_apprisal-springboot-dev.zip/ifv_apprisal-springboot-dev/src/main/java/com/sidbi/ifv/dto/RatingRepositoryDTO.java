package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class RatingRepositoryDTO {
	
	private Long rtCode;
	
	private Long ifvId;
	
	private String rtType;
	
	private String rtParticulars1;
	
	private String rtRemarks;
	
	private String rtOrder;
	
	private String rtFlg;
	
	private Date dateOfAction;

}
