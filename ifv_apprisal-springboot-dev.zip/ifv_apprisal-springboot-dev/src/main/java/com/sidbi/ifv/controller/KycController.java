package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.KycDTO;
import com.sidbi.ifv.dto.SfbCommondtDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.KycService;
import com.sidbi.ifv.services.SfbCommondtService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifckyc")
public class KycController {

	private static final Logger logger = LoggerFactory.getLogger(KycController.class);

	@Autowired
	private KycService kycService;

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private SfbCommondtService sfbCommondtService;

	@GetMapping("/getAll")
	public ResponseEntity<List<KycDTO>> findAll() {
		logger.info("findAll() started KycController");
		List<KycDTO> list = kycService.findAll();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<KycDTO> findById(@PathVariable Long id) {
		logger.info("findById() started KycController {} ", id);
		KycDTO kycDTO = kycService.findById(id);
		return ResponseEntity.ok(kycDTO);
	}

	@PostMapping("/save")
	public ResponseEntity<KycDTO> save(@RequestBody KycDTO kycDto) {
		logger.info("save() started KycController {} ", kycDto);
		KycDTO kycDTO = kycService.save(kycDto);
		return ResponseEntity.ok(kycDTO);

	}

	@PostMapping("/saveAll")
	public ResponseEntity<CommonDTO> saveAll(@RequestBody CommonDTO commonDTO) {
		logger.info("saveAll() started in KycController ");
		CommonDTO savedCommonDTO = kycService.saveCommonDTO(commonDTO);
		return ResponseEntity.ok(savedCommonDTO);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<KycDTO> update(@PathVariable Long id, @RequestBody KycDTO kycDto) {
		logger.info("update() started KycController {} ", kycDto);
		KycDTO kycDTO = kycService.update(id, kycDto);
		return ResponseEntity.ok(kycDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started KycController {} ", id);
		kycService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<CommonDTO> getAllKycEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllKycEntityOnIfvId() started in KycController ");
		CommonDTO commonDTO = kycService.findCommonDTOByIfvId(ifvId);

		if (CollectionUtils.isEmpty(commonDTO.getListKycDto())) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {

				List<KycDTO> kycDTOs = kycService.findAllByIfvId(applicationDTO.getIfvId());
				if (!CollectionUtils.isEmpty(kycDTOs)) {
					kycDTOs.forEach(e -> {
						e.setIfvId(ifvId);
						e.setKycId(null);
					});

					commonDTO.setListKycDto(kycDTOs);
				}
			}
		}

		if (commonDTO.getSfbCommondtDTO() == null) {

			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {

				List<SfbCommondtDTO> commondtDTOs = sfbCommondtService.findAllByIfvId(applicationDTO.getIfvId());

				if (!CollectionUtils.isEmpty(commondtDTOs)) {
					commondtDTOs.forEach(e -> {
						e.setIfvId(ifvId);
						e.setSfbId(null);
					});

					commonDTO.setSfbCommondtDTO(commondtDTOs.get(0));
				}

			}

		}

		return ResponseEntity.ok(commonDTO);
	}

	@GetMapping("/getAllOnIfvIdOrCifNo/{ifvId}/{cifNumber}")
	public ResponseEntity<CommonDTO> getAllOnIfvIdAndCifNo(@PathVariable Long ifvId, @PathVariable String cifNumber) {
		logger.info("getAllOnIfvIdOrCifNo() started in KycController ");
		CommonDTO commonDTO = kycService.findCommonDTOByIfvIdOrCifNumber(ifvId, cifNumber);
		return ResponseEntity.ok(commonDTO);
	}
}
