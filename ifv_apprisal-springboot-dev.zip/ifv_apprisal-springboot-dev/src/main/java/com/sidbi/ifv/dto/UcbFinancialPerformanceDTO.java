package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class UcbFinancialPerformanceDTO {

	private Long id;

	private Long ifvId;

	private String particulars;

	private BigDecimal amount1;

	private BigDecimal amount2;

	private Date date1;

	private Date date2;

	private String note;

}
