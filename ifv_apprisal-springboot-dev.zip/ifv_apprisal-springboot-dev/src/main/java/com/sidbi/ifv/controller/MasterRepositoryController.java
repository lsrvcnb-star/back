package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.MasterRepositoryDTO;
import com.sidbi.ifv.services.MasterRepositoryService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/masterrepo")
public class MasterRepositoryController {

	private static final Logger logger = LoggerFactory.getLogger(MasterRepositoryController.class);

	@Autowired
	private MasterRepositoryService masterRepositoryService;

	@GetMapping("/get/{id}")
	public ResponseEntity<MasterRepositoryDTO> findById(@PathVariable Long id) {
		logger.info("findById() started MasterRepositoryController {} ", id);
		MasterRepositoryDTO masterRepositoryDTO = masterRepositoryService.findById(id);
		return ResponseEntity.ok(masterRepositoryDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<MasterRepositoryDTO>> findAll() {
		logger.info("findAll() started MasterRepositoryController ");
		List<MasterRepositoryDTO> list = masterRepositoryService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<MasterRepositoryDTO> save(@RequestBody MasterRepositoryDTO masterRepositoryDTO) {
		logger.info("save() started MasterRepositoryController {} ", masterRepositoryDTO);
		MasterRepositoryDTO savedMasterRepositoryDTO = masterRepositoryService.save(masterRepositoryDTO);
		return ResponseEntity.ok(savedMasterRepositoryDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<MasterRepositoryDTO>> saveAll(
			@RequestBody List<MasterRepositoryDTO> listMasterRepositoryDTO) {
		logger.info("saveAll() started in MasterRepositoryController ");
		List<MasterRepositoryDTO> savedMasterRepositoryDTOs = masterRepositoryService.saveAll(listMasterRepositoryDTO);
		return ResponseEntity.ok(savedMasterRepositoryDTOs);
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<MasterRepositoryDTO> update(@PathVariable Long id,
			@RequestBody MasterRepositoryDTO masterRepositoryDTO) {
		logger.info("update() started MasterRepositoryController {} ", masterRepositoryDTO);
		MasterRepositoryDTO updatedMasterRepositoryDTO = masterRepositoryService.update(id, masterRepositoryDTO);
		return ResponseEntity.ok(updatedMasterRepositoryDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started MasterRepositoryController {} ", id);
		masterRepositoryService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<MasterRepositoryDTO>> getAllS2IFVMasterRepositoryEntityOnIfvId(
			@PathVariable Long ifvId) {
		logger.info("getAllS2IFVMasterRepositoryEntityOnIfvId() started in MasterRepositoryController ");
		List<MasterRepositoryDTO> masterRepositoryDTOs = masterRepositoryService.findAllByIfvId(ifvId);
		return ResponseEntity.ok(masterRepositoryDTOs);
	}

	@GetMapping("/getAllOnMstParticulars/{mstParticulars}")
	public ResponseEntity<List<MasterRepositoryDTO>> getAllOnMstParticulars(@PathVariable String mstParticulars) {
		logger.info("getAllOnMstParticulars() started in MasterRepositoryController ");
		List<MasterRepositoryDTO> masterRepositoryDTOs = masterRepositoryService
				.findAllByMstParticulars(mstParticulars);
		return ResponseEntity.ok(masterRepositoryDTOs);
	}

}