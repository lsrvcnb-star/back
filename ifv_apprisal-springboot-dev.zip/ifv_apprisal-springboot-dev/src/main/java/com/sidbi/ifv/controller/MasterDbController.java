package com.sidbi.ifv.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.AggregateExposureRequestDto;
import com.sidbi.ifv.dto.AggregateExposureResponseDto;
import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.dto.HrmsEmpNameDesignationDTO;
import com.sidbi.ifv.dto.IfvDigilendingDetailsDto;
import com.sidbi.ifv.dto.IfvSanctionDetailsDTO;
import com.sidbi.ifv.dto.StatusResponseDto;
import com.sidbi.ifv.dto.TriggerResponseDto;
import com.sidbi.ifv.services.MasterDbService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/masters")
public class MasterDbController {

	private static final Logger logger = LoggerFactory.getLogger(MasterDbController.class);

	@Autowired
	private MasterDbService service;

	@GetMapping("/getAllBcmCifEntity")
	public ResponseEntity<Object> getAllBcmCifData() {
		logger.info("Started getAllBcmCifData() in MasterDbController");
		List<Object> list = service.getAllBcmCifData();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getBcmSchemes")
	public ResponseEntity<Object> getBcmSchemesData() {
		logger.info("Started getBcmSchemesData() in MasterDbController");
		List<Object> list = service.getBcmSchemes();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getBcmLocaltionCodes")
	public ResponseEntity<Object> getBcmLocationCodes() {
		logger.info("Started getBcmLocationCodes() in MasterDbController");
		List<Object> list = service.getBcmLocationCodes();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getCustExpo/{cifNumber}")
	public ResponseEntity<Object> getCustExpo(@PathVariable String cifNumber) {
		logger.info("Started getCustExpo() in MasterDbController");
		List<Object> list = service.getCustExpo(cifNumber);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getCustOs/{cifNumber}")
	public ResponseEntity<Object> getCustOs(@PathVariable String cifNumber) {
		logger.info("Started getCustOs() in MasterDbController");
		List<Object> list = service.getCustOs(cifNumber);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getPastDisbursements/{cifNumber}")
	public ResponseEntity<Object> getPastDisbursements(@PathVariable String cifNumber) {
		logger.info("Started getPastDisbursements() in MasterDbController");
		List<Object> list = service.getPastDisbursements(cifNumber);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getOSDetails/{cifNumber}")
	public ResponseEntity<Object> outStandingDetails(@PathVariable String cifNumber) {
		logger.info("Started outStandingDetails() in MasterDbController");
		List<Object> list = service.outStandingDetails(cifNumber);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getFundDetails/{fundAvailable}")
	public ResponseEntity<Object> bcmFundCodeDetails(@PathVariable String fundAvailable) {
		logger.info("Started bcmFundCodeDetails() in MasterDbController");
		List<Object> list = service.bcmFundCodeDetails(fundAvailable);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getFutureRepayDetails/{cifNumber}")
	public ResponseEntity<Object> futureRepayOfExistingOutStandingDTO(@PathVariable String cifNumber) {
		logger.info("Started futureRepayOfExistingOutStandingDTO() in MasterDbController");
		List<Object> list = service.futureRepayOfExistingOutStandingDTO(cifNumber);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getExpouserDetails/{cifNumber}")
	public ResponseEntity<BigDecimal> exposureLimitForBarwBank(@PathVariable String cifNumber) {
		logger.info("Started exposureLimitForBarwBank() in MasterDbController");
		BigDecimal list = service.exposureLimitForBarwBank(cifNumber);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getHrmsEmpDetails/{cmtCode}")
	public ResponseEntity<List<CmtMemberMasterDTO>> getHrmsEmpDetails(@PathVariable Integer cmtCode) {
		logger.info("Started getHrmsEmpDetails() in MasterDbController");
		List<CmtMemberMasterDTO> list = service.getHrmsEmpDetails(cmtCode);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getSchemesOnFundCd/{fundCd}")
	public ResponseEntity<Object> getSchemesOnFundCd(@PathVariable String fundCd) {
		logger.info("Started getSchemesOnFundCd() in MasterDbController");
		List<Object> list = service.getSchemesOnFundCd(fundCd);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getFundCodeAndDesc")
	public ResponseEntity<Object> getFundCodeAndDesc() {
		logger.info("Started getFundCodeAndDesc() in MasterDbController");
		List<Object> list = service.getFundCodeAndDesc();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getEmployeeNames/{empIds}")
	public ResponseEntity<List<HrmsEmpNameDesignationDTO>> getEmployeeNames(@PathVariable List<String> empIds) {
		logger.info("Started getHrmsEmpDetails() in MasterDbController");
		List<HrmsEmpNameDesignationDTO> list = service.getEmployeeNames(empIds);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getAllSanctionDetails")
	public ResponseEntity<Object> getAllSanctionDetails() {
		logger.info("Started getAllSanctionDetails() in MasterDbController");
		List<Object> list = service.getAllSanctionDetails();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getAllEmpNames")
	public ResponseEntity<List<String>> getAllEmpNames() {
		logger.info("Started getAllEmpNames() in MasterDbController");
		List<String> list = service.getAllEmpNames();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getEmpDetails/{empName}")
	public ResponseEntity<HrmsEmpNameDesignationDTO> getEmpDetailsOnEmpName(@PathVariable String empName) {
		logger.info("Started getEmpDetailsOnEmpName() in MasterDbController");
		HrmsEmpNameDesignationDTO dto = service.getEmpDetailsOnEmpName(empName);
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/getEmpCodeAndDesc")
	public ResponseEntity<Map<String, String>> getEmpCodeAndDesc() {
		logger.info("Started getEmpCodeAndDesc() in MasterDbController");
		Map<String, String> map = service.getEmpCodeAndDesc();
		return ResponseEntity.ok(map);
	}

	@GetMapping("/getBankType/{custCd}")
	public ResponseEntity<String> getBankType(@PathVariable String custCd) {
		logger.info("Started getBankType() in MasterDbController");
		String bankType = service.getBankType(custCd);
		return ResponseEntity.ok(bankType);
	}

	@GetMapping("/findBankDetailsByCifNumber/{custCd}")
	public ResponseEntity<Object> findBankDetailsByCifNumber(@PathVariable String custCd) {
		logger.info("Started findBankDetailsByCifNumber() in MasterDbController");
		Object bank = service.findBankDetailsByCifNumber(custCd);
		return ResponseEntity.ok(bank);
	}

	@GetMapping("/getBenchmarkDetails")
	public ResponseEntity<List<String>> getBenchmarkDetails() {
		logger.info("Started getBenchmarkDetails() in MasterDbController");
		List<String> list = service.getBenchmarkDetails();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getAddressByCifNumber/{custCd}")
	public ResponseEntity<String> getAddressByCifNumber(@PathVariable String custCd) {
		logger.info("Started getAddressByCifNumber() in MasterDbController");
		String bank = service.getAddressByCifNumber(custCd);
		return ResponseEntity.ok(bank);
	}

	@GetMapping("/getDistrictsByState/{stateCode}")
	public ResponseEntity<Object> getDistrictsByState(@PathVariable String stateCode) {
		logger.info("Started getDistrictsByState() in MasterDbController");
		List<Object> list = service.getDistrictsByState(stateCode);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getSanctionDetailsOnPage")
	public ResponseEntity<Page<IfvSanctionDetailsDTO>> getSanctionDetailsOnPage(
			@RequestParam(defaultValue = "0") int start, @RequestParam(defaultValue = "10") int size,
			@RequestParam(required = false) String filters, @RequestParam(required = false) String sorting,
			@RequestParam(required = false) String globalFilter, @RequestParam(required = false) String status) {

		logger.info("getSanctionDetailsOnPage() started MasterDbController {} ", status);

		return ResponseEntity.ok(service.getSanctionDetailsOnPage(start, size, filters, sorting, globalFilter, status));
	}

	@GetMapping("/getSanctionedProposalsCount")
	public ResponseEntity<Long> getSanctionedProposalsCount() {
		logger.info("getSanctionedProposalsCount() started MasterDbController ");
		return ResponseEntity.ok(service.getSanctionedProposalsCount());
	}

	@GetMapping("/getAllTrancheOnFundCode/{fundCode}")
	public ResponseEntity<List<BigDecimal>> getAllTrancheOnFundCode(@PathVariable String fundCode) {
		logger.info("getAllTrancheOnFundCode() started MasterDbController {} ", fundCode);
		return ResponseEntity.ok(service.getAllTrancheOnFundCode(fundCode));
	}

	@GetMapping("/fetchBenificiaryDetails")
	public ResponseEntity<Page<IfvDigilendingDetailsDto>> fetchBenificiaryDetails(
			@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) {

		return ResponseEntity.ok(service.fetchBenificiaryDetails(page, size));
	}

	@PostMapping("/getAggregateExposureStatus")
	public ResponseEntity<StatusResponseDto> checkStatus(@RequestBody AggregateExposureRequestDto dto) {
		logger.info("checkStatus() called for date: {} : {}", dto.getAsOnDate(), dto.getGroupName());
		return ResponseEntity.ok(service.checkStatus(dto));
	}

	@PostMapping("/triggerAggregateExposure")
	public ResponseEntity<TriggerResponseDto> triggerProcedure(@RequestBody AggregateExposureRequestDto dto) {
		logger.info("triggerProcedure() called for date: {}", dto.getAsOnDate());
		return ResponseEntity.ok(service.triggerProcedure(dto));
	}

	@PostMapping("/getAggregateExposureData")
	public ResponseEntity<AggregateExposureResponseDto> getAggregateExposureData(
			@RequestBody AggregateExposureRequestDto dto) {
		logger.info("getAggregateExposureData() called for cifNumber: {}", dto.getCifNumber());
		return ResponseEntity.ok(service.getAggregateExposureData(dto));
	}

	@PostMapping("/getAggregateExposureOnGroup")
	public ResponseEntity<BigDecimal> getAggregateExposureOnGroup(@RequestBody AggregateExposureRequestDto dto) {
		logger.info("getAggregateExposureOnGroup() called for cifNumber: {}", dto.getCifNumber());
		return ResponseEntity.ok(service.getAggregateExposureOnGroup(dto));
	}

	@GetMapping("/getGroupNameByCif/{cifNumber}")
	public ResponseEntity<String> checkStatus(@PathVariable String cifNumber) {
		logger.info("getGroupNameByCif() called for cif: {}", cifNumber);
		return ResponseEntity.ok(service.getGroupNameByCif(cifNumber));
	}
}