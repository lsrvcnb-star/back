package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.IfvSanctionDetailsEntity;

public interface SanctionDtRepository extends JpaRepository<IfvSanctionDetailsEntity, Long> {

	List<IfvSanctionDetailsEntity> findAllByBnlSrNoIn(List<Long> minuteIds);

}
