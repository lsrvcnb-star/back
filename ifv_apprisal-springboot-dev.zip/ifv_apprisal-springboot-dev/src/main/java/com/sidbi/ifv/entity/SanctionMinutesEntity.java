package com.sidbi.ifv.entity;

import java.time.LocalDateTime;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_MINUTES_SANCTION")
public class SanctionMinutesEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sanct_detail_code")
	private Long sanctDetailCode;

	@Column(name = "agenda_id")
	private String agendaId;

	@Column(name = "commitee_code")
	private Integer commiteeCode;

	@Column(name = "meeting_date")
	private Date meetingDate;

	@Column(name = "sanct_stage")
	private String sanctStage;

	@Column(name = "meeting_place")
	private String meetingPlace;

	@Column(name = "agenda_created_by")
	private String agendaCreatedBy;

	@Column(name = "reporting_officer")
	private String reportingOfficer;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "convenor_code")
	private String convenorCode;

	@Column(name = "al_convenor_code")
	private String alConvenorCode;

	@Column(name = "member_code")
	private String memberCode;

	@Column(name = "meeting_no")
	private Integer meetingNo;

	@Column(name = "chairman_code")
	private String chairmanCode;

	@Column(name = "grant_leaves")
	private String grantLeaves;

	@Column(name = "note1")
	private String note1;

	@Column(name = "note2")
	private String note2;

	@Column(name = "flash_note")
	private String flashNote;

	@Column(name = "created_modified_user")
	private String createdModifiedUser;

	@Column(name = "forwarded_stage1_user")
	private String forwardedStage1User;

	@Column(name = "forwarded_stage2_user")
	private String forwardedStage2User;

	@Column(name = "forwarded_stage1_date_time")
	private LocalDateTime forwardedStage1DateTime;

	@Column(name = "forwarded_stage2_date_time")
	private LocalDateTime forwardedStage2DateTime;

	@Column(name = "current_user_emp_id")
	private String currentUserEmpId;

	@Column(name = "benchmark_note")
	private String benchmarkNote;

	@Column(name = "current_checker_id")
	private Long currentCheckerId;

	@Transient
	private String remarks;

}