package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HrmsEmpNameDesignationDTO {
	
	private String empCode;
	private String branchCd;
	private String empName;
	private Integer desigCode;
	private String desigDesc;
	private String reportingMgr;

}
