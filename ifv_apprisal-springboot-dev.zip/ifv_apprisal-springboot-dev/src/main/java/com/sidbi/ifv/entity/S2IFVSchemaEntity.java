package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_SCHEMA")
public class S2IFVSchemaEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SC_ID")
	private Integer scId;
	
	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "SC_SCHEMENAME")
	private String scSchemeName;
	
	@Column(name = "SC_AMOUNT")
	private BigDecimal scAmount;
	
	@Column(name = "SC_ROI")
	private BigDecimal scRoi;
	
	@Column(name = "SC_TENURE")
	private String scTenure;
	
	@Column(name = "PRINCIPAL_REPAYMENT")
	private String principalRepayment;
	
	@Column(name = "INTEREST_PAYMENT")
	private String interestPayment;
	
	@Column(name = "FUND_CODE")
	private String fundCode;
	
	
}
