package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.UcbFinancialPerformanceEntity;

public interface UcbFinancialPerformanceRepo extends JpaRepository<UcbFinancialPerformanceEntity, Long> {

	List<UcbFinancialPerformanceEntity> findByIfvId(Long ifvId);

}
