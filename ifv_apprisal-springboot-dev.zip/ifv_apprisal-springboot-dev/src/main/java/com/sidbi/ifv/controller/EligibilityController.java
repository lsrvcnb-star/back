package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.EligibilityDTO;
import com.sidbi.ifv.services.EligibilityService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcelig")
public class EligibilityController {

	private static final Logger logger = LoggerFactory.getLogger(EligibilityController.class);

	@Autowired
	private EligibilityService s2ifccEligibilityService;

	@GetMapping("/get/{id}")
	public ResponseEntity<EligibilityDTO> findById(@PathVariable Long id) {
		logger.info("findById() started EligibilityController {} ", id);
		EligibilityDTO s2ifccEligibilityDTO = s2ifccEligibilityService.findById(id);
		return ResponseEntity.ok(s2ifccEligibilityDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<EligibilityDTO>> findAll() {
		logger.info("findAll() started EligibilityController ");
		List<EligibilityDTO> list = s2ifccEligibilityService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<EligibilityDTO> save(@RequestBody EligibilityDTO s2ifccEligibilityDTO) {
		logger.info("save() started EligibilityController {} ", s2ifccEligibilityDTO);
		EligibilityDTO savedS2ifccEligibilityDTO = s2ifccEligibilityService.save(s2ifccEligibilityDTO);
		return ResponseEntity.ok(savedS2ifccEligibilityDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<EligibilityDTO>> saveAll(@RequestBody List<EligibilityDTO> listEligibilityDTO) {
		logger.info("saveAll() started in EligibilityController ");
		List<EligibilityDTO> savedEligibilityDTOs = s2ifccEligibilityService.saveAll(listEligibilityDTO);
		return ResponseEntity.ok(savedEligibilityDTOs);
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<EligibilityDTO> update(@PathVariable Long id,
			@RequestBody EligibilityDTO s2ifccEligibilityDTO) {
		logger.info("update() started EligibilityController {} ", s2ifccEligibilityDTO);
		EligibilityDTO updatedS2ifccEligibilityDTO = s2ifccEligibilityService.update(id, s2ifccEligibilityDTO);
		return ResponseEntity.ok(updatedS2ifccEligibilityDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started EligibilityController {} ", id);
		s2ifccEligibilityService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getByIfvId/{ifvId}")
	public ResponseEntity<EligibilityDTO> getByIfvId(@PathVariable Long ifvId) {
		logger.info("getAllS2IFVEligibilityEntityOnIfvId() started in EligibilityController {} ", ifvId);
		EligibilityDTO eligibilityDTOs = s2ifccEligibilityService.findByIfvId(ifvId);
		return ResponseEntity.ok(eligibilityDTOs);
	}

}
