package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class UcbTop10BorrowersDTO {
	private Long id;

	private Long ifvId;

	private String customerName;

	private BigDecimal totalOs;

	private String natureOfActivity;

	private String borrowerNote;
}
