package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class InstitutionalDTO {

	private Long inId;

	private Long ifvId;

	private String inParticular;

	private BigDecimal inAmount;
	
	private Date inDate;

}
