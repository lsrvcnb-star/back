package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.StatusOfListingEntity;

public interface StatusOfListingRepository extends JpaRepository<StatusOfListingEntity, Long> {

	List<StatusOfListingEntity> findByIfvId(Long ifvId);
}