package com.sidbi.ifv.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.sidbi.ifv.dto.AggregateExposureRequestDto;
import com.sidbi.ifv.dto.AggregateExposureResponseDto;
import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.dto.CustomerDto;
import com.sidbi.ifv.dto.HrmsEmpNameDesignationDTO;
import com.sidbi.ifv.dto.IfvDigilendingDetailsDto;
import com.sidbi.ifv.dto.IfvIntBeneficiaryDetailRequest;
import com.sidbi.ifv.dto.IfvRefMasterDto;
import com.sidbi.ifv.dto.IfvSanctionDetailsDTO;
import com.sidbi.ifv.dto.StatusResponseDto;
import com.sidbi.ifv.dto.TriggerResponseDto;
import com.sidbi.ifv.dto.VerticalDto;
import com.sidbi.ifv.entity.DFSErrorLog;
import com.sidbi.ifv.entity.IfvSanctionDetailsEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.repo.DFSErrorLogRepo;
import com.sidbi.ifv.services.BcmCifAPIClient;
import com.sidbi.ifv.services.BcmSchemeAPIClient;
import com.sidbi.ifv.services.CmtMemberMasterService;
import com.sidbi.ifv.services.MasterCommonAPIClient;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.services.SanctionDtService;

import feign.FeignException;

@Service
public class MasterDbServiceImpl implements MasterDbService {

	private static final Logger logger = LoggerFactory.getLogger(MasterDbServiceImpl.class);

	@Autowired
	private BcmCifAPIClient bcmCifAPIClient;

	@Autowired
	private BcmSchemeAPIClient bcmSchemeAPIClient;

	@Autowired
	private MasterCommonAPIClient masterCommonAPIClient;

	@Autowired
	private CmtMemberMasterService cmtMemberMasterService;

	@Autowired
	private SanctionDtService sanctionDtService;

	@Autowired
	private DFSErrorLogRepo dfsErrorLogRepo;

	String msg = "";

	@Autowired
	private ModelMapper mapper;

	@Override
	public List<Object> getAllBcmCifData() {
		logger.info("Started getAllBcmCifData() in MasterDbServiceImpl");
		try {
			return bcmCifAPIClient.findCustCDLongName();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getAllBcmCifData() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getAllBcmCifData() in MasterDbServiceImpl " + msg + "", e);
		}
	}

	@Override
	public List<Object> getBcmSchemes() {
		logger.info("Started getBcmSchemes() in MasterDbServiceImpl");
		try {
			return bcmSchemeAPIClient.findAllSchemes();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getBcmSchemes() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException("Error occurred in getBcmSchemes() in MasterDbServiceImpl " + msg + "",
					e);
		}
	}

	@Override
	public List<Object> getBcmLocationCodes() {
		logger.info("Started getBcmLocationCodes() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getBcmLocationCodes();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getBcmLocationCodes() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getBcmLocationCodes() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	public List<Object> getCustExpo(String cifNumber) {
		logger.info("Started getCustExpo() in MasterDbServiceImpl");
		try {
			LocalDate yesterday = LocalDate.now().minusDays(1);
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			String date = yesterday.format(dateTimeFormatter);
			return masterCommonAPIClient.getCustExpo(cifNumber, date);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getCustExpo() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException("Error occurred in getCustExpo() in MasterDbServiceImpl" + msg + "",
					e);
		}
	}

	public List<Object> getCustOs(String cifNumber) {
		logger.info("Started getCustOs() in MasterDbServiceImpl");
		try {
			LocalDate yesterday = LocalDate.now().minusDays(1);
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			String date = yesterday.format(dateTimeFormatter);
			return masterCommonAPIClient.getCustOs(cifNumber, date);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getCustOs() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException("Error occurred in getCustOs() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<Object> getPastDisbursements(String cifNumber) {
		logger.info("Started getPastDisbursements() in MasterDbServiceImpl");
		try {
			int year = Year.now().getValue();
			int month = LocalDate.now().getMonthValue();
			if (month >= 3) {
				year = year + 1;
			}
			return masterCommonAPIClient.getPastDisbursements(cifNumber, year);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getPastDisbursements() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getPastDisbursements() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<Object> outStandingDetails(String cifNumber) {
		logger.info("Started outStandingDetails() in MasterDbServiceImpl");
		try {

			int year = Year.now().getValue();
			int month = LocalDate.now().getMonthValue();
			if (month >= 3) {
				year = year + 1;
			}

			List<Object> dataList = masterCommonAPIClient.outStandingDetails(cifNumber);
			List<Object> filteredData = new ArrayList<>();
			for (Object obj : dataList) {
				if (obj instanceof Map) {
					@SuppressWarnings("unchecked")
					Map<String, Object> map = (Map<String, Object>) obj;
					int y = (int) map.getOrDefault("year", 0);
					if (y == year - 1 || y == year) {
						filteredData.add(obj);
					}
				}
			}

			return filteredData;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in outStandingDetails() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in outStandingDetails() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<Object> bcmFundCodeDetails(String fundAvailable) {
		logger.info("Started bcmFundCodeDetails() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.bcmFundCodeDetails(fundAvailable);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in bcmFundCodeDetails() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in bcmFundCodeDetails() in MasterDbServiceImpl" + msg + "", e);
		}

	}

	@Override
	public List<Object> futureRepayOfExistingOutStandingDTO(String cifNumber) {
		logger.info("Started futureRepayOfExistingOutStandingDTO() in MasterDbServiceImpl");
		try {
			List<Object> ob = new ArrayList<>();
			List<Integer> yearList = new ArrayList<>();
			int yr = Calendar.getInstance().get(Calendar.YEAR);
			yearList.add(yr);
			for (int i = 0; i < 8; i++) {
				yearList.add(++yr);
			}
			yearList.forEach(e -> {
				List<Object> list = masterCommonAPIClient.futureRepayOfExistingOutStandingDTO(cifNumber, e);
				if (list != null && !list.isEmpty()) {
					ob.addAll(list);
				}
			});

			return ob;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in futureRepayOfExistingOutStandingDTO() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in futureRepayOfExistingOutStandingDTO() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public BigDecimal exposureLimitForBarwBank(String cifNumber) {
		logger.info("Started exposureLimitForBarwBank() in MasterDbServiceImpl");
		try {
			int year = Year.now().getValue();
			int month = LocalDate.now().getMonthValue();
			if (month >= 3) {
				year = year + 1;
			}

			return masterCommonAPIClient.exposureLimitForBarwBank(cifNumber, year);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in exposureLimitForBarwBank() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in exposureLimitForBarwBank() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<CmtMemberMasterDTO> getHrmsEmpDetails(Integer cmtCode) {
		logger.info("Started getHrmsEmpDetails() in MasterDbServiceImpl");
		try {
			List<CmtMemberMasterDTO> dtos = cmtMemberMasterService.findAllByCmtCode(cmtCode);
			return dtos.stream().filter(e -> e.getEnableFlag().equals('Y'))
					.map(entity -> mapper.map(entity, CmtMemberMasterDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getHrmsEmpDetails() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getHrmsEmpDetails() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<Object> getSchemesOnFundCd(String fundCd) {
		logger.info("Started getSchemesOnFundCd() in MasterDbServiceImpl");
		try {
			return bcmSchemeAPIClient.findSchemesOnFundCd(fundCd);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getSchemesOnFundCd() in MasterDbServiceImpl {} {} ", msg, fundCd);
			throw new DatabaseOperationException(
					"Error occurred in getSchemesOnFundCd() in MasterDbServiceImpl " + msg + "" + fundCd + " ", e);
		}
	}

	@Override
	public List<Object> getFundCodeAndDesc() {
		logger.info("Started getFundCodeAndDesc() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getFundCodeAndDesc();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getFundCodeAndDesc() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getFundCodeAndDesc() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public List<HrmsEmpNameDesignationDTO> getEmployeeNames(List<String> empIds) {
		logger.info("Started getEmployeeNames() in MasterDbServiceImpl");
		try {
			List<HrmsEmpNameDesignationDTO> hrmsEmpNameDesignationDTOs = masterCommonAPIClient
					.getHrmsEmpDetails(empIds);
			return !hrmsEmpNameDesignationDTOs.isEmpty() ? hrmsEmpNameDesignationDTOs : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getEmployeeNames() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getEmployeeNames() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public Object saveSanctionDt(IfvSanctionDetailsEntity sanctionDtEntity) {
		return null;
	}

	@Override
	public List<Object> getAllSanctionDetails() {
		logger.info("Started getAllSanctionDetails() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getAllSanctionDetails();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getAllSanctionDetails() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getAllSanctionDetails() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public List<String> getAllEmpNames() {
		logger.info("Started getAllEmpNames() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getAllEmpNames();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getAllEmpNames() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getAllEmpNames() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public HrmsEmpNameDesignationDTO getEmpDetailsOnEmpName(String empName) {
		logger.info("Started getEmployeeNames() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getEmpDetailsOnEmpName(empName);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getEmpDetailsOnEmpName() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getEmpDetailsOnEmpName() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public Map<String, String> getEmpCodeAndDesc() {
		logger.info("Started getEmpCodeAndDesc() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getEmpCodeAndDesc();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getEmpCodeAndDesc() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getEmpCodeAndDesc() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public String getBankType(String custCd) {
		logger.info("Started getBankType() in MasterDbServiceImpl {} ", custCd);
		try {
			return masterCommonAPIClient.getBankType(custCd);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getBankType() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException("Error occurred in getBankType() in MasterDbServiceImpl " + msg + " ",
					e);
		}

	}

	@Override
	public Object findBankDetailsByCifNumber(String custCd) {
		logger.info("Started findBankDetailsByCifNumber() in MasterDbServiceImpl {} ", custCd);
		try {
			return masterCommonAPIClient.findBankDetailsByCifNumber(custCd);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in findBankDetailsByCifNumber() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in findBankDetailsByCifNumber() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public List<String> getBenchmarkDetails() {
		logger.info("Started getBenchmarkDetails() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getBenchmarkDetails();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getBenchmarkDetails() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getBenchmarkDetails() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public String getAddressByCifNumber(String custCd) {
		logger.info("Started getAddressByCifNumber() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getAddressByCifNumber(custCd);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getAddressByCifNumber() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getAddressByCifNumber() in MasterDbServiceImpl " + msg + " ", e);
		}
	}

	@Override
	public String getBankShortName(String custCd) {
		logger.info("Started getBankShortName() in MasterDbServiceImpl {} ", custCd);
		try {
			return masterCommonAPIClient.getBankShortName(custCd);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getBankShortName() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getBankShortName() in MasterDbServiceImpl " + msg + " ", e);
		}

	}

	@Override
	public List<Object> getDistrictsByState(String stateCode) {
		logger.info("Started getDistrictsByState() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getDistrictsByState(stateCode);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getDistrictsByState() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getDistrictsByState() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public Page<IfvSanctionDetailsDTO> getSanctionDetailsOnPage(int start, int size, String filters, String sorting,
			String globalFilter, String status) {
		logger.info("Started getSanctionDetailsOnPage() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getSanctionDetailsOnPage(start, size, filters, sorting, globalFilter, status);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getSanctionDetailsOnPage() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getSanctionDetailsOnPage() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public Long getSanctionedProposalsCount() {
		logger.info("Started getSanctionedProposalsCount() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getSanctionedProposalsCount();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getSanctionedProposalsCount() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getSanctionedProposalsCount() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public Boolean sendDataToDFS(List<Long> minuteIds) {
		logger.info("Started sendDataToDFS");
		if (CollectionUtils.isEmpty(minuteIds)) {
			String errorMsg = "Empty minutes data. No minute IDs provided for processing";
			logError(errorMsg, null);
			throw new IllegalArgumentException(errorMsg);
		}

		List<IfvSanctionDetailsDTO> sanctionDtDTOs;

		try {
			sanctionDtDTOs = sanctionDtService.findAllByBnlSrNoIn(minuteIds);
			if (CollectionUtils.isEmpty(sanctionDtDTOs)) {
				logError("No sanction data found for minute IDs: " + minuteIds, minuteIds);
				return false;
			}

			Boolean isSent = masterCommonAPIClient.postDataToDFS(sanctionDtDTOs);
			if (Boolean.TRUE.equals(isSent)) {
				logger.info("Successfully sent data to DFS for minute IDs: {}", minuteIds);
				return true;
			} else {
				logError("DFS API returned false for minute IDs: " + minuteIds, minuteIds);
				return false;
			}
		} catch (FeignException e) {
			String errorMsg = String.format("DFS API call failed with status %d: %s", e.status(), e.getMessage());
			logError(errorMsg, minuteIds, e);
			return false;
		} catch (Exception e) {
			logError("Unexpected error in DFS API call: " + e.getMessage(), minuteIds, e);
			return false;
		}
	}

	@Transactional
	private void logError(String errorMessage, List<Long> minuteIds) {
		logError(errorMessage, minuteIds, null);
	}

	@Transactional
	private void logError(String errorMessage, List<Long> minuteIds, Exception e) {
		try {
			DFSErrorLog errorLog = new DFSErrorLog();
			errorLog.setErrorMsg(errorMessage);
			errorLog.setMinuteIds(minuteIds != null ? minuteIds.toString() : null);
			dfsErrorLogRepo.save(errorLog);
			if (e != null) {
				logger.error("Error in sendDataToDFS() for minute IDs: {}", minuteIds, e);
			} else {
				logger.error(errorMessage);
			}
		} catch (Exception logError) {
			logger.error("Failed to save error log to database: {}", logError.getMessage(), logError);
		}
	}

	@Override
	public String getBenchMarkRateByName(String benchMarkName) {
		logger.info("Started getBenchMarkRateByName() in MasterDbServiceImpl {}", benchMarkName);
		try {
			return masterCommonAPIClient.getBenchMarkRateByName(benchMarkName);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getBenchMarkRateByName() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getBenchMarkRateByName() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<BigDecimal> getAllTrancheOnFundCode(String fundCode) {
		logger.info("Started getAllTrancheOnFundCode() in MasterDbServiceImpl {}", fundCode);
		try {
			return masterCommonAPIClient.getAllTrancheOnFundCode(fundCode);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getAllTrancheOnFundCode() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getAllTrancheOnFundCode() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public Page<IfvDigilendingDetailsDto> fetchBenificiaryDetails(int page, int size) {
		logger.info("Started getSanctionDetailsOnPage() in MasterDbServiceImpl");
		try {
			return null;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in fetchBenificiaryDetails() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in fetchBenificiaryDetails() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<String> fetchLoanAccNoOnCif(String cifNumber) {
		logger.info("Started fetchLoanAccNoOnCif() in MasterDbServiceImpl {}", cifNumber);
		try {
			return masterCommonAPIClient.fetchLoanAccNoOnCif(cifNumber);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in fetchLoanAccNoOnCif() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in fetchLoanAccNoOnCif() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public Boolean savePreDisbData(IfvRefMasterDto ifvRefMasterDto) {
		logger.info("Started savePreDisbData() in MasterDbServiceImpl {}", ifvRefMasterDto.getCustCd());
		try {
			return masterCommonAPIClient.savePreDisbData(ifvRefMasterDto);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in savePreDisbData() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in savePreDisbData() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public String saveIfvBeneficiaryDetails(String filePath) {
		logger.info("Started saveIfvBeneficiaryDetails() in MasterDbServiceImpl {}", filePath);
		try {
			return masterCommonAPIClient.saveIfvBeneficiaryDetails(filePath);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in saveIfvBeneficiaryDetails() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in saveIfvBeneficiaryDetails() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public Map<String, Object> processingStatus(String jobId) {
		logger.info("Started processingStatus() in MasterDbServiceImpl {}", jobId);
		try {
			return masterCommonAPIClient.processingStatus(jobId);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in processingStatus() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in processingStatus() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public void saveIfvBeneficiaryDetailsAsync(IfvIntBeneficiaryDetailRequest beneficiaryDetailRequest) {
		logger.info("Started processingStatus() in MasterDbServiceImpl {}", beneficiaryDetailRequest.getJobId());
		try {
			masterCommonAPIClient.saveIfvBeneficiaryDetailsAsync(beneficiaryDetailRequest);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in processingStatus() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in processingStatus() in MasterDbServiceImpl" + msg + "", e);
		}

	}

	@Override
	public List<String> fetchDisbDateOnAccNo(String accNo) {
		logger.info("Started fetchDisbDateOnAccNo() in MasterDbServiceImpl accNo : {}", accNo);
		try {
			return masterCommonAPIClient.fetchDisbDateOnAccNo(accNo);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in fetchDisbDateOnAccNo() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in fetchDisbDateOnAccNo() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<VerticalDto> getIfvVerticals() {
		logger.info("Started getIfvVerticals() in MasterDbServiceImpl");
		try {
			return masterCommonAPIClient.getIfvVerticals();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getIfvVerticals() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getIfvVerticals() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public List<CustomerDto> fetchCustomersOnVertical(String vertical) {
		logger.info("Started fetchDisbDateOnAccNo() in MasterDbServiceImpl vertical: {}", vertical);
		try {
			return masterCommonAPIClient.fetchCustomersOnVertical(vertical);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in fetchCustomersOnVertical() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in fetchCustomersOnVertical() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public StatusResponseDto checkStatus(AggregateExposureRequestDto dto) {
		logger.info("Started checkStatus() in MasterDbServiceImpl asOnDate: {} : {}", dto.getAsOnDate(),
				dto.getGroupName());
		try {
			return masterCommonAPIClient.checkStatus(dto);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in checkStatus() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException("Error occurred in checkStatus() in MasterDbServiceImpl" + msg + "",
					e);
		}
	}

	@Override
	public TriggerResponseDto triggerProcedure(AggregateExposureRequestDto dto) {
		logger.info("Started triggerProcedure() in MasterDbServiceImpl cif: {}", dto.getCifNumber());
		try {
			return masterCommonAPIClient.triggerProcedure(dto);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in triggerProcedure() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in triggerProcedure() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public AggregateExposureResponseDto getAggregateExposureData(AggregateExposureRequestDto dto) {
		logger.info("Started getAggregateExposureData() in MasterDbServiceImpl cif: {}", dto.getCifNumber());
		try {
			return masterCommonAPIClient.getAggregateExposureData(dto);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getAggregateExposureData() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getAggregateExposureData() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public String getGroupNameByCif(String cifNumber) {
		logger.info("Started getGroupNameByCif() in MasterDbServiceImpl cif: {}", cifNumber);
		try {
			return masterCommonAPIClient.getGroupNameByCif(cifNumber);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getGroupNameByCif() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getGroupNameByCif() in MasterDbServiceImpl" + msg + "", e);
		}
	}

	@Override
	public BigDecimal getAggregateExposureOnGroup(AggregateExposureRequestDto dto) {
		logger.info("Started getAggregateExposureOnGroup() in MasterDbServiceImpl cif: {}", dto.getCifNumber());
		try {
			return masterCommonAPIClient.getAggregateExposureOnGroup(dto);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error occurred in getAggregateExposureOnGroup() in MasterDbServiceImpl {} ", msg);
			throw new DatabaseOperationException(
					"Error occurred in getAggregateExposureOnGroup() in MasterDbServiceImpl" + msg + "", e);
		}
	}

}
