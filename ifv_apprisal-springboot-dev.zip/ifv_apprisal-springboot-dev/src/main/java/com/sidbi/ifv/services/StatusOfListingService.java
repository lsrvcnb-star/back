package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.StatusOfListingDto;

public interface StatusOfListingService extends CrudService<StatusOfListingDto, Long> {

	List<StatusOfListingDto> findAllByIfvId(Long ifvId);

}