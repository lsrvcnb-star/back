package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVInvestorEntity;

public interface InvestorRepository extends JpaRepository<S2IFVInvestorEntity, Long> {
	
	List<S2IFVInvestorEntity> findByIfvId(Long ifvId);

}
