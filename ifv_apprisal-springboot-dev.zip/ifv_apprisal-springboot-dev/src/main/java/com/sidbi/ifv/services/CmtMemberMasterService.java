package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.CmtMemberMasterDTO;

public interface CmtMemberMasterService extends CrudService<CmtMemberMasterDTO, Long> {

	List<CmtMemberMasterDTO> findAll();

	List<CmtMemberMasterDTO> findAllByCmtCode(Integer cmtCode);

}