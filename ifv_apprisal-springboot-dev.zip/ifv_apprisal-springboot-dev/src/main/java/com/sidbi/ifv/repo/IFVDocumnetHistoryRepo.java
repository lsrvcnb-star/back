package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sidbi.ifv.entity.IFVDocumnetHistoryEntity;

public interface IFVDocumnetHistoryRepo extends JpaRepository<IFVDocumnetHistoryEntity, Long> {

	@Query(value = "select distinct hst_curr_officer_code  from  tbl_fwd_history  where fwd_status_id=:fwdStatusID", nativeQuery = true)
	List<Long> findByfwdStatusID(Long fwdStatusID);
	
	//@Query(value = "select *  from  tbl_fwd_history  where fwd_status_id=:fwdStatusID", nativeQuery = true)
	List<IFVDocumnetHistoryEntity> findAllByFwdStatusID(Long fwdStatusID);
}
