package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.SanctionTermsConditionsDTO;

public interface SanctionTermsConditionsService extends CrudService<SanctionTermsConditionsDTO, Long> {

	List<SanctionTermsConditionsDTO> findAllByIfvId(Long ifvId);

	List<SanctionTermsConditionsDTO> findAllByIfvIdAndPrId(Long ifvId, Long prId);

	SanctionTermsConditionsDTO findByIfvIdAndPrId(Long ifvId, Long prId);

	List<SanctionTermsConditionsDTO> findByAppNumberAndPrId(String appNo, Long prId, Long loiId);
}