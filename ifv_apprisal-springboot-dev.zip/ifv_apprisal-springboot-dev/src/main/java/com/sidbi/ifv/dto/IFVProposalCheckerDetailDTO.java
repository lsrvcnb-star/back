package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IFVProposalCheckerDetailDTO {

	private Long id;

	private Long ifvId;

	private Character status;

	private Long currentUserId;

	private String currentUserName;

	private String currentUserDesignation;

	private String currentUserAction;

	private LocalDateTime dateTimeOfReceipt;

	private LocalDateTime dateTimeOfAction;

	private String currentUserComment;

	private Long forwardedUserId;

	private String forwardedUserName;

	private String forwardedUserDesignation;

}
