package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.UcbEligibilityCriteriaDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.UcbEligibilityCriteriaService;

@RestController
@CrossOrigin
@RequestMapping("/ucb-eligibility-criteria")
public class UcbEligibilityCriteriaController extends CrudController<UcbEligibilityCriteriaDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(UcbEligibilityCriteriaController.class);

	@Autowired
	private UcbEligibilityCriteriaService service;

	@Override
	public CrudService<UcbEligibilityCriteriaDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<UcbEligibilityCriteriaDTO>> getUcbEligibilityIfvId(@PathVariable Long ifvId) {
		logger.info("getUcbFincOnIfvId() started in UcbEligibilityCriteriaController ");
		List<UcbEligibilityCriteriaDTO> dtos = service.findAllByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}
}
