package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.services.TblIfvModuleFwdService;

@CrossOrigin
@RestController
@RequestMapping("/ifv/modulefwd")
public class TblIfvModuleFwdController {

	private static final Logger logger = LoggerFactory.getLogger(TblIfvModuleFwdController.class);

	@Autowired
	private TblIfvModuleFwdService tblIfvModuleFwdService;

	@GetMapping("/getAll")
	public ResponseEntity<List<TblIfvModuleFwdDTO>> findAll() {
		logger.info("getAll() started TblIfvModuleFwdContoller ");
		List<TblIfvModuleFwdDTO> list = tblIfvModuleFwdService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<TblIfvModuleFwdDTO> save(@RequestBody TblIfvModuleFwdDTO tblIfvModuleFwdDTO) {
		logger.info("save() started TblIfvModuleFwdContoller ");
		TblIfvModuleFwdDTO createApplication = tblIfvModuleFwdService.save(tblIfvModuleFwdDTO);
		return ResponseEntity.ok(createApplication);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<TblIfvModuleFwdDTO> findById(@PathVariable Long id) {
		logger.info("getById() started TblIfvModuleFwdContoller {} ", id);
		TblIfvModuleFwdDTO tblIfvModuleFwdDTO = tblIfvModuleFwdService.findById(id);
		return ResponseEntity.ok(tblIfvModuleFwdDTO);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<TblIfvModuleFwdDTO> update(@PathVariable long id,
			@RequestBody TblIfvModuleFwdDTO tblIfvModuleFwdDTO) {
		logger.info("update() started TblIfvModuleFwdContoller {} ", id);
		TblIfvModuleFwdDTO updateApp = tblIfvModuleFwdService.update(id, tblIfvModuleFwdDTO);
		return ResponseEntity.ok(updateApp);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started TblIfvModuleFwdContoller {} ", id);
		tblIfvModuleFwdService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getByIfvId/{id}")
	public ResponseEntity<TblIfvModuleFwdDTO> getByIfvId(@PathVariable Long id) {
		logger.info("getByIfvId() started TblIfvModuleFwdContoller {} ", id);
		TblIfvModuleFwdDTO tblIfvModuleFwdDTO = tblIfvModuleFwdService.findByIfvId(id);
		return ResponseEntity.ok(tblIfvModuleFwdDTO);
	}

	@GetMapping("/getByAlCode/{alCode}")
	public ResponseEntity<TblIfvModuleFwdDTO> getByAlCode(@PathVariable Long alCode) {
		logger.info("getByAlCode() started TblIfvModuleFwdContoller {} ", alCode);
		TblIfvModuleFwdDTO tblIfvModuleFwdDTO = tblIfvModuleFwdService.findByAlCode(alCode);
		return ResponseEntity.ok(tblIfvModuleFwdDTO);
	}
}
