package com.sidbi.ifv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_CHIEFBOARD")
public class S2IFVChiefBoardEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CB_ID") 	
	private Long cbId;
	
	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "CB_NAME")
	private String cbName;
	
	@Column(name = "CB_DESIGNATION")
	private String cbDesignation;
	
	@Column(name = "CB_REMARKS")
	private String cbRemarks;
	
	@Column(name = "CB_TYPE")
	private String cbType;

}
