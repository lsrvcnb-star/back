package com.sidbi.ifv.services;

import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.dto.CommonRequestDto;

public interface FileStorageService {
	ResponseEntity<StreamingResponseBody> handleFile(CommonRequestDto requestDto);
}
