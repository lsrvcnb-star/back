package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AssOutstandingDTO;

public interface AssOutstandingService {

	AssOutstandingDTO findById(Long id);

	AssOutstandingDTO save(AssOutstandingDTO ifccApplicationDTO);

	AssOutstandingDTO update(Long id, AssOutstandingDTO s2IfccApplicationDTO);

	void delete(Long id);

	List<AssOutstandingDTO> findAll();

	List<AssOutstandingDTO> saveAll(List<AssOutstandingDTO> listAssOutstandingDTO);

	List<AssOutstandingDTO> findAllByIfvId(Long ifvId);
}
