package com.sidbi.ifv.util;

import java.util.Hashtable;

import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.security.auth.login.AccountException;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class ActiveDirectoryAuthenticationUtil {

	private static final String CONTEXT_FACTORY_CLASS = "com.sun.jndi.ldap.LdapCtxFactory";

	private String[] ldapServerUrls;

	private int lastLdapUrlIndex;

	private final String domainName;

	public ActiveDirectoryAuthenticationUtil(String domainName) {
		this.domainName = domainName.toUpperCase();

		try {
			ldapServerUrls = new String[]{"ldap://172.16.100.24:389","ldap://172.16.100.25:389","ldap://172.20.99.24:389", "ldap://172.20.99.25:389"};
		} catch (Exception e) {
			e.printStackTrace();
		}
		lastLdapUrlIndex = 0;
	}

	public boolean authenticate(String username, String password) throws AccountException {
		if (ldapServerUrls == null || ldapServerUrls.length == 0) {
			throw new AccountException("Unable to find ldap servers");
		}
		int retryCount = 0;
		int currentLdapUrlIndex = lastLdapUrlIndex;
		do {
			retryCount++;
			try {
				// Set up the environment for creating the initial context
				Hashtable<Object, Object> env = new Hashtable<>();
				env.put(Context.INITIAL_CONTEXT_FACTORY, CONTEXT_FACTORY_CLASS);
				env.put(Context.PROVIDER_URL, ldapServerUrls[currentLdapUrlIndex]);
				env.put(Context.SECURITY_PRINCIPAL, username + "@" + domainName);
				env.put(Context.SECURITY_CREDENTIALS, password);//when move to production need to uncomment this line -11-03-2020
				DirContext ctx = new InitialDirContext(env);
				ctx.close();
				lastLdapUrlIndex = currentLdapUrlIndex;
				return true;
			} catch (CommunicationException exp) {
				exp.printStackTrace();
				// if the exception of type communication we can assume the AD
				// is not reachable hence retry can be attempted with next
				// available AD
				if (retryCount < ldapServerUrls.length) {
					currentLdapUrlIndex++;
					if (currentLdapUrlIndex == ldapServerUrls.length) {
						currentLdapUrlIndex = 0;
					}
					continue;
				}
				return false;
			} catch (Exception e) {
				log.error("Exception occured: {}",e.getMessage());
				return false;
			}
		} while (true);
	}
}
