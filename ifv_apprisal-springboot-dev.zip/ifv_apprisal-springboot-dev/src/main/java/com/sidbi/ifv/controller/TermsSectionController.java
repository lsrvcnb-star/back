package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.TermsSectionDTO;
import com.sidbi.ifv.services.TermSanctionService;

@RestController
@RequestMapping("/ifv/ifcsanction")
@CrossOrigin(origins = "*")
public class TermsSectionController {

	@Autowired
	private TermSanctionService sanctionService;

	private static final Logger logger = LoggerFactory.getLogger(TermsSectionController.class);

	@GetMapping("/get/{iffId}")
	public ResponseEntity<TermsSectionDTO> getTermSanction(@PathVariable Long ifvId) {
		logger.info("getTermSanction() started TermsSectionController {} ",ifvId);
		TermsSectionDTO termSanctionDTO = sanctionService.getTermSanctionById(ifvId);
		return ResponseEntity.ok(termSanctionDTO);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<TermsSectionDTO>> getAllTermSanction() {
		logger.info("getAllTermSanction() started TermsSectionController ");
		List<TermsSectionDTO> list = sanctionService.getAllTermSanction();
		return ResponseEntity.ok(list);
	}

}
