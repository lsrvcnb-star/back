package com.sidbi.ifv.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.dto.IfvLoIDocumentUploadRequest;
import com.sidbi.ifv.dto.IfvSignedLoiRequestDTO;
import com.sidbi.ifv.dto.IfvSignedLoiResponseDTO;
import com.sidbi.ifv.dto.LoIDetailDTO;
import com.sidbi.ifv.dto.LoiEmailNotificationDTO;
import com.sidbi.ifv.dto.LoiStatusCountResponse;
import com.sidbi.ifv.entity.AppraisalMinutesDataEntity;
import com.sidbi.ifv.entity.IfvBankRefinanceApplication;
import com.sidbi.ifv.entity.IfvLoiDocuments;
import com.sidbi.ifv.entity.LoIDetailEntity;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.enums.FileModule;
import com.sidbi.ifv.enums.FileSubModuleEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.AppraisalMinutesDataRepository;
import com.sidbi.ifv.repo.IfvBankRefinanceApplicationRepository;
import com.sidbi.ifv.repo.IfvLoiDocumentsRepository;
import com.sidbi.ifv.repo.LoIDetailRepo;
import com.sidbi.ifv.services.LoIDetailService;
import com.sidbi.ifv.specs.IfvSignedLoiSpecification;
import com.sidbi.ifv.util.FileUploadUtility;
import com.sidbi.ifv.util.GenericSpecification;
import com.sidbi.ifv.util.SortingUtil;

@Service
public class LoIDetailServiceImpl implements LoIDetailService {

	private static final Logger logger = LoggerFactory.getLogger(LoIDetailServiceImpl.class);

	@Autowired
	private LoIDetailRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";
	private static final String LOI_ENTITY = "LoIDetailEntity";

	@Autowired
	private IfvLoiDocumentsRepository ifvLoiDocumentsRepository;

	@Autowired
	private FileUploadUtility fileUploadService;

	@Autowired
	private AppraisalMinutesDataRepository appraisalMinutesDataRepository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private IfvBankRefinanceApplicationRepository ifvBankRefinanceApplicationRepository;

	private static final ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public LoIDetailDTO findById(Long id) {
		logger.info("findById() started in LoIDetailServiceImpl for LoIDetailEntity {} ", id);
		LoIDetailEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("LOIDetailEntity", id));
		return mapper.map(entity, LoIDetailDTO.class);
	}

	@Override
	public List<LoIDetailDTO> findAll() {
		logger.info("findAll() started in LoIDetailServiceImpl of LoIDetailEntity");
		try {
			List<LoIDetailEntity> list = repository.findAll();
			return !list.isEmpty()
					? list.stream().map(entity -> mapper.map(entity, LoIDetailDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all LoIDetailEntity .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all LoIDetailEntity ." + msg + " ", e);
		}
	}

	@Override
	public LoIDetailDTO save(LoIDetailDTO dto) {
		logger.info("save() started in LoIDetailServiceImpl for LoIDetailEntity {} ", dto);
		try {
			LoIDetailEntity existingEntity = null;
			if (dto.getId() != null && dto.getId() > 0) {

				existingEntity = repository.findById(dto.getId())
						.orElseThrow(() -> new EntityNotFoundException(LOI_ENTITY, dto.getId()));

				BeanUtils.copyProperties(dto, existingEntity);

			} else {
				existingEntity = mapper.map(dto, LoIDetailEntity.class);
			}

			repository.save(existingEntity);

			return mapper.map(existingEntity, LoIDetailDTO.class);
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while creating LoIDetailEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  LoIDetailEntity." + msg + " ", e);
		}
	}

	@Override
	public List<LoIDetailDTO> saveAll(List<LoIDetailDTO> dtos) {
		logger.info("saveAll() started in LoIDetailServiceImpl for List of LoIDetailEntity");
		try {

			List<LoIDetailEntity> entitiesToSave = dtos.stream().map(dto -> mapper.map(dto, LoIDetailEntity.class))
					.collect(Collectors.toList());
			List<LoIDetailEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, LoIDetailDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all LoIDetailEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all LoIDetailEntity." + msg + " ", e);
		}
	}

	@Override
	public LoIDetailDTO update(Long id, LoIDetailDTO dto) {
		logger.info("update() started in LoIDetailServiceImpl for LoIDetailEntity {} {} ", id, dto);
		try {
			LoIDetailEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException(LOI_ENTITY, id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, LoIDetailDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating LoIDetailEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating LoIDetailEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in LoIDetailServiceImpl for LoIDetailEntity {} ", id);
		try {
			LoIDetailEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException(LOI_ENTITY, id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting LoIDetailEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting LoIDetailEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public LoIDetailDTO findBySancId(Long sancId) {
		logger.info("findBySancId() started in LoIDetailServiceImpl for LoIDetailEntity {} ", sancId);
		try {

			LoIDetailEntity entity = repository.findBySancId(sancId);

			if (entity != null) {
				return mapper.map(entity, LoIDetailDTO.class);
			} else {
				return new LoIDetailDTO();
			}

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findBySancId LoIDetailEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findBySancId LoIDetailEntity of id ." + msg + " " + sancId, e);
		}
	}

	@Override
	public LoIDetailDTO findLoIBySancIdAndSancDetailCode(Long sancId, Long sancDetailId, Long minuteId) {
		logger.info("findLoIBySancIdAndSancDetailCode() started in LoIDetailServiceImpl for LoIDetailEntity {} ",
				sancId);
		try {

			LoIDetailEntity entity = repository.findLoIBySancIdAndSancDetailIdAndAppraisalMnuteId(sancId, sancDetailId,
					minuteId);

			if (entity != null) {
				return mapper.map(entity, LoIDetailDTO.class);
			} else {
				return new LoIDetailDTO();
			}

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findLoIBySancIdAndSancDetailCode LoIDetailEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findLoIBySancIdAndSancDetailCode LoIDetailEntity of id ." + msg + " "
							+ sancId,
					e);
		}
	}

	@Override
	public Page<LoIDetailDTO> getAllOnUserTypeOnPage(int page, int size, String filters, String sorting,
			String globalFilter) {
		logger.info("getAllOnUserTypeOnPage() started in SanctionMinutesServiceImpl for sancMinId ");
		try {

			Sort baseSort = Sort.by(Sort.Order.desc("id"));
			if (StringUtils.hasText(sorting)) {
				Sort additionalSort = SortingUtil.parseSort(sorting);
				baseSort = baseSort.and(additionalSort);
			}

			Specification<LoIDetailEntity> spec = new GenericSpecification<>(filters);
			Pageable pageable = PageRequest.of(page, size, baseSort);
			Page<LoIDetailEntity> entityPage = repository.findAll(spec, pageable);
			List<LoIDetailDTO> loIDetailDTOs = entityPage.getContent().stream()
					.map(entity -> mapper.map(entity, LoIDetailDTO.class)).collect(Collectors.toList());
			return new PageImpl<>(loIDetailDTOs, pageable, entityPage.getTotalElements());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while getAllOnUserTypeOnPage sanctionMinutesEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while getAllOnUserTypeOnPage sanctionMinutesEntity of id: " + msg + " ", e);
		}
	}

	@Override
	public LoiEmailNotificationDTO submitSignedLoI(MultipartFile file, IfvLoIDocumentUploadRequest request) {

		logger.info("submitSignedLoI() started. loiDetailsId={}", request.getLoiDetailsId());

		try {

			LoIDetailEntity loiEntity = repository.findById(request.getLoiDetailsId())
					.orElseThrow(() -> new EntityNotFoundException("LoI Details not found",
							String.valueOf(request.getLoiDetailsId())));

			logger.info("LoI details found. loiDetailsId={}, ifvNo={}", loiEntity.getId(), loiEntity.getIfvNo());

			Optional<AppraisalMinutesDataEntity> appraisalMinutesDataOpt = appraisalMinutesDataRepository
					.findById(loiEntity.getAppraisalMnuteId());

			AppraisalMinutesDataEntity appraisalMinutesData = appraisalMinutesDataOpt
					.orElseThrow(() -> new EntityNotFoundException("Appraisal Minutes not found",
							String.valueOf(loiEntity.getAppraisalMnuteId())));

			String appNo = appraisalMinutesData.getAppId();

			S2IFVApplicationEntity application = applicationRepository.findByAppNumber(appNo).get(0);

			if (application == null) {
				throw new EntityNotFoundException("IFV application not found", appNo);
			}

			String filePath = fileUploadService.uploadIfvLoiFile(file, file.getOriginalFilename(), FileModule.LOI,
					FileSubModuleEnum.SIGNED_LOI, appNo, loiEntity.getId());
			String bankRefNo = null;
			String bankEmailId = null;

			if (StringUtils.hasText(application.getBankAppRefNos())) {

				logger.info("Bank App Ref Nos JSON: {}", application.getBankAppRefNos());

				List<String> bankAppRefNos = objectMapper.readValue(application.getBankAppRefNos(),
						new TypeReference<List<String>>() {
						});

				logger.info("Parsed bankAppRefNos: {}", bankAppRefNos);

				if (!CollectionUtils.isEmpty(bankAppRefNos)) {

					List<IfvBankRefinanceApplication> bankApps = ifvBankRefinanceApplicationRepository
							.findByAppRefIdIn(bankAppRefNos);

					logger.info("Found {} bank applications", bankApps.size());

					for (IfvBankRefinanceApplication app : bankApps) {

						logger.info("Checking AppRefId={}, FundCode={}, SubmitByEmail={}", app.getAppRefId(),
								app.getFundCode(), app.getSubmitByEmail());

						if (Objects.equals(appraisalMinutesData.getFundCode(), app.getFundCode())) {

							bankRefNo = app.getAppRefId();
							bankEmailId = app.getSubmitByEmail();

							logger.info("Matched Bank App. AppRefId={}, Email={}", bankRefNo, bankEmailId);

							break;
						}
					}

					if (!StringUtils.hasText(bankRefNo)) {

						logger.warn("No matching bank app found for FundCode={}. Falling back to first application.",
								appraisalMinutesData.getFundCode());

						IfvBankRefinanceApplication fallbackApp = bankApps.get(0);

						bankRefNo = fallbackApp.getAppRefId();
						bankEmailId = fallbackApp.getSubmitByEmail();

						logger.info("Fallback AppRefId={}, Email={}", bankRefNo, bankEmailId);
					}
				}
			}

			logger.info("Final Selection -> AppRefId={}, Email={}", bankRefNo, bankEmailId);

			IfvLoiDocuments document = new IfvLoiDocuments();

			document.setBankName(application.getIfvName());
			document.setCifNumber(application.getCifNumber());

			document.setLoiDetailsId(loiEntity.getId());
			document.setIfvAppNo(appNo);
			document.setBankRefNo(bankRefNo);
			document.setScheme(request.getScheme());
			document.setSanctionAmount(request.getAmount());

			document.setLoiNo(loiEntity.getIfvNo());

			document.setFileName(file.getOriginalFilename());
			document.setFilePath(filePath);
			document.setFileSize(file.getSize());
			document.setFileType(file.getContentType());

			document.setStatus("ISSUED");

			document.setUploadedBy(request.getUploadBy());
			document.setUploadedDate(LocalDateTime.now());

			document.setSanctionedDateTime(LocalDateTime.now());

			ifvLoiDocumentsRepository.save(document);

			logger.info("Signed LoI uploaded successfully. loiDetailsId={}, appNo={}, bankRefNo={}",
					document.getLoiDetailsId(), document.getIfvAppNo(), document.getBankRefNo());

			LoiEmailNotificationDTO response = new LoiEmailNotificationDTO();
			response.setAppRefNo(bankRefNo);
			response.setBankEmailId(bankEmailId);
			response.setBankName(application.getIfvName());
			response.setLoiNo(loiEntity.getIfvNo());

			logger.info("Email data bankEmailId={}, appNo={}, loiNo={}", bankEmailId, application.getIfvName(),
					loiEntity.getIfvNo());

			return response;
		}

		catch (Exception e) {

			logger.error("Error while uploading signed LoI. loiDetailsId={}", request.getLoiDetailsId(), e);

			throw new DatabaseOperationException("Error occurred while uploading signed LoI", e);
		}
	}

	@Override
	public IfvLoiDocuments getSignedLoIDocument(Long loiDetailsId) {

		return ifvLoiDocumentsRepository.findByLoiDetailsId(loiDetailsId).orElse(null);
	}

	@Override
	public Page<IfvSignedLoiResponseDTO> fetchSignedLoiSummary(IfvSignedLoiRequestDTO request) {

		logger.info("fetchSignedLoiSummary called");

		try {

			Pageable pageable = getPageable(request);

			Specification<IfvLoiDocuments> spec = IfvSignedLoiSpecification.filter(request);

			Page<IfvLoiDocuments> entityPage = ifvLoiDocumentsRepository.findAll(spec, pageable);

			return entityPage.map(entity -> mapper.map(entity, IfvSignedLoiResponseDTO.class));

		} catch (Exception e) {

			throw new DatabaseOperationException("Error fetching Signed LoI Summary", e);
		}
	}

	private Pageable getPageable(IfvSignedLoiRequestDTO request) {

		String sortField = StringUtils.hasText(request.getSortField()) ? request.getSortField() : "uploadedDate";

		Sort.Direction direction = "asc".equalsIgnoreCase(request.getSortDirection()) ? Sort.Direction.ASC
				: Sort.Direction.DESC;

		return PageRequest.of(request.getPage(), request.getSize(), Sort.by(direction, sortField));
	}

	@Override
	@Transactional
	public LoiEmailNotificationDTO submitCounterSignedLoI(MultipartFile file, Long loiDetailsId) {

		logger.info("submitCounterSignedLoI started. loiDetailsId={}", loiDetailsId);

		try {

			IfvLoiDocuments document = ifvLoiDocumentsRepository.findByLoiDetailsId(loiDetailsId).orElseThrow(
					() -> new EntityNotFoundException("LoI document not found", String.valueOf(loiDetailsId)));

			String filePath = fileUploadService.uploadIfvLoiFile(file, file.getOriginalFilename(), FileModule.LOI,
					FileSubModuleEnum.COUNTER_SIGNED_LOI, document.getIfvAppNo(), loiDetailsId);

			document.setCounterFileName(file.getOriginalFilename());
			document.setCounterFilePath(filePath);
			// document.setCounterUploadedBy(request.getUploadBy());
			document.setCounterUploadedDate(LocalDateTime.now());
			// document.setCounterRemarks(request.getRemarks());

			document.setStatus("COUNTER_SIGNED");

			// document.setModifiedBy(request.getUploadBy());
			document.setModifiedDate(LocalDateTime.now());

			ifvLoiDocumentsRepository.save(document);

			logger.info("Counter signed LoI uploaded successfully. loiDetailsId={}", loiDetailsId);

			IfvBankRefinanceApplication bankApp = ifvBankRefinanceApplicationRepository
					.findByAppRefId(document.getBankRefNo()).orElseThrow(
							() -> new EntityNotFoundException("Bank Application not found", document.getBankRefNo()));

			LoiEmailNotificationDTO response = new LoiEmailNotificationDTO();

			response.setAppRefNo(document.getBankRefNo());
			response.setBankEmailId(bankApp.getSubmitByEmail());
			response.setBankName(document.getBankName());
			response.setLoiNo(document.getLoiNo());

			return response;

		} catch (Exception e) {

			logger.error("Error while uploading counter signed LoI. loiDetailsId={}", loiDetailsId, e);

			throw new DatabaseOperationException("Error occurred while uploading counter signed LoI", e);
		}
	}

	@Override
	public ResponseEntity<LoiStatusCountResponse> fetchLoiStatusCounts(String cifNumber) {
		return ResponseEntity.ok(ifvLoiDocumentsRepository.fetchLoiStatusCounts(cifNumber));
	}

}
