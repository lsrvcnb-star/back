package com.sidbi.ifv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ucb_eligibility_criteria")
public class UcbEligibilityCriteriaEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "particulars")
	private String particulars;

	@Column(name = "bfs_norm")
	private String bfsNorm;

	@Column(name = "compliance_status")
	private String complianceStatus;

	@Column(name = "compliance_status_year")
	private String complianceStatusYear;

	@Column(name = "eligibility_type")
	private String eligibilityType;

	@Column(name = "relaxation_cap")
	private String relaxationCap;

}
