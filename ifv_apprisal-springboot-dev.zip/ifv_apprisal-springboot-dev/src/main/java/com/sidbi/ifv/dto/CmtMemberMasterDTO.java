package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class CmtMemberMasterDTO {

	private Long cmtMemberCode;

	private String memberCode;

	private String cmtMemberRole;

	private BigDecimal cmtCode;

	private String cmtType;

	private String cmtRemark;

	private String createdBy;

	private Date createdDate;

	private Character enableFlag;

	private String memberName;

	private String memberVertical;

	private String memberShortName;

	private String memberMailId;

}