package com.sidbi.ifv.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ifv_rimv_apps")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IfvRimvApp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "rimv_ref_id", nullable = false, length = 20)
	private String rimvRefId;

	@Column(name = "cif_number", nullable = false, length = 150)
	private String cifNumber;

	@Column(name = "bank_name", nullable = false, length = 150)
	private String bankName;

	@Column(name = "current_user_id")
	private Long currentUserId;

	@Column(name = "current_user_name", length = 150)
	private String currentUserName;

	@Column(name = "created_date_time")
	private LocalDateTime createdDateTime;

	@Column(name = "fwd_status", length = 50)
	private String fwdStatus;

	@Column(name = "forwarded_date_time")
	private LocalDateTime forwardedDateTime;

	@Column(name = "fwd_comments", length = 4000)
	private String fwdComments;

	@Column(name = "fwd_user_id")
	private Long fwdUserId;

	@Column(name = "fwd_by")
	private String fwdBy;

	@Column(name = "rimv_comments", length = 4000)
	private String rimvComments;

	@Column(name = "rimv_file_path", length = 500)
	private String rimvFilePath;

	@Column(name = "single_scale_rating", length = 500)
	private String singleScaleRating;

	@Column(name = "combined_rating", length = 500)
	private String combinedRating;

	@Column(name = "rimv_updated_date_time")
	private LocalDateTime rimvUpdatedDateTime;
}