package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "IFV_BANK_REFINANCE_APPLICATION", uniqueConstraints = { @UniqueConstraint(columnNames = "APP_REF_ID") })
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IfvBankRefinanceApplication {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "APP_REF_ID", nullable = false)
	private String appRefId;

	@Column(name = "NAME_OF_BANK")
	private String nameOfBank;

	@Column(name = "CIF_NUMBER")
	private String cifNumber;

	@Column(name = "TYPE_OF_BANK")
	private String typeOfBank;

	@Column(name = "FUND_CODE")
	private String fundCode;

	@Column(name = "FUND_DESCRIPTION")
	private String fundDescription;

	@Column(name = "SCHEME_CODE")
	private String schemeCode;

	@Column(name = "SCHEME_SHORT_NAME")
	private String schemeShortName;

	@Column(name = "SCHEME_LONG_NAME")
	private String schemeLongName;

	@Column(name = "CUSTOM_SCHEME_NAME")
	private String customSchemeName;

	@Column(name = "CURRENCY_TYPE")
	private String currencyType;

	@Column(name = "APPLICATION_STATUS")
	private String applicationStatus;

	@Column(name = "FRAMEWORK_PARM_TIER")
	private BigDecimal frameworkParmTier;

	@Column(name = "FRAMEWORK_PARM_CRAR")
	private BigDecimal frameworkParmCRAR;

	@Column(name = "FRAMEWORK_PARM_CET1")
	private BigDecimal frameworkParmCET1;

	@Column(name = "FRAMEWORK_PARM_CCB")
	private BigDecimal frameworkParmCCB;

	@Column(name = "BANK_NAME")
	private String bankName;

	@Column(name = "BANK_ACCOUNT_NO")
	private String bankAccountNo;

	@Column(name = "RTGS_CODE")
	private String rtgsCode;

	@Column(name = "NEFT_CODE")
	private String neftCode;

	@Column(name = "BANK_ADDRESS")
	private String bankAddress;

	@Column(name = "LEGAL_ENTITY_IDENTIFIER")
	private String legalEntityIdentifier;

	@Column(name = "LEI_VALIDITY")
	private LocalDate leiValidity;

	@Column(name = "REFINANCE_APP_FILE_NAME")
	private String refinanceAppFileName;

	@Column(name = "REFINANCE_APP_FILE_PATH")
	private String refinanceAppFilePath;

	@Column(name = "AUTH_SIGN_FILE_NAME")
	private String authSignFileName;

	@Column(name = "AUTH_SIGN_FILE_PATH")
	private String authSignFilePath;

	@Column(name = "SUBMITTED_BY")
	private String submittedBy;

	@Column(name = "SUBMITTED_DATE_TIME")
	private LocalDateTime submittedDateTime;

	@CreationTimestamp
	@Column(name = "CREATED_DATE", updatable = false)
	private LocalDateTime createdDate;

	@Column(name = "RETURN_REMARKS")
	private String returnRemarks;

	@Column(name = "RETURN_BY")
	private String returnBy;

	@Column(name = "RETURN_DATE_TIME")
	private LocalDateTime returnDateTime;

	@Column(name = "SUBMIT_BY_EMAIL")
	private String submitByEmail;

}
