package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.entity.AppraisalMinutesDataEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.entity.SanctionMinutesDtlEntity;
import com.sidbi.ifv.enums.SanctionStageEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.repo.AppraisalMinutesDataRepository;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.repo.SanctionMinutesDtlRepository;
import com.sidbi.ifv.services.AppraisalMinutesDataService;

import jakarta.transaction.Transactional;

@Service
public class AppraisalMinutesDataServiceImpl implements AppraisalMinutesDataService {

	private static final Logger logger = LoggerFactory.getLogger(AppraisalMinutesDataServiceImpl.class);

	@Autowired
	private AppraisalMinutesDataRepository repository;

	@Autowired
	private SanctionMinutesDtlRepository sanctionMinutesDtlRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	String msg = "";

	@Override
	public AppraisalMinutesDataDTO findById(Long id) {
		return null;
	}

	@Override
	public List<AppraisalMinutesDataDTO> findAll() {
		return Collections.emptyList();
	}

	@Override
	public AppraisalMinutesDataDTO save(AppraisalMinutesDataDTO dto) {
		return null;
	}

	@Override
	public List<AppraisalMinutesDataDTO> saveAll(List<AppraisalMinutesDataDTO> dtos) {
		return Collections.emptyList();
	}

	@Override
	public AppraisalMinutesDataDTO update(Long id, AppraisalMinutesDataDTO dto) {
		return null;
	}

	@Override
	public void delete(Long id) {
		logger.info("delete");
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public Boolean saveAllAppraisalMinutesData(List<AppraisalMinutesDataDTO> data) {
		logger.info("saveAllAppraisalMinutesData() started in AppraisalMinutesDataServiceImpl");
		try {

			List<AppraisalMinutesDataEntity> entitiesToSave = data.stream()
					.map(dto -> mapper.map(dto, AppraisalMinutesDataEntity.class)).collect(Collectors.toList());

			Long sancDtlCode = data.stream().map(AppraisalMinutesDataDTO::getSancDtlCode).findFirst().orElse(null);

			entitiesToSave.forEach(e -> {
				e.setStatus(SanctionStageEnum.CR_MIN.getStatus());
				e.setCreatedDate(new Date());

			});

			Long prId = data.stream().map(AppraisalMinutesDataDTO::getPrId).findFirst().orElse(0L);

			S2IFVProposedSchemaEntity proposedSchemaEntity = proposedSchemaRepository.findByPrId(prId);

			List<S2IFVProposedSchemaEntity> entities = proposedSchemaRepository
					.findByIfvId(proposedSchemaEntity.getIfvId());

			if (entities.size() != data.size()) {
				logger.error("Error Occurred while Saving all AppraisalMinutesDataEntity");
				throw new DatabaseOperationException(
						"Error Occurred while saving minutes data. Kindly refresh the page and try again.");
			}

			repository.saveAll(entitiesToSave);

			SanctionMinutesDtlEntity existingEntity = sanctionMinutesDtlRepository.findBySancDtlCode(sancDtlCode);
			existingEntity.setSancStatus(SanctionStageEnum.CR_MIN.getStatus());
			sanctionMinutesDtlRepository.save(existingEntity);
			return true;

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all AppraisalMinutesDataEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all AppraisalMinutesDataEntity." + msg + " ", e);
		}
	}

	@Override
	public List<AppraisalMinutesDataDTO> getAllAppraisalMinutesDataBySancDtlCode(Long sancDtlCode) {
		logger.info("getAllAppraisalMinutesDataBySancDtlCode() started in AppraisalMinutesDataServiceImpl ");
		try {
			List<AppraisalMinutesDataEntity> dtlEntities = repository.findBySancDtlCode(sancDtlCode);
			if (!dtlEntities.isEmpty()) {

				return dtlEntities.stream().sorted(Comparator.comparing(AppraisalMinutesDataEntity::getId))
						.map(e -> mapper.map(e, AppraisalMinutesDataDTO.class)).collect(Collectors.toList());
			} else {
				return new ArrayList<>();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all AppraisalMinutesDataEntity based on sancDtlCode. {} {} ",
					sancDtlCode, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all AppraisalMinutesDataEntity  based on sancStatusCode." + msg + " ",
					e);

		}
	}

	@Override
	public List<AppraisalMinutesDataDTO> getAllAppraisalMinutesDataByAgendaIdAndAppId(String agendaId, String appId) {
		logger.info("getAllAppraisalMinutesDataByAgendaIdAndAppId() started in AppraisalMinutesDataServiceImpl ");
		try {
			List<AppraisalMinutesDataEntity> dtlEntities = repository.findByAgendaIdAndAppId(agendaId, appId);
			if (!dtlEntities.isEmpty()) {
				return dtlEntities.stream().sorted(Comparator.comparing(AppraisalMinutesDataEntity::getId))
						.map(e -> mapper.map(e, AppraisalMinutesDataDTO.class)).collect(Collectors.toList());
			} else {
				return new ArrayList<>();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while Finding all AppraisalMinutesDataEntity based on agendaId and appId. {} {} {}",
					agendaId, appId, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all AppraisalMinutesDataEntity  based on agendaId and appId." + msg
							+ " ",
					e);

		}
	}

	@Override
	public AppraisalMinutesDataDTO findBySancDtlCodeAppIdPrId(Long sancDtlCode, String appId, Long prId) {
		logger.info("findBySancDtlCodeAppIdPrId() started in AppraisalMinutesDataServiceImpl ");
		try {

			AppraisalMinutesDataEntity data = repository.findBySancDtlCodeAndAppIdAndPrId(sancDtlCode, appId, prId);

			return mapper.map(data, AppraisalMinutesDataDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while Finding all AppraisalMinutesDataEntity based on agendaId and appId. {} {} {}",
					sancDtlCode, appId, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all AppraisalMinutesDataEntity  based on agendaId and appId." + msg
							+ " ",
					e);

		}
	}

	@Override
	public List<AppraisalMinutesDataDTO> findByAgendaId(String agendaId) {
		logger.info("findByAgendaId() started in AppraisalMinutesDataServiceImpl ");
		try {
			List<AppraisalMinutesDataEntity> dtlEntities = repository.findByAgendaId(agendaId);
			if (!CollectionUtils.isEmpty(dtlEntities)) {
				return dtlEntities.stream().sorted(Comparator.comparing(AppraisalMinutesDataEntity::getId))
						.map(e -> mapper.map(e, AppraisalMinutesDataDTO.class)).collect(Collectors.toList());
			} else {
				return new ArrayList<>();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all AppraisalMinutesDataDTO based on agendaId. {} {}", agendaId,
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all AppraisalMinutesDataDTO  based on agendaId." + msg + " ", e);

		}
	}

}
