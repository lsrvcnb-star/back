package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AreasGeographicalDTO;
import com.sidbi.ifv.dto.CommonDTO;

public interface AreasGeographicalService {

	AreasGeographicalDTO findById(Long id);

	AreasGeographicalDTO save(AreasGeographicalDTO ifccApplicationDTO);

	AreasGeographicalDTO update(Long id, AreasGeographicalDTO s2IfccApplicationDTO);

	void delete(Long id);

	List<AreasGeographicalDTO> findAll();
	
	List<AreasGeographicalDTO> saveAll(List<AreasGeographicalDTO> listAreasGeographicalDTO);

	List<AreasGeographicalDTO> findAllByIfvId(Long ifvId);

	CommonDTO saveCommonDTO(CommonDTO commonDTO);

	CommonDTO findCommonDTOByIfvId(Long ifvId);
	
	CommonDTO findCommonDTOByIfvIdAndAgType(Long ifvId, String agType);
	
	List<AreasGeographicalDTO> findByIfvIdAndCtAgType(Long ifvId,String agType);

	void deleteGeographicalArea(Long id);
}
