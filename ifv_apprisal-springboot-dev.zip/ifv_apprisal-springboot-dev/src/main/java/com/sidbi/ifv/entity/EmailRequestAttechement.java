package com.sidbi.ifv.entity;

public class EmailRequestAttechement {
	
	private String recipient;
    private String msgBody;
    private String subject;
    private String attechement;
  
    
    
	public String getAttechement() {
		return attechement;
	}
	public void setAttechement(String attechement) {
		this.attechement = attechement;
	}
	public String getRecipient() {
		return recipient;
	}
	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}
	public String getMsgBody() {
		return msgBody;
	}
	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}


}
