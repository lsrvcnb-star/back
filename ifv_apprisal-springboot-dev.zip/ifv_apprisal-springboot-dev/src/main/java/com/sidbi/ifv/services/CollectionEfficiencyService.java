package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.CollectionEfficiencyDTO;

public interface CollectionEfficiencyService extends CrudService<CollectionEfficiencyDTO, Long> {

	List<CollectionEfficiencyDTO> findAllByIfvId(Long ifvId);

}
