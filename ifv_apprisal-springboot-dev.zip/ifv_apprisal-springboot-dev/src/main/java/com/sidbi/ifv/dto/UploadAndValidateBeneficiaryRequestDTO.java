package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class UploadAndValidateBeneficiaryRequestDTO {

	private String benRefNo;
	private String benPreDisbFlag;
	private String loanAccountNo;
	private String disbDate;
	private String remarks;
	private String submitBy;
	private String proceedWithBankUploadFile;

	private String jobId;
	private LocalDateTime refDate;

}
