package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryDetailsDTO {

	@JsonIgnore // Don't serialize row number in response
	private Integer rowNumber;

	private Long bbdSrNo;

	@NotBlank(message = "User ID is required")
	@Size(max = 50, message = "User ID must not exceed 50 characters")
	private String bbdUserId;

	@NotBlank(message = "State name is required")
	@Size(max = 60, message = "State name must not exceed 60 characters")
	private String bbdStateName;

	@NotBlank(message = "State code is required")
	@Size(max = 5, message = "State code must not exceed 5 characters")
	private String bbdStateCode;

	@Min(value = 0, message = "District code must be positive")
	@Max(value = 99, message = "District code must not exceed 99")
	private Integer bbdDistrictCode;

	@Size(max = 60, message = "Account of unit must not exceed 60 characters")
	private String bbdAcctOfUnit;

	@NotBlank(message = "Name of unit is required")
	@Size(max = 200, message = "Name of unit must not exceed 200 characters")
	private String bbdNameOfUnit;

	@Size(max = 2000, message = "Address must not exceed 2000 characters")
	private String bbdAddrOfUnit;

	@Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]{1}$|^$", message = "Invalid PAN format. Expected format: ABCDE1234F")
	@Size(max = 10, message = "PAN must be 10 characters")
	private String bbdPanOfUnit;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Past(message = "Date of birth/incorporation must be in the past")
	private LocalDate bbdDateOfBirthInc;

	@Size(max = 50, message = "URC number must not exceed 50 characters")
	private String bbdUrcNoOfUnit;

	@Min(value = 1000000000L, message = "Mobile number must be 10 digits")
	@Max(value = 9999999999L, message = "Mobile number must be 10 digits")
	private Long mobileNoLinkedUrc;

	@Size(max = 10, message = "New enterprise nos must not exceed 10 characters")
	private String newEnterpriseNos;

	@Size(max = 10, message = "Existing enterprise nos must not exceed 10 characters")
	private String existingEnterpriseNos;

	@Size(max = 2000, message = "Name of activity must not exceed 2000 characters")
	private String bbdNameOfActivity;

	@Min(value = 0, message = "SC category count must be non-negative")
	private Long bbdCateSc;

	@Min(value = 0, message = "ST category count must be non-negative")
	private Long bbdCateSt;

	@Min(value = 0, message = "WE category count must be non-negative")
	private Long bbdCateWe;

	@Min(value = 0, message = "MC category count must be non-negative")
	private Long bbdCateMc;

	@Min(value = 0, message = "General category count must be non-negative")
	private Long bbdCateGen;

	@Min(value = 0, message = "Micro manufacturing count must be non-negative")
	private Long bbdMicroMfgNos;

	@Min(value = 0, message = "Micro service count must be non-negative")
	private Long bbdMicroServiceNos;

	@Min(value = 0, message = "Small manufacturing count must be non-negative")
	private Long bbdSmallMfgNos;

	@Min(value = 0, message = "Small service count must be non-negative")
	private Long bbdSmallServiceNos;

	@Min(value = 0, message = "Medium manufacturing count must be non-negative")
	private Long bbdMediumMfgNos;

	@Min(value = 0, message = "Medium service count must be non-negative")
	private Long bbdMediumServiceNos;

	@Min(value = 0, message = "Microfinance borrower count must be non-negative")
	private Long bbdMicrofinanceBorrower;

	@Min(value = 0, message = "Employee general number must be non-negative")
	private Long bbdEmployeeGenNo;

	@DecimalMin(value = "0.0", inclusive = true, message = "TL loan sanctioned must be non-negative")
	@Digits(integer = 18, fraction = 2, message = "TL loan sanctioned must have max 18 digits and 2 decimal places")
	private BigDecimal bbdTlLoanSanc;

	@DecimalMin(value = "0.0", inclusive = true, message = "WC loan sanctioned must be non-negative")
	@Digits(integer = 18, fraction = 2, message = "WC loan sanctioned must have max 18 digits and 2 decimal places")
	private BigDecimal bbdWcLoanSanc;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@PastOrPresent(message = "Disbursement date must not be in the future")
	private LocalDate dateOfDisburseLoanDisb;

	@DecimalMin(value = "0.0", inclusive = true, message = "TL loan disbursed must be non-negative")
	@Digits(integer = 18, fraction = 2, message = "TL loan disbursed must have max 18 digits and 2 decimal places")
	private BigDecimal bbdTlLoanDisb;

	@DecimalMin(value = "0.0", inclusive = true, message = "WC loan disbursed must be non-negative")
	@Digits(integer = 18, fraction = 2, message = "WC loan disbursed must have max 18 digits and 2 decimal places")
	private BigDecimal bbdWcLoanDisb;

	@DecimalMin(value = "0.0", inclusive = true, message = "TL loan outstanding must be non-negative")
	@Digits(integer = 18, fraction = 2, message = "TL loan outstanding must have max 18 digits and 2 decimal places")
	private BigDecimal bbdTlLoanOs;

	@DecimalMin(value = "0.0", inclusive = true, message = "WC loan outstanding must be non-negative")
	@Digits(integer = 18, fraction = 2, message = "WC loan outstanding must have max 18 digits and 2 decimal places")
	private BigDecimal bbdWcLoanOs;

	@DecimalMin(value = "0.0", inclusive = true, message = "Rate of interest must be non-negative")
	@DecimalMax(value = "99.99", inclusive = true, message = "Rate of interest must not exceed 99.99")
	@Digits(integer = 2, fraction = 2, message = "Rate of interest must have max 2 digits and 2 decimal places")
	private BigDecimal bbdRateOfInterestChng;

	@Min(value = 0, message = "Processing fee must be non-negative")
	private Long bbdProcessingFee;

	@DecimalMin(value = "0.0", inclusive = true, message = "Refinance claimed must be non-negative")
	@Digits(integer = 18, fraction = 2, message = "Refinance claimed must have max 18 digits and 2 decimal places")
	private BigDecimal bbdRefinanceClmd;

	@Pattern(regexp = "^[YN]$|^$", message = "Backend flag must be 'Y' or 'N'")
	private String bbdBackendFlag;

	@Size(max = 8, message = "Account number must not exceed 8 characters")
	private String acctNo;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@PastOrPresent(message = "Disbursement date must not be in the future")
	private LocalDate disbDt;

	@Size(max = 30, message = "Reference number must not exceed 30 characters")
	private String refNo;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@PastOrPresent(message = "Reference date must not be in the future")
	private LocalDate refDate;
}
