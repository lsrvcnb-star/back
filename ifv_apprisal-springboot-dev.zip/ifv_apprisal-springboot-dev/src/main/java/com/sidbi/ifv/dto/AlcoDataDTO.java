package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class AlcoDataDTO {

	private Long dtCode;

	private Long ifvId;

	private String dtAppl;

	private String dtBankname;

	private BigDecimal dtAmount;

	private String dtScheme;

	private BigDecimal dtPeriod;

	private BigDecimal dtRoi;

	private BigDecimal dtCostOfFunds;

	private BigDecimal dtSpeedmargin;

	private String dtPrinicipalRep;

	private Date dateOfAction;

	private Long alCode;

	private String fundCode;

	private Long prId;

	private String schemeCode;
}
