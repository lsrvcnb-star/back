package com.sidbi.ifv.exception;

import org.springframework.security.core.AuthenticationException;

public class UserDisabledException extends AuthenticationException {
	private static final long serialVersionUID = 1L;

	public UserDisabledException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public UserDisabledException(String msg) {
		super(msg);
	}
}
