package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "disclosure_divergence_details")
public class DisclosureDivergenceEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "particulars")
	private String particulars;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "dis_type")
	private String disType;

	@Column(name = "remarks")
	private String remarks;

}