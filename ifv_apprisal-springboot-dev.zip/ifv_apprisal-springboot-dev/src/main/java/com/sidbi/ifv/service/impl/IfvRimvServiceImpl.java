package com.sidbi.ifv.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.dto.IfvRimvAppDto;
import com.sidbi.ifv.dto.IfvRimvAppForwardDto;
import com.sidbi.ifv.dto.IfvRimvDocDto;
import com.sidbi.ifv.dto.RimvValidatedRequestDto;
import com.sidbi.ifv.entity.IfvRimvApp;
import com.sidbi.ifv.entity.IfvRimvDoc;
import com.sidbi.ifv.enums.FileModule;
import com.sidbi.ifv.enums.FileSubModuleEnum;
import com.sidbi.ifv.enums.RiMVStatusFlagEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.exception.ExternalServiceException;
import com.sidbi.ifv.repo.IfvRimvAppRepo;
import com.sidbi.ifv.repo.IfvRimvDocRepo;
import com.sidbi.ifv.services.IfvRimvService;
import com.sidbi.ifv.services.RimvServiceClient;
import com.sidbi.ifv.util.FileUploadUtility;
import com.sidbi.ifv.util.GenericSpecification;

import feign.FeignException;
import feign.RetryableException;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Service
@Log4j2
public class IfvRimvServiceImpl implements IfvRimvService {

	private final IfvRimvDocRepo ifvRimvDocRepo;
	private final IfvRimvAppRepo ifvRimvAppRepo;
	private final ModelMapper mapper;
	private final FileUploadUtility fileUploadUtility;

	@Autowired
	private RimvServiceClient rimvServiceClient;

	String msg = "";

	@Override
	public Map<String, Long> getCountOfRimvApps() {
		log.info("getCountOfRimvApps called");

		try {
			Map<String, Long> statusCountMap = new LinkedHashMap<>();

			statusCountMap.put(RiMVStatusFlagEnum.CREATED.getShortName(), 0L);
			statusCountMap.put(RiMVStatusFlagEnum.PENDING.getShortName(), 0L);
			statusCountMap.put(RiMVStatusFlagEnum.REJECTED.getShortName(), 0L);
			statusCountMap.put(RiMVStatusFlagEnum.APPROVED.getShortName(), 0L);

			List<Object[]> results = ifvRimvAppRepo.countAppsByStatus();

			for (Object[] row : results) {
				String statusCode = (String) row[0];
				Long count = (Long) row[1];

				if (RiMVStatusFlagEnum.CREATED.getShortName().equals(statusCode)) {
					statusCountMap.put(RiMVStatusFlagEnum.CREATED.getShortName(), count);
				} else if (RiMVStatusFlagEnum.PENDING.getShortName().equals(statusCode)) {
					statusCountMap.put(RiMVStatusFlagEnum.PENDING.getShortName(), count);
				} else if (RiMVStatusFlagEnum.REJECTED.getShortName().equals(statusCode)) {
					statusCountMap.put(RiMVStatusFlagEnum.REJECTED.getShortName(), count);
				} else if (RiMVStatusFlagEnum.APPROVED.getShortName().equals(statusCode)) {
					statusCountMap.put(RiMVStatusFlagEnum.APPROVED.getShortName(), count);
				}
			}

			return statusCountMap;

		} catch (Exception e) {
			log.error("Error fetching getCountOfRimvApps list", e);
			throw new DatabaseOperationException("Error fetching getCountOfRimvApps", e);
		}
	}

	@Override
	public Page<IfvRimvAppDto> fetchIfvRimvApps(Pageable pageable, String filters, String sorting,
			String globalFilter) {

		log.info("fetchIfvRimvApps called | Page: {} Size: {}", pageable.getPageNumber(), pageable.getPageSize());

		try {
			Specification<IfvRimvApp> spec = new GenericSpecification<>(filters);

			if (StringUtils.hasText(globalFilter)) {
				spec = spec.and(globalSearchSpecification(globalFilter));
			}

			Pageable pageableWithSort = applySorting(pageable, sorting);

			Page<IfvRimvApp> entityPage = ifvRimvAppRepo.findAll(spec, pageableWithSort);

			log.info("Fetched {} IfvRimvApps records", entityPage.getTotalElements());

			return entityPage.map(entity -> mapper.map(entity, IfvRimvAppDto.class));

		} catch (Exception e) {
			log.error("Error fetching IfvRimvApps list", e);
			throw new DatabaseOperationException("Error fetching IfvRimvApps list", e);
		}
	}

	private Specification<IfvRimvApp> globalSearchSpecification(String globalFilter) {

		return (root, query, cb) -> {
			String likePattern = "%" + globalFilter.toLowerCase() + "%";

			return cb.or(cb.like(cb.lower(root.get("rimvRefId")), likePattern),
					cb.like(cb.lower(root.get("cifNumber")), likePattern),
					cb.like(cb.lower(root.get("bankName")), likePattern));
		};
	}

	@Override
	public boolean saveIfvRimvApp(IfvRimvAppDto request) {

		if (request == null) {
			log.error("saveIfvRimvApp failed: Request DTO is null");
			throw new IllegalArgumentException("Request data cannot be null");
		}

		log.info("saveIfvRimvApp started for CIF: {}", request.getCifNumber());

		try {

			request.setFwdStatus(RiMVStatusFlagEnum.CREATED.getShortName());
			int nextAppId = getNextAppIdForCurrentFinancialYear();
			String appNo = createIfvRimvAppNo(nextAppId);
			request.setRimvRefId(appNo);
			request.setCreatedDateTime(LocalDateTime.now());

			IfvRimvApp entity = mapper.map(request, IfvRimvApp.class);
			ifvRimvAppRepo.save(entity);

			log.info("saveIfvRimvApp completed successfully for CIF: {}", request.getCifNumber());
			return true;

		} catch (IllegalArgumentException e) {
			log.error("Validation failure during save for CIF: {} | {}", request.getCifNumber(), e.getMessage(), e);
			throw e;

		} catch (Exception e) {
			log.error("Unexpected error while saving IfvRimvApp for CIF: {}", request.getCifNumber(), e);
			throw new DatabaseOperationException("Unexpected error while saving IfvRimvApp", e);
		}

	}

	public int getNextAppIdForCurrentFinancialYear() {
		log.info("Getting next app ID for current financial year");

		LocalDateTime now = LocalDateTime.now(ZoneId.of("Asia/Kolkata"));
		int currentMonth = now.getMonthValue();
		int currentYear = now.getYear();

		LocalDateTime financialYearStart;
		if (currentMonth >= 4) {
			financialYearStart = LocalDateTime.of(currentYear, 4, 1, 0, 0, 0);
		} else {
			financialYearStart = LocalDateTime.of(currentYear - 1, 4, 1, 0, 0, 0);
		}

		log.info("Financial year start date: {}", financialYearStart);

		// Find the latest application number created after financial year start
		String latestAppNo = ifvRimvAppRepo.findLatestAppNoFromDate(financialYearStart);

		log.info("Latest application number found: {}", latestAppNo);

		if (latestAppNo == null || latestAppNo.isEmpty()) {
			log.info("No applications found in current financial year, starting from 1");
			return 1;
		}

		// Extract the last 4 digits from the application number
		String numberPart = latestAppNo.substring(latestAppNo.length() - 4);
		int nextId = Integer.parseInt(numberPart) + 1;

		log.info("Next application ID will be: {}", nextId);
		return nextId;
	}

	public String createIfvRimvAppNo(int appId) {
		log.info("Started createIfvRimvAppNo() with appId: {}", appId);
		try {

			String prefix = "IFVRIMV";
			LocalDate now = LocalDate.now(ZoneId.of("Asia/Kolkata"));
			int year = now.getYear() % 100;
			int month = now.getMonthValue();

			String yearStr = (month >= 4) ? "F" + (year + 1) : String.valueOf(year);
			String id = String.format("%04d", appId);
			String appNo = prefix + yearStr + id;

			log.info("Generated application number: {}", appNo);
			return appNo;

		} catch (Exception e) {
			msg = e.getMessage();
			log.error("Error occurred while creating IfvRimvAppNo: {}", msg, e);
			throw new DatabaseOperationException("Error occurred while creating IfvRimvAppNo: " + msg, e);
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean deleteIfvRimvApp(Long id) {

		log.info("Started deleteIfvRimvApp() with appId: {}", id);

		try {

			if (!ifvRimvAppRepo.existsById(id)) {
				return false;
			}

			List<IfvRimvDoc> docs = ifvRimvDocRepo.findAllByIfvRimvAppId(id);

			ifvRimvDocRepo.deleteAllByIfvRimvAppId(id);

			ifvRimvAppRepo.deleteById(id);

			docs.forEach(doc -> {
				try {
					fileUploadUtility.deleteFile(doc.getFilePath());
				} catch (Exception ex) {
					log.error("Failed to delete file: {}", doc.getFilePath(), ex);
				}
			});

			return true;

		} catch (Exception e) {
			log.error("Error occurred while deleting IfvRimvApp: {}", e.getMessage(), e);
			throw new DatabaseOperationException("Error occurred while deleting IfvRimvApp: " + e.getMessage(), e);
		}
	}

	@Override
	public List<IfvRimvDocDto> getAllDocsOnIfvRimvAppId(Long ifvRimvAppId) {
		try {
			return ifvRimvDocRepo.findAllByIfvRimvAppId(ifvRimvAppId).stream().map(this::convertToDto)
					.collect(Collectors.toList());
		} catch (Exception e) {
			log.error("Error occurred while fetching IfvRimvDoc for ifvRimvAppId: {}", ifvRimvAppId, e);
			throw new DatabaseOperationException(
					"Error retrieving IfvRimvDoc for ifvRimvAppId: " + ifvRimvAppId + " | " + e.getMessage());
		}
	}

	private IfvRimvDocDto convertToDto(IfvRimvDoc entity) {
		return mapper.map(entity, IfvRimvDocDto.class);
	}

	private IfvRimvAppDto convertAppToDto(IfvRimvApp entity) {
		return mapper.map(entity, IfvRimvAppDto.class);
	}

	@Override
	public IfvRimvDocDto uploadRimvDocument(MultipartFile file, Long ifvRimvAppId, String remarks) {
		if (file == null || file.isEmpty()) {
			throw new IllegalArgumentException("File cannot be null or empty");
		}

		try {
			String fileName = file.getOriginalFilename();
			if (fileName == null || fileName.isBlank()) {
				throw new IllegalArgumentException("File name is invalid");
			}

			IfvRimvApp ifvRimvApp = ifvRimvAppRepo.findById(ifvRimvAppId)
					.orElseThrow(() -> new EntityNotFoundException("IfvRimvApps", ifvRimvAppId));

			String uploadedFilePath = fileUploadUtility.uploadFile(file.getBytes(), fileName, FileModule.IFV_RIMV,
					FileSubModuleEnum.RIMV_DOCS, ifvRimvApp.getRimvRefId());
			log.info("File uploaded successfully to: {} for ifvRimvAppId: {}", uploadedFilePath, ifvRimvAppId);

			IfvRimvDoc entity = new IfvRimvDoc();
			entity.setFileModule(FileModule.IFV_RIMV.getFolderName());
			entity.setFileSubModule(FileSubModuleEnum.RIMV_DOCS.getFolderName());
			entity.setIfvRimvAppId(ifvRimvAppId);
			entity.setFileName(fileName);
			entity.setFileType(file.getContentType());
			entity.setFilePath(uploadedFilePath);
			entity.setUploadedDateTime(LocalDateTime.now());
			entity.setRemarks(remarks);
			IfvRimvDoc savedEntity = ifvRimvDocRepo.save(entity);
			return convertToDto(savedEntity);

		} catch (Exception e) {
			log.error("Error occurred while uploading document for ifvRimvAppId: {}", ifvRimvAppId, e);
			throw new DatabaseOperationException(
					"Error uploading document for ifvRimvAppId: " + ifvRimvAppId + " | " + e.getMessage());
		}
	}

	@Override
	public IfvRimvDocDto findById(Long documentId) {
		log.info("findById() started in IfvRimvServiceImpl for documentId: {}", documentId);
		try {
			IfvRimvDoc entity = ifvRimvDocRepo.findById(documentId)
					.orElseThrow(() -> new EntityNotFoundException("IfvRimvDocs", IfvRimvDoc.class));
			return convertToDto(entity);
		} catch (Exception e) {
			log.error("Error occurred while fetching document for documentId: {}", documentId, e);
			throw new DatabaseOperationException(
					"Error fetching document for documentId: " + documentId + " | " + e.getMessage());
		}
	}

	@Override
	public void deleteRimvDocument(Long documentId) {
		log.info("deleteRimvDocument() started in IfvRimvServiceImpl for documentId: {}", documentId);
		try {
			IfvRimvDoc entity = ifvRimvDocRepo.findById(documentId)
					.orElseThrow(() -> new EntityNotFoundException("IfvRimvDoc", IfvRimvDoc.class));
			fileUploadUtility.deleteFile(entity.getFilePath());
			ifvRimvDocRepo.delete(entity);
			log.info("Document deleted successfully for documentId: {}", documentId);
		} catch (Exception e) {
			log.error("Error occurred while deleting document for documentId: {}", documentId, e);
			throw new DatabaseOperationException(
					"Error deleting document for documentId: " + documentId + " | " + e.getMessage());
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean forwardDocumentsToRimv(IfvRimvAppForwardDto dto) {

		Long ifvRimvAppId = dto.getIfvRimvAppId();
		log.info("forwardDocumentsToRimv() started for ifvRimvAppId: {}", ifvRimvAppId);

		try {
			IfvRimvApp app = ifvRimvAppRepo.findById(ifvRimvAppId)
					.orElseThrow(() -> new EntityNotFoundException("IfvRimvApp", ifvRimvAppId));

			List<IfvRimvDoc> docs = ifvRimvDocRepo.findAllByIfvRimvAppId(ifvRimvAppId);
			if (docs.isEmpty()) {
				throw new EntityNotFoundException("IfvRimvDoc", ifvRimvAppId);
			}

			app.setFwdStatus(RiMVStatusFlagEnum.PENDING.getShortName());
			app.setForwardedDateTime(LocalDateTime.now());
			app.setFwdComments(dto.getFwdComments());
			app.setFwdUserId(dto.getFwdUserId());
			app.setFwdBy(dto.getFwdBy());
			ifvRimvAppRepo.save(app);

			IfvRimvAppDto appDto = convertAppToDto(app);
			appDto.setIfvRimvDocs(docs.stream().map(this::convertToDto).collect(Collectors.toList()));

			boolean isSent = rimvServiceClient.forwardDocumentsToRimv(appDto);
			if (!isSent) {
				throw new IllegalStateException("RIMV service responded with failure");
			}

			return true;

		} catch (RetryableException ex) {
			log.error("RIMV service not reachable for appId {}", ifvRimvAppId, ex);
			throw new ExternalServiceException("RIMV service is unavailable. Please try again later.", ex);
		} catch (FeignException ex) {
			log.error("RIMV service error response for appId {}", ifvRimvAppId, ex);
			throw new ExternalServiceException("RIMV service error: " + ex.getMessage(), ex);
		} catch (EntityNotFoundException ex) {
			log.error("Entity not found while forwarding ifvRimvAppId {}", ifvRimvAppId, ex);
			throw ex;
		} catch (Exception ex) {
			log.error("Unexpected error forwarding documents for ifvRimvAppId {}", ifvRimvAppId, ex);
			throw new DatabaseOperationException("Error forwarding documents for ifvRimvAppId: " + ifvRimvAppId, ex);
		}
	}

	@Override
	public Page<IfvRimvAppForwardDto> fetchIfvRimvDocsGrouped(int page, int size) {
		return null;
	}

	@Override
	public boolean updateIfvRimvDocsStatus(RimvValidatedRequestDto dto) {
		final Long ifvRimvAppId = dto != null ? dto.getIfvRimvAppId() : null;
		log.info("updateIfvRimvDocsStatus() started for ifvRimvAppId: {}", ifvRimvAppId);

		try {
			if (ifvRimvAppId == null) {
				throw new IllegalArgumentException("ifvRimvAppId must not be null.");
			}

			String rimvStatus = dto.getRimvStatus();
			if (rimvStatus == null || rimvStatus.isBlank()) {
				throw new IllegalArgumentException("RIMV status must not be null or blank.");
			}

			String fwdStatus;
			switch (rimvStatus.trim().toUpperCase()) {
			case "RJ":
				fwdStatus = "R";
				break;
			case "AP":
				fwdStatus = "A";
				break;
			default:
				throw new IllegalArgumentException("Unsupported RIMV status: " + rimvStatus);
			}

			IfvRimvApp ifvRimvApp = ifvRimvAppRepo.findById(ifvRimvAppId)
					.orElseThrow(() -> new EntityNotFoundException("IfvRimvApp", ifvRimvAppId));

			ifvRimvApp.setFwdStatus(fwdStatus);
			ifvRimvApp.setRimvComments(dto.getRimvComments());
			ifvRimvApp.setRimvFilePath(dto.getRimvFilePath());
			ifvRimvApp.setRimvUpdatedDateTime(LocalDateTime.now());
			ifvRimvApp.setSingleScaleRating(dto.getSingleScaleRating());
			ifvRimvApp.setCombinedRating(dto.getCombinedRating());

			ifvRimvAppRepo.save(ifvRimvApp);

			log.info("Documents updated successfully for ifvRimvAppId: {}", ifvRimvAppId);
			return true;

		} catch (EntityNotFoundException ex) {
			log.error("No documents found for ifvRimvAppId: {}", ifvRimvAppId, ex);
			throw ex;
		} catch (IllegalArgumentException ex) {
			log.error("Validation error for ifvRimvAppId: {} | {}", ifvRimvAppId, ex.getMessage(), ex);
			throw ex;
		} catch (Exception e) {
			log.error("Error occurred while updating documents for ifvRimvAppId: {}", ifvRimvAppId, e);
			throw new DatabaseOperationException(
					"Error updating documents for ifvRimvAppId: " + ifvRimvAppId + " | " + e.getMessage(), e);
		}
	}

	private Pageable applySorting(Pageable pageable, String sorting) {

		if (!StringUtils.hasText(sorting) || "[]".equals(sorting.trim())) {
			return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("id").descending());
		}

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(sorting);

			if (rootNode.isArray()) {

				if (rootNode.isEmpty()) {
					return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("id").descending());
				}

				JsonNode sortNode = rootNode.get(0);

				String field = sortNode.path("id").asText(null);
				Boolean isDesc = sortNode.path("desc").asBoolean(false);

				if (field == null) {
					log.warn("Sorting JSON missing 'id': {}", sorting);
					return pageable;
				}

				Sort sort = isDesc ? Sort.by(field).descending() : Sort.by(field).ascending();

				return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
			}

			String field = rootNode.path("id").asText(null);
			boolean isDesc = rootNode.path("desc").asBoolean(false);

			if (field == null) {
				log.warn("Sorting JSON missing 'id': {}", sorting);
				return pageable;
			}

			Sort sort = isDesc ? Sort.by(field).descending() : Sort.by(field).ascending();

			return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);

		} catch (Exception e) {
			log.warn("Invalid sorting JSON received: {}", sorting, e);
			return pageable;
		}
	}

}
