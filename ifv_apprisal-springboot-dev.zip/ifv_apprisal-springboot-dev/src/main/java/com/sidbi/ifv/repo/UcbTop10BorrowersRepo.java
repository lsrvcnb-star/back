package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.UcbTop10BorrowersEntity;

public interface UcbTop10BorrowersRepo extends JpaRepository<UcbTop10BorrowersEntity, Long> {

	List<UcbTop10BorrowersEntity> findByIfvId(Long ifvId);

}
