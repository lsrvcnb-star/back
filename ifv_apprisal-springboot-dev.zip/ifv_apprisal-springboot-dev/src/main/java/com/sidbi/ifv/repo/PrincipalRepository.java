package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVPrincipalEntity;

public interface PrincipalRepository extends JpaRepository<S2IFVPrincipalEntity, Long> {

	List<S2IFVPrincipalEntity> findByIfvId(Long ifvId);

	void deleteByPrId(Long prId);

	S2IFVPrincipalEntity findByIfvIdAndPrId(Long ifvId, Long prId);

}