package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TriggerResponseDto {
	private String status;
	private String jobId;
}
