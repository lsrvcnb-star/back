package com.sidbi.ifv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Import;

import com.sidbi.ifv.config.AppConfig;

@SpringBootApplication
@EnableFeignClients
@Import(AppConfig.class)
public class Api1Application extends SpringBootServletInitializer {
	public static void main(String[] args) {
		SpringApplication.run(Api1Application.class, args);
	}
}