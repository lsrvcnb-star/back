package com.sidbi.ifv.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVEligibilityEntity;

public interface EligibilityRepository extends JpaRepository< S2IFVEligibilityEntity, Long>{

	Optional<S2IFVEligibilityEntity> findByIfvId(Long ifvId);
	
	S2IFVEligibilityEntity getByIfvId(Long ifvId);
}
