package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sidbi.ifv.entity.TblIfvModuleFwdEntity;

public interface TblIfvModuleFwdRepository extends JpaRepository<TblIfvModuleFwdEntity, Long> {

	TblIfvModuleFwdEntity findByIfvId(Long id);

	@Query(value = "select * from TBL_IFV_MODULE_FWD where APP_STATUS =:appStatus and IFV_ID is not null ", nativeQuery = true)
	List<TblIfvModuleFwdEntity> findAllByAppStatusAndIfvId(String appStatus);

	@Query(value = "select * from TBL_IFV_MODULE_FWD where APP_STATUS =:appStatus and AL_CODE is not null ", nativeQuery = true)
	List<TblIfvModuleFwdEntity> findAllByAppStatusAndAlCode(String appStatus);

	TblIfvModuleFwdEntity findByAlCode(Long alCode);

	List<TblIfvModuleFwdEntity> findByIfvIdIn(List<Long> ids);

	List<TblIfvModuleFwdEntity> findByAlCodeIn(List<Long> ids);

}