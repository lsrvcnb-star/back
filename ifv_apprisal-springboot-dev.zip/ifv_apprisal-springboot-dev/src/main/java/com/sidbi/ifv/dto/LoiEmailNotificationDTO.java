package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class LoiEmailNotificationDTO {

	private String bankName;

	private String appRefNo;

	private String loiNo;

	private String bankEmailId;
}
