package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.SanctionStatusDTO;
import com.sidbi.ifv.entity.SanctionStatusEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.SanctionStatusRepository;
import com.sidbi.ifv.services.SanctionStatusService;

@Service
public class SanctionStatusServiceImpl implements SanctionStatusService {

	private static final Logger logger = LoggerFactory.getLogger(SanctionStatusServiceImpl.class);

	@Autowired
	private SanctionStatusRepository repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public SanctionStatusDTO findById(Long id) {
		logger.info("findById() started in SanctionStatusServiceImpl for SanctionStatusEntity {} ", id);
		SanctionStatusEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("sanctionStatusEntity", id));
		return mapper.map(entity, SanctionStatusDTO.class);
	}

	@Override
	public List<SanctionStatusDTO> findAll() {
		logger.info("findAll() started in SanctionStatusServiceImpl of SanctionStatusEntity");
		try {
			List<SanctionStatusEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, SanctionStatusDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all SanctionStatusEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all SanctionStatusEntities ." + msg + " ", e);
		}
	}

	@Override
	public SanctionStatusDTO save(SanctionStatusDTO dto) {
		logger.info("save() started in SanctionStatusServiceImpl for SanctionStatusEntity {} ", dto);
		try {
			SanctionStatusEntity entity = mapper.map(dto, SanctionStatusEntity.class);
			repository.save(entity);
			return mapper.map(entity, SanctionStatusDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating SanctionStatusEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  SanctionStatusEntity." + msg + " ", e);
		}
	}

	@Override
	public List<SanctionStatusDTO> saveAll(List<SanctionStatusDTO> dtos) {
		logger.info("saveAll() started in SanctionStatusServiceImpl for List of SanctionStatusEntity");
		try {

			List<SanctionStatusEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, SanctionStatusEntity.class)).collect(Collectors.toList());
			List<SanctionStatusEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, SanctionStatusDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all SanctionStatusEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all SanctionStatusEntities." + msg + " ",
					e);
		}
	}

	@Override
	public SanctionStatusDTO update(Long id, SanctionStatusDTO dto) {
		logger.info("update() started in SanctionStatusServiceImpl for SanctionStatusEntity {} {} ", id, dto);
		try {
			SanctionStatusEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("SanctionStatusEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, SanctionStatusDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating SanctionStatusEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating SanctionStatusEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in SanctionStatusServiceImpl for SanctionStatusEntity {} ", id);
		try {
			SanctionStatusEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("SanctionStatusEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting SanctionStatusEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting SanctionStatusEntity of id ." + msg + " " + id, e);
		}

	}

}
