package com.sidbi.ifv.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sidbi.ifv.config.FeignConfig;
import com.sidbi.ifv.dto.AcceptReturnComplianceRequestDto;
import com.sidbi.ifv.dto.BankPortalApiResponse;
import com.sidbi.ifv.dto.BeneficiaryDocsResponse;
import com.sidbi.ifv.dto.BeneficiarySummaryResponse;
import com.sidbi.ifv.dto.ComplianceResponseDto;
import com.sidbi.ifv.dto.ComplianceStatusSummaryRequest;
import com.sidbi.ifv.dto.ComplianceStatusSummaryResponse;
import com.sidbi.ifv.dto.FetchBeneficiaryRequest;
import com.sidbi.ifv.dto.ReturnBankForwardedDocumentRequest;

@FeignClient(name = "bank-portal", url = "${bankportal.service.url}", configuration = FeignConfig.class)
public interface BankPortalClient {

	@PostMapping("/beneficiary/fetchBeneficiaryDataForIfv")
	ResponseEntity<Page<BeneficiarySummaryResponse>> fetchBeneficiaryDataFromService(
			@RequestBody FetchBeneficiaryRequest request);

	@PostMapping("/beneficiary/fetchBeneficiaryDocsByCif")
	ResponseEntity<Page<BeneficiaryDocsResponse>> fetchBeneficiaryDocsByCif(
			@RequestBody FetchBeneficiaryRequest request);

	@PostMapping("/beneficiary/returnForwardedApplication")
	ResponseEntity<BankPortalApiResponse<String>> returnForwardedApplication(
			@RequestBody ReturnBankForwardedDocumentRequest request);

	@PostMapping("/refinance-app/returnBankApplication")
	ResponseEntity<BankPortalApiResponse<String>> returnBankApplication(
			@RequestBody ReturnBankForwardedDocumentRequest request);

	@PostMapping("/refinance-app/status/in-progress")
	ResponseEntity<BankPortalApiResponse<String>> updateAppStatusToInProgress(List<String> bankAppRefNos);

	@PostMapping("/compliance-status/fetchComplianceSummaryForAllBanks")
	ResponseEntity<Page<ComplianceStatusSummaryResponse>> fetchComplianceSummaryForAllBanks(
			ComplianceStatusSummaryRequest request);

	@PostMapping("/compliance-status/acceptOrReturnCompliance")
	ResponseEntity<ComplianceResponseDto> acceptOrReturnCompliance(
			@RequestBody AcceptReturnComplianceRequestDto request);

	@PostMapping("/compliance-status/createCompliances")
	ResponseEntity<String> createCompliances(List<String> appRefIds);

}
