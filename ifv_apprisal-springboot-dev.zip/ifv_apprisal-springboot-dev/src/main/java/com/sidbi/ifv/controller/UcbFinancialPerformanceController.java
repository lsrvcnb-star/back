package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.UcbFinancialPerformanceDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.UcbFinancialPerformanceService;

@RestController
@CrossOrigin
@RequestMapping("/ucb-financial-performance")
public class UcbFinancialPerformanceController extends CrudController<UcbFinancialPerformanceDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(UcbFinancialPerformanceController.class);

	@Autowired
	private UcbFinancialPerformanceService service;

	@Override
	public CrudService<UcbFinancialPerformanceDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<UcbFinancialPerformanceDTO>> getUcbFincOnIfvId(@PathVariable Long ifvId) {
		logger.info("getUcbFincOnIfvId() started in UcbFinancialPerformanceController ");
		List<UcbFinancialPerformanceDTO> dtos = service.findAllByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}
}