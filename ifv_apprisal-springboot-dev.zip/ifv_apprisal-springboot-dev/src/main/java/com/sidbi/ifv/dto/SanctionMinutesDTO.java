package com.sidbi.ifv.dto;

import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class SanctionMinutesDTO {

	private Long sanctDetailCode;

	private String agendaId;

	private Integer commiteeCode;

	private Date meetingDate;

	private String sanctStage;

	private String meetingPlace;

	private String agendaCreatedBy;

	private String reportingOfficer;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

	private String convenorCode;

	private String alConvenorCode;

	private String memberCode;

	private Integer meetingNo;

	private String chairmanCode;

	private String grantLeaves;

	private String note1;

	private String note2;

	private String flashNote;

	private String createdModifiedUser;

	private String forwardedStage1User;

	private String forwardedStage2User;

	private LocalDateTime forwardedStage1DateTime;

	private LocalDateTime forwardedStage2DateTime;

	private String currentUserEmpId;

	private String benchmarkNote;

	private Long currentCheckerId;

	private String remarks;
}
