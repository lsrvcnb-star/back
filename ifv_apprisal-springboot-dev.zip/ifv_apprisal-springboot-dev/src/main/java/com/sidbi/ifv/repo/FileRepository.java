package com.sidbi.ifv.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.S2IFVFileRepositoryEntity;

public interface FileRepository extends JpaRepository<S2IFVFileRepositoryEntity, Long> {

	List<S2IFVFileRepositoryEntity> findAllBySancMinDetailIdIn(List<Long> sancMinDetailIds);

	@Query("from S2IFVFileRepositoryEntity where fileModule is null and sancMinDetailId =:sancMinDetailId")
	Optional<S2IFVFileRepositoryEntity> findBySancMinDetailIdAndFileModule(
			@Param("sancMinDetailId") Long sancMinDetailId);

	Optional<S2IFVFileRepositoryEntity> findBySancMinDetailIdAndFileModule(Long sancMinDetailId, String module);

	S2IFVFileRepositoryEntity findByFileIfvId(Long ifvId);

	S2IFVFileRepositoryEntity findByFileAlcoId(Long alcoId);

	Optional<S2IFVFileRepositoryEntity> findByFileIfvIdAndFileModule(Long fileIfvId, String fileModule);

	Optional<S2IFVFileRepositoryEntity> findByFileCode(Long id);

	S2IFVFileRepositoryEntity findByFileModule(String module);

	@Query("from S2IFVFileRepositoryEntity where fileModule is null and fileIfvId =:fileIfvId")
	Optional<S2IFVFileRepositoryEntity> findByFileIfvIdAndFileModule(@Param("fileIfvId") Long fileIfvId);

	Optional<S2IFVFileRepositoryEntity> findByLoiId(Long id);

	Optional<S2IFVFileRepositoryEntity> findByPropLoiId(Long id);
}
