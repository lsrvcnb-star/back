package com.sidbi.ifv.controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.IfvLoginRequest;
import com.sidbi.ifv.model.JwtResponse;
import com.sidbi.ifv.service.impl.IfvAuthenticationService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("auth")
@RequiredArgsConstructor
public class JwtAuthenticationController {

	private final IfvAuthenticationService authService;

	@GetMapping("/getCaptcha")
	public ResponseEntity<Map<String, String>> getCaptcha() {
		return ResponseEntity.ok(authService.generateCaptcha());
	}

	@PostMapping("/ifvLogin")
	public ResponseEntity<JwtResponse> ifvLogin(@Valid @RequestBody IfvLoginRequest request) {

		JwtResponse response = authService.login(request);
		return ResponseEntity.ok(response);
	}

	@PostMapping("/ssoIfvLogin")
	public ResponseEntity<JwtResponse> ssoIfvLogin(@RequestParam String username) {

		JwtResponse response = authService.ssoLogin(username);
		return ResponseEntity.ok(response);
	}
}
