package com.sidbi.ifv.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.DFSErrorLog;

public interface DFSErrorLogRepo extends JpaRepository<DFSErrorLog, Long> {

}
