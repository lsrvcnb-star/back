package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AlcoMinutesDataDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.SanctionMinutesDtlDTO;

public interface SanctionMinutesDtlService extends CrudService<SanctionMinutesDtlDTO, Long> {
	
	List<SanctionMinutesDtlDTO> findBySanctStatusCode(Long sanctStatusCode,CommonDTO commonDTO);

	Long circulateAgenda(Long sancMinDtlId);

	Boolean saveAllAlcoMinutesData(List<AlcoMinutesDataDTO> data);

	List<AlcoMinutesDataDTO> getAllAlcoMinutesDataBySancDtlCode(Long sancDtlCode);
	
}
