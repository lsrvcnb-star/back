package com.sidbi.ifv.repo;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;

public interface ProposedSchemaRepository extends JpaRepository<S2IFVProposedSchemaEntity, Long> {

	List<S2IFVProposedSchemaEntity> findByIfvId(Long ifvId);

	S2IFVProposedSchemaEntity findByPrId(Long prId);

	@Query(value = "SELECT p FROM S2IFVProposedSchemaEntity p INNER JOIN S2IFVApplicationEntity a ON p.ifvId = a.ifvId WHERE a.appNumber = :appId")
	List<S2IFVProposedSchemaEntity> findByAppNo(@Param("appId") String appId);

	List<S2IFVProposedSchemaEntity> findAllByIfvIdIn(Set<Long> sIfvIds);

}
