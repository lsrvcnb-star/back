package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.RatingRepositoryDTO;

public interface RatingRepositoryService {
	
	List<RatingRepositoryDTO> findAll();

	RatingRepositoryDTO findById(Long id);

	RatingRepositoryDTO save(RatingRepositoryDTO ratingRepositoryDTO);

	RatingRepositoryDTO update(Long id, RatingRepositoryDTO ratingRepositoryDTO);
	
	void delete(Long id);

	List<RatingRepositoryDTO> saveAll(List<RatingRepositoryDTO> ratingRepositoryDTOs);

	List<RatingRepositoryDTO> findAllByIfvId(Long ifvId);

}
