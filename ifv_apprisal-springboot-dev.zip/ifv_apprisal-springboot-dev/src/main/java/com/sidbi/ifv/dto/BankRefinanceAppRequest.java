package com.sidbi.ifv.dto;

import java.time.LocalDate;
import java.util.Map;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class BankRefinanceAppRequest {

	@Min(value = 0, message = "Page number must be 0 or greater")
	private int page = 0;

	@Min(value = 1, message = "Size must be at least 1")
	@Max(value = 100, message = "Size must not exceed 100")
	private int size = 10;

	@Size(max = 50, message = "Application reference number must not exceed 50 characters")
	private String appRefId;

	@Size(max = 50, message = "CIF number must not exceed 50 characters")
	private String cifNumber;

	@Size(max = 200, message = "Bank name must not exceed 200 characters")
	private String nameOfBank;

	@Size(max = 500, message = "Scheme name must not exceed 500 characters")
	private String customSchemeName;

	@Size(max = 30, message = "Application status must not exceed 30 characters")
	private String applicationStatus;

	private LocalDate submittedFromDate;

	private LocalDate submittedToDate;

	private String submittedBy;

	private String sortField = "submittedDateTime";

	private String sortDirection = "desc";

	@Size(max = 255, message = "Global filter must not exceed 255 characters")
	private String globalFilter;

	private Map<String, String> filters;
}