package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.IFVDocumnetHistoryDTO;
import com.sidbi.ifv.services.IFVDocumnetHistoryService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/docHistory")
public class IFVDocumnetHistoryController {
	private static final Logger logger = LoggerFactory.getLogger(IFVDocumnetHistoryController.class);

	@Autowired
	private IFVDocumnetHistoryService iFVDocumnetHistoryService;
	
	@GetMapping("/get/{id}")
	public ResponseEntity<IFVDocumnetHistoryDTO> findById(@PathVariable Long id) {
		logger.info("findById() started IFVDocumnetHistoryController {} ",id);
		IFVDocumnetHistoryDTO iFVDocumnetHistoryDTOFind = iFVDocumnetHistoryService.findById(id);
		return ResponseEntity.ok(iFVDocumnetHistoryDTOFind);
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<IFVDocumnetHistoryDTO>> findAll() {
		logger.info("findAll() started IFVDocumnetHistoryController ");
		List<IFVDocumnetHistoryDTO> list = iFVDocumnetHistoryService.findAll();
		return ResponseEntity.ok(list);
	}
	@PostMapping("/save")
	public ResponseEntity<IFVDocumnetHistoryDTO> save(@RequestBody IFVDocumnetHistoryDTO iFVDocumnetHistoryDTO) {
		logger.info("save() started IFVDocumnetHistoryController {} ",iFVDocumnetHistoryDTO);
		IFVDocumnetHistoryDTO iFVDocumnetHistoryDTOSave = iFVDocumnetHistoryService.save(iFVDocumnetHistoryDTO);
		return ResponseEntity.ok(iFVDocumnetHistoryDTOSave);
	}
	@PutMapping("/update/{id}")
	public ResponseEntity<IFVDocumnetHistoryDTO> update(@PathVariable Long id,
			@RequestBody IFVDocumnetHistoryDTO iFVDocumnetHistoryDTO) {
		logger.info("update() started IFVDocumnetHistoryController {} ",iFVDocumnetHistoryDTO);
		IFVDocumnetHistoryDTO iFVDocumnetHistoryDTOUpdate = iFVDocumnetHistoryService.update(id, iFVDocumnetHistoryDTO);
		return ResponseEntity.ok(iFVDocumnetHistoryDTOUpdate);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started IFVDocumnetHistoryController {} ",id);
		iFVDocumnetHistoryService.delete(id);
		return ResponseEntity.noContent().build();
	}

}
