package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "C2_MINUTES_SANCT_STATUS")
public class SanctionStatusEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sanct_status_code")
	private Long sanctStatusCode;

	@Column(name = "agenda_number")
	private String agendaNumber;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "sanct_dscn_status")
	private String sanctDscnStatus;

	@Column(name = "min_sumry_created")
	private String minSumryCreated;

	@Column(name = "branch_name")
	private String branchName;

	@Column(name = "unit_name")
	private String unitName;

	@Column(name = "scheme_name")
	private String schemeName;

	@Column(name = "scheme_cd")
	private BigDecimal schemeCd;

	@Column(name = "application_no")
	private String applicationNo;

	@Column(name = "loan_amount")
	private BigDecimal loanAmount;

	@Column(name = "application_dt")
	private Date applicationDt;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

}