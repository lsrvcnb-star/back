package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.UcbCriteriaParameterEntity;

public interface UcbCriteriaParameterRepo extends JpaRepository<UcbCriteriaParameterEntity, Long> {

	List<UcbCriteriaParameterEntity> findByIfvId(Long ifvId);

}
