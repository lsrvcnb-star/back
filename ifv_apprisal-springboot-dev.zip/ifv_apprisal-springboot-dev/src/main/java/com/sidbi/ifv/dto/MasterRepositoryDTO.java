package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class MasterRepositoryDTO {
	
	private Long mstCode;
	
	private Long ifvId;
	
	private String mstParticulars;
	
	private String mstRemarks;
	
	private String mstOrder;
	
	private String mstFlg;
	
	private Date dateOfAction;

}
