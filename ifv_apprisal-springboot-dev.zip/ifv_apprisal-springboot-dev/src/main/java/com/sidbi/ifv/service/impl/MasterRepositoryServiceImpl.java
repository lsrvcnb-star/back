package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.MasterRepositoryDTO;
import com.sidbi.ifv.entity.S2IFVMasterRepositoryEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.MasterRepository;
import com.sidbi.ifv.services.MasterRepositoryService;
import com.sidbi.ifv.util.CommonUtil;

@Service
public class MasterRepositoryServiceImpl implements MasterRepositoryService {

	private static final Logger logger = LoggerFactory.getLogger(MasterRepositoryServiceImpl.class);

	@Autowired
	private MasterRepository masterRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private CommonUtil commonUtil;

	String msg = "";

	@Override
	public List<MasterRepositoryDTO> findAll() {
		logger.info("findAll() started in MasterRepositoryServiceImpl of S2IFVMasterRepositoryEntity");
		try {
			List<S2IFVMasterRepositoryEntity> list = masterRepository.findAll();
			return !list.isEmpty() ? list.stream()
					.map(masterRepositoryEntity -> modelMapper.map(masterRepositoryEntity, MasterRepositoryDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVMasterRepositoryEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVMasterRepositoryEntities." + msg + " ", e);
		}
	}

	@Override
	public MasterRepositoryDTO findById(Long id) {
		logger.info("findById() started in MasterRepositoryServiceImpl for S2IFVMasterRepositoryEntity {} ", id);
		S2IFVMasterRepositoryEntity s2ifvMasterRepositoryEntity = masterRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("s2IFVMasterRepositoryEntity", id));
		return modelMapper.map(s2ifvMasterRepositoryEntity, MasterRepositoryDTO.class);
	}

	@Override
	public MasterRepositoryDTO save(MasterRepositoryDTO masterRepositoryDTO) {
		logger.info("save() started in MasterRepositoryServiceImpl for S2IFVMasterRepositoryEntity {} ",
				masterRepositoryDTO);
		try {
			S2IFVMasterRepositoryEntity s2ifvMasterRepositoryEntity = modelMapper.map(masterRepositoryDTO,
					S2IFVMasterRepositoryEntity.class);
			masterRepository.save(s2ifvMasterRepositoryEntity);
			return modelMapper.map(s2ifvMasterRepositoryEntity, MasterRepositoryDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVMasterRepositoryEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  S2IFVMasterRepositoryEntity entity." + msg + " ", e);
		}
	}

	@Override
	public MasterRepositoryDTO update(Long id, MasterRepositoryDTO masterRepositoryDTO) {
		logger.info("update() started in MasterRepositoryServiceImpl for S2IFVMasterRepositoryEntity {} {} ", id,
				masterRepositoryDTO);
		try {
			S2IFVMasterRepositoryEntity existings2ifvMasterRepositoryEntity = masterRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVMasterRepositoryEntity", id));
			BeanUtils.copyProperties(masterRepositoryDTO, existings2ifvMasterRepositoryEntity,
					commonUtil.getNullPropertyNames(masterRepositoryDTO));
			masterRepository.save(existings2ifvMasterRepositoryEntity);
			return modelMapper.map(existings2ifvMasterRepositoryEntity, MasterRepositoryDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVMasterRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVMasterRepositoryEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in MasterRepositoryServiceImpl for S2IFVMasterRepositoryEntity {} ", id);
		try {
			S2IFVMasterRepositoryEntity existings2ifvMasterRepositoryEntity = masterRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVMasterRepositoryEntity", id));
			masterRepository.delete(existings2ifvMasterRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVMasterRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVMasterRepositoryEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<MasterRepositoryDTO> saveAll(List<MasterRepositoryDTO> masterRepositoryDTOs) {
		logger.info("saveAll() started in MasterRepositoryServiceImpl for List of S2IFVMasterRepositoryEntity");
		try {
			List<S2IFVMasterRepositoryEntity> masterRepositoryEntitiesToSave = masterRepositoryDTOs.stream()
					.map(masterRepositoryDTO -> modelMapper.map(masterRepositoryDTO, S2IFVMasterRepositoryEntity.class))
					.collect(Collectors.toList());
			masterRepositoryEntitiesToSave.forEach(e -> e.setDateOfAction(new Date()));
			List<S2IFVMasterRepositoryEntity> savedMasterRepositoryEntities = masterRepository
					.saveAll(masterRepositoryEntitiesToSave);

			return savedMasterRepositoryEntities.stream()
					.map(masterRepositoryEntity -> modelMapper.map(masterRepositoryEntity, MasterRepositoryDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVMasterRepositoryEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVMasterRepositoryEntities." + msg + " ", e);
		}
	}

	@Override
	public List<MasterRepositoryDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in MasterRepositoryServiceImpl ");
		try {
			List<S2IFVMasterRepositoryEntity> listMasterRepositoryEntities = masterRepository.findByIfvId(ifvId);

			return (listMasterRepositoryEntities != null && !listMasterRepositoryEntities.isEmpty())
					? listMasterRepositoryEntities.stream()
							.map(masterRepositoryEntity -> modelMapper.map(masterRepositoryEntity,
									MasterRepositoryDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVMasterRepositoryEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVMasterRepositoryEntities  based on IfvId." + msg + " "
							+ ifvId,
					e);

		}
	}

	@Override
	public List<MasterRepositoryDTO> findAllByMstParticulars(String mstParticulars) {
		logger.info("findAllByMstParticulars() started in MasterRepositoryServiceImpl ");
		try {
			List<S2IFVMasterRepositoryEntity> listMasterRepositoryEntities = masterRepository
					.findAllByMstParticulars(mstParticulars);

			return (listMasterRepositoryEntities != null && !listMasterRepositoryEntities.isEmpty())
					? listMasterRepositoryEntities.stream()
							.sorted(Comparator.comparingInt(entity -> Integer.parseInt(entity.getMstOrder())))
							.map(masterRepositoryEntity -> modelMapper.map(masterRepositoryEntity,
									MasterRepositoryDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVMasterRepositoryEntities based on mstParticulars. {}",
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVMasterRepositoryEntities  based on mstParticulars." + msg
							+ " " + mstParticulars,
					e);

		}
	}
}