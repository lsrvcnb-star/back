package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_COLLECTION_EFFICIENCY")
public class CollectionEfficiencyEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "PARTICULARS")
	private String particulars;

	@Column(name = "COLLECTION_EFFICIENCY")
	private BigDecimal collectionEfficiency;

}
