package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_SFB_COMMONDT")
public class S2IFVSfbCommondtEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SFB_ID")
	private Long sfbId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "SFB_SHAREPORTFOLIODATE")
	private Date sfbShareportfoliodate;

	@Column(name = "SFB_AO_NETWORK")
	private String sfbAoNetwork;

	@Column(name = "SFB_AO_BRANCHES")
	private String sfbAoBranches;

	@Column(name = "SFB_AO_MAJORITY_BRANCHES")
	private String sfbAoMajorityBranches;

	@Column(name = "SFB_AO_DATE")
	private Date sfbAoDate;

	@Column(name = "SFB_SHAREHOLDINGPATTERN")
	private Date sfShareholdingpattern;

	@Column(name = "audit_comments")
	private String auditComments;

	@Column(name = "alco_or_subalco")
	private String alcoOrSubalco;

	@Column(name = "discretion_involved")
	private String discretionInvolved;

	@Column(name = "discretion_involved_reason")
	private String discretionInvolvedReason;

	@Column(name = "cm_msers_data")
	private String cmMsersData;

	@Column(name = "cm_rmse_data")
	private String cmRmseData;

	@Column(name = "cm_rsfb_data")
	private String cmRsfbData;

	@Column(name = "cm_fabia_data")
	private String cmFabiaData;

	@Column(name = "cm_rampe_data")
	private String cmRampeData;

	@Column(name = "cm_chief_func_note")
	private String cmChiefFuncNote;

	@Column(name = "cm_geo_area_note")
	private String cmGeoAreaNote;

	@Column(name = "cm_key_investors_note")
	private String cmKeyInvestorsNote;

	@Column(name = "ucs_regulatory_environment")
	private String ucsRegulatoryEnvironment;

	@Column(name = "ucs_brief_particulars")
	private String ucsBriefParticulars;

	@Column(name = "ucs_director_exposure")
	private String ucsDirectorExposure;

	@Column(name = "ucs_institutional_borrowings")
	private String ucsInstitutionalBorrowings;

	@Column(name = "ucb_seg_portfolio_date")
	private Date ucbSegPortfolioDate;

	@Column(name = "ucb_seg2_portfolio_date")
	private Date ucbSeg2PortfolioDate;

	@Column(name = "ucb_seg2_note")
	private String ucbSeg2Note;

	@Column(name = "past_disb_note")
	private String pastDisbNote;

	@Column(name = "outstandings_note")
	private String outstandingsNote;

	@Column(name = "future_rep_note")
	private String futureRepNote;

	@Column(name = "interest_reset")
	private String interestReset;

}