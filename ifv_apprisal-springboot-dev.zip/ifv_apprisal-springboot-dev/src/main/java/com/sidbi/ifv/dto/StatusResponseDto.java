package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class StatusResponseDto {
	private String status;
	private Long count;
}
