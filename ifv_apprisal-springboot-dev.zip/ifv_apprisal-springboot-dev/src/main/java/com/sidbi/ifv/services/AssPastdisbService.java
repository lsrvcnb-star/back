package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AssPastdisbDTO;

public interface AssPastdisbService {

	List<AssPastdisbDTO> findAll();

	AssPastdisbDTO findById(Long id);

	AssPastdisbDTO save(AssPastdisbDTO s2IFCCAssPastdisbDTO);

	AssPastdisbDTO update(Long id, AssPastdisbDTO s2IFCCAssPastdisbDTO);

	void delete(Long id);

	List<AssPastdisbDTO> saveAll(List<AssPastdisbDTO> listAssPastdisbDTO);

	List<AssPastdisbDTO> findAllByIfvId(Long ifvId);

}
