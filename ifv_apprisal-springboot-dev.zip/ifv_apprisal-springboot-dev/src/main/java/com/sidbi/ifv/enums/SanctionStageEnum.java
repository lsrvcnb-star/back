package com.sidbi.ifv.enums;

public enum SanctionStageEnum {

	CR_AGNDA("CREATED", "Created Agenda"), CIRC_AGNDA("CIRCULATED", "Circulated Agenda"),
	CR_MIN("MINCREATED", "Minutes Created"), SUB_MIN("SUBMITTED", "Submitted Minutes"),
	APPRV_MIN("APPROVED", "Approved Minutes"), CLOSED("CLOSED", "Closed Minutes"), LOCK("LOCKED", "Lock Minutes");

	private final String status;

	private final String value;

	private SanctionStageEnum(String status, String value) {
		this.status = status;
		this.value = value;
	}

	public String getStatus() {
		return status;
	}

	public String getValue() {
		return value;
	}

}
