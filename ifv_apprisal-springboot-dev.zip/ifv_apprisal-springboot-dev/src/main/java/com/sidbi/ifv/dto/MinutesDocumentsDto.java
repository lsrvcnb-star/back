package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MinutesDocumentsDto {

	private Long id;

	private String module;

	private Long minuteId;

	private MultipartFile file;

	private String documentName;

	private String documentType;

	private byte[] documentContent;

	private LocalDateTime createdAt;

	private LocalDateTime updatedAt;

	private String createdBy;

	private String updatedBy;

	private String status;

	private Long uploadedUserId;
}
