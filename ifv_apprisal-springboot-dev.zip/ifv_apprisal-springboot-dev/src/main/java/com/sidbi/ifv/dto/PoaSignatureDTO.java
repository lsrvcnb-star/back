package com.sidbi.ifv.dto;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.util.FileType;

import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class PoaSignatureDTO {

	private Long id;

	private String cifNumber;

	private String bankName;

	private Date startDate;

	private Date endDate;

	private byte[] file;

	@Size(max = 12 * 1024 * 1024, message = "File size must be less than or eqaul to 12MB")
	@FileType(types = { "application/pdf", "image/jpeg", "image/png", "image/gif", "application/msword",
			"application/vnd.openxmlformats-officedocument.wordprocessingml.document" }, message = "Invalid file type")
	private MultipartFile fileData;

	private List<String> fileNames;

	private String fileName;

}
