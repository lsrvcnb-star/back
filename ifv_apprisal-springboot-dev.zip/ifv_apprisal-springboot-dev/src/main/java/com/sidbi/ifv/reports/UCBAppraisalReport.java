package com.sidbi.ifv.reports;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.MalformedURLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.sidbi.ifv.dto.AssistanceAppliedForDto;
import com.sidbi.ifv.dto.DisclosureDivergenceDto;
import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.HrmsEmpNameDesignationDTO;
import com.sidbi.ifv.dto.IFVProposalCheckerDetailDTO;
import com.sidbi.ifv.dto.IfvAggregateExposureDto;
import com.sidbi.ifv.dto.MasterRepositoryDTO;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.dto.RestructuredAssetsDTO;
import com.sidbi.ifv.dto.StatusOfListingDto;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.dto.UcbAnnexureDTO;
import com.sidbi.ifv.dto.UcbBorrowersDetailDto;
import com.sidbi.ifv.dto.UcbCriteriaParameterDTO;
import com.sidbi.ifv.dto.UcbEligibilityCriteriaDTO;
import com.sidbi.ifv.dto.UcbFinancialPerformanceDTO;
import com.sidbi.ifv.dto.UcbTop10BorrowersDTO;
import com.sidbi.ifv.entity.CollectionEfficiencyEntity;
import com.sidbi.ifv.entity.IFVDocumnetHistoryEntity;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVAreasGeographicalEntity;
import com.sidbi.ifv.entity.S2IFVAssOutstandingEntity;
import com.sidbi.ifv.entity.S2IFVAssPastdisbEntity;
import com.sidbi.ifv.entity.S2IFVAssRepaymentsEntity;
import com.sidbi.ifv.entity.S2IFVChiefBoardEntity;
import com.sidbi.ifv.entity.S2IFVEligibilityEntity;
import com.sidbi.ifv.entity.S2IFVFinancialHighlightsEntity;
import com.sidbi.ifv.entity.S2IFVInstitutionalEntity;
import com.sidbi.ifv.entity.S2IFVInvestorEntity;
import com.sidbi.ifv.entity.S2IFVKycEntity;
import com.sidbi.ifv.entity.S2IFVPrincipalEntity;
import com.sidbi.ifv.entity.S2IFVProfileBdEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.entity.S2IFVRatingRepositoryEntity;
import com.sidbi.ifv.entity.S2IFVSchemaEntity;
import com.sidbi.ifv.entity.S2IFVSfbCommondtEntity;
import com.sidbi.ifv.entity.S2IFVTermConditionsDataEntity;
import com.sidbi.ifv.entity.SanctionTermsConditionsEntity;
import com.sidbi.ifv.enums.UserDesignationEnum;
import com.sidbi.ifv.exception.ReportGenerationException;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.CurrencyConverter;
import com.sidbi.ifv.util.FontFirstClass;
import com.sidbi.ifv.util.PageNumberEvent;

public class UCBAppraisalReport {

	private static final Logger logger = LoggerFactory.getLogger(UCBAppraisalReport.class);

	private static final DecimalFormat decimalFormat = new DecimalFormat("#.##");

	private static final String SCHEME = "Scheme";
	private static final String AMOUNT = "Amount";
	private static final String TENURE = "Tenure";
	private static final String DATE_FORMAT = "dd/MM/yyyy";
	private static final String DATE_FORMAT2 = "dd-MM-yyyy";
	private static final String REPO_RATE = "REPO RATE";
	private static final String RBI_REPO_RATE = "RBI Repo rate";
	private static final String TOTAL = "Total";
	private static final String SL_NO = "Sl. No.";
	private static final String PARTICULARS = "Particulars";
	private static final String TOP_FIVE_KYC = "TopFiveKyc";
	private static final String SPACE = "           ";
	private static final String IFV_MUMBAI = ",\nMumbai - IFV";
	private static final String APPROVED = "Approved";
	private static final String DATE = "Date: ";
	private static final String SL_N = "Sl.\n";
	private static final String SL_N2 = "Sl No";
	private static final String PERIOD_FY = "Period (FY)";
	private static final String RUPEE = "Rupee";
	private static final String CONST = "\u2022 ";
	private static final String IN_CRORE = " In crore)";

	FontFirstClass fontFirstClass = new FontFirstClass();
	Font paragraphFont = fontFirstClass.fontForText();
	Font rupeeFont = fontFirstClass.fontForRupeesSymbol();
	Font headLineFont = fontFirstClass.fontForHeadLine();
	Font underlineTextFont = fontFirstClass.underlineTextFont();
	Font italicFont = fontFirstClass.italicFont();

	Chunk pSpace = new Chunk("\r");
	List<S2IFVApplicationEntity> s2IFCCApplicationList;

	List<S2IFVKycEntity> kycDtoList;

	List<S2IFVChiefBoardEntity> chiefBoardDTOList;

	List<S2IFVAreasGeographicalEntity> areaOfGeographicalDTOList;

	List<S2IFVInvestorEntity> investorDTOList;

	List<S2IFVAssPastdisbEntity> assPastdisbDTOList;

	List<S2IFVAssOutstandingEntity> assOutstandingDTOList;

	List<S2IFVAssRepaymentsEntity> assRepaymentsDTOList;

	List<S2IFVSchemaEntity> s2ifccSchemaDTOList;

	List<S2IFVPrincipalEntity> principalDTOList;

	List<S2IFVInstitutionalEntity> institutionalDTOList;

	S2IFVTermConditionsDataEntity conditionDataDTOList;

	List<S2IFVFinancialHighlightsEntity> highlightsDTOList;

	S2IFVEligibilityEntity eligibilityEntitiesDTOList;

	S2IFVSfbCommondtEntity commondtEntityData;

	List<S2IFVRatingRepositoryEntity> ratingRepositoryData;

	List<S2IFVAreasGeographicalEntity> listOfCtAgType;

	List<S2IFVAreasGeographicalEntity> listOfStAgType;

	List<MasterRepositoryDTO> masterRepositoryData;

	List<S2IFVProfileBdEntity> profileBdList;

	List<ProposedSchemaDTO> proposedSchemaDetails;

	List<HrmsEmpNameDesignationDTO> hrmsEmpName;

	List<CollectionEfficiencyEntity> collectionEfficiencyDto;

	List<S2IFVProposedSchemaEntity> proposedSchemaDto;

	List<RestructuredAssetsDTO> restructuredAssetsDto;

	List<SanctionTermsConditionsEntity> sanctionTermsConditionsDto;

	List<IfvApiUsersEntity> ifvApiUsersDetails;

	List<IFVDocumnetHistoryEntity> iFVDocumnetHistoryDetails;

	List<StatusOfListingDto> statusOfListingDtos;

	String bankType;

	FileRepositoryDTO fileRepositoryDTO;

	TblIfvModuleFwdDTO tblIfvModuleFwdDTO;

	List<UcbTop10BorrowersDTO> borrowersDTOs;

	List<UcbFinancialPerformanceDTO> financialPerformanceDTOs = null;

	List<UcbEligibilityCriteriaDTO> eligibilityCriteriaDTOs = null;

	List<UcbCriteriaParameterDTO> criteriaParameterDTOs = null;

	List<UcbAnnexureDTO> annexureDTOs = null;

	UcbBorrowersDetailDto borrowersDetailDto;

	List<DisclosureDivergenceDto> disclosureDivergenceDtos;

	boolean isRRB;

	List<AssistanceAppliedForDto> assistanceAppliedForDtos;

	List<IFVProposalCheckerDetailDTO> ifvProposalCheckerDetailDTOs;

	List<IfvAggregateExposureDto> aggregateExposure;

	public UCBAppraisalReport(List<S2IFVApplicationEntity> s2IFCCApplicationList, List<S2IFVKycEntity> kycDtoList,
			List<S2IFVChiefBoardEntity> chiefBoardDTOList, List<S2IFVAreasGeographicalEntity> areaOfGeographicalDTOList,
			List<S2IFVInvestorEntity> investorDTOList, List<S2IFVAssPastdisbEntity> assPastdisbDTOList,
			List<S2IFVAssOutstandingEntity> assOutstandingDTOList, List<S2IFVAssRepaymentsEntity> assRepaymentsDTOList,
			List<S2IFVSchemaEntity> s2ifccSchemaDTOList, List<S2IFVPrincipalEntity> principalDTOList,
			List<S2IFVInstitutionalEntity> institutionalDTOList, S2IFVTermConditionsDataEntity conditionDataDTOList,
			List<S2IFVFinancialHighlightsEntity> highlightsDTOList, S2IFVEligibilityEntity eligibilityEntitiesDTOList,
			S2IFVSfbCommondtEntity commondtEntityData, List<S2IFVRatingRepositoryEntity> ratingRepositoryData,
			List<S2IFVAreasGeographicalEntity> listOfCtAgType, List<S2IFVAreasGeographicalEntity> listOfStAgType,
			List<MasterRepositoryDTO> masterRepositoryData, List<S2IFVProfileBdEntity> profileBdList,
			List<ProposedSchemaDTO> proposedSchemaDetails, List<HrmsEmpNameDesignationDTO> hrmsEmpName,
			List<CollectionEfficiencyEntity> collectionEfficiencyDto, List<S2IFVProposedSchemaEntity> proposedSchemaDto,
			List<RestructuredAssetsDTO> restructuredAssetsDto,
			List<SanctionTermsConditionsEntity> sanctionTermsConditionsDto, List<IfvApiUsersEntity> ifvApiUsersDetails,
			List<IFVDocumnetHistoryEntity> iFVDocumnetHistoryDetails, String banktype,
			FileRepositoryDTO fileRepositoryDTO, List<StatusOfListingDto> statusOfListingDtos,
			TblIfvModuleFwdDTO tblIfvModuleFwdDTO, List<UcbTop10BorrowersDTO> borrowersDTOs,
			List<UcbFinancialPerformanceDTO> financialPerformanceDTOs,
			List<UcbEligibilityCriteriaDTO> eligibilityCriteriaDTOs,
			List<UcbCriteriaParameterDTO> criteriaParameterDTOs, List<UcbAnnexureDTO> annexureDTOs,
			UcbBorrowersDetailDto borrowersDetailDto, List<DisclosureDivergenceDto> disclosureDivergenceDtos,
			boolean isRRB, List<AssistanceAppliedForDto> assistanceAppliedForDtos,
			List<IFVProposalCheckerDetailDTO> ifvProposalCheckerDetailDTOs,
			List<IfvAggregateExposureDto> aggregateExposure) {

		this.s2IFCCApplicationList = s2IFCCApplicationList;

		this.kycDtoList = kycDtoList;

		this.chiefBoardDTOList = chiefBoardDTOList;

		this.areaOfGeographicalDTOList = areaOfGeographicalDTOList;

		this.investorDTOList = investorDTOList;

		this.assPastdisbDTOList = assPastdisbDTOList;

		this.assOutstandingDTOList = assOutstandingDTOList;

		this.assRepaymentsDTOList = assRepaymentsDTOList;

		this.s2ifccSchemaDTOList = s2ifccSchemaDTOList;

		this.principalDTOList = principalDTOList;

		this.institutionalDTOList = institutionalDTOList;

		this.conditionDataDTOList = conditionDataDTOList;

		this.highlightsDTOList = highlightsDTOList;

		this.eligibilityEntitiesDTOList = eligibilityEntitiesDTOList;

		this.commondtEntityData = commondtEntityData;

		this.ratingRepositoryData = ratingRepositoryData;

		this.listOfCtAgType = listOfCtAgType;

		this.listOfStAgType = listOfStAgType;

		this.masterRepositoryData = masterRepositoryData;

		this.profileBdList = profileBdList;

		this.proposedSchemaDetails = proposedSchemaDetails;

		this.hrmsEmpName = hrmsEmpName;

		this.collectionEfficiencyDto = collectionEfficiencyDto;

		this.proposedSchemaDto = proposedSchemaDto;

		this.restructuredAssetsDto = restructuredAssetsDto;

		this.sanctionTermsConditionsDto = sanctionTermsConditionsDto;

		this.ifvApiUsersDetails = ifvApiUsersDetails;

		this.iFVDocumnetHistoryDetails = iFVDocumnetHistoryDetails;

		this.bankType = banktype;

		this.fileRepositoryDTO = fileRepositoryDTO;

		this.statusOfListingDtos = statusOfListingDtos;

		this.tblIfvModuleFwdDTO = tblIfvModuleFwdDTO;

		this.borrowersDTOs = borrowersDTOs;

		this.financialPerformanceDTOs = financialPerformanceDTOs;

		this.eligibilityCriteriaDTOs = eligibilityCriteriaDTOs;

		this.criteriaParameterDTOs = criteriaParameterDTOs;

		this.annexureDTOs = annexureDTOs;

		this.borrowersDetailDto = borrowersDetailDto;

		this.disclosureDivergenceDtos = disclosureDivergenceDtos;

		this.isRRB = isRRB;

		this.assistanceAppliedForDtos = assistanceAppliedForDtos;

		this.ifvProposalCheckerDetailDTOs = ifvProposalCheckerDetailDTOs;

		this.aggregateExposure = aggregateExposure;
	}

	private void nestedTableProposedSanctioned(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPaddingTop(4);
		cell.setPaddingBottom(4);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SCHEME, headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		Chunk c3 = new Chunk(AMOUNT, headLineFont);
		Chunk c33 = new Chunk("\n(crore)", italicFont);

		Phrase p3 = new Phrase();
		p3.add(c3);
		p3.add(c33);

		cell.setPhrase(p3);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		Chunk c1 = new Chunk("RoI", headLineFont);
		Chunk c11 = new Chunk("\n(% p.a.)", italicFont);

		Phrase p1 = new Phrase();
		p1.add(c1);
		p1.add(c11);

		cell.setPhrase(p1);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		boolean isAnyOneInterestResetPresent = proposedSchemaDetails.stream()
				.anyMatch(e -> e.getInterestReset() != null && !e.getInterestReset().isBlank());

		if (isAnyOneInterestResetPresent) {
			cell.setPhrase(new Phrase("Interest\nReset", headLineFont));
			cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			table.addCell(cell);
		}

		Chunk c2 = new Chunk(TENURE, headLineFont);
		Chunk c22 = new Chunk("\n(In months)", italicFont);

		Phrase p2 = new Phrase();
		p2.add(c2);
		p2.add(c22);

		cell.setPhrase(p2);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Principal Repayment", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private String formatRoi(BigDecimal roi) {
		if (roi.scale() > 0) {
			return roi.setScale(2, RoundingMode.HALF_UP).toPlainString();
		}
		return roi.toPlainString();
	}

	private String formatAmount(BigDecimal number) {
		if (number == null) {
			return "";
		}

		int scale = number.stripTrailingZeros().scale();

		if (scale == 1) {
			return number.setScale(2, RoundingMode.HALF_UP).toPlainString();
		} else {
			return number.stripTrailingZeros().toPlainString();
		}
	}

	private void nestedTableProposedSanctionedData(PdfPTable table) {

		BigDecimal totalAmount = BigDecimal.ZERO;
		String remarks = "";

		SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);

		Optional<ProposedSchemaDTO> optionalDto = proposedSchemaDetails.stream().findFirst();
		if (optionalDto.isPresent()) {
			ProposedSchemaDTO pdto = optionalDto.get();
			Optional<S2IFVApplicationEntity> optinalEntity = s2IFCCApplicationList.stream()
					.filter(entity -> entity.getIfvId().equals(pdto.getIfvId())).findFirst();
			if (optinalEntity.isPresent()) {
				remarks = optinalEntity.get().getIfvRemarks();
			}
		}

		boolean isAnyOneInterestResetPresent = proposedSchemaDetails.stream()
				.anyMatch(e -> e.getInterestReset() != null && !e.getInterestReset().isBlank());

		for (ProposedSchemaDTO proposedSchemaDto : proposedSchemaDetails) {

			String schemeName = "";

			boolean addApprox;

			if (proposedSchemaDto.getPrFundname().toLowerCase().contains("rmse")) {
				schemeName = this.getSchemeName(proposedSchemaDto.getPrFundname());
				addApprox = true;
			} else {
				schemeName = proposedSchemaDto.getPrSchemeName() != null ? proposedSchemaDto.getPrSchemeName() : "";
				addApprox = false;
			}

			PdfPCell cellPrSchemeName = new PdfPCell(new Phrase(schemeName, paragraphFont));
			cellPrSchemeName.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellPrSchemeName.setPadding(5);

			table.addCell(cellPrSchemeName);

			PdfPCell cellAmount = new PdfPCell(
					new Phrase(CommonUtil.formatNumber(formatAmount(proposedSchemaDto.getPrAmount())), paragraphFont));
			cellAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cellAmount);

			String benchMark = proposedSchemaDto.getBenchMark();

			if (benchMark != null && !benchMark.isBlank()) {

				String repoNote = null;

				if (benchMark.toUpperCase().contains(REPO_RATE)) {
					benchMark = RBI_REPO_RATE;
					repoNote = proposedSchemaDto.getRoiNote();
				}

				StringBuilder stringBuilder = new StringBuilder(benchMark);

				if (proposedSchemaDto.getSpread() != null && !proposedSchemaDto.getSpread().isBlank()) {
					stringBuilder.append(" + " + proposedSchemaDto.getSpread() + " bps");

				}

				if (proposedSchemaDto.getInterestType() != null && !proposedSchemaDto.getInterestType().isBlank()) {
					stringBuilder.append("\n(" + proposedSchemaDto.getInterestType() + ")");

				}

				if (repoNote != null && !repoNote.isEmpty()) {
					stringBuilder.append("\n(" + repoNote + ")");
				}

				PdfPCell cellRoi = new PdfPCell(new Phrase(stringBuilder.toString(), paragraphFont));
				cellRoi.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(cellRoi);
			} else {
				String roi = proposedSchemaDto.getPrRoi() != null ? formatRoi(proposedSchemaDto.getPrRoi()) : "";
				if (proposedSchemaDto.getInterestType() != null && !proposedSchemaDto.getInterestType().isBlank()) {
					roi += "\n(" + proposedSchemaDto.getInterestType() + ")";
				}
				PdfPCell cellRoi = new PdfPCell(new Phrase(roi, paragraphFont));
				cellRoi.setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(cellRoi);
			}

			if (isAnyOneInterestResetPresent) {
				PdfPCell cellIntReset = new PdfPCell(new Phrase(
						proposedSchemaDto.getInterestReset() != null ? proposedSchemaDto.getInterestReset() : "",
						paragraphFont));
				cellIntReset.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(cellIntReset);
			}

			String tenure = proposedSchemaDto.getPrTenure() != null
					? proposedSchemaDto.getPrTenure().stripTrailingZeros().toPlainString()
					: "";

			if (addApprox) {
				tenure = tenure + "\n(Approx.)";
			}

			PdfPCell cellTenure = new PdfPCell(new Phrase(tenure, paragraphFont));
			cellTenure.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cellTenure);

			String principalRepaymentData = proposedSchemaDto.getPrPrincipalRepayment() != null
					? proposedSchemaDto.getPrPrincipalRepayment()
					: "";
			if (proposedSchemaDto.getPrMaturityDate() != null) {

				principalRepaymentData += "\n(Maturing on " + format.format(proposedSchemaDto.getPrMaturityDate())
						+ ")";
			}

			PdfPCell cellPrRepayment = new PdfPCell(new Phrase(principalRepaymentData, paragraphFont));
			cellPrRepayment.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cellPrRepayment);

			BigDecimal amount = proposedSchemaDto.getPrAmount() != null ? proposedSchemaDto.getPrAmount()
					: BigDecimal.ZERO;
			totalAmount = totalAmount.add(amount);

		}

		PdfPCell cell = new PdfPCell();
		cell.setPaddingBottom(5);
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setPhrase(new Phrase(TOTAL, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(CommonUtil.formatNumber(formatAmount(totalAmount)), headLineFont));

		table.addCell(cell);
		cell.setPhrase(new Phrase("", headLineFont));

		if (isAnyOneInterestResetPresent) {
			cell.setColspan(4);
		} else {
			cell.setColspan(5);
		}

		table.addCell(cell);

		if (!remarks.isEmpty()) {
			PdfPCell remarksCell = new PdfPCell();
			remarksCell.setPadding(4);

			remarksCell.setPhrase(new Phrase(remarks, paragraphFont));
			if (isAnyOneInterestResetPresent) {
				remarksCell.setColspan(7);
			} else {
				remarksCell.setColspan(8);
			}

			table.addCell(remarksCell);
		}

	}

	private void exposureLimitBorrowingBank(PdfPTable table) {
		for (S2IFVApplicationEntity applicationEntity : s2IFCCApplicationList) {
			PdfPCell cell = new PdfPCell();
			cell.setPadding(5);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);

			cell.setPhrase(new Phrase(""));
			table.addCell(cell);

			cell.setPhrase(new Phrase("BO", headLineFont));
			cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			table.addCell(cell);

			cell.setPhrase(new Phrase("Exposure Limit*", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			String formattedExpLimit = applicationEntity.getIfvExposureLimit() != null
					? CommonUtil.formatNumber(formatAmount(applicationEntity.getIfvExposureLimit()))
					: "";

			cell.setPhrase(new Phrase(formattedExpLimit, paragraphFont));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			cell.setPhrase(new Phrase("Existing O/S", paragraphFont));
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			String formattedExistingOs = applicationEntity.getIfvExistingOs() != null
					? CommonUtil.formatNumber(formatAmount(applicationEntity.getIfvExistingOs()))
					: "";

			cell.setPhrase(new Phrase(formattedExistingOs, paragraphFont));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			cell.setPhrase(new Phrase("Undisbursed Sanction", paragraphFont));
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			String formattedUndisbursedSanction = applicationEntity.getIfvUndisbursedSanction() != null
					? CommonUtil.formatNumber(formatAmount(applicationEntity.getIfvUndisbursedSanction()))
					: "";

			cell.setPhrase(new Phrase(formattedUndisbursedSanction, paragraphFont));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			cell.setPhrase(new Phrase("Proposed Exposure", paragraphFont));
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			String formattedPropExposure = applicationEntity.getIfvPropExposure() != null
					? CommonUtil.formatNumber(formatAmount(applicationEntity.getIfvPropExposure()))
					: "";

			cell.setPhrase(new Phrase(formattedPropExposure, paragraphFont));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			cell.setPhrase(new Phrase("Total Exposure", headLineFont));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);

			String ifvTotalExposure = applicationEntity.getIfvTotalExposure() != null
					? CommonUtil.formatNumber(formatAmount(applicationEntity.getIfvTotalExposure()))
					: "";

			cell.setPhrase(new Phrase(ifvTotalExposure, headLineFont));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setBackgroundColor(BaseColor.WHITE);
			table.addCell(cell);
		}

	}

	private void detailsKeyProduct(PdfPTable table, String segment) {

		String col1Name = "Name of \n" + "Product ";
		String col2Name = "Amount \n(Rs in" + " crores )";
		if (segment.equalsIgnoreCase("segment")) {
			col1Name = "Segment";
			col2Name = "O/s\n(Rs in crores)";
		}

		PdfPCell cell = new PdfPCell();
		cell.setPadding(6);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_N + "No. ", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase(col1Name, headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase(col2Name, headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase("% share in " + "portfolio \n", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase("", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthTop(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase("", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthTop(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase("", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthTop(0);
		table.addCell(cell);
		Date sharePortfolioDate = commondtEntityData.getSfbShareportfoliodate();

		String formatterShareportfolioDatedt = "";
		if (sharePortfolioDate != null) {
			DateTimeFormatter formateShareportfolioDatedt = DateTimeFormatter.ofPattern(DATE_FORMAT2);
			LocalDate ShareportDate = sharePortfolioDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			formatterShareportfolioDatedt = ShareportDate.format(formateShareportfolioDatedt);
		}
		cell.setPhrase(new Phrase("[ " + String.valueOf(formatterShareportfolioDatedt + " ]"), headLineFont));
		cell.setBorderWidthTop(0);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void detailsKeyProductData(PdfPTable table, String segment) {
		int count = 0;
		List<S2IFVKycEntity> list = kycDtoList;
		if (!isRRB) {
			list = kycDtoList.stream().filter(e -> e.getKycType() != null && e.getKycType().equalsIgnoreCase(segment))
					.sorted(Comparator.comparing(S2IFVKycEntity::getKycId)).collect(Collectors.toList());
		}

		for (S2IFVKycEntity dtoList : list) {
			if (dtoList.getKycProductName() != null && !dtoList.getKycProductName().isBlank()) {
				PdfPCell cellKycId = new PdfPCell(new Phrase(Integer.toString(++count), paragraphFont));
				cellKycId.setHorizontalAlignment(Element.ALIGN_CENTER);
				cellKycId.setPadding(5);
				table.addCell(cellKycId);
				PdfPCell cellKycProductName = new PdfPCell(new Phrase(dtoList.getKycProductName(), paragraphFont));
				cellKycProductName.setHorizontalAlignment(Element.ALIGN_LEFT);
				cellKycProductName.setPadding(5);
				table.addCell(cellKycProductName);

				String formattedKycAmount = dtoList.getKycAmount() != null
						? CommonUtil.formatNumber(dtoList.getKycAmount().toPlainString())
						: "";

				PdfPCell cellKycAmount = new PdfPCell(new Phrase(formattedKycAmount, paragraphFont));
				cellKycAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
				cellKycAmount.setPadding(5);
				table.addCell(cellKycAmount);

				BigDecimal kycShareProfile = dtoList.getKycShareProfile() != null ? dtoList.getKycShareProfile()
						: BigDecimal.ZERO;

				PdfPCell cellKycShareProfile = new PdfPCell(new Phrase(String.valueOf(kycShareProfile), paragraphFont));
				cellKycShareProfile.setHorizontalAlignment(Element.ALIGN_RIGHT);
				cellKycShareProfile.setPadding(5);
				table.addCell(cellKycShareProfile);
			}
		}

		if (!segment.equalsIgnoreCase(TOP_FIVE_KYC)) {
			PdfPCell cellKycId = new PdfPCell(new Phrase("", paragraphFont));
			cellKycId.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellKycId.setPadding(5);
			table.addCell(cellKycId);
			PdfPCell cellKycProductName = new PdfPCell(new Phrase(TOTAL, headLineFont));
			cellKycProductName.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellKycProductName.setPadding(5);
			table.addCell(cellKycProductName);

			BigDecimal kycAmount = list.stream().map(e -> e.getKycAmount()).reduce(BigDecimal.ZERO, (a, b) -> a.add(b));
			String formattedKycAmountTot = CommonUtil.formatNumber(kycAmount.stripTrailingZeros().toPlainString());
			PdfPCell cellKycAmount = new PdfPCell(new Phrase(formattedKycAmountTot, headLineFont));
			cellKycAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cellKycAmount.setPadding(5);
			table.addCell(cellKycAmount);

			BigDecimal kycShareProfile = list.stream().map(e -> e.getKycShareProfile()).reduce(BigDecimal.ZERO,
					(a, b) -> a.add(b));

			String kycShareProfileAmount = "";
			kycShareProfileAmount = setKeyShareAmt(kycShareProfile);

			PdfPCell cellKycShareProfile = new PdfPCell(new Phrase(kycShareProfileAmount, headLineFont));
			cellKycShareProfile.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cellKycShareProfile.setPadding(5);
			table.addCell(cellKycShareProfile);
		}

	}

	private String setKeyShareAmt(BigDecimal kycShareProfile) {
		String kycShareProfileAmount;
		if (kycShareProfile.stripTrailingZeros().scale() <= 0) {
			kycShareProfileAmount = kycShareProfile.toBigInteger().toString();
		} else {
			kycShareProfileAmount = decimalFormat.format(kycShareProfile);
		}
		return kycShareProfileAmount;
	}

	private void chiefFunctionaryBoard(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPaddingBottom(4f);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_N + "No.", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase(isRRB ? "Name & Designation" : "Name", headLineFont));
		cell.setPaddingTop(8f);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase(isRRB ? "Board Member" : "Designation", headLineFont));
		cell.setPaddingTop(8f);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Remarks", headLineFont));
		cell.setPaddingTop(8f);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void chiefFunctionaryBoardData(PdfPTable table) {
		int sr = 1;
		for (S2IFVProfileBdEntity profilelist : profileBdList) {
			PdfPCell cell = new PdfPCell();
			cell.setLeading(16, 0);
			cell.setPaddingLeft(4);
			cell.setHorizontalAlignment(Rectangle.LEFT);
			cell.setPhrase(new Phrase(String.valueOf(sr), paragraphFont));
			cell.setPaddingBottom(8f);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			cell.setPhrase(new Phrase(profilelist.getPrFirstName() != null ? profilelist.getPrFirstName() : "",
					paragraphFont));
			cell.setPaddingBottom(8f);
			cell.setHorizontalAlignment(Rectangle.LEFT);
			table.addCell(cell);

			cell.setPhrase(new Phrase(profilelist.getPrDesignation() != null ? profilelist.getPrDesignation() : "",
					paragraphFont));
			cell.setPaddingBottom(8f);
			cell.setHorizontalAlignment(Rectangle.LEFT);
			table.addCell(cell);

			cell.setPhrase(new Phrase(profilelist.getPrBriefProfile() != null ? profilelist.getPrBriefProfile() : "",
					paragraphFont));
			cell.setHorizontalAlignment(Rectangle.LEFT);
			cell.setPaddingBottom(8f);
			table.addCell(cell);
			++sr;
		}

	}

	private void oprationGeographical(PdfPTable table) {

		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_NO, headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase(isRRB ? "District" : "STATE/UT", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("No. of Branches", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void oprationGeographicalDataWithST(PdfPTable table) {
		List<S2IFVAreasGeographicalEntity> agStateAmount = listOfStAgType.stream()
				.sorted(Comparator.comparing(S2IFVAreasGeographicalEntity::getAgState)).collect(Collectors.toList());

		int count = 1;
		for (S2IFVAreasGeographicalEntity areaOfGeographicalDTO : agStateAmount) {
			String agState = areaOfGeographicalDTO.getAgState() != null ? areaOfGeographicalDTO.getAgState() : "";
			if (!agState.isBlank() && agState != null) {
				PdfPCell pCount = new PdfPCell(new Phrase(String.valueOf(count), paragraphFont));
				pCount.setPadding(5);
				pCount.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(pCount);

				PdfPCell pAgState = new PdfPCell(new Phrase(agState, paragraphFont));
				pAgState.setHorizontalAlignment(Element.ALIGN_LEFT);
				pAgState.setPadding(5);
				table.addCell(pAgState);
				BigDecimal agBranch = areaOfGeographicalDTO.getAgBranch() != null ? areaOfGeographicalDTO.getAgBranch()
						: BigDecimal.ZERO;
				PdfPCell pAgBranch = new PdfPCell(new Phrase(String.valueOf(agBranch.intValue()), paragraphFont));
				pAgBranch.setHorizontalAlignment(Element.ALIGN_RIGHT);
				pAgBranch.setPadding(5);
				table.addCell(pAgBranch);
				count++;
			}
		}
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase("", headLineFont));
		cell.setBorderWidthTop(1);
		table.addCell(cell);

		cell.setPhrase(new Phrase(TOTAL, headLineFont));
		cell.setBorderWidthTop(1);
		table.addCell(cell);

		List<BigDecimal> list = agStateAmount.stream().map(S2IFVAreasGeographicalEntity::getAgBranch)
				.collect(Collectors.toList());
		BigDecimal total = list.stream().map(value -> value == null ? BigDecimal.ZERO : value).reduce(BigDecimal.ZERO,
				BigDecimal::add);

		cell.setPhrase(new Phrase("" + total.intValue(), headLineFont));
		cell.setBorderWidthTop(1);
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		table.addCell(cell);
	}

	private void oprationGeographicalDataForRRB(Document document) throws DocumentException {
		Paragraph p13 = new Paragraph();
		p13.setAlignment(Element.ALIGN_CENTER);
		SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
		String dateVal = commondtEntityData.getSfbAoDate() != null
				? String.valueOf(format.format(commondtEntityData.getSfbAoDate()))
				: "";
		Paragraph chunk13 = new Paragraph("Branch Network as on " + dateVal, underlineTextFont);
		chunk13.setAlignment(Element.ALIGN_CENTER);
		p13.add(chunk13);
		document.add(p13);
		document.add(Chunk.NEWLINE);
		Map<String, List<S2IFVAreasGeographicalEntity>> groupedByState = listOfStAgType.stream()
				.sorted(Comparator.comparing(S2IFVAreasGeographicalEntity::getAgId))
				.collect(Collectors.groupingBy(S2IFVAreasGeographicalEntity::getRrbStateName));
		int grandTotalDistricts = 0;
		int grandTotalBranches = 0;
		for (Map.Entry<String, List<S2IFVAreasGeographicalEntity>> stateEntry : groupedByState.entrySet()) {
			String stateName = stateEntry.getKey();
			List<S2IFVAreasGeographicalEntity> stateEntities = stateEntry.getValue();
			Paragraph stateHeader = new Paragraph("State: " + stateName, headLineFont);
			stateHeader.setAlignment(Element.ALIGN_LEFT);
			document.add(stateHeader);
			PdfPTable table = new PdfPTable(3);
			table.setWidthPercentage(100);
			table.setWidths(new float[] { 20, 50, 30 });
			table.setSpacingBefore(10f);
			table.setSpacingAfter(10f);
			String[] headers = { SL_NO, "District", "No. of Branches" };
			for (String header : headers) {
				PdfPCell headerCell = new PdfPCell(new Phrase(header, headLineFont));
				headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
				headerCell.setPadding(5f);
				table.addCell(headerCell);
			}
			int stateTotalAgBranch = stateEntities.stream().mapToInt(e -> e.getAgBranch().intValue()).sum();
			int stateTotalDistricts = stateEntities.size();
			for (int i = 0; i < stateEntities.size(); i++) {
				S2IFVAreasGeographicalEntity entity = stateEntities.get(i);
				PdfPCell slNoCell = new PdfPCell(new Phrase(String.valueOf(i + 1)));
				slNoCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				slNoCell.setPadding(5f);
				table.addCell(slNoCell);
				PdfPCell districtCell = new PdfPCell(new Phrase(entity.getAgState()));
				districtCell.setPadding(5f);
				table.addCell(districtCell);
				PdfPCell branchesCell = new PdfPCell(new Phrase(String.valueOf(entity.getAgBranch().intValue())));
				branchesCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				branchesCell.setPadding(5f);
				table.addCell(branchesCell);
			}
			PdfPCell totalLabelCell = new PdfPCell(new Phrase(TOTAL, headLineFont));
			totalLabelCell.setColspan(2);
			totalLabelCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			totalLabelCell.setPadding(5f);
			table.addCell(totalLabelCell);
			PdfPCell totalValueCell = new PdfPCell(new Phrase(String.valueOf(stateTotalAgBranch), headLineFont));
			totalValueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			totalValueCell.setPadding(5f);
			table.addCell(totalValueCell);
			document.add(table);
			document.add(Chunk.NEWLINE);
			grandTotalDistricts += stateTotalDistricts;
			grandTotalBranches += stateTotalAgBranch;
		}
		Paragraph grandTotalParagraph = new Paragraph("Total Number of Districts: " + grandTotalDistricts,
				headLineFont);
		grandTotalParagraph.setAlignment(Element.ALIGN_LEFT);
		document.add(grandTotalParagraph);

		grandTotalParagraph = new Paragraph("Total Number of Branches: " + grandTotalBranches, headLineFont);
		grandTotalParagraph.setAlignment(Element.ALIGN_LEFT);
		document.add(grandTotalParagraph);
	}

	private void keyDomesticInvestors(PdfPTable table) {

		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase("Sl.\nNo.", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase(PARTICULARS, headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("% age of shares", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		if (!isRRB) {
			cell.setPhrase(new Phrase("No of Members", headLineFont));
			cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			table.addCell(cell);
		}

		Chunk c1 = new Chunk(AMOUNT, headLineFont);
		Chunk c11 = new Chunk(isRRB ? "\n(Rs in crore)" : "\n(Rs in lakh)", italicFont);

		Phrase p1 = new Phrase();
		p1.add(c1);
		p1.add(c11);

		cell.setPhrase(p1);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void keyDomesticInvestorsData(PdfPTable table) {
		List<S2IFVInvestorEntity> dto = investorDTOList.stream()
				.sorted(Comparator.comparingLong(S2IFVInvestorEntity::getKiId)).collect(Collectors.toList());
		int count = 0;
		BigDecimal perTot = BigDecimal.ZERO;
		BigDecimal countTot = BigDecimal.ZERO;
		BigDecimal holdingTot = BigDecimal.ZERO;

		for (S2IFVInvestorEntity investorDTO : dto) {
			if (investorDTO.getKiHolder() != null && !investorDTO.getKiHolder().isBlank()) {

				PdfPCell pKiId = new PdfPCell(new Phrase(Integer.toString(++count), paragraphFont));
				pKiId.setHorizontalAlignment(Element.ALIGN_CENTER);
				pKiId.setPadding(5);
				table.addCell(pKiId);

				PdfPCell pKiHolder = new PdfPCell(new Phrase(investorDTO.getKiHolder(), paragraphFont));
				pKiHolder.setHorizontalAlignment(Element.ALIGN_LEFT);
				pKiHolder.setPadding(5);
				table.addCell(pKiHolder);

				String percShares = "", memCount = "", amount = "";

				if (investorDTO.getKiPproportion() != null) {
					perTot = perTot.add(investorDTO.getKiPproportion());
					percShares = investorDTO.getKiPproportion().toPlainString();
				}
				if (investorDTO.getKiCount() != null) {
					countTot = countTot.add(investorDTO.getKiCount());
					memCount = CommonUtil.formatNumber(investorDTO.getKiCount().stripTrailingZeros().toPlainString());
				}
				if (investorDTO.getKiHolding() != null) {
					holdingTot = holdingTot.add(investorDTO.getKiHolding());
					amount = CommonUtil.formatNumber(investorDTO.getKiHolding().stripTrailingZeros().toPlainString());
				}

				if (investorDTO.getKiHolder().equalsIgnoreCase("Others")
						|| investorDTO.getKiHolder().equalsIgnoreCase("Other")) {
					percShares = "";
					memCount = "";
					amount = "";
				}

				PdfPCell pKpercShares = new PdfPCell(new Phrase(percShares, paragraphFont));
				pKpercShares.setHorizontalAlignment(Element.ALIGN_RIGHT);
				pKpercShares.setPadding(5);
				table.addCell(pKpercShares);

				if (!isRRB) {
					PdfPCell pKCount = new PdfPCell(new Phrase(memCount, paragraphFont));
					pKCount.setHorizontalAlignment(Element.ALIGN_RIGHT);
					pKCount.setPadding(5);
					table.addCell(pKCount);
				}

				PdfPCell pKiPproportion = new PdfPCell(new Phrase(amount, paragraphFont));
				pKiPproportion.setHorizontalAlignment(Element.ALIGN_RIGHT);
				pKiPproportion.setPadding(5);
				table.addCell(pKiPproportion);

			}
		}
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase("", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(TOTAL, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(perTot.stripTrailingZeros().toPlainString(), headLineFont));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		table.addCell(cell);

		if (!isRRB) {
			cell.setPhrase(
					new Phrase(CommonUtil.formatNumber(countTot.stripTrailingZeros().toPlainString()), headLineFont));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);
		}

		cell.setPhrase(
				new Phrase(CommonUtil.formatNumber(holdingTot.stripTrailingZeros().toPlainString()), headLineFont));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		table.addCell(cell);

	}

	private void institutionalBorrowings(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_NO, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Name of the Lender", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Outstanding (Rs in crore)", headLineFont));
		table.addCell(cell);

	}

	private void institutionalBorrowingsData(PdfPTable table) {
		int srNo = 1;
		for (S2IFVInstitutionalEntity institutionalList : institutionalDTOList) {
			PdfPCell srNum = new PdfPCell(new Phrase(String.valueOf(srNo), paragraphFont));
			srNum.setHorizontalAlignment(Element.ALIGN_CENTER);
			srNum.setPadding(5);
			table.addCell(srNum);

			PdfPCell cellParticular = new PdfPCell(
					new Phrase(institutionalList.getInParticular() != null ? institutionalList.getInParticular() : "",
							paragraphFont));

			cellParticular.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellParticular.setPadding(5);
			table.addCell(cellParticular);

			String inAmount = institutionalList.getInAmount() != null
					? CommonUtil.formatNumber(institutionalList.getInAmount().stripTrailingZeros().toPlainString())
					: "";
			PdfPCell cellInAmount = new PdfPCell(new Phrase(inAmount, paragraphFont));
			cellInAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cellInAmount.setPadding(5);
			table.addCell(cellInAmount);
			srNo++;
		}

		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		List<BigDecimal> amountList = institutionalDTOList.stream().map(S2IFVInstitutionalEntity::getInAmount)
				.collect(Collectors.toList());
		BigDecimal total = amountList.stream().map(value -> value == null ? BigDecimal.ZERO : value)
				.reduce(BigDecimal.ZERO, BigDecimal::add);

		cell.setPhrase(new Phrase(""));
		table.addCell(cell);

		cell.setPhrase(new Phrase(TOTAL, headLineFont));
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.addCell(cell);

		PdfPCell cellTotal = new PdfPCell(
				new Phrase(total != null ? CommonUtil.formatNumber(total.stripTrailingZeros().toPlainString()) : "",
						headLineFont));
		cellTotal.setHorizontalAlignment(Element.ALIGN_RIGHT);
		table.addCell(cellTotal);

	}

	private void disclosure(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPaddingTop(5f);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_NO, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(PARTICULARS, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Amount (Rs in crore)", headLineFont));
		table.addCell(cell);

	}

	private void disclosureData(PdfPTable table) {

		int srNo = 1;
		for (DisclosureDivergenceDto dto : disclosureDivergenceDtos) {
			PdfPCell srNum = new PdfPCell(new Phrase(String.valueOf(srNo), paragraphFont));
			srNum.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(srNum);

			PdfPCell cellParticular = new PdfPCell(
					new Phrase(dto.getParticulars() != null ? dto.getParticulars() : "", paragraphFont));
			cellParticular.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cellParticular);

			String amount = dto.getAmount() != null ? dto.getAmount().stripTrailingZeros().toPlainString() : "";

			PdfPCell cellInAmount = new PdfPCell(new Phrase(amount, paragraphFont));
			cellInAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cellInAmount);
			srNo++;
		}

	}

	private void financialHighlight(PdfPTable table) {
		logger.info("started financialHighlight in AppraisalMerged");
		PdfPCell cell = new PdfPCell();
		cell.setPaddingTop(8f);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setPadding(5);

		cell.setPhrase(new Phrase(SL_N + "No.", headLineFont));
		cell.setBorderWidthRight(0.4f);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase(PARTICULARS, headLineFont));
		cell.setBorderWidthRight(0.4f);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase("FY Ended (Audited)"/* +financialHighlightsDTO.getFhFyMarch31() */, headLineFont));
		cell.setPaddingRight(-3f);
		cell.setBorderWidthRight(0);
		cell.setColspan(2);
		table.addCell(cell);

		PdfPCell cellA = new PdfPCell();
		cellA.setPaddingTop(8f);
		cellA.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellA.setPadding(5);

		cellA.setPhrase(new Phrase("YOY(%)", headLineFont));
		cellA.setBorderWidthLeft(0.4f);
		cellA.setBorderWidthBottom(0);
		table.addCell(cellA);

		Optional<S2IFVFinancialHighlightsEntity> fyResultMonth = highlightsDTOList.stream()
				.filter(e -> e.getFhFyResults() != null || e.getMonths() != null).findAny();

		S2IFVFinancialHighlightsEntity Result = null;
		int fyResultIn = 0;
		String months = "";
		BigDecimal fyResult = BigDecimal.ZERO;
		if (fyResultMonth.isPresent()) {
			Result = fyResultMonth.get();
			if (Result.getFhFyResults() != null) {
				fyResult = Result.getFhFyResults();
			}
			if (Result.getMonths() != null) {
				months = Result.getMonths();
				fyResultIn = fyResult.intValue();
			}

		}

		if (fyResult.intValue() > 0) {
			cellA.setPhrase(new Phrase("FY " + fyResultIn + "\n" + months, headLineFont));
			cellA.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellA.setBorderWidthRight(0.4f);
			table.addCell(cellA);

		}

		PdfPCell cellB = new PdfPCell();
		cellB.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellB.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellB.setPadding(5);

		cellB.setPhrase(new Phrase(" ", headLineFont));
		cellB.setBorderWidthTop(0);
		cellB.setBorderWidthRight(0.4f);
		cellB.setBorderWidthLeft(0.4f);
		cellB.setPaddingTop(-2f);
		table.addCell(cellB);

		cellB.setPhrase(new Phrase(" ", headLineFont));
		cellB.setBorderWidthRight(0.4f);
		cellB.setBorderWidthLeft(0.4f);
		cellB.setBorderWidthTop(0);
		cellB.setPaddingTop(-2f);
		table.addCell(cellB);

		Optional<S2IFVFinancialHighlightsEntity> dto = highlightsDTOList.stream()
				.filter(e -> e.getCurrentYearValue() != null && e.getPreviousYearValue() != null).findAny();

		S2IFVFinancialHighlightsEntity financialHighlightsData = new S2IFVFinancialHighlightsEntity();

		if (dto.isPresent()) {
			financialHighlightsData = dto.get();
		}

		cellB.setPhrase(new Phrase(financialHighlightsData.getCurrentYearValue() + "", headLineFont));
		cellB.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellB.setBorderWidthTop(0.4f);
		cellB.setPaddingTop(8f);
		table.addCell(cellB);

		cellB.setPhrase(new Phrase(financialHighlightsData.getPreviousYearValue() + "", headLineFont));
		cellB.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellB.setBorderWidthTop(0.4f);
		cellB.setPaddingTop(8f);
		table.addCell(cellB);

		cellB.setPhrase(new Phrase("    ", headLineFont));
		cellB.setBorderWidthTop(0);
		table.addCell(cellB);

		if (fyResult.intValue() > 0) {
			cellB.setPhrase(new Phrase("*result\n" + "(unaudited)", headLineFont));
			cellB.setPadding(5f);
			cellB.setBorderWidthRight(0.4f);
			cellB.setBorderWidthLeft(0.4f);
			cellB.setBorderWidthTop(0);
			table.addCell(cellB);

		}
	}

	private void financialHighlightData(PdfPTable table) {
		List<S2IFVFinancialHighlightsEntity> list = highlightsDTOList.stream()
				.sorted(Comparator.comparingLong(S2IFVFinancialHighlightsEntity::getFhId)).collect(Collectors.toList());

		int count = 1;
		int finY = 0;

		Optional<S2IFVFinancialHighlightsEntity> highlightEntity = highlightsDTOList.stream()
				.filter(e -> e.getFhFyResults() != null).findAny();

		if (highlightEntity.isPresent()) {
			S2IFVFinancialHighlightsEntity entity = highlightEntity.get();
			finY = entity.getFhFyResults() != null ? entity.getFhFyResults().intValue() : 0;
		}

		int objCount = 0;

		for (S2IFVFinancialHighlightsEntity financialHighlightsDTO : list) {
			PdfPCell pSrNo = new PdfPCell(new Phrase(String.valueOf(count), paragraphFont));
			pSrNo.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pSrNo);

			PdfPCell pFhParticular = new PdfPCell(
					new Phrase(String.valueOf(financialHighlightsDTO.getFhParticular()), paragraphFont));
			pFhParticular.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(pFhParticular);

			BigDecimal fyOne = financialHighlightsDTO.getFhFy1() == null ? BigDecimal.ZERO
					: financialHighlightsDTO.getFhFy1();

			BigDecimal strippedFyOne = fyOne.stripTrailingZeros();

			String fyOneInString = "";

			if (objCount < 9) {
				fyOneInString = CommonUtil.formatNumber(fyOne.toBigInteger().toString());
			} else {
				fyOneInString = strippedFyOne.scale() > 0 ? CommonUtil.formatNumber(fyOne.toPlainString())
						: CommonUtil.formatNumber(strippedFyOne.toPlainString());
			}

			PdfPCell pFhFy1 = new PdfPCell(new Phrase(fyOneInString, paragraphFont));
			pFhFy1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pFhFy1);

			BigDecimal fyTwo = financialHighlightsDTO.getFhFy2() == null ? BigDecimal.ZERO
					: financialHighlightsDTO.getFhFy2();

			BigDecimal strippedFyTwo = fyTwo.stripTrailingZeros();

			String fy2InString = "";

			if (objCount < 9) {
				fy2InString = CommonUtil.formatNumber(fyTwo.toBigInteger().toString());
			} else {
				fy2InString = strippedFyTwo.scale() > 0 ? CommonUtil.formatNumber(fyTwo.toPlainString())
						: CommonUtil.formatNumber(strippedFyTwo.toPlainString());
			}

			PdfPCell pFhFy2 = new PdfPCell(new Phrase(fy2InString, paragraphFont));
			pFhFy2.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pFhFy2);

			BigDecimal fyYoY = financialHighlightsDTO.getFhYoy() == null ? BigDecimal.ZERO
					: financialHighlightsDTO.getFhYoy();

			BigDecimal strippedFyYoY = fyYoY.stripTrailingZeros();

			PdfPCell pFhYoy = new PdfPCell(
					new Phrase(strippedFyYoY.scale() > 0 ? CommonUtil.formatNumber(fyYoY.toPlainString())
							: CommonUtil.formatNumber(strippedFyYoY.toPlainString()), paragraphFont));
			pFhYoy.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pFhYoy);

			if (finY > 0) {
				BigDecimal fhFhFy3 = financialHighlightsDTO.getFhFy3();
				if (fhFhFy3 == null || fhFhFy3.compareTo(BigDecimal.ZERO) == 0) {
					PdfPCell pFhFy3 = new PdfPCell(new Phrase("-", paragraphFont));
					pFhFy3.setHorizontalAlignment(Element.ALIGN_RIGHT);
					table.addCell(pFhFy3);
				} else {

					BigDecimal strippedFyThree = fhFhFy3.stripTrailingZeros();

					PdfPCell pFhFy3 = new PdfPCell(
							new Phrase(strippedFyThree.scale() > 0 ? CommonUtil.formatNumber(fhFhFy3.toPlainString())
									: CommonUtil.formatNumber(strippedFyThree.toPlainString()), paragraphFont));
					pFhFy3.setHorizontalAlignment(Element.ALIGN_RIGHT);
					table.addCell(pFhFy3);
				}
			}
			count++;
			++objCount;
		}

	}

	private void collectionEfficiency(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase("Particulars.", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Collection Efficiency (%)", headLineFont));
		table.addCell(cell);
	}

	private void collectionEfficiencyData1(PdfPTable table) {
		PdfPCell cell1 = new PdfPCell();
		cell1.setPadding(5f);
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setPhrase(new Phrase("Year", headLineFont));
		table.addCell(cell1);

		List<CollectionEfficiencyEntity> dto = collectionEfficiencyDto.stream().collect(Collectors.toList());
		for (CollectionEfficiencyEntity collectionEfficienc : dto) {
			PdfPCell cell = new PdfPCell();
			cell.setPadding(5f);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setPhrase(new Phrase(collectionEfficienc.getParticulars(), headLineFont));
			table.addCell(cell);
		}

	}

	private void collectionEfficiencyData2(PdfPTable table) {
		PdfPCell cell2 = new PdfPCell();
		cell2.setPadding(5f);
		cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell2.setPhrase(new Phrase("Collection Efficiency", headLineFont));
		table.addCell(cell2);

		List<CollectionEfficiencyEntity> dto = collectionEfficiencyDto.stream().collect(Collectors.toList());
		for (CollectionEfficiencyEntity collectionEfficienc : dto) {
			PdfPCell cell = new PdfPCell();
			cell.setPadding(5f);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setPhrase(new Phrase(String.valueOf(collectionEfficienc.getCollectionEfficiency()), paragraphFont));
			table.addCell(cell);
		}

	}

	private void collectionEfficiencyData(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		List<CollectionEfficiencyEntity> dto = collectionEfficiencyDto.stream().collect(Collectors.toList());

		for (CollectionEfficiencyEntity collectionEfficienc : dto) {
			cell.setPhrase(new Phrase(collectionEfficienc.getParticulars(), headLineFont));
			table.addCell(cell);

			cell.setPhrase(new Phrase(String.valueOf(collectionEfficienc.getCollectionEfficiency()), headLineFont));
			table.addCell(cell);
		}
	}

	private void restructuredAssets(PdfPTable table) {
		PdfPCell cellA = new PdfPCell();
		cellA.setPadding(5f);
		cellA.setHorizontalAlignment(Element.ALIGN_CENTER);

		cellA.setPhrase(new Phrase("Date", headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase("No of A/cs", headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase(AMOUNT, headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

	}

	private void restructuredAssetsData(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		for (RestructuredAssetsDTO dto : restructuredAssetsDto) {

			String rsDateFormattedrdate = "";
			Date eRsDate = dto.getRsDate();
			if (eRsDate != null) {
				DateTimeFormatter formateeRsDate = DateTimeFormatter.ofPattern(DATE_FORMAT2);
				LocalDate Formatterdate = eRsDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				rsDateFormattedrdate = Formatterdate.format(formateeRsDate);
			}

			cell.setPhrase(new Phrase(String.valueOf(rsDateFormattedrdate), paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			cell.setPhrase(
					new Phrase(String.valueOf(dto.getNoOfAccounts() != null ? dto.getNoOfAccounts() : BigDecimal.ZERO),
							paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);

			String amount = dto.getRsAmount() != null ? CommonUtil.formatNumber(dto.getRsAmount().toPlainString()) : "";

			cell.setPhrase(new Phrase(amount, paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);

		}

	}

	private void boardApprovedCriteria(PdfPTable table) {
		String FormattedeEcGsecDate = "";
		String FormattedRmseDate = "";

		Date EcGsecDate = eligibilityEntitiesDTOList.getEcGsecDate() != null
				? eligibilityEntitiesDTOList.getEcGsecDate()
				: null;
		Date EcRmseDate = eligibilityEntitiesDTOList.getEcRmseDate() != null
				? eligibilityEntitiesDTOList.getEcRmseDate()
				: null;
		if (EcGsecDate != null) {
			DateTimeFormatter formateEcGsecDate = DateTimeFormatter.ofPattern(DATE_FORMAT2);
			LocalDate DateCollection = EcGsecDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			FormattedeEcGsecDate = DateCollection.format(formateEcGsecDate);

		}
		if (EcRmseDate != null) {
			DateTimeFormatter formateEcGsecDate = DateTimeFormatter.ofPattern(DATE_FORMAT2);
			LocalDate DateCollectionEcRmseDate = EcRmseDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			FormattedRmseDate = DateCollectionEcRmseDate.format(formateEcGsecDate);
		}
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPCell cellA = new PdfPCell();
		cellA.setPadding(5);
		cellA.setBorderWidthRight(0);
		cellA.setBorderWidthLeft(1);
		cellA.setBackgroundColor(BaseColor.WHITE);
		cellA.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellA.setPhrase(new Phrase("i.", underlineTextFont));
		cellA.setPaddingBottom(7f);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase("Board approved criteria & compliance", underlineTextFont));
		cellA.setBorderWidthRight(0);
		cellA.setBorderWidthLeft(0);
		cellA.setPaddingBottom(8f);
		cellA.setPaddingLeft(4f);
		cellA.setBackgroundColor(BaseColor.WHITE);
		cellA.setHorizontalAlignment(Rectangle.LEFT);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase("", paragraphFont));
		cellA.setBorderWidthRight(1);
		cellA.setBorderWidthLeft(0);
		cellA.setBackgroundColor(BaseColor.WHITE);
		cellA.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cellA);

		cell.setPhrase(new Phrase("1", paragraphFont));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);

		PdfPCell cellB = new PdfPCell();
		cellB.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellB.setPadding(5);
		cellB.setPaddingTop(-2);
		cellB.setHorizontalAlignment(Element.ALIGN_JUSTIFIED_ALL);
		Phrase phB = new Phrase("Assistance against existing assets:", underlineTextFont);
		Phrase phB1 = new Phrase("Refinance will be on reimbursement basis"
				+ " against existing assets. Amount equivalent to " + "outstanding portfolio of loans and advances"
				+ " (i.e., terms loans and working capital advances) "
				+ "for eligible activities, in which disbursements " + "have been made to existing/ new MSEs up to 12"
				+ " months before date of application for refinance by PLIs. \n", paragraphFont);
		cellB.addElement(phB);
		cellB.addElement(phB1);
		table.addCell(cellB);

		Phrase phEcAssstance = new Phrase(eligibilityEntitiesDTOList.getEcRmseAssistance() != null
				? eligibilityEntitiesDTOList.getEcRmseAssistance()
				: "" + "\n\n", paragraphFont);
		Phrase phEcAssstanceStatus = new Phrase(
				eligibilityEntitiesDTOList.getEcRmseStatus() != null ? eligibilityEntitiesDTOList.getEcRmseStatus()
						: "",
				headLineFont);
		cell.addElement(phEcAssstance);
		cell.addElement(phEcAssstanceStatus);
		cell.setBackgroundColor(BaseColor.WHITE);
		table.addCell(cell);

		cell.setPhrase(new Phrase("2", paragraphFont));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		PdfPCell cellC = new PdfPCell();
		cellC.setPaddingTop(-2);
		cellC.setPadding(5);
		cellC.setBackgroundColor(BaseColor.LIGHT_GRAY);
		Phrase phC = new Phrase("Assistance for creation of incremental assets:", underlineTextFont);
		Phrase phC1 = new Phrase(
				"Commitment for concessional funds under " + "the facility will be given to PLIs against their "
						+ "application indicating the anticipated utilisation. "
						+ "Such commitment would be generally valid for 3 to 6 months.\n",
				paragraphFont);
		cellC.addElement(phC);
		cellC.addElement(phC1);
		cellC.setPaddingTop(-2);
		table.addCell(cellC);

		Phrase phFabiaRemarks = new Phrase(
				eligibilityEntitiesDTOList.getEcAssstance() != null ? eligibilityEntitiesDTOList.getEcAssstance()
						: "" + "\n\n",
				paragraphFont);
		Phrase phFabiaRemarksStatus = new Phrase(eligibilityEntitiesDTOList.getEcAssstanceStatus() != null
				? eligibilityEntitiesDTOList.getEcAssstanceStatus()
				: "", headLineFont);
		cell.addElement(phFabiaRemarks);
		cell.addElement(phFabiaRemarksStatus);
		cell.setBackgroundColor(BaseColor.WHITE);
		table.addCell(cell);

		PdfPCell cellA1 = new PdfPCell();
		cellA1.setPadding(5);
		cellA1.setBorderWidthRight(0);
		cellA1.setBorderWidthLeft(1);
		cellA1.setBackgroundColor(BaseColor.WHITE);
		cellA1.setPhrase(new Phrase("ii", underlineTextFont));
		cellA1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cellA1);

		cellA1.setPhrase(new Phrase("RBI Criteria and Compliance ", underlineTextFont));
		cellA1.setBorderWidthRight(0);
		cellA1.setBorderWidthLeft(0);
		cellA1.setPaddingBottom(7f);
		cellA1.setBackgroundColor(BaseColor.WHITE);
		cellA1.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.addCell(cellA1);

		cellA1.setPhrase(new Phrase("", paragraphFont));
		cellA1.setBorderWidthRight(1);
		cellA1.setBorderWidthLeft(0);
		cellA1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cellA1);

		cell.setPhrase(new Phrase("3", paragraphFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);

		String ecGsecPercent = eligibilityEntitiesDTOList.getEcGsecPercent() != null
				? eligibilityEntitiesDTOList.getEcGsecPercent().stripTrailingZeros().toPlainString()
				: "";

		PdfPCell cellD = new PdfPCell();
		cellD.setPadding(5);
		cellD.setPaddingTop(-2);
		cellD.setBackgroundColor(BaseColor.LIGHT_GRAY);
		Phrase phD1 = new Phrase(
				"Lending rate to ultimate borrowers by eligible institutions should be up to 350 bps / 450 bps over the External Benchmark "
						+ "“10-year G-Sec yield” under Regular / ICDD scheme respectively. " + "\n" + "Note: " + "\n"
						+ "          • The yield as on the last day of the " + "quarter may be used to consider the "
						+ "eligibility of bank loans of refinance for" + " the ensuing quarter" + "\n"
						+ "10 year G-Sec yield as on " + FormattedeEcGsecDate + " was " + ecGsecPercent + "%.",
				paragraphFont);
		cellD.addElement(phD1);
		table.addCell(cellD);

		Phrase phRbiCompliance = new Phrase(eligibilityEntitiesDTOList.getEcRbiCompliance() != null
				? eligibilityEntitiesDTOList.getEcRbiCompliance()
				: "" + "\n\n", paragraphFont);
		Phrase phEcRbiStatus = new Phrase(
				eligibilityEntitiesDTOList.getEcRbiStatus() != null ? eligibilityEntitiesDTOList.getEcRbiStatus() : "",
				headLineFont);
		cell.addElement(phRbiCompliance);
		cell.addElement(phEcRbiStatus);
		cell.setBackgroundColor(BaseColor.WHITE);
		table.addCell(cell);

		cell.setPhrase(new Phrase("4", paragraphFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		PdfPCell cellE = new PdfPCell();
		cellE.setPadding(5);
		cellE.setPaddingTop(-2);
		cellE.setBackgroundColor(BaseColor.LIGHT_GRAY);

		String fixedRate = eligibilityEntitiesDTOList.getEcSdbiFixed() != null
				? eligibilityEntitiesDTOList.getEcSdbiFixed().stripTrailingZeros().toPlainString()
				: "";
		Phrase phSpread = new Phrase("SIDBI spread is fixed at " + fixedRate + " bps over and"
				+ " above the cost of borrowing under MSE" + " Refinance Fund.", paragraphFont);
		cellE.addElement(phSpread);
		table.addCell(cellE);

		String sts = eligibilityEntitiesDTOList.getEcSidbiRemarks() != null
				? eligibilityEntitiesDTOList.getEcSidbiRemarks()
				: "";

		Phrase phEcIcddRemarks = new Phrase(sts + "\n\n", paragraphFont);
		Phrase phEcNnpaStatus = new Phrase(
				eligibilityEntitiesDTOList.getEcSidbiStatus() != null ? eligibilityEntitiesDTOList.getEcSidbiStatus()
						: "",
				headLineFont);
		cell.addElement(phEcIcddRemarks);
		cell.addElement(phEcNnpaStatus);
		cell.setBackgroundColor(BaseColor.WHITE);
		table.addCell(cell);

		List<String> rmseSchemeList;

		if (isRRB) {
			rmseSchemeList = new ArrayList<>();
			rmseSchemeList.add("RMSE- (Regular)");
			rmseSchemeList.add("RMSE- (ICDD)");
		} else {
			rmseSchemeList = proposedSchemaDetails.stream()
					.filter(e -> e.getPrFundname().toUpperCase().contains("RMSE"))
					.filter(e -> !e.getPrFundname().toUpperCase().contains("ICDD")).map(e -> e.getPrFundname())
					.distinct().collect(Collectors.toCollection(ArrayList::new));
			rmseSchemeList.add("RMSE- (ICDD)");
		}

		if (rmseSchemeList.size() > 0) {

			int start = 4;

			// Initialize the first scheme
			cell.setPhrase(new Phrase(Integer.toString(++start), paragraphFont));
			cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			table.addCell(cell);
			String scheme1Data = "Eligibility as per RBI letter dated " + FormattedRmseDate
					+ ", for having achieved PSL target for lending to Micro enterprise in FY "
					+ eligibilityEntitiesDTOList.getEcRmsEmiCrofy() + ".";
			String rmse1Data = StringUtils.hasText(eligibilityEntitiesDTOList.getRmse1Data())
					? eligibilityEntitiesDTOList.getRmse1Data()
					: scheme1Data;

			addSchemeInfoToTable(table, rmseSchemeList, 0, rmse1Data, eligibilityEntitiesDTOList.getEcRmseRemarks(),
					eligibilityEntitiesDTOList.getEcRmseStatus1(), paragraphFont, underlineTextFont, headLineFont);

			// Loop for additional schemes if available
			for (int i = 1; i < rmseSchemeList.size(); i++) {
				cell.setPhrase(new Phrase(Integer.toString(++start), paragraphFont));
				cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
				table.addCell(cell);
				String schemeData = "";
				switch (i) {
				case 1:
					schemeData = "Availability of assets in the 196 identified credit deficient districts.";
					break;
				default:
					break;
				}
				String rmseData = switch (i) {
				case 1 -> StringUtils.hasText(eligibilityEntitiesDTOList.getRmse2Data())
						? eligibilityEntitiesDTOList.getRmse2Data()
						: schemeData;
				case 2 -> StringUtils.hasText(eligibilityEntitiesDTOList.getRmse3Data())
						? eligibilityEntitiesDTOList.getRmse3Data()
						: "";
				case 3 -> StringUtils.hasText(eligibilityEntitiesDTOList.getRmse4Data())
						? eligibilityEntitiesDTOList.getRmse4Data()
						: "";
				case 4 -> StringUtils.hasText(eligibilityEntitiesDTOList.getRmse5Data())
						? eligibilityEntitiesDTOList.getRmse5Data()
						: "";
				default -> "";
				};
				String remarks = switch (i) {
				case 1 -> eligibilityEntitiesDTOList.getEcIcddRemarks();
				case 2 -> eligibilityEntitiesDTOList.getRmse3Remarks();
				case 3 -> eligibilityEntitiesDTOList.getRmse4Remarks();
				case 4 -> eligibilityEntitiesDTOList.getRmse5Remarks();
				default -> null;
				};
				String status = switch (i) {
				case 1 -> eligibilityEntitiesDTOList.getEcIcddStatus();
				case 2 -> eligibilityEntitiesDTOList.getRmse3Status();
				case 3 -> eligibilityEntitiesDTOList.getRmse4Status();
				case 4 -> eligibilityEntitiesDTOList.getRmse5Status();
				default -> "";
				};

				if (StringUtils.hasText(rmseData)) {
					addSchemeInfoToTable(table, rmseSchemeList, i, rmseData, remarks, status, paragraphFont,
							underlineTextFont, headLineFont);
				}

			}
		}
	}

	private PdfPCell createCellWithPadding(float padding, float paddingTop, BaseColor bgColor) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(padding);
		cell.setPaddingTop(paddingTop);
		cell.setBackgroundColor(bgColor);
		return cell;
	}

	private void addSchemeInfoToTable(PdfPTable table, List<String> rmseSchemeList, int index, String rmseData,
			String remarks, String status, Font paragraphFont, Font underlineTextFont, Font headLineFont) {
		PdfPCell cell = createCellWithPadding(5, -2, BaseColor.LIGHT_GRAY);
		// Add Scheme name
		Phrase schemeName = new Phrase(this.getSchemeName(rmseSchemeList.get(index)), underlineTextFont);
		cell.addElement(schemeName);
		// Add RMSE Data
		Phrase rmsePhrase = new Phrase(rmseData, paragraphFont);
		cell.addElement(rmsePhrase);
		table.addCell(cell);
		// Add Remarks and Status
		PdfPCell statusCell = createCellWithPadding(5, 0, BaseColor.WHITE);
		Phrase remarksPhrase = new Phrase(remarks != null ? remarks : "" + "\n\n", paragraphFont);
		Phrase statusPhrase = new Phrase(status, headLineFont);
		statusCell.addElement(remarksPhrase);
		statusCell.addElement(statusPhrase);
		table.addCell(statusCell);
	}

	private void pastDisbursement(PdfPTable table) {
		logger.info("started pastDisbursement in AppraisalMerged");
		PdfPCell cell = new PdfPCell();
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);

		cell.setPhrase(new Phrase(SL_N2, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(PERIOD_FY, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Date", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(AMOUNT, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(SCHEME, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("RoI", headLineFont));
		table.addCell(cell);

		Chunk c3 = new Chunk(TENURE, headLineFont);
		Chunk c33 = new Chunk("\n(Months)", italicFont);

		Phrase p3 = new Phrase();
		p3.add(c3);
		p3.add(c33);

		cell.setPhrase(p3);
		table.addCell(cell);

	}

	private void pastDisbursementData(PdfPTable table) {
		int count = 0;

		for (S2IFVAssPastdisbEntity assPastdisbDTO : assPastdisbDTOList) {

			PdfPCell slNo = new PdfPCell(new Phrase(String.valueOf(++count), paragraphFont));
			slNo.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(slNo);

			PdfPCell pAePeriodfy = new PdfPCell(
					new Phrase(String.valueOf(assPastdisbDTO.getAePeriodfy()), paragraphFont));
			pAePeriodfy.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pAePeriodfy);
			String aeFormattedDate = "";

			Date aeDate = assPastdisbDTO.getAeDate();
			if (aeDate != null) {
				DateTimeFormatter AeDateFormate = DateTimeFormatter.ofPattern(DATE_FORMAT2);
				LocalDate LocalAeDate = aeDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				aeFormattedDate = AeDateFormate.format(LocalAeDate);
			}
			PdfPCell pAeDate = new PdfPCell(new Phrase(aeFormattedDate, paragraphFont));
			pAeDate.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pAeDate);

			String formattedPastAmt = assPastdisbDTO.getAeAmount() != null
					? CommonUtil.formatNumber(assPastdisbDTO.getAeAmount().toPlainString())
					: "";

			PdfPCell pAeAmount = new PdfPCell(new Phrase(formattedPastAmt, paragraphFont));
			pAeAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pAeAmount);

			PdfPCell pAeScheme = new PdfPCell(new Phrase(assPastdisbDTO.getAeScheme(), paragraphFont));
			pAeScheme.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pAeScheme);

			BigDecimal aeRoi = assPastdisbDTO.getAeRoi() != null ? assPastdisbDTO.getAeRoi() : BigDecimal.ZERO;
			PdfPCell pAeRoi = new PdfPCell(new Phrase(String.valueOf(aeRoi), paragraphFont));
			pAeRoi.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pAeRoi);

			String aeTenure = "";
			if (assPastdisbDTO.getAeTenure() != null) {
				aeTenure = assPastdisbDTO.getAeTenure();
			}
			PdfPCell pAeTenure = new PdfPCell(new Phrase(String.valueOf(aeTenure), paragraphFont));
			pAeTenure.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pAeTenure);

		}

	}

	private void outstanding(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);

		cell.setPhrase(new Phrase(SL_N2, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(PERIOD_FY, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("O/S at the" + " begining " + "of the year", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(AMOUNT + " Disbursed", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Repaid", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("O/S at the" + " end of the" + " period", headLineFont));
		table.addCell(cell);

	}

	private void outstandingData(PdfPTable table) {
		int count = 0;
		for (S2IFVAssOutstandingEntity assOutstandingDTO : assOutstandingDTOList) {

			PdfPCell slNo = new PdfPCell(new Phrase(String.valueOf(++count), paragraphFont));
			slNo.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(slNo);

			PdfPCell pOsPeriodFy = new PdfPCell(
					new Phrase(String.valueOf(assOutstandingDTO.getOsPeriodFy()), paragraphFont));

			pOsPeriodFy.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pOsPeriodFy);

			String formattedOsYear = assOutstandingDTO.getOsYear() != null
					? CommonUtil.formatNumber(assOutstandingDTO.getOsYear().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pOsYear = new PdfPCell(new Phrase(formattedOsYear, paragraphFont));
			pOsYear.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pOsYear);

			String formattedOsAmountDisb = assOutstandingDTO.getOsAmountDisb() != null
					? CommonUtil.formatNumber(assOutstandingDTO.getOsAmountDisb().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pOsAmountDisb = new PdfPCell(new Phrase(formattedOsAmountDisb, paragraphFont));
			pOsAmountDisb.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pOsAmountDisb);

			String formattedOsRepaid = assOutstandingDTO.getOsRepaid() != null
					? CommonUtil.formatNumber(assOutstandingDTO.getOsRepaid().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pOsRepaid = new PdfPCell(new Phrase(formattedOsRepaid, paragraphFont));
			pOsRepaid.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pOsRepaid);

			String formattedOsEnd = assOutstandingDTO.getOsEnd() != null
					? CommonUtil.formatNumber(assOutstandingDTO.getOsEnd().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pOsEnd = new PdfPCell(new Phrase(formattedOsEnd, paragraphFont));
			pOsEnd.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pOsEnd);

		}

	}

	private void futureRepaymentsOutstanding(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);

		cell.setPhrase(new Phrase(SL_N2, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(PERIOD_FY, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Q1", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Q2", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Q3", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Q4", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Total \n Repayment", headLineFont));
		table.addCell(cell);

	}

	private void futureRepaymentsOutstandingData(PdfPTable table) {

		int count = 0;
		BigDecimal total = BigDecimal.ZERO;
		for (S2IFVAssRepaymentsEntity assRepaymentsDTO : assRepaymentsDTOList) {

			PdfPCell slNo = new PdfPCell(new Phrase(String.valueOf(++count), paragraphFont));
			slNo.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(slNo);

			PdfPCell pOsPeriodFy = new PdfPCell(new Phrase(
					String.valueOf(assRepaymentsDTO.getRpPeriodfy() != null ? assRepaymentsDTO.getRpPeriodfy() : 0),
					paragraphFont));
			pOsPeriodFy.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pOsPeriodFy);

			String formattedQ1 = assRepaymentsDTO.getRpQ1() != null
					? CommonUtil.formatNumber(assRepaymentsDTO.getRpQ1().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pRpQ1 = new PdfPCell(new Phrase(formattedQ1, paragraphFont));
			pRpQ1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pRpQ1);

			String formattedQ2 = assRepaymentsDTO.getRpQ2() != null
					? CommonUtil.formatNumber(assRepaymentsDTO.getRpQ2().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pRpQ2 = new PdfPCell(new Phrase(formattedQ2, paragraphFont));
			pRpQ2.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pRpQ2);

			String formattedQ3 = assRepaymentsDTO.getRpQ3() != null
					? CommonUtil.formatNumber(assRepaymentsDTO.getRpQ3().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pRpQ3 = new PdfPCell(new Phrase(formattedQ3, paragraphFont));
			pRpQ3.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pRpQ3);

			String formattedQ4 = assRepaymentsDTO.getRpQ4() != null
					? CommonUtil.formatNumber(assRepaymentsDTO.getRpQ4().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pRpQ4 = new PdfPCell(new Phrase(formattedQ4, paragraphFont));
			pRpQ4.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pRpQ4);

			String formattedTotal = assRepaymentsDTO.getRpTotal() != null
					? CommonUtil.formatNumber(assRepaymentsDTO.getRpTotal().stripTrailingZeros().toPlainString())
					: "";

			PdfPCell pRpTotal = new PdfPCell(new Phrase(formattedTotal, paragraphFont));
			pRpTotal.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pRpTotal);

			total = total.add(assRepaymentsDTO.getRpTotal() != null ? assRepaymentsDTO.getRpTotal() : BigDecimal.ZERO);
		}

		PdfPCell cell = new PdfPCell();
		cell.setPadding(4);
		cell.setColspan(2);
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setPhrase(new Phrase(TOTAL, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase(
				CommonUtil.formatNumber(total.stripTrailingZeros().setScale(2, RoundingMode.HALF_UP).toPlainString()),
				headLineFont));
		cell.setColspan(5);
		table.addCell(cell);

	}

	private void amountRateOfIntrest(PdfPTable table, boolean interestResetExists) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(3);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);

		cell.setPhrase(new Phrase(SCHEME, headLineFont));
		table.addCell(cell);

		Chunk c1 = new Chunk(AMOUNT, headLineFont);
		Chunk c11 = new Chunk("\n(Rs in crore)", italicFont);

		Phrase p1 = new Phrase();
		p1.add(c1);
		p1.add(c11);

		cell.setPhrase(p1);
		table.addCell(cell);

		Chunk c2 = new Chunk("Rate of Interest", headLineFont);
		Chunk c22 = new Chunk("\n(% p.a.)", italicFont);

		Phrase p2 = new Phrase();
		p2.add(c2);
		p2.add(c22);

		cell.setPhrase(p2);
		table.addCell(cell);

		if (interestResetExists) {
			cell.setPhrase(new Phrase("Interest Reset", headLineFont));
			table.addCell(cell);
		}

		Chunk c3 = new Chunk(TENURE, headLineFont);
		Chunk c33 = new Chunk("\n(Months)", italicFont);

		Phrase p3 = new Phrase();
		p3.add(c3);
		p3.add(c33);

		cell.setPhrase(p3);
		table.addCell(cell);

	}

	private void amountRateOfIntrestData(PdfPTable table, boolean interestResetExists) {

		BigDecimal total = BigDecimal.ZERO;

		for (S2IFVProposedSchemaEntity schemaDTO : proposedSchemaDto) {

			String schemeName = "";

			if (schemaDTO.getPrFundname().toLowerCase().contains("rmse")) {
				schemeName = this.getSchemeName(schemaDTO.getPrFundname());
			} else {
				schemeName = schemaDTO.getPrSchemeName();
			}

			PdfPCell pPrSchemeName = new PdfPCell(new Phrase(schemeName, paragraphFont));
			pPrSchemeName.setHorizontalAlignment(Element.ALIGN_LEFT);
			pPrSchemeName.setPadding(5);
			pPrSchemeName.setPaddingLeft(10);
			table.addCell(pPrSchemeName);

			String formattedAmt = schemaDTO.getPrAmount() != null
					? CommonUtil.formatNumber(formatAmount(schemaDTO.getPrAmount()))
					: "";

			PdfPCell pScAmount = new PdfPCell(new Phrase(formattedAmt, paragraphFont));
			pScAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pScAmount);

			String benchMark = schemaDTO.getBenchMark();

			if (benchMark != null && !benchMark.isBlank()) {

				String repoNote = null;

				if (benchMark.toUpperCase().contains(REPO_RATE)) {
					benchMark = RBI_REPO_RATE;
					repoNote = schemaDTO.getRoiNote();
				}

				StringBuilder stringBuilder = new StringBuilder(benchMark);

				if (schemaDTO.getSpread() != null && !schemaDTO.getSpread().isBlank()) {
					stringBuilder.append(" + " + schemaDTO.getSpread() + " bps");

				}

				if (schemaDTO.getInterestType() != null && !schemaDTO.getInterestType().isBlank()) {
					stringBuilder.append("\n(" + schemaDTO.getInterestType() + ")");

				}

				if (repoNote != null && !repoNote.isEmpty()) {
					stringBuilder.append("\n(" + repoNote + ")");
				}

				PdfPCell cellRoi = new PdfPCell(new Phrase(stringBuilder.toString(), paragraphFont));
				cellRoi.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(cellRoi);
			} else {
				String roi = schemaDTO.getPrRoi() != null ? formatRoi(schemaDTO.getPrRoi()) : "";
				if (schemaDTO.getInterestType() != null && !schemaDTO.getInterestType().isBlank()) {
					roi += "\n(" + schemaDTO.getInterestType() + ")";
				}
				PdfPCell cellRoi = new PdfPCell(new Phrase(roi, paragraphFont));
				cellRoi.setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(cellRoi);
			}

			if (interestResetExists) {
				PdfPCell intReset = new PdfPCell(new Phrase(
						schemaDTO.getInterestReset() != null ? schemaDTO.getInterestReset() : "", paragraphFont));
				intReset.setHorizontalAlignment(Element.ALIGN_LEFT);
				intReset.setPadding(5);
				intReset.setPaddingLeft(10);
				table.addCell(intReset);
			}

			int month = 0;
			BigDecimal tenure = schemaDTO.getPrTenure() != null ? schemaDTO.getPrTenure() : BigDecimal.ZERO;
			month = tenure.intValue();
			String tenureInString = String.valueOf(month);
			if (schemeName.contains("RMSE")) {
				tenureInString += "\n(Approx.)";
			}
			PdfPCell pScTenure = new PdfPCell(new Phrase(tenureInString, paragraphFont));
			pScTenure.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(pScTenure);

			total = total.add(schemaDTO.getPrAmount() != null ? schemaDTO.getPrAmount() : BigDecimal.ZERO);
		}

		PdfPCell cell = new PdfPCell();
		cell.setPadding(4);
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setPhrase(new Phrase(TOTAL, headLineFont));
		table.addCell(cell);

		String formattedTotAmt = total != null ? CommonUtil.formatNumber(formatAmount(total)) : "";

		cell.setPhrase(new Phrase(formattedTotAmt, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("", headLineFont));
		cell.setColspan(3);
		table.addCell(cell);

	}

	private void repaymentTerms(PdfPTable table) {
		logger.info("started repaymentTerms in AppraisalMerged");
		PdfPCell cell = new PdfPCell();
		cell.setPadding(3);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);

		cell.setPhrase(new Phrase(SCHEME, headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Principal " + "Repayment", headLineFont));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Interest " + "Payment", headLineFont));
		table.addCell(cell);

	}

	private void repaymentTermsData(PdfPTable table) {

		Map<Long, ProposedSchemaDTO> map = proposedSchemaDetails.stream()
				.collect(Collectors.toMap(ProposedSchemaDTO::getPrId, Function.identity()));

		for (S2IFVPrincipalEntity dto : principalDTOList) {

			String schemeName1 = "";

			ProposedSchemaDTO prDto = map.get(dto.getPrId());

			if (prDto.getPrFundname().toLowerCase().contains("rmse")) {
				schemeName1 = this.getSchemeName(prDto.getPrFundname());
			} else {
				schemeName1 = dto.getPlScheme();
			}

			PdfPCell schemeName = new PdfPCell(new Phrase(schemeName1, paragraphFont));
			schemeName.setHorizontalAlignment(Element.ALIGN_LEFT);
			schemeName.setLeading(15, 0);
			schemeName.setPaddingLeft(5);
			schemeName.setPaddingBottom(5);
			table.addCell(schemeName);

			Paragraph p = new Paragraph(dto.getPlRepayment(), paragraphFont);
			p.setAlignment(Element.ALIGN_LEFT);

			PdfPCell pPlRepayment = new PdfPCell();
			pPlRepayment.addElement(p);
			pPlRepayment.setLeading(15, 0);
			pPlRepayment.setPaddingLeft(5);
			pPlRepayment.setPaddingBottom(5);
			table.addCell(pPlRepayment);

			p = new Paragraph(dto.getPlIntPayment(), paragraphFont);
			p.setAlignment(Element.ALIGN_LEFT);

			PdfPCell pIntPayment = new PdfPCell();
			pIntPayment.addElement(p);
			pIntPayment.setLeading(15, 0);
			pIntPayment.setPaddingLeft(5);
			pIntPayment.setPaddingBottom(5);
			table.addCell(pIntPayment);

		}

		String plPeriod = principalDTOList.stream().filter(dto -> dto.getPlScheme() != null)
				.filter(dto -> dto.getPlScheme().equalsIgnoreCase("RMSE")).filter(dto -> dto.getPlPeriod() != null)
				.filter(dto -> !dto.getPlPeriod().isEmpty()).map(dto -> dto.getPlPeriod()).findFirst().orElse(null);
		if (plPeriod != null) {

			Paragraph p = new Paragraph(plPeriod, paragraphFont);
			p.setAlignment(Element.ALIGN_JUSTIFIED);

			PdfPCell plperiodData = new PdfPCell();
			plperiodData.addElement(p);
			plperiodData.setColspan(3);
			plperiodData.setLeading(15, 0);
			plperiodData.setPaddingLeft(5);
			plperiodData.setPaddingBottom(5);
			table.addCell(plperiodData);

		}

	}

	private void tenureRepaymentPeriod(PdfPTable table) {
		logger.info("started tenureRepaymentPeriod in AppraisalMerged");
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);

		cell.setPhrase(new Phrase("Principal Repayment", headLineFont));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Interest Payment", headLineFont));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);

	}

	private void tenureRepaymentPeriodDataOnEntity(PdfPTable table, SanctionTermsConditionsEntity entity) {

		Paragraph p = new Paragraph(entity.getTsPrincipalRepayment() != null ? entity.getTsPrincipalRepayment() : "",
				paragraphFont);
		p.setAlignment(Element.ALIGN_LEFT);

		PdfPCell cellRepayment = new PdfPCell();
		cellRepayment.addElement(p);
		cellRepayment.setLeading(17, 0);
		cellRepayment.setPaddingTop(-1f);
		cellRepayment.setPaddingBottom(5f);
		cellRepayment.setPaddingLeft(5f);
		table.addCell(cellRepayment);

		p = new Paragraph(entity.getTsIntrestPayment() != null ? entity.getTsIntrestPayment() : "", paragraphFont);
		p.setAlignment(Element.ALIGN_LEFT);

		PdfPCell cellIntPayment = new PdfPCell();
		cellIntPayment.addElement(p);
		cellIntPayment.setLeading(17, 0);
		cellIntPayment.setPaddingTop(-1f);
		cellIntPayment.setPaddingBottom(6f);
		cellIntPayment.setPaddingLeft(5f);
		table.addCell(cellIntPayment);
	}

	private void writeTableHeader(PdfPTable table) throws DocumentException, IOException {
		logger.info("started writeTableHeader in AppraisalMerged");
		for (S2IFVApplicationEntity applicationEntity : s2IFCCApplicationList) {

			int noCount = 0;

			PdfPCell cell1 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			cell1.setPaddingBottom(8f);
			cell1.setPaddingTop(1);
			cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell1.setPadding(5);
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell2 = new PdfPCell(new Paragraph("Name of the bank", paragraphFont));
			cell2.setPaddingBottom(7f);
			cell2.setPaddingTop(5f);
			cell2.setPaddingLeft(5f);
			cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);

			String bankName = applicationEntity.getIfvName();

			if (applicationEntity.getIfvShortName() != null && !applicationEntity.getIfvShortName().isBlank()) {
				bankName = bankName + " (" + applicationEntity.getIfvShortName() + ")";
			}

			PdfPCell cell3 = new PdfPCell(new Paragraph(bankName, paragraphFont));
			cell3.setPadding(5);
			cell3.setPaddingTop(5f);
			cell3.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell bck1 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			bck1.setPaddingBottom(8f);
			bck1.setPaddingTop(1);
			bck1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			bck1.setPadding(5);
			bck1.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell bck2 = new PdfPCell(new Paragraph("Background", paragraphFont));
			bck2.setPaddingBottom(7f);
			bck2.setPaddingTop(5f);
			bck2.setPaddingLeft(5f);
			bck2.setHorizontalAlignment(Element.ALIGN_LEFT);
			bck2.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell bck3 = new PdfPCell();

			Paragraph bck3Para = makeWordBold(applicationEntity.getIfvBackground());

			bck3.addElement(bck3Para);
			bck3.setPaddingTop(-2f);
			bck3.setPaddingBottom(7f);
			bck3.setLeading(17, 0);
			bck3.setPaddingLeft(6f);
			bck3.setBackgroundColor(BaseColor.WHITE);
			bck3.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell4 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			cell4.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell4.setLeading(17, 0);
			cell4.setPaddingTop(0f);
			cell4.setPaddingLeft(5f);
			cell4.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell5 = new PdfPCell(new Paragraph("Assistance applied for", paragraphFont));
			cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell5.setLeading(17, 0);
			cell5.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell5.setPaddingTop(0f);
			cell5.setPaddingLeft(5f);
			cell5.setPaddingBottom(5f);

			PdfPCell cell6 = new PdfPCell();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
			Paragraph pIfvAssistance = new Paragraph();
			if (!CollectionUtils.isEmpty(assistanceAppliedForDtos)) {
				for (AssistanceAppliedForDto dto : assistanceAppliedForDtos) {
					String schemeName = dto.getFundName().toLowerCase().contains("rmse")
							? getSchemeName(dto.getFundName())
							: (dto.getSchemeName() != null ? dto.getSchemeName() : "");
					LocalDate localDate = dto.getVideDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
					String formattedDate = localDate.format(formatter);
					String note = String.format("Rs. %s crore under %s vide application dated %s",
							CommonUtil.formatNumber(formatAmount(dto.getAmount())), schemeName, formattedDate);
					pIfvAssistance.add(new Chunk(note + "\n", paragraphFont));
				}
			} else {
				pIfvAssistance = new Paragraph(applicationEntity.getIfvAssistance(), paragraphFont);
			}

			cell6.addElement(pIfvAssistance);
			cell6.setPaddingTop(-2f);
			cell6.setPaddingBottom(7f);
			cell6.setLeading(17, 0);
			cell6.setPaddingLeft(6f);
			cell6.setBackgroundColor(BaseColor.WHITE);
			cell6.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell7 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell7.setLeading(17, 0);
			cell7.setPaddingTop(0f);
			cell7.setPaddingLeft(5f);
			cell7.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell8 = new PdfPCell(new Paragraph("Amount proposed for sanction", paragraphFont));
			cell8.setLeading(17, 0);
			cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell8.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell8.setPaddingTop(0f);
			cell8.setPaddingLeft(5f);

			boolean isAnyOneInterestResetPresent = proposedSchemaDetails.stream()
					.anyMatch(e -> e.getInterestReset() != null && !e.getInterestReset().isBlank());

			PdfPTable nested1 = null;
			nested1 = new PdfPTable(isAnyOneInterestResetPresent ? 6 : 5);
			nested1.setWidthPercentage(100f);

			if (isAnyOneInterestResetPresent) {
				nested1.setWidths(new float[] { 28, 17, 18, 17, 18, 20 });
			} else {
				nested1.setWidths(new float[] { 28, 17, 18, 17, 18 });
			}

			nested1.setSpacingBefore(10);

			nestedTableProposedSanctioned(nested1);
			nestedTableProposedSanctionedData(nested1);

			PdfPCell cell9 = new PdfPCell(new Paragraph(""));
			cell9.setPadding(5);
			cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell9.addElement(nested1);

			PdfPCell cell10 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			cell10.setPadding(5);
			cell10.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell11 = new PdfPCell(new Paragraph("Exposure limit (as advised by RiMV)", paragraphFont));
			cell11.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell11.setLeading(17, 0);
			cell11.setPaddingLeft(5f);
			cell11.setPaddingBottom(8f);
			cell11.setColspan(2);

			PdfPCell cell101 = new PdfPCell(new Paragraph("5.a", paragraphFont));
			cell101.setBorderWidthBottom(0);
			cell101.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell101.setPadding(5);
			cell101.setBorderWidthRight(0.5f);
			cell101.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell102 = new PdfPCell(new Paragraph("Exposure limit for borrowing bank", paragraphFont));
			cell102.setBorderWidthBottom(0);
			cell102.setBorderWidthLeft(0.5f);
			cell102.setLeading(17, 0);
			cell102.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell102.setPadding(5);
			cell102.setPaddingTop(-1);

			Paragraph para1 = new Paragraph();
			para1.setFont(paragraphFont);
			para1.add("The counterparty exposure limit for Business Operation (BO) is given below: (");
			Paragraph rupeeParagraph = new Paragraph(RUPEE, rupeeFont);
			Paragraph para2 = new Paragraph();
			para2.setFont(paragraphFont);
			para2.add(" In Crore)");
			Phrase phrase = new Phrase();
			phrase.add(para1);
			phrase.add(rupeeParagraph);
			phrase.add(para2);
			PdfPCell cell103 = new PdfPCell(phrase);
			cell103.setBackgroundColor(BaseColor.WHITE);
			cell103.setLeading(17, 0);
			cell103.setBorderWidthLeft(0.5f);
			cell103.setPaddingLeft(6f);
			cell103.setBorderWidthBottom(0);

			PdfPCell cell13 = new PdfPCell(new Paragraph(""));
			cell13.setBorderWidthTop(0);
			cell13.setBorderWidthRight(0.5f);
			cell13.setBorderWidthBottom(0);
			cell13.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell cell14 = new PdfPCell(new Paragraph(""));
			cell14.setBorderWidthTop(0);
			cell14.setBorderWidthLeft(0.5f);
			cell14.setBorderWidthBottom(0);
			cell14.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPTable nested2 = new PdfPTable(2);
			nested2.setWidthPercentage(100f);
			nested2.setWidths(new float[] { 6f, 4f });
			nested2.setSpacingBefore(10f);
			nested2.setSpacingAfter(0f);
			exposureLimitBorrowingBank(nested2);

			PdfPCell cell15 = new PdfPCell(new Paragraph(
					"The counterparty exposure limits for buisness Opration (BO) is given below", paragraphFont));
			cell15.setLeading(17, 0);
			cell15.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell15.setBackgroundColor(BaseColor.WHITE);
			cell15.setPadding(6);
			cell15.setBorderWidthLeft(0.5f);
			cell15.setBorderWidthBottom(0);
			cell15.setBorderWidthTop(0);
			cell15.addElement(nested2);
			nested2.addCell(cell15);

			PdfPCell cell104 = new PdfPCell(new Paragraph(""));
			cell104.setBorderColor(BaseColor.BLACK);
			cell104.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell104.setPadding(5);
			cell104.setBorderWidthTop(0);

			PdfPCell cell105 = new PdfPCell(new Paragraph(""));
			cell105.setBorderColor(BaseColor.BLACK);
			cell105.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell105.setBorderWidthTop(0);
			cell105.setPadding(5);
			String dateformateExposureFormated = "";

			Date dateExposure = applicationEntity.getIfvRepaymentDate();
			if (dateExposure != null) {
				DateTimeFormatter formateExposure = DateTimeFormatter.ofPattern(DATE_FORMAT2);
				LocalDate dateCollection = dateExposure.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				dateformateExposureFormated = dateCollection.format(formateExposure);
			}

			PdfPCell cell106 = new PdfPCell();
			Paragraph pMISAlert = new Paragraph(
					"*As per MIS Alert (Institution Wise Exposure) Report dated " + dateformateExposureFormated + "\n",
					paragraphFont);
			cell106.addElement(pMISAlert);
			cell106.setPaddingTop(-5f);
			cell106.setPaddingLeft(6f);
			cell106.setPaddingBottom(6f);
			cell106.setBackgroundColor(BaseColor.WHITE);
			cell106.setBorderWidthTop(0);

			PdfPCell cell1044 = new PdfPCell(new Paragraph(""));
			cell1044.setBorderColor(BaseColor.BLACK);
			cell1044.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell1044.setPadding(5);
			cell1044.setBorderWidthTop(0);
			cell1044.setBorderWidthBottom(0);

			PdfPCell cell1055 = new PdfPCell(new Paragraph(""));
			cell1055.setBorderColor(BaseColor.BLACK);
			cell1055.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell1055.setBorderWidthTop(0);
			cell1055.setPadding(5);
			cell1055.setBorderWidthBottom(0);

			PdfPCell cell1066 = new PdfPCell();
			Paragraph expRemarks = new Paragraph(
					applicationEntity.getIfvExpRemarks() != null ? applicationEntity.getIfvExpRemarks() : "",
					paragraphFont);
			cell1066.addElement(expRemarks);
			cell1066.setPaddingTop(-5f);
			cell1066.setPaddingLeft(6f);
			cell1066.setPaddingBottom(6f);
			cell1066.setBackgroundColor(BaseColor.WHITE);
			cell1066.setBorderWidthTop(0);
			cell1066.setBorderWidthBottom(0);

			if (applicationEntity.getIfvExpRemarks() != null && !applicationEntity.getIfvExpRemarks().isEmpty()) {
				cell1066.addElement(pSpace);
			}

			PdfPCell cell4b0 = new PdfPCell(new Paragraph("5.b", paragraphFont));
			cell4b0.setBorderWidthBottom(0);
			cell4b0.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell4b0.setPadding(5);
			cell4b0.setBorderWidthRight(0.5f);
			cell4b0.setHorizontalAlignment(Element.ALIGN_CENTER);
			String cell4b1Perc = null;
			String cell4b1Category = null;
			if (aggregateExposure != null && !aggregateExposure.isEmpty()) {
				cell4b1Perc = aggregateExposure.get(0).getCapitalFunds() != null
						? CommonUtil.formatNumber(formatAmount(aggregateExposure.get(0).getCapitalFunds()))
						: "";

				cell4b1Category = aggregateExposure.get(0).getGroupName() != null
						? aggregateExposure.get(0).getGroupName()
						: "Banks";
			}
			String cell4b1Text = "Aggregate Exposure cap for the " + cell4b1Category + " : " + cell4b1Perc
					+ "% of the capital funds of SIDBI";

			PdfPCell cell4b1 = new PdfPCell(new Paragraph(cell4b1Text, paragraphFont));
			cell4b1.setBorderWidthBottom(0);
			cell4b1.setBorderWidthLeft(0.5f);
			cell4b1.setLeading(17, 0);
			cell4b1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell4b1.setPadding(5);
			cell4b1.setPaddingTop(-1);

			PdfPCell cell4b2 = new PdfPCell(new Paragraph(""));

			PdfPTable table4b = new PdfPTable(3);
			table4b.setWidthPercentage(100f);
			table4b.setWidths(new float[] { 0.7f, 4.5f, 1.8f });
			aggregateExposureHeader(table4b);
			aggregateExposureData(table4b);

			cell4b2.addElement(table4b);
			cell4b2.setLeading(17, 0);
			cell4b2.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell4b2.setBorderWidthBottom(0);
			cell4b2.setPadding(5);
			Paragraph cell4bpara = new Paragraph(
					"@SIDBI Solo Exposure shall include: All exposure, (i.e. BO+TO exposure).", paragraphFont);
			Paragraph cell4bpara1 = new Paragraph(
					"\nBO exposure shall include Refinance+ On-lending, Co-Lending, and any other credit exposure, as applicable.",
					paragraphFont);
			cell4b2.addElement(cell4bpara);
			cell4b2.addElement(cell4bpara1);

			Font fontForSFB = FontFactory.getFont(FontFactory.TIMES_ITALIC);
			fontForSFB.setColor(BaseColor.RED);
			fontForSFB.setSize(10.5f);
			PdfPCell cell19 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			cell19.setPadding(5);
			cell19.setBorderWidthBottom(0);
			cell19.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell19.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell20 = new PdfPCell(new Paragraph(
					"Rating(External/\nInternal)\n& Adverse News,\nif any/Regulatory\nRestriction, if any",
					paragraphFont));
			cell20.setLeading(15, 0);
			cell20.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell20.setPadding(5);
			cell20.setPaddingTop(1);
			cell20.setBorderWidthBottom(0);
			cell20.setBackgroundColor(BaseColor.LIGHT_GRAY);

			List<Chunk> extRatingChunks = new ArrayList<>();
			if (applicationEntity.getIfvExternalRating() != null
					&& !applicationEntity.getIfvExternalRating().isEmpty()) {
				String[] sentences = applicationEntity.getIfvExternalRating().split("\\n");
				for (String sentence : sentences) {
					sentence = sentence.trim();
					if (!sentence.isEmpty()) {
						Chunk chunk = new Chunk(sentence, paragraphFont);
						extRatingChunks.add(chunk);
					}
				}
			}

			PdfPCell cell21 = new PdfPCell();
			Paragraph p1 = new Paragraph("i. External Rating: ", headLineFont);

			Paragraph p15 = new Paragraph();
			p15.setFont(paragraphFont);
			if (applicationEntity.getIfvExternalRating() != null
					&& !applicationEntity.getIfvExternalRating().isEmpty()) {
				for (Chunk item : extRatingChunks) {

					p15.add(item);
					p15.add(Chunk.NEWLINE);
				}
			} else {

				p15 = new Paragraph("", paragraphFont);
			}
			p15.setAlignment(Element.ALIGN_JUSTIFIED);
			p15.setIndentationLeft(20);
			p15.setIndentationRight(5);
			p1.setIndentationLeft(5);

			cell21.addElement(p1);
			cell21.addElement(p15);
			cell21.addElement(pSpace);

			Paragraph pInternalRating = new Paragraph("ii. Internal Rating: ", headLineFont);
			Paragraph p115InternalRating = new Paragraph(
					applicationEntity.getInternalRating() != null ? applicationEntity.getInternalRating() : "",
					paragraphFont);
			p115InternalRating.setAlignment(Element.ALIGN_JUSTIFIED);
			p115InternalRating.setIndentationLeft(15);
			p115InternalRating.setIndentationRight(5);
			pInternalRating.setIndentationLeft(5);

			cell21.addElement(pInternalRating);
			cell21.addElement(p115InternalRating);
			cell21.addElement(pSpace);

			Paragraph pIfvExternalRating = new Paragraph("iii. EWS: ", headLineFont);
			Paragraph p115 = new Paragraph(applicationEntity.getIfvEws() != null ? applicationEntity.getIfvEws() : "",
					paragraphFont);
			p115.setAlignment(Element.ALIGN_JUSTIFIED);
			p115.setIndentationLeft(20);
			p115.setIndentationRight(5);
			pIfvExternalRating.setIndentationLeft(5);

			cell21.addElement(pIfvExternalRating);
			cell21.addElement(p115);
			cell21.addElement(pSpace);

			Paragraph p18 = new Paragraph("iv. Adverse News about Bank: ", headLineFont);

			Paragraph p118 = new Paragraph("");
			p118.setFont(paragraphFont);

			if (applicationEntity.getIfvAdverseNews() != null && !applicationEntity.getIfvAdverseNews().isEmpty()) {
				String[] sentences = applicationEntity.getIfvAdverseNews().split("\\n");
				for (String sentence : sentences) {
					sentence = sentence.trim();
					if (!sentence.isEmpty()) {
						Chunk chunk = new Chunk(sentence, paragraphFont);
						p118.add(chunk);
						p118.add(Chunk.NEWLINE);
					}
				}
			}

			p118.setAlignment(Element.ALIGN_JUSTIFIED);
			p118.setIndentationLeft(20);
			p118.setIndentationRight(5);
			p18.setIndentationLeft(5);

			cell21.addElement(p18);
			cell21.addElement(p118);
			cell21.addElement(pSpace);

			Paragraph p21 = new Paragraph("v. Monetary penalty/regulatory restrictions: ", headLineFont);
			Paragraph p121 = new Paragraph(
					applicationEntity.getIfvMonetary() != null ? applicationEntity.getIfvMonetary() : "",
					paragraphFont);
			p121.setAlignment(Element.ALIGN_JUSTIFIED);
			p121.setIndentationLeft(20);
			p121.setIndentationRight(5);
			p21.setIndentationLeft(5);

			cell21.addElement(p21);
			cell21.addElement(p121);
			cell21.addElement(pSpace);

			Paragraph pOtherRemarks = new Paragraph("vi. Other Remarks: ", headLineFont);

			String remarks = applicationEntity.getOtherRemarks();
			if (remarks == null) {
				remarks = "";
			}

			List<Chunk> remarksChunks = new ArrayList<>();
			if (!remarks.equalsIgnoreCase("")) {
				String[] sentences = remarks.split("\\n");
				for (String sentence : sentences) {
					sentence = sentence.trim();
					if (!sentence.isEmpty()) {
						Chunk chunk = new Chunk(CONST + sentence, paragraphFont);
						remarksChunks.add(chunk);
					}
				}
			}

			Paragraph pOtherRemarksData = new Paragraph();
			pOtherRemarksData.setFont(paragraphFont);
			if (remarks.equalsIgnoreCase("")) {
				pOtherRemarksData = new Paragraph(remarks, paragraphFont);
			} else {
				for (Chunk item : remarksChunks) {
					pOtherRemarksData.add(item);
					pOtherRemarksData.add(Chunk.NEWLINE);
				}
			}
			pOtherRemarksData.setAlignment(Element.ALIGN_JUSTIFIED);
			pOtherRemarks.setIndentationLeft(20);
			pOtherRemarks.setIndentationRight(5);
			pOtherRemarksData.setIndentationLeft(5);

			cell21.addElement(pOtherRemarksData);
			cell21.addElement(pSpace);

			PdfPCell regEnv = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			regEnv.setPadding(5);
			regEnv.setHorizontalAlignment(Element.ALIGN_CENTER);
			regEnv.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell regEnv1 = new PdfPCell(new Paragraph("Regulatory \n" + "environment ", paragraphFont));
			regEnv1.setHorizontalAlignment(Element.ALIGN_LEFT);
			regEnv1.setPadding(5);
			regEnv1.setPaddingTop(1);
			regEnv1.setLeading(17, 0);
			regEnv1.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell regEnv2 = new PdfPCell();
			String regData = commondtEntityData.getUcsRegulatoryEnvironment() != null
					? commondtEntityData.getUcsRegulatoryEnvironment()
					: "";
			Paragraph regPar = new Paragraph(regData, paragraphFont);
			regPar.setAlignment(Element.ALIGN_JUSTIFIED);
			regEnv2.addElement(regPar);
			regEnv2.setPadding(5f);

			PdfPCell cell25 = new PdfPCell(new Paragraph(isRRB ? "9" : Integer.toString(++noCount), paragraphFont));
			cell25.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell25.setPadding(5);
			cell25.setBorderColor(BaseColor.BLACK);
			cell25.setBorderWidthBottom(0);
			cell25.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell25.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell26 = new PdfPCell(new Paragraph(
					isRRB ? "Chief Functionary & Board (Governance and Management)" : "Chief Functionary & Board",
					paragraphFont));
			cell26.setLeading(17, 0);
			cell26.setPaddingTop(1f);
			cell26.setPaddingLeft(5f);
			cell26.setBorderWidthBottom(0);
			cell26.setBorderColor(BaseColor.BLACK);
			cell26.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell26.setHorizontalAlignment(Element.ALIGN_LEFT);

			String cbData = commondtEntityData.getCmChiefFuncNote() != null ? commondtEntityData.getCmChiefFuncNote()
					: "";
			PdfPCell cell125 = new PdfPCell();
			cell125.addElement(new Paragraph(cbData, paragraphFont));
			cell125.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell125.setPadding(5f);

			PdfPCell brief = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			brief.setPadding(5);
			brief.setHorizontalAlignment(Element.ALIGN_CENTER);
			brief.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell brief1 = new PdfPCell(new Paragraph(
					"Brief particulars of credit\nand risk control\nmechanism of the bank", paragraphFont));
			brief1.setHorizontalAlignment(Element.ALIGN_LEFT);
			brief1.setPadding(5);
			brief1.setPaddingTop(1);
			brief1.setLeading(17, 0);
			brief1.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell brief2 = new PdfPCell();
			String briefData = commondtEntityData.getUcsBriefParticulars() != null
					? commondtEntityData.getUcsBriefParticulars()
					: "";
			brief2.addElement(new Paragraph(briefData, paragraphFont));
			brief2.setHorizontalAlignment(Element.ALIGN_LEFT);
			brief2.setPadding(5f);

			// Details of Key Products
			PdfPCell cell22 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			cell22.setPadding(5);
			cell22.setBorderWidthBottom(0);
			cell22.setBorderWidthTop(0);
			cell22.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell22.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell23 = new PdfPCell(new Paragraph("a) Details of key products", paragraphFont));
			cell23.setPaddingLeft(5f);
			cell23.setLeading(15, 0);
			cell23.setBorderWidth(0);
			cell23.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell23.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell seg1 = new PdfPCell(new Paragraph(
					"Segment wise portfolio of " + applicationEntity.getIfvName() + " is given below:", paragraphFont));
			seg1.setHorizontalAlignment(Element.ALIGN_LEFT);
			seg1.setBackgroundColor(BaseColor.WHITE);
			seg1.setPadding(5);
			seg1.setLeading(17, 0);
			seg1.setBorderWidthBottom(0);
			seg1.setBorderWidthTop(0);

			PdfPCell seg11 = new PdfPCell(new Paragraph(""));
			seg11.setBorderWidthTop(0);
			seg11.setBackgroundColor(BaseColor.LIGHT_GRAY);
			seg11.setBorderWidthBottom(0);

			PdfPCell seg111 = new PdfPCell();
			seg111.setBorderWidthTop(0);
			seg111.setBackgroundColor(BaseColor.LIGHT_GRAY);
			seg111.setHorizontalAlignment(Element.ALIGN_CENTER);
			seg111.setBorderWidth(0);

			PdfPTable segTable = new PdfPTable(4);
			segTable.setWidthPercentage(100f);
			segTable.setWidths(new float[] { 0.9f, 3.4f, 2.3f, 2.5f });
			segTable.setSpacingBefore(10);
			detailsKeyProduct(segTable, "segment");
			detailsKeyProductData(segTable, "UcbSegmentOne");

			PdfPCell seg1111 = new PdfPCell(new Paragraph(""));
			seg1111.setBorderWidthTop(0);
			seg1111.setPadding(5);
			segTable.setSpacingAfter(10);
			seg1111.addElement(segTable);
			seg1111.setBorderWidthBottom(0);

			PdfPCell cell222 = new PdfPCell(new Paragraph(isRRB ? "8" : "", paragraphFont));
			cell222.setPadding(5);
			cell222.setBorderWidthTop(0);
			cell222.setBorderWidthRight(0);
			cell222.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell222.setBorderWidthBottom(0);

			PdfPCell cell233 = new PdfPCell(
					new Paragraph(isRRB ? "Details of Key products (Lending segment)" : "", paragraphFont));
			cell233.setPaddingLeft(5f);
			cell233.setLeading(15, 0);
			cell233.setBorderWidthTop(0);
			cell233.setBorderWidthRight(0);
			cell233.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell233.setBorderWidthBottom(0);

			PdfPCell cell24 = new PdfPCell(new Paragraph(isRRB ? "The top 5 products are given below:"
					: "Out of the above, the top 5 products are given below:", paragraphFont));
			cell24.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell24.setBackgroundColor(BaseColor.WHITE);
			cell24.setPadding(5);
			cell24.setLeading(17, 0);
			cell24.setBorderWidthBottom(0);
			cell24.setBorderWidthTop(0);

			PdfPCell cell122 = new PdfPCell(new Paragraph(""));
			cell122.setBorderWidthTop(0);
			cell122.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell122.setBorderWidthBottom(0);
			cell122.setBorderWidthRight(0);

			PdfPCell cell123 = new PdfPCell();
			cell123.setBorderWidthTop(0);
			cell123.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell123.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell123.setBorderWidthBottom(0);
			cell123.setBorderWidthRight(0);

			PdfPTable nested3 = new PdfPTable(4);
			nested3.setWidthPercentage(100f);
			nested3.setWidths(new float[] { 0.9f, 3.4f, 2.3f, 2.5f });
			nested3.setSpacingBefore(10);
			detailsKeyProduct(nested3, TOP_FIVE_KYC);
			detailsKeyProductData(nested3, TOP_FIVE_KYC);

			PdfPCell cell124 = new PdfPCell(new Paragraph(""));
			cell124.setBorderWidthTop(0);
			cell124.setBorderWidthBottom(0);
			cell124.setPadding(5);
			nested3.setSpacingAfter(10);
			cell124.addElement(nested3);

			PdfPCell segNote1 = new PdfPCell(new Paragraph("", paragraphFont));
			segNote1.setPadding(5);
			segNote1.setBorderWidthTop(0);
			segNote1.setBorderWidthRight(0);
			segNote1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			segNote1.setBorderWidthBottom(0);

			PdfPCell segNote11 = new PdfPCell(new Paragraph("", paragraphFont));
			segNote11.setPaddingLeft(5f);
			segNote11.setLeading(15, 0);
			segNote11.setBorderWidthTop(0);
			segNote11.setBorderWidthRight(0);
			segNote11.setBackgroundColor(BaseColor.LIGHT_GRAY);
			segNote11.setBorderWidthBottom(0);

			String segNote = commondtEntityData.getUcbSeg2Note() != null ? commondtEntityData.getUcbSeg2Note() : "";
			PdfPCell segNote111 = new PdfPCell(new Paragraph(segNote, paragraphFont));
			segNote111.setHorizontalAlignment(Element.ALIGN_LEFT);
			segNote111.setBackgroundColor(BaseColor.WHITE);
			segNote111.setPadding(5);
			segNote111.setLeading(17, 0);
			segNote111.setBorderWidthBottom(0);
			segNote111.setBorderWidthTop(0);

			// Top 10 borrowers
			PdfPCell borr2 = new PdfPCell(new Paragraph(Integer.toString(noCount), paragraphFont));
			borr2.setBackgroundColor(BaseColor.LIGHT_GRAY);
			borr2.setBorderWidthBottom(0);
			borr2.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell borr22 = new PdfPCell(new Paragraph("b) Borrowers Details", paragraphFont));
			borr22.setPadding(5);
			borr22.setBackgroundColor(BaseColor.LIGHT_GRAY);
			borr22.setHorizontalAlignment(Element.ALIGN_LEFT);
			borr22.setBorderWidthBottom(0);
			borr22.setBorderWidthLeft(0);
			borr22.setBorderWidthRight(0);

			PdfPTable borrowRbl = new PdfPTable(4);
			borrowRbl.setWidthPercentage(100);
			borrowRbl.setWidths(new float[] { 10, 40, 20, 30 });
			borrowRbl.setSpacingBefore(10);
			borrowerHeader(borrowRbl);
			borrowerData(borrowRbl);
			borrowRbl.setSpacingAfter(10);

			Paragraph pr1 = new Paragraph();
			Chunk c1 = new Chunk("Total number of borrowers: ", headLineFont);
			pr1.add(c1);
			Phrase ph1 = new Phrase(borrowersDetailDto.getTotBorrowers() != null
					? CommonUtil.formatNumber(borrowersDetailDto.getTotBorrowers().toString())
					: "", paragraphFont);
			pr1.add(ph1);

			Paragraph pr2 = new Paragraph();
			Chunk c2 = new Chunk("Total number of MSME customers: ", headLineFont);
			pr2.add(c2);
			Phrase ph2 = new Phrase(borrowersDetailDto.getTotMsmeCustomers() != null
					? CommonUtil.formatNumber(borrowersDetailDto.getTotMsmeCustomers().toString())
					: "", paragraphFont);
			pr2.add(ph2);

			Paragraph pr3 = new Paragraph();
			Chunk c3 = new Chunk("Total number of corporate borrowers: ", headLineFont);
			pr3.add(c3);
			Phrase ph3 = new Phrase(borrowersDetailDto.getTotCorpBorrowers() != null
					? CommonUtil.formatNumber(borrowersDetailDto.getTotCorpBorrowers().toString())
					: "", paragraphFont);
			pr3.add(ph3);

			Paragraph pr4 = new Paragraph();
			pr4.add(pSpace);
			Phrase ph4 = new Phrase(
					borrowersDetailDto.getRemarks() != null ? borrowersDetailDto.getRemarks().toString() : "",
					paragraphFont);
			pr4.add(ph4);

			PdfPCell borr222 = new PdfPCell(new Paragraph(""));
			borr222.setPadding(5);
			borr222.addElement(pr1);
			borr222.addElement(pr2);
			borr222.addElement(pr3);
			borr222.addElement(pr4);
			borr222.setBorderWidthBottom(0);

			PdfPCell borrowNote1 = new PdfPCell(new Paragraph("", paragraphFont));
			borrowNote1.setPadding(5);
			borrowNote1.setBorderWidthTop(0);
			borrowNote1.setBorderWidthRight(0);
			borrowNote1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			borrowNote1.setBorderWidthBottom(0);

			PdfPCell borrowNote11 = new PdfPCell(new Paragraph("", paragraphFont));
			borrowNote11.setPaddingLeft(5f);
			borrowNote11.setLeading(15, 0);
			borrowNote11.setBorderWidthTop(0);
			borrowNote11.setBorderWidthRight(0);
			borrowNote11.setBackgroundColor(BaseColor.LIGHT_GRAY);
			borrowNote11.setBorderWidthBottom(0);

			String borrowNote = borrowersDTOs.stream().filter(e -> e.getBorrowerNote() != null)
					.map(e -> e.getBorrowerNote()).findAny().orElse("");
			PdfPCell borrowNote111 = new PdfPCell(new Paragraph(borrowNote, paragraphFont));
			borrowNote111.setHorizontalAlignment(Element.ALIGN_LEFT);
			borrowNote111.setBackgroundColor(BaseColor.WHITE);
			borrowNote111.setPadding(5);
			borrowNote111.setLeading(17, 0);
			borrowNote111.setBorderWidthBottom(0);
			borrowNote111.setBorderWidthTop(0);

			PdfPCell expoDir1 = new PdfPCell(new Paragraph(Integer.toString(noCount), paragraphFont));
			expoDir1.setPadding(5);
			expoDir1.setHorizontalAlignment(Element.ALIGN_CENTER);
			expoDir1.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell expoDir11 = new PdfPCell(new Paragraph("c) Exposure to Directors", paragraphFont));
			expoDir11.setHorizontalAlignment(Element.ALIGN_LEFT);
			expoDir11.setPadding(5);
			expoDir11.setPaddingTop(1);
			expoDir11.setLeading(17, 0);
			expoDir11.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell expoDir111 = new PdfPCell();
			String expDir = commondtEntityData.getUcsDirectorExposure() != null
					? commondtEntityData.getUcsDirectorExposure()
					: "";
			expoDir111.addElement(new Paragraph(expDir, paragraphFont));
			expoDir111.setHorizontalAlignment(Element.ALIGN_LEFT);
			expoDir111.setPadding(5f);

			PdfPCell cell28 = new PdfPCell(new Paragraph(isRRB ? "8" : Integer.toString(++noCount), paragraphFont));
			cell28.setPadding(5);
			cell28.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell28.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell cell29 = new PdfPCell(new Paragraph("Areas of Operation-\n" + "Geographical ", paragraphFont));
			cell29.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell29.setPadding(5);
			cell29.setPaddingTop(1);
			cell29.setLeading(17, 0);
			cell29.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell cell128 = new PdfPCell();
			String areaOpGeoData = commondtEntityData.getCmGeoAreaNote() != null ? commondtEntityData.getCmGeoAreaNote()
					: "";
			cell128.addElement(new Paragraph(areaOpGeoData, paragraphFont));
			cell128.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell128.setPadding(5f);

			PdfPCell intBorr1 = new PdfPCell(new Paragraph(Integer.toString(++noCount), paragraphFont));
			intBorr1.setPadding(5);
			intBorr1.setHorizontalAlignment(Element.ALIGN_CENTER);
			intBorr1.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell intBorr11 = new PdfPCell(new Paragraph("Institutional borrowings", paragraphFont));
			intBorr11.setHorizontalAlignment(Element.ALIGN_LEFT);
			intBorr11.setPadding(5);
			intBorr11.setPaddingTop(1);
			intBorr11.setLeading(17, 0);
			intBorr11.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell intBorr111 = new PdfPCell();
			String intBorrow = commondtEntityData.getUcsInstitutionalBorrowings() != null
					? commondtEntityData.getUcsInstitutionalBorrowings()
					: "";
			intBorr111.addElement(new Paragraph(intBorrow, paragraphFont));
			intBorr111.setHorizontalAlignment(Element.ALIGN_LEFT);
			intBorr111.setPadding(5f);

			PdfPCell cell31 = new PdfPCell(new Paragraph(isRRB ? "9" : Integer.toString(++noCount), paragraphFont));
			cell31.setPadding(5);
			cell31.setBorderWidthBottom(0);
			cell31.setBorderWidthTop(0);
			cell31.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell31.setHorizontalAlignment(Element.ALIGN_CENTER);

			PdfPCell cell32 = new PdfPCell(
					new Paragraph("Key Investors (if any, domestic / foreign other than promoters)", paragraphFont));
			cell32.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell32.setLeading(17, 0);
			cell32.setPaddingLeft(5f);
			cell32.setBorderWidth(0);
			cell32.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell cell134 = new PdfPCell(new Paragraph(""));
			Paragraph para = new Paragraph(commondtEntityData.getCmKeyInvestorsNote(), paragraphFont);
			Paragraph para11 = new Paragraph("\n");

			int size = 5;
			float[] ft = { 10, 30, 20, 20, 20 };

			if (isRRB) {
				size = 4;
				ft = new float[] { 10, 30, 20, 20 };
			}

			PdfPTable nested6 = new PdfPTable(size);
			nested6.setWidthPercentage(100);
			nested6.setWidths(ft);

			keyDomesticInvestors(nested6);
			keyDomesticInvestorsData(nested6);
			cell134.addElement(para);
			cell134.addElement(para11);
			cell134.addElement(nested6);
			cell134.setLeading(17, 0);
			cell134.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell134.setBorderWidthBottom(0);
			cell134.setBorderWidthTop(0);
			cell134.setPadding(5);

			PdfPCell cell135 = new PdfPCell(new Paragraph(""));
			cell135.setBorderWidthTop(0);
			cell135.setBackgroundColor(BaseColor.LIGHT_GRAY);

			PdfPCell cell136 = new PdfPCell(new Paragraph("", fontForSFB));
			cell136.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell136.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell136.setPadding(5);
			cell136.setBorderWidthTop(0);
			cell136.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell33 = new PdfPCell();
			cell33.setBackgroundColor(BaseColor.WHITE);
			cell33.setPadding(5);
			cell33.setBorderWidthTop(0);
			cell33.setLeading(17, 0);

			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);

			table.addCell(bck1);
			table.addCell(bck2);
			table.addCell(bck3);

			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);
			table.addCell(cell9);
			table.addCell(cell10);
			table.addCell(cell11);
			table.addCell(cell101);
			table.addCell(cell102);
			table.addCell(cell103);
			table.addCell(cell13);
			table.addCell(cell14);
			table.addCell(cell15);
			table.addCell(cell1044);
			table.addCell(cell1055);
			table.addCell(cell1066);

			table.addCell(cell104);
			table.addCell(cell105);
			table.addCell(cell106);

			if (!CollectionUtils.isEmpty(aggregateExposure)) {
				table.addCell(cell4b0);
				table.addCell(cell4b1);
				table.addCell(cell4b2);
			}

			table.addCell(cell19);
			table.addCell(cell20);
			table.addCell(cell21);

			table.addCell(regEnv);
			table.addCell(regEnv1);
			table.addCell(regEnv2);

			if (!isRRB) {

				table.addCell(cell25);
				table.addCell(cell26);
				table.addCell(cell125);

				table.addCell(brief);
				table.addCell(brief1);
				table.addCell(brief2);

				table.addCell(cell22);
				table.addCell(cell23);
				table.addCell(seg1);
				table.addCell(seg11);
				table.addCell(seg111);
				table.addCell(seg1111);

				table.addCell(cell222);
				table.addCell(cell233);
				table.addCell(cell24);

				table.addCell(cell122);
				table.addCell(cell123);
				table.addCell(cell124);
			}

			table.addCell(segNote1);
			table.addCell(segNote11);
			table.addCell(segNote111);

			if (!isRRB) {
				table.addCell(borr2);
				table.addCell(borr22);
				table.addCell(borr222);

				table.addCell(borrowNote1);
				table.addCell(borrowNote11);
				table.addCell(borrowNote111);

				table.addCell(expoDir1);
				table.addCell(expoDir11);
				table.addCell(expoDir111);
			}

			table.addCell(cell28);
			table.addCell(cell29);
			table.addCell(cell128);

			if (!isRRB) {
				table.addCell(intBorr1);
				table.addCell(intBorr11);
				table.addCell(intBorr111);
			}

			table.addCell(cell31);
			table.addCell(cell32);
			table.addCell(cell134);
			table.addCell(cell135);
			table.addCell(cell136);
			table.addCell(cell33);

		}
	}

	private void writeTableHeaderforFinecialHighlight(PdfPTable table)
			throws DocumentException, MalformedURLException, IOException {
		Optional<S2IFVFinancialHighlightsEntity> finPerformance = highlightsDTOList.stream()
				.filter(e -> e.getFhFinperformance() != null || e.getFhAssestProfile() != null
						|| e.getFhLiabilities() != null || e.getFhProfitabilities() != null || e.getFhEqulity() != null
						|| e.getFhDisclosure() != null || e.getFhCollection() != null || e.getFhEfficiency() != null
						|| e.getFhStatutory() != null || e.getFhStatus() != null || e.getFhHighlights() != null
						|| e.getFinancialPerformanceYear2() != null || e.getFinancialPerformanceYear1() != null)
				.findAny();
		S2IFVFinancialHighlightsEntity financialHighlightsEntity = new S2IFVFinancialHighlightsEntity();
		if (finPerformance.isPresent()) {
			financialHighlightsEntity = finPerformance.get();
		}

		PdfPCell cell1 = new PdfPCell(new Paragraph(isRRB ? "10" : "14", paragraphFont));
		cell1.setPadding(5);
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);

		Chunk underLine3 = new Chunk("Financial Highlights (Standalone financials):");
		underLine3.setFont(underlineTextFont);
		Chunk ch133 = new Chunk(" (", headLineFont);
		Chunk rupeeChunk = new Chunk(RUPEE, rupeeFont);
		Chunk ch134 = new Chunk(IN_CRORE, headLineFont);
		Paragraph p101 = new Paragraph();
		p101.add(underLine3);
		p101.add(ch133);
		p101.add(rupeeChunk);
		p101.add(ch134);

		PdfPTable nested1 = null;

		int finY = 0;
		Optional<S2IFVFinancialHighlightsEntity> highlightEntity = highlightsDTOList.stream()
				.filter(e -> e.getFhFyResults() != null).findAny();
		if (highlightEntity.isPresent()) {
			S2IFVFinancialHighlightsEntity entity = highlightEntity.get();
			finY = entity.getFhFyResults() != null ? entity.getFhFyResults().intValue() : 0;
		}

		if (finY > 0) {
			nested1 = new PdfPTable(6);
			nested1.setWidthPercentage(100f);
			nested1.setWidths(new float[] { 1.4f, 3.2f, 2.5f, 2.5f, 2.2f, 2.7f });
			nested1.setSpacingBefore(10);
		} else {
			nested1 = new PdfPTable(5);
			nested1.setWidthPercentage(100f);
			nested1.setWidths(new float[] { 1.4f, 3.2f, 2.5f, 2.5f, 2.2f });
			nested1.setSpacingBefore(10);

		}

		financialHighlight(nested1);
		financialHighlightData(nested1);

		String fhFinperformance = financialHighlightsEntity.getFhFinperformance() != null
				? financialHighlightsEntity.getFhFinperformance()
				: "";
		if (fhFinperformance == null) {
			fhFinperformance = "";
		}

		List<Chunk> chunks = new ArrayList<>();
		if (!fhFinperformance.equalsIgnoreCase("")) {
			String[] sentences = fhFinperformance.split("\\n");
			for (String sentence : sentences) {
				sentence = sentence.trim();
				if (!sentence.isEmpty()) {
					Chunk chunk = new Chunk(CONST + sentence, paragraphFont);
					chunks.add(chunk);
				}

			}
		}

		Paragraph pSFBs = new Paragraph();
		pSFBs.setSpacingBefore(5f);
		pSFBs.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunkSFBs = new Paragraph("*CET1&CCB not applicable in case of UCB.", paragraphFont);
		pSFBs.add(chunkSFBs);

		String fhFinancialPerformanceYear1 = financialHighlightsEntity.getFinancialPerformanceYear1() != null
				? financialHighlightsEntity.getFinancialPerformanceYear1()
				: "";
		Paragraph p1 = new Paragraph();
		p1.setSpacingBefore(10f);
		p1.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk1 = new Paragraph("Financial Performance (" + fhFinancialPerformanceYear1 + "): ",
				underlineTextFont);
		p1.add(chunk1);
		Paragraph parFinperformance = new Paragraph();
		parFinperformance.setFont(paragraphFont);
		if (fhFinperformance.equalsIgnoreCase("")) {
			parFinperformance = new Paragraph(String.valueOf(fhFinperformance), paragraphFont);
		} else {
			for (Chunk item : chunks) {
				parFinperformance.add(item);
				parFinperformance.add(Chunk.NEWLINE);
			}
		}
		parFinperformance.setAlignment(Element.ALIGN_JUSTIFIED);
		parFinperformance.setIndentationLeft(15);
		parFinperformance.setIndentationRight(5);
		String fhAssestProfile;
		fhAssestProfile = financialHighlightsEntity.getFhAssestProfile();
		if (fhAssestProfile == null) {
			fhAssestProfile = "";
		}

		List<Chunk> assetChunks = new ArrayList<>();
		if (!fhAssestProfile.equalsIgnoreCase("")) {
			String[] sentences = fhAssestProfile.split("\\n");
			for (String sentence : sentences) {
				sentence = sentence.trim();
				if (!sentence.isEmpty()) {
					Chunk chunk = new Chunk(CONST + sentence, paragraphFont);
					assetChunks.add(chunk);
				}
			}
		}

		Paragraph p2 = new Paragraph();
		p2.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk2 = new Paragraph("Assets Profile: ", underlineTextFont);
		p2.add(chunk2);

		Paragraph parAssets = new Paragraph();
		parAssets.setFont(paragraphFont);
		if (fhAssestProfile.equalsIgnoreCase("")) {
			parAssets = new Paragraph(String.valueOf(fhAssestProfile), paragraphFont);
		} else {
			for (Chunk item : assetChunks) {
				parAssets.add(item);
				parAssets.add(Chunk.NEWLINE);
			}
		}
		parAssets.setAlignment(Element.ALIGN_JUSTIFIED);
		parAssets.setIndentationLeft(15);
		parAssets.setIndentationRight(5);

		String liabilities = financialHighlightsEntity.getFhLiabilities();
		if (liabilities == null) {
			liabilities = "";
		}
		List<Chunk> liabilitesChunks = new ArrayList<>();
		if (!liabilities.equalsIgnoreCase("")) {
			String[] sentences = liabilities.split("\\n");
			for (String sentence : sentences) {
				sentence = sentence.trim();
				if (!sentence.isEmpty()) {
					Chunk chunk = new Chunk(CONST + sentence, paragraphFont);
					liabilitesChunks.add(chunk);
				}
			}
		}

		Paragraph p3 = new Paragraph();
		p3.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk3 = new Paragraph("Liabilities Profile: ", underlineTextFont);
		p3.add(chunk3);

		Paragraph parLiabilities = new Paragraph();
		parLiabilities.setFont(paragraphFont);
		if (liabilities.equalsIgnoreCase("")) {
			parLiabilities = new Paragraph(String.valueOf(liabilities), paragraphFont);
		} else {
			for (Chunk item : liabilitesChunks) {
				parLiabilities.add(item);
				parLiabilities.add(Chunk.NEWLINE);
			}
		}
		parLiabilities.setAlignment(Element.ALIGN_JUSTIFIED);
		parLiabilities.setIndentationLeft(15);
		parLiabilities.setIndentationRight(5);

		Paragraph p4 = new Paragraph();
		p4.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk4 = new Paragraph("Profitablity: ", underlineTextFont);
		p4.add(chunk4);

		String profitabilities = financialHighlightsEntity.getFhProfitabilities();
		if (profitabilities == null) {
			profitabilities = "";
		}
		List<Chunk> profitabilitiesChunks = new ArrayList<>();
		if (!profitabilities.equalsIgnoreCase("")) {
			String[] sentences = profitabilities.split("\\n");
			for (String sentence : sentences) {
				sentence = sentence.trim();
				if (!sentence.isEmpty()) {
					Chunk chunk = new Chunk(CONST + sentence, paragraphFont);
					profitabilitiesChunks.add(chunk);
				}
			}
		}

		Paragraph parProfitablity = new Paragraph();
		parProfitablity.setFont(paragraphFont);
		if (profitabilities.equalsIgnoreCase("")) {
			parProfitablity = new Paragraph(String.valueOf(profitabilities), paragraphFont);
		} else {
			for (Chunk item : profitabilitiesChunks) {
				parProfitablity.add(item);
				parProfitablity.add(Chunk.NEWLINE);
			}
		}
		parProfitablity.setAlignment(Element.ALIGN_JUSTIFIED);
		parProfitablity.setIndentationLeft(15);
		parProfitablity.setIndentationRight(5);

		Paragraph p5 = new Paragraph();
		p5.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk5 = new Paragraph("Equity:", underlineTextFont);
		p5.add(chunk5);

		String equities = financialHighlightsEntity.getFhEqulity();
		if (equities == null) {
			equities = "";
		}
		List<Chunk> equitiesChunks = new ArrayList<>();
		if (!equities.equalsIgnoreCase("")) {
			String[] sentences = equities.split("\\n");
			for (String sentence : sentences) {
				sentence = sentence.trim();
				if (!sentence.isEmpty()) {
					Chunk chunk = new Chunk(CONST + sentence, paragraphFont);
					equitiesChunks.add(chunk);
				}
			}
		}

		Paragraph parEquity = new Paragraph();
		parEquity.setFont(paragraphFont);
		if (equities.equalsIgnoreCase("")) {
			parEquity = new Paragraph(String.valueOf(equities), paragraphFont);
		} else {
			for (Chunk item : equitiesChunks) {
				parEquity.add(item);
				parEquity.add(Chunk.NEWLINE);
			}
		}
		parEquity.setAlignment(Element.ALIGN_JUSTIFIED);
		parEquity.setIndentationLeft(15);
		parEquity.setIndentationRight(5);

		String fhFinancialPerformanceYear2 = financialHighlightsEntity.getFinancialPerformanceYear2() != null
				? financialHighlightsEntity.getFinancialPerformanceYear2()
				: "";

		Paragraph p105 = new Paragraph();
		p5.setAlignment(Element.ALIGN_LEFT);

		Paragraph chunk105 = new Paragraph(fhFinancialPerformanceYear2 + " / Financial performance", underlineTextFont);

		if (isRRB) {
			chunk105 = new Paragraph("Financial performance (" + fhFinancialPerformanceYear2 + "):", underlineTextFont);
		}
		p105.add(chunk105);

		Paragraph parFhHighlights = new Paragraph(financialHighlightsEntity.getFinancialPerformance2(), paragraphFont);
		parFhHighlights.setSpacingBefore(6f);
		parFhHighlights.setLeading(14, 0);
		parFhHighlights.setIndentationLeft(15);
		parFhHighlights.setIndentationRight(5);

		PdfPTable fin2Table = new PdfPTable(4);
		fin2Table.setWidthPercentage(90);
		fin2Table.setWidths(new float[] { 10, 40, 25, 25 });
		fin2Table.setSpacingAfter(10f);
		fin2Performance(fin2Table);
		fin2PerformaceData(fin2Table);

		String fin2Note = financialPerformanceDTOs.stream().filter(e -> e.getNote() != null).map(e -> e.getNote())
				.findAny().orElse("");
		Paragraph fin2TableNote = new Paragraph(fin2Note, paragraphFont);
		fin2TableNote.setSpacingBefore(6f);
		fin2TableNote.setLeading(14, 0);
		fin2TableNote.setIndentationLeft(15);
		fin2TableNote.setIndentationRight(5);

		Paragraph p6 = new Paragraph();
		p6.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk6 = new Paragraph(isRRB ? "Disclosure on Divergence\u00B9:"
				: "Divergence in asset classification and provisioning\u00B9:", underlineTextFont);
		p6.add(chunk6);
		Paragraph parDisclosure = new Paragraph(financialHighlightsEntity.getFhDisclosure(), paragraphFont);
		parDisclosure.setAlignment(Element.ALIGN_JUSTIFIED);
		parDisclosure.setSpacingBefore(6f);
		parDisclosure.setLeading(14, 0);
		parDisclosure.setIndentationLeft(15);
		parDisclosure.setIndentationRight(5);
		parDisclosure.add(pSpace);
		parDisclosure.add(Chunk.NEWLINE);

		boolean isCollectionEffExists = false;

		Paragraph p7 = new Paragraph();
		List<CollectionEfficiencyEntity> dto = collectionEfficiencyDto.stream().collect(Collectors.toList());

		if (!dto.isEmpty() && dto.size() > 0) {
			isCollectionEffExists = true;
			parEquity.add(pSpace);
			p7.setAlignment(Element.ALIGN_LEFT);
			Paragraph chunk7 = new Paragraph("Collection efficiancy:", underlineTextFont);
			p7.add(chunk7);
		}

		int colSize = collectionEfficiencyDto.size();
		PdfPTable nestedCollEfi = new PdfPTable(colSize + 1);
		nestedCollEfi.setWidthPercentage(100f);
		float[] columnWidths = new float[colSize + 1];
		columnWidths[0] = 2f;
		for (int i = 1; i <= colSize; i++) {
			columnWidths[i] = 1f;
		}
		nestedCollEfi.setWidths(columnWidths);
		nestedCollEfi.setSpacingAfter(10f);
		collectionEfficiencyData1(nestedCollEfi);
		collectionEfficiencyData2(nestedCollEfi);

		Paragraph parCollection = new Paragraph(financialHighlightsEntity.getFhCollection(), paragraphFont);
		parCollection.setSpacingBefore(6f);
		parCollection.setLeading(14, 0);
		parCollection.add(pSpace);

		PdfPTable nestedRestructured = new PdfPTable(3);
		nestedRestructured.setWidthPercentage(90f);
		nestedRestructured.setWidths(new float[] { 33f, 33f, 34f });
		nestedRestructured.setSpacingAfter(10f);
		restructuredAssets(nestedRestructured);
		restructuredAssetsData(nestedRestructured);

		PdfPTable nestedStatusListing = new PdfPTable(3);
		nestedStatusListing.setWidthPercentage(80f);
		nestedStatusListing.setWidths(new float[] { 40f, 30f, 30f });
		nestedStatusListing.setSpacingAfter(10f);
		statusListing(nestedStatusListing);
		statusListingData(nestedStatusListing);

		PdfPTable nestedp7 = new PdfPTable(2);
		nestedp7.setWidthPercentage(100f);
		nestedp7.setWidths(new float[] { 5.4f, 6.2f });
		nestedp7.setSpacingAfter(10f);
		collectionEfficiency(nestedp7);
		collectionEfficiencyData(nestedp7);

		Font font = FontFactory.getFont(FontFactory.HELVETICA, 9f);

		String rbiGuidelines = financialHighlightsEntity.getRbiGuidelines() != null
				? financialHighlightsEntity.getRbiGuidelines()
				: "";

		Paragraph pRBICircular = new Paragraph("\u00B9" + rbiGuidelines, font);
		pRBICircular.setAlignment(Element.ALIGN_JUSTIFIED);
		pRBICircular.setIndentationLeft(15);
		pRBICircular.setIndentationRight(5);
		Paragraph p8 = new Paragraph();
		p8.setAlignment(Element.ALIGN_LEFT);

		Paragraph chunk8 = new Paragraph(isRRB ? "Any adverse remarks by Statutory Auditors:"
				: "Any adverse remarks by Statutory Auditors/Nominee Director of SIDBI.", underlineTextFont);
		p8.add(chunk8);

		String statutories = financialHighlightsEntity.getFhStatutory();
		if (statutories == null) {
			statutories = "";
		}
		List<Chunk> statutoriesChunks = new ArrayList<>();
		if (!statutories.equalsIgnoreCase("")) {
			String[] sentences = statutories.split("\\n");
			for (String sentence : sentences) {
				sentence = sentence.trim();
				if (!sentence.isEmpty()) {
					Chunk chunk = new Chunk(CONST + sentence, paragraphFont);
					statutoriesChunks.add(chunk);
				}
			}
		}

		Paragraph parStatus = new Paragraph();
		parStatus.setFont(paragraphFont);
		if (equities.equalsIgnoreCase("")) {
			parStatus = new Paragraph(String.valueOf(statutories), paragraphFont);
		} else {
			for (Chunk item : statutoriesChunks) {
				parStatus.add(item);
				parStatus.add(Chunk.NEWLINE);
			}
		}
		parStatus.setAlignment(Element.ALIGN_JUSTIFIED);
		parStatus.setIndentationLeft(15);
		parStatus.setIndentationRight(5);

		Paragraph p9 = new Paragraph();
		p9.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk9 = new Paragraph(
				isRRB ? "NPA management:" : "Status of Listing of SFB/Hold Co. if listed, share price",
				underlineTextFont);
		p9.add(chunk9);

		boolean showStatusListing = false;

		if (statusOfListingDtos != null && !statusOfListingDtos.isEmpty()) {
			showStatusListing = true;
		}

		Paragraph parPrice = new Paragraph(financialHighlightsEntity.getFhStatus(), paragraphFont);
		parPrice.setSpacingBefore(6f);
		parPrice.setLeading(14, 0);
		parPrice.setIndentationLeft(15);
		parPrice.setIndentationRight(5);

		Paragraph p10 = new Paragraph();
		p10.setAlignment(Element.ALIGN_LEFT);
		Paragraph chunk10 = new Paragraph();
		Chunk cnk1 = new Chunk(financialHighlightsEntity.getRestructuredAsset() != null
				? financialHighlightsEntity.getRestructuredAsset()
				: "", underlineTextFont);
		chunk10.add(cnk1);
		p10.add(chunk10);
		p10.add(pSpace);

		boolean showRestructuredAsset = false;

		if (restructuredAssetsDto != null && restructuredAssetsDto.size() > 0) {
			showRestructuredAsset = true;
		}

		PdfPCell cell2 = new PdfPCell(new Paragraph(" "));
		cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell2.setBackgroundColor(BaseColor.WHITE);
		cell2.setPadding(5);
		cell2.addElement(p101);
		cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell2.addElement(nested1);

		cell2.setPadding(5);
		if (!isRRB) {
			cell2.addElement(pSFBs);
		}

		cell2.addElement(p1);
		cell2.addElement(parFinperformance);
		cell2.addElement(pSpace);
		cell2.addElement(p2);
		cell2.addElement(parAssets);
		cell2.addElement(pSpace);
		cell2.addElement(p3);
		cell2.addElement(parLiabilities);
		cell2.addElement(pSpace);
		cell2.addElement(p4);
		cell2.addElement(parProfitablity);
		cell2.addElement(pSpace);
		cell2.addElement(p5);
		cell2.addElement(parEquity);

		if (fhFinancialPerformanceYear2.length() > 0 || (financialHighlightsEntity.getFinancialPerformance2() != null
				&& !financialHighlightsEntity.getFinancialPerformance2().isEmpty())) {
			cell2.addElement(pSpace);
			cell2.addElement(p105);
			cell2.addElement(parFhHighlights);
		}

		if (financialPerformanceDTOs.size() > 0) {
			cell2.addElement(fin2Table);
		}

		if (fin2Note != null && !fin2Note.isBlank()) {
			cell2.addElement(fin2TableNote);
		}

		if (isCollectionEffExists) {
			cell2.addElement(p7);
			cell2.addElement(pSpace);
			cell2.addElement(nestedCollEfi);
			cell2.addElement(pSpace);
		}

		if (isRRB) {
			cell2.addElement(pSpace);
		} else {
			cell2.addElement(p6);
			cell2.addElement(parDisclosure);
			cell2.addElement(pRBICircular);
			cell2.addElement(pSpace);
		}

		if (showRestructuredAsset) {
			cell2.addElement(p10);
			cell2.addElement(nestedRestructured);
			cell2.addElement(pSpace);
		}

		if (!isRRB) {
			cell2.addElement(p8);
			cell2.addElement(parStatus);
			cell2.addElement(pSpace);
		} else {
			cell2.addElement(p6);
			cell2.addElement(parDisclosure);
			cell2.addElement(pRBICircular);
		}

		if (showStatusListing) {
			cell2.addElement(pSpace);
			cell2.addElement(nestedStatusListing);
		}
		cell2.addElement(pSpace);

		PdfPCell cell7 = new PdfPCell(new Paragraph(isRRB ? "11" : "15", paragraphFont));
		cell7.setPadding(5);
		cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell7.setBorderWidthBottom(0);
		cell7.setBorderWidthRight(0);

		PdfPTable nested3 = new PdfPTable(5);
		nested3.setWidthPercentage(100);

		if (isRRB) {
			nested3.setWidths(new float[] { 7, 15, 25, 40, 25 });
		} else {
			nested3.setWidths(new float[] { 7, 15, 20, 20, 30 });
		}

		nested3.setSpacingBefore(10);
		eligibilityCriteria(nested3);
		eligibilityCriteriaData(nested3, "BFS");
		String r = isRRB ? "RRBs" : "UCBs";

		PdfPCell cell8 = new PdfPCell();
		Paragraph pEligibity = new Paragraph(
				"The Board approved eligibility criteria for assistance to " + r + " and its compliance:",
				paragraphFont);
		cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell8.setBackgroundColor(BaseColor.WHITE);
		cell8.setPadding(4);
		cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell8.addElement(pEligibity);
		cell8.addElement(nested3);
		cell8.setBorderWidthBottom(0);

		PdfPCell rimc = new PdfPCell(new Paragraph("", paragraphFont));
		rimc.setPadding(5);
		rimc.setBackgroundColor(BaseColor.LIGHT_GRAY);
		rimc.setHorizontalAlignment(Element.ALIGN_CENTER);
		rimc.setBorderWidthTop(0);
		rimc.setBorderWidthRight(0);
		rimc.setBorderWidthBottom(0);

		PdfPTable rimcTbl = new PdfPTable(3);
		rimcTbl.setWidthPercentage(100);
		rimcTbl.setWidths(new float[] { 10, 50, 40 });
		rimcTbl.setSpacingBefore(10);
		eligibilityCriteria1(rimcTbl);
		eligibilityCriteriaData1(rimcTbl, "RIMC");

		PdfPCell rimc1 = new PdfPCell();
		Paragraph rimc1Note = new Paragraph("Board/RiMC approval and its compliance", paragraphFont);
		rimc1.setHorizontalAlignment(Element.ALIGN_LEFT);
		rimc1.setBackgroundColor(BaseColor.WHITE);
		rimc1.setPadding(4);
		rimc1.setHorizontalAlignment(Element.ALIGN_CENTER);
		rimc1.addElement(rimc1Note);
		rimc1.addElement(rimcTbl);
		rimc1.setBorderWidthTop(0);
		rimc1.setBorderWidthBottom(0);

		PdfPCell cell9 = new PdfPCell(new Paragraph(""));
		cell9.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell9.setPadding(5);
		cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell9.setBorderWidthBottom(0);
		cell9.setBorderWidthRight(0);
		cell9.setBorderWidthTop(0);
		PdfPTable nested4 = new PdfPTable(3);
		nested4.setWidthPercentage(100f);
		nested4.setWidths(new float[] { 0.5f, 4f, 4f });
		nested4.setSpacingBefore(10);

		List<String> fundNameForLabel = proposedSchemaDetails.stream()
				.filter(e -> e.getPrFundname().toLowerCase().contains("rmse")).map(e -> e.getPrFundname())
				.collect(Collectors.toList());
		String schemeNameForLabel = "";

		int count = 0;

		for (String val : fundNameForLabel) {
			schemeNameForLabel += this.getSchemeName(val) + " ";
			if (count < fundNameForLabel.size() - 1) {
				schemeNameForLabel += " / ";
			}
			++count;
		}

		PdfPCell cell10 = new PdfPCell();
		Paragraph par = new Paragraph(schemeNameForLabel + " specific criteria and compliance", headLineFont);
		cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell10.setBackgroundColor(BaseColor.WHITE);
		cell10.setBorderWidthBottom(0);
		cell10.addElement(par);
		cell10.addElement(nested4);
		boardApprovedCriteria(nested4);

		PdfPTable nested5 = new PdfPTable(3);
		nested5.setWidthPercentage(100f);
		nested5.setWidths(new float[] { 0.5f, 4f, 4f });
		nested5.setSpacingBefore(10);

		InputStream checkedBox = getClass().getResourceAsStream("/Images/checkedBox.png");
		Image pngcheckedBox = Image.getInstance(IOUtils.toByteArray(checkedBox));
		InputStream unCheckedBox = getClass().getResourceAsStream("/Images/UncheckedBox.png");
		Image pngunCheckedBox = Image.getInstance(IOUtils.toByteArray(unCheckedBox));

		pngunCheckedBox.scaleToFit(10, 10);
		pngcheckedBox.scaleToFit(10, 10);
		Paragraph parFABIA = new Paragraph("FABIA-MSME / RAMPE scheme specific criteria and compliance ", headLineFont);
		parFABIA.add(new Chunk(pngunCheckedBox, 0, 0));

		PdfPCell cell11 = new PdfPCell();

		cell11.setBorderWidthTop(0);
		cell11.setBorderWidthRight(0);
		cell11.setBorderWidthBottom(0);
		cell11.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPCell just1 = new PdfPCell(new Paragraph(isRRB ? "12" : "16", paragraphFont));
		just1.setPadding(5);
		just1.setHorizontalAlignment(Element.ALIGN_CENTER);
		just1.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPTable just1Tbl = new PdfPTable(2);
		just1Tbl.setWidthPercentage(100);
		just1Tbl.setWidths(new float[] { 50, 50 });
		just1Tbl.setSplitLate(false);

		PdfPCell cell = new PdfPCell();
		cell.setPhrase(new Phrase("Justification/rationale for the proposed relaxation", paragraphFont));
		cell.setPadding(4f);
		cell.setLeading(15, 0);
		cell.setPaddingTop(1);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setPaddingBottom(5f);
		cell.setPaddingLeft(5f);
		cell.setBorderWidth(0);
		just1Tbl.addCell(cell);

		String justNote = criteriaParameterDTOs.stream().filter(e -> e.getJustification() != null)
				.map(e -> e.getJustification()).findAny().orElse("");

		Paragraph p = new Paragraph(justNote, paragraphFont);
		p.setAlignment(Element.ALIGN_JUSTIFIED);

		cell.addElement(p);
		cell.setBackgroundColor(BaseColor.WHITE);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setPaddingBottom(5f);
		cell.setPaddingLeft(5f);
		cell.setBorderWidth(0);
		just1Tbl.addCell(cell);

		PdfPCell just11 = new PdfPCell();
		just11.setHorizontalAlignment(Element.ALIGN_LEFT);
		just11.setPadding(0);
		just11.setLeading(17, 0);
		just11.addElement(just1Tbl);

		PdfPCell crit1 = new PdfPCell(new Paragraph("17", paragraphFont));
		Paragraph pppp = new Paragraph("17", paragraphFont);
		crit1.addElement(pppp);
		crit1.setPadding(5);
		crit1.setBackgroundColor(BaseColor.LIGHT_GRAY);
		crit1.setHorizontalAlignment(Element.ALIGN_CENTER);
		crit1.setBorderWidthBottom(0);
		crit1.setBorderWidthRight(0);

		PdfPTable critTbl = new PdfPTable(4);
		critTbl.setWidthPercentage(100);
		critTbl.setWidths(new float[] { 7, 35, 15, 45 });
		critTbl.setSpacingBefore(10);
		criteria(critTbl);
		criteriaData(critTbl);

		String note = criteriaParameterDTOs.stream().filter(e -> e.getNote() != null).map(e -> e.getNote()).findAny()
				.orElse("");

		PdfPCell crit11 = new PdfPCell();
		Paragraph pNote = new Paragraph(note, paragraphFont);
		crit11.setBackgroundColor(BaseColor.WHITE);
		crit11.setPadding(4);
		crit11.setHorizontalAlignment(Element.ALIGN_CENTER);
		crit11.addElement(pNote);
		crit11.addElement(critTbl);
		crit11.setBorderWidthBottom(0);

		boolean rmseSchemeName = proposedSchemaDetails.stream().filter(e -> e.getPrSchemeName() != null)
				.anyMatch(e -> e.getPrSchemeName().toLowerCase().contains("rmse"));

		if (!rmseSchemeName) {
			table.addCell(cell1);
			table.addCell(cell2);

			table.addCell(cell7);
			table.addCell(cell8);

			table.addCell(rimc);
			table.addCell(rimc1);

			table.addCell(cell9);
			table.addCell(cell11);

			PdfPCell cell99 = new PdfPCell(new Paragraph(""));
			cell99.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell99.setPadding(5);
			cell99.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell99.setBorderWidthBottom(0);
			cell99.setBorderWidthRight(0);
			cell99.setBorderWidthTop(0);

			if (eligibilityEntitiesDTOList.getEcFabiaStatus() != null
					&& !eligibilityEntitiesDTOList.getEcFabiaStatus().isEmpty()) {
				Paragraph parFABIA3 = new Paragraph(eligibilityEntitiesDTOList.getEcFabiaStatus() + "\n",
						paragraphFont);
				parFABIA3.setAlignment(Element.ALIGN_JUSTIFIED);
				PdfPCell cell12 = new PdfPCell();
				cell12.setBorderWidthBottom(0);
				cell12.setBorderWidthTop(0);
				cell12.setPadding(5);
				cell12.addElement(parFABIA3);
				table.addCell(cell99);
				table.addCell(cell12);
			}
			if (eligibilityEntitiesDTOList.getBankParameter() != null
					&& !eligibilityEntitiesDTOList.getBankParameter().isEmpty()) {
				Paragraph parFABIA4 = new Paragraph(eligibilityEntitiesDTOList.getBankParameter() + "\n\n",
						headLineFont);
				parFABIA4.setAlignment(Element.ALIGN_JUSTIFIED);
				PdfPCell cell12 = new PdfPCell();
				cell12.setBorderWidthTop(0);
				cell12.setPadding(5);
				cell12.addElement(parFABIA4);
				table.addCell(cell99);
				table.addCell(cell12);
			}

			table.addCell(just1);
			table.addCell(just11);

			if (!isRRB) {
				table.addCell(crit1);
				table.addCell(crit11);
			}

		} else {
			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell7);
			table.addCell(cell8);

			table.addCell(rimc);
			table.addCell(rimc1);

			table.addCell(cell9);
			table.addCell(cell10);
			table.addCell(cell11);

			PdfPCell cell99 = new PdfPCell(new Paragraph(""));
			cell99.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell99.setPadding(5);
			cell99.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell99.setBorderWidthBottom(0);
			cell99.setBorderWidthRight(0);

			if (eligibilityEntitiesDTOList.getEcFabiaStatus() != null
					&& !eligibilityEntitiesDTOList.getEcFabiaStatus().isEmpty()) {
				Paragraph parFABIA3 = new Paragraph(eligibilityEntitiesDTOList.getEcFabiaStatus() + "\n",
						paragraphFont);
				parFABIA3.setAlignment(Element.ALIGN_JUSTIFIED);

				PdfPCell cell12 = new PdfPCell();
				cell12.setBorderWidthTop(0);
				cell12.setBorderWidthBottom(0);
				cell12.setPadding(5);
				cell12.addElement(parFABIA3);
				table.addCell(cell99);
				table.addCell(cell99);
				table.addCell(cell12);
			} else {
				table.addCell(cell99);
			}

			if (eligibilityEntitiesDTOList.getBankParameter() != null
					&& !eligibilityEntitiesDTOList.getBankParameter().isEmpty()) {
				Paragraph parFABIA4 = new Paragraph(eligibilityEntitiesDTOList.getBankParameter() + "\n\n",
						headLineFont);
				parFABIA4.setAlignment(Element.ALIGN_JUSTIFIED);
				PdfPCell cell12 = new PdfPCell();
				cell12.setBorderWidthTop(0);
				cell12.setPadding(5);
				cell12.addElement(parFABIA4);
				cell12.setBorderWidthTop(0);
				cell99.setBorderWidthTop(0);
				table.addCell(cell99);
				table.addCell(cell12);
			}

			table.addCell(just1);
			table.addCell(just11);

			if (!isRRB) {
				table.addCell(crit1);
				table.addCell(crit11);
			}

		}
	}

	private void writeTableHeaderforRefinanceScheme(PdfPTable table) throws DocumentException {

		boolean rsfbSchemeName = proposedSchemaDetails.stream().filter(dto -> dto.getPrSchemeName() != null)
				.anyMatch(dto -> dto.getPrSchemeName().equalsIgnoreCase("REFINANCE TO SFB"));
		boolean mserSchemeName = proposedSchemaDetails.stream().filter(dto -> dto.getPrSchemeName() != null)
				.anyMatch(dto -> dto.getPrSchemeName().equalsIgnoreCase("MSERS"));
		boolean rmseSchemeName = proposedSchemaDetails.stream().filter(dto -> dto.getPrFundname() != null)
				.anyMatch(dto -> dto.getPrFundname().toLowerCase().contains("rmse"));
		boolean fabiaSchemeName = proposedSchemaDetails.stream().filter(dto -> dto.getPrSchemecode() != null)
				.anyMatch(dto -> dto.getPrSchemecode().equalsIgnoreCase("4C"));
		boolean rampeSchemeName = proposedSchemaDetails.stream().filter(dto -> dto.getPrSchemecode() != null)
				.anyMatch(dto -> dto.getPrSchemecode().equalsIgnoreCase("4D"));

		Optional<S2IFVAssRepaymentsEntity> assRepaymentslist = assRepaymentsDTOList.stream()
				.filter(e -> e.getRpRefinanceAcc() != null && e.getRpRepaymentTrack() != null).findAny();

		S2IFVAssRepaymentsEntity repaymentsList = new S2IFVAssRepaymentsEntity();
		if (assRepaymentslist.isPresent()) {
			repaymentsList = assRepaymentslist.get();
		}
		PdfPCell cell1 = new PdfPCell(new Paragraph(isRRB ? "13" : "18", paragraphFont));
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell1.setPadding(5);

		PdfPCell cell2 = new PdfPCell(
				new Paragraph("Assistance earlier availed and past dealings under refinance schemes", paragraphFont));
		cell2.setPadding(4f);
		cell2.setLeading(15, 0);
		cell2.setPaddingTop(1);
		cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPTable nested1 = new PdfPTable(7);
		nested1.setWidthPercentage(100f);
		nested1.setWidths(new float[] { 6f, 15f, 20f, 17f, 17f, 10f, 15f });
		nested1.setSpacingBefore(6);
		nested1.setSpacingAfter(10);

		PdfPTable nested2 = new PdfPTable(6);
		nested2.setWidthPercentage(100f);
		nested2.setWidths(new float[] { 1.6f, 2.4f, 3.5f, 3.0f, 2.6f, 3.5f });
		nested2.setSpacingBefore(6);
		nested2.setSpacingAfter(10);

		PdfPTable nested3 = new PdfPTable(7);
		nested3.setWidthPercentage(100f);
		nested3.setWidths(new float[] { 1.6f, 2.6f, 2.4f, 2.4f, 2.4f, 2.4f, 4.2f });
		nested3.setSpacingBefore(6);

		pastDisbursement(nested1);
		pastDisbursementData(nested1);
		outstanding(nested2);
		outstandingData(nested2);
		futureRepaymentsOutstanding(nested3);
		futureRepaymentsOutstandingData(nested3);

		String rpRefinanceAcc = repaymentsList.getRpRefinanceAcc() != null ? repaymentsList.getRpRefinanceAcc() : "_";
		String rpRepaymentTrack = repaymentsList.getRpRepaymentTrack() != null ? repaymentsList.getRpRepaymentTrack()
				: "_";
		PdfPCell cell3 = new PdfPCell();
		cell3.setPaddingTop(-9f);
		Paragraph disbursementPara = new Paragraph();
		Phrase Disbursement1 = new Phrase("Past Disbursement:", headLineFont);
		Phrase brPhrase = new Phrase(" (", headLineFont);
		Phrase rupeePhrase = new Phrase(RUPEE, rupeeFont);
		Phrase Disbursement2 = new Phrase(IN_CRORE, headLineFont);
		disbursementPara.add(Disbursement1);
		disbursementPara.add(brPhrase);
		disbursementPara.add(rupeePhrase);
		disbursementPara.add(Disbursement2);

		Paragraph outstandingPara = new Paragraph();
		Phrase Outstanding1 = new Phrase("Outstanding:", headLineFont);
		outstandingPara.add(Outstanding1);
		outstandingPara.add(brPhrase);
		outstandingPara.add(rupeePhrase);
		outstandingPara.add(Disbursement2);

		Phrase Repayment = new Phrase("Repayment track record:", headLineFont);

		Phrase refinance = new Phrase(SPACE + "The existing refinance account with SIDBI is " + rpRefinanceAcc
				+ " and categorized as " + rpRepaymentTrack + " repayment track record as per RiMV guidelines.",
				paragraphFont);

		Paragraph futurePara = new Paragraph();
		Phrase future1 = new Phrase("\nFuture Repayments of existing outstanding:", headLineFont);
		Phrase brFPhrase = new Phrase(" (", headLineFont);
		Phrase future2 = new Phrase(IN_CRORE, headLineFont);
		futurePara.add(future1);
		futurePara.add(brFPhrase);
		futurePara.add(rupeePhrase);
		futurePara.add(future2);

		cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell3.setBackgroundColor(BaseColor.WHITE);
		cell3.setPadding(5);
		cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell3.addElement(disbursementPara);

		if (!CollectionUtils.isEmpty(assPastdisbDTOList)) {
			cell3.addElement(nested1);
		}

		if (StringUtils.hasText(commondtEntityData.getPastDisbNote())) {
			Phrase pastNote = new Phrase(SPACE + commondtEntityData.getPastDisbNote(), paragraphFont);
			cell3.addElement(pastNote);
			cell3.addElement(pSpace);
		}

		cell3.addElement(outstandingPara);

		if (!CollectionUtils.isEmpty(assOutstandingDTOList)) {
			cell3.addElement(nested2);
		}

		if (StringUtils.hasText(commondtEntityData.getOutstandingsNote())) {
			Phrase outstanding = new Phrase(SPACE + commondtEntityData.getOutstandingsNote(), paragraphFont);
			cell3.addElement(outstanding);
			cell3.addElement(pSpace);
		}

		cell3.addElement(Repayment);

		if (!CollectionUtils.isEmpty(assRepaymentsDTOList)) {
			cell3.addElement(refinance);
			cell3.addElement(futurePara);
			cell3.addElement(nested3);
		}

		if (StringUtils.hasText(commondtEntityData.getFutureRepNote())) {
			Phrase futureRep = new Phrase(SPACE + commondtEntityData.getFutureRepNote(), paragraphFont);
			cell3.addElement(futureRep);
		}

		PdfPCell cell4 = new PdfPCell(new Paragraph(isRRB ? "14" : "19", paragraphFont));
		cell4.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell4.setPadding(5);
		cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell5 = new PdfPCell(new Paragraph("For MSERS/RSFB:\nIntrest Margin", paragraphFont));
		cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell5.setBorderColor(BaseColor.BLACK);
		cell5.setPadding(5);
		cell5.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPCell cellSIDBI = new PdfPCell(new Paragraph("Cost of fund to SIDBI and Interest Margin", paragraphFont));
		cellSIDBI.setHorizontalAlignment(Element.ALIGN_LEFT);
		cellSIDBI.setBorderColor(BaseColor.BLACK);
		cellSIDBI.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellSIDBI.setPadding(4f);
		cellSIDBI.setLeading(15, 0);
		cellSIDBI.setPaddingTop(1);

		PdfPCell cell6 = new PdfPCell();

		if (rsfbSchemeName) {

			Paragraph pr1 = new Paragraph();
			pr1.setAlignment(Element.ALIGN_JUSTIFIED);
			Chunk rsfbChunk = new Chunk("RSFB: ", headLineFont);
			pr1.add(rsfbChunk);
			Phrase ph1 = new Phrase(commondtEntityData.getCmRsfbData(), paragraphFont);
			pr1.add(ph1);
			cell6.addElement(pr1);
			cell6.addElement(new Paragraph("\n"));
		}
		if (mserSchemeName) {

			Paragraph pr2 = new Paragraph();
			pr2.setAlignment(Element.ALIGN_JUSTIFIED);
			Chunk maserChunk = new Chunk("MSER: ", headLineFont);
			pr2.add(maserChunk);
			Phrase ph2 = new Phrase(commondtEntityData.getCmMsersData(), paragraphFont);
			pr2.add(ph2);
			cell6.addElement(pr2);
			cell6.addElement(new Paragraph("\n"));
		}
		if (rmseSchemeName) {

			Paragraph pr3 = new Paragraph();
			pr3.setAlignment(Element.ALIGN_JUSTIFIED);
			Chunk rmseChunk = new Chunk("RMSE: ", headLineFont);
			pr3.add(rmseChunk);
			Phrase ph3 = new Phrase(commondtEntityData.getCmRmseData(), paragraphFont);
			pr3.add(ph3);
			cell6.addElement(pr3);
			cell6.addElement(new Paragraph("\n"));
		}

		if (fabiaSchemeName) {

			Paragraph pr4 = new Paragraph();
			pr4.setAlignment(Element.ALIGN_JUSTIFIED);
			Chunk fabiaChunk = new Chunk("FABIA-MSME: ", headLineFont);
			pr4.add(fabiaChunk);
			Phrase ph4 = new Phrase(commondtEntityData.getCmFabiaData(), paragraphFont);
			pr4.add(ph4);
			cell6.addElement(pr4);
			cell6.addElement(new Paragraph("\n"));
		}

		if (rampeSchemeName) {

			Paragraph pr5 = new Paragraph();
			pr5.setAlignment(Element.ALIGN_JUSTIFIED);
			Chunk rampeChunk = new Chunk("RAMPE: ", headLineFont);
			pr5.add(rampeChunk);
			Phrase ph5 = new Phrase(commondtEntityData.getCmRampeData(), paragraphFont);
			pr5.add(ph5);
			cell6.addElement(pr5);
			cell6.addElement(new Paragraph("\n"));
		}

		if (StringUtils.hasText(commondtEntityData.getInterestReset())) {

			Paragraph pr5 = new Paragraph();
			pr5.setAlignment(Element.ALIGN_JUSTIFIED);
			Chunk rampeChunk = new Chunk("Interest Reset: ", headLineFont);
			pr5.add(rampeChunk);
			Phrase ph5 = new Phrase(commondtEntityData.getInterestReset(), paragraphFont);
			pr5.add(ph5);
			cell6.addElement(pr5);
		}

		cell6.addElement(pSpace);
		cell6.setBackgroundColor(BaseColor.WHITE);
		cell6.setPadding(3);
		cell6.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell7 = new PdfPCell(new Paragraph(isRRB ? "15" : "20", paragraphFont));
		cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell7.setPadding(5);

		PdfPCell cell8 = new PdfPCell();
		Paragraph parMajor = new Paragraph("Major terms and conditions", headLineFont);
		cell8.addElement(parMajor);
		cell8.setPaddingTop(-2f);
		cell8.setPaddingLeft(5f);
		cell8.setColspan(2);

		PdfPCell cell9 = new PdfPCell();
		cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
		LineSeparator lineAbc = new LineSeparator();
		lineAbc.setOffset(-6);
		lineAbc.setLineWidth(0.5f);
		Paragraph para = new Paragraph("   a", paragraphFont);
		para.setSpacingAfter(5f);
		Paragraph parb = new Paragraph("   b", paragraphFont);
		parb.setSpacingBefore(5f);
		parb.setSpacingAfter(5f);
		Paragraph parc = new Paragraph("   c", paragraphFont);
		parc.setSpacingBefore(5f);
		cell9.addElement(para);
		cell9.addElement(lineAbc);
		cell9.addElement(parb);
		cell9.addElement(lineAbc);
		cell9.addElement(parc);
		cell9.setPadding(0);
		cell9.setLeading(35, 10);
		cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell9.setBackgroundColor(BaseColor.LIGHT_GRAY);

		boolean interestResetExists = proposedSchemaDetails.stream().map(ProposedSchemaDTO::getInterestReset)
				.anyMatch(e -> e != null && !e.isBlank());

		PdfPTable nested4 = new PdfPTable(interestResetExists ? 5 : 4);
		nested4.setSpacingBefore(10f);
		nested4.setWidthPercentage(100f);

		if (interestResetExists) {
			nested4.setWidths(new float[] { 30f, 23f, 23f, 26f, 24f });
		} else {
			nested4.setWidths(new float[] { 30f, 23f, 23f, 24f });
		}

		amountRateOfIntrest(nested4, interestResetExists);
		amountRateOfIntrestData(nested4, interestResetExists);

		PdfPCell cell10 = new PdfPCell(new Paragraph(""));

		Paragraph parAmount = new Paragraph(" Amount\n", paragraphFont);
		parAmount.setSpacingAfter(5f);
		Paragraph parROI = new Paragraph(" Rate of Interest\n", paragraphFont);
		parROI.setSpacingBefore(5f);
		parROI.setSpacingAfter(5f);
		Paragraph parTenure = new Paragraph(" Tenure ", paragraphFont);
		parTenure.setSpacingBefore(5f);
		parTenure.setSpacingAfter(5f);
		cell10.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell10.setLeading(35, 10);
		cell10.setPaddingTop(2);
		cell10.setPaddingLeft(4f);
		LineSeparator line = new LineSeparator();
		line.setOffset(-6);
		line.setLineWidth(0.5f);
		cell10.addElement(parAmount);
		cell10.addElement(line);
		cell10.addElement(parROI);
		cell10.addElement(line);
		cell10.addElement(parTenure);
		cell10.setPadding(0);

		PdfPCell cell11 = new PdfPCell();
		cell11.setPadding(5f);
		cell11.addElement(nested4);

		table.addCell(cell1);
		table.addCell(cell2);
		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cellSIDBI);
		table.addCell(cell6);

		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);

	}

	private void writeTableHeaderforUpfrontFee(PdfPTable table) throws DocumentException, IOException {

		PdfPCell cell22 = new PdfPCell(new Paragraph("e", paragraphFont));
		cell22.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell22.setPadding(5);
		cell22.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell23 = new PdfPCell(new Paragraph("Upfront Fee", paragraphFont));
		cell23.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell23.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell23.setPaddingLeft(5);

		PdfPCell cell24 = new PdfPCell();
		Paragraph tsUpfrontefee = new Paragraph(conditionDataDTOList.getTsUpfrontFee(), paragraphFont);
		cell24.addElement(tsUpfrontefee);
		cell24.setPadding(5);
		cell24.setPaddingTop(-3f);
		cell24.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell25 = new PdfPCell(new Paragraph("d", paragraphFont));
		cell25.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell25.setPadding(5);
		cell25.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell26 = new PdfPCell(new Paragraph("Repayment terms", paragraphFont));
		cell26.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell26.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell26.setPadding(3);

		PdfPTable nested5 = new PdfPTable(3);
		nested5.setWidthPercentage(100f);
		nested5.setWidths(new float[] { 20f, 40f, 40f });
		nested5.setSpacingBefore(10);
		repaymentTerms(nested5);
		repaymentTermsData(nested5);

		PdfPCell cell27 = new PdfPCell(new Paragraph(""));
		cell27.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell27.setPadding(5);
		cell27.addElement(nested5);

		PdfPCell cellf = new PdfPCell(new Paragraph("21", paragraphFont));
		cellf.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellf.setPadding(5);
		cellf.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cellExpected = new PdfPCell(new Paragraph("Expected date of disbursement.", paragraphFont));
		cellExpected.setPadding(4f);
		cellExpected.setLeading(15, 0);
		cellExpected.setPaddingTop(1);
		cellExpected.setHorizontalAlignment(Element.ALIGN_LEFT);
		cellExpected.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPCell cellDisbursement = new PdfPCell();
		Paragraph pTsDisbursement = new Paragraph(conditionDataDTOList.getTsDisbursement(), paragraphFont);
		cellDisbursement.addElement(pTsDisbursement);
		cellDisbursement.setHorizontalAlignment(Element.ALIGN_LEFT);
		cellDisbursement.setPadding(5);
		cellDisbursement.setPaddingTop(-3f);

		int noCount = 16;

		boolean isSpec = StringUtils.hasText(conditionDataDTOList.getTsSpecific());

		PdfPCell cell128 = new PdfPCell(new Paragraph(isRRB ? Integer.toString(noCount) : "21", paragraphFont));
		cell128.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell128.setPadding(5);
		cell128.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell129 = new PdfPCell(new Paragraph(
				"Specific comments,\nif any (viz. Period up to interest rate is valid / last date of drawal, etc.)",
				paragraphFont));
		cell129.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell129.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell129.setPadding(4f);
		cell129.setLeading(15, 0);
		cell129.setPaddingTop(1);

		PdfPCell cell130 = new PdfPCell();
		Paragraph pTsSpecific = new Paragraph(conditionDataDTOList.getTsSpecific(), paragraphFont);
		pTsSpecific.setAlignment(Element.ALIGN_JUSTIFIED);
		cell130.addElement(pTsSpecific);
		cell130.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell130.setPadding(5);
		cell130.setPaddingTop(-3f);

		if (isSpec) {
			++noCount;
		}

		PdfPCell cell31 = new PdfPCell(new Paragraph(isRRB ? Integer.toString(noCount) : "22", paragraphFont));
		cell31.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell31.setPadding(5);
		cell31.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell32 = new PdfPCell(new Paragraph("End borrowers' data", paragraphFont));
		cell32.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell32.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell32.setPadding(5);

		PdfPCell cell33 = new PdfPCell();
		Paragraph pTsBorrowers = new Paragraph(conditionDataDTOList.getTsBorrowers(), paragraphFont);
		pTsBorrowers.setAlignment(Element.ALIGN_JUSTIFIED);
		cell33.addElement(pTsBorrowers);
		cell33.setPadding(5);
		cell33.setPaddingTop(-3f);
		cell33.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell34 = new PdfPCell(new Paragraph(""));
		cell34.setPadding(5);
		cell34.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell34.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell35 = new PdfPCell(new Paragraph(""));
		cell35.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell35.setPadding(5);

		InputStream checkedBox = getClass().getResourceAsStream("/Images/checkedBox.png");
		Image pngcheckedBox = Image.getInstance(IOUtils.toByteArray(checkedBox));
		InputStream unCheckedBox = getClass().getResourceAsStream("/Images/UncheckedBox.png");
		Image pngunCheckedBox = Image.getInstance(IOUtils.toByteArray(unCheckedBox));

		pngunCheckedBox.scaleToFit(10, 10);
		pngcheckedBox.scaleToFit(10, 10);

		PdfPCell cell36 = new PdfPCell();
		Paragraph pMSERSUnchecked = new Paragraph(" MSERS/RMSE/RSFB/RAMPE: ", underlineTextFont);
		pMSERSUnchecked.add(new Chunk(pngunCheckedBox, 0, 0));
		Paragraph pMSERSchecked = new Paragraph(" MSERS/RMSE/RSFB/RAMPE: ", underlineTextFont);
		pMSERSchecked.add(new Chunk(pngcheckedBox, 0, 0));
		pMSERSchecked.setSpacingAfter(5f);

		Paragraph pShall = new Paragraph(
				" i.   The bank shall submit a list of end borrowers in \n      the prescribed format at the time of disbursement \n      or within extended period as may be allowed by\n      the "
						+ "sanctioning committee. In case the bank fails\n      to furnish the list of end-borrowers as per sanction \n      terms, penal interest @2% on the outstanding \n      amount will be charged with prospective effect till \n      date of receipt of data.\n"
						+ "             • Further, if the data is not furnished within 3\n               months from the date of disbursement, SIDBI\n               shall have the right to recall the loan and the\n               bank would be required to prepay the entire\n               loan outstanding.",
				paragraphFont);

		Paragraph pFABIAChecked = new Paragraph(" FABIA: ", underlineTextFont);
		pFABIAChecked.add(new Chunk(pngcheckedBox, 0, 0));
		Paragraph pFABIAUnchecked = new Paragraph(" FABIA: ", underlineTextFont);
		pFABIAUnchecked.add(new Chunk(pngunCheckedBox, 0, 0));
		Paragraph pborrowers = new Paragraph(
				" i.   The Bank shall submit the list of MSME end\n       borrowers in the prescribed format within 3/6\n       months from the date of 1st disbursement or\n       within extended period as may be allowed by the\n       sanctioning committee.\r\n"
						+ "             • In case, the bank fails to furnish the list of\n               end- borrowers as per sanction terms, penal\n               interest @2% on the outstanding amount will\n               be charged with prospective effect till date of\n               receipt of data.\r\n"
						+ "                      ■Further, if the data is not furnished within\n                      3/6 months from the date of disburse-\n                      ment, SIDBI shall have the right to recall\n                      the loan and the bank would be required\n                      to prepay the entire loan outstanding.",
				paragraphFont);
		cell36.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell36.setPadding(5);

		String tsRampe = null;
		tsRampe = conditionDataDTOList.getTsRampe();
		if (tsRampe == null || tsRampe.isEmpty() || !tsRampe.equalsIgnoreCase("true")) {
			cell36.addElement(pMSERSUnchecked);
			pMSERSUnchecked.setSpacingAfter(5f);
		} else {
			cell36.addElement(pMSERSchecked);
			pMSERSchecked.setSpacingAfter(5f);
		}
		cell36.addElement(pShall);
		String tsFabia = null;
		tsFabia = conditionDataDTOList.getTsFabia();
		if (tsFabia == null || tsFabia.isEmpty() || !tsFabia.equalsIgnoreCase("true")) {
			cell36.addElement(pFABIAUnchecked);
		} else {
			cell36.addElement(pFABIAChecked);
		}
		cell36.addElement(pborrowers);

		PdfPCell cell40 = new PdfPCell(new Paragraph(isRRB ? Integer.toString(++noCount) : "23", paragraphFont));
		cell40.setPadding(5);
		cell40.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell40.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell41 = new PdfPCell(new Paragraph("Validity of sanction ", paragraphFont));
		cell41.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell41.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell41.setPadding(5);

		PdfPCell cell42 = new PdfPCell();
		Paragraph pTsValiditySanction = new Paragraph(conditionDataDTOList.getTsValiditySanction(), paragraphFont);
		pTsValiditySanction.setAlignment(Element.ALIGN_JUSTIFIED);
		cell42.addElement(pTsValiditySanction);
		cell42.setPadding(5);
		cell42.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell42.setPaddingTop(-3f);

		PdfPCell cell37 = new PdfPCell(new Paragraph(isRRB ? Integer.toString(++noCount) : "24", paragraphFont));
		cell37.setPadding(5);
		cell37.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell37.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell38 = new PdfPCell(new Paragraph("Terms of Sanction", paragraphFont));
		cell38.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell38.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell38.setPadding(5);

		PdfPCell cell39 = new PdfPCell();
		Paragraph parAppendix = new Paragraph();
		parAppendix.add(new Chunk("As per ", paragraphFont));
		parAppendix.add(new Chunk("Appendix.", paragraphFont));
		cell39.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell39.setPadding(5);
		cell39.addElement(parAppendix);
		cell39.setPaddingTop(-3f);

		PdfPCell cell43 = new PdfPCell(new Paragraph(isRRB ? Integer.toString(++noCount) : "25", paragraphFont));
		cell43.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell43.setPadding(5);
		cell43.setBorderWidthBottom(0.2f);
		cell43.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPCell cell44 = new PdfPCell(new Paragraph("DoP for Sanction", paragraphFont));
		cell44.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell44.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell44.setPadding(5);

		PdfPCell cell45 = new PdfPCell();
		Paragraph pTsDopSanction = new Paragraph(conditionDataDTOList.getTsDopSanction(), paragraphFont);
		pTsDopSanction.setAlignment(Element.ALIGN_JUSTIFIED);
		cell45.addElement(pTsDopSanction);
		cell45.setPadding(5);
		cell45.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell45.setPaddingTop(-3f);

		PdfPCell cell46 = new PdfPCell(new Paragraph(isRRB ? Integer.toString(++noCount) : "26", paragraphFont));
		cell46.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell46.setPadding(5);
		cell46.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell47 = new PdfPCell(new Paragraph("DoP for Relaxation", paragraphFont));
		cell47.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell47.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell47.setPadding(5);

		PdfPCell cell48 = new PdfPCell();
		Paragraph pTsDopRelaxtion = new Paragraph(conditionDataDTOList.getTsDopRelaxtion(), paragraphFont);
		pTsDopRelaxtion.setAlignment(Element.ALIGN_JUSTIFIED);
		cell48.addElement(pTsDopRelaxtion);
		cell48.setPadding(5);
		cell48.setPaddingTop(-3f);
		cell48.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell49 = new PdfPCell(new Paragraph(isRRB ? Integer.toString(++noCount) : "27", paragraphFont));
		cell49.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell49.setPadding(5);
		cell49.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell50 = new PdfPCell(new Paragraph("Recommendation", paragraphFont));
		cell50.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell50.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell50.setPadding(5);

		PdfPCell cell51 = new PdfPCell();
		Paragraph pTsRecommendation = new Paragraph(conditionDataDTOList.getTsRecommendation(), paragraphFont);
		pTsRecommendation.setAlignment(Element.ALIGN_JUSTIFIED);
		cell51.addElement(pTsRecommendation);
		cell51.setPadding(5);
		cell51.setPaddingTop(-3f);
		cell51.setHorizontalAlignment(Element.ALIGN_LEFT);

		table.addCell(cell25);
		table.addCell(cell26);
		table.addCell(cell27);

		if (conditionDataDTOList.getTsSpecific() != null && !conditionDataDTOList.getTsSpecific().isEmpty()) {
			table.addCell(cell128);
			table.addCell(cell129);
			table.addCell(cell130);
		}

		table.addCell(cell31);
		table.addCell(cell32);
		table.addCell(cell33);

		table.addCell(cell40);
		table.addCell(cell41);
		table.addCell(cell42);

		table.addCell(cell37);
		table.addCell(cell38);
		table.addCell(cell39);

		table.addCell(cell43);
		table.addCell(cell44);
		table.addCell(cell45);
		table.addCell(cell46);
		table.addCell(cell47);
		table.addCell(cell48);
		table.addCell(cell49);
		table.addCell(cell50);
		table.addCell(cell51);

	}

	private void writeTableHeaderforAppendixOne(PdfPTable table, SanctionTermsConditionsEntity dto, int no,
			Map<Long, ProposedSchemaDTO> map) throws DocumentException {
		logger.info("started writeTableHeaderforAppendixOne in AppraisalMerged");

		String ifvName = "";

		for (S2IFVApplicationEntity applicationEntity : s2IFCCApplicationList) {
			ifvName = applicationEntity.getIfvName();

		}

		PdfPCell cellTandC = new PdfPCell(new Paragraph("Terms and Conditions of Sanction", underlineTextFont));
		cellTandC.setBorderWidth(0);
		cellTandC.setPaddingBottom(10);
		cellTandC.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellTandC.setColspan(3);

		Paragraph p5 = new Paragraph();
		p5.setAlignment(Element.ALIGN_CENTER);
		p5.setSpacingAfter(20);
		Phrase chunk5 = new Phrase("", underlineTextFont);
		p5.add(chunk5);
		PdfPCell cell1 = new PdfPCell(new Paragraph("1", paragraphFont));
		cell1.setPadding(5);
		cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		String fundName = "";
		String schemeName = "";
		BigDecimal tsRAteInterest = BigDecimal.ZERO;
		String tsRoiRepayment = "";
		BigDecimal amount = BigDecimal.ZERO;
		String amountInWords = "";
		BigDecimal tsTunure = BigDecimal.ZERO;
		String tsTenureWd = "";
		String tsExtent = "";
		String tsEligibleMse = "";
		String tsEventDflt = "";
		String tsSecurity = "";
		String tsDocumentstion = "";
		String tsTimeFrame = "";
		String tsDrawaloan = "";

		String tsOtherCond = "";

		Paragraph appPara = new Paragraph("Appendix-" + convertToRoman(no), underlineTextFont);
		appPara.setAlignment(Element.ALIGN_RIGHT);
		PdfPCell cellAppendix = new PdfPCell();
		cellAppendix.setBorderWidth(0);
		cellAppendix.setPaddingBottom(5);
		cellAppendix.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cellAppendix.addElement(appPara);
		cellAppendix.setColspan(3);

		fundName = dto.getFundName() != null ? dto.getFundName() : "";
		schemeName = dto.getSchemeName() != null ? dto.getSchemeName() : "";

		tsRAteInterest = dto.getTsRAteInterest() != null ? dto.getTsRAteInterest() : BigDecimal.ZERO;
		tsRoiRepayment = dto.getTsRoiRepayment() != null ? dto.getTsRoiRepayment() : "";
		amount = dto.getAmount() != null ? dto.getAmount().stripTrailingZeros() : BigDecimal.ZERO;
		amountInWords = dto.getAmountInWords() != null ? dto.getAmountInWords() : "";
		tsTunure = dto.getTsTenurePeriod() != null ? dto.getTsTenurePeriod() : BigDecimal.ZERO;
		tsTenureWd = dto.getTsTenureWd() != null ? dto.getTsTenureWd() : "";
		tsExtent = dto.getTsExtent() != null ? dto.getTsExtent() : "";
		tsEligibleMse = dto.getTsEligibleMse() != null ? dto.getTsEligibleMse() : "";
		tsEventDflt = dto.getTsEventDflt() != null ? dto.getTsEventDflt() : "";
		tsSecurity = dto.getTsSecurity() != null ? dto.getTsSecurity() : "";
		tsDocumentstion = dto.getTsDocumentstion() != null ? dto.getTsDocumentstion() : "";
		tsTimeFrame = dto.getTsTimeFrame() != null ? dto.getTsTimeFrame() : "";
		tsDrawaloan = dto.getTsDrawaloan() != null ? dto.getTsDrawaloan() : "";
		tsOtherCond = dto.getTsOtherCond() != null ? dto.getTsOtherCond() : "";

		if (schemeName.toUpperCase().contains("RMSE")) {
			schemeName = this.getSchemeName(dto.getFundName());
		}

		PdfPCell pSanction = new PdfPCell();
		Paragraph chunkpSanction = new Paragraph("Sanction of refinance to " + ifvName + " under " + schemeName,
				underlineTextFont);
		chunkpSanction.setAlignment(Element.ALIGN_CENTER);
		pSanction.addElement(chunkpSanction);
		pSanction.setBorderWidth(0);
		pSanction.setPaddingBottom(8);
		pSanction.setHorizontalAlignment(Element.ALIGN_CENTER);
		pSanction.setColspan(3);

		PdfPCell cell2 = new PdfPCell(new Paragraph("Fund", paragraphFont));
		cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell2.setPadding(5);

		PdfPCell cell3 = new PdfPCell(new Paragraph("" + fundName, headLineFont));
		cell3.setPadding(5);
		cell3.setHorizontalAlignment(Element.ALIGN_LEFT);

		int count = 0;

		PdfPCell cell4 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell4.setPadding(5);
		cell4.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPCell cell5 = new PdfPCell(new Paragraph(SCHEME, paragraphFont));
		cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell5.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell5.setPadding(5);

		PdfPCell cellSchemeName = new PdfPCell(new Paragraph("" + schemeName, headLineFont));
		cellSchemeName.setPadding(5);
		cellSchemeName.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell6 = new PdfPCell();
		Paragraph pInterest = new Paragraph("Interest will be charged @ " + tsRAteInterest + " % p.a. ("
				+ CurrencyConverter.convert(tsRAteInterest, "Roi") + " per annum.)" + " \n", paragraphFont);
		Paragraph pRoiRepayments = new Paragraph("" + tsRoiRepayment, headLineFont);
		cell6.addElement(pInterest);
		cell6.addElement(pRoiRepayments);
		cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell6.setPaddingTop(-3f);
		cell6.setPaddingLeft(5f);
		cell6.setPaddingBottom(5f);

		PdfPCell cell7 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell7.setPadding(5);
		cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell7.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell8 = new PdfPCell();

		Paragraph para = new Paragraph();
		Phrase phrase1 = new Phrase(AMOUNT, paragraphFont);
		para.add(phrase1);

		cell8.addElement(para);
		cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell8.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell8.setPadding(5);

		PdfPCell cellAmount = new PdfPCell();
		Chunk rupeeChunk = new Chunk(RUPEE, rupeeFont);
		Paragraph pAmount = new Paragraph();
		pAmount.add(rupeeChunk);
		Chunk amountChunk = new Chunk(CommonUtil.formatNumber(formatAmount(amount)) + " crore (" + amountInWords + ")",
				paragraphFont);
		pAmount.add(amountChunk);
		cellAmount.addElement(pAmount);
		cellAmount.setPadding(5);
		cellAmount.setPaddingTop(-4);
		cellAmount.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell9 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell9.setPadding(5);
		cell9.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell9.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell10 = new PdfPCell(new Paragraph("Rate of Interest", paragraphFont));
		cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell10.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell10.setPadding(5);

		String roi = dto.getTsRAteInterest() != null ? formatRoi(dto.getTsRAteInterest()) : "";

		String boldText = "";

		boolean is3MTBillBenchmark = dto.getBenchMark() != null && dto.getBenchMark().toLowerCase().contains("t-bill");
		boolean isRepoRate = dto.getBenchMark() != null && dto.getBenchMark().toLowerCase().contains("repo");

		String benchMark = dto.getBenchMark();

		if (benchMark != null && !benchMark.isBlank()) {

			if (benchMark.toUpperCase().contains(REPO_RATE)) {
				benchMark = RBI_REPO_RATE;
			}

			StringBuilder stringBuilder = new StringBuilder(benchMark);

			if (dto.getSpread() != null && !dto.getSpread().isBlank()) {
				stringBuilder.append(" + " + dto.getSpread() + " bps.");

			}

			boldText = stringBuilder.toString();

		} else {
			roi = dto.getTsRAteInterest() != null ? formatRoi(dto.getTsRAteInterest()) : "";

			boldText = roi + " % p.a " + "(" + CurrencyConverter.convert(new BigDecimal(roi), "Roi") + " per annum.)";
		}

		String text = "Interest will be charged @ ";

		Phrase phrase = new Phrase();
		phrase.add(new Chunk(text, paragraphFont));
		phrase.add(new Chunk(boldText, headLineFont));

		if (benchMark != null && benchMark.toLowerCase().contains("repo")) {

			ProposedSchemaDTO proposedSchemaDTO = map.get(dto.getPrId());
			if (proposedSchemaDTO.getRoiNote() != null && !proposedSchemaDTO.getRoiNote().isBlank()) {
				phrase.add(new Chunk(" (" + proposedSchemaDTO.getRoiNote().trim() + ")", paragraphFont));

				String regex = "(\\d+\\.\\d+)% p\\.a\\.";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(proposedSchemaDTO.getRoiNote());
				if (matcher.find()) {
					String extractedRate = matcher.group(1);
					phrase.add(new Chunk(
							" (" + CurrencyConverter.convert(new BigDecimal(extractedRate), "Roi") + " per annum).",
							paragraphFont));
				}

			}

			if (dto.getSpread() != null && !dto.getSpread().isBlank()) {
				phrase.add(new Chunk(
						" RBI Repo to be on actuals, i.e., Repo will change as and when the same is changed by RBI. (Spread of "
								+ dto.getSpread() + " bps will remain unchanged).",
						headLineFont));
				phrase.add(Chunk.NEWLINE);
				phrase.add(Chunk.NEWLINE);
			}

		}

		Paragraph paragraph = new Paragraph(phrase);

		Paragraph pRoiRepayment = new Paragraph(tsRoiRepayment, paragraphFont);
		pRoiRepayment.setAlignment(Element.ALIGN_JUSTIFIED);

		PdfPCell cellROI = new PdfPCell();
		cellROI.addElement(paragraph);

		if (is3MTBillBenchmark) {
			if (dto.getInterestResetNote() != null && !dto.getInterestResetNote().isBlank()) {
				Phrase subPhrase = new Phrase();
				subPhrase.add(pSpace);
				subPhrase.add(new Chunk("Interest Reset: ", underlineTextFont));
				subPhrase.add(new Chunk(dto.getInterestResetNote(), paragraphFont));
				Paragraph subParagraph = new Paragraph(subPhrase);
				cellROI.addElement(subParagraph);
			}

			if (dto.getBenchMarkNote() != null && !dto.getBenchMarkNote().isBlank()) {
				Phrase subPhrase1 = new Phrase();

				subPhrase1.add(new Chunk("Benchmark: ", underlineTextFont));
				subPhrase1.add(new Chunk(dto.getBenchMarkNote() != null ? dto.getBenchMarkNote() : "", paragraphFont));
				cellROI.addElement(new Paragraph(subPhrase1));

			}

			cellROI.addElement(pRoiRepayment);
		} else if (isRepoRate) {

			cellROI.addElement(pRoiRepayment);

			if (dto.getInterestResetNote() != null && !dto.getInterestResetNote().isBlank()) {
				Phrase subPhrase = new Phrase();
				subPhrase.add(pSpace);
				subPhrase.add(new Chunk("Reset of interest rate: ", underlineTextFont));
				subPhrase.add(new Chunk(dto.getInterestResetNote(), paragraphFont));
				Paragraph subParagraph = new Paragraph(subPhrase);
				cellROI.addElement(subParagraph);
			}

		} else {
			cellROI.addElement(pRoiRepayment);
		}

		cellROI.setPadding(5);
		cellROI.setPaddingBottom(5);
		cellROI.setLeading(16, 0);
		cellROI.setPaddingTop(-3);

		PdfPTable nested1 = new PdfPTable(2);
		nested1.setWidthPercentage(100f);
		nested1.setWidths(new float[] { 5f, 5f });
		nested1.setSpacingBefore(6);
		tenureRepaymentPeriod(nested1);
		tenureRepaymentPeriodDataOnEntity(nested1, dto);

		PdfPCell cellTenure = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cellTenure.setPadding(5);
		cellTenure.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellTenure.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell11 = new PdfPCell(
				new Paragraph("Tenure of\r\n" + "Refinance/\r\n" + "Repayment Peroid\r\n", paragraphFont));
		cell11.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell11.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell11.setLeading(16, 0);
		cell11.setPadding(5);
		cell11.setPaddingTop(1);
		PdfPCell cell12 = new PdfPCell();
		Phrase chTenure = new Phrase("Tenure: ", headLineFont);
		String tenureMsg = dto.getTsTenureApprox() != null ? dto.getTsTenureApprox() : "";
		Chunk chApprox = new Chunk(tsTunure.intValue() + " months " + tenureMsg, headLineFont);
		Paragraph pTsTenurePeriod = new Paragraph(String.valueOf("Tenure: "), paragraphFont);
		chTenure.add(pTsTenurePeriod);
		pTsTenurePeriod.add(chApprox);
		Paragraph pTsTenureWd = new Paragraph(tsTenureWd, paragraphFont);
		cell12.addElement(pTsTenurePeriod);
		cell12.addElement(nested1);
		cell12.addElement(pTsTenureWd);
		cell12.setLeading(16, 0);
		cell12.setPadding(5);
		cell12.setPaddingTop(-4);
		cell12.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cellP6 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cellP6.setPaddingTop(5);
		cellP6.setPadding(5);
		cellP6.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellP6.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cellExtent = new PdfPCell(new Paragraph("Extent of Refinance", paragraphFont));
		cellExtent.setBackgroundColor(BaseColor.WHITE);
		cellExtent.setPadding(5);
		cellExtent.setPaddingTop(1);
		cellExtent.setLeading(16, 0);
		cellExtent.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellExtent.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cellTsExtent = new PdfPCell();
		Paragraph pTsExtent = new Paragraph(String.valueOf(tsExtent), paragraphFont);
		pTsExtent.setAlignment(Element.ALIGN_JUSTIFIED);
		cellTsExtent.addElement(pTsExtent);
		cellTsExtent.setPadding(5);
		cellTsExtent.setPaddingTop(-2);
		cellTsExtent.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell16 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell16.setPaddingTop(5);
		cell16.setPadding(5);
		cell16.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell16.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell17 = new PdfPCell(new Paragraph("Eligible MSE end Borrowers / beneficiaries", paragraphFont));
		cell17.setBackgroundColor(BaseColor.WHITE);
		cell17.setPadding(5);
		cell17.setPaddingTop(1);
		cell17.setLeading(16, 0);
		cell17.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell17.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell18 = new PdfPCell();
		Paragraph pTsEligibleMse = new Paragraph(String.valueOf(tsEligibleMse), paragraphFont);
		pTsEligibleMse.setAlignment(Element.ALIGN_JUSTIFIED);
		cell18.addElement(pTsEligibleMse);
		cell18.setPadding(5);
		cell18.setPaddingTop(-2);
		cell18.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell19 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell19.setPadding(5);
		cell19.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell19.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell20 = new PdfPCell(new Paragraph("Eligible activities", paragraphFont));
		cell20.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell20.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell20.setPadding(5);
		cell20.setPaddingTop(2);

		PdfPCell cell21 = new PdfPCell(new Paragraph("As defined in section 2(h) of SIDBI Act.", paragraphFont));
		cell21.setPadding(5);
		cell21.setPaddingTop(2);
		cell21.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell22 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell22.setPadding(5);
		cell22.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell22.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell23 = new PdfPCell(new Paragraph("Event of Default", paragraphFont));
		cell23.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell23.setPadding(5);
		cell23.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell24 = new PdfPCell();
		Paragraph pTsEventDflt = new Paragraph(tsEventDflt, paragraphFont);
		pTsEventDflt.setAlignment(Element.ALIGN_JUSTIFIED);
		cell24.addElement(pTsEventDflt);
		cell24.setPadding(5);
		cell24.setPaddingTop(-1);
		cell24.setLeading(14, 0);
		cell24.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell25 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell25.setPadding(5);
		cell25.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell25.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell26 = new PdfPCell(new Paragraph("Security", paragraphFont));
		cell26.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell26.setPadding(5);
		cell26.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell27 = new PdfPCell();
		Paragraph pTsSecurity = new Paragraph(tsSecurity, paragraphFont);
		pTsSecurity.setAlignment(Element.ALIGN_JUSTIFIED);
		cell27.addElement(pTsSecurity);
		cell27.setPadding(5);
		cell27.setLeading(14, 0);
		cell27.setPaddingTop(-1);
		cell27.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell28 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell28.setPadding(5);
		cell28.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell28.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell29 = new PdfPCell(new Paragraph("Documentation", paragraphFont));
		cell29.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell29.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell29.setPadding(5);

		PdfPCell cell30 = new PdfPCell();
		Paragraph pTsDocumentstion = new Paragraph(tsDocumentstion, paragraphFont);
		pTsDocumentstion.setAlignment(Element.ALIGN_JUSTIFIED);
		cell30.addElement(pTsDocumentstion);
		cell30.setPadding(5);
		cell30.setPaddingTop(1);
		cell30.setLeading(16, 0);
		cell30.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell31 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell31.setPadding(5);
		cell31.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell31.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell32 = new PdfPCell(new Paragraph("Time frame for acceptance of LOl / Disbursement", paragraphFont));
		cell32.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell32.setPadding(5);
		cell32.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell32.setPadding(4f);
		cell32.setLeading(15, 0);
		cell32.setPaddingTop(1);

		PdfPCell cell33 = new PdfPCell();
		Paragraph pTsTimeFrame = new Paragraph(tsTimeFrame, paragraphFont);
		pTsTimeFrame.setAlignment(Element.ALIGN_JUSTIFIED);
		cell33.addElement(pTsTimeFrame);
		cell33.setPadding(5);
		cell33.setPaddingTop(1);
		cell33.setLeading(16, 0);
		cell33.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell34 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell34.setPadding(5);
		cell34.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell34.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell35 = new PdfPCell(new Paragraph("Drawal of loan", paragraphFont));
		cell35.setPaddingTop(-1);
		cell35.setBackgroundColor(BaseColor.WHITE);
		cell35.setPadding(5);
		cell35.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell35.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell36 = new PdfPCell();
		Paragraph pTsDrawalloan = new Paragraph(tsDrawaloan, paragraphFont);
		pTsDrawalloan.setAlignment(Element.ALIGN_JUSTIFIED);
		cell36.addElement(pTsDrawalloan);
		cell36.setPadding(5);
		cell36.setPaddingTop(-1);
		cell36.setLeading(16, 0);
		cell36.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell37 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell37.setPadding(5);
		cell37.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell37.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell38 = new PdfPCell(new Paragraph("Other Conditions", paragraphFont));
		cell38.setBackgroundColor(BaseColor.WHITE);
		cell38.setPadding(5);
		cell38.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell38.setHorizontalAlignment(Element.ALIGN_LEFT);

		String conNumbers = "";
		String[] conNumber = new String[] {};
		List<Long> conditionNumbers = new ArrayList<>();
		if (tsOtherCond == null || tsOtherCond.isEmpty()) {
			conNumber = new String[] {};
		} else {
			conNumbers = tsOtherCond;
			conNumber = conNumbers.split(",");

			for (String conList : conNumber) {
				conditionNumbers.add(Long.parseLong(conList));
			}
		}

		List<String> conditions = masterRepositoryData.stream().filter(e -> conditionNumbers.contains(e.getMstCode()))
				.map(MasterRepositoryDTO::getMstRemarks).collect(Collectors.toList());
		PdfPCell cell39 = new PdfPCell();
		cell39.setPaddingTop(1);
		cell39.setPadding(5);
		cell39.setHorizontalAlignment(Element.ALIGN_LEFT);
		int SrNo = 1;
		for (String con : conditions) {

			Paragraph p = new Paragraph(SrNo + ".  " + con + "\n\n", paragraphFont);
			p.setAlignment(Element.ALIGN_JUSTIFIED);
			cell39.addElement(p);
			cell39.setPaddingTop(-1);
			SrNo++;
		}
		no++;

		table.addCell(cellAppendix);
		table.addCell(pSanction);
		table.addCell(cellTandC);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cellSchemeName);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cellAmount);
		table.addCell(cell9);

		table.addCell(cell10);
		table.addCell(cellROI);
		table.addCell(cellTenure);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cellP6);
		table.addCell(cellExtent);
		table.addCell(cellTsExtent);
		table.addCell(cell16);
		table.addCell(cell17);
		table.addCell(cell18);
		table.addCell(cell19);
		table.addCell(cell20);
		table.addCell(cell21);
		table.addCell(cell22);
		table.addCell(cell23);
		table.addCell(cell24);
		table.addCell(cell25);
		table.addCell(cell26);
		table.addCell(cell27);
		table.addCell(cell28);
		table.addCell(cell29);
		table.addCell(cell30);
		table.addCell(cell31);
		table.addCell(cell32);
		table.addCell(cell33);
		table.addCell(cell34);
		table.addCell(cell35);
		table.addCell(cell36);
		table.addCell(cell37);
		table.addCell(cell38);
		table.addCell(cell39);
	}

	private void annexureTwo(PdfPTable table) {
		Paragraph p8 = new Paragraph();
		String[] alphabets = { "A", "B", "C", "D", "E", "F", "G", };
		ratingRepositoryData.sort(Comparator.comparing(S2IFVRatingRepositoryEntity::getRtCode));
		List<String> lRtTypes = ratingRepositoryData.stream().map(S2IFVRatingRepositoryEntity::getRtType).distinct()
				.sorted(String::compareTo).collect(Collectors.toList());
		int alphabetIndex = 0;
		for (String rtType : lRtTypes) {
			int count = 1;
			Paragraph pExternal = new Paragraph("\n" + alphabets[alphabetIndex++] + ". " + rtType, headLineFont);
			p8.add(pExternal);
			List<S2IFVRatingRepositoryEntity> filteredData = ratingRepositoryData.stream()
					.filter(e -> e.getRtType().equalsIgnoreCase(rtType)).collect(Collectors.toList());
			for (S2IFVRatingRepositoryEntity entity : filteredData) {
				Paragraph pRtParticulars = new Paragraph(
						"\n     " + count++ + ". " + entity.getRtParticulars1().trim() + "\n", headLineFont);
				pRtParticulars.setSpacingAfter(5f);
				p8.add(pRtParticulars);
				List<String> remarksList = Arrays.asList(entity.getRtRemarks().trim().split("\n"));
				addRemarksWithBullets(p8, remarksList);
			}
		}
		PdfPCell cell = new PdfPCell();
		cell.addElement(p8);
		cell.setPadding(5);
		table.addCell(cell);
	}

	private void addRemarksWithBullets(Paragraph paragraph, List<String> remarksList) {
		for (String remark : remarksList) {
			if (!remark.trim().isEmpty()) {
				Paragraph pRtRemark = new Paragraph();
				Chunk bullet = new Chunk(CONST, paragraphFont);
				List<String> remarkLines = splitText(remark, 82);
				boolean containsBoldMarkers = remark.contains("**");
				for (int j = 0; j < remarkLines.size(); j++) {

					String text = remarkLines.get(j);

					if (text.contains("**")) {
						// Split the text on "**"
						String[] parts = text.split("\\*\\*");
						for (int i = 0; i < parts.length; i++) {
							if (i % 2 == 1) {
								// Text inside "**" should be bold
								if (j == 0) {
									pRtRemark.add(new Chunk(parts[i], headLineFont));
								} else {
									pRtRemark.add(new Chunk("\n  " + parts[i], headLineFont));
								}
							} else {
								// Text outside "**" should be regular
								if (j == 0) {
									pRtRemark.add(new Chunk(parts[i], paragraphFont));
								} else {
									pRtRemark.add(new Chunk("\n  " + parts[i], paragraphFont));
								}
							}
						}
					} else {
						// If no "**" found, add text normally
						if (j == 0) {
							if (!containsBoldMarkers) {
								pRtRemark.add(bullet); // Add bullet only if the entire remark has no **
							}
							pRtRemark.add(new Chunk(text, paragraphFont));
						} else {
							pRtRemark.add(new Chunk("\n  " + text, paragraphFont));
						}
					}

				}
				pRtRemark.setIndentationLeft(30);
				pRtRemark.setLeading(0, 1.2f);
				pRtRemark.setSpacingAfter(5f);

				paragraph.add(pRtRemark);
			} else {
				paragraph.add(new Paragraph("\n", paragraphFont));
			}
		}
	}

	private List<String> splitText(String text, int maxLength) {
		List<String> lines = new ArrayList<>();
		String[] words = text.split(" ");
		StringBuilder currentLine = new StringBuilder();
		for (String word : words) {
			if (currentLine.length() + word.length() + 1 > maxLength) {
				lines.add(currentLine.toString().trim());
				currentLine = new StringBuilder();
			}
			currentLine.append(word).append(" ");
		}
		if (currentLine.length() > 0) {
			lines.add(currentLine.toString().trim());
		}
		return lines;
	}

	private void writeTableHeaderforAnnexureTwo(Paragraph p11) throws DocumentException {
		logger.info("started writeTableHeaderforAnnexureTwo in AppraisalMerged");
		PdfPTable nested4 = new PdfPTable(4);
		nested4.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested4.setWidthPercentage(100f);
		nested4.setWidths(new float[] { 0.6f, 2f, 3f, 4.5f });
		chiefFunctionaryBoard(nested4);
		chiefFunctionaryBoardData(nested4);

		p11.add(nested4);
	}

	private void writeTableHeaderforAnnexureThree(Paragraph p14) throws DocumentException {
		logger.info("started writeTableHeaderforAnnexureThree in AppraisalMerged");
		PdfPTable nested5 = new PdfPTable(3);
		nested5.setWidthPercentage(100f);
		nested5.setWidths(new float[] { 0.7f, 3.5f, 2.3f });
		oprationGeographical(nested5);
		oprationGeographicalDataWithST(nested5);
		p14.add(nested5);
	}

	private void writeTableHeaderforAnnexureFour(Paragraph p15) throws DocumentException {
		PdfPTable nested6 = new PdfPTable(3);
		nested6.setWidthPercentage(100f);
		nested6.setWidths(new float[] { 0.7f, 3.5f, 2.3f });
		keyDomesticInvestors(nested6);
		keyDomesticInvestorsData(nested6);
		p15.add(nested6);
	}

	private void writeTableHeaderforAnnexureFive(Paragraph p16) throws DocumentException {
		PdfPTable nested7 = new PdfPTable(3);
		nested7.setWidthPercentage(100f);
		nested7.setWidths(new float[] { 0.7f, 3.5f, 2.3f });
		nested7.setSpacingBefore(10);
		institutionalBorrowings(nested7);
		institutionalBorrowingsData(nested7);
		p16.add(nested7);
	}

	private void writeTableHeaderforAnnexureSeven(Paragraph p) throws DocumentException {
		PdfPTable nested7 = new PdfPTable(3);
		nested7.setWidthPercentage(100f);
		nested7.setWidths(new float[] { 0.7f, 3.5f, 2.3f });
		nested7.setSpacingBefore(25f);
		disclosure(nested7);
		disclosureData(nested7);
		p.add(nested7);
	}

	private void addTableHeader(PdfPTable table) {
		String[] headers = { "Name of the user, Designation, Office", "Date & Time of receipt", "Action",
				"Date & Time of action", "Comments/\nRemarks", "Forwarded to" };
		for (String header : headers) {
			PdfPCell cell = new PdfPCell();
			cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell.setBorderWidth(1);
			cell.setPhrase(new Phrase(header, headLineFont));
			table.addCell(cell);
		}
	}

	private void addRows(PdfPTable table) {
		String managerName = tblIfvModuleFwdDTO.getModifiedBy() != null && !tblIfvModuleFwdDTO.getModifiedBy().isBlank()
				? tblIfvModuleFwdDTO.getModifiedBy()
				: tblIfvModuleFwdDTO.getCreatedBy();
		String checker1Name = tblIfvModuleFwdDTO.getChecker1Name();
		String checker2Name = tblIfvModuleFwdDTO.getChecker2Name();
		String checker3Name = tblIfvModuleFwdDTO.getChecker3Name();
		String checker4Name = tblIfvModuleFwdDTO.getChecker4Name();
		Long appCurrentUser = tblIfvModuleFwdDTO.getAppCurrentOfficerCode();
		String acceptanceNote = "Accept and Forward";
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String lockedDateAndTime = tblIfvModuleFwdDTO.getLockedDateTime() != null
				? dateTimeFormatter.format(tblIfvModuleFwdDTO.getLockedDateTime())
				: "";

		String makerDesignation;

		if (StringUtils.hasText(tblIfvModuleFwdDTO.getMakerDesignation())) {
			makerDesignation = tblIfvModuleFwdDTO.getMakerDesignation();
		} else {
			makerDesignation = "Manager";
		}

		// Row 1
		table.addCell(createCell(managerName + ", " + makerDesignation + IFV_MUMBAI, Element.ALIGN_LEFT));
		table.addCell(createCell(lockedDateAndTime, Element.ALIGN_CENTER));
		table.addCell(createCell("Originator", Element.ALIGN_CENTER));
		table.addCell(createCell(lockedDateAndTime, Element.ALIGN_CENTER));
		table.addCell(createCell(tblIfvModuleFwdDTO.getLockComment() != null ? tblIfvModuleFwdDTO.getLockComment() : "",
				Element.ALIGN_LEFT));
		String checker1Data = "";
		if (checker1Name != null && !checker1Name.isBlank()) {
			checker1Data = checker1Name + ", " + tblIfvModuleFwdDTO.getChecker1Desg() + IFV_MUMBAI;
		} else if (checker2Name != null && !checker2Name.isBlank()) {
			checker1Data = checker2Name + ", " + tblIfvModuleFwdDTO.getChecker2Desg() + IFV_MUMBAI;
		} else if (checker3Name != null && !checker3Name.isBlank()) {
			checker1Data = checker3Name + ", " + tblIfvModuleFwdDTO.getChecker3Desg() + IFV_MUMBAI;
		} else if (checker4Name != null && !checker4Name.isBlank()) {
			checker1Data = checker4Name + ", " + tblIfvModuleFwdDTO.getChecker4Desg() + IFV_MUMBAI;
		}
		table.addCell(createCell(checker1Data, Element.ALIGN_LEFT));

		if (tblIfvModuleFwdDTO.getAppStatus().equalsIgnoreCase("NW")) {
			return;
		}

		// Row 2
		if (tblIfvModuleFwdDTO.getAppStatus().equalsIgnoreCase("AP") && tblIfvModuleFwdDTO.getChecker1Id() != null
				&& appCurrentUser.intValue() == tblIfvModuleFwdDTO.getChecker1Id().intValue()) {
			acceptanceNote = APPROVED;
		}
		String checker1FwdDateTime = tblIfvModuleFwdDTO.getChecker1FwdDate() != null
				? dateTimeFormatter.format(tblIfvModuleFwdDTO.getChecker1FwdDate())
				: "";

		String checker2Data = "";
		if (!acceptanceNote.equals(APPROVED)) {
			if (checker2Name != null && !checker2Name.isBlank()) {
				checker2Data = checker2Name + ", " + tblIfvModuleFwdDTO.getChecker2Desg() + IFV_MUMBAI;
			} else if (checker3Name != null && !checker3Name.isBlank()) {
				checker2Data = checker3Name + ", " + tblIfvModuleFwdDTO.getChecker3Desg() + IFV_MUMBAI;
			} else if (checker4Name != null && !checker4Name.isBlank()) {
				checker2Data = checker4Name + ", " + tblIfvModuleFwdDTO.getChecker4Desg() + IFV_MUMBAI;
			}
		}

		if (checker1Data != null && !checker1Data.isBlank() && tblIfvModuleFwdDTO.getChecker1Id() != null) {
			table.addCell(createCell(checker1Data, Element.ALIGN_LEFT));
			table.addCell(createCell(lockedDateAndTime, Element.ALIGN_CENTER));
			table.addCell(createCell(checker2Data.isBlank() && !acceptanceNote.equals(APPROVED) ? "" : acceptanceNote,
					Element.ALIGN_CENTER));
			table.addCell(createCell(checker1FwdDateTime, Element.ALIGN_CENTER));
			table.addCell(createCell(
					tblIfvModuleFwdDTO.getChecker1Comment() != null ? tblIfvModuleFwdDTO.getChecker1Comment() : "",
					Element.ALIGN_LEFT));
			table.addCell(createCell(checker2Data, Element.ALIGN_LEFT));
		}

		if (acceptanceNote.equals(APPROVED)) {
			return;
		}
		// Row 3
		String checker3Data = "";
		if (checker3Name != null && !checker3Name.isBlank()) {
			checker3Data = checker3Name + ", " + tblIfvModuleFwdDTO.getChecker3Desg() + IFV_MUMBAI;
		} else if (checker4Name != null && !checker4Name.isBlank()) {
			checker3Data = checker4Name + ", " + tblIfvModuleFwdDTO.getChecker4Desg() + IFV_MUMBAI;
		}
		String checker2FwdDateTime = "";
		if (checker2Data != null && !checker2Data.isBlank() && tblIfvModuleFwdDTO.getChecker2Id() != null) {
			if (tblIfvModuleFwdDTO.getAppStatus().equalsIgnoreCase("AP")
					&& appCurrentUser.intValue() == tblIfvModuleFwdDTO.getChecker2Id().intValue()) {
				acceptanceNote = APPROVED;
			}
			checker2FwdDateTime = tblIfvModuleFwdDTO.getChecker2FwdDate() != null
					? dateTimeFormatter.format(tblIfvModuleFwdDTO.getChecker2FwdDate())
					: "";

			if (tblIfvModuleFwdDTO.getChecker1Id() == null) {
				checker1FwdDateTime = lockedDateAndTime;
			}

			table.addCell(createCell(checker2Data, Element.ALIGN_LEFT));
			table.addCell(createCell(checker1FwdDateTime, Element.ALIGN_CENTER));
			table.addCell(createCell(checker3Data.isBlank() && !acceptanceNote.equals(APPROVED) ? "" : acceptanceNote,
					Element.ALIGN_CENTER));
			table.addCell(createCell(checker2FwdDateTime, Element.ALIGN_CENTER));
			table.addCell(createCell(
					tblIfvModuleFwdDTO.getChecker2Comment() != null ? tblIfvModuleFwdDTO.getChecker2Comment() : "",
					Element.ALIGN_LEFT));
			table.addCell(createCell(acceptanceNote.equals(APPROVED) ? "" : checker3Data, Element.ALIGN_LEFT));
		}
		if (acceptanceNote.equals(APPROVED)) {
			return;
		}
		// Row 4
		String checker4Data = "";
		if (checker4Name != null && !checker4Name.isBlank()) {
			checker4Data = checker4Name + ", " + tblIfvModuleFwdDTO.getChecker4Desg() + IFV_MUMBAI;
		}
		String checker3FwdDateTime = "";
		if (checker3Data != null && !checker3Data.isBlank() && tblIfvModuleFwdDTO.getChecker3Id() != null) {
			if (tblIfvModuleFwdDTO.getAppStatus().equalsIgnoreCase("AP")
					&& appCurrentUser.intValue() == tblIfvModuleFwdDTO.getChecker3Id().intValue()) {
				acceptanceNote = APPROVED;
			}
			checker3FwdDateTime = tblIfvModuleFwdDTO.getChecker3FwdDate() != null
					? dateTimeFormatter.format(tblIfvModuleFwdDTO.getChecker3FwdDate())
					: "";
			table.addCell(createCell(checker3Data, Element.ALIGN_LEFT));

			// Add date logic
			if (tblIfvModuleFwdDTO.getChecker2Id() == null) {
				checker2FwdDateTime = checker1FwdDateTime;
			}

			table.addCell(createCell(checker2FwdDateTime, Element.ALIGN_CENTER));
			table.addCell(createCell(checker4Data.isBlank() && !acceptanceNote.equals(APPROVED) ? "" : acceptanceNote,
					Element.ALIGN_CENTER));
			table.addCell(createCell(checker3FwdDateTime, Element.ALIGN_CENTER));
			table.addCell(createCell(
					tblIfvModuleFwdDTO.getChecker3Comment() != null ? tblIfvModuleFwdDTO.getChecker3Comment() : "",
					Element.ALIGN_LEFT));
			table.addCell(createCell(acceptanceNote.equals(APPROVED) ? "" : checker4Data, Element.ALIGN_LEFT));
		}
		if (acceptanceNote.equals(APPROVED)) {
			return;
		}
		String approvedDateTime = "";
		// Row 5
		if (checker4Data != null && !checker4Data.isBlank() && tblIfvModuleFwdDTO.getChecker4Id() != null) {
			if (tblIfvModuleFwdDTO.getAppStatus().equalsIgnoreCase("AP")
					&& appCurrentUser.intValue() == tblIfvModuleFwdDTO.getChecker4Id().intValue()) {
				acceptanceNote = APPROVED;
			} else {
				acceptanceNote = "";
			}
			approvedDateTime = tblIfvModuleFwdDTO.getApprovedDateTime() != null
					? dateTimeFormatter.format(tblIfvModuleFwdDTO.getApprovedDateTime())
					: "";

			if (tblIfvModuleFwdDTO.getChecker3Id() == null) {
				checker3FwdDateTime = checker2FwdDateTime;
			}

			table.addCell(createCell(checker4Data, Element.ALIGN_LEFT));
			table.addCell(createCell(checker3FwdDateTime, Element.ALIGN_CENTER));
			table.addCell(createCell(acceptanceNote, Element.ALIGN_CENTER));
			table.addCell(createCell(approvedDateTime, Element.ALIGN_CENTER));
			table.addCell(createCell(
					tblIfvModuleFwdDTO.getChecker4Comment() != null ? tblIfvModuleFwdDTO.getChecker4Comment() : "",
					Element.ALIGN_LEFT));
			table.addCell(createCell("", Element.ALIGN_LEFT));
		}
	}

	private void aggregateExposureHeader(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(3);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_N + "No.", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Particulars", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Amount (Cr)", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void aggregateExposureData(PdfPTable table) {

		for (IfvAggregateExposureDto aggregateExposureDto : aggregateExposure) {

			Paragraph slNoPara = new Paragraph(aggregateExposureDto.getSlNo().toString(), paragraphFont);
			slNoPara.setLeading(0f, 1.2f);
			slNoPara.setAlignment(Element.ALIGN_CENTER);

			PdfPCell slNo = new PdfPCell();
			slNo.addElement(slNoPara);
			slNo.setVerticalAlignment(Element.ALIGN_MIDDLE);
			slNo.setHorizontalAlignment(Element.ALIGN_CENTER);
			slNo.setPadding(5f);
			table.addCell(slNo);

			Paragraph particularsPara = new Paragraph(aggregateExposureDto.getParticulars(), paragraphFont);
			particularsPara.setLeading(0f, 1.2f);

			PdfPCell particulars = new PdfPCell();
			particulars.addElement(particularsPara);
			particulars.setVerticalAlignment(Element.ALIGN_MIDDLE);
			particulars.setHorizontalAlignment(Element.ALIGN_LEFT);
			particulars.setPadding(5f);
			table.addCell(particulars);

			String amount = aggregateExposureDto.getAmount() != null
					? CommonUtil.formatNumber(formatAmount(aggregateExposureDto.getAmount()))
					: "";

			Paragraph amountPara = new Paragraph(amount, paragraphFont);
			amountPara.setLeading(0f, 1.2f);
			amountPara.setAlignment(Element.ALIGN_RIGHT);

			PdfPCell amountCell = new PdfPCell();
			amountCell.addElement(amountPara);
			amountCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			amountCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			amountCell.setPadding(5f);
			table.addCell(amountCell);
		}
	}

	private PdfPCell createCell(String content, int alignment) {
		PdfPCell cell = new PdfPCell(new Phrase(content, paragraphFont));
		cell.setHorizontalAlignment(alignment);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5);
		return cell;
	}

	String msg = "";

	public byte[] export() throws DocumentException, MalformedURLException, IOException {

		boolean sBankType = false;
		if (bankType != null && ((bankType.equalsIgnoreCase("PUBLIC SECTOR BANK")
				|| bankType.equalsIgnoreCase("PRIVATE SECTOR BANK") || bankType.equalsIgnoreCase("FOREIGN BANKS")))) {
			sBankType = true;
		}

		String ifvName = s2IFCCApplicationList.get(0).getIfvShortName() != null
				? s2IFCCApplicationList.get(0).getIfvShortName()
				: s2IFCCApplicationList.get(0).getIfvName();

		String header1 = "Refinance to " + ifvName;

		String subject = buildDocSubject();
		String officeNote = "INSTITUTIONAL FINANCE VERTICAL";

		for (S2IFVApplicationEntity applicationEntity : s2IFCCApplicationList) {
			try {

				boolean isApproved = false;

				if (tblIfvModuleFwdDTO.getAppStatus().equalsIgnoreCase("AP")) {
					isApproved = true;
				}

				Document document = new Document(PageSize.A4);
				float baseMargin = 72; // 2.54 cm in points
				document.setMargins(baseMargin, baseMargin, baseMargin, baseMargin);

				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				PdfWriter writer = PdfWriter.getInstance(document, outputStream);
				PageNumberEvent pageNumberEvent = new PageNumberEvent(isApproved, header1, proposedSchemaDetails);
				writer.setPageEvent(pageNumberEvent);
				document.open();

				String documentId = applicationEntity.getAppNumber();

				Paragraph pHeader = new Paragraph();
				pHeader.setAlignment(Element.ALIGN_CENTER);
				pHeader.setSpacingAfter(15);
				pHeader.add(new Phrase("Office Note Approval Process Workflow",
						FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12f)));
				document.add(pHeader);

				Paragraph subjectParagraph = new Paragraph();
				Phrase pPhrase = new Phrase("Subject: ", headLineFont);
				Phrase pPhrase1 = new Phrase(subject, paragraphFont);
				subjectParagraph.add(pPhrase);
				subjectParagraph.add(pPhrase1);
				document.add(subjectParagraph);

				Paragraph officeNoteParagraph = new Paragraph();
				Phrase pPhrase2 = new Phrase("Office Note: ", headLineFont);
				Phrase pPhrase22 = new Phrase(officeNote, paragraphFont);
				officeNoteParagraph.add(pPhrase2);
				officeNoteParagraph.add(pPhrase22);

				document.add(officeNoteParagraph);

				Paragraph documentIdParagraph = new Paragraph();
				Phrase pPhrase3 = new Phrase("Document ID: ", headLineFont);
				Phrase pPhrase33 = new Phrase(documentId, paragraphFont);
				documentIdParagraph.add(pPhrase3);
				documentIdParagraph.add(pPhrase33);
				documentIdParagraph.setSpacingAfter(10);
				document.add(documentIdParagraph);

				PdfPTable table = new PdfPTable(6);
				table.setWidthPercentage(100);
				table.setWidths(new float[] { 3, 2, 2, 2, 3, 2 });

				addTableHeader(table);
				if (CollectionUtils.isEmpty(ifvProposalCheckerDetailDTOs)) {
					addRows(table);
				} else {
					addNewNote(table);
				}
				document.add(table);

				document.newPage();
				Paragraph p1 = new Paragraph();
				p1.setAlignment(Element.ALIGN_CENTER);
				p1.setSpacingAfter(5);
				Phrase chunk1 = new Phrase("MEMORANDUM TO THE IFCC-CGM", underlineTextFont);
				p1.add(chunk1);

				Paragraph p2 = new Paragraph();
				p2.setAlignment(Element.ALIGN_CENTER);
				p2.setSpacingAfter(15);
				Phrase chunk2 = new Phrase("Proposal for sanction of refinance to - " + applicationEntity.getIfvName(),
						underlineTextFont);
				p2.add(chunk2);

				Paragraph p3 = new Paragraph();
				p3.setAlignment(Element.ALIGN_CENTER);
				p3.setSpacingAfter(15);
				p3.setSpacingBefore(8f);
				p3.add(pSpace);
				Phrase chunk3 = new Phrase("IFCC-CGM", underlineTextFont);
				p3.add(chunk3);

				Paragraph pSubmitted = new Paragraph("\nSubmitted for approval.", paragraphFont);
				pSubmitted.add(pSpace);
				pSubmitted.add(pSpace);
				Paragraph pSign = new Paragraph();

				Stream<String> officerName = hrmsEmpName.stream().map(HrmsEmpNameDesignationDTO::getEmpName)
						.map(e -> e.replace("  ", " "));
				Paragraph pName = new Paragraph("" + officerName.collect(Collectors.joining("")), underlineTextFont);
				/*
				 * List<Date> createdDateList = s2IFCCApplicationList.stream()
				 * .map(S2IFVApplicationEntity::getCreatedDate).collect(Collectors.toList());
				 */
				/*
				 * String dateTimeFormatted = ""; if (dateOfAction != null) { DateTimeFormatter
				 * dateformate = DateTimeFormatter.ofPattern(DATE_FORMAT2); LocalDate ld =
				 * dateOfAction.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				 * dateTimeFormatted = ld.format(dateformate); }
				 */
				Stream<String> officerDisg = hrmsEmpName.stream().map(HrmsEmpNameDesignationDTO::getDesigDesc)
						.map(e -> e.replace("  ", ""));
				Paragraph pDisg = new Paragraph("" + officerDisg.collect(Collectors.joining()), underlineTextFont);
				pSign.setAlignment(Element.ALIGN_RIGHT);
				pSign.setIndentationRight(10f);
				pSign.add(pSpace);
				pSign.add(pName);
				pSign.add(pSpace);
				pSign.add(pDisg);
				pSign.add(pSpace);

				PdfPTable signTable = new PdfPTable(1);
				signTable.setWidthPercentage(100);

				PdfPCell makerMainCell = new PdfPCell();

				String makerName = tblIfvModuleFwdDTO.getModifiedBy() != null ? tblIfvModuleFwdDTO.getModifiedBy()
						: tblIfvModuleFwdDTO.getCreatedBy();
				String checker1 = tblIfvModuleFwdDTO.getChecker1Name() != null
						? "(" + tblIfvModuleFwdDTO.getChecker1Name() + ")"
						: "";
				String checker2 = tblIfvModuleFwdDTO.getChecker2Name() != null
						? "(" + tblIfvModuleFwdDTO.getChecker2Name() + ")"
						: "";
				String checker3 = tblIfvModuleFwdDTO.getChecker3Name() != null
						? "(" + tblIfvModuleFwdDTO.getChecker3Name() + ")"
						: "";
				String checker4 = tblIfvModuleFwdDTO.getChecker4Name() != null
						? "(" + tblIfvModuleFwdDTO.getChecker4Name() + ")"
						: "";

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
				String checker1Date = tblIfvModuleFwdDTO.getChecker1FwdDate() != null
						? tblIfvModuleFwdDTO.getChecker1FwdDate().format(formatter)
						: "";

				String checker2Date = tblIfvModuleFwdDTO.getChecker2FwdDate() != null
						? tblIfvModuleFwdDTO.getChecker2FwdDate().format(formatter)
						: "";

				String checker3Date = tblIfvModuleFwdDTO.getChecker3FwdDate() != null
						? tblIfvModuleFwdDTO.getChecker3FwdDate().format(formatter)
						: "";

				String approvedDate = tblIfvModuleFwdDTO.getApprovedDateTime() != null
						? tblIfvModuleFwdDTO.getApprovedDateTime().format(formatter)
						: "";

				String makerDesignation;

				if (StringUtils.hasText(tblIfvModuleFwdDTO.getMakerDesignation())) {
					makerDesignation = tblIfvModuleFwdDTO.getMakerDesignation();
				} else {
					makerDesignation = "Manager";
				}

				Paragraph checker1Cell = new Paragraph("AGM, IFV " + checker1, headLineFont);
				Paragraph checker1CellDate = new Paragraph(DATE + checker1Date, paragraphFont);

				Paragraph checker2Cell = new Paragraph("DGM, IFV " + checker2, headLineFont);
				Paragraph checker2CellDate = new Paragraph(DATE + checker2Date, paragraphFont);

				Paragraph checker3Cell = new Paragraph("GM, IFV " + checker3, headLineFont);
				Paragraph checker3CellDate = new Paragraph(DATE + checker3Date, paragraphFont);

				Paragraph checker4Cell = new Paragraph("CGM, IFV " + checker4, headLineFont);
				Paragraph checker4CellDate = new Paragraph(DATE + approvedDate, paragraphFont);

				if (!makerDesignation
						.equalsIgnoreCase(UserDesignationEnum.ASSISTANT_GENERAL_MANAGER.getDesignationName())) {

					makerMainCell.addElement(checker1Cell);
					makerMainCell.addElement(checker1CellDate);
					makerMainCell.addElement(pSpace);
				}

				makerMainCell.addElement(checker2Cell);
				makerMainCell.addElement(checker2CellDate);
				makerMainCell.addElement(pSpace);

				makerMainCell.addElement(checker3Cell);
				makerMainCell.addElement(checker3CellDate);
				makerMainCell.addElement(pSpace);

				makerMainCell.addElement(checker4Cell);
				makerMainCell.addElement(checker4CellDate);
				makerMainCell.setBorderWidth(0);
				makerMainCell.setHorizontalAlignment(Element.ALIGN_LEFT);
				signTable.addCell(makerMainCell);

				LocalDateTime makerTime = null;

				ZoneId zoneId = ZoneId.systemDefault();

				if (tblIfvModuleFwdDTO.getLockedDateTime() != null) {
					makerTime = tblIfvModuleFwdDTO.getLockedDateTime();
				} else if (tblIfvModuleFwdDTO.getModifiedDate() != null) {
					Instant instant = tblIfvModuleFwdDTO.getModifiedDate().toInstant();
					makerTime = LocalDateTime.ofInstant(instant, zoneId);
				} else {
					Instant instant = tblIfvModuleFwdDTO.getCreatedDate().toInstant();
					makerTime = LocalDateTime.ofInstant(instant, zoneId);
				}

				String checkerDateTimeFormatted = makerTime.format(formatter);

				PdfPCell checkerMainCell = new PdfPCell();
				checkerMainCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

				Paragraph checkerNameCell = new Paragraph(makerDesignation + ", IFV (" + makerName + ")", headLineFont);
				Paragraph checkerdateCell = new Paragraph(DATE + checkerDateTimeFormatted, paragraphFont);
				checkerdateCell.setAlignment(Element.ALIGN_RIGHT);
				checkerNameCell.setAlignment(Element.ALIGN_RIGHT);
				checkerMainCell.addElement(checkerNameCell);

				checkerMainCell.addElement(checkerdateCell);

				checkerMainCell.setBorderWidth(0);

				PdfPTable signTable2 = new PdfPTable(1);

				signTable2.addCell(checkerMainCell);

				Optional<S2IFVRatingRepositoryEntity> ratingList = ratingRepositoryData.stream()
						.filter(e -> e.getRtType() != null || e.getIfvId() != null).findAny();
				Paragraph p6 = new Paragraph();
				p6.setAlignment(Element.ALIGN_RIGHT);
				p6.setSpacingBefore(20);
				p6.setSpacingAfter(15);
				Phrase chunk6 = new Phrase("Annexure I", underlineTextFont);
				p6.add(chunk6);

				Paragraph p7 = new Paragraph();

				p7.setSpacingAfter(15);
				Paragraph chunk7 = new Paragraph("Rating details - " + applicationEntity.getIfvName(),
						underlineTextFont);
				chunk7.setAlignment(Element.ALIGN_CENTER);
				p7.add(chunk7);
				p7.setAlignment(Element.ALIGN_CENTER);

				Optional<S2IFVProfileBdEntity> profilelist = profileBdList.stream()
						.filter(e -> e.getIfvId() != null || e.getPrFirstName() != null).findAny();
				Paragraph p9 = new Paragraph();
				p9.setAlignment(Element.ALIGN_RIGHT);
				p9.setSpacingBefore(20);
				p9.setSpacingAfter(15);

				Phrase chunk9 = new Phrase("Annexure II", underlineTextFont);

				p9.add(chunk9);

				Paragraph p10 = new Paragraph();
				p10.setAlignment(Element.ALIGN_CENTER);
				p10.setSpacingAfter(25);
				Paragraph chunk10 = new Paragraph("Profile of the Board of Directors", underlineTextFont);
				chunk10.setAlignment(Element.ALIGN_CENTER);
				p10.add(chunk10);

				Optional<S2IFVAreasGeographicalEntity> areaGeoList = listOfStAgType.stream()
						.filter(e -> e.getIfvId() != null || e.getAgBranch() != null).findAny();
				Paragraph p12 = new Paragraph();
				p12.setAlignment(Element.ALIGN_RIGHT);
				p12.setSpacingBefore(20);
				p12.setSpacingAfter(15);

				/*
				 * Optional<S2IFVInvestorEntity> investerList = investorDTOList.stream()
				 * .filter(e -> e.getIfvId() != null).findAny();
				 */
				Paragraph pAnnexureFour = new Paragraph();
				pAnnexureFour.setAlignment(Element.ALIGN_CENTER);
				pAnnexureFour.setSpacingBefore(20);
				pAnnexureFour.setSpacingAfter(15);

				Paragraph pAnn4 = new Paragraph();
				pAnn4.setAlignment(Element.ALIGN_RIGHT);
				pAnn4.setSpacingBefore(20);
				pAnn4.setSpacingAfter(15);

				Phrase chunkAnnFour = new Phrase("Annexure III", underlineTextFont);

				pAnn4.add(chunkAnnFour);

				Paragraph pAnnexureFourShare = new Paragraph();
				pAnnexureFourShare.setAlignment(Element.ALIGN_CENTER);
				pAnnexureFourShare.setSpacingAfter(25);
				Paragraph chunkFour = new Paragraph(
						"Lending Mechanism as followed by " + applicationEntity.getIfvName(), underlineTextFont);
				chunkFour.setAlignment(Element.ALIGN_CENTER);
				pAnnexureFourShare.add(chunkFour);

				Paragraph pAnn5 = new Paragraph();
				pAnn5.setAlignment(Element.ALIGN_RIGHT);
				pAnn5.setSpacingBefore(20);
				pAnn5.setSpacingAfter(15);

				Phrase chunkAnnFive1 = new Phrase("Annexure IV", underlineTextFont);

				pAnn5.add(chunkAnnFive1);

				Paragraph pAnnexureFiveShare = new Paragraph();
				pAnnexureFiveShare.setAlignment(Element.ALIGN_CENTER);
				pAnnexureFiveShare.setSpacingAfter(25);
				Paragraph chunkFive = new Paragraph("Risk Control Mechanism of " + applicationEntity.getIfvName(),
						underlineTextFont);
				chunkFive.setAlignment(Element.ALIGN_CENTER);
				pAnnexureFiveShare.add(chunkFive);

				Phrase chunk12 = new Phrase(isRRB ? "Annexure II" : "Annexure V", underlineTextFont);
				p12.add(chunk12);

				Paragraph p13 = new Paragraph();
				p13.setAlignment(Element.ALIGN_CENTER);
				p13.setSpacingAfter(25);
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
				String dateVal = commondtEntityData.getSfbAoDate() != null
						? String.valueOf(format.format(commondtEntityData.getSfbAoDate()))
						: "";
				Paragraph chunk13 = new Paragraph("Branch Network as on " + dateVal, underlineTextFont);
				chunk13.setAlignment(Element.ALIGN_CENTER);
				p13.add(chunk13);

				Paragraph pAnnexureFive = new Paragraph();
				pAnnexureFive.setAlignment(Element.ALIGN_RIGHT);
				pAnnexureFive.setSpacingBefore(20);
				pAnnexureFive.setSpacingAfter(15);

				Phrase chunkAnnFive = new Phrase("Annexure VI", underlineTextFont);
				pAnnexureFive.add(chunkAnnFive);

				Optional<S2IFVInstitutionalEntity> inList = institutionalDTOList.stream()
						.filter(e -> e.getInDate() != null).findAny();
				Optional<S2IFVInstitutionalEntity> institutionalIFVdetails = institutionalDTOList.stream()
						.filter(e -> e.getIfvId() != null).findAny();

				String inDateFormatted = "";
				if (inList.isPresent()) {
					S2IFVInstitutionalEntity inDateList = inList.get();
					Date inDate = inDateList.getInDate();
					DateTimeFormatter inDateFormate = DateTimeFormatter.ofPattern(DATE_FORMAT2);
					LocalDate inDateLocalDate = inDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
					inDateFormatted = inDateLocalDate.format(inDateFormate);
				}

				Paragraph pAnnexure7Share = new Paragraph();
				pAnnexure7Share.setAlignment(Element.ALIGN_CENTER);
				pAnnexure7Share.setSpacingAfter(10);
				Paragraph chunkSeven = new Paragraph("Institutional borrowings as on  : " + inDateFormatted,
						underlineTextFont);
				chunkSeven.setAlignment(Element.ALIGN_CENTER);
				pAnnexure7Share.add(chunkSeven);

				PdfPTable table1 = new PdfPTable(3);
				table1.setWidthPercentage(100f);
				table1.setWidths(new float[] { 0.6f, 2.3f, 7.1f });
				table1.setSpacingBefore(10);

				PdfPTable table2 = new PdfPTable(2);
				table2.setWidthPercentage(100f);
				table2.setWidths(new float[] { 0.6f, 9.4f });

				PdfPTable table3 = new PdfPTable(3);
				table3.setWidthPercentage(100f);
				table3.setWidths(new float[] { 0.6f, 2.3f, 7.1f });

				PdfPTable table102 = new PdfPTable(3);
				table102.setWidthPercentage(100f);
				table102.setWidths(new float[] { 0.6f, 2.3f, 7.1f });

				PdfPTable table4 = new PdfPTable(3);
				table4.setWidthPercentage(100f);
				table4.setWidths(new float[] { 0.6f, 2.3f, 7.1f });
				table4.setSpacingBefore(10);

				Paragraph p11 = new Paragraph();

				Paragraph p14 = new Paragraph();

				Paragraph p15 = new Paragraph();

				Paragraph p16 = new Paragraph();

				writeTableHeader(table1);
				writeTableHeaderforFinecialHighlight(table2);

				writeTableHeaderforRefinanceScheme(table3);

				writeTableHeaderforUpfrontFee(table102);

				writeTableHeaderforAnnexureTwo(p11);
				writeTableHeaderforAnnexureThree(p14);
				writeTableHeaderforAnnexureFour(p15);
				writeTableHeaderforAnnexureFive(p16);

				document.add(p1);
				document.add(p2);
				document.add(table1);
				document.add(table2);
				document.add(table3);
				document.add(table102);
				document.add(pSubmitted);
				document.add(signTable2);
				document.add(signTable);
				document.add(p3);
				document.newPage();

				int no = 1;

				Map<Long, ProposedSchemaDTO> map = proposedSchemaDetails.stream()
						.collect(Collectors.toMap(ProposedSchemaDTO::getPrId, Function.identity()));

				if (sanctionTermsConditionsDto != null && !sanctionTermsConditionsDto.isEmpty()) {

					for (SanctionTermsConditionsEntity dto : sanctionTermsConditionsDto) {

						PdfPTable tableS = new PdfPTable(3);

						tableS.setWidthPercentage(100f);

						tableS.setWidths(new float[] { 0.6f, 2.3f, 7.1f });

						tableS.setSpacingBefore(10);

						writeTableHeaderforAppendixOne(tableS, dto, no, map);

						no++;

						document.add(tableS);

						document.newPage();

					}

				}

				byte[] pdfBytes = fileRepositoryDTO != null ? fileRepositoryDTO.getFileDataBytea() : null;
				if (pdfBytes != null) {
					PdfPTable annexureOneTbl = new PdfPTable(1);
					annexureOnefileData(annexureOneTbl, writer);
					document.add(annexureOneTbl);
				}

				if (ratingList.isPresent()) {
					PdfPTable rtTbl = new PdfPTable(1);
					rtTbl.setWidthPercentage(100);
					rtTbl.setSplitLate(false);
					annexureTwo(rtTbl);
					document.newPage();
					document.add(p6);
					document.add(p7);
					document.add(rtTbl);
				}
				if (bankType != null && ((bankType.equalsIgnoreCase("PUBLIC SECTOR BANK")
						|| bankType.equalsIgnoreCase("PRIVATE SECTOR BANK")
						|| bankType.equalsIgnoreCase("FOREIGN BANKS")))) {
				} else if (profilelist.isPresent()) {
					document.newPage();
					document.add(p9);
					document.add(p10);
					document.add(p11);
				} else {

				}

				List<UcbAnnexureDTO> ann4Data = annexureDTOs.stream().filter(e -> e.getAnnexureNo().intValue() == 4)
						.collect(Collectors.toList());
				List<UcbAnnexureDTO> ann5Data = annexureDTOs.stream().filter(e -> e.getAnnexureNo().intValue() == 5)
						.collect(Collectors.toList());

				if (ann4Data.size() > 0) {
					PdfPTable ann4Tbl = new PdfPTable(1);
					annexureFour(ann4Tbl, ann4Data);
					document.newPage();
					document.add(pAnn4);
					document.add(pAnnexureFourShare);
					document.add(ann4Tbl);
				}

				if (ann5Data.size() > 0) {
					PdfPTable ann5Tbl = new PdfPTable(1);
					annexureFive(ann5Tbl);
					document.newPage();
					document.add(pAnn5);
					document.add(pAnnexureFiveShare);
					document.add(ann5Tbl);
				}

				if (!isRRB && areaGeoList.isPresent()) {
					document.newPage();
					document.add(p12);
					document.add(p13);
					document.add(p14);
				}

				if (isRRB && areaGeoList.isPresent()) {
					document.newPage();
					document.add(p12);
					oprationGeographicalDataForRRB(document);
				}

				if (!sBankType && institutionalIFVdetails.isPresent()) {
					document.newPage();
					document.add(pAnnexureFive);
					document.add(pAnnexure7Share);
					document.add(p16);
				}

				if (disclosureDivergenceDtos != null && disclosureDivergenceDtos.size() > 0) {
					Paragraph pAnn7 = new Paragraph();
					pAnn7.setAlignment(Element.ALIGN_RIGHT);
					pAnn7.setSpacingBefore(20);
					pAnn7.setSpacingAfter(15);

					Phrase cChunk7 = new Phrase("Annexure VII", underlineTextFont);
					pAnn7.add(cChunk7);

					Paragraph pAnn71 = new Paragraph();
					pAnn71.setAlignment(Element.ALIGN_CENTER);
					pAnn71.setSpacingAfter(10);
					Paragraph c71 = new Paragraph("Divergence in Asset Classification and Provisioning",
							underlineTextFont);
					c71.setAlignment(Element.ALIGN_CENTER);
					pAnn71.add(c71);

					Paragraph pAnn7Div = new Paragraph();
					writeTableHeaderforAnnexureSeven(pAnn7Div);

					document.newPage();
					document.add(pAnn7);
					document.add(pAnn71);
					document.add(pAnn7Div);
				}

				document.close();
				writer.close();
				return outputStream.toByteArray();

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Error Occurred while generating pdf. {} ", e.getMessage());
				throw new ReportGenerationException("Error Occurred while generating report: " + msg + " ", e);
			}

		}
		return null;

	}

	public String convertToRoman(int num) {
		logger.info("Started convertToRoman() " + num);
		if (num <= 0 || num > 3999) {
			return "";
		}
		String[] romanSymbols = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };
		int[] values = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
		StringBuilder sb = new StringBuilder();
		int i = 0;
		while (num > 0) {
			while (num >= values[i]) {
				sb.append(romanSymbols[i]);
				num -= values[i];
			}
			i++;
		}
		logger.info("Ended convertToRoman() " + sb.toString());
		return sb.toString();
	}

	private void statusListing(PdfPTable table) {
		PdfPCell cellA = new PdfPCell();
		cellA.setPadding(5f);
		cellA.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellA.setPhrase(new Phrase(" ", headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase("NSE", headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase("BSE", headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

	}

	private void statusListingData(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		for (StatusOfListingDto dto : statusOfListingDtos) {

			cell.setPhrase(new Phrase(dto.getColumn1(), paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			cell.setPhrase(new Phrase(dto.getColumn2() != null ? dto.getColumn2().toPlainString() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);

			cell.setPhrase(new Phrase(dto.getColumn3() != null ? dto.getColumn3().toPlainString() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);

		}

	}

	private void borrowerHeader(PdfPTable table) {

		PdfPCell cell = new PdfPCell();
		cell.setPadding(6);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_N + "No. ", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Customer Name", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		Chunk c1 = new Chunk("Total O/s", headLineFont);
		Chunk c11 = new Chunk("\n(Rs in lakh)", italicFont);

		Phrase p1 = new Phrase();
		p1.add(c1);
		p1.add(c11);

		cell.setPhrase(p1);
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Nature of activity", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setBorderWidthBottom(0);
		table.addCell(cell);
	}

	private void borrowerData(PdfPTable table) {
		int count = 0;

		for (UcbTop10BorrowersDTO dtoList : borrowersDTOs) {
			PdfPCell cellKycId = new PdfPCell(new Phrase(Integer.toString(++count), paragraphFont));
			cellKycId.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellKycId.setPadding(5);
			table.addCell(cellKycId);
			PdfPCell cellKycProductName = new PdfPCell(new Phrase(dtoList.getCustomerName(), paragraphFont));
			cellKycProductName.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellKycProductName.setPadding(5);
			table.addCell(cellKycProductName);

			String totOsFormat = dtoList.getTotalOs() != null
					? CommonUtil.formatNumber(dtoList.getTotalOs().toPlainString())
					: "";

			PdfPCell cellKycAmount = new PdfPCell(new Phrase(totOsFormat, paragraphFont));
			cellKycAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cellKycAmount.setPadding(5);
			table.addCell(cellKycAmount);

			String activity = dtoList.getNatureOfActivity() != null ? dtoList.getNatureOfActivity() : "";

			PdfPCell cellKycShareProfile = new PdfPCell(new Phrase(activity, paragraphFont));
			cellKycShareProfile.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellKycShareProfile.setPadding(5);
			table.addCell(cellKycShareProfile);
		}

		PdfPCell cellKycId = new PdfPCell(new Phrase("", paragraphFont));
		cellKycId.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellKycId.setPadding(5);
		table.addCell(cellKycId);
		PdfPCell cellKycProductName = new PdfPCell(new Phrase(TOTAL, headLineFont));
		cellKycProductName.setHorizontalAlignment(Element.ALIGN_LEFT);
		cellKycProductName.setPadding(5);
		table.addCell(cellKycProductName);

		BigDecimal totOs = borrowersDTOs.stream().map(e -> e.getTotalOs()).reduce(BigDecimal.ZERO, (a, b) -> a.add(b));

		PdfPCell cellKycAmount = new PdfPCell(new Phrase(CommonUtil.formatNumber(totOs.toPlainString()), headLineFont));
		cellKycAmount.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cellKycAmount.setPadding(5);
		table.addCell(cellKycAmount);

		PdfPCell cellKycShareProfile = new PdfPCell(new Phrase("", paragraphFont));
		cellKycShareProfile.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cellKycShareProfile.setPadding(5);
		table.addCell(cellKycShareProfile);

	}

	private void fin2Performance(PdfPTable table) {
		PdfPCell cellA = new PdfPCell();
		cellA.setPadding(5f);
		cellA.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellA.setPhrase(new Phrase("Sl.\nNo.", headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase(PARTICULARS, headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

		DateTimeFormatter formater = DateTimeFormatter.ofPattern(DATE_FORMAT2);

		Date date1 = financialPerformanceDTOs.stream().filter(e -> e.getDate1() != null).map(e -> e.getDate1())
				.findAny().orElse(null);

		LocalDate date1InLocalDate = date1 != null ? date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null;

		String date1InString = date1 != null ? date1InLocalDate.format(formater) : "";

		Date date2 = financialPerformanceDTOs.stream().filter(e -> e.getDate2() != null).map(e -> e.getDate2())
				.findAny().orElse(null);
		LocalDate date2InLocalDate = date2 != null ? date2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null;

		String date2InString = date2 != null ? date2InLocalDate.format(formater) : "";

		cellA.setPhrase(new Phrase("As on " + date1InString, headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

		cellA.setPhrase(new Phrase("As on " + date2InString, headLineFont));
		cellA.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cellA);

	}

	private void fin2PerformaceData(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		int count = 0;
		financialPerformanceDTOs = financialPerformanceDTOs.stream()
				.sorted(Comparator.comparing(UcbFinancialPerformanceDTO::getId)).collect(Collectors.toList());

		for (UcbFinancialPerformanceDTO dto : financialPerformanceDTOs) {

			cell.setPhrase(new Phrase(Integer.toString(++count), paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			cell.setPhrase(new Phrase(dto.getParticulars(), paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			String amount1 = dto.getAmount1() != null ? CommonUtil.formatNumber(dto.getAmount1().toPlainString()) : "";
			String amount2 = dto.getAmount2() != null ? CommonUtil.formatNumber(dto.getAmount2().toPlainString()) : "";

			cell.setPhrase(new Phrase(amount1, paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);

			cell.setPhrase(new Phrase(amount2, paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);

		}

	}

	private void eligibilityCriteria(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase("Sl.\nNo", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Parameters", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("BfS Norm", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Relaxation Cap", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		String compStatus = eligibilityCriteriaDTOs.stream().filter(e -> e.getComplianceStatusYear() != null)
				.map(e -> e.getComplianceStatusYear()).findAny().orElse("");

		cell.setPhrase(new Phrase("Compliance Status\n (" + compStatus + ")", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void addMergedRelaxationCapCell(PdfPTable table, List<UcbEligibilityCriteriaDTO> dtos, int startIndex,
			int rowSpan) {
		PdfPCell mergedCell = new PdfPCell();
		mergedCell.setRowspan(rowSpan);
		mergedCell.setPadding(5f);
		if (!isRRB) {
			mergedCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			mergedCell.setHorizontalAlignment(Element.ALIGN_CENTER);

		}

		StringBuilder content = new StringBuilder();
		for (int i = startIndex; i < startIndex + rowSpan && i < dtos.size(); i++) {
			if (i == startIndex) {
				content.append(dtos.get(i).getRelaxationCap());
				break; // We only need the content from the first applicable row
			}
		}

		if (isRRB) {
			Paragraph relaxationCapPara = new Paragraph(content.toString(), paragraphFont);
			relaxationCapPara.setAlignment(Element.ALIGN_JUSTIFIED);
			mergedCell.addElement(relaxationCapPara);
		} else {
			mergedCell.setPhrase(new Phrase(content.toString(), paragraphFont));
		}

		mergedCell.setLeading(17, 0);
		mergedCell.setPaddingTop(-1f);
		mergedCell.setPaddingBottom(5f);
		mergedCell.setPaddingLeft(5f);
		table.addCell(mergedCell);
	}

	private void eligibilityCriteriaData(PdfPTable table, String status) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		List<UcbEligibilityCriteriaDTO> dtos = eligibilityCriteriaDTOs.stream()
				.filter(e -> e.getEligibilityType().equalsIgnoreCase(status))
				.sorted(Comparator.comparing(UcbEligibilityCriteriaDTO::getId)).collect(Collectors.toList());

		int count = 0;
		for (UcbEligibilityCriteriaDTO dto : dtos) {
			count++;
			cell.setPhrase(new Phrase(Integer.toString(count), paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			cell.setPhrase(new Phrase(dto.getParticulars() != null ? dto.getParticulars() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);
			cell.setPhrase(new Phrase(dto.getBfsNorm() != null ? dto.getBfsNorm() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			if (isRRB) {
				if (count == 1) {
					addMergedRelaxationCapCell(table, dtos, 0, 5);

				} else if (count == 6) {
					addMergedRelaxationCapCell(table, dtos, 5, 2);
				} else if (count > 7) {
					cell.setPhrase(new Phrase((dto.getRelaxationCap() != null && !dto.getRelaxationCap().isEmpty())
							? dto.getRelaxationCap()
							: "", paragraphFont));
					cell.setBackgroundColor(BaseColor.WHITE);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
				}
			} else {
				if (count == 1) {
					addMergedRelaxationCapCell(table, dtos, 0, 7);

				} else if (count == 8) {
					addMergedRelaxationCapCell(table, dtos, 4, 3);
				} else if (count > 7) {
					cell.setPhrase(new Phrase((dto.getRelaxationCap() != null && !dto.getRelaxationCap().isEmpty())
							? dto.getRelaxationCap()
							: "", paragraphFont));
					cell.setBackgroundColor(BaseColor.WHITE);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
				}
			}

			cell.setPhrase(
					new Phrase(dto.getComplianceStatus() != null ? dto.getComplianceStatus() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setLeading(17, 0);
			cell.setPaddingTop(-1f);
			cell.setPaddingBottom(5f);
			cell.setPaddingLeft(5f);
			table.addCell(cell);
		}
	}

	private void eligibilityCriteria1(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase(SL_NO, headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Board / RiMC stipulation", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Compliance", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void eligibilityCriteriaData1(PdfPTable table, String status) {
		List<UcbEligibilityCriteriaDTO> dtos = eligibilityCriteriaDTOs.stream()
				.filter(e -> e.getEligibilityType().equalsIgnoreCase(status))
				.sorted(Comparator.comparing(UcbEligibilityCriteriaDTO::getId)).collect(Collectors.toList());
		int count = 0;
		for (UcbEligibilityCriteriaDTO dto : dtos) {
			// First column - Count
			PdfPCell countCell = new PdfPCell();
			countCell.setPadding(5f);
			countCell.setPhrase(new Phrase(Integer.toString(++count), paragraphFont));
			countCell.setBackgroundColor(BaseColor.WHITE);
			countCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(countCell);
			// Second column - Particulars
			PdfPCell particularsCell = new PdfPCell();
			particularsCell.setPadding(5f);
			Paragraph particularsPara = new Paragraph(dto.getParticulars() != null ? dto.getParticulars() : "",
					paragraphFont);
			particularsPara.setAlignment(Element.ALIGN_JUSTIFIED);
			particularsCell.addElement(particularsPara);
			particularsCell.setBackgroundColor(BaseColor.WHITE);
			particularsCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			particularsCell.setLeading(17, 0);
			particularsCell.setPaddingTop(-1f);
			particularsCell.setPaddingBottom(5f);
			particularsCell.setPaddingLeft(5f);
			table.addCell(particularsCell);
			// Third column - Compliance Status
			PdfPCell complianceCell = new PdfPCell();
			complianceCell.setPadding(5f);
			Paragraph compliancePara = new Paragraph(dto.getComplianceStatus() != null ? dto.getComplianceStatus() : "",
					paragraphFont);
			compliancePara.setAlignment(Element.ALIGN_JUSTIFIED);
			complianceCell.addElement(compliancePara);
			complianceCell.setBackgroundColor(BaseColor.WHITE);
			complianceCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			complianceCell.setLeading(17, 0);
			complianceCell.setPaddingTop(-1f);
			complianceCell.setPaddingBottom(5f);
			complianceCell.setPaddingLeft(5f);
			table.addCell(complianceCell);
		}
	}

	public void writeTableHeaderforComp(PdfPTable table) throws DocumentException {
		PdfPCell cell7 = new PdfPCell(new Paragraph("17", paragraphFont));
		cell7.setPadding(5);
		cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell7.setBorderWidthBottom(0);
		cell7.setBorderWidthRight(0);

		PdfPTable nested3 = new PdfPTable(4);
		nested3.setWidthPercentage(100);
		nested3.setWidths(new float[] { 5, 40, 10, 45 });
		nested3.setSpacingBefore(10);
		criteria(nested3);
		criteriaData(nested3);

		String note = criteriaParameterDTOs.stream().filter(e -> e.getNote() != null).map(e -> e.getNote()).findAny()
				.orElse("");

		PdfPCell cell8 = new PdfPCell();
		Paragraph pNote = new Paragraph(note, paragraphFont);
		cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell8.setBackgroundColor(BaseColor.WHITE);
		cell8.setPadding(4);
		cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell8.addElement(pNote);
		cell8.addElement(nested3);
		cell8.setBorderWidthBottom(0);

		table.addCell(cell7);
		table.addCell(cell8);
	}

	private void criteria(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setPhrase(new Phrase("Sl.\nNo", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Criteria parameters for qualifying as FSWM", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Complied\n(Y/N)", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

		String date1InString = criteriaParameterDTOs.stream().filter(e -> e.getComplianceDate() != null)
				.map(e -> e.getComplianceDate()).findAny().orElse("");
		cell.setPhrase(new Phrase("Compliance\n(" + date1InString + ")", headLineFont));
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		table.addCell(cell);

	}

	private void criteriaData(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5f);

		List<UcbCriteriaParameterDTO> dtos = criteriaParameterDTOs.stream()
				.sorted(Comparator.comparing(UcbCriteriaParameterDTO::getId)).collect(Collectors.toList());

		int count = 0;

		for (UcbCriteriaParameterDTO dto : dtos) {

			cell.setPhrase(new Phrase(Integer.toString(++count), paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			cell.setPhrase(
					new Phrase(dto.getCriteriaParameters() != null ? dto.getCriteriaParameters() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setLeading(17, 0);
			cell.setPaddingTop(-1f);
			cell.setPaddingBottom(5f);
			cell.setPaddingLeft(5f);
			table.addCell(cell);

			cell.setPhrase(new Phrase(dto.getComplied() != null ? dto.getComplied().toString() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setLeading(17, 0);
			cell.setPaddingTop(-1f);
			cell.setPaddingBottom(5f);
			cell.setPaddingLeft(5f);
			table.addCell(cell);

			cell.setPhrase(new Phrase(dto.getComplied() != null ? dto.getCompliance() : "", paragraphFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setLeading(17, 0);
			cell.setPaddingTop(-1f);
			cell.setPaddingBottom(5f);
			cell.setPaddingLeft(5f);
			table.addCell(cell);

		}

	}

	public void annexureOnefileData(PdfPTable table, PdfWriter writer) throws IOException, BadElementException {
		byte[] pdfBytes = fileRepositoryDTO.getFileDataBytea();
		if (fileRepositoryDTO.getFileType().equalsIgnoreCase("pdf")) {
			table.setWidthPercentage(100);
			PdfReader reader = new PdfReader(new ByteArrayInputStream(pdfBytes));
			for (int i = 1; i <= reader.getNumberOfPages(); i++) {
				PdfImportedPage page = writer.getImportedPage(reader, i);
				PdfPCell cell = new PdfPCell(Image.getInstance(page));
				table.addCell(cell);
			}
		} else {

		}
	}

	private void annexureFour(PdfPTable table, List<UcbAnnexureDTO> data) {

		Paragraph p8 = new Paragraph();

		String note = annexureDTOs.parallelStream()
				.filter(e -> e.getNote() != null && e.getAnnexureNo().intValue() == 4).map(e -> e.getNote()).findAny()
				.orElse("");
		Paragraph pExternal = new Paragraph(note, paragraphFont);
		p8.add(pExternal);

		PdfPCell cell = new PdfPCell();
		cell.addElement(p8);
		cell.setPadding(5);
		cell.setPaddingBottom(20);
		table.setWidthPercentage(100);
		table.addCell(cell);

	}

	private void annexureFive(PdfPTable table) {

		Paragraph p8 = new Paragraph();

		String note = annexureDTOs.parallelStream()
				.filter(e -> e.getNote() != null && e.getAnnexureNo().intValue() == 5).map(e -> e.getNote()).findAny()
				.orElse("");
		Paragraph pExternal = new Paragraph(note, paragraphFont);
		p8.add(pExternal);

		PdfPCell cell = new PdfPCell();
		cell.addElement(p8);
		cell.setPadding(5);
		cell.setPaddingBottom(20);
		table.setWidthPercentage(100);
		table.addCell(cell);

	}

	public String getSchemeName(String schemeName) {
		String wordToFind = "FUND";
		int index = schemeName.indexOf(wordToFind);
		if (index != -1) {
			return schemeName.substring(0, index).trim();
		}
		return schemeName;
	}

	public Paragraph makeWordBold(String sentence) {
		// Regular expression to match words between single stars
		Pattern pattern = Pattern.compile("\\*(.*?)\\*");
		Matcher matcher = pattern.matcher(sentence);
		// Create a Paragraph object to build the PDF content
		Paragraph p = new Paragraph();
		int lastEnd = 0;
		while (matcher.find()) {
			// Add the text before the bold word
			if (matcher.start() > lastEnd) {
				p.add(new Phrase(sentence.substring(lastEnd, matcher.start()), paragraphFont));
			}
			// Add the bold word
			p.add(new Phrase(matcher.group(1), headLineFont));
			lastEnd = matcher.end();
		}
		// Add any remaining text after the last bold word
		if (lastEnd < sentence.length()) {
			p.add(new Phrase(sentence.substring(lastEnd), paragraphFont));
		}

		return p;
	}

	private String processSchemeName(String schemeName, String fundName) {
		if (schemeName.toUpperCase().contains("RMSE")) {
			return getSchemeName(fundName);
		} else if (schemeName.toUpperCase().contains("FINANCIAL ASSISTANCE")) {
			return "FABIA";
		} else if (schemeName.toUpperCase().contains("SFB")) {
			return "RSFB";
		} else if (schemeName.toUpperCase().contains("RAMPE")) {
			return "RAMPE";
		}
		return schemeName;
	}

	private String buildDocSubject() {
		S2IFVApplicationEntity ifccApplication = s2IFCCApplicationList.get(0);
		String ifvShortName = Optional.ofNullable(ifccApplication.getIfvShortName()).filter(s -> !s.isBlank())
				.orElse(ifccApplication.getIfvName());
		return ifvShortName + "_Refinance Proposal_" + proposedSchemaDetails.stream().map(e -> {
			String amount = "Rs." + e.getPrAmount().stripTrailingZeros().toPlainString() + " Cr";
			String schemeName = processSchemeName(e.getPrSchemeName(), e.getPrFundname());
			return amount + "_" + schemeName;
		}).collect(Collectors.joining(" & "));
	}

	private void addNewNote(PdfPTable table) {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		for (IFVProposalCheckerDetailDTO detailDTO : ifvProposalCheckerDetailDTOs) {
			table.addCell(createCell(
					detailDTO.getCurrentUserName() + ", " + detailDTO.getCurrentUserDesignation() + IFV_MUMBAI,
					Element.ALIGN_LEFT));
			table.addCell(createCell(dateTimeFormatter.format(detailDTO.getDateTimeOfReceipt()), Element.ALIGN_CENTER));
			table.addCell(createCell(detailDTO.getCurrentUserAction(), Element.ALIGN_CENTER));
			table.addCell(createCell(dateTimeFormatter.format(detailDTO.getDateTimeOfAction()), Element.ALIGN_CENTER));
			table.addCell(createCell(detailDTO.getCurrentUserComment() != null ? detailDTO.getCurrentUserComment() : "",
					Element.ALIGN_LEFT));
			String fwdUserDetails = StringUtils.hasText(detailDTO.getForwardedUserName())
					? detailDTO.getForwardedUserName() + ", " + detailDTO.getForwardedUserDesignation() + IFV_MUMBAI
					: "";
			table.addCell(createCell(fwdUserDetails, Element.ALIGN_LEFT));

		}

	}

}
