package com.sidbi.ifv.security;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.sidbi.ifv.config.JwtTokenUtil;
import com.sidbi.ifv.services.JwtUserDetailsService;
import com.sidbi.ifv.util.Constants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class JwtAuthFilter extends OncePerRequestFilter {

	private final JwtTokenUtil jwtTokenUtil;
	private final JwtUserDetailsService userDetailsService;

	@Value("${service.auth.issuer}")
	private String serviceIssuer;

	@Value("${service.auth.secret}")
	private String serviceSecret;

	private SecretKey serviceKey;

	@PostConstruct
	public void init() {
		this.serviceKey = Keys.hmacShaKeyFor(serviceSecret.getBytes(StandardCharsets.UTF_8));
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String serviceToken = request.getHeader("X-Service-Token");
		String authHeader = request.getHeader("Authorization");

		if (SecurityContextHolder.getContext().getAuthentication() != null) {
			filterChain.doFilter(request, response);
			return;
		}

		try {
			if (authHeader != null && authHeader.startsWith("Bearer ")) {
				if (!handleUserToken(authHeader, request, response))
					return;
			} else if (serviceToken != null && !serviceToken.isBlank()) {
				if (!handleServiceToken(serviceToken, response))
					return;
			}

		} catch (Exception e) {
			log.error("Authentication error", e);
			sendErrorResponse(response, HttpServletResponse.SC_UNAUTHORIZED, "Authentication failed");
			return;
		}

		filterChain.doFilter(request, response);
	}

	private boolean handleServiceToken(String token, HttpServletResponse response) throws IOException {

		try {
			Claims claims = Jwts.parser().clockSkewSeconds(30).verifyWith(serviceKey).build().parseSignedClaims(token)
					.getPayload();

			String subject = claims.getSubject();
			String scope = claims.get("scope", String.class);

			if (!"service-account".equals(subject) || !"service-to-service".equals(scope)) {

				log.warn("Invalid service token claims");
				sendErrorResponse(response, 401, "Invalid service token claims");
				return false;
			}

			UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(subject, null,
					List.of());

			SecurityContextHolder.getContext().setAuthentication(auth);
			log.info("Service authenticated");

			return true;

		} catch (ExpiredJwtException e) {
			log.warn("Service token expired");
			sendErrorResponse(response, 401, "Service token expired");
		} catch (SignatureException e) {
			log.error("Invalid service token signature", e);
			sendErrorResponse(response, 401, "Invalid service token");
		} catch (Exception e) {
			log.error("Service token validation failed", e);
			sendErrorResponse(response, 401, "Service token validation failed");
		}

		return false;
	}

	private boolean handleUserToken(String authHeader, HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		String token = authHeader.substring(7);

		try {
			if (!jwtTokenUtil.validateTokenWithoutUser(token)) {
				sendErrorResponse(response, 401, Constants.INVALID_TOKEN);
				return false;
			}

			String username = jwtTokenUtil.getUsernameFromToken(token);

			if (username == null) {
				sendErrorResponse(response, 401, Constants.INVALID_TOKEN);
				return false;
			}

			UserDetails userDetails = userDetailsService.loadUserByUsername(username);

			if (!jwtTokenUtil.validateToken(token, userDetails)) {
				sendErrorResponse(response, 401, Constants.INVALID_TOKEN);
				return false;
			}

			UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(userDetails, null,
					userDetails.getAuthorities());

			auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

			SecurityContextHolder.getContext().setAuthentication(auth);
			log.info("User authenticated: {}", username);

			return true;

		} catch (ExpiredJwtException e) {
			log.warn("User token expired");
			sendErrorResponse(response, 401, "Token expired");
		} catch (UsernameNotFoundException e) {
			log.warn("User not found");
			sendErrorResponse(response, 401, "User not found");
		} catch (Exception e) {
			log.warn(Constants.INVALID_TOKEN, e);
			sendErrorResponse(response, 401, Constants.INVALID_TOKEN);
		}

		return false;
	}

	private void sendErrorResponse(HttpServletResponse response, int status, String message) throws IOException {

		response.setStatus(status);
		response.setContentType("application/json");
		response.getWriter().write("{\"error\": \"" + message + "\"}");
	}
}