package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class AssPastdisbDTO {

	private Long aeId;

	private Long ifvId;

	private Integer aePeriodfy;

	private Date aeDate;

	private BigDecimal aeAmount;

	private String aeScheme;

	private BigDecimal aeRoi;

	private String aeTenure;

	private String aeType;
}
