package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MinutesColendingLimitDTO {

	private Long id;

	private Integer minuteSanctionId;

	private String bankName;

	private String cifNumber;

	private BigDecimal lendingLimit;

	@Column(length = 150)
	private String scheme;

	private String riskSharingRatio;

	private BigDecimal initialOperatingLimit;

	private String remarks;

	private String createdBy;

	private LocalDate createdDate;

	private String sancStatus;
}
