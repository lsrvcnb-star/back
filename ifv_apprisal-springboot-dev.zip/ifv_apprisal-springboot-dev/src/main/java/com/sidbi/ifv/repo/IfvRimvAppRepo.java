package com.sidbi.ifv.repo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.IfvRimvApp;

public interface IfvRimvAppRepo extends JpaRepository<IfvRimvApp, Long>, JpaSpecificationExecutor<IfvRimvApp> {

	@Query("SELECT i.rimvRefId FROM IfvRimvApp i WHERE i.createdDateTime >= :startDate ORDER BY i.createdDateTime DESC LIMIT 1")
	String findLatestAppNoFromDate(@Param("startDate") LocalDateTime startDate);

	@Query("SELECT a.fwdStatus, COUNT(a) FROM IfvRimvApp a GROUP BY a.fwdStatus")
	List<Object[]> countAppsByStatus();

}
