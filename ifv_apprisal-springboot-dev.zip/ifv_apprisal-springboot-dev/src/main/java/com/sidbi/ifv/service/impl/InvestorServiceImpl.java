package com.sidbi.ifv.service.impl;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.InvestorDTO;
import com.sidbi.ifv.dto.SfbCommondtDTO;
import com.sidbi.ifv.entity.S2IFVInvestorEntity;
import com.sidbi.ifv.entity.S2IFVSfbCommondtEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.InvestorRepository;
import com.sidbi.ifv.repo.SfbCommondtRepository;
import com.sidbi.ifv.services.InvestorService;

@Service
public class InvestorServiceImpl implements InvestorService {

	private static final Logger logger = LoggerFactory.getLogger(InvestorServiceImpl.class);

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private InvestorRepository investorRepo;

	@Autowired
	private SfbCommondtRepository sfbCommondtRepository;

	String msg = "";

	@Override
	public List<InvestorDTO> findAll() {
		logger.info("findAll() started in InvestorServiceImpl for S2IFVInvestorEntity");
		try {
			List<S2IFVInvestorEntity> list = investorRepo.findAll();
			return list.stream().map(s -> modelMapper.map(s, InvestorDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVInvestorEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVInvestorEntity entities." + msg + " ", e);
		}
	}

	@Override
	public InvestorDTO findById(Long id) {

		logger.info("findById() started in InvestorServiceImpl for S2IFVInvestorEntity");
		try {
			S2IFVInvestorEntity investorEntity = investorRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVInvestorEntity", id));
			return modelMapper.map(investorEntity, InvestorDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching S2IFVInvestorEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching S2IFVInvestorEntity entities." + msg + " ", e);
		}
	}

	@Override
	public InvestorDTO save(InvestorDTO investorDTO) {
		logger.info("save() started in InvestorServiceImpl for S2IFVInvestorEntity");
		try {
			S2IFVInvestorEntity investorEntity = modelMapper.map(investorDTO, S2IFVInvestorEntity.class);
			investorRepo.save(investorEntity);
			return modelMapper.map(investorEntity, InvestorDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while saving S2IFVInvestorEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while saving S2IFVInvestorEntity entities." + msg + " ", e);
		}
	}

	@Override
	public InvestorDTO update(Long id, InvestorDTO investorDTO) {
		logger.info("update() started in InvestorServiceImpl for S2IFVInvestorEntity");
		try {
			S2IFVInvestorEntity investorEntity = investorRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVInvestorEntity", id));
			BeanUtils.copyProperties(investorDTO, investorEntity);
			investorRepo.save(investorEntity);
			return modelMapper.map(investorEntity, InvestorDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching S2IFVInvestorEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching S2IFVInvestorEntity entities." + msg + " ", e);
		}
	}

	@Override
	public void deleteAppraisal(Long id) {
		logger.info("deleteAppraisal() started in InvestorServiceImpl for S2IFVInvestorEntity");
		try {
			S2IFVInvestorEntity investorEntity = investorRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVInvestorEntity", id));
			investorRepo.delete(investorEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleteing S2IFVInvestorEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleteing S2IFVInvestorEntity entity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public List<InvestorDTO> saveAll(List<InvestorDTO> lsitInvestorDTO) {
		logger.info("saveAll() started in InvestorServiceImpl for List of S2IFVInvestorEntity");
		try {
			List<S2IFVInvestorEntity> investorEntitiesToSave = lsitInvestorDTO.stream()
					.map(investorDTO -> modelMapper.map(investorDTO, S2IFVInvestorEntity.class))
					.collect(Collectors.toList());
			List<S2IFVInvestorEntity> savedInvestorEntities = investorRepo.saveAll(investorEntitiesToSave);

			return savedInvestorEntities.stream()
					.map(investorEntity -> modelMapper.map(investorEntity, InvestorDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVInvestorEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVInvestorEntity entities." + msg + " ", e);

		}
	}

	@Override
	public List<InvestorDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in InvestorServiceImpl ");
		try {
			List<S2IFVInvestorEntity> listInvestorEntities = investorRepo.findByIfvId(ifvId);
			return listInvestorEntities.stream()
					.map(investorEntity -> modelMapper.map(investorEntity, InvestorDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVInvestorEntities based on IfvId. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVInvestorEntities based on IfvId." + ifvId + " " + msg + " ",
					e);

		}
	}

	@Override
	public CommonDTO saveCommonDTO(CommonDTO commonDTO) {
		logger.info("Started saveCommonDTO() in InvestorServiceImpl");
		SfbCommondtDTO sfbCommondtDTO = commonDTO.getSfbCommondtDTO();
		logger.info("sfbCommondtDTO {} ", sfbCommondtDTO);
		List<InvestorDTO> lsitInvestorDTO = commonDTO.getListInvestorDTO();
		logger.info("lsitInvestorDTO {} ", lsitInvestorDTO);
		try {
			List<S2IFVSfbCommondtEntity> s2ifvSfbCommondtEntities = sfbCommondtRepository
					.findByIfvId(sfbCommondtDTO.getIfvId());
			S2IFVSfbCommondtEntity s2ifvSfbCommondtEntity = (s2ifvSfbCommondtEntities != null
					&& !s2ifvSfbCommondtEntities.isEmpty()) ? s2ifvSfbCommondtEntities.get(0)
							: modelMapper.map(sfbCommondtDTO, S2IFVSfbCommondtEntity.class);
			s2ifvSfbCommondtEntity.setCmKeyInvestorsNote(sfbCommondtDTO.getCmKeyInvestorsNote());
			S2IFVSfbCommondtEntity savedS2ifvSfbCommondtEntity = sfbCommondtRepository.save(s2ifvSfbCommondtEntity);
			logger.info("s2ifvSfbCommondtEntity {} ", s2ifvSfbCommondtEntity);
			List<S2IFVInvestorEntity> investorEntitiesToSave = lsitInvestorDTO.stream()
					.map(investorDTO -> modelMapper.map(investorDTO, S2IFVInvestorEntity.class))
					.collect(Collectors.toList());
			List<S2IFVInvestorEntity> savedInvestorEntities = investorRepo.saveAll(investorEntitiesToSave);
			logger.info("savedInvestorEntities {} ", savedInvestorEntities);
			CommonDTO commonDTO2 = new CommonDTO();
			commonDTO2.setListInvestorDTO(savedInvestorEntities.stream()
					.map(investorEntity -> modelMapper.map(investorEntity, InvestorDTO.class))
					.collect(Collectors.toList()));
			commonDTO2.setSfbCommondtDTO(modelMapper.map(savedS2ifvSfbCommondtEntity, SfbCommondtDTO.class));
			logger.info("commonDTO2 {} ", commonDTO2);
			return commonDTO2;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing saveCommonDTO. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while executing saveCommonDTO." + msg + " ", e);
		}

	}

	@Override
	public CommonDTO findCommonDTOByIfvId(Long ifvId) {
		logger.info("Started findCommonDTOByIfvId() in InvestorServiceImpl with ifvId {} ", ifvId);
		try {
			List<S2IFVInvestorEntity> s2ifvInvestorEntities = investorRepo.findByIfvId(ifvId);
			logger.info("s2ifvInvestorEntities {} ", s2ifvInvestorEntities);
			List<S2IFVSfbCommondtEntity> listS2IFVSfbCommondtEntities = sfbCommondtRepository.findByIfvId(ifvId);
			SfbCommondtDTO sfbCommondtDTO = listS2IFVSfbCommondtEntities.stream().findFirst()
					.map(s2IFVSfbCommondtEntity -> modelMapper.map(s2IFVSfbCommondtEntity, SfbCommondtDTO.class))
					.orElse(null);
			logger.info("sfbCommondtDTO {}", sfbCommondtDTO);
			CommonDTO commonDTO = new CommonDTO();
			commonDTO.setSfbCommondtDTO(sfbCommondtDTO);
			commonDTO.setListInvestorDTO(
					s2ifvInvestorEntities.stream().sorted(Comparator.comparing(S2IFVInvestorEntity::getKiId))
							.map(investorEntity -> modelMapper.map(investorEntity, InvestorDTO.class))
							.sorted(Comparator.comparing(InvestorDTO::getKiId)).collect(Collectors.toList()));
			logger.info("commonDTO {}", commonDTO);
			return commonDTO;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing findCommonDTOByIfvId based on IfvId. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while executing findCommonDTOByIfvId based on IfvId." + ifvId + " " + msg + " ", e);
		}
	}
}