package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_ELIGIBILITY")
public class S2IFVEligibilityEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EC_ID")
	private Long ecId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "EC_REMARKS")
	private String ecRemarks;

	@Column(name = "EC_BFSNORMS")
	private String ecBfsnorms;

	@Column(name = "EC_REMARKS1")
	private String ecRemarks1;

	@Column(name = "EC_BFSNORMS1")
	private String ecBfsnorms1;

	@Column(name = "EC_BFNORMSELIGIBILITY")
	private String ecBfnormseligibility;

	@Column(name = "EC_PSBS")
	private String ecPsbs;

	@Column(name = "EC_SECTFOREIGNBANK")
	private String ecSectForEignBank;

	@Column(name = "EC_NNPADATE")
	private Date ecNnpaDate;

	@Column(name = "EC_NNPAPERCENT")
	private BigDecimal ecNnpaPercent;

	@Column(name = "EC_NNOAREMARKS")
	private String ecNnoaRemarks;

	@Column(name = "EC_NNPASTATUS")
	private String ecNnpaStatus;

	@Column(name = "EC_RMSEASSISTANCE")
	private String ecRmseAssistance;

	@Column(name = "EC_RMSESTATUS")
	private String ecRmseStatus;

	@Column(name = "EC_ASSSTANCE")
	private String ecAssstance;

	@Column(name = "EC_ASSSTANCESTATUS")
	private String ecAssstanceStatus;

	@Column(name = "EC_RBICOMPLIANCE")
	private String ecRbiCompliance;

	@Column(name = "EC_RBISTATUS")
	private String ecRbiStatus;

	@Column(name = "EC_GSECDATE")
	private Date ecGsecDate;

	@Column(name = "EC_GSECPERCENT")
	private BigDecimal ecGsecPercent;

	@Column(name = "EC_SIDBIFIXED")
	private BigDecimal ecSdbiFixed;

	@Column(name = "EC_SIDBIREMARKS")
	private String ecSidbiRemarks;

	@Column(name = "EC_SIDBISTATUS")
	private String ecSidbiStatus;

	@Column(name = "EC_RMSEDATE")
	private Date ecRmseDate;

	@Column(name = "EC_RMSEMICROFY")
	private String ecRmsEmiCrofy;

	@Column(name = "EC_RMSEREMARKS")
	private String ecRmseRemarks;

	@Column(name = "EC_RMSESTATUS1")
	private String ecRmseStatus1;

	@Column(name = "EC_ICDDREMARKS")
	private String ecIcddRemarks;

	@Column(name = "EC_ICDDSTATUS")
	private String ecIcddStatus;

	@Column(name = "EC_FABIAREMARKS")
	private String ecFabiaRemarks;

	@Column(name = "EC_FABIASTATUS")
	private String ecFabiaStatus;

	@Column(name = "bank_parameter")
	private String bankParameter;

	@Column(name = "rmse1_data")
	private String rmse1Data;

	@Column(name = "rmse2_data")
	private String rmse2Data;

	@Column(name = "rmse3_data")
	private String rmse3Data;

	@Column(name = "rmse4_data")
	private String rmse4Data;

	@Column(name = "rmse5_data")
	private String rmse5Data;

	@Column(name = "rmse3_remarks")
	private String rmse3Remarks;

	@Column(name = "rmse4_remarks")
	private String rmse4Remarks;

	@Column(name = "rmse5_remarks")
	private String rmse5Remarks;

	@Column(name = "rmse3_status")
	private String rmse3Status;

	@Column(name = "rmse4_status")
	private String rmse4Status;

	@Column(name = "rmse5_status")
	private String rmse5Status;

}
