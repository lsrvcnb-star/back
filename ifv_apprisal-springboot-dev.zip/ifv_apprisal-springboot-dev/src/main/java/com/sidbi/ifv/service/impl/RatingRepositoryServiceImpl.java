package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.RatingRepositoryDTO;
import com.sidbi.ifv.entity.S2IFVRatingRepositoryEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.RatingRepository;
import com.sidbi.ifv.services.RatingRepositoryService;

@Service
public class RatingRepositoryServiceImpl implements RatingRepositoryService {

	private static final Logger logger = LoggerFactory.getLogger(RatingRepositoryServiceImpl.class);

	@Autowired
	private RatingRepository ratingRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<RatingRepositoryDTO> findAll() {
		logger.info("findAll() started in RatingRepositoryServiceImpl of S2IFVRatingRepositoryEntity");
		try {
			List<S2IFVRatingRepositoryEntity> list = ratingRepository.findAll();
			return !list.isEmpty() ? list.stream()
					.map(ratingRepositoryEntity -> modelMapper.map(ratingRepositoryEntity, RatingRepositoryDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVRatingRepositoryEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVRatingRepositoryEntities." + msg + " ", e);
		}
	}

	@Override
	public RatingRepositoryDTO findById(Long id) {
		logger.info("findById() started in RatingRepositoryServiceImpl for S2IFVRatingRepositoryEntity {} ", id);
		S2IFVRatingRepositoryEntity s2ifvRatingRepositoryEntity = ratingRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("S2IFVRatingRepositoryEntity", id));
		return modelMapper.map(s2ifvRatingRepositoryEntity, RatingRepositoryDTO.class);

	}

	@Override
	public RatingRepositoryDTO save(RatingRepositoryDTO ratingRepositoryDTO) {
		logger.info("save() started in RatingRepositoryServiceImpl for S2IFVRatingRepositoryEntity {} ",
				ratingRepositoryDTO);
		try {
			ratingRepositoryDTO.setDateOfAction(new Date());
			S2IFVRatingRepositoryEntity s2ifvRatingRepositoryEntity = modelMapper.map(ratingRepositoryDTO,
					S2IFVRatingRepositoryEntity.class);
			ratingRepository.save(s2ifvRatingRepositoryEntity);
			return modelMapper.map(s2ifvRatingRepositoryEntity, RatingRepositoryDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVRatingRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  S2IFVRatingRepositoryEntity." + msg + " ", e);
		}
	}

	@Override
	public RatingRepositoryDTO update(Long id, RatingRepositoryDTO ratingRepositoryDTO) {
		logger.info("update() started in RatingRepositoryServiceImpl for S2IFVRatingRepositoryEntity {} {} ", id,
				ratingRepositoryDTO);
		try {
			S2IFVRatingRepositoryEntity existingS2IFVRatingRepositoryEntity = ratingRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVMasterRepositoryEntity", id));
			BeanUtils.copyProperties(ratingRepositoryDTO, existingS2IFVRatingRepositoryEntity);
			ratingRepository.save(existingS2IFVRatingRepositoryEntity);
			return modelMapper.map(existingS2IFVRatingRepositoryEntity, RatingRepositoryDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVRatingRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVRatingRepositoryEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in RatingRepositoryServiceImpl for S2IFVRatingRepositoryEntity {} ", id);
		try {
			S2IFVRatingRepositoryEntity existingS2IFVRatingRepositoryEntity = ratingRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVMasterRepositoryEntity", id));
			ratingRepository.delete(existingS2IFVRatingRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVRatingRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVRatingRepositoryEntity of id ." + id + " " + msg, e);
		}

	}

	@Override
	public List<RatingRepositoryDTO> saveAll(List<RatingRepositoryDTO> ratingRepositoryDTOs) {
		logger.info("saveAll() started in RatingRepositoryServiceImpl for List of S2IFVRatingRepositoryEntity");
		try {
			Date currentDate = new Date();
			ratingRepositoryDTOs.forEach(ratingRepositoryDTO -> ratingRepositoryDTO.setDateOfAction(currentDate));
			List<S2IFVRatingRepositoryEntity> ratingRepositoryEntitiesToSave = ratingRepositoryDTOs.stream()
					.map(ratingRepositoryDTO -> modelMapper.map(ratingRepositoryDTO, S2IFVRatingRepositoryEntity.class))
					.collect(Collectors.toList());
			List<S2IFVRatingRepositoryEntity> savedRatingRepositoryEntities = ratingRepository
					.saveAll(ratingRepositoryEntitiesToSave);

			return savedRatingRepositoryEntities.stream()
					.map(ratingRepositoryEntity -> modelMapper.map(ratingRepositoryEntity, RatingRepositoryDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVRatingRepositoryEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVRatingRepositoryEntities." + msg + " ", e);
		}
	}

	@Override
	public List<RatingRepositoryDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in RatingRepositoryServiceImpl ");
		try {
			List<S2IFVRatingRepositoryEntity> listRatingRepositoryEntities = ratingRepository.findByIfvId(ifvId);
			return (listRatingRepositoryEntities != null && !listRatingRepositoryEntities.isEmpty())
					? listRatingRepositoryEntities.stream()
							.sorted(Comparator.comparing(S2IFVRatingRepositoryEntity::getRtCode))
							.map(ratingRepositoryEntity -> modelMapper.map(ratingRepositoryEntity,
									RatingRepositoryDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVRatingRepositoryEntities based on IfvId. {}",
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVRatingRepositoryEntities  based on IfvId." + ifvId + " "
							+ msg,
					e);

		}
	}
}