package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.PrincipalDTO;
import com.sidbi.ifv.entity.S2IFVPrincipalEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.PrincipalRepository;
import com.sidbi.ifv.services.PrincipalService;

@Service
public class PrincipalServiceImpl implements PrincipalService {
	
	private static final Logger logger = LoggerFactory.getLogger(PrincipalServiceImpl.class);

	@Autowired
	private PrincipalRepository  s2ifccPrincipalRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	String msg = "";

	@Override
	public List<PrincipalDTO> findAll() {
		logger.info("findAll() started in PrincipalServiceImpl for S2IFVPrincipalEntity");
		try {
			List<S2IFVPrincipalEntity> list = s2ifccPrincipalRepository.findAll();
			return list.stream().map(ifccsfbcommon -> modelMapper.map(ifccsfbcommon, PrincipalDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVPrincipalEntity entities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching all S2IFVPrincipalEntity entities."+msg+" ",
					e);
		}
	}

	@Override
	public PrincipalDTO findById(Long id) {
		logger.info("findById() started in PrincipalServiceImpl for S2IFVPrincipalEntity {} ",id);
		try {
			S2IFVPrincipalEntity s2ifccPrincipalEntity = s2ifccPrincipalRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVPrincipalEntity", id));
			return modelMapper.map(s2ifccPrincipalEntity, PrincipalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFVPrincipalEntity entity. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching  S2IFVPrincipalEntity entity."+msg+" ", e);
		}
	}

	@Override
	public PrincipalDTO save(PrincipalDTO s2ifccPrincipalDTO) {
		logger.info("save() started in PrincipalServiceImpl for S2IFVPrincipalEntity {} ",s2ifccPrincipalDTO);
		try {
			S2IFVPrincipalEntity s2ifccPrincipalEntity = modelMapper.map(s2ifccPrincipalDTO,
					S2IFVPrincipalEntity.class);
			s2ifccPrincipalRepository.save(s2ifccPrincipalEntity);
			return modelMapper.map(s2ifccPrincipalEntity, PrincipalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVPrincipalEntity entity. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVPrincipalEntity entity."+msg+" ", e);
		}
	}

	@Override
	public PrincipalDTO update(Long id, PrincipalDTO s2ifccPrincipalDTO) {
		logger.info("update() started in PrincipalServiceImpl for S2IFVPrincipalEntity {} {} ",id,s2ifccPrincipalDTO);
		try {
			S2IFVPrincipalEntity existings2ifccPrincipalEntity = s2ifccPrincipalRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVPrincipalEntity", id));
			BeanUtils.copyProperties(s2ifccPrincipalDTO, existings2ifccPrincipalEntity);
			s2ifccPrincipalRepository.save(existings2ifccPrincipalEntity);
			return modelMapper.map(existings2ifccPrincipalEntity, PrincipalDTO.class);

		} 
		catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVPrincipalEntity entity. {} ",msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVPrincipalEntity entity of id ." + id+" "+msg+" ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in PrincipalServiceImpl for S2IFVPrincipalEntity {} ",id);
		try {
			S2IFVPrincipalEntity existings2ifccPrincipalEntity = s2ifccPrincipalRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVPrincipalEntity", id));
			s2ifccPrincipalRepository.delete(existings2ifccPrincipalEntity);
		} 
		catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVPrincipalEntity entity. {} ",msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVPrincipalEntity entity of id ." +id+" "+msg+" ", e);
		}
		
	}

	@Override
	public List<PrincipalDTO> saveAll(List<PrincipalDTO> listPrincipalDTO) {
		logger.info("saveAll() started in PrincipalServiceImpl for List of S2IFVPrincipalEntity");
		try {
			List<S2IFVPrincipalEntity> principalEntitiesToSave = listPrincipalDTO.stream()
					.map(principalDTO -> modelMapper.map(principalDTO, S2IFVPrincipalEntity.class)).collect(Collectors.toList());
			List<S2IFVPrincipalEntity> savedPrincipalEntities = s2ifccPrincipalRepository.saveAll(principalEntitiesToSave);

			return savedPrincipalEntities.stream().map(principalEntitity -> modelMapper.map(principalEntitity, PrincipalDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVPrincipalEntities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while Saving all S2IFVPrincipalEntities."+msg+" ", e);
		}
	}

	@Override
	public List<PrincipalDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in PrincipalServiceImpl ");
		try {
			List<S2IFVPrincipalEntity> listPrincipalEntities = s2ifccPrincipalRepository.findByIfvId(ifvId);
			return listPrincipalEntities.stream().map(principalEntitity -> modelMapper.map(principalEntitity, PrincipalDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVPrincipalEntities based on IfvId. {}",msg);
			throw new DatabaseOperationException("Error Occurred while Finding all S2IFVPrincipalEntities  based on IfvId."+ifvId+" "+msg+" ", e);

		}
	}

}
