package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.DisclosureDivergenceDto;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.DisclosureDivergenceService;

@RestController
@CrossOrigin
@RequestMapping("/disclosure-divergence")
public class DisclosureDivergenceController extends CrudController<DisclosureDivergenceDto, Long> {

	private static final Logger logger = LoggerFactory.getLogger(DisclosureDivergenceController.class);

	@Autowired
	private DisclosureDivergenceService service;

	@Override
	public CrudService<DisclosureDivergenceDto, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<DisclosureDivergenceDto>> findByIfvId(@PathVariable Long ifvId) {
		logger.info("findByIfvId() started in DisclosureDivergenceController ");
		List<DisclosureDivergenceDto> dtos = service.findByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}
}