package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AssistanceAppliedForDto;
import com.sidbi.ifv.dto.IfvAggregateExposureDto;
import com.sidbi.ifv.dto.ProposedSchemaDTO;

public interface ProposedSchemaService extends CrudService<ProposedSchemaDTO, Long> {

	List<ProposedSchemaDTO> findAllByIfvId(Long ifvId);

	List<ProposedSchemaDTO> findAllByappId(String appId);

	List<AssistanceAppliedForDto> findAllAssistanceByIfvId(Long ifvId);

	AssistanceAppliedForDto findAssistanceById(Long id);

	void deleteAssistanceById(Long id);

	void deleteAggregateExposure(Long id);

	List<IfvAggregateExposureDto> findAggregateExposureByIfvId(Long id);

}
