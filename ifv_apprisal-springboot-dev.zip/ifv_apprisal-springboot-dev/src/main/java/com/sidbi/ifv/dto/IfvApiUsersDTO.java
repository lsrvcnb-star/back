package com.sidbi.ifv.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
public class IfvApiUsersDTO {

	private Integer ofrCode;

	private Integer ofrOrgCode;

	private Integer ofrBrnCode;

	private String ofrName;

	private Integer ofrDesgCode;

	private Integer ofrDeptCode;

	private String ofrType;

	private String ofrMiddleName;

	private String ofrLastName;

	private String ofrEmail;

	private String ofrEmpId;

	private String ofrUserId;

	private String ofrUserPassword;

	private String ofrCreateStatus;

	private String ofrUserActive;

	private Integer reportingOfficerCode;

	private Integer privCode;

	private Integer appModuleId;

	private String privRead;

	private String privWrite;

	private String privNew;

	private String privLock;

	private String privUnlock;

	private String privConfirm;

	private String privRecommend;

	private String privSendBackChecker;

	private String privClearCirculation;

	private String privForwordBranch;

	private String privApprove;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

	private String ipAddress;
	
	private String ofrShortName;

}