package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_ALCO_PROPOSAL")
public class S2IFVAlcoProposalEntity {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "al_code")
	private Long alCode;
	
	@Column(name = "al_type")
	private String alType;
	
	@Column(name = "al_background")
	private String alBackground;
	
	@Column(name = "al_presnt_proposal")
	private String alPresntProposal;
	
	@Column(name = "al_tenor")
	private String alTenor;
	
	@Column(name = "al_1yr")
	private BigDecimal al1yr;
	
	@Column(name = "al_3yr")
	private BigDecimal al3yr;
	
	@Column(name = "al_5yr")
	private BigDecimal al5yr;
	
	@Column(name = "al_recommendation")
	private String alRecommendation;
	
	@Column(name = "date_of_action")
	private Date dateOfAction;
	
	@Column(name = "al_app_number")
	private String alAppNumber;

}
