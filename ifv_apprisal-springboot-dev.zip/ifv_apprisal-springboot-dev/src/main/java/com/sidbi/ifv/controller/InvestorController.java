package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.InvestorDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.InvestorService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcinvestor")
public class InvestorController {

	private static final Logger logger = LoggerFactory.getLogger(InvestorController.class);

	@Autowired
	private InvestorService investorService;

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/getAll")
	public List<InvestorDTO> findAll() {
		logger.info("findAll() started InvestorController");
		return investorService.findAll();
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<InvestorDTO> findById(@PathVariable Long id) {
		logger.info("findById() started InvestorController {} ", id);
		InvestorDTO investorDTO = investorService.findById(id);
		return ResponseEntity.ok(investorDTO);
	}

	@PostMapping("/save")
	public ResponseEntity<InvestorDTO> save(@RequestBody InvestorDTO investorDTO) {
		logger.info("save() started InvestorController {} ", investorDTO);
		InvestorDTO createFinancialHighlightsDTO = investorService.save(investorDTO);
		return ResponseEntity.ok(createFinancialHighlightsDTO);

	}

	@PostMapping("/saveAll")
	public ResponseEntity<CommonDTO> saveAll(@RequestBody CommonDTO commonDTO) {
		logger.info("saveAll() started in InvestorController ");
		CommonDTO savedcommonDTO = investorService.saveCommonDTO(commonDTO);
		return ResponseEntity.ok(savedcommonDTO);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<InvestorDTO> update(@RequestBody InvestorDTO investorDTO, @PathVariable Long id) {
		logger.info("update() started InvestorController {} ", investorDTO);
		InvestorDTO updatedFinancialHighlightsDTO = investorService.update(id, investorDTO);
		return ResponseEntity.ok(updatedFinancialHighlightsDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> deleteAppraisal(@PathVariable Long id) {
		logger.info("delete() started InvestorController {} ", id);
		investorService.deleteAppraisal(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<CommonDTO> getAllInvestorEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllKycEntityOnIfvId() started in KycController ");
		CommonDTO commonDTO = investorService.findCommonDTOByIfvId(ifvId);

		if (CollectionUtils.isEmpty(commonDTO.getListInvestorDTO())) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				List<InvestorDTO> dtos = investorService.findAllByIfvId(applicationDTO.getIfvId());

				if (!CollectionUtils.isEmpty(dtos)) {
					dtos.forEach(e -> {
						e.setKiId(null);
						e.setIfvId(ifvId);
					});

					commonDTO.setListInvestorDTO(dtos);

				}

			}

		}

		return ResponseEntity.ok(commonDTO);

	}
}
