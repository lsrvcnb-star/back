package com.sidbi.ifv.services;

import java.util.List;
import com.sidbi.ifv.dto.BenchmarkRepositoryDTO;

public interface BenchmarkRepositoryService {
	
	List<BenchmarkRepositoryDTO> findAll();

	BenchmarkRepositoryDTO findById(Long id);

	BenchmarkRepositoryDTO save(BenchmarkRepositoryDTO benchmarkRepositoryDTO);

	BenchmarkRepositoryDTO update(Long id, BenchmarkRepositoryDTO benchmarkRepositoryDTO);
	
	void delete(Long id);

	List<BenchmarkRepositoryDTO> saveAll(List<BenchmarkRepositoryDTO> benchmarkRepositoryDTOs);

	List<BenchmarkRepositoryDTO> findAllByIfvId(Long ifvId);
	
	List<BenchmarkRepositoryDTO> findAllByBmBanktype(String bmBankType);

	List<BenchmarkRepositoryDTO> findAllByAlCodeAndBmBanktype(Long alCode,String bmBankType);

}