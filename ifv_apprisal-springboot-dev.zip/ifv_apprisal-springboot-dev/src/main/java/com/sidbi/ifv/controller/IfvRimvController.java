package com.sidbi.ifv.controller;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.dto.CommonRequestDto;
import com.sidbi.ifv.dto.IfvRimvAppDto;
import com.sidbi.ifv.dto.IfvRimvAppForwardDto;
import com.sidbi.ifv.dto.IfvRimvDocDto;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.FileStorageService;
import com.sidbi.ifv.services.IfvRimvService;
import com.sidbi.ifv.util.CommonRimvServiceSupport;
import com.sidbi.ifv.util.ProfileService;

@RestController
@CrossOrigin
@RequestMapping("/rimv")
public class IfvRimvController {

	private static final Logger logger = LoggerFactory.getLogger(IfvRimvController.class);

	@Autowired
	private IfvRimvService ifvRimvService;

	@Autowired
	private FileStorageService fileStorageService;

	@Autowired
	private CommonRimvServiceSupport commonRimvServiceSupport;

	@Autowired
	private EmailService emailService;

	@Autowired
	private ProfileService profileService;

	@GetMapping("/getCountOfRimvApps")
	public ResponseEntity<Map<String, Long>> getCountOfRimvApps() {

		Map<String, Long> result = ifvRimvService.getCountOfRimvApps();

		return ResponseEntity.ok(result);
	}

	@GetMapping("/fetchIfvRimvApps")
	public ResponseEntity<Page<IfvRimvAppDto>> fetchIfvRimvApps(@RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter) {

		Pageable pageable = PageRequest.of(start, size);
		Page<IfvRimvAppDto> result = ifvRimvService.fetchIfvRimvApps(pageable, filters, sorting, globalFilter);

		return ResponseEntity.ok(result);
	}

	@PostMapping("/saveIfvRimvApp")
	public ResponseEntity<Boolean> saveIfvRimvApp(@RequestBody IfvRimvAppDto request) {

		boolean success = ifvRimvService.saveIfvRimvApp(request);
		return ResponseEntity.ok(success);
	}

	@DeleteMapping("/deleteIfvRimvApp/{id}")
	public ResponseEntity<Boolean> deleteIfvRimvApp(@PathVariable Long id) {
		boolean success = ifvRimvService.deleteIfvRimvApp(id);
		return ResponseEntity.ok(success);
	}

	@GetMapping("/getAllDocsOnIfvRimvAppId/{ifvRimvAppId}")
	public ResponseEntity<List<IfvRimvDocDto>> getAllDocsOnIfvRimvAppId(@PathVariable Long ifvRimvAppId) {
		logger.info("getAllDocsOnIfvRimvAppId() started ApplicationController {} ", ifvRimvAppId);
		return ResponseEntity.ok(ifvRimvService.getAllDocsOnIfvRimvAppId(ifvRimvAppId));
	}

	@PostMapping(value = "/uploadRimvDocument", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<IfvRimvDocDto> saveOrUpdateDocument(@RequestPart("file") MultipartFile file,
			@RequestParam("ifvRimvAppId") Long ifvRimvAppId,
			@RequestParam(value = "remarks", required = false) String remarks) {
		return ResponseEntity.ok(ifvRimvService.uploadRimvDocument(file, ifvRimvAppId, remarks));
	}

	@GetMapping("/viewRimvDocument/{documentId}")
	public ResponseEntity<Resource> viewDocument(@PathVariable Long documentId) {
		try {
			IfvRimvDocDto doc = ifvRimvService.findById(documentId);

			Path filePath = Paths.get(doc.getFilePath());
			Resource resource = new FileSystemResource(filePath);

			if (resource.exists() && resource.isReadable()) {
				return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
						.header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + resource.getFilename() + "\"")
						.body(resource);
			} else {
				logger.error("File not found: {}", filePath);
				return ResponseEntity.notFound().build();
			}
		} catch (Exception e) {
			logger.error("Error viewing document {}: {}", documentId, e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@GetMapping("/downloadRimvDocument/{documentId}")
	public ResponseEntity<Resource> downloadDocument(@PathVariable Long documentId) {
		try {
			IfvRimvDocDto doc = ifvRimvService.findById(documentId);

			Path filePath = Paths.get(doc.getFilePath());

			Resource resource = new FileSystemResource(filePath);

			if (!resource.exists() || !resource.isReadable()) {
				logger.error("File not found or not readable: {}", filePath);
				return ResponseEntity.notFound().build();
			}

			return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
					.body(resource);

		} catch (Exception e) {
			logger.error("Error downloading document {}: {}", documentId, e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@DeleteMapping("/deleteRimvDocument/{documentId}")
	public ResponseEntity<String> deleteDocument(@PathVariable Long documentId) {
		try {
			ifvRimvService.deleteRimvDocument(documentId);
			return ResponseEntity.ok().body("Document deleted successfully");
		} catch (Exception e) {
			return ResponseEntity.internalServerError().body("Failed to delete document: " + e.getMessage());
		}
	}

	@PostMapping(value = "/forwardDocumentsToRimv")
	public ResponseEntity<Boolean> forwardDocumentsToRimv(@RequestBody IfvRimvAppForwardDto ifvRimvAppForwardDto) {
		boolean isSent = ifvRimvService.forwardDocumentsToRimv(ifvRimvAppForwardDto);
		if (isSent && !profileService.isProfileActive("local")) {
			emailService.sendFwdEmailToRimv(ifvRimvAppForwardDto);
		}
		return ResponseEntity.ok(isSent);
	}

	@PostMapping("/viewRimvDocByFilePath")
	public ResponseEntity<Resource> viewRimvDocByFilePath(@RequestBody CommonRequestDto dto) {
		return serveDocumentByPath(dto.getFilePath(), true);
	}

	@PostMapping("/downloadRimvDocByFilePath")
	public ResponseEntity<Resource> downloadRimvDocByFilePath(@RequestBody CommonRequestDto dto) {
		return serveDocumentByPath(dto.getFilePath(), false);
	}

	private ResponseEntity<Resource> serveDocumentByPath(String filePath, boolean inline) {
		try {
			if (filePath == null || filePath.trim().isEmpty()) {
				logger.warn("Empty file path provided");
				return ResponseEntity.badRequest().build();
			}

			Path requestedPath = Paths.get(filePath).normalize();

			if (!commonRimvServiceSupport.isPathAllowed(requestedPath)) {
				logger.error("Access denied to path: {}", requestedPath);
				return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
			}

			Resource resource = new FileSystemResource(requestedPath);

			if (!resource.exists()) {
				logger.warn("File not found: {}", requestedPath);
				return ResponseEntity.notFound().build();
			}

			if (!resource.isReadable()) {
				logger.error("File not readable: {}", requestedPath);
				return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
			}

			MediaType contentType = commonRimvServiceSupport.determineContentType(resource.getFilename());
			String disposition = inline ? "inline" : "attachment";

			return ResponseEntity.ok().contentType(contentType).header(HttpHeaders.CONTENT_DISPOSITION,
					disposition + "; filename=\"" + resource.getFilename() + "\"").body(resource);

		} catch (Exception e) {
			logger.error("Error serving document: {}", filePath, e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@PostMapping("/handleViewOrDownloadRimvUploads")
	public ResponseEntity<StreamingResponseBody> handleFile(@RequestBody CommonRequestDto requestDto) {
		return fileStorageService.handleFile(requestDto);
	}

}
