package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_APPRAISAL_MINUTES_DATA")
public class AppraisalMinutesDataEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "sanc_dtl_code")
	private Long sancDtlCode;

	@Column(name = "agenda_no")
	private Long agendaNo;

	@Column(name = "agenda_id")
	private String agendaId;

	@Column(name = "app_id")
	private String appId;

	@Column(name = "bank_name")
	private String bankName;

	@Column(name = "scheme_name")
	private String schemeName;

	@Column(name = "fund_name")
	private String fundName;

	@Column(name = "fund_code")
	private String fundCode;

	@Column(name = "loan_amount")
	private BigDecimal loanAmount;

	@Column(name = "interest_rate")
	private BigDecimal interestRate;

	@Column(name = "tenure")
	private Integer tenure;

	@Column(name = "principal_repayment")
	private String principalRepayment;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "status")
	private String status;

	@Column(name = "scheme_code")
	private String schemeCode;

	@Column(name = "pr_id")
	private Long prId;

	@Column(name = "interest_type")
	private String interestType;

	@Column(name = "bench_mark")
	private String benchMark;

	@Column(name = "spread")
	private String spread;

	@Column(name = "interest_reset")
	private String interestReset;

	@Column(name = "maturity_date")
	private Date maturityDate;

}
