package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.IfvApiUsersDTO;

public interface IfvApiUsersService extends CrudService<IfvApiUsersDTO, Integer> {

	List<IfvApiUsersDTO> findAllOnEmpIds(List<String> empIds);

	List<IfvApiUsersDTO> findAllByOfrType(String ofrType);

	List<IfvApiUsersDTO> getCheckerListForForwarding(Long ifvId, Long ofrCode);

	List<IfvApiUsersDTO> getCheckerListForSendBack(Long ifvId, Long ofrCode);

	List<IfvApiUsersDTO> findAllCheckers();

	List<IfvApiUsersDTO> findAllOnOfrCode(List<Integer> ofrCode);

}