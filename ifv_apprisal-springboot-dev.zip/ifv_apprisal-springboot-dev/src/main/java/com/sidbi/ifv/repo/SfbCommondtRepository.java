package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVSfbCommondtEntity;

public interface SfbCommondtRepository extends JpaRepository<S2IFVSfbCommondtEntity, Long>{

	List<S2IFVSfbCommondtEntity> findByIfvId(Long ifvId);
	
	S2IFVSfbCommondtEntity getByIfvId(Long ifvId);
}
