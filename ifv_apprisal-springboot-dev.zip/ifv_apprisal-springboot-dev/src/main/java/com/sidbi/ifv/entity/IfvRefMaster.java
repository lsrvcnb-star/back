package com.sidbi.ifv.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "IFV_REF_MASTERS")
@Data
public class IfvRefMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "CUST_CD")
	private String custCd;

	@Column(name = "REF_NO")
	private String refNo;

	@Column(name = "REF_DATE")
	private LocalDateTime refDate;
}
