package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IfvProposalDto {

	private BigDecimal refinanceAmount;

	private String rateType;

	private BigDecimal rateOfInterest;

	private String benchmark;

	private BigDecimal spread;

	private Integer tenureInMonths;

	private Integer tenureInDays;

	private String interestReset;

	private String principalRepayment;

	private Integer moratoriumMonths;

	private LocalDate maturityDate;
}