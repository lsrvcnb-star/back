package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "TBL_IFV_LOGIN")
@Data
public class IfvApiUsersEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "OFR_CODE")
	private Integer ofrCode;

	@Column(name = "OFR_ORG_CODE")
	private Integer ofrOrgCode;

	@Column(name = "OFR_BRN_CODE")
	private Integer ofrBrnCode;

	@Column(name = "OFR_NAME")
	private String ofrName;

	@Column(name = "OFR_DESG_CODE")
	private Integer ofrDesgCode;

	@Column(name = "OFR_DEPT_CODE")
	private Integer ofrDeptCode;

	@Column(name = "OFR_TYPE")
	private String ofrType;

	@Column(name = "OFR_MIDDLE_NAME")
	private String ofrMiddleName;

	@Column(name = "OFR_LAST_NAME")
	private String ofrLastName;

	@Column(name = "OFR_EMAIL")
	private String ofrEmail;

	@Column(name = "OFR_EMP_ID")
	private String ofrEmpId;

	@Column(name = "OFR_USER_ID")
	private String ofrUserId;

	@Column(name = "OFR_USER_PASSWORD")
	private String ofrUserPassword;

	@Column(name = "OFR_CREATE_STATUS")
	private String ofrCreateStatus;

	@Column(name = "OFR_USER_ACTIVE")
	private String ofrUserActive;

	@Column(name = "REPORTING_OFFICER_CODE")
	private Integer reportingOfficerCode;

	@Column(name = "PRIV_CODE")
	private Integer privCode;

	@Column(name = "APP_MODULE_ID")
	private Integer appModuleId;

	@Column(name = "PRIV_READ")
	private String privRead;

	@Column(name = "PRIV_WRITE")
	private String privWrite;

	@Column(name = "PRIV_NEW")
	private String privNew;

	@Column(name = "PRIV_LOCK")
	private String privLock;

	@Column(name = "PRIV_UNLOCK")
	private String privUnlock;

	@Column(name = "PRIV_CONFIRM")
	private String privConfirm;

	@Column(name = "PRIV_RECOMMEND")
	private String privRecommend;

	@Column(name = "PRIV_SEND_BACK_CHECKER")
	private String privSendBackChecker;

	@Column(name = "PRIV_CLEAR_CIRCULATION")
	private String privClearCirculation;

	@Column(name = "PRIV_FORWARD_BRANCH")
	private String privForwordBranch;

	@Column(name = "PRIV_APPROVE")
	private String privApprove;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "IP_ADDRESS")
	private String ipAddress;
	
	@Column(name = "OFR_SHORT_NAME")
	private String ofrShortName;

}
