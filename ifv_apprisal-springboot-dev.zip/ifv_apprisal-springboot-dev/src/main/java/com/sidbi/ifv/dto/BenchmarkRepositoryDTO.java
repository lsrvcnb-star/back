package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class BenchmarkRepositoryDTO {

	private Long bmCode;

	private Long ifvId;

	private String bmBanktype;

	private String bmBankmeetingdate;

	private String bmParticulars1;

	private String bmRemarks;

	private String bmOrder;

	private String bmFlg;

	private Date dateOfAction;
	
	private Long alCode;

}