package com.sidbi.ifv.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ifv_minutes_fwd_checker_details")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IFVMinutesCheckerDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "minute_id", nullable = false)
	private Long minuteId;

	@Column(name = "minute_file_id", nullable = false)
	private Long minuteFileId;

	@Column(name = "fwd_rej_status", nullable = false, length = 1)
	private Character status;

	@Column(name = "current_user_id")
	private Long currentUserId;

	@Column(name = "current_user_name", length = 150)
	private String currentUserName;

	@Column(name = "current_user_designation", length = 150)
	private String currentUserDesignation;

	@Column(name = "current_user_action", length = 20)
	private String currentUserAction;

	@Column(name = "date_time_of_receipt", nullable = false)
	private LocalDateTime dateTimeOfReceipt;

	@Column(name = "date_time_of_action", nullable = false)
	private LocalDateTime dateTimeOfAction;

	@Column(name = "current_user_fwd_rej_comment", length = 4000)
	private String currentUserComment;

	@Column(name = "fwd_rej_user_id")
	private Long forwardedUserId;

	@Column(name = "fwd_rej_user_name", length = 150)
	private String forwardedUserName;

	@Column(name = "fwd_rej_user_designation", length = 150)
	private String forwardedUserDesignation;

}
