package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BankPortalApiResponse<T> {

	private int statusCode;
	private String errorCode;
	private String statusMessage;
	private T data;
	private String path;
	private LocalDateTime timestamp;
	private boolean success;
}
