package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.sidbi.ifv.entity.S2IFVAreasGeographicalEntity;

public interface AreasGeographicalRepository extends JpaRepository<S2IFVAreasGeographicalEntity, Long> {

	List<S2IFVAreasGeographicalEntity> findByIfvId(Long ifvId);

	List<S2IFVAreasGeographicalEntity> findByIfvIdAndAgType(Long ifvId, String agType);

	@Modifying
	@Transactional
	@Query(value = "delete from s2_ifv_areasgeographical e where e.ifv_id = :ifvId and lower(e.rrb_state_name) = lower(:rrbStateName)", nativeQuery = true)
	void deleteAllByIfvIdAndRrbStateName(@Param(value = "ifvId") Long ifvId,
			@Param(value = "rrbStateName") String rrbStateName);

}
