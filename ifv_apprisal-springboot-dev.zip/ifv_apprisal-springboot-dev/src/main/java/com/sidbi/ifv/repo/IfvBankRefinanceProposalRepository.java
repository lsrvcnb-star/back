package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.IfvBankRefinanceProposal;

public interface IfvBankRefinanceProposalRepository extends JpaRepository<IfvBankRefinanceProposal, Long> {

	void deleteByApplicationId(Long id);

	List<IfvBankRefinanceProposal> findByApplicationIdIn(List<Long> applicationIds);

	List<IfvBankRefinanceProposal> findAllByApplicationId(Long id);

}
