package com.sidbi.ifv.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.IFVMinutesCheckerDetailDTO;
import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.dto.MinutesDocumentsDto;
import com.sidbi.ifv.dto.MinutesDocumentsRequest;
import com.sidbi.ifv.dto.MinutesForwardRequest;
import com.sidbi.ifv.dto.SanctionMinutesDTO;
import com.sidbi.ifv.dto.SanctionMinutesDtlDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.services.SanctionMinutesDtlService;
import com.sidbi.ifv.services.SanctionMinutesService;
import com.sidbi.ifv.util.ApiResponse;
import com.sidbi.ifv.util.ProfileService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/api/sanction-minutes")
public class SanctionMinutesController extends CrudController<SanctionMinutesDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(SanctionMinutesController.class);

	@Autowired
	private SanctionMinutesService service;

	@Autowired
	private SanctionMinutesDtlService dtlService;

	@Autowired
	private MasterDbService masterDbService;

	@Autowired
	private ProfileService profileService;

	@Override
	public CrudService<SanctionMinutesDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping(value = { "/getCount/{committeeCode}", "/getCount" })
	public ResponseEntity<Long> getCount(@PathVariable Optional<Integer> committeeCode) {
		logger.info("Started getCount() in SanctionMinutesController {} ", committeeCode);
		if (committeeCode.isPresent()) {
			return ResponseEntity.ok(service.getCount(committeeCode.get()));
		} else {
			return ResponseEntity.ok(service.getCount(null));
		}
	}

	@PostMapping("/saveSanctionMinutes")
	public ResponseEntity<Long> saveSanctionMinutes(@RequestBody CommonDTO commonDTO) {
		logger.info("Started saveSanctionMinutes() in SanctionMinutesController");
		return ResponseEntity.ok(service.saveSanctionMinutes(commonDTO));
	}

	@GetMapping("/getSanctionMinutesById/{id}")
	public ResponseEntity<CommonDTO> getSanctionMinutesById(@PathVariable Long id) {
		logger.info("Started getSanctionMinutesById() in SanctionMinutesController");
		CommonDTO commonDTO = new CommonDTO();
		SanctionMinutesDTO dto = service.findById(id);
		List<SanctionMinutesDtlDTO> dtlDTO = dtlService.findBySanctStatusCode(id, commonDTO);
		commonDTO.setSanctionMinutesDTO(dto);
		commonDTO.setSanctionMinutesDtlDTOs(dtlDTO);
		return ResponseEntity.ok(commonDTO);

	}

	@PostMapping("/circulateAllInOne/{sancMinId}")
	public ResponseEntity<Long> circulateAllInOne(@PathVariable Long sancMinId) {
		logger.info("Started circulateAllInOne() in SanctionMinutesController: {} ", sancMinId);
		return ResponseEntity.ok(service.circulateAllInOne(sancMinId));
	}

	@PostMapping("/approveSanction/{mtCode}/{userId}")
	public ResponseEntity<Boolean> approveSanction(@PathVariable Long mtCode, @PathVariable Integer userId) {
		logger.info("Started approveSanction() in SanctionMinutesController: {} {}", mtCode, userId);

		List<Long> minuteIds = service.approveSanctionMinutes(mtCode, userId);
		logger.info("minuteIds in Controller {}", minuteIds);
		boolean isSent = false;
		if (CollectionUtils.isEmpty(minuteIds)) {
			return ResponseEntity.ok(true);
		} else {
			isSent = masterDbService.sendDataToDFS(minuteIds);
			logger.info("Data sent to DFS {}", isSent);
			service.createCompliances(minuteIds);
		}

		if (isSent && !profileService.isProfileActive("local")) {
			// service.sendMail(mtCode)
		}

		return ResponseEntity.ok(isSent);
	}

	@GetMapping(value = { "/checkMeetingNoExistence/{meetingNo}/{committee}" })
	public ResponseEntity<Long> checkMeetingNoExistence(@PathVariable Integer meetingNo,
			@PathVariable Integer committee) {
		logger.info("Started checkMeetingNoExistence() in SanctionMinutesController {} ", meetingNo);
		return ResponseEntity.ok(service.checkMeetingNoExistence(meetingNo, committee));
	}

	@GetMapping("/getAllAppraisalMinutesDataBySancId/{sancId}")
	public ResponseEntity<List<AppraisalMinutesDataDTO>> getAllAppraisalMinutesDataBySancId(@PathVariable Long sancId) {
		logger.info("Started getAllAppraisalMinutesDataBySancId() in SanctionMinutesController");
		return ResponseEntity.ok(service.getAllAppraisalMinutesDataBySancId(sancId));
	}

	@GetMapping("/getAppraisalDateByAppId/{appNo}/{minuteId}")
	public ResponseEntity<String> getAppraisalDateByAppId(@PathVariable String appNo, @PathVariable Long minuteId) {
		logger.info("Started getAppraisalDateByAppId() in SanctionMinutesController");
		return ResponseEntity.ok(service.getAppraisalDateByAppId(appNo, minuteId));
	}

	@PostMapping("/forwardMinutes/{sancMinId}/{stage}/{empId}")
	public ResponseEntity<Long> forwardMinutes(@PathVariable Long sancMinId, @PathVariable int stage,
			@PathVariable String empId) {
		logger.info("Started forwardMinutes() in SanctionMinutesController: {} ", sancMinId);
		return ResponseEntity.ok(service.forwardMinutes(sancMinId, stage, empId));
	}

	@PostMapping("/rejectMinutes/{sancMinId}")
	public ResponseEntity<Long> rejectMinutes(@PathVariable Long sancMinId) {
		logger.info("Started rejectMinutes() in SanctionMinutesController: {} ", sancMinId);
		return ResponseEntity.ok(service.rejectMinutes(sancMinId));
	}

	@GetMapping("/getAllOnUserTypeOnPage/{userType}/{userCode}")
	public ResponseEntity<Page<SanctionMinutesDTO>> getAllOnUserTypeOnPage(@PathVariable String userType,
			@PathVariable String userCode, @RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter,
			@RequestParam(required = false) String status) {

		logger.info("getAllOnUserTypeOnPage() started SanctionMinutesController {} ", userType);

		int page = start / size;
		return ResponseEntity.ok(
				service.getAllOnUserTypeOnPage(userType, userCode, page, size, filters, sorting, globalFilter, status));
	}

	@GetMapping("/status-counts/{userType}/{userCode}")
	public ResponseEntity<Map<String, Long>> getStatusCounts(@PathVariable String userType,
			@PathVariable Long userCode) {
		logger.info("getStatusCounts() started SanctionMinutesController {} ", userCode);
		return ResponseEntity.ok(service.getStatusCounts(userType, userCode));
	}

	@PostMapping(value = "/saveOrUpdateDocument", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<ApiResponse<MinutesDocumentsDto>> saveOrUpdateDocument(
			@RequestPart("file") MultipartFile file, @RequestPart("document") @Valid MinutesDocumentsRequest request) {
		try {
			MinutesDocumentsDto dto = new MinutesDocumentsDto();
			dto.setModule(request.getModule());
			dto.setMinuteId(request.getMinuteId());
			dto.setCreatedBy(request.getCreatedBy());
			dto.setStatus(request.getStatus());
			dto.setUploadedUserId(request.getUploadedUserId());
			dto.setFile(file);
			MinutesDocumentsDto savedDto = service.saveOrUpdateDocument(dto);
			return ResponseEntity.ok(new ApiResponse<>(true, savedDto, null, null));
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(new ApiResponse<>(false, null, e.getMessage(), null));
		} catch (Exception e) {
			String errorMessage = "An error occurred while processing the document: " + e.getMessage();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse<>(false, null, errorMessage, null));
		}
	}

	@GetMapping("/getDocumentByMinuteId/{minuteId}")
	public ResponseEntity<MinutesDocumentsDto> getDocumentByMinuteId(@PathVariable Long minuteId) {
		MinutesDocumentsDto document = service.getDocumentByMinuteId(minuteId);
		return ResponseEntity.ok(document);
	}

	@GetMapping("/viewDocument/{id}")
	public ResponseEntity<byte[]> viewDocument(@PathVariable Long id) {
		try {
			MinutesDocumentsDto response = service.getDocumentById(id);
			return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
					.header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + response.getDocumentName() + "\"")
					.body(response.getDocumentContent());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@DeleteMapping("/deleteDocument/{id}")
	public ResponseEntity<Void> deleteDocument(@PathVariable Long id) {
		service.deleteDocument(id);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/getMinuteIdByLoiIdAndPrId/{loiId}/{prId}")
	public ResponseEntity<Map<Long, Long>> getMinuteIdByLoiIdAndPrId(@PathVariable Long loiId,
			@PathVariable Long prId) {
		Map<Long, Long> map = service.getMinuteIdByLoiIdAndPrId(loiId, prId);
		return ResponseEntity.ok(map);
	}

	@PostMapping("/fwdOrRejMinutes")
	public ResponseEntity<Boolean> fwdOrRejMinutes(@RequestBody MinutesForwardRequest forwardRequest) {
		logger.info("Started fwdOrRejMinutes() in SanctionMinutesController ");
		return ResponseEntity.ok(service.fwdOrRejMinutes(forwardRequest));
	}

	@GetMapping("/getMinutesFwdRejDetails/{minuteId}")
	public ResponseEntity<List<IFVMinutesCheckerDetailDTO>> getMinutesFwdRejDetails(@PathVariable Long minuteId) {
		logger.info("Started getMinutesFwdRejDetails() in SanctionMinutesController ");
		return ResponseEntity.ok(service.getMinutesFwdRejDetails(minuteId));
	}

	@GetMapping("/getUserListForRejectingMinutes/{minuteId}")
	public ResponseEntity<List<IfvApiUsersDTO>> getUserListForRejectingMinutes(@PathVariable Long minuteId) {
		logger.info("Started getUserListForRejectingMinutes() in SanctionMinutesController ");
		return ResponseEntity.ok(service.getUserListForRejectingMinutes(minuteId));
	}
}
