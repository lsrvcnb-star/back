package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.entity.CmtMemberMasterEntity;
import com.sidbi.ifv.enums.CommitteeEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.CmtMemberMasterRepository;
import com.sidbi.ifv.services.CmtMemberMasterService;
import com.sidbi.ifv.util.CommonUtil;

@Service
public class CmtMemberMasterServiceImpl implements CmtMemberMasterService {

	private static final Logger logger = LoggerFactory.getLogger(CmtMemberMasterServiceImpl.class);

	@Autowired
	private CmtMemberMasterRepository repository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CommonUtil commonUtil;

	String msg = "";

	@Override
	public List<CmtMemberMasterDTO> findAll() {
		logger.info("findAll() started in CmtMemberMasterServiceImpl of CmtMemberMasterEntity");
		try {
			List<CmtMemberMasterEntity> list = repository.findAll();
			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparingInt(entity -> entity.getCmtMemberCode().intValue()))
							.map(entity -> mapper.map(entity, CmtMemberMasterDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all CmtMemberMasterEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all CmtMemberMasterEntities ." + msg + " ", e);
		}
	}

	@Override
	public List<CmtMemberMasterDTO> findAllByCmtCode(Integer cmtCode) {
		logger.info("findAllByCmtCode() started in CmtMemberMasterServiceImpl of CmtMemberMasterEntity");
		try {
			List<CmtMemberMasterEntity> list = repository.findByCmtCode(cmtCode);
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, CmtMemberMasterDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all CmtMemberMasterEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all CmtMemberMasterEntities ." + msg + " ", e);
		}
	}

	@Override
	public CmtMemberMasterDTO findById(Long id) {
		logger.info("findById() started in CmtMemberMasterServiceImpl for CmtMemberMasterEntity {} ", id);
		CmtMemberMasterEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("CMTMemberMasterEntity", id));
		return mapper.map(entity, CmtMemberMasterDTO.class);
	}

	@Override
	public CmtMemberMasterDTO save(CmtMemberMasterDTO dto) {
		logger.info("save() started in CmtMemberMasterServiceImpl for CmtMemberMasterEntity {} ", dto);
		try {
			// Validation 1: Check if member with same name and committee code already
			// exists
			boolean memberExists = repository.existsByMemberNameAndCmtCodeAndEnableFlag(dto.getMemberName(),
					dto.getCmtCode(), 'Y');
			if (memberExists) {
				throw new DatabaseOperationException(
						"Member with name '" + dto.getMemberName() + "' already exists for the committee "
								+ CommitteeEnum.getCommitteeNameByCode(dto.getCmtCode().intValue()));
			}
			// Validation 2: Check for unique member types (CV, AC, CM) per committee
			if ("CV".equals(dto.getCmtType()) || "AC".equals(dto.getCmtType()) || "CM".equals(dto.getCmtType())) {
				boolean typeExists = repository.existsByCmtCodeAndCmtType(dto.getCmtCode(), dto.getCmtType());
				if (typeExists) {
					throw new DatabaseOperationException("Committee already has a member with type '" + dto.getCmtType()
							+ "'. Only one member of this type is allowed per committee.");
				}
			}
			dto.setCmtRemark("New");
			dto.setCreatedDate(new Date());
			dto.setEnableFlag('Y');
			CmtMemberMasterEntity entity = mapper.map(dto, CmtMemberMasterEntity.class);
			repository.save(entity);
			return mapper.map(entity, CmtMemberMasterDTO.class);
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating CmtMemberMasterEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating CmtMemberMasterEntity." + msg + " ", e);
		}
	}

	@Override
	public List<CmtMemberMasterDTO> saveAll(List<CmtMemberMasterDTO> dtos) {
		logger.info("saveAll() started in CmtMemberMasterServiceImpl for List of CmtMemberMasterEntity");
		try {
			List<CmtMemberMasterEntity> list = new ArrayList<>();

			Map<Integer, Map<String, Long>> mp = dtos.stream().filter(dtt -> !dtt.getCmtType().equalsIgnoreCase("MB"))
					.collect(Collectors.groupingBy(dt -> dt.getCmtCode().intValue(),
							Collectors.groupingBy(CmtMemberMasterDTO::getCmtType, Collectors.counting())));
			boolean exists = mp.values().stream().flatMap(fp -> fp.values().stream()).anyMatch(count -> count > 1);
			if (exists) {
				throw new DatabaseOperationException("Duplicate types for members");
			}

			dtos.stream().forEach(dto -> {
				boolean exist = dto.getCmtMemberCode() != null && dto.getCmtMemberCode() > 0;
				CmtMemberMasterEntity entity = new CmtMemberMasterEntity();
				if (exist) {
					entity = repository.findById(dto.getCmtMemberCode()).orElseThrow(
							() -> new EntityNotFoundException("CmtMemberMasterEntity", dto.getCmtMemberCode()));
					dto.setCmtRemark("Modify");
				} else {
					dto.setCmtRemark("New");
					dto.setCreatedDate(new Date());
					dto.setEnableFlag('Y');
				}
				BeanUtils.copyProperties(dto, entity, commonUtil.getNullPropertyNames(dto));
				list.add(repository.save(entity));
			});

			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, CmtMemberMasterDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all CmtMemberMasterEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all CmtMemberMasterEntities." + msg + " ",
					e);
		}
	}

	@Override
	public CmtMemberMasterDTO update(Long id, CmtMemberMasterDTO dto) {
		logger.info("update() started in CmtMemberMasterServiceImpl for CmtMemberMasterEntity {} {} ", id, dto);
		try {
			CmtMemberMasterEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("cmtMemberMasterEntity", id));
			BeanUtils.copyProperties(dto, existingEntity, commonUtil.getNullPropertyNames(dto));
			repository.save(existingEntity);
			return mapper.map(existingEntity, CmtMemberMasterDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating CmtMemberMasterEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating CmtMemberMasterEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in CmtMemberMasterServiceImpl for CmtMemberMasterEntity {} ", id);
		try {
			CmtMemberMasterEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("cmtMemberMasterEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting CmtMemberMasterEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting CmtMemberMasterEntity of id ." + msg + " " + id, e);
		}

	}

}