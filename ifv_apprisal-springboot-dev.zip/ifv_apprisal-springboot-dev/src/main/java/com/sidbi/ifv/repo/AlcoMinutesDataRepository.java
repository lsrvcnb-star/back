package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.AlcoMinutesDataEntity;

public interface AlcoMinutesDataRepository extends JpaRepository<AlcoMinutesDataEntity, Long> {

	List<AlcoMinutesDataEntity> findBySancDtlCode(Long sancDtlCode);

	List<AlcoMinutesDataEntity> findByAgendaIdAndAppId(String agendaId, String appId);

}