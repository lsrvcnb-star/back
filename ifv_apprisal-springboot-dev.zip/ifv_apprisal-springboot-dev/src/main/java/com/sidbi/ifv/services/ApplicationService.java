package com.sidbi.ifv.services;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.CreateProposalRequest;
import com.sidbi.ifv.dto.IFVProposalCheckerDetailDTO;
import com.sidbi.ifv.dto.IfvAppReportDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.model.ApplicationSummaryModel;

public interface ApplicationService {

	ApplicationDTO findById(Long id);

	ApplicationDTO save(ApplicationDTO ifccApplication);

	ApplicationDTO update(Long id, ApplicationDTO s2IfccApplicationDTO);

	void delete(Long id);

	List<ApplicationDTO> findAll();

	TblIfvModuleFwdDTO lockDocument(ApplicationDTO applicationDTO);

	boolean checkIfvIdExistsInChildTables(Long ifvId);

	List<ApplicationDTO> getAllOnUserType(String userType, Long userCode);

	TblIfvModuleFwdDTO confirmDocument(ApplicationDTO applicationDTO);

	TblIfvModuleFwdDTO unlockDocument(ApplicationDTO applicationDTO);

	TblIfvModuleFwdDTO approveDocument(ApplicationDTO applicationDTO);

	String createAppNo(int id);

	List<ApplicationDTO> findAllByIfvIdIn(List<Long> ifvIds);

	List<IfvAppReportDTO> getIfvAppsReportData();

	TblIfvModuleFwdDTO revertApprovedDocument(ApplicationDTO applicationDTO);

	Object findBankDetailsByAppNumber(String appNo);

	ApplicationDTO findByCifNumber(String cifNo);

	Page<ApplicationDTO> getApplicationOnPage(int page, int size, String globalFilter, String sorting);

	String getAddressByCifNumber(String appNo);

	Page<ApplicationSummaryModel> getAllOnUserTypeOnPage(String userType, Long ofrCode, int page, int size,
			String filters, String sorting, String globalFilter, String status);

	String getDetailsOfEmptyData(Long ifvNo);

	ApplicationDTO findSecondHighestByIfvId(Long ifvId);

	Map<String, Long> getStatusCounts(String userType, Long userCode);

	List<IFVProposalCheckerDetailDTO> findAllCheckerDetailsByIfvId(Long ifvId);

	void sendEmail(Long ifvId);

	ApplicationDTO findByIfvId(Long id);

	ApplicationDTO loadProposalData(CreateProposalRequest request);

}
