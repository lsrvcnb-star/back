package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IfvLoIDocumentUploadRequest {

	private Long loiDetailsId;

	private BigDecimal amount;

	private String scheme;

	private String uploadBy;

}
