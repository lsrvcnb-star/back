package com.sidbi.ifv.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class IfvSignedLoiRequestDTO {

	@Min(value = 0, message = "Page number must be 0 or greater")
	private int page = 0;

	@Min(value = 1, message = "Size must be at least 1")
	@Max(value = 100, message = "Size must not exceed 100")
	private int size = 10;

	private String ifvAppNo;

	private String bankRefNo;
	
	private String bankName;
	
	private String cifNumber;

	private String scheme;

	private String loiNo;

	private String fileName;

	private String status;

	private String uploadedBy;

	private LocalDate uploadedDateFrom;

	private LocalDate uploadedDateTo;

	private String sortField = "uploadedDate";

	private String sortDirection = "desc";
}