package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.IfvSanctionDetailsDTO;

public interface SanctionDtService extends CrudService<IfvSanctionDetailsDTO, Long> {

	List<IfvSanctionDetailsDTO> findAllByBnlSrNoIn(List<Long> minuteIds);

}
