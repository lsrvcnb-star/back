package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ucb_financial_performance")
public class UcbFinancialPerformanceEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "particulars")
	private String particulars;

	@Column(name = "amount1")
	private BigDecimal amount1;

	@Column(name = "amount2")
	private BigDecimal amount2;

	@Column(name = "date1")
	private Date date1;

	@Column(name = "date2")
	private Date date2;

	@Column(name = "note")
	private String note;

}
