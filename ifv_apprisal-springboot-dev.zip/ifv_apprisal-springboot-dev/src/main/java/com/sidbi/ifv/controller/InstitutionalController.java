package com.sidbi.ifv.controller;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.InstitutionalDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.InstitutionalService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/instit")
public class InstitutionalController {
	private static final Logger logger = LoggerFactory.getLogger(InstitutionalController.class);

	@Autowired
	private InstitutionalService institutionalService;

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/getAll")
	public List<InstitutionalDTO> findAll() {
		logger.info("findAll() started InstitutionalController");
		return institutionalService.findAll();
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<InstitutionalDTO> findById(@PathVariable Long id) {
		logger.info("findById() started InstitutionalController {} ", id);
		InstitutionalDTO institutionalDTO = institutionalService.findById(id);
		return ResponseEntity.ok(institutionalDTO);
	}

	@PostMapping("/save")
	public ResponseEntity<InstitutionalDTO> save(@RequestBody InstitutionalDTO institutionalDTO) {
		logger.info("save() started InstitutionalController {} ", institutionalDTO);
		InstitutionalDTO createInstitutionalDTO = institutionalService.save(institutionalDTO);
		return ResponseEntity.ok(createInstitutionalDTO);

	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<InstitutionalDTO>> saveAll(@RequestBody List<InstitutionalDTO> listInstitutionalDTO) {
		logger.info("saveAll() started in InstitutionalController ");
		List<InstitutionalDTO> savedInstitutionalDTOs = institutionalService.saveAll(listInstitutionalDTO);
		return ResponseEntity.ok(savedInstitutionalDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<InstitutionalDTO> update(@PathVariable Long id,
			@RequestBody InstitutionalDTO institutionalDTO) {
		logger.info("update() started InstitutionalController {} ", institutionalDTO);
		InstitutionalDTO updatedInstitutionalDTO = institutionalService.update(id, institutionalDTO);
		return ResponseEntity.ok(updatedInstitutionalDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> deleteAppraisal(@PathVariable Long id) {
		logger.info("delete() started InstitutionalController {} ", id);
		institutionalService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<InstitutionalDTO>> getAllS2IFVInstitutionalEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllS2IFVInstitutionalEntityOnIfvId() started in InstitutionalController ");
		List<InstitutionalDTO> institutionalDTOs = institutionalService.findAllByIfvId(ifvId);

		if (CollectionUtils.isEmpty(institutionalDTOs)) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				List<InstitutionalDTO> dtos2 = institutionalService.findAllByIfvId(applicationDTO.getIfvId());
				if (!CollectionUtils.isEmpty(dtos2)) {
					dtos2.sort(Comparator.comparing(InstitutionalDTO::getInId));
					dtos2.forEach(dto -> {
						dto.setIfvId(ifvId);
						dto.setInId(null);
					});
					return ResponseEntity.ok(dtos2);
				}
			}
			return ResponseEntity.ok(Collections.emptyList());
		} else {
			institutionalDTOs.sort(Comparator.comparing(InstitutionalDTO::getInId));
			return ResponseEntity.ok(institutionalDTOs);
		}

	}
}
