package com.sidbi.ifv.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.SanctionStatusEntity;

public interface SanctionStatusRepository extends JpaRepository<SanctionStatusEntity, Long> {

}