package com.sidbi.ifv.controller;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.ProfileBdDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.ProfileDbService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/bdprofile")
public class ProfileBdController {

	private static final Logger logger = LoggerFactory.getLogger(ProfileBdController.class);

	@Autowired
	private ProfileDbService profileDbService;

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/get/{id}")
	public ResponseEntity<ProfileBdDTO> findById(@PathVariable Long id) {
		logger.info("findById() started ProfileDbController {} ", id);
		ProfileBdDTO profileDbDTO = profileDbService.findById(id);
		return ResponseEntity.ok(profileDbDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<ProfileBdDTO>> findAll() {
		logger.info("findAll() started ProfileDbController ");
		List<ProfileBdDTO> list = profileDbService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<ProfileBdDTO> save(@RequestBody ProfileBdDTO profileDbDTO) {
		logger.info("save() started ProfileDbController {} ", profileDbDTO);
		ProfileBdDTO savedProfileDbDTO = profileDbService.save(profileDbDTO);
		return ResponseEntity.ok(savedProfileDbDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<ProfileBdDTO>> saveAll(@RequestBody List<ProfileBdDTO> listProfileDbDTO) {
		logger.info("saveAll() started in ProfileDbController ");
		List<ProfileBdDTO> savedProfileDbDTOs = profileDbService.saveAll(listProfileDbDTO);
		return ResponseEntity.ok(savedProfileDbDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<ProfileBdDTO> update(@PathVariable Long id, @RequestBody ProfileBdDTO profileDbDTO) {
		logger.info("update() started ProfileDbController {} ", profileDbDTO);
		ProfileBdDTO updatedProfileDbDTO = profileDbService.update(id, profileDbDTO);
		return ResponseEntity.ok(updatedProfileDbDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started ProfileDbController {} ", id);
		profileDbService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<ProfileBdDTO>> getAllS2IFVProfileDbEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllS2IFVProfileDbEntityOnIfvId() started in ProfileDbController ");
		List<ProfileBdDTO> profileDbDTOs = profileDbService.findAllByIfvId(ifvId);

		if (CollectionUtils.isEmpty(profileDbDTOs)) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				List<ProfileBdDTO> dtos2 = profileDbService.findAllByIfvId(applicationDTO.getIfvId());
				if (!CollectionUtils.isEmpty(dtos2)) {
					dtos2.forEach(dto -> {
						dto.setIfvId(ifvId);
						dto.setPrCode(null);
					});
					return ResponseEntity.ok(dtos2);
				}
			}
			return ResponseEntity.ok(Collections.emptyList());
		} else {
			return ResponseEntity.ok(profileDbDTOs);
		}

	}

}