package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MinutesInterestResetDTO {

	private Long id;
	private String bankName;
	private String cifNumber;
	private BigDecimal amount;
	private Integer periodInMonths;
	private LocalDate resetDate;
	private BigDecimal rateOfInterest;
	private BigDecimal costOfFunds;
	private LocalDate resetDueDate;
	private String remarks;
	private String sancStatus;
}