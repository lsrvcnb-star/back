package com.sidbi.ifv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.IfvSanctionDetailsDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.SanctionDtService;

@RestController
@CrossOrigin
@RequestMapping("/api/sanction-dt")
public class SanctionDtController extends CrudController<IfvSanctionDetailsDTO, Long> {

	@Autowired
	private SanctionDtService service;

	@Override
	public CrudService<IfvSanctionDetailsDTO, Long> getCrudService() {
		return service;
	}

}
