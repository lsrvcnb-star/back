package com.sidbi.ifv.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ifv_beneficiary_apps")
public class IfvBeneficiaryApp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "bn_ref_no")
	private String bnRefNo;

	@Column(name = "file_name", length = 150)
	private String fileName;

	@Column(name = "file_path", length = 500)
	private String filePath;

	@Column(name = "file_type", length = 50)
	private String fileType;

	@Column(name = "upload_date_time")
	private LocalDateTime uploadDateTime;

	@Column(name = "upload_by", length = 100)
	private String uploadBy;

	@Column(name = "remarks", length = 4000)
	private String remarks;

}
