package com.sidbi.ifv.specs;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.BankRefinanceAppRequest;
import com.sidbi.ifv.entity.IfvBankRefinanceApplication;

import jakarta.persistence.criteria.Predicate;

public final class IfvBankRefinanceApplicationSpecs {

	private IfvBankRefinanceApplicationSpecs() {
	}

	public static Specification<IfvBankRefinanceApplication> filter(BankRefinanceAppRequest request) {

		return (root, query, cb) -> {

			List<Predicate> predicates = new ArrayList<>();

			if (StringUtils.hasText(request.getAppRefId())) {
				predicates
						.add(cb.like(cb.lower(root.get("appRefId")), "%" + request.getAppRefId().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getCifNumber())) {
				predicates.add(
						cb.like(cb.lower(root.get("cifNumber")), "%" + request.getCifNumber().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getNameOfBank())) {
				predicates.add(
						cb.like(cb.lower(root.get("nameOfBank")), "%" + request.getNameOfBank().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getCustomSchemeName())) {
				predicates.add(cb.like(cb.lower(root.get("customSchemeName")),
						"%" + request.getCustomSchemeName().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getApplicationStatus())) {
				predicates.add(cb.equal(cb.lower(root.get("applicationStatus")),
						request.getApplicationStatus().toLowerCase()));
			}

			if (StringUtils.hasText(request.getSubmittedBy())) {
				predicates.add(
						cb.like(cb.lower(root.get("submittedBy")), "%" + request.getSubmittedBy().toLowerCase() + "%"));
			}

			if (request.getSubmittedFromDate() != null) {

				predicates.add(cb.greaterThanOrEqualTo(root.get("submittedDateTime"),
						request.getSubmittedFromDate().atStartOfDay()));
			}

			if (request.getSubmittedToDate() != null) {

				predicates.add(cb.lessThanOrEqualTo(root.get("submittedDateTime"),
						request.getSubmittedToDate().atTime(23, 59, 59)));
			}

			// Global Search
			if (StringUtils.hasText(request.getGlobalFilter())) {

				String value = "%" + request.getGlobalFilter().toLowerCase() + "%";

				predicates.add(cb.or(cb.like(cb.lower(root.get("appRefId")), value),
						cb.like(cb.lower(root.get("cifNumber")), value),
						cb.like(cb.lower(root.get("nameOfBank")), value),
						cb.like(cb.lower(root.get("schemeCode")), value),
						cb.like(cb.lower(root.get("customSchemeName")), value),
						cb.like(cb.lower(root.get("applicationStatus")), value),
						cb.like(cb.lower(root.get("submittedBy")), value)));
			}

			// MRT Column Filters
			Map<String, String> filters = request.getFilters();

			if (filters != null) {

				filters.forEach((key, value) -> {

					if (!StringUtils.hasText(value)) {
						return;
					}

					switch (key) {

					case "appRefId":
						predicates.add(cb.like(cb.lower(root.get("appRefId")), "%" + value.toLowerCase() + "%"));
						break;

					case "cifNumber":
						predicates.add(cb.like(cb.lower(root.get("cifNumber")), "%" + value.toLowerCase() + "%"));
						break;

					case "nameOfBank":
						predicates.add(cb.like(cb.lower(root.get("nameOfBank")), "%" + value.toLowerCase() + "%"));
						break;

					case "schemeCode":
						predicates.add(cb.like(cb.lower(root.get("schemeCode")), "%" + value.toLowerCase() + "%"));
						break;

					case "applicationStatus":
						predicates.add(cb.equal(cb.lower(root.get("applicationStatus")), value.toLowerCase()));
						break;

					default:
						break;
					}
				});
			}

			return cb.and(predicates.toArray(new Predicate[0]));
		};
	}
}