package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class UcbBorrowersDetailDto {

	private Long id;

	private Long ifvId;

	private Integer totBorrowers;

	private Integer totMsmeCustomers;

	private Integer totCorpBorrowers;

	private String remarks;
}
