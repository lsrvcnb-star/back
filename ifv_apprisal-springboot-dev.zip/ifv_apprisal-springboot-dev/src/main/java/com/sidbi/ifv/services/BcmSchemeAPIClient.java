package com.sidbi.ifv.services;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(url = "${masterdbms.url}" , value = "IFVSchemeService")
public interface BcmSchemeAPIClient {
	
	@GetMapping("/api/get/allSchems")
	List<Object> findAllSchemes();
	
	@GetMapping("/api/get/schemesOnFundCd/{fundCd}")
	List<Object> findSchemesOnFundCd(@PathVariable String fundCd);

}