package com.sidbi.ifv.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.SanctionTermsConditionsDTO;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.entity.SanctionTermsConditionsEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.repo.SanctionTermsConditionsRepository;
import com.sidbi.ifv.services.AppraisalMinutesDataService;
import com.sidbi.ifv.services.LoIDetailService;
import com.sidbi.ifv.services.SanctionTermsConditionsService;
import com.sidbi.ifv.util.CommonUtil;

@Service
public class SanctionTermsConditionsServiceImpl implements SanctionTermsConditionsService {

	private static final Logger logger = LoggerFactory.getLogger(SanctionTermsConditionsServiceImpl.class);

	@Autowired
	private SanctionTermsConditionsRepository repository;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private ApplicationRepository ifccApplicationRepo;

	@Autowired
	private LoIDetailService loIDetailService;

	@Autowired
	private AppraisalMinutesDataService appraisalMinutesDataService;

	String msg = "";

	@Override
	public SanctionTermsConditionsDTO findById(Long id) {
		logger.info("findById() started in SanctionTermsConditionsServiceImpl for SanctionTermsConditionsEntity {} ",
				id);
		SanctionTermsConditionsEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("SanctionTermsConditionsEntity", id));
		return mapper.map(entity, SanctionTermsConditionsDTO.class);
	}

	@Override
	public List<SanctionTermsConditionsDTO> findAll() {
		logger.info("findAll() started in SanctionTermsConditionsServiceImpl of SanctionTermsConditionsEntity");
		try {
			List<SanctionTermsConditionsEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, SanctionTermsConditionsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all SanctionTermsConditionsEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all SanctionTermsConditionsEntities ." + msg + " ", e);
		}
	}

	@Override
	public SanctionTermsConditionsDTO save(SanctionTermsConditionsDTO dto) {
		logger.info("save() started in SanctionTermsConditionsServiceImpl for SanctionTermsConditionsEntity {} ", dto);
		try {
			SanctionTermsConditionsEntity entity = mapper.map(dto, SanctionTermsConditionsEntity.class);
			S2IFVProposedSchemaEntity entity2 = proposedSchemaRepository.findByPrId(entity.getPrId());
			entity.setFundCode(entity2.getPrFundcode());
			entity.setSchemeCode(entity2.getPrSchemecode());
			repository.save(entity);
			return mapper.map(entity, SanctionTermsConditionsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating SanctionTermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  SanctionTermsConditionsEntity." + msg + " ", e);
		}
	}

	@Override
	public List<SanctionTermsConditionsDTO> saveAll(List<SanctionTermsConditionsDTO> dtos) {
		logger.info(
				"saveAll() started in SanctionTermsConditionsServiceImpl for List of SanctionTermsConditionsEntity");
		try {

			List<SanctionTermsConditionsEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, SanctionTermsConditionsEntity.class)).collect(Collectors.toList());
			List<SanctionTermsConditionsEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, SanctionTermsConditionsDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all SanctionTermsConditionsEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all SanctionTermsConditionsEntities." + msg + " ", e);
		}
	}

	@Override
	public SanctionTermsConditionsDTO update(Long id, SanctionTermsConditionsDTO dto) {
		logger.info("update() started in SanctionTermsConditionsServiceImpl for SanctionTermsConditionsEntity {} {} ",
				id, dto);
		try {
			SanctionTermsConditionsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("sanctionTermsConditionsEntity", id));
			BeanUtils.copyProperties(dto, existingEntity, commonUtil.getNullPropertyNames(dto));
			repository.save(existingEntity);
			return mapper.map(existingEntity, SanctionTermsConditionsDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating SanctionTermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating SanctionTermsConditionsEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in SanctionTermsConditionsServiceImpl for SanctionTermsConditionsEntity {} ", id);
		try {
			SanctionTermsConditionsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("sanctionTermsConditionsEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting SanctionTermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting SanctionTermsConditionsEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<SanctionTermsConditionsDTO> findAllByIfvId(Long ifvId) {
		logger.info(
				"findAllByIfvId() started in SanctionTermsConditionsServiceImpl for SanctionTermsConditionsEntity {} ",
				ifvId);
		try {

			List<SanctionTermsConditionsEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty()) ? list.stream().map(
					restructuredAssetsEntity -> mapper.map(restructuredAssetsEntity, SanctionTermsConditionsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId SanctionTermsConditionsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId SanctionTermsConditionsEntity of id ." + msg + " " + ifvId, e);
		}
	}

	@Override
	public List<SanctionTermsConditionsDTO> findAllByIfvIdAndPrId(Long ifvId, Long prId) {
		logger.info(
				"findAllByIfvIdAndPrId() started in SanctionTermsConditionsServiceImpl for SanctionTermsConditionsEntity {} ",
				ifvId);
		try {

			List<SanctionTermsConditionsEntity> list = repository.findAllByIfvIdAndPrId(ifvId, prId);
			return (list != null && !list.isEmpty()) ? list.stream().map(
					restructuredAssetsEntity -> mapper.map(restructuredAssetsEntity, SanctionTermsConditionsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while findAllByIfvIdAndPrId SanctionTermsConditionsEntity of ifvId and prId . {} {} {} ",
					msg, ifvId, prId);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvIdAndPrId SanctionTermsConditionsEntity of ifvId and prId ." + msg
							+ " " + ifvId + " " + prId + " ",
					e);
		}
	}

	@Override
	public SanctionTermsConditionsDTO findByIfvIdAndPrId(Long ifvId, Long prId) {
		logger.info(
				"findAllByIfvIdAndPrId() started in SanctionTermsConditionsServiceImpl for SanctionTermsConditionsEntity {} ",
				ifvId);
		try {

			SanctionTermsConditionsEntity entity = repository.findByIfvIdAndPrId(ifvId, prId);
			if (entity == null)
				entity = new SanctionTermsConditionsEntity();
			return mapper.map(entity, SanctionTermsConditionsDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while findByIfvIdAndPrId SanctionTermsConditionsEntity of ifvId and prId . {} {} {} ",
					msg, ifvId, prId);
			throw new DatabaseOperationException(
					"Error Occurred while findByIfvIdAndPrId SanctionTermsConditionsEntity of ifvId and prId ." + msg
							+ " " + ifvId + " " + prId + " ",
					e);
		}
	}

	@Override
	public List<SanctionTermsConditionsDTO> findByAppNumberAndPrId(String appNo, Long prId, Long loiId) {
		logger.info("Finding sanction terms for application: {}, prId: {}", appNo, prId);
		try {
			var ifccApplication = ifccApplicationRepo.findByAppNumber(appNo).stream().findFirst()
					.orElseThrow(() -> new EntityNotFoundException("EntityNotFoundException", appNo));
			var allProposedSchemas = proposedSchemaRepository.findByIfvId(ifccApplication.getIfvId());
			var targetSchema = allProposedSchemas.stream().filter(e -> e.getPrId().equals(prId)).findFirst()
					.orElseThrow(() -> new EntityNotFoundException("S2IFVProposedSchemaEntity", prId));
			var filteredSchemas = allProposedSchemas.stream()
					.filter(e -> e.getPrSchemeName().equals(targetSchema.getPrSchemeName()))
					.filter(e -> !targetSchema.getPrSchemeName().toUpperCase().contains("RMSE")
							|| e.getPrFundname().equals(targetSchema.getPrFundname()))
					.collect(Collectors.toList());
			var loiDetail = loIDetailService.findById(loiId);
			return filteredSchemas.stream().map(schema -> {
				var appraisalData = appraisalMinutesDataService.findBySancDtlCodeAppIdPrId(loiDetail.getSancDetailId(),
						appNo, schema.getPrId());
				var sanctionTerms = repository.findByIfvIdAndPrId(ifccApplication.getIfvId(), schema.getPrId());
				if (sanctionTerms == null) {
					sanctionTerms = new SanctionTermsConditionsEntity();
				}
				sanctionTerms.setAmount(appraisalData.getLoanAmount());
				sanctionTerms.setTsRAteInterest(appraisalData.getInterestRate());
				sanctionTerms.setTsTenurePeriod(BigDecimal.valueOf(appraisalData.getTenure()));
				sanctionTerms.setBenchMark(appraisalData.getBenchMark());
				sanctionTerms.setSpread(appraisalData.getSpread());
				sanctionTerms.setInterestReset(appraisalData.getInterestReset());
				sanctionTerms.setInterestType(appraisalData.getInterestType());
				return sanctionTerms;
			}).map(entity -> mapper.map(entity, SanctionTermsConditionsDTO.class)).collect(Collectors.toList());
		} catch (EntityNotFoundException e) {
			throw e;
		} catch (Exception e) {
			throw new DatabaseOperationException(
					String.format("Failed to process sanction terms for application: %s, prId: %s", appNo, prId), e);
		}
	}

}
