package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "ifv_aggregate_exposure")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IfvAggregateExposure {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "ifv_id", nullable = false)
	private Long ifvId;

	@Column(name = "capital_funds")
	private BigDecimal capitalFunds;

	@Column(name = "sl_no")
	private Integer slNo;

	@Column(name = "particulars")
	private String particulars;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "group_name")
	private String groupName;

	@Column(name = "created_at", updatable = false)
	private LocalDateTime createdAt;

	@Column(name = "updated_at")
	private LocalDateTime updatedAt;

	@PrePersist
	protected void onCreate() {
		this.createdAt = LocalDateTime.now();
		this.updatedAt = LocalDateTime.now();
	}

	@PreUpdate
	protected void onUpdate() {
		this.updatedAt = LocalDateTime.now();
	}
}
