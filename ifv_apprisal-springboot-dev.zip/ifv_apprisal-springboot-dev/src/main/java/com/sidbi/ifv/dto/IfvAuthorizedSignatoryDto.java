package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IfvAuthorizedSignatoryDto {

	private String nameOfAuthSignatory;

	private String designation;

	private String email;

	private Long mobileNumber;

}
