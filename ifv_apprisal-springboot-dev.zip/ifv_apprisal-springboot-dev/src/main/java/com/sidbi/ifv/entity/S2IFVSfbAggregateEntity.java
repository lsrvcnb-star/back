package com.sidbi.ifv.entity;
 
import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
 
@Data
@Entity
@Table(name = "S2_IFV_SFB_AGGREGATE")
public class S2IFVSfbAggregateEntity {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "AGG_ID")
	private Long aggId;
 
	@Column(name = "IFV_ID")
	private Long ifvId;
 
	@Column(name = "AGG_STANDALONEAMONT")
	private BigDecimal aggStandaloneAmount;
 
	@Column(name = "AGG_MAXIMUMCAP1")
	private BigDecimal aggMaximumCap1;
 
	@Column(name = "AGG_EXPOSUREDATE")
	private Date aggExposureDate;
 
	@Column(name = "AGG_BO")
	private BigDecimal aggBo;
 
	@Column(name = "AGG_STOTAL")
	private BigDecimal aggStotal;
 
	@Column(name = "AGG_CONSOLIDATEDAMOUNT")
	private BigDecimal aggConsolidatedAmount;
 
	@Column(name = "AGG_MAXIMUMCAP2")
	private BigDecimal aggMaximumCap2;
 
	@Column(name = "AGG_MUDRA")
	private BigDecimal aggMudra;
 
	@Column(name = "AGG_SVCL")
	private BigDecimal aggSvcl;
 
	@Column(name = "AGG_CTOTAL")
	private BigDecimal aggCtotal;
 
	@Column(name = "AGG_PROPOSEDAMOUNT")
	private BigDecimal aggProposedAmount;
 
}
