package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.IFVDocumnetHistoryDTO;

public interface IFVDocumnetHistoryService {
	
	List<IFVDocumnetHistoryDTO> findAll();
	IFVDocumnetHistoryDTO save(IFVDocumnetHistoryDTO iFVDocumnetHistoryDTO);
	IFVDocumnetHistoryDTO update(Long id, IFVDocumnetHistoryDTO iFVDocumnetHistoryDTO);
	void delete(Long id);
	IFVDocumnetHistoryDTO findById(Long id);

}
