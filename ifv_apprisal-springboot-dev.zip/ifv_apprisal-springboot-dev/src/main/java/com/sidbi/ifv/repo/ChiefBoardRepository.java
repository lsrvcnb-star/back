package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVChiefBoardEntity;

public interface ChiefBoardRepository extends JpaRepository<S2IFVChiefBoardEntity, Long> {
	
	List<S2IFVChiefBoardEntity> findByIfvId(Long ifvId);

}
