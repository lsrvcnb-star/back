package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVBenchmarkRepositoryEntity;

public interface BenchmarkRepository extends JpaRepository<S2IFVBenchmarkRepositoryEntity, Long> {

	List<S2IFVBenchmarkRepositoryEntity> findByIfvId(Long ifvId);
	
	List<S2IFVBenchmarkRepositoryEntity> findByBmBanktype(String bankType);
	
	List<S2IFVBenchmarkRepositoryEntity> findByAlCodeAndBmBanktype(Long alCode, String bankType);

}