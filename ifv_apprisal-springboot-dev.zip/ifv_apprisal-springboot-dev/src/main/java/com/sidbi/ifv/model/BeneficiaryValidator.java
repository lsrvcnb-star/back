package com.sidbi.ifv.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.sidbi.ifv.dto.BeneficiaryDetailsDTO;

@Component
public class BeneficiaryValidator {

	public List<String> validate(BeneficiaryDetailsDTO dto, int rowNum) {

		List<String> errors = new ArrayList<>();

		if (isBlank(dto.getBbdUserId())) {
			errors.add("Row " + rowNum + ": User ID is required");
		}

		if (isBlank(dto.getBbdPanOfUnit()) || !dto.getBbdPanOfUnit().matches("[A-Z]{5}[0-9]{4}[A-Z]")) {
			errors.add("Row " + rowNum + ": Invalid PAN number");
		}

		if (dto.getMobileNoLinkedUrc() == null || String.valueOf(dto.getMobileNoLinkedUrc()).length() != 10) {
			errors.add("Row " + rowNum + ": Invalid mobile number");
		}

		if (isBlank(dto.getAcctNo())) {
			errors.add("Row " + rowNum + ": Account number is mandatory");
		}

		return errors;
	}

	private boolean isBlank(String val) {
		return val == null || val.trim().isEmpty();
	}
}
