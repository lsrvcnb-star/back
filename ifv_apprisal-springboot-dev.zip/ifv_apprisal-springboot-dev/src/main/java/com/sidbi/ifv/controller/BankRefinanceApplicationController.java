package com.sidbi.ifv.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.dto.AcceptReturnComplianceRequestDto;
import com.sidbi.ifv.dto.BankRefinanceAppRequest;
import com.sidbi.ifv.dto.BankRefinanceAppResponse;
import com.sidbi.ifv.dto.CommonRequestDto;
import com.sidbi.ifv.dto.ComplianceStatusSummaryRequest;
import com.sidbi.ifv.dto.ComplianceStatusSummaryResponse;
import com.sidbi.ifv.dto.IfvRefinanceApplicationRequest;
import com.sidbi.ifv.dto.ReturnBankForwardedDocumentRequest;
import com.sidbi.ifv.services.BankRefinanceApplicationService;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.FileStorageService;
import com.sidbi.ifv.util.ApiResponse;
import com.sidbi.ifv.util.ProfileService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/bank/refinance")
@RequiredArgsConstructor
public class BankRefinanceApplicationController {

	private final BankRefinanceApplicationService bankRefinanceApplicationService;
	private final FileStorageService fileStorageService;
	private final ProfileService profileService;
	private final EmailService emailService;

	@PostMapping("/forward-application")
	public ResponseEntity<ApiResponse<String>> receiveForwardedApplication(
			@RequestBody IfvRefinanceApplicationRequest request) {

		return ResponseEntity.ok(bankRefinanceApplicationService.receiveForwardedApplication(request));
	}

	@PostMapping("/fetchBankApplications")
	public ResponseEntity<Page<BankRefinanceAppResponse>> fetchBankApplications(
			@Valid @RequestBody BankRefinanceAppRequest request) {
		return ResponseEntity.ok(bankRefinanceApplicationService.fetchBankApplications(request));
	}

	@GetMapping("/fetchBankApplicationByAppRefId")
	public ResponseEntity<IfvRefinanceApplicationRequest> getApplicationDetails(@RequestParam String appRefId) {

		return ResponseEntity.ok(bankRefinanceApplicationService.fetchBankApplicationByAppRefId(appRefId));
	}

	@PostMapping("/downloadFileByPath")
	public ResponseEntity<StreamingResponseBody> downloadFileByPath(@RequestBody CommonRequestDto requestDto) {
		log.info("Called download...");
		return fileStorageService.handleFile(requestDto);
	}

	@PostMapping("/returnBankApplication")
	public ResponseEntity<ApiResponse<String>> returnForwardedApplication(
			@RequestBody ReturnBankForwardedDocumentRequest request) {

		try {

			BankRefinanceAppResponse dto = bankRefinanceApplicationService.returnBankApplication(request);

			ApiResponse<String> response = ApiResponse.<String>builder().success(true).data("SUCCESS")
					.message("Application returned successfully").errors(Collections.emptyList()).build();
			if (!profileService.isProfileActive("local")) {
				emailService.sendBankAppReturnEmail(dto);
			}
			return ResponseEntity.ok(response);

		} catch (Exception e) {

			ApiResponse<String> response = ApiResponse.<String>builder().success(false).data(null)
					.message("Failed to return application").errors(List.of(e.getMessage())).build();

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	@PostMapping("/validateBankApplication")
	public ResponseEntity<ApiResponse<String>> validateBankApplication(
			@RequestBody ReturnBankForwardedDocumentRequest request) {

		bankRefinanceApplicationService.validateBankApplication(request.getBenRefNo());
		ApiResponse<String> response = ApiResponse.<String>builder().success(true).data("SUCCESS")
				.message("Application verified successfully").errors(Collections.emptyList()).build();
		return ResponseEntity.ok(response);
	}

	@PostMapping("/fetchActiveProposalBankApps")
	public ResponseEntity<Page<BankRefinanceAppResponse>> fetchActiveProposalBankApps(
			@Valid @RequestBody BankRefinanceAppRequest request) {
		return ResponseEntity.ok(bankRefinanceApplicationService.fetchActiveProposalBankApps(request));
	}

	@PostMapping("/fetchComplianceSummaryForAllBanks")
	public ResponseEntity<Page<ComplianceStatusSummaryResponse>> fetchComplianceSummaryForAllBanks(
			@Valid @RequestBody ComplianceStatusSummaryRequest request) {
		return ResponseEntity.ok(bankRefinanceApplicationService.fetchComplianceSummaryForAllBanks(request));
	}

	@PostMapping("/acceptOrReturnCompliance")
	public ResponseEntity<ApiResponse<String>> acceptOrReturnCompliance(
			@RequestBody AcceptReturnComplianceRequestDto request) {

		log.info("Accept/Return compliance request received. appRefNo={}, complianceType={}, action={}",
				request.getAppRefNo(), request.getComplianceType(), request.getStatus());

		try {

			bankRefinanceApplicationService.acceptOrReturnCompliance(request);

			log.info("Compliance action completed successfully. appRefNo={}, complianceType={}, action={}",
					request.getAppRefNo(), request.getComplianceType(), request.getStatus());

			String message = "COMPLETED".equalsIgnoreCase(request.getStatus()) ? "Compliance accepted successfully"
					: "Compliance returned successfully";

			ApiResponse<String> response = ApiResponse.<String>builder().success(true).data("SUCCESS").message(message)
					.errors(Collections.emptyList()).build();

			return ResponseEntity.ok(response);

		} catch (Exception e) {

			log.error("Failed to process compliance action. appRefNo={}, complianceType={}, action={}",
					request.getAppRefNo(), request.getComplianceType(), request.getStatus(), e);

			ApiResponse<String> response = ApiResponse.<String>builder().success(false).data(null)
					.message("Failed to process compliance").errors(List.of(e.getMessage())).build();

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

}
