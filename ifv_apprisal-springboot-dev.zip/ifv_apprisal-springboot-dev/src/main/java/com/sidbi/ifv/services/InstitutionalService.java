package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.InstitutionalDTO;

public interface InstitutionalService {

	List<InstitutionalDTO> findAll();

	InstitutionalDTO findById(Long id);

	InstitutionalDTO save(InstitutionalDTO institutionalDTO);

	InstitutionalDTO update(Long id, InstitutionalDTO institutionalDTO);

	void delete(Long id);

	List<InstitutionalDTO> saveAll(List<InstitutionalDTO> listInstitutionalDTO);

	List<InstitutionalDTO> findAllByIfvId(Long ifvId);
}
