package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVTermsSectionEntity;

public interface TermsSectionRepository extends JpaRepository<S2IFVTermsSectionEntity, Long> {
	
	public List<S2IFVTermsSectionEntity> findByIfvId(Long ifvId);

}
