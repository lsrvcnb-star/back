package com.sidbi.ifv.enums;

public enum FileSubModuleEnum {

	PROPOSAL("PROPOSAL"), RIMV_DOCS("RIMV_DOCS"), SIGNED_LOI("SIGNED_LOI"), COUNTER_SIGNED_LOI("COUNTER_SIGNED_LOI");

	private final String folderName;

	FileSubModuleEnum(String folderName) {
		this.folderName = folderName;
	}

	public String getFolderName() {
		return folderName;
	}

}
