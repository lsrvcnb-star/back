package com.sidbi.ifv.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MinutesDocumentsRequest {
	@NotNull
	private String module;
	@NotNull
	private Long minuteId;
	@NotBlank
	private String createdBy;
	@NotBlank
	private String status;
	@NotNull
	private Long uploadedUserId;
}
