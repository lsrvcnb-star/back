package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.ChiefBoardDTO;

public interface ChiefBoardService {
	
	List<ChiefBoardDTO> findAll();

	ChiefBoardDTO findById(Long id);

	ChiefBoardDTO save(ChiefBoardDTO s2ifccChiefBoardDTO);

	ChiefBoardDTO update(Long id, ChiefBoardDTO s2ifccChiefBoardDTO);
	
	void delete(Long id);
	
	List<ChiefBoardDTO> saveAll(List<ChiefBoardDTO> listChiefBoardDTO);

	List<ChiefBoardDTO> findAllByIfvId(Long ifvId);


}
