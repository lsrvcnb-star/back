package com.sidbi.ifv.exception;

import org.springframework.security.core.AuthenticationException;

public class InvalidUsernameException extends AuthenticationException {
	private static final long serialVersionUID = 1L;

	public InvalidUsernameException(String msg) {
		super(msg);
	}

	public InvalidUsernameException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
