package com.sidbi.ifv.service.impl;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.config.JwtTokenUtil;
import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.dto.IfvLoginRequest;
import com.sidbi.ifv.model.JwtResponse;
import com.sidbi.ifv.services.JwtUserDetailsServiceForIfv;
import com.sidbi.ifv.util.ActiveDirectoryAuthenticationUtil;
import com.sidbi.ifv.util.CryptoUtil;
import com.sidbi.ifv.util.ProfileService;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@RequiredArgsConstructor
@Log4j2
public class IfvAuthenticationService {

	private final CryptoUtil cryptoUtil;
	private final JwtTokenUtil jwtTokenUtil;
	private final JwtUserDetailsServiceForIfv userService;
	private final ProfileService profileService;

	public Map<String, String> generateCaptcha() {
		String captchaText = generateCaptchaText();
		String encryptedCaptcha = cryptoUtil.encrypt(captchaText);

		return Map.of("captcha", captchaText, "encryptedCaptcha", encryptedCaptcha);
	}

	public JwtResponse login(IfvLoginRequest request) {

		String decryptedCaptcha = cryptoUtil.decrypt(request.getEncryptedCaptcha());

		if (!request.getCaptcha().trim().equalsIgnoreCase(decryptedCaptcha.trim())) {
			throw new IllegalArgumentException("Invalid captcha");
		}

		String username = cryptoUtil.decrypt(request.getUsername());
		String password = cryptoUtil.decrypt(request.getPassword());

		if (!profileService.isProfileActive("local")) {
			if (!authenticateWithLdap(username, password)) {
				throw new BadCredentialsException("Authentication failed");
			}
		}

		IfvApiUsersDTO userDTO = userService.loadUserByUsername(username);

		String token = jwtTokenUtil
				.generateToken(new User(userDTO.getOfrUserId(), userDTO.getOfrUserPassword(), new ArrayList<>()));

		JwtResponse response = new JwtResponse(token);
		response.setData(userDTO);

		return response;
	}

	public JwtResponse ssoLogin(String encUsername) {
		String username = cryptoUtil.decrypt(encUsername);
		IfvApiUsersDTO userDTO = userService.loadUserByUsername(username);

		String token = jwtTokenUtil
				.generateToken(new User(userDTO.getOfrUserId(), userDTO.getOfrUserPassword(), new ArrayList<>()));

		JwtResponse response = new JwtResponse(token);
		response.setData(userDTO);

		return response;
	}

	private boolean authenticateWithLdap(String username, String password) {
		try {
			ActiveDirectoryAuthenticationUtil auth = new ActiveDirectoryAuthenticationUtil("SIDBIFARM.COM");

			return auth.authenticate(username, password);

		} catch (Exception e) {
			log.error("LDAP authentication error", e);
			throw new AuthenticationServiceException("LDAP authentication failed", e);
		}
	}

	private String generateCaptchaText() {
		final String CHARACTERS = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz123456789";
		final int CAPTCHA_LENGTH = 4;
		SecureRandom random = new SecureRandom();

		return random.ints(CAPTCHA_LENGTH, 0, CHARACTERS.length()).mapToObj(CHARACTERS::charAt)
				.collect(StringBuilder::new, StringBuilder::append, StringBuilder::append).toString();
	}
}
