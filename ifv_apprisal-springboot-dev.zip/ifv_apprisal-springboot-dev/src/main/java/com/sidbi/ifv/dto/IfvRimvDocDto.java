package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IfvRimvDocDto {

	private Long id;
	private Long ifvRimvAppId;
	private String fileModule;
	private String fileSubModule;
	private String fileName;
	private String fileType;
	private String filePath;
	private LocalDateTime uploadedDateTime;
	private String remarks;
}
