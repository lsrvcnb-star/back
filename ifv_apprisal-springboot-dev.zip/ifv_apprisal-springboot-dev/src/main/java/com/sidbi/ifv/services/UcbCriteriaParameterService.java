package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.UcbCriteriaParameterDTO;

public interface UcbCriteriaParameterService extends CrudService<UcbCriteriaParameterDTO, Long> {

	List<UcbCriteriaParameterDTO> findAllByIfvId(Long ifvId);

}
