package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVAssRepaymentsEntity;

public interface AssRepaymentsRepository extends JpaRepository<S2IFVAssRepaymentsEntity, Long> {

	List<S2IFVAssRepaymentsEntity> findByIfvId(Long ifvId);

	void deleteByIfvId(Long ifvId);

}
