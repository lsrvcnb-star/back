package com.sidbi.ifv.controller;

import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.dto.CVRequest;
import com.sidbi.ifv.dto.CommonRequestDto;
import com.sidbi.ifv.dto.IfvLoIDocumentUploadRequest;
import com.sidbi.ifv.dto.IfvSignedLoiRequestDTO;
import com.sidbi.ifv.dto.IfvSignedLoiResponseDTO;
import com.sidbi.ifv.dto.LoIDetailDTO;
import com.sidbi.ifv.dto.LoiEmailNotificationDTO;
import com.sidbi.ifv.dto.LoiStatusCountResponse;
import com.sidbi.ifv.entity.IfvLoiDocuments;
import com.sidbi.ifv.model.CVWebLoginRequest;
import com.sidbi.ifv.model.CVWebResponse;
import com.sidbi.ifv.service.impl.CVWebService;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.FileStorageService;
import com.sidbi.ifv.services.LoIDetailService;
import com.sidbi.ifv.util.ApiResponse;
import com.sidbi.ifv.util.ProfileService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin
@RequestMapping("/loi-details")
public class LoIDetailController extends CrudController<LoIDetailDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(LoIDetailController.class);

	@Autowired
	private LoIDetailService service;

	@Override
	public CrudService<LoIDetailDTO, Long> getCrudService() {
		return service;
	}

	@Autowired
	private CVWebService cvWebService;

	@Autowired
	private FileStorageService fileStorageService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private ProfileService profileService;

	@GetMapping("/findBySancId/{sancId}")
	public ResponseEntity<LoIDetailDTO> findBySancId(@PathVariable Long sancId) {
		logger.info("findBySancId() started in LoIDetailController ");
		LoIDetailDTO dto = service.findBySancId(sancId);
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/findLoIBySancIdAndSancDetailCode/{sancId}/{sancDetailId}/{minuteId}")
	public ResponseEntity<LoIDetailDTO> findLoIBySancIdAndSancDetailCode(@PathVariable Long sancId,
			@PathVariable Long sancDetailId, @PathVariable Long minuteId) {
		logger.info("findLoIBySancIdAndSancDetailCode() started in LoIDetailController ");
		LoIDetailDTO dto = service.findLoIBySancIdAndSancDetailCode(sancId, sancDetailId, minuteId);
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/getAllOnUserTypeOnPage")
	public ResponseEntity<Page<LoIDetailDTO>> getAllOnUserTypeOnPage(@RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter) {

		logger.info("getAllOnUserTypeOnPage() started LoIDetailController");

		int page = start / size;
		return ResponseEntity.ok(service.getAllOnUserTypeOnPage(page, size, filters, sorting, globalFilter));
	}

	@PostMapping("/dmsLogin")
	public ResponseEntity<CVWebResponse> dmsLogin(@RequestParam("username") String username,
			@RequestParam("password") String password,
			@RequestParam(value = "localAddress", required = false) String localAddress) {
		logger.info("dmsLogin() started with params: username={}, localAddress={}", username, localAddress);
		CVWebLoginRequest cvWebLoginRequest = new CVWebLoginRequest();
		cvWebLoginRequest.setUsername(username);
		cvWebLoginRequest.setPassword(password);
		cvWebLoginRequest.setLocalAddress(localAddress);
		CVWebResponse response = cvWebService.login(cvWebLoginRequest);
		String sessionId = null;
		if (response.isSuccess()) {
			sessionId = response.getSessionId().split("~")[0];
			response.setSessionId(sessionId);
		}
		return ResponseEntity.ok(response);
	}

	@PostMapping("/getLoINoFromDMS")
	public ResponseEntity<CVWebResponse> getLoINoFromDMS(@RequestBody CVRequest request) {
		logger.info(
				"getLoINoFromDMS() started with params: username={}, folderId={}, documentName={}, region={}, language={}",
				request.getUsername(), request.getFolderId(), request.getDocumentName(), request.getRegion(),
				request.getLanguage());
		CVWebResponse response = cvWebService.cvappCreateNewDocumentWS(request);
		return ResponseEntity.ok(response);
	}

	@PostMapping(value = "/submitSignedLoI", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<ApiResponse<String>> submitSignedLoI(@RequestPart("file") MultipartFile file,
			@RequestPart("request") IfvLoIDocumentUploadRequest request, HttpServletRequest httpRequest) {

		logger.info("Submit signed LoI request received. loiDetailsId={}", request.getLoiDetailsId());

		LoiEmailNotificationDTO emailResponse = service.submitSignedLoI(file, request);

		if (!profileService.isProfileActive("local")) {
			emailService.signedLoiSubmissionNotification(emailResponse);
		}

		ApiResponse<String> response = ApiResponse.<String>builder().success(true).data("SUCCESS")
				.message("Signed LoI uploaded successfully").errors(Collections.emptyList()).build();

		return ResponseEntity.ok(response);
	}

	@GetMapping("/signed-loi/{loiDetailsId}")
	public ResponseEntity<ApiResponse<IfvLoiDocuments>> getSignedLoIDocument(@PathVariable Long loiDetailsId) {

		IfvLoiDocuments document = service.getSignedLoIDocument(loiDetailsId);

		ApiResponse<IfvLoiDocuments> response = ApiResponse.<IfvLoiDocuments>builder().success(true).data(document)
				.message("Signed LoI details fetched successfully").errors(Collections.emptyList()).build();

		return ResponseEntity.ok(response);
	}

	@PostMapping("/downloadSignedLoI")
	public ResponseEntity<StreamingResponseBody> handleFile(@RequestBody CommonRequestDto requestDto) {
		return fileStorageService.handleFile(requestDto);
	}

	@PostMapping("/signed-loi-summary")
	public ResponseEntity<Page<IfvSignedLoiResponseDTO>> fetchSignedLoiSummary(
			@RequestBody IfvSignedLoiRequestDTO request) {

		return ResponseEntity.ok(service.fetchSignedLoiSummary(request));
	}

	@PostMapping(value = "/submitCounterSignedLoI", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<String> submitCounterSignedLoI(@RequestPart("file") MultipartFile file,
			@RequestParam("loiDetailsId") Long loiDetailsId, HttpServletRequest httpRequest) {

		logger.info("Submit Counter Signed LoI request received. loiDetailsId={}", loiDetailsId);

		LoiEmailNotificationDTO emailResponse = service.submitCounterSignedLoI(file, loiDetailsId);

		if (!profileService.isProfileActive("local")) {
			emailService.counterSignedLoiSubmissionNotification(emailResponse);
		}

		return ResponseEntity.ok("Counter signed LoI submitted successfully");
	}

	@Operation(summary = "Fetch LOI Status Counts")
	@PostMapping("/fetchLoiStatusCounts")
	public ResponseEntity<LoiStatusCountResponse> fetchLoiStatusCounts(@RequestParam String cifNumber,
			HttpServletRequest httpRequest) {

		logger.info("Fetch LOI Status Counts API called");

		return service.fetchLoiStatusCounts(cifNumber);

	}
}