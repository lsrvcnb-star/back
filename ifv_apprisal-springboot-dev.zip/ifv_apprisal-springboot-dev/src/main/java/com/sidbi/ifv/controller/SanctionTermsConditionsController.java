package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.SanctionTermsConditionsDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.SanctionTermsConditionsService;

@RestController
@CrossOrigin
@RequestMapping("/api/sanctiontermconditions")
public class SanctionTermsConditionsController extends CrudController<SanctionTermsConditionsDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(SanctionTermsConditionsController.class);

	@Autowired
	private SanctionTermsConditionsService service;

	@Override
	public CrudService<SanctionTermsConditionsDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<SanctionTermsConditionsDTO>> getSanctionTermsConditionsDTOOnIfvId(
			@PathVariable Long ifvId) {
		logger.info("getSanctionTermsConditionsDTOOnIfvId() started in SanctionTermsConditionsController ");
		List<SanctionTermsConditionsDTO> dtos = service.findAllByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}

	@GetMapping("/getAllOnIfvIdAndPrId/{ifvId}/{prId}")
	public ResponseEntity<SanctionTermsConditionsDTO> getSanctionTermsConditionsDTOOnIfvIdAndPrId(
			@PathVariable Long ifvId, @PathVariable Long prId) {
		logger.info("getSanctionTermsConditionsDTOOnIfvIdAndPrId() started in SanctionTermsConditionsController ");
		return ResponseEntity.ok(service.findByIfvIdAndPrId(ifvId, prId));
	}

	@GetMapping("/findByAppNumberAndPrId/{appNo}/{prId}/{loiId}")
	public ResponseEntity<List<SanctionTermsConditionsDTO>> findByAppNumberAndPrId(@PathVariable String appNo,
			@PathVariable Long prId, @PathVariable Long loiId) {
		logger.info("findByAppNumberAndPrId() started in SanctionTermsConditionsController ");
		return ResponseEntity.ok(service.findByAppNumberAndPrId(appNo, prId, loiId));
	}

}
