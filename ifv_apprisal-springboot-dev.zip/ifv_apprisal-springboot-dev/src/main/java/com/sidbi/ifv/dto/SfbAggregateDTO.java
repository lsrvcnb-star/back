package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class SfbAggregateDTO {

	private Long aggId;
 
	private Long ifvId;
 
	private BigDecimal aggStandaloneAmount;
 
	private BigDecimal aggMaximumCap1;
 
	private Date aggExposureDate;
 
	private BigDecimal aggBo;
 
	private BigDecimal aggStotal;
 
	private BigDecimal aggConsolidatedAmount;
 
	private BigDecimal aggMaximumCap2;
 
	private BigDecimal aggMudra;
 
	private BigDecimal aggSvcl;
 
	private BigDecimal aggCtotal;
 
	private BigDecimal aggProposedAmount;
 
	
 


}
