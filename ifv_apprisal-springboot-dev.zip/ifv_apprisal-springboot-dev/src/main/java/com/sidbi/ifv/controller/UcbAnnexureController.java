package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.UcbAnnexureDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.UcbAnnexureService;

@RestController
@CrossOrigin
@RequestMapping("/ucb-annexure")
public class UcbAnnexureController extends CrudController<UcbAnnexureDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(UcbAnnexureController.class);

	@Autowired
	private UcbAnnexureService service;

	@Override
	public CrudService<UcbAnnexureDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvIdAndAnnexureNo/{ifvId}/{annexureNo}")
	public ResponseEntity<List<UcbAnnexureDTO>> getUcbCriteriaIfvId(@PathVariable Long ifvId,
			@PathVariable Integer annexureNo) {
		logger.info("getUcbFincOnIfvId() started in UcbAnnexureController ");
		List<UcbAnnexureDTO> dtos = service.findAllByIfvIdAndAnnexureNo(ifvId, annexureNo);
		return ResponseEntity.ok(dtos);
	}
}
