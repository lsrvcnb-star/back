package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sidbi.ifv.entity.IfvRimvDoc;

public interface IfvRimvDocRepo extends JpaRepository<IfvRimvDoc, Long>, JpaSpecificationExecutor<IfvRimvDoc> {

	List<IfvRimvDoc> findAllByIfvRimvAppId(Long ifvRimvAppId);

	void deleteAllByIfvRimvAppId(Long id);

}
