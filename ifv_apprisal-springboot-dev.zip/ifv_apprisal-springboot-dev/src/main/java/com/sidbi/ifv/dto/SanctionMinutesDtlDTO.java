package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class SanctionMinutesDtlDTO {

	private Long sancDtlCode;

	private Long sanctStatusCode;

	private Integer agendaNo;
	
	private String agendaId;

	private String appid;

	private String sanctPurposeStatus;

	private String sanctDscnStatus;

	private String minSumryCreated;

	private String branchName;

	private Date applicationDt;

	private String unitName;

	private BigDecimal loanAmount;

	private String schemeName;

	private String schemeCd;

	private BigDecimal interestRate;

	private BigDecimal tenor;

	private String principalRepayment;

	private String remarks;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;
	
	private String sancStatus;
	
	private BigDecimal costOfFunds;
	
	private BigDecimal spreadMargin;
}
