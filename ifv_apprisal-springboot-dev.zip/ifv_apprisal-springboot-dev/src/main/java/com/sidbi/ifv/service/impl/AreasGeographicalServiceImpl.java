package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AreasGeographicalDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.SfbCommondtDTO;
import com.sidbi.ifv.entity.S2IFVAreasGeographicalEntity;
import com.sidbi.ifv.entity.S2IFVSfbCommondtEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AreasGeographicalRepository;
import com.sidbi.ifv.repo.SfbCommondtRepository;
import com.sidbi.ifv.services.AreasGeographicalService;

@Service
public class AreasGeographicalServiceImpl implements AreasGeographicalService {

	private static final Logger logger = LoggerFactory.getLogger(AreasGeographicalServiceImpl.class);

	@Autowired
	private AreasGeographicalRepository areaOfGeographicalRepo;

	@Autowired
	private SfbCommondtRepository sfbCommondtRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<AreasGeographicalDTO> findAll() {
		logger.info("findAll() started in AreasGeographicalServiceImpl for S2IFVAreasGeographicalEntity");
		try {
			List<S2IFVAreasGeographicalEntity> list = areaOfGeographicalRepo.findAll();
			return list.stream().map(m -> modelMapper.map(m, AreasGeographicalDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAreasGeographicalEntities. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAreasGeographicalEntities." + msg + " ", e);
		}
	}

	@Override
	public AreasGeographicalDTO findById(Long id) {
		logger.info("findById() started in AreasGeographicalServiceImpl for S2IFVAreasGeographicalEntity {} ", id);
		try {
			Optional<S2IFVAreasGeographicalEntity> ifccApplication = areaOfGeographicalRepo.findById(id);
			if (ifccApplication.isPresent()) {
				return modelMapper.map(ifccApplication.get(), AreasGeographicalDTO.class);
			} else {
				logger.error("Error Occurred while fetching  S2IFVAreasGeographicalEntity.");
				throw new EntityNotFoundException("s2IFVAreasGeographicalEntity", id);
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAreasGeographicalEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching S2IFVAreasGeographicalEntity." + msg + " ", e);
		}

	}

	@Override
	public AreasGeographicalDTO save(AreasGeographicalDTO s2ifccAreaOfGeographicalDTO) {

		logger.info("save() started in AreasGeographicalServiceImpl for S2IFVAreasGeographicalEntity {}",
				s2ifccAreaOfGeographicalDTO);
		try {
			S2IFVAreasGeographicalEntity s2ifccApplicationEntity = modelMapper.map(s2ifccAreaOfGeographicalDTO,
					S2IFVAreasGeographicalEntity.class);
			areaOfGeographicalRepo.save(s2ifccApplicationEntity);
			return modelMapper.map(s2ifccApplicationEntity, AreasGeographicalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVAreasGeographicalEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  S2IFVAreasGeographicalEntity." + msg + " ", e);
		}
	}

	@Override
	public AreasGeographicalDTO update(Long id, AreasGeographicalDTO s2ifccAreaOfGeographicalDTO) {
		logger.info("update() started in AreasGeographicalServiceImpl for S2IFVAreasGeographicalEntity {} {}", id,
				s2ifccAreaOfGeographicalDTO);
		try {
			S2IFVAreasGeographicalEntity applicationEntity = areaOfGeographicalRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("IFVAreasGeographicalEntity", id));
			BeanUtils.copyProperties(s2ifccAreaOfGeographicalDTO, applicationEntity);
			areaOfGeographicalRepo.save(applicationEntity);
			return modelMapper.map(applicationEntity, AreasGeographicalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVAreasGeographicalEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVAreasGeographicalEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in AreasGeographicalServiceImpl for IfccApplicationDTO {}", id);
		try {
			S2IFVAreasGeographicalEntity applicationEntity = areaOfGeographicalRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAreasGeographicalEntity", id));
			areaOfGeographicalRepo.delete(applicationEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVAreasGeographicalEntity entity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVAreasGeographicalEntity entity of id ." + id + " " + msg + " ",
					e);
		}

	}

	@Override
	public List<AreasGeographicalDTO> saveAll(List<AreasGeographicalDTO> listAreasGeographicalDTO) {
		logger.info("saveAll() started in AreasGeographicalServiceImpl for List of S2IFVAreasGeographicalEntity");
		try {
			List<S2IFVAreasGeographicalEntity> areasGeographicalEntitiesToSave = listAreasGeographicalDTO.stream().map(
					areasGeographicalDTO -> modelMapper.map(areasGeographicalDTO, S2IFVAreasGeographicalEntity.class))
					.collect(Collectors.toList());
			List<S2IFVAreasGeographicalEntity> savedAreasGeographicalEntities = areaOfGeographicalRepo
					.saveAll(areasGeographicalEntitiesToSave);

			return savedAreasGeographicalEntities.stream().map(
					areasGeographicalEntity -> modelMapper.map(areasGeographicalEntity, AreasGeographicalDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVAreasGeographicalEntities. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVAreasGeographicalEntities ." + msg + " ", e);

		}
	}

	@Override
	public List<AreasGeographicalDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in AreasGeographicalServiceImpl ");
		try {
			List<S2IFVAreasGeographicalEntity> listAreasGeographicalEntities = areaOfGeographicalRepo
					.findByIfvId(ifvId);
			return listAreasGeographicalEntities.stream().map(
					areasGeographicalEntity -> modelMapper.map(areasGeographicalEntity, AreasGeographicalDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAreasGeographicalEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAreasGeographicalEntities   based on IfvId." + ifvId + " "
							+ msg + " ",
					e);

		}
	}

	@Override
	public CommonDTO saveCommonDTO(CommonDTO commonDTO) {
		logger.info("Started saveCommonDTO() in AreasGeographicalServiceImpl ");
		SfbCommondtDTO sfbCommondtDTO = commonDTO.getSfbCommondtDTO();
		logger.info("sfbCommondtDTO {} ", sfbCommondtDTO);
		List<AreasGeographicalDTO> listAreasGeographicalDTOs = commonDTO.getListAreasGeographicalDTO();
		logger.info("listAreasGeographicalDTOs {} ", listAreasGeographicalDTOs);

		try {
			List<S2IFVSfbCommondtEntity> s2ifvSfbCommondtEntities = sfbCommondtRepository
					.findByIfvId(sfbCommondtDTO.getIfvId());

			S2IFVSfbCommondtEntity s2ifvSfbCommondtEntity = (s2ifvSfbCommondtEntities != null
					&& !s2ifvSfbCommondtEntities.isEmpty()) ? s2ifvSfbCommondtEntities.get(0)
							: modelMapper.map(sfbCommondtDTO, S2IFVSfbCommondtEntity.class);
			s2ifvSfbCommondtEntity.setSfbAoNetwork(sfbCommondtDTO.getSfbAoNetwork());
			s2ifvSfbCommondtEntity.setSfbAoBranches(sfbCommondtDTO.getSfbAoBranches());
			s2ifvSfbCommondtEntity.setSfbAoDate(sfbCommondtDTO.getSfbAoDate());
			s2ifvSfbCommondtEntity.setSfbAoMajorityBranches(sfbCommondtDTO.getSfbAoMajorityBranches());
			S2IFVSfbCommondtEntity savedS2ifvSfbCommondtEntity = sfbCommondtRepository.save(s2ifvSfbCommondtEntity);
			logger.info("s2ifvSfbCommondtEntity {} ", s2ifvSfbCommondtEntity);
			List<S2IFVAreasGeographicalEntity> areasGeographicalEntitiesToSave = listAreasGeographicalDTOs.stream().map(
					areasGeographicalDTO -> modelMapper.map(areasGeographicalDTO, S2IFVAreasGeographicalEntity.class))
					.collect(Collectors.toList());
			List<S2IFVAreasGeographicalEntity> savedAreasGeographicalEntities = areaOfGeographicalRepo
					.saveAll(areasGeographicalEntitiesToSave);
			logger.info("savedAreasGeographicalEntities {} ", savedAreasGeographicalEntities);
			CommonDTO commonDTO2 = new CommonDTO();
			commonDTO2.setListAreasGeographicalDTO(savedAreasGeographicalEntities.stream().map(
					areasGeographicalEntity -> modelMapper.map(areasGeographicalEntity, AreasGeographicalDTO.class))
					.collect(Collectors.toList()));
			commonDTO2.setSfbCommondtDTO(modelMapper.map(savedS2ifvSfbCommondtEntity, SfbCommondtDTO.class));
			logger.info("commonDTO2 {} ", commonDTO2);
			return commonDTO2;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing saveCommonDTO. {}", msg);
			throw new DatabaseOperationException("Error Occurred while executing saveCommonDTO." + msg + " ", e);
		}

	}

	@Override
	public CommonDTO findCommonDTOByIfvId(Long ifvId) {
		logger.info("Started findCommonDTOByIfvId() in AreasGeographicalServiceImpl with ifvId {} ", ifvId);
		try {
			List<S2IFVAreasGeographicalEntity> listAreasGeographicalEntities = areaOfGeographicalRepo
					.findByIfvId(ifvId);
			logger.info("listAreasGeographicalEntities {} ", listAreasGeographicalEntities);
			List<S2IFVSfbCommondtEntity> listS2IFVSfbCommondtEntities = sfbCommondtRepository.findByIfvId(ifvId);
			SfbCommondtDTO sfbCommondtDTO = listS2IFVSfbCommondtEntities.stream().findFirst()
					.map(s2IFVSfbCommondtEntity -> modelMapper.map(s2IFVSfbCommondtEntity, SfbCommondtDTO.class))
					.orElse(null);
			logger.info("sfbCommondtDTO {}", sfbCommondtDTO);
			CommonDTO commonDTO = new CommonDTO();
			commonDTO.setSfbCommondtDTO(sfbCommondtDTO);
			commonDTO.setListAreasGeographicalDTO(listAreasGeographicalEntities.stream()
					.sorted(Comparator.comparing(S2IFVAreasGeographicalEntity::getAgId))
					.map(areasGeographicalEntity -> modelMapper.map(areasGeographicalEntity,
							AreasGeographicalDTO.class))
					.collect(Collectors.toList()));
			logger.info("commonDTO {}", commonDTO);
			return commonDTO;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing findCommonDTOByIfvId based on IfvId. {} {} ", msg, ifvId);
			throw new DatabaseOperationException(
					"Error Occurred while executing findCommonDTOByIfvId based on IfvId." + ifvId + " " + msg + " ", e);

		}

	}

	@Override
	public CommonDTO findCommonDTOByIfvIdAndAgType(Long ifvId, String agType) {
		logger.info(
				"Started findCommonDTOByIfvIdAndAgType() in AreasGeographicalServiceImpl with ifvId and agType {} {} ",
				ifvId, agType);
		try {
			List<S2IFVAreasGeographicalEntity> listAreasGeographicalEntities = areaOfGeographicalRepo
					.findByIfvIdAndAgType(ifvId, agType);
			logger.info("listAreasGeographicalEntities {} ", listAreasGeographicalEntities);
			List<S2IFVSfbCommondtEntity> listS2IFVSfbCommondtEntities = sfbCommondtRepository.findByIfvId(ifvId);
			SfbCommondtDTO sfbCommondtDTO = listS2IFVSfbCommondtEntities.stream().findFirst()
					.map(s2IFVSfbCommondtEntity -> modelMapper.map(s2IFVSfbCommondtEntity, SfbCommondtDTO.class))
					.orElse(null);
			logger.info("sfbCommondtDTO {}", sfbCommondtDTO);
			CommonDTO commonDTO = new CommonDTO();
			commonDTO.setSfbCommondtDTO(sfbCommondtDTO);
			commonDTO.setListAreasGeographicalDTO(listAreasGeographicalEntities.stream()
					.sorted(Comparator.comparing(S2IFVAreasGeographicalEntity::getAgId))
					.map(areasGeographicalEntity -> modelMapper.map(areasGeographicalEntity,
							AreasGeographicalDTO.class))
					.collect(Collectors.toList()));
			logger.info("commonDTO {}", commonDTO);
			return commonDTO;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while executing findCommonDTOByIfvIdAndAgType based on IfvId and agType. {} {} {} ",
					msg, ifvId, agType);
			throw new DatabaseOperationException(
					"Error Occurred while executing findCommonDTOByIfvIdAndAgType based on IfvId and agType." + ifvId
							+ " " + agType + " " + msg + " ",
					e);

		}

	}

	@Override
	public List<AreasGeographicalDTO> findByIfvIdAndCtAgType(Long ifvId, String agType) {
		logger.info("Started findByIfvIdAndCtAgType() in AreasGeographicalServiceImpl with ifvId and agType {} {} ",
				ifvId, agType);
		try {
			List<S2IFVAreasGeographicalEntity> listAreasGeographicalEntities = areaOfGeographicalRepo
					.findByIfvIdAndAgType(ifvId, agType);

			return (listAreasGeographicalEntities != null && !listAreasGeographicalEntities.isEmpty())
					? listAreasGeographicalEntities.stream()
							.sorted(Comparator.comparing(S2IFVAreasGeographicalEntity::getAgId))
							.map(areasGeographicalEntity -> modelMapper.map(areasGeographicalEntity,
									AreasGeographicalDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing findByIfvIdAndCtAgType based on IfvId and agType. {} {} {} ",
					msg, ifvId, agType);
			throw new DatabaseOperationException(
					"Error Occurred while executing findByIfvIdAndCtAgType based on IfvId and agType." + ifvId + " "
							+ agType + " " + msg + " ",
					e);
		}
	}

	@Override
	public void deleteGeographicalArea(Long id) {
		logger.info(
				"deleteGeographicalArea() started in AreasGeographicalServiceImpl for S2IFVAreasGeographicalEntity {}",
				id);
		try {
			S2IFVAreasGeographicalEntity applicationEntity = areaOfGeographicalRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAreasGeographicalEntity", id));

			areaOfGeographicalRepo.deleteAllByIfvIdAndRrbStateName(applicationEntity.getIfvId(),
					applicationEntity.getRrbStateName());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVAreasGeographicalEntity entity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVAreasGeographicalEntity entity of id ." + id + " " + msg + " ",
					e);
		}

	}
}