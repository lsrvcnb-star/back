package com.sidbi.ifv.reports;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTBorder;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTInd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTbl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblBorders;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblCellMar;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblGrid;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblGridCol;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcMar;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTVerticalJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STBorder;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STVerticalJc;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.IfvProposalLoIDto;
import com.sidbi.ifv.dto.MasterRepositoryDTO;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.dto.SanctionTermsConditionsDTO;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.CurrencyConverter;

public class LoIReportWord {

	private static final int DEFAULT_FONT_SIZE = 11;

	private static final String DEFAULT_FONT_STYLE = "Rupee Foradian";

	private List<MasterRepositoryDTO> masterRepositoryData;

	private IfvProposalLoIDto ifvProposalLoIDto;

	private List<SanctionTermsConditionsDTO> sanctionTermsConditionsDTOs;

	private List<ProposedSchemaDTO> proposedSchemaDetails;

	private String userName;

	private String designation;

	private static final String COLOR = "000000";

	public LoIReportWord(IfvProposalLoIDto ifvProposalLoIDto,
			List<SanctionTermsConditionsDTO> sanctionTermsConditionsDTOs,
			List<MasterRepositoryDTO> masterRepositoryData, List<ProposedSchemaDTO> proposedSchemaDetails,
			String userName, String designation) {
		this.ifvProposalLoIDto = ifvProposalLoIDto;
		this.sanctionTermsConditionsDTOs = sanctionTermsConditionsDTOs;
		this.masterRepositoryData = masterRepositoryData;
		this.proposedSchemaDetails = proposedSchemaDetails;
		this.userName = userName;
		this.designation = designation;
	}

	public byte[] generateWordDocument() throws Exception {
		try (XWPFDocument document = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {

			addHeaderSection(document);
			addReferenceAndDate(document);
			addAddressSection(document);
			addMainContent(document);
			addNote3Footer(document);
			int size = 1;
			Map<Long, ProposedSchemaDTO> map = proposedSchemaDetails.stream()
					.collect(Collectors.toMap(ProposedSchemaDTO::getPrId, Function.identity()));
			if (sanctionTermsConditionsDTOs != null && !sanctionTermsConditionsDTOs.isEmpty()) {
				for (SanctionTermsConditionsDTO dto : sanctionTermsConditionsDTOs) {
					document.createParagraph().setPageBreak(true); // New page
					createTableForAppendix(dto, size, map, document);
					++size;
				}
			}
			document.write(out);
			return out.toByteArray();
		}
	}

	private void addHeaderSection(XWPFDocument document) {
		XWPFParagraph header = document.createParagraph();
		header.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun headerRun = header.createRun();
		headerRun.setText("दो प्रतियों में / In Duplicate");
		headerRun.setBold(true);
		headerRun.setUnderline(UnderlinePatterns.SINGLE);
		headerRun.setFontSize(DEFAULT_FONT_SIZE);
		headerRun.setFontFamily(DEFAULT_FONT_STYLE);
		headerRun.addBreak();
		headerRun.addBreak();

	}

	private void addReferenceAndDate(XWPFDocument document) {
		XWPFTable table = document.createTable(2, 2);
		table.setWidth("100%");
		// Remove borders from the table
		table.setCellMargins(0, 0, 0, 0); // Set cell margins to 0
		table.setInsideHBorder(XWPFTable.XWPFBorderType.NONE, 0, 0, "");
		table.setInsideVBorder(XWPFTable.XWPFBorderType.NONE, 0, 0, "");
		table.setTopBorder(XWPFTable.XWPFBorderType.NONE, 0, 0, "");
		table.setBottomBorder(XWPFTable.XWPFBorderType.NONE, 0, 0, "");
		table.setLeftBorder(XWPFTable.XWPFBorderType.NONE, 0, 0, "");
		table.setRightBorder(XWPFTable.XWPFBorderType.NONE, 0, 0, "");
		// Alternative method using direct CTTbl manipulation
		CTTbl ttbl = table.getCTTbl();
		CTTblPr tblPr = ttbl.getTblPr();
		CTTblBorders borders = tblPr.isSetTblBorders() ? tblPr.getTblBorders() : tblPr.addNewTblBorders();
		borders.addNewTop().setVal(STBorder.NONE);
		borders.addNewBottom().setVal(STBorder.NONE);
		borders.addNewLeft().setVal(STBorder.NONE);
		borders.addNewRight().setVal(STBorder.NONE);
		borders.addNewInsideH().setVal(STBorder.NONE);
		borders.addNewInsideV().setVal(STBorder.NONE);
		// First row
		XWPFTableRow row1 = table.getRow(0);
		XWPFTableCell cell1 = row1.getCell(0);
		XWPFParagraph paragraph1 = cell1.getParagraphs().get(0);
		XWPFRun run1 = paragraph1.createRun();
		run1.setText("सिडबी:आईएफवी सं. " + ifvProposalLoIDto.getLoiNo());
		run1.setFontSize(DEFAULT_FONT_SIZE);
		run1.setFontFamily(DEFAULT_FONT_STYLE);
		LocalDate localDate = ifvProposalLoIDto.getLoiDate().toInstant().atZone(java.time.ZoneId.systemDefault())
				.toLocalDate();
		String formattedDate = localDate.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH));
		XWPFTableCell cell2 = row1.getCell(1);
		XWPFParagraph paragraph2 = cell2.getParagraphs().get(0);
		paragraph2.setAlignment(ParagraphAlignment.RIGHT);
		XWPFRun run2 = paragraph2.createRun();
		run2.setText(formattedDate);
		run2.setFontSize(DEFAULT_FONT_SIZE);
		run2.setFontFamily(DEFAULT_FONT_STYLE);
		// Second row
		XWPFTableRow row2 = table.getRow(1);
		XWPFTableCell cell3 = row2.getCell(0);
		XWPFParagraph paragraph3 = cell3.getParagraphs().get(0);
		XWPFRun run3 = paragraph3.createRun();
		run3.setFontSize(DEFAULT_FONT_SIZE);
		run3.setFontFamily(DEFAULT_FONT_STYLE);
		run3.setText("SIDBI: IFV: No. " + ifvProposalLoIDto.getLoiNo());
		XWPFTableCell cell4 = row2.getCell(1);
		XWPFParagraph paragraph4 = cell4.getParagraphs().get(0);
		paragraph4.setAlignment(ParagraphAlignment.RIGHT);
		XWPFRun run4 = paragraph4.createRun();
		run4.setFontSize(DEFAULT_FONT_SIZE);
		run4.setFontFamily(DEFAULT_FONT_STYLE);
		run4.setText(formattedDate);
	}

	private void addAddressSection(XWPFDocument document) {
		// Create paragraph
		XWPFParagraph addressPara = document.createParagraph();
		// Set paragraph width to 50% using indentation
		CTPPr pPr = addressPara.getCTP().getPPr();
		if (pPr == null)
			pPr = addressPara.getCTP().addNewPPr();
		// Set right indentation to limit width to 50%
		CTInd ind = pPr.addNewInd();
		// Using twips (twentieth of a point) - setting right indentation to 50% of
		// typical page width
		ind.setRight(BigInteger.valueOf(4500)); // This value represents roughly 50% of page width
		// Add content
		XWPFRun toRun = addressPara.createRun();
		toRun.setText("To,");
		toRun.setFontSize(DEFAULT_FONT_SIZE);
		toRun.setFontFamily(DEFAULT_FONT_STYLE);
		toRun.addBreak();
		// Add address as a single block
		XWPFRun addressRun = addressPara.createRun();
		addressRun.setText(ifvProposalLoIDto.getAddressOfTheBank());
		addressRun.setFontSize(DEFAULT_FONT_SIZE);
		addressRun.setFontFamily(DEFAULT_FONT_STYLE);
		addressRun.addBreak();
		addressRun.addBreak();
		// Add Dear Sir
		XWPFRun dearRun = addressPara.createRun();
		dearRun.setText("प्रिय महोदय / Dear Sir,");
		dearRun.setFontSize(DEFAULT_FONT_SIZE);
		dearRun.setFontFamily(DEFAULT_FONT_STYLE);
	}

	private void addMainContent(XWPFDocument document) {
		// Add header note
		XWPFParagraph headerNote = document.createParagraph();
		headerNote.setAlignment(ParagraphAlignment.CENTER);

		String schemeName = ifvProposalLoIDto.getSchemeName();

		XWPFRun headerNoteHindiRun = headerNote.createRun();
		headerNoteHindiRun.setText("सूक्ष्म और लघु उद्यम पुनर्वित्त (" + schemeName
				+ ") योजना के अंतर्गत पुनर्वित्त सहायता हेतु आशय पत्र");
		headerNoteHindiRun.setUnderline(UnderlinePatterns.SINGLE);
		headerNoteHindiRun.setFontSize(DEFAULT_FONT_SIZE);
		headerNoteHindiRun.setFontFamily(DEFAULT_FONT_STYLE);
		headerNoteHindiRun.addBreak();

		XWPFRun headerNoteRun = headerNote.createRun();
		headerNoteRun.setText(ifvProposalLoIDto.getHeaderNote());
		headerNoteRun.setUnderline(UnderlinePatterns.SINGLE);
		headerNoteRun.setFontSize(DEFAULT_FONT_SIZE);
		headerNoteRun.setFontFamily(DEFAULT_FONT_STYLE);
		headerNoteRun.addBreak();
		// Add Note 1
		if (ifvProposalLoIDto.getNote1() != null && !ifvProposalLoIDto.getNote1().isBlank()) {
			XWPFParagraph note1 = document.createParagraph();
			note1.setAlignment(ParagraphAlignment.BOTH);

			XWPFRun tabRun = note1.createRun();
			tabRun.addTab();

			String paraDate = " ";
			// Pattern to match dates in format "Month DD, YYYY"
			Pattern pattern = Pattern.compile(
					"(January|February|March|April|May|June|July|August|September|October|November|December)\\s+(\\d{1,2}),\\s+(\\d{4})");
			Matcher matcher = pattern.matcher(ifvProposalLoIDto.getNote1());
			if (matcher.find()) {
				String month = matcher.group(1);
				String day = matcher.group(2);
				String year = matcher.group(3);
				try {
					// Parse and format the date
					paraDate = String.format("%s %s %s", day, month, year);

				} catch (DateTimeParseException e) {
					e.printStackTrace();
				}
			}

			String annexures = "Annexure";
			if (sanctionTermsConditionsDTOs.size() > 1) {
				StringBuilder annexuresBuilder = new StringBuilder();
				for (int i = 1; i <= sanctionTermsConditionsDTOs.size(); i++) {
					annexuresBuilder.append("Annexure ").append(i);
					if (i < sanctionTermsConditionsDTOs.size()) {
						annexuresBuilder.append(" & ");
					}
				}
				annexures = annexuresBuilder.toString();
			}

			String hindiText = """
					%s योजना के अंतर्गत पुनर्वित्त की मंजूरी से संबंधित दिनांक %s, के अपने आवेदन का सदर्भ लें । हम सूचित करते हैं कि आप के अनुरोध पर विचार किया गया है और भारतीय लघु उद्योग विकास बैंक (सिडबी) आप के बैंक को रु.%s करोड़ (%s) सिडबी की %s योजना के अंतर्गत, आपके द्वारा निष्पादित सामान्य करार के तहत सहमत शर्तों और विशेष रूप से विचाराधीन प्रस्ताव के लिए %s में विनिर्दिष्ट नियमों और शर्तों पर पुनर्वित्त के माध्यम से वित्तीय सहायता प्रदान करने के लिए सैद्धांतिक रूप से सहमत है।
					"""
					.formatted(schemeName, paraDate,
							CommonUtil.formatNumber(ifvProposalLoIDto.getAmount().stripTrailingZeros().toPlainString()),
							ifvProposalLoIDto.getAmountInWords(), schemeName, annexures);
			XWPFRun note1HindiRun = note1.createRun();
			note1HindiRun.setText(hindiText);
			note1HindiRun.setFontSize(DEFAULT_FONT_SIZE);
			note1HindiRun.setFontFamily(DEFAULT_FONT_STYLE);
			note1HindiRun.addBreak();
			note1HindiRun.addBreak();
			XWPFRun tabRun1 = note1.createRun();
			tabRun1.addTab();
			XWPFRun note1Run = note1.createRun();
			note1Run.setText(ifvProposalLoIDto.getNote1());
			note1Run.setFontSize(DEFAULT_FONT_SIZE);
			note1Run.setFontFamily(DEFAULT_FONT_STYLE);
			note1Run.addBreak();
			note1Run.addBreak();
		}
		// Add Note 2
		if (ifvProposalLoIDto.getNote2() != null && !ifvProposalLoIDto.getNote2().isBlank()) {

			XWPFParagraph pageBreakParagraph = document.createParagraph();
			XWPFRun pageBreakRun = pageBreakParagraph.createRun();
			pageBreakRun.addBreak(BreakType.PAGE);

			XWPFParagraph note2 = document.createParagraph();
			note2.setAlignment(ParagraphAlignment.BOTH);
			XWPFRun tabRun = note2.createRun();
			tabRun.addTab();
			XWPFRun note2HindiRun = note2.createRun();
			note2HindiRun.setFontSize(DEFAULT_FONT_SIZE);
			note2HindiRun.setFontFamily(DEFAULT_FONT_STYLE);
			note2HindiRun.setText(
					"2. यह आशय पत्र दो प्रतियों में जारी किया जा रहा है। यदि ये नियम और शर्तें आपके बैंक को स्वीकार्य हों तो, आप कृपया अपने बैंक के प्राधिकृत अधिकारी द्वारा विधिवत रुप से स्वीकृत इसकी द्वितीयक प्रति हमें वापस भिजवाएँ। कृपया बैंक के मुहर के साथ इसकी द्वितीयक प्रति के प्रत्येक पृष्ठ पर हस्ताक्षर करें और इसे करार के लिए अपेक्षित मूल्य के गैर-न्यायिक स्टाम्प पेपर के साथ संलग्न करें, जिस पर प्राधिकृत अधिकारी द्वारा निम्नानुसार समर्थन किया गया हो:");
			note2HindiRun.addBreak();
			note2HindiRun.addBreak();
			XWPFRun tabRun1 = note2.createRun();
			tabRun1.addTab();

			XWPFRun note2Run = note2.createRun();
			note2Run.setText(ifvProposalLoIDto.getNote2());
			note2Run.setFontSize(DEFAULT_FONT_SIZE);
			note2Run.setFontFamily(DEFAULT_FONT_STYLE);
			note2Run.addBreak();
		}

		addSubNotes(document);

		// Add Note 3
		if (ifvProposalLoIDto.getNote3() != null && !ifvProposalLoIDto.getNote3().isBlank()) {

			XWPFParagraph pageBreakParagraph = document.createParagraph();
			XWPFRun pageBreakRun = pageBreakParagraph.createRun();
			pageBreakRun.addBreak(BreakType.PAGE);

			XWPFParagraph note3 = document.createParagraph();
			note3.setAlignment(ParagraphAlignment.BOTH);

			XWPFRun tabRun = note3.createRun();
			tabRun.addTab();
			XWPFRun note3HindiRun = note3.createRun();
			note3HindiRun.setFontSize(DEFAULT_FONT_SIZE);
			note3HindiRun.setFontFamily(DEFAULT_FONT_STYLE);
			note3HindiRun.setText(
					"3. कृपया नोट करें कि इस पत्र को सिडबी की ओर से किसी भी प्रकार के बाध्यकारी दायित्व के रूप में तब तक नहीं माना जाना चाहिए, जब तक कि आप का बैंक उक्त सुविधा से संबन्धित ऋण करार और अन्य दस्तावेज, यदि कोई हो तो, इस आशय पत्र की तिथि से 3 कार्य दिवस के भीतर या सिडबी द्वारा अपने पूर्ण विवेक से अनुमत ऐसी किसी आगे की समयावधि के भीतर आपके बैंक द्वारा निष्पादित नहीं कर दिया जाता है।");
			note3HindiRun.addBreak();
			note3HindiRun.addBreak();
			XWPFRun tabRun1 = note3.createRun();
			tabRun1.addTab();

			XWPFRun note3Run = note3.createRun();
			note3Run.setText(ifvProposalLoIDto.getNote3());
			note3Run.setFontSize(DEFAULT_FONT_SIZE);
			note3Run.setFontFamily(DEFAULT_FONT_STYLE);
			note3Run.addBreak();
		}
	}

	private void addSubNotes(XWPFDocument document) {
		XWPFParagraph pSubNote1 = null;
		XWPFParagraph pSubNote2 = null;
		boolean subNotePresent = false;
		XWPFTable containerTable = document.createTable();
		containerTable.setWidth("100%");
		// Set cell margins for better content spacing
		setCellMargins(containerTable, 50, 50, 50, 50); // 200 twips = ~10 points
		XWPFTableRow row = containerTable.getRow(0);
		XWPFTableCell containerCell = row.getCell(0);
		// Add subnote 1
		if (ifvProposalLoIDto.getNote2Subnote1() != null && !ifvProposalLoIDto.getNote2Subnote1().isBlank()) {
			pSubNote1 = containerCell.getParagraphs().get(0);
			XWPFRun run = pSubNote1.createRun();
			run.setText(ifvProposalLoIDto.getNote2Subnote1());
			run.setBold(true);
			run.setFontSize(DEFAULT_FONT_SIZE);
			run.setFontFamily(DEFAULT_FONT_STYLE);
			pSubNote1.setAlignment(ParagraphAlignment.BOTH);
			pSubNote1.setSpacingAfter(300);
			subNotePresent = true;
		}
		// Add subnote 2
		if (ifvProposalLoIDto.getNote2Subnote2() != null && !ifvProposalLoIDto.getNote2Subnote2().isBlank()) {
			pSubNote2 = containerCell.addParagraph();
			XWPFRun run = pSubNote2.createRun();
			run.setText(ifvProposalLoIDto.getNote2Subnote2());
			run.setBold(true);
			run.setFontSize(DEFAULT_FONT_SIZE);
			run.setFontFamily(DEFAULT_FONT_STYLE);
			pSubNote2.setAlignment(ParagraphAlignment.BOTH);
			pSubNote2.setSpacingAfter(300);
		}
		if (subNotePresent) {
			// Add document details
			XWPFParagraph pSubNote3 = containerCell.addParagraph();
			// Name of Document
			XWPFRun nameRun = pSubNote3.createRun();
			nameRun.setText("Name of the Document: ");
			nameRun.setBold(true);
			nameRun.setFontSize(DEFAULT_FONT_SIZE);
			nameRun.setFontFamily(DEFAULT_FONT_STYLE);
			XWPFRun nameValueRun = pSubNote3.createRun();
			nameValueRun.setText(
					ifvProposalLoIDto.getNameOfDocuments() != null ? ifvProposalLoIDto.getNameOfDocuments() : "");
			nameValueRun.setItalic(true);
			nameValueRun.setFontSize(DEFAULT_FONT_SIZE);
			nameValueRun.setFontFamily(DEFAULT_FONT_STYLE);
			nameValueRun.addBreak();
			nameValueRun.addBreak();
			// Date
			String formattedDate2 = "";
			if (ifvProposalLoIDto.getDocumentDated() != null) {
				LocalDate localDate2 = ifvProposalLoIDto.getDocumentDated().toInstant()
						.atZone(java.time.ZoneId.systemDefault()).toLocalDate();
				formattedDate2 = localDate2.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH));
			}
			XWPFRun dateRun = pSubNote3.createRun();
			dateRun.setText("Dated: ");
			dateRun.setBold(true);
			dateRun.setFontSize(DEFAULT_FONT_SIZE);
			dateRun.setFontFamily(DEFAULT_FONT_STYLE);
			XWPFRun dateValueRun = pSubNote3.createRun();
			dateValueRun.setText(formattedDate2);
			dateValueRun.setItalic(true);
			dateValueRun.setFontSize(DEFAULT_FONT_SIZE);
			dateValueRun.setFontFamily(DEFAULT_FONT_STYLE);
			dateValueRun.addBreak();
			// Section/Clause
			XWPFRun sectionRun = pSubNote3.createRun();
			sectionRun.setText("Section / Clause No. & Page Number: ");
			sectionRun.setBold(true);
			sectionRun.setFontSize(DEFAULT_FONT_SIZE);
			sectionRun.setFontFamily(DEFAULT_FONT_STYLE);
			XWPFRun sectionValueRun = pSubNote3.createRun();
			sectionValueRun.setText(
					ifvProposalLoIDto.getSectionOrClauseNo() != null ? ifvProposalLoIDto.getSectionOrClauseNo() : "");
			sectionValueRun.setItalic(true);
			sectionValueRun.setFontSize(DEFAULT_FONT_SIZE);
			sectionValueRun.setFontFamily(DEFAULT_FONT_STYLE);
			sectionValueRun.addBreak();
			// Mode
			XWPFRun modeRun = pSubNote3.createRun();
			modeRun.setText("Mode: ");
			modeRun.setBold(true);
			modeRun.setFontSize(DEFAULT_FONT_SIZE);
			modeRun.setFontFamily(DEFAULT_FONT_STYLE);
			XWPFRun modeValueRun = pSubNote3.createRun();
			modeValueRun.setText(ifvProposalLoIDto.getSectionMode() != null ? ifvProposalLoIDto.getSectionMode() : "");
			modeValueRun.setItalic(true);
			modeValueRun.setFontSize(DEFAULT_FONT_SIZE);
			modeValueRun.setFontFamily(DEFAULT_FONT_STYLE);
			modeValueRun.addBreak();
			modeValueRun.addBreak();
			// KYC Documents
			XWPFRun kycRun = pSubNote3.createRun();
			kycRun.setText("The following KYC documents of authorized signatories are attached (Any one).");
			kycRun.setBold(true);
			kycRun.setFontSize(DEFAULT_FONT_SIZE);
			kycRun.setFontFamily(DEFAULT_FONT_STYLE);
			kycRun.addBreak();
			XWPFRun kycDocRun = pSubNote3.createRun();
			kycDocRun.setText(
					"\t" + (ifvProposalLoIDto.getKycDocuments() != null ? ifvProposalLoIDto.getKycDocuments() : ""));
			kycDocRun.setItalic(true);
			kycDocRun.setFontSize(DEFAULT_FONT_SIZE);
			kycDocRun.setFontFamily(DEFAULT_FONT_STYLE);
			kycDocRun.addBreak();
			kycDocRun.addBreak();
			XWPFParagraph signatureLinePara = containerCell.addParagraph();
			// First Line: Date and Full Signature
			XWPFRun dateLineRun = signatureLinePara.createRun();
			dateLineRun.setText("Date: ");
			dateLineRun.setBold(true);
			dateLineRun.setFontSize(DEFAULT_FONT_SIZE);
			dateLineRun.setFontFamily(DEFAULT_FONT_STYLE);
			// Add a tab to create space between Date and Full Signature
			XWPFRun tabRun1 = signatureLinePara.createRun();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			tabRun1.addTab();
			XWPFRun fullSignatureRun = signatureLinePara.createRun();
			fullSignatureRun.setText("(Full Signature)");
			fullSignatureRun.setBold(true);
			fullSignatureRun.setFontSize(DEFAULT_FONT_SIZE);
			fullSignatureRun.setFontFamily(DEFAULT_FONT_STYLE);
			// Second Line: Place and Name & Designation
			XWPFParagraph placeLinePara = containerCell.addParagraph();
			XWPFRun placeLineRun = placeLinePara.createRun();
			placeLineRun.setText("Place: ");
			placeLineRun.setBold(true);
			placeLineRun.setFontSize(DEFAULT_FONT_SIZE);
			placeLineRun.setFontFamily(DEFAULT_FONT_STYLE);
			// Add a tab to create space between Place and Name & Designation
			XWPFRun tabRun2 = placeLinePara.createRun();
			tabRun2.addTab();
			tabRun2.addTab();
			tabRun2.addTab();
			tabRun2.addTab();
			tabRun2.addTab();
			tabRun2.addTab();
			tabRun2.addTab();
			tabRun2.addTab();
			tabRun2.addTab();
			XWPFRun nameDesignationRun = placeLinePara.createRun();
			nameDesignationRun.setText("(Name & Designation)");
			nameDesignationRun.setBold(true);
			nameDesignationRun.setFontSize(DEFAULT_FONT_SIZE);
			nameDesignationRun.setFontFamily(DEFAULT_FONT_STYLE);
			// Authorized Signatory on a separate line
			XWPFParagraph authSignatoryPara = containerCell.addParagraph();
			authSignatoryPara.setAlignment(ParagraphAlignment.RIGHT);
			XWPFRun authSignatoryRun = authSignatoryPara.createRun();
			authSignatoryRun.setText("(Authorized Signatory)");
			authSignatoryRun.setBold(true);
			authSignatoryRun.setFontSize(DEFAULT_FONT_SIZE);
			authSignatoryRun.setFontFamily(DEFAULT_FONT_STYLE);
			authSignatoryRun.addBreak();
			authSignatoryRun.addBreak();
		}
	}

	private void setCellMargins(XWPFTable table, int top, int right, int bottom, int left) {
		CTTbl ttbl = table.getCTTbl();
		CTTblPr tblPr = ttbl.getTblPr() != null ? ttbl.getTblPr() : ttbl.addNewTblPr();
		CTTblCellMar cellMar = tblPr.getTblCellMar() != null ? tblPr.getTblCellMar() : tblPr.addNewTblCellMar();
		CTTblWidth topMargin = cellMar.getTop() != null ? cellMar.getTop() : cellMar.addNewTop();
		topMargin.setType(STTblWidth.DXA);
		topMargin.setW(BigInteger.valueOf(top));
		CTTblWidth rightMargin = cellMar.getRight() != null ? cellMar.getRight() : cellMar.addNewRight();
		rightMargin.setType(STTblWidth.DXA);
		rightMargin.setW(BigInteger.valueOf(right));
		CTTblWidth bottomMargin = cellMar.getBottom() != null ? cellMar.getBottom() : cellMar.addNewBottom();
		bottomMargin.setType(STTblWidth.DXA);
		bottomMargin.setW(BigInteger.valueOf(bottom));
		CTTblWidth leftMargin = cellMar.getLeft() != null ? cellMar.getLeft() : cellMar.addNewLeft();
		leftMargin.setType(STTblWidth.DXA);
		leftMargin.setW(BigInteger.valueOf(left));
	}

	private void addNote3Footer(XWPFDocument document) {
		XWPFParagraph footer = document.createParagraph();

		footer.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun footerRun1 = footer.createRun();
		footerRun1.addTab();
		footerRun1.setText("कृपया प्राप्ति सूचना दें / Please acknowledge receipt.");
		footerRun1.setFontSize(DEFAULT_FONT_SIZE);
		footerRun1.setFontFamily(DEFAULT_FONT_STYLE);
		XWPFParagraph footer1 = document.createParagraph();
		footer1.setAlignment(ParagraphAlignment.RIGHT);
		XWPFRun footerRun = footer1.createRun();
		footerRun.setFontSize(DEFAULT_FONT_SIZE);
		footerRun.setFontFamily(DEFAULT_FONT_STYLE);
		footerRun.setText("भवदीय Yours faithfully,");
		footerRun.addBreak();
		footerRun.addBreak();
		footerRun.setText("[" + userName + "]");
		footerRun.addBreak();
		footerRun.setText(designation);
		footerRun.addBreak();
		footerRun.addBreak();
		XWPFParagraph enclosure = document.createParagraph();
		enclosure.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun enclosureRun = enclosure.createRun();
		enclosureRun.setText("संलग्नक: यथोक्त Encl: As above");
		enclosureRun.setFontSize(DEFAULT_FONT_SIZE);
		enclosureRun.setFontFamily(DEFAULT_FONT_STYLE);
	}

	public String getSchemeName(String schemeName) {
		String wordToFind = "FUND";
		int index = schemeName.indexOf(wordToFind);
		if (index != -1) {
			return schemeName.substring(0, index).trim();
		}
		return schemeName;
	}

	private void createTableForAppendix(SanctionTermsConditionsDTO dto, int size, Map<Long, ProposedSchemaDTO> map,
			XWPFDocument document) {
		// Add Annexure header
		XWPFParagraph annexurePara = document.createParagraph();
		annexurePara.setAlignment(ParagraphAlignment.RIGHT);
		XWPFRun annexureRun = annexurePara.createRun();
		annexureRun.setText("Annexure-" + size);
		annexureRun.setBold(true);
		annexureRun.setFontSize(DEFAULT_FONT_SIZE);
		annexureRun.setFontFamily(DEFAULT_FONT_STYLE);
		// Add title
		XWPFParagraph titlePara = document.createParagraph();
		titlePara.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun titleRun = titlePara.createRun();
		titleRun.setText("Terms and Conditions of Sanction");
		titleRun.setBold(true);
		titleRun.setFontSize(DEFAULT_FONT_SIZE);
		titleRun.setFontFamily(DEFAULT_FONT_STYLE);
		titleRun.setUnderline(UnderlinePatterns.SINGLE);
		// Add scheme name
		String schemeName = dto.getSchemeName() != null ? dto.getSchemeName() : "";
		if (schemeName.toUpperCase().contains("RMSE")) {
			schemeName = getSchemeName(dto.getFundName());
		}
		XWPFParagraph schemePara = document.createParagraph();
		schemePara.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun schemeRun = schemePara.createRun();
		schemeRun.setText("Refinance under " + schemeName + " scheme to " + ifvProposalLoIDto.getIfvName());
		schemeRun.setBold(true);
		schemeRun.setFontSize(DEFAULT_FONT_SIZE);
		schemeRun.setFontFamily(DEFAULT_FONT_STYLE);
		schemeRun.setUnderline(UnderlinePatterns.SINGLE);
		// Create table
		XWPFTable table = document.createTable();
		table.setWidth("100%");
		setTableColumnWidths(table, new int[] { 600, 2300, 7100 });
		// Remove default first row
		table.removeRow(0);
		// Add table rows
		addTableRow(table, "1", "Scheme", schemeName);
		String finalAmountInWords;
		String amountInWords = dto.getAmountInWords() != null ? dto.getAmountInWords() : "";
		if (amountInWords.contains("Rupees")) {
			finalAmountInWords = CommonUtil.formatNumber(dto.getAmount().stripTrailingZeros().toPlainString())
					+ " crore (" + amountInWords + ")";
		} else {
			finalAmountInWords = CommonUtil.formatNumber(dto.getAmount().stripTrailingZeros().toPlainString())
					+ " crore (Rupees " + amountInWords + ")";
		}
		addTableRow(table, "2", "Amount", "₹" + finalAmountInWords);
		String interestRate = formatInterestRateDetails(dto, map.get(dto.getPrId()));
		addTableRowWithFormat(table, "3", "Rate of Interest", interestRate);
		addTableRowWithFormatExtended(table, "4", "Tenure of Refinance / Repayment", dto);
		addTableRow(table, "5", "Extent of Refinance", dto.getTsExtent());
		addTableRow(table, "6", "Eligible end borrowers / underlying assets", dto.getTsEligibleMse());
		addTableRow(table, "7", "Eligible activities", "As defined in section 2(h) of SIDBI Act.");
		addTableRow(table, "8", "Event of default", dto.getTsEventDflt());
		addTableRow(table, "9", "Security", dto.getTsSecurity());
		addTableRow(table, "10", "Documentation", dto.getTsDocumentstion());
		addTableRow(table, "11", "Time frame for acceptance of LoI / disbursement", dto.getTsTimeFrame());
		addTableRow(table, "12", "Drawal of loan", dto.getTsDrawaloan());
		addTableRowWithForOtherConditions(table, "13", "Other Conditions", dto.getTsOtherCond());
	}

	private void addTableRow(XWPFTable table, String number, String label, String value) {
		XWPFTableRow row = table.createRow();
		// Set row height
		row.setHeight((int) (240)); // Approximately 12pt in twentieths of a point
		row.getCtRow().getTrPr().addNewTrHeight().setVal(BigInteger.valueOf(240));
		// Create cells if they don't exist
		XWPFTableCell cell1 = row.getCell(0);
		if (cell1 == null) {
			cell1 = row.createCell();
		}
		XWPFTableCell cell2 = row.getCell(1);
		if (cell2 == null) {
			cell2 = row.createCell();
		}
		XWPFTableCell cell3 = row.getCell(2);
		if (cell3 == null) {
			cell3 = row.createCell();
		}
		// Number cell
		XWPFParagraph para1 = cell1.getParagraphs().isEmpty() ? cell1.addParagraph() : cell1.getParagraphs().get(0);
		XWPFRun run1 = para1.createRun();
		run1.setText(number);
		run1.setFontSize(DEFAULT_FONT_SIZE);
		run1.setFontFamily(DEFAULT_FONT_STYLE);
		setCellProperties(cell1, true, ParagraphAlignment.CENTER);
		// Label cell
		XWPFParagraph para2 = cell2.getParagraphs().isEmpty() ? cell2.addParagraph() : cell2.getParagraphs().get(0);
		XWPFRun run2 = para2.createRun();
		run2.setText(label);
		run2.setFontSize(DEFAULT_FONT_SIZE);
		run2.setFontFamily(DEFAULT_FONT_STYLE);
		setCellProperties(cell2, true, ParagraphAlignment.LEFT);
		// Set vertical alignment for label cell to top
		CTTc ctTc = cell2.getCTTc();
		CTTcPr tcPr = ctTc.isSetTcPr() ? ctTc.getTcPr() : ctTc.addNewTcPr();
		CTVerticalJc vAlign = tcPr.isSetVAlign() ? tcPr.getVAlign() : tcPr.addNewVAlign();
		vAlign.setVal(STVerticalJc.TOP);
		// Value cell
		XWPFParagraph para3 = cell3.getParagraphs().isEmpty() ? cell3.addParagraph() : cell3.getParagraphs().get(0);
		XWPFRun run3 = para3.createRun();
		run3.setText(value);
		run3.setFontSize(DEFAULT_FONT_SIZE);
		run3.setFontFamily(DEFAULT_FONT_STYLE);
		setCellProperties(cell3, false, ParagraphAlignment.BOTH);
		// Set minimal spacing for paragraphs
		para1.setSpacingAfter(0);
		para2.setSpacingAfter(0);
		para3.setSpacingAfter(0);
		para1.setSpacingBefore(0);
		para2.setSpacingBefore(0);
		para3.setSpacingBefore(0);
	}

	private void setCellProperties(XWPFTableCell cell, boolean isHeader, ParagraphAlignment alignment) {
		// Clear existing paragraphs
		while (cell.getParagraphs().size() > 1) {
			cell.removeParagraph(cell.getParagraphs().size() - 1);
		}
		XWPFParagraph paragraph = cell.getParagraphArray(0);
		paragraph.setAlignment(alignment);
		// Set minimal spacing
		paragraph.setSpacingAfter(0);
		paragraph.setSpacingBefore(0);
		// Set cell properties
		CTTc ctTc = cell.getCTTc();
		CTTcPr tcPr = ctTc.isSetTcPr() ? ctTc.getTcPr() : ctTc.addNewTcPr();
		if (isHeader) {
			// Set background color to light gray for header cells
			CTShd ctShd = tcPr.isSetShd() ? tcPr.getShd() : tcPr.addNewShd();
			ctShd.setFill("D3D3D3");
		}
		// Set minimal cell margins/padding
		CTTcMar tcMar = tcPr.isSetTcMar() ? tcPr.getTcMar() : tcPr.addNewTcMar();
		// Set all margins to minimal value (20 twentieths of a point = 1 point)
		if (!tcMar.isSetTop())
			tcMar.addNewTop();
		if (!tcMar.isSetBottom())
			tcMar.addNewBottom();
		if (!tcMar.isSetLeft())
			tcMar.addNewLeft();
		if (!tcMar.isSetRight())
			tcMar.addNewRight();
		tcMar.getTop().setW(BigInteger.valueOf(20));
		tcMar.getBottom().setW(BigInteger.valueOf(20));
		tcMar.getLeft().setW(BigInteger.valueOf(50));
		tcMar.getRight().setW(BigInteger.valueOf(50));
	}

	private void addTableRowWithFormat(XWPFTable table, String number, String label, String value) {
		XWPFTableRow row = table.createRow();
		// Create cells if they don't exist
		XWPFTableCell cell1 = row.getCell(0);
		if (cell1 == null) {
			cell1 = row.createCell();
		}
		XWPFTableCell cell2 = row.getCell(1);
		if (cell2 == null) {
			cell2 = row.createCell();
		}
		XWPFTableCell cell3 = row.getCell(2);
		if (cell3 == null) {
			cell3 = row.createCell();
		}
		// Number cell
		XWPFParagraph para1 = cell1.getParagraphs().isEmpty() ? cell1.addParagraph() : cell1.getParagraphs().get(0);
		XWPFRun run1 = para1.createRun();
		run1.setText(number);
		run1.setFontSize(DEFAULT_FONT_SIZE);
		run1.setFontFamily(DEFAULT_FONT_STYLE);
		setCellProperties(cell1, true, ParagraphAlignment.CENTER);
		// Label cell with line breaks
		XWPFParagraph para2 = cell2.getParagraphs().isEmpty() ? cell2.addParagraph() : cell2.getParagraphs().get(0);
		XWPFRun run2 = para2.createRun();
		String[] lines = label.split("\n");
		for (int i = 0; i < lines.length; i++) {
			run2.setText(lines[i]);
			if (i < lines.length - 1) {
				run2.addBreak();
			}
		}
		run2.setFontSize(DEFAULT_FONT_SIZE);
		run2.setFontFamily(DEFAULT_FONT_STYLE);
		setCellProperties(cell2, true, ParagraphAlignment.LEFT);
		// Value cell with possible formatting
		XWPFParagraph para3 = cell3.getParagraphs().isEmpty() ? cell3.addParagraph() : cell3.getParagraphs().get(0);
		XWPFRun run3 = para3.createRun();
		String[] valueLines = value.split("\n");
		for (int i = 0; i < valueLines.length; i++) {
			run3.setText(valueLines[i]);
			if (i < valueLines.length - 1) {
				run3.addBreak();
			}
		}
		run3.setFontSize(DEFAULT_FONT_SIZE);
		run3.setFontFamily(DEFAULT_FONT_STYLE);
		setCellProperties(cell3, false, ParagraphAlignment.LEFT);
	}

	private String formatInterestRateDetails(SanctionTermsConditionsDTO dto, ProposedSchemaDTO proposedSchemaDTO) {
		StringBuilder resultBuilder = new StringBuilder();
		String roi;
		String boldText = "";
		boolean is3MTBillBenchmark = dto.getBenchMark() != null && dto.getBenchMark().toLowerCase().contains("t-bill");
		boolean isRepoRate = dto.getBenchMark() != null && dto.getBenchMark().toLowerCase().contains("repo");
		String benchMark = dto.getBenchMark();
		// Build the initial interest rate text
		if (benchMark != null && !benchMark.isBlank()) {
			if (benchMark.toUpperCase().contains("REPO RATE")) {
				benchMark = "RBI Repo rate";
			}
			if (dto.getSpread() != null && !dto.getSpread().isBlank()) {
				boldText = benchMark + " + " + dto.getSpread() + " bps.";
			} else {
				boldText = benchMark;
			}
		} else {
			roi = dto.getTsRAteInterest() != null ? formatRoi(dto.getTsRAteInterest()) : "";
			if (StringUtils.hasText(roi)) {
				boldText = roi + " % p.a (" + CurrencyConverter.convert(new BigDecimal(roi), "Roi") + " per annum.)";
			}
		}
		// Start building the complete text
		resultBuilder.append("Interest will be charged @ ").append(boldText);
		// Add repo rate specific details
		if (benchMark != null && benchMark.toLowerCase().contains("repo") && proposedSchemaDTO != null
				&& proposedSchemaDTO.getRoiNote() != null && !proposedSchemaDTO.getRoiNote().isBlank()) {
			resultBuilder.append(" (").append(proposedSchemaDTO.getRoiNote().trim()).append(")");
			// Extract and add rate if present
			String regex = "(\\d+\\.\\d+)% p\\.a\\.";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(proposedSchemaDTO.getRoiNote());
			if (matcher.find()) {
				String extractedRate = matcher.group(1);
				resultBuilder.append(" (").append(CurrencyConverter.convert(new BigDecimal(extractedRate), "Roi"))
						.append(" per annum).");
			}
			// Add spread information
			if (dto.getSpread() != null && !dto.getSpread().isBlank()) {
				resultBuilder.append(
						"\nRBI Repo to be on actuals, i.e., Repo will change as and when the same is changed by RBI. ")
						.append("(Spread of ").append(dto.getSpread()).append(" bps will remain unchanged).\n\n");
			}
		}
		// Add repayment details
		if (dto.getTsRoiRepayment() != null && !dto.getTsRoiRepayment().isBlank()) {
			resultBuilder.append("\n").append(dto.getTsRoiRepayment());
		}
		// Add benchmark specific notes
		if (is3MTBillBenchmark) {
			if (dto.getInterestResetNote() != null && !dto.getInterestResetNote().isBlank()) {
				resultBuilder.append("\nInterest Reset: ").append(dto.getInterestResetNote());
			}
			if (dto.getBenchMarkNote() != null && !dto.getBenchMarkNote().isBlank()) {
				resultBuilder.append("\nBenchmark: ").append(dto.getBenchMarkNote());
			}
		} else if (isRepoRate) {
			if (dto.getInterestResetNote() != null && !dto.getInterestResetNote().isBlank()) {
				resultBuilder.append("\nReset of interest rate: ").append(dto.getInterestResetNote());
			}
		} else {
			if (proposedSchemaDTO != null && StringUtils.hasText(proposedSchemaDTO.getInterestReset())
					&& StringUtils.hasText(dto.getInterestResetNote())) {
				resultBuilder.append("\nInterest Reset: ").append(dto.getInterestResetNote());
			}
		}
		return resultBuilder.toString();
	}

	private String formatRoi(BigDecimal roi) {
		if (roi.scale() > 0) {
			return roi.setScale(2, RoundingMode.HALF_UP).toPlainString();
		}
		return roi.toPlainString();
	}

	private void setTableColumnWidths(XWPFTable table, int[] widths) {
		CTTbl ctTbl = table.getCTTbl();
		CTTblGrid tblGrid = ctTbl.getTblGrid();
		if (tblGrid == null) {
			tblGrid = ctTbl.addNewTblGrid();
		}
		table.setWidth("100%");
		for (int i = 0; i < widths.length; i++) {
			CTTblGridCol gridCol = tblGrid.addNewGridCol();
			gridCol.setW(BigInteger.valueOf(widths[i]));
			XWPFTableRow row = table.getRow(0);
			if (row != null) {
				XWPFTableCell cell = row.getCell(i);
				if (cell != null) {
					cell.setWidth(String.valueOf(widths[i]));
				}
			}
		}
	}

	private void addTableRowWithFormatExtended(XWPFTable table, String number, String label,
			SanctionTermsConditionsDTO dto) {
		StringBuilder tenureText = new StringBuilder();
		if (dto.getTsTenurePeriod() != null) {
			tenureText.append("Tenure: ").append(dto.getTsTenurePeriod().intValue()).append(" months");
			if (dto.getTsTenureApprox() != null && !dto.getTsTenureApprox().isBlank()) {
				tenureText.append(" ").append(dto.getTsTenureApprox());
			}
		}
		String repaymentText = "";
		if (dto.getTsTenureWd() != null && !dto.getTsTenureWd().isBlank()) {
			repaymentText = dto.getTsTenureWd();
		}
		XWPFTableRow row = table.createRow();
		XWPFTableCell cell1 = row.getCell(0);
		XWPFTableCell cell2 = row.getCell(1);
		XWPFTableCell cell3 = row.getCell(2);
		XWPFParagraph para1 = cell1.getParagraphArray(0);
		if (para1 == null) {
			para1 = cell1.addParagraph();
		}
		XWPFRun run1 = para1.createRun();
		run1.setText(number);
		run1.setFontSize(DEFAULT_FONT_SIZE);
		run1.setFontFamily(DEFAULT_FONT_STYLE);
		setCellProperties(cell1, true, ParagraphAlignment.CENTER);
		para1.setAlignment(ParagraphAlignment.CENTER);
		XWPFParagraph para2 = cell2.getParagraphArray(0);
		if (para2 == null) {
			para2 = cell2.addParagraph();
		}
		XWPFRun run2 = para2.createRun();
		String[] lines = label.split("\\n");
		for (int i = 0; i < lines.length; i++) {
			run2.setText(lines[i]);
			if (i < lines.length - 1) {
				run2.addBreak();
			}
		}
		run2.setFontSize(DEFAULT_FONT_SIZE);
		run2.setFontFamily(DEFAULT_FONT_STYLE);
		para2.setAlignment(ParagraphAlignment.LEFT);
		setCellProperties(cell2, true, ParagraphAlignment.LEFT);
		while (cell3.getParagraphs().size() > 0) {
			cell3.removeParagraph(0);
		}
		setCellMargins(cell3, 50, 20, 50, 50);
		if (tenureText.length() > 0) {
			XWPFParagraph tenurePara = cell3.addParagraph();
			XWPFRun tenureRun = tenurePara.createRun();
			tenureRun.setText(tenureText.toString());
			tenureRun.setFontSize(DEFAULT_FONT_SIZE);
			tenureRun.setFontFamily(DEFAULT_FONT_STYLE);
			tenurePara.setAlignment(ParagraphAlignment.BOTH);
		}
		createInnerTable(cell3, dto);
		if (!repaymentText.isEmpty()) {
			XWPFParagraph repaymentPara = cell3.addParagraph();
			XWPFRun repaymentRun = repaymentPara.createRun();
			repaymentRun.setText(repaymentText);
			repaymentRun.setFontSize(DEFAULT_FONT_SIZE);
			repaymentRun.setFontFamily(DEFAULT_FONT_STYLE);
			repaymentPara.setAlignment(ParagraphAlignment.BOTH);
		}
	}

	private XWPFTable createInnerTable(XWPFTableCell parentCell, SanctionTermsConditionsDTO dto) {
		XWPFTable innerTable = parentCell
				.insertNewTbl(parentCell.getParagraphArray(parentCell.getParagraphs().size() - 1).getCTP().newCursor());
		CTTbl ctTbl = innerTable.getCTTbl();
		CTTblPr tblPr = ctTbl.addNewTblPr();
		CTTblWidth tblWidth = tblPr.addNewTblW();
		tblWidth.setW(BigInteger.valueOf(5000));
		tblWidth.setType(STTblWidth.PCT);
		CTTblBorders borders = tblPr.isSetTblBorders() ? tblPr.getTblBorders() : tblPr.addNewTblBorders();
		addTableBorder(borders.addNewTop(), STBorder.SINGLE, 8, COLOR);
		addTableBorder(borders.addNewBottom(), STBorder.SINGLE, 4, COLOR);
		addTableBorder(borders.addNewLeft(), STBorder.SINGLE, 4, COLOR);
		addTableBorder(borders.addNewRight(), STBorder.SINGLE, 4, COLOR);
		addTableBorder(borders.addNewInsideH(), STBorder.SINGLE, 4, COLOR);
		addTableBorder(borders.addNewInsideV(), STBorder.SINGLE, 4, COLOR);
		XWPFTableRow headerRow = innerTable.getRow(0);
		if (headerRow == null) {
			headerRow = innerTable.createRow();
		}
		createAndStyleHeaderCell(headerRow, 0, "Principal Repayment");
		createAndStyleHeaderCell(headerRow, 1, "Interest Payment");
		XWPFTableRow contentRow = innerTable.createRow();
		createAndStyleContentCell(contentRow, 0,
				dto.getTsPrincipalRepayment() != null ? dto.getTsPrincipalRepayment() : "");
		createAndStyleContentCell(contentRow, 1, dto.getTsIntrestPayment() != null ? dto.getTsIntrestPayment() : "");
		return innerTable;
	}

	private void addTableBorder(CTBorder border, STBorder.Enum type, int size, String color) {
		border.setVal(type);
		border.setSz(BigInteger.valueOf(size));
		border.setSpace(BigInteger.valueOf(0));
		border.setColor(color);
	}

	private void createAndStyleHeaderCell(XWPFTableRow row, int pos, String text) {
		XWPFTableCell cell = row.getCell(pos);
		if (cell == null) {
			cell = row.createCell();
		}
		while (cell.getParagraphs().size() > 0) {
			cell.removeParagraph(0);
		}
		setCellMargins(cell, 50, 20, 20, 20);
		XWPFParagraph para = cell.addParagraph();
		para.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun run = para.createRun();
		run.setText(text);
		run.setBold(true);
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setFontFamily(DEFAULT_FONT_STYLE);
		cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
		CTTcPr tcPr = cell.getCTTc().addNewTcPr();
		CTTblWidth cellWidth = tcPr.addNewTcW();
		cellWidth.setType(STTblWidth.PCT);
		cellWidth.setW(BigInteger.valueOf(2500));
	}

	private void createAndStyleContentCell(XWPFTableRow row, int pos, String content) {
		XWPFTableCell cell = row.getCell(pos);
		if (cell == null) {
			cell = row.createCell();
		}
		while (cell.getParagraphs().size() > 0) {
			cell.removeParagraph(0);
		}
		setCellMargins(cell, 200, 200, 200, 200);
		XWPFParagraph para = cell.addParagraph();
		para.setAlignment(ParagraphAlignment.BOTH);
		XWPFRun run = para.createRun();
		run.setText(content);
		run.setFontSize(DEFAULT_FONT_SIZE);
		run.setFontFamily(DEFAULT_FONT_STYLE);
		cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
		CTTcPr tcPr = cell.getCTTc().addNewTcPr();
		CTTblWidth cellWidth = tcPr.addNewTcW();
		cellWidth.setType(STTblWidth.PCT);
		cellWidth.setW(BigInteger.valueOf(2500));
	}

	private void setCellMargins(XWPFTableCell cell, int top, int right, int bottom, int left) {
		CTTcPr tcPr = cell.getCTTc().isSetTcPr() ? cell.getCTTc().getTcPr() : cell.getCTTc().addNewTcPr();
		CTTcMar tcMar = tcPr.isSetTcMar() ? tcPr.getTcMar() : tcPr.addNewTcMar();
		CTTblWidth topMargin = tcMar.isSetTop() ? tcMar.getTop() : tcMar.addNewTop();
		topMargin.setType(STTblWidth.DXA);
		topMargin.setW(BigInteger.valueOf(top));
		CTTblWidth rightMargin = tcMar.isSetRight() ? tcMar.getRight() : tcMar.addNewRight();
		rightMargin.setType(STTblWidth.DXA);
		rightMargin.setW(BigInteger.valueOf(right));
		CTTblWidth bottomMargin = tcMar.isSetBottom() ? tcMar.getBottom() : tcMar.addNewBottom();
		bottomMargin.setType(STTblWidth.DXA);
		bottomMargin.setW(BigInteger.valueOf(bottom));
		CTTblWidth leftMargin = tcMar.isSetLeft() ? tcMar.getLeft() : tcMar.addNewLeft();
		leftMargin.setType(STTblWidth.DXA);
		leftMargin.setW(BigInteger.valueOf(left));
	}

	private void addTableRowWithForOtherConditions(XWPFTable table, String number, String label, String tsOtherCond) {
		// Create main row
		XWPFTableRow row = table.createRow();
		// Set up cells
		XWPFTableCell cell1 = row.getCell(0); // Number cell
		XWPFTableCell cell2 = row.getCell(1); // Label cell
		XWPFTableCell cell3 = row.getCell(2); // Content cell
		// Style Number cell (Column 1) with gray background
		XWPFParagraph para1 = cell1.getParagraphArray(0);
		if (para1 == null) {
			para1 = cell1.addParagraph();
		}
		XWPFRun run1 = para1.createRun();
		run1.setText(number);
		run1.setFontSize(DEFAULT_FONT_SIZE);
		run1.setFontFamily(DEFAULT_FONT_STYLE);
		para1.setAlignment(ParagraphAlignment.CENTER);
		setCellProperties(cell1, true, ParagraphAlignment.LEFT);
		// Style Label cell (Column 2) with gray background
		XWPFParagraph para2 = cell2.getParagraphArray(0);
		if (para2 == null) {
			para2 = cell2.addParagraph();
		}
		XWPFRun run2 = para2.createRun();
		run2.setText(label);
		run2.setFontSize(DEFAULT_FONT_SIZE);
		run2.setFontFamily(DEFAULT_FONT_STYLE);
		para2.setAlignment(ParagraphAlignment.LEFT);
		setCellProperties(cell2, true, ParagraphAlignment.LEFT);
		// Content cell (Column 3)
		// Clear any existing content
		while (cell3.getParagraphs().size() > 0) {
			cell3.removeParagraph(0);
		}
		// Process conditions
		List<Long> conditionNumbers = new ArrayList<>();

		if (tsOtherCond != null && !tsOtherCond.isBlank()) {
			String[] tokens = tsOtherCond.split(",");
			for (String token : tokens) {
				String trimmed = token.trim();
				if (!trimmed.isEmpty()) {
					try {
						conditionNumbers.add(Long.parseLong(trimmed));
					} catch (NumberFormatException nfe) {
					}
				}
			}
		}
		// Get conditions from master repository
		List<String> conditions = masterRepositoryData.stream().filter(e -> conditionNumbers.contains(e.getMstCode()))
				.map(MasterRepositoryDTO::getMstRemarks).collect(Collectors.toList());
		// Add conditions to cell3
		int srNo = 1;
		for (String condition : conditions) {
			XWPFParagraph condPara = cell3.addParagraph();
			XWPFRun condRun = condPara.createRun();
			condRun.setText(srNo + ".  " + condition);
			condRun.setFontSize(DEFAULT_FONT_SIZE);
			condRun.setFontFamily(DEFAULT_FONT_STYLE);
			condPara.setAlignment(ParagraphAlignment.BOTH);
			// Add spacing after each condition
			condPara.setSpacingAfter(240); // 12 points
			srNo++;
		}
	}

}
