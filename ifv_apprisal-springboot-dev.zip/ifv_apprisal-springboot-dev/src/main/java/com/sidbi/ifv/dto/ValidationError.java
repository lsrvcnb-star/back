package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValidationError {
	private int rowNumber;
	private String fieldName;
	private String errorMessage;
	private String fieldValue;
}
