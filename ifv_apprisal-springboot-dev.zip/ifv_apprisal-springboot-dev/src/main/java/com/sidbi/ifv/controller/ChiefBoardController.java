package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ChiefBoardDTO;
import com.sidbi.ifv.services.ChiefBoardService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcchboard")
public class ChiefBoardController {
	


	private static final Logger logger = LoggerFactory.getLogger(ChiefBoardController.class);

	@Autowired
	private ChiefBoardService s2ifccChiefBoardService;
	
	@GetMapping("/get/{id}")
	public ResponseEntity<ChiefBoardDTO> findById(@PathVariable Long id) {
		logger.info("findById() started ChiefBoardController {} ",id);
		ChiefBoardDTO s2ifccPrincipalDTO = s2ifccChiefBoardService.findById(id);
		return ResponseEntity.ok(s2ifccPrincipalDTO);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<ChiefBoardDTO>> findAll() {
		logger.info("findAll() started ChiefBoardController ");
		List<ChiefBoardDTO> list = s2ifccChiefBoardService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<ChiefBoardDTO> save(@RequestBody ChiefBoardDTO s2ifccChiefBoardDTO) {
		logger.info("save() started ChiefBoardController {} ",s2ifccChiefBoardDTO);
		ChiefBoardDTO savedS2ifccChiefBoardDTO = s2ifccChiefBoardService.save(s2ifccChiefBoardDTO);
        return ResponseEntity.ok(savedS2ifccChiefBoardDTO);
    }
	
	@PostMapping("/saveAll")
	public ResponseEntity<List<ChiefBoardDTO>> saveAll(@RequestBody List<ChiefBoardDTO> listChiefBoardDTO) {
		logger.info("saveAll() started in ChiefBoardController ");
		List<ChiefBoardDTO> savedChiefBoardDTOs = s2ifccChiefBoardService.saveAll(listChiefBoardDTO);
		return ResponseEntity.ok(savedChiefBoardDTOs);
	}
	
    @PutMapping("/update/{id}")
    public ResponseEntity<ChiefBoardDTO> update(@PathVariable Long id,
                                                               @RequestBody ChiefBoardDTO s2ifccChiefBoardDTO) {
    	logger.info("update() started ChiefBoardController {} ",s2ifccChiefBoardDTO);
    	ChiefBoardDTO updatedS2ifccChiefBoardDTO = s2ifccChiefBoardService.update(id, s2ifccChiefBoardDTO);
        return ResponseEntity.ok(updatedS2ifccChiefBoardDTO);
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
    	logger.info("delete() started ChiefBoardController {} ",id);
    	s2ifccChiefBoardService.delete(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/getAllOnIfvId/{ifvId}")
	 public ResponseEntity<List<ChiefBoardDTO>> getAllChiefBoardEntityOnIfvId(@PathVariable Long ifvId) {
		 logger.info("getAllChiefBoardEntityOnIfvId() started in ChiefBoardController ");
		 List<ChiefBoardDTO> chiefBoardDTOs = s2ifccChiefBoardService.findAllByIfvId(ifvId);
		 return ResponseEntity.ok(chiefBoardDTOs);
	 }

}
