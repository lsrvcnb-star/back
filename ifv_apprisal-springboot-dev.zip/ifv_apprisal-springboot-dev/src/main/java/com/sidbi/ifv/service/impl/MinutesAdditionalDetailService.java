package com.sidbi.ifv.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sidbi.ifv.dto.MinutesColendingLimitDTO;
import com.sidbi.ifv.dto.MinutesInterestResetDTO;
import com.sidbi.ifv.dto.MinutesOtherItemsDTO;
import com.sidbi.ifv.entity.MinutesColendingLimit;
import com.sidbi.ifv.entity.MinutesInterestReset;
import com.sidbi.ifv.entity.MinutesOtherItems;
import com.sidbi.ifv.repo.MinutesColendingLimitRepository;
import com.sidbi.ifv.repo.MinutesInterestResetRepository;
import com.sidbi.ifv.repo.MinutesOtherItemsRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MinutesAdditionalDetailService {

	private final MinutesColendingLimitRepository repository;
	private final MinutesInterestResetRepository interestResetRepository;
	private final MinutesOtherItemsRepository otherItemsRepository;
	private final ModelMapper modelMapper;

	@Transactional
	public void saveColendingLimits(Integer minuteSanctionId, List<MinutesColendingLimitDTO> limits) {

		repository.deleteByMinuteSanctionId(minuteSanctionId);

		List<MinutesColendingLimit> entities = limits.stream().map(dto -> {
			MinutesColendingLimit entity = modelMapper.map(dto, MinutesColendingLimit.class);

			entity.setId(null);
			entity.setMinuteSanctionId(minuteSanctionId);
			entity.setCreatedDate(LocalDate.now());

			return entity;
		}).toList();

		repository.saveAll(entities);
	}

	@Transactional
	public void deleteById(Long id) {
		repository.deleteById(id);
	}

	public List<MinutesColendingLimitDTO> getByMinuteSanctionId(Integer minuteSanctionId) {

		return repository.findByMinuteSanctionId(minuteSanctionId).stream()
				.map(entity -> modelMapper.map(entity, MinutesColendingLimitDTO.class)).toList();
	}

	@Transactional
	public void saveInterestResets(Integer minuteSanctionId, List<MinutesInterestResetDTO> dtos) {

		interestResetRepository.deleteByMinuteSanctionId(minuteSanctionId);

		List<MinutesInterestReset> entities = dtos.stream().map(dto -> {
			MinutesInterestReset entity = modelMapper.map(dto, MinutesInterestReset.class);

			entity.setId(null);
			entity.setMinuteSanctionId(minuteSanctionId);
			entity.setCreatedDate(LocalDate.now());

			return entity;
		}).toList();

		interestResetRepository.saveAll(entities);
	}

	public List<MinutesInterestResetDTO> getInterestResetsByMinuteSanctionId(Integer minuteSanctionId) {
		return interestResetRepository.findByMinuteSanctionId(minuteSanctionId).stream()
				.map(entity -> modelMapper.map(entity, MinutesInterestResetDTO.class)).toList();
	}

	public void deleteInterestResetsById(Long id) {
		interestResetRepository.deleteById(id);
	}

	@Transactional
	public void saveOtherItems(Integer minuteSanctionId, List<MinutesOtherItemsDTO> dtos) {

		otherItemsRepository.deleteByMinuteSanctionId(minuteSanctionId);

		List<MinutesOtherItems> entities = dtos.stream().map(dto -> {
			MinutesOtherItems entity = modelMapper.map(dto, MinutesOtherItems.class);
			entity.setId(null);
			entity.setMinuteSanctionId(minuteSanctionId);
			entity.setCreatedDate(LocalDate.now());
			return entity;
		}).toList();

		otherItemsRepository.saveAll(entities);
	}

	public List<MinutesOtherItemsDTO> fetchOtherItems(Integer minuteSanctionId) {
		return otherItemsRepository.findByMinuteSanctionId(minuteSanctionId).stream()
				.map(e -> modelMapper.map(e, MinutesOtherItemsDTO.class)).toList();
	}

	public void deleteOtherItemsById(Long id) {
		otherItemsRepository.deleteById(id);
	}

}
