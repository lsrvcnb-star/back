package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVAssPastdisbEntity;

public interface AssPastdisbRepository extends JpaRepository<S2IFVAssPastdisbEntity, Long>{

	List<S2IFVAssPastdisbEntity> findByIfvId(Long ifvId);
	
	List<S2IFVAssPastdisbEntity> findByIfvIdOrderByAeId(Long ifvId);

	void deleteByIfvId(Long ifvId);
	

}
