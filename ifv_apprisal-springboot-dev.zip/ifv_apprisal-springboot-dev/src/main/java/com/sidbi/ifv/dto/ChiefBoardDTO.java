package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class ChiefBoardDTO {

	private Long cbId;

	private Long ifvId;

	private String cbName;

	private String cbDesignation;

	private String cbRemarks;

	private String cbType;

}
