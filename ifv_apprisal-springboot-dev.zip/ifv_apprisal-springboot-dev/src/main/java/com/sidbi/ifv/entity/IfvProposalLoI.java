package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ifv_proposals_loi")
public class IfvProposalLoI {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "ifv_name")
	private String ifvName;

	@Column(name = "app_number")
	private String appNumber;

	@Column(name = "pr_ids")
	private String prIds;

	@Column(name = "loi_no")
	private String loiNo;

	@Column(name = "loi_date")
	private Date loiDate;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "amount_in_words")
	private String amountInWords;

	@Column(name = "fund_name")
	private String fundName;

	@Column(name = "scheme_name")
	private String schemeName;

	@Column(name = "ifv_app_dated")
	private Date ifvAppDated;

	@Column(name = "header_note")
	private String headerNote;

	@Column(name = "address_of_the_bank")
	private String addressOfTheBank;

	@Column(name = "note1")
	private String note1;

	@Column(name = "note2")
	private String note2;

	@Column(name = "note2_subnote1")
	private String note2Subnote1;

	@Column(name = "note2_subnote2")
	private String note2Subnote2;

	@Column(name = "note3")
	private String note3;

	@Column(name = "loi_user")
	private Integer loiUser;

	@Column(name = "name_of_documents")
	private String nameOfDocuments;

	@Column(name = "document_dated")
	private Date documentDated;

	@Column(name = "section_or_clause_no")
	private String sectionOrClauseNo;

	@Column(name = "section_mode")
	private String sectionMode;

	@Column(name = "kyc_documents")
	private String kycDocuments;
}
