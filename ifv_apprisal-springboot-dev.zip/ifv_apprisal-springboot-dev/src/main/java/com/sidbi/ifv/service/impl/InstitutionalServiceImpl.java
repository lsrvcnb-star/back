package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.InstitutionalDTO;
import com.sidbi.ifv.entity.S2IFVInstitutionalEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.InstitutionalRepository;
import com.sidbi.ifv.services.InstitutionalService;

@Service
public class InstitutionalServiceImpl implements InstitutionalService {

	private static final Logger logger = LoggerFactory.getLogger(InstitutionalServiceImpl.class);
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private InstitutionalRepository institutionalRepo;
	
	String msg = "";

	@Override
	public List<InstitutionalDTO> findAll() {
		logger.info("findAll() started in InstitutionalServiceImpl for S2IFVInstitutionalEntity");
		try {
			List<S2IFVInstitutionalEntity> list = institutionalRepo.findAll();
			return list.stream().map(s -> modelMapper.map(s, InstitutionalDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVInstitutionalEntity entities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching all S2IFVInstitutionalEntity entities."+msg+" ", e);
		}
	}

	@Override
	public InstitutionalDTO findById(Long id) {
		logger.info("findById() started in InstitutionalServiceImpl for S2IFVInstitutionalEntity");
		try {
			S2IFVInstitutionalEntity institutionalEntity = institutionalRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVInstitutionalEntity", id));
			return modelMapper.map(institutionalEntity, InstitutionalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching S2IFVInstitutionalEntity entities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching S2IFVInstitutionalEntity entities."+msg+" ", e);
		}
	}

	@Override
	public InstitutionalDTO save(InstitutionalDTO institutionalDTO) {
		logger.info("save() started in InstitutionalServiceImpl for S2IFVInstitutionalEntity");
		try {
			S2IFVInstitutionalEntity institutionalEntity = modelMapper.map(institutionalDTO, S2IFVInstitutionalEntity.class);
			institutionalRepo.save(institutionalEntity);
			return modelMapper.map(institutionalEntity, InstitutionalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while saving S2IFVInstitutionalEntity entities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while saving S2IFVInstitutionalEntity entities."+msg+" ", e);
		}
	}

	@Override
	public InstitutionalDTO update(Long id, InstitutionalDTO institutionalDTO) {
		logger.info("update() started in InstitutionalServiceImpl for S2IFVInstitutionalEntity");
		try {
			S2IFVInstitutionalEntity existinginstitutional= institutionalRepo.findById(id).

					orElseThrow(() -> new EntityNotFoundException("S2IFVInstitutionalEntity", id));
			BeanUtils.copyProperties(institutionalDTO, existinginstitutional);
			institutionalRepo.save(existinginstitutional);
			return modelMapper.map(institutionalDTO, InstitutionalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching S2IFVInstitutionalEntity entities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while fetching S2IFVInstitutionalEntity entities."+msg+" ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in InstitutionalServiceImpl for S2IFVInstitutionalEntity");
		try {
			S2IFVInstitutionalEntity institutionalEntity = institutionalRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVInstitutionalEntity", id));
			institutionalRepo.delete(institutionalEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleteing S2IFVInstitutionalEntity entity. {} ",msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleteing S2IFVInstitutionalEntity entity of id ." + id + " "+msg+ " ", e);

		}
	}

	@Override
	public List<InstitutionalDTO> saveAll(List<InstitutionalDTO> listInstitutionalDTO) {
		logger.info("saveAll() started in InstitutionalServiceImpl for List of S2IFVInstitutionalEntity");
		try {
			List<S2IFVInstitutionalEntity> institutionalEntitiesToSave = listInstitutionalDTO.stream()
					.map(institutionalDTO -> modelMapper.map(institutionalDTO, S2IFVInstitutionalEntity.class)).collect(Collectors.toList());
			List<S2IFVInstitutionalEntity> savedInstitutionalEntities = institutionalRepo.saveAll(institutionalEntitiesToSave);

			return savedInstitutionalEntities.stream().map(institutionalEntity -> modelMapper.map(institutionalEntity, InstitutionalDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVInstitutionalEntities. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while Saving all S2IFVInstitutionalEntities."+msg+" ", e);
		}
	}

	@Override
	public List<InstitutionalDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in InstitutionalServiceImpl ");
		try {
			List<S2IFVInstitutionalEntity> listInstitutionalEntities = institutionalRepo.findByIfvId(ifvId);
			return listInstitutionalEntities.stream().map(institutionalEntitiy -> modelMapper.map(institutionalEntitiy, InstitutionalDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVInstitutionalEntities based on IfvId. {} ",msg);
			throw new DatabaseOperationException("Error Occurred while Finding all S2IFVInstitutionalEntities  based on IfvId."+ifvId+" "+msg+" ", e);

		}
	}

}
