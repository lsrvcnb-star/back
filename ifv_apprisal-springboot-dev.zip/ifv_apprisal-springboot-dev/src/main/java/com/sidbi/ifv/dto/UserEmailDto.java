package com.sidbi.ifv.dto;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserEmailDto {

	private Set<String> toEmailIds;

	private Set<String> ccEmailIds;

	private Set<String> bccEmailIds;

}
