package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class AssistanceAppliedForDto {

	private Long id;

	private Long ifvId;

	private Long prId;

	private String schemeName;

	private String schemeCode;

	private String fundName;

	private String fundCode;

	private BigDecimal amount;

	private Date videDate;
}
