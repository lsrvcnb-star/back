package com.sidbi.ifv.dto;

import java.time.Instant;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class ComplianceStatusSummaryRequest {

	@Min(value = 0, message = "Page must be >= 0")
	private int page = 0;

	@Min(value = 1, message = "Size must be >= 1")
	@Max(value = 100, message = "Size must be <= 100")
	private int size = 10;

	@Pattern(regexp = "^[a-zA-Z0-9 .,_\\-/]{0,255}$", message = "Global filter contains invalid characters")
	private String globalFilter;

	// Example: SIDBI/REF/2026/00002
	@Pattern(regexp = "^[A-Za-z0-9/_-]{0,100}$", message = "Reference number contains invalid characters")
	private String appRefNo;

	@Pattern(regexp = "^(Balance Confirmation Certificate|MSME Portfolio Certificate|Adequacy Certificate)?$", message = "Invalid Compliance")
	private String complianceType;

	@Pattern(regexp = "^(PENDING|SUBMITTED|COMPLETED|OVERDUE|RETURNED)?$", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid status")
	private String status;

	private Instant uploadDateTimeFrom;

	private Instant uploadDateTimeTo;

	@Pattern(regexp = "^(id|appRefId|complianceType|status|uploadDate|dueDate|asOnDate)?$", message = "Invalid sort field")
	private String sortField = "uploadDate";

	@Pattern(regexp = "^(asc|desc)$", flags = Pattern.Flag.CASE_INSENSITIVE, message = "sortDirection must be asc or desc")
	private String sortDirection = "desc";

}
