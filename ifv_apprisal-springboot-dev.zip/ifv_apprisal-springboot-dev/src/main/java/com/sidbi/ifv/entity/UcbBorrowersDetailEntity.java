package com.sidbi.ifv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ucb_borrowers_details")
public class UcbBorrowersDetailEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "tot_borrowers")
	private Integer totBorrowers;

	@Column(name = "tot_msme_customers")
	private Integer totMsmeCustomers;

	@Column(name = "tot_corp_borrowers")
	private Integer totCorpBorrowers;

	@Column(name = "remarks")
	private String remarks;
}
