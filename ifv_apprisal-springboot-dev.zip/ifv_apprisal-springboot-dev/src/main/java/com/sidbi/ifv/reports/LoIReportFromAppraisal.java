package com.sidbi.ifv.reports;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.MalformedURLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StringUtils;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPCellEvent;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import com.sidbi.ifv.dto.IfvProposalLoIDto;
import com.sidbi.ifv.dto.MasterRepositoryDTO;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.dto.SanctionTermsConditionsDTO;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.CurrencyConverter;
import com.sidbi.ifv.util.FontFirstClass;

public class LoIReportFromAppraisal {

	private static final Logger logger = LoggerFactory.getLogger(LoIReportFromAppraisal.class);

	FontFirstClass fontFirstClass = new FontFirstClass();

	Font paragraphFont = FontFactory.getFont(FontFactory.HELVETICA, 10.5f, Font.NORMAL);
	Font headLineFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10.5f);
	Font underlineFont = FontFactory.getFont(FontFactory.HELVETICA, 10.5f, Font.BOLD | Font.UNDERLINE);
	Font paragraphItalic = FontFactory.getFont(FontFactory.HELVETICA, 10.5f, Font.ITALIC);

	Font hindiFont = fontFirstClass.getHindiFont();
	Font hindiFontBoldUnderline = fontFirstClass.getHindiFontBoldUnderline();
	Font hindiFontBold = fontFirstClass.getHindiFontBold();

	Chunk pSpace = new Chunk("\r");
	Font rupeeFont = fontFirstClass.fontForRupeesSymbol();

	private List<MasterRepositoryDTO> masterRepositoryData;

	private IfvProposalLoIDto ifvProposalLoIDto;

	private List<SanctionTermsConditionsDTO> sanctionTermsConditionsDTOs;

	private List<ProposedSchemaDTO> proposedSchemaDetails;

	private String userName;

	private String designation;

	public LoIReportFromAppraisal(IfvProposalLoIDto ifvProposalLoIDto,
			List<SanctionTermsConditionsDTO> sanctionTermsConditionsDTOs,
			List<MasterRepositoryDTO> masterRepositoryData, List<ProposedSchemaDTO> proposedSchemaDetails,
			String userName, String designation) {
		this.ifvProposalLoIDto = ifvProposalLoIDto;
		this.sanctionTermsConditionsDTOs = sanctionTermsConditionsDTOs;
		this.masterRepositoryData = masterRepositoryData;
		this.proposedSchemaDetails = proposedSchemaDetails;
		this.userName = userName;
		this.designation = designation;
	}

	public byte[] generatePdfData() throws DocumentException, MalformedURLException, IOException {
		Document document = new Document(PageSize.A4);
		float baseMargin = 72; // 2.54 cm in points
		document.setMargins(baseMargin, baseMargin, 75, baseMargin);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, outputStream);

		writer.setPageEvent(new FooterPageEvent());

		document.open();

		Paragraph p1 = new Paragraph();
		p1.setAlignment(Element.ALIGN_CENTER);
		p1.add(Chunk.NEWLINE);
		p1.setSpacingAfter(15);

		Phrase combinedPhrase = new Phrase();
		combinedPhrase.add(new Chunk("nks çfr;ksa esa", hindiFontBoldUnderline));
		combinedPhrase.add(new Chunk(" / In Duplicate", underlineFont));
		p1.add(combinedPhrase);
		p1.add(Chunk.NEWLINE);
		p1.add(Chunk.NEWLINE);

		PdfPTable table1 = new PdfPTable(2);
		table1.setWidthPercentage(100);
		table1.setWidths(new float[] { 75, 25 });

		LocalDate localDate = ifvProposalLoIDto.getLoiDate().toInstant().atZone(java.time.ZoneId.systemDefault())
				.toLocalDate();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
		String formattedDate = localDate.format(formatter);

		combinedPhrase = new Phrase();
		combinedPhrase.add(new Chunk("flMch%vkÃ,Qoh la", hindiFont));
		combinedPhrase.add(new Chunk(". " + ifvProposalLoIDto.getLoiNo(), paragraphFont));

		PdfPCell leftCell = new PdfPCell(combinedPhrase);
		leftCell.setHorizontalAlignment(Element.ALIGN_LEFT);
		leftCell.setBorder(Rectangle.NO_BORDER);
		table1.addCell(leftCell);

		String monthName = localDate.getMonth().toString();
		String monthNameInHindi = getMonthInHindi(monthName);
		String dayString = String.valueOf(localDate.getDayOfMonth());
		String yearString = String.valueOf(localDate.getYear());

		combinedPhrase = new Phrase();
		combinedPhrase.add(new Chunk(dayString + " ", paragraphFont));
		combinedPhrase.add(new Chunk(monthNameInHindi, hindiFont));
		combinedPhrase.add(new Chunk(", " + yearString, paragraphFont));

		PdfPCell rightCell = new PdfPCell(combinedPhrase);
		rightCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		rightCell.setBorder(Rectangle.NO_BORDER);
		table1.addCell(rightCell);

		leftCell = new PdfPCell(new Paragraph("SIDBI: IFV: No. " + ifvProposalLoIDto.getLoiNo(), paragraphFont));
		leftCell.setHorizontalAlignment(Element.ALIGN_LEFT);
		leftCell.setBorder(Rectangle.NO_BORDER);
		table1.addCell(leftCell);

		rightCell = new PdfPCell(new Paragraph(formattedDate, paragraphFont));
		rightCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		rightCell.setBorder(Rectangle.NO_BORDER);
		table1.addCell(rightCell);

		Paragraph p2 = new Paragraph();
		p2.setAlignment(Element.ALIGN_LEFT);
		p2.add(Chunk.NEWLINE);

		String mulLine = """
				To,
				%s
				""".formatted(ifvProposalLoIDto.getAddressOfTheBank());

		Phrase chunk2 = new Phrase(mulLine, paragraphFont);
		p2.add(chunk2);
		p2.setIndentationRight(250);

		Paragraph p3 = new Paragraph();
		p3.setAlignment(Element.ALIGN_LEFT);
		p3.add(Chunk.NEWLINE);
		p3.setSpacingAfter(10);

		combinedPhrase = new Phrase();
		combinedPhrase.add(new Chunk("fç; egksn;", hindiFont));
		combinedPhrase.add(new Chunk(" / Dear Sir,", paragraphFont));
		p3.add(combinedPhrase);

		Paragraph p4 = new Paragraph();
		p4.setAlignment(Element.ALIGN_CENTER);
		p4.setSpacingAfter(15);
		Phrase chunk4 = new Phrase(ifvProposalLoIDto.getHeaderNote(), underlineFont);
		p4.add(chunk4);

		document.add(p1);
		document.add(table1);
		document.add(p2);
		document.add(p3);
		document.add(p4);

		Chunk tabSpace = new Chunk(new String(new char[10]).replace('\0', ' ')); // 5 spaces, adjust as needed

		if (ifvProposalLoIDto.getNote1() != null && !ifvProposalLoIDto.getNote1().isBlank()) {
			Paragraph p = new Paragraph();

			String schemeName = ifvProposalLoIDto.getSchemeName();

			combinedPhrase = new Phrase();
			combinedPhrase.add(new Chunk(tabSpace + "  " + schemeName + " ", paragraphFont));
			combinedPhrase.add(new Chunk(";kstuk ds varxZr iquÆoÙk dh eatwjh ls lacafèkr fnukad", hindiFont));

			// Pattern to match dates in format "Month DD, YYYY"
			Pattern pattern = Pattern.compile(
					"(January|February|March|April|May|June|July|August|September|October|November|December)\\s+(\\d{1,2}),\\s+(\\d{4})");
			Matcher matcher = pattern.matcher(ifvProposalLoIDto.getNote1());
			if (matcher.find()) {
				String month = matcher.group(1);
				String day = matcher.group(2);
				String year = matcher.group(3);
				try {
					// Parse and format the date
					String dateStr = String.format("%s %s %s", day, month, year);

					combinedPhrase.add(new Chunk(" " + dateStr + " ", paragraphFont));

				} catch (DateTimeParseException e) {
					combinedPhrase.add(new Chunk(tabSpace + " " + tabSpace, paragraphFont));
				}
			} else {
				combinedPhrase.add(new Chunk(tabSpace + " " + tabSpace, paragraphFont));
			}

			combinedPhrase.add(new Chunk(
					"ds vius vkosnu dk lnHkZ ysa A ge lwfpr djrs gSa fd vki ds vuqjksèk ij fopkj fd;k x;k gS vkSj Hkkjrh; y?kq m|ksx fodkl cSad ¼flMch½ vki ds cSad dks ",
					hindiFont));
			Chunk rupeeChunk = new Chunk("Rupee", rupeeFont);
			combinedPhrase.add(rupeeChunk);

			combinedPhrase.add(new Chunk(""
					+ CommonUtil.formatNumber(ifvProposalLoIDto.getAmount().stripTrailingZeros().toPlainString()) + " ",
					paragraphFont));

			combinedPhrase.add(new Chunk("djksM+", hindiFont));

			combinedPhrase.add(new Chunk(" (" + ifvProposalLoIDto.getAmountInWords() + ") ", paragraphFont));

			combinedPhrase.add(new Chunk("flMch dh", hindiFont));
			combinedPhrase.add(new Chunk(" " + schemeName + " ", paragraphFont));
			combinedPhrase.add(new Chunk(
					";kstuk ds varxZr] vkids }kjk fu\"ikfnr lkekU; djkj ds rgr lger 'krks± vkSj fo'ks\"k :i ls fopkjkèkhu çLrko ds fy,",
					hindiFont));

			String annexures = "Annexure";
			if (sanctionTermsConditionsDTOs.size() > 1) {
				StringBuilder annexuresBuilder = new StringBuilder();
				for (int i = 1; i <= sanctionTermsConditionsDTOs.size(); i++) {
					annexuresBuilder.append("Annexure ").append(i);
					if (i < sanctionTermsConditionsDTOs.size()) {
						annexuresBuilder.append(" & ");
					}
				}
				annexures = annexuresBuilder.toString();
			}

			combinedPhrase.add(new Chunk(" " + annexures + " ", paragraphFont));
			combinedPhrase.add(new Chunk(
					"esa fofuÆn\"V fu;eksa vkSj 'krks± ij iquÆoÙk ds ekè;e ls foÙkh; lgk;rk çnku djus ds fy, lS)kafrd :i ls lger gSA",
					hindiFont));

			String finalNote1 = ifvProposalLoIDto.getNote1();
			String[] parts = finalNote1.split("(?i)Rs\\.");
			combinedPhrase.add(new Chunk("\n\n" + tabSpace + "  ", paragraphFont));
			combinedPhrase.add(new Chunk(parts[0], paragraphFont));
			if (parts.length > 1) {
				combinedPhrase.add(rupeeChunk);
				combinedPhrase.add(new Chunk(parts[1].trim(), paragraphFont));
			}

			p.add(combinedPhrase);

			p.setAlignment(Element.ALIGN_JUSTIFIED);
			p.setSpacingAfter(15);

			document.add(p);
		}

		if (ifvProposalLoIDto.getNote2() != null && !ifvProposalLoIDto.getNote2().isBlank()) {
			Paragraph p = new Paragraph();

			combinedPhrase = new Phrase();
			combinedPhrase.add(new Chunk("2. " + tabSpace, paragraphFont));
			combinedPhrase.add(new Chunk(
					";g vk'k; i= nks çfr;ksa esa tkjh fd;k tk jgk gSA ;fn ;s fu;e vkSj 'krs± vkids cSad dks Lohdk;Z gksa rks] vki —i;k vius cSad ds çkfèk—r vfèkdkjh }kjk fofèkor #i ls Loh—r bldh f}rh;d çfr gesa okil fHktok,¡A —i;k cSad ds eqgj ds lkFk bldh f}rh;d çfr ds çR;sd i`\"B ij gLrk{kj djsa vkSj bls djkj ds fy, visf{kr ewY; ds xSj&U;kf;d LVkEi isij ds lkFk layXu djsa] ftl ij çkfèk—r vfèkdkjh }kjk fuEukuqlkj leFkZu fd;k x;k gks%",
					hindiFont));
			combinedPhrase.add(new Chunk("\n\n" + tabSpace + " " + ifvProposalLoIDto.getNote2(), paragraphFont));
			p.add(combinedPhrase);
			p.setAlignment(Element.ALIGN_JUSTIFIED);
			p.setSpacingAfter(15);

			document.newPage();
			document.add(p);
		}

		Paragraph pSubNote1 = new Paragraph();
		Paragraph pSubNote2 = new Paragraph();
		boolean subNotePresent = false;

		if (ifvProposalLoIDto.getNote2Subnote1() != null && !ifvProposalLoIDto.getNote2Subnote1().isBlank()) {
			Phrase chunkNote = new Phrase(ifvProposalLoIDto.getNote2Subnote1(), headLineFont);
			pSubNote1.add(chunkNote);
			pSubNote1.setAlignment(Element.ALIGN_JUSTIFIED);
			pSubNote1.setSpacingAfter(15);
			subNotePresent = true;

		}

		if (ifvProposalLoIDto.getNote2Subnote2() != null && !ifvProposalLoIDto.getNote2Subnote2().isBlank()) {
			Phrase chunkNote = new Phrase(ifvProposalLoIDto.getNote2Subnote2(), headLineFont);
			pSubNote2.add(chunkNote);
			pSubNote2.setAlignment(Element.ALIGN_JUSTIFIED);
			pSubNote2.setSpacingAfter(15);

		}

		if (subNotePresent) {

			Paragraph pSubNote3 = new Paragraph();
			Phrase chunkNote3 = new Phrase("Name of the Document: ", headLineFont);
			Phrase chunkNote33 = new Phrase(
					ifvProposalLoIDto.getNameOfDocuments() != null ? ifvProposalLoIDto.getNameOfDocuments() : "",
					paragraphItalic);

			String formattedDate2;
			if (ifvProposalLoIDto.getDocumentDated() != null) {
				LocalDate localDate2 = ifvProposalLoIDto.getDocumentDated().toInstant()
						.atZone(java.time.ZoneId.systemDefault()).toLocalDate();
				formattedDate2 = localDate2.format(formatter);
			} else {
				formattedDate2 = "";
			}

			Phrase chunkNote333 = new Phrase("Dated: ", headLineFont);
			Phrase chunkNote333Val = new Phrase(formattedDate2, paragraphItalic);
			Phrase chunkNote3333 = new Phrase("Section / Clause No. & Page Number: ", headLineFont);
			Phrase chunkNote3333Val = new Phrase(
					ifvProposalLoIDto.getSectionOrClauseNo() != null ? ifvProposalLoIDto.getSectionOrClauseNo() : "",
					paragraphItalic);
			Phrase chunkNote33333 = new Phrase("Mode: ", headLineFont);
			Phrase chunkNote333333 = new Phrase(
					ifvProposalLoIDto.getSectionMode() != null ? ifvProposalLoIDto.getSectionMode() : "",
					paragraphItalic);
			Phrase chunkNoteKyc = new Phrase(
					"The following KYC documents of authorized signatories are attached (Any one).", headLineFont);

			String kyc = ifvProposalLoIDto.getKycDocuments() != null ? ifvProposalLoIDto.getKycDocuments() : "";

			Phrase chunkNoteKycDoc = new Phrase(tabSpace + kyc, paragraphItalic);
			pSubNote3.add(chunkNote3);
			pSubNote3.add(chunkNote33);
			pSubNote3.add(Chunk.NEWLINE);
			pSubNote3.add(Chunk.NEWLINE);
			pSubNote3.add(chunkNote333);
			pSubNote3.add(chunkNote333Val);

			pSubNote3.add(Chunk.NEWLINE);
			pSubNote3.add(chunkNote3333);
			pSubNote3.add(chunkNote3333Val);
			pSubNote3.add(Chunk.NEWLINE);
			pSubNote3.add(chunkNote33333);
			pSubNote3.add(chunkNote333333);
			pSubNote3.add(Chunk.NEWLINE);
			pSubNote3.add(Chunk.NEWLINE);
			pSubNote3.add(chunkNoteKyc);
			pSubNote3.add(Chunk.NEWLINE);
			pSubNote3.add(chunkNoteKycDoc);

			PdfPTable table2 = new PdfPTable(2);
			table2.setWidthPercentage(100);

			PdfPCell cell1 = new PdfPCell();
			cell1.addElement(new Paragraph("Date: ", headLineFont));
			cell1.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell2 = new PdfPCell();
			Paragraph pCell2 = new Paragraph("(Full Signature)", headLineFont);
			pCell2.setAlignment(Element.ALIGN_RIGHT);
			cell2.addElement(pCell2);
			cell2.setBorder(Rectangle.NO_BORDER);
			table2.addCell(cell1);
			table2.addCell(cell2);

			PdfPCell cell11 = new PdfPCell();
			cell11.addElement(new Paragraph("Place: ", headLineFont));
			cell11.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell22 = new PdfPCell();
			Paragraph pCell22 = new Paragraph("(Name & Designation)”", headLineFont);
			pCell22.setAlignment(Element.ALIGN_RIGHT);
			cell22.addElement(pCell22);
			cell22.setBorder(Rectangle.NO_BORDER);
			table2.addCell(cell11);
			table2.addCell(cell22);

			PdfPCell cell111 = new PdfPCell();
			cell111.addElement(new Paragraph("", headLineFont));
			cell111.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell222 = new PdfPCell();
			Paragraph pCell222 = new Paragraph("(Authorized Signatory)", headLineFont);
			pCell222.setAlignment(Element.ALIGN_RIGHT);
			cell222.addElement(pCell222);
			cell222.setBorder(Rectangle.NO_BORDER);
			table2.addCell(cell111);
			table2.addCell(cell222);

			pSubNote3.setAlignment(Element.ALIGN_JUSTIFIED);
			pSubNote3.setSpacingAfter(15);

			PdfPCell cell = new PdfPCell();
			cell.addElement(pSubNote1);
			cell.addElement(pSubNote2);
			cell.addElement(pSubNote3);
			cell.addElement(table2);
			cell.addElement(Chunk.NEWLINE);
			cell.addElement(Chunk.NEWLINE);
			cell.setBorder(Rectangle.BOX);
			cell.setPadding(10);

			cell.setCellEvent(new PdfPCellEvent() {
				@Override
				public void cellLayout(PdfPCell cell, Rectangle position, PdfContentByte[] canvases) {
					PdfContentByte canvas = canvases[PdfPTable.TEXTCANVAS];
					float x = position.getLeft() + (position.getWidth() / 2);
					float y = position.getBottom() + 10;
					float radius = 40;
					canvas.saveState();
					canvas.setColorFill(BaseColor.WHITE);
					canvas.setColorStroke(BaseColor.BLACK);
					canvas.setLineWidth(0.5f);
					canvas.circle(x, y, radius);
					canvas.fillStroke();
					canvas.restoreState();
					ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, new Phrase("Round Stamp", paragraphFont),
							x, y, 0);
				}
			});
			PdfPTable table = new PdfPTable(1);
			table.setWidthPercentage(100);
			table.addCell(cell);
			document.add(table);
		}

		if (ifvProposalLoIDto.getNote3() != null && !ifvProposalLoIDto.getNote3().isBlank()) {

			document.newPage();

			Paragraph p = new Paragraph();

			combinedPhrase = new Phrase();
			combinedPhrase.add(new Chunk("3. " + tabSpace, paragraphFont));
			combinedPhrase.add(new Chunk(
					"—i;k uksV djsa fd bl i= dks flMch dh vksj ls fdlh Hkh çdkj ds ckè;dkjh nkf;Ro ds :i esa rc rd ugÈ ekuk tkuk pkfg,] tc rd fd vki dk cSad mä lqfoèkk ls lacfUèkr _.k djkj vkSj vU; nLrkost] ;fn dksÃ gks rks] bl vk'k; i= dh frfFk ls",
					hindiFont));

			String no = ifvProposalLoIDto.getLoiNo().contains("RMSE") ? " 7 " : " 3 ";

			combinedPhrase.add(new Chunk(no, paragraphFont));
			combinedPhrase.add(new Chunk(
					"dk;Z fnol ds Hkhrj ;k flMch }kjk vius iw.kZ foosd ls vuqer ,slh fdlh vkxs dh le;kofèk ds Hkhrj vkids cSad }kjk fu\"ikfnr ugÈ dj fn;k tkrk gSA",
					hindiFont));
			combinedPhrase.add(new Chunk("\n\n" + tabSpace + " " + ifvProposalLoIDto.getNote3(), paragraphFont));
			p.add(combinedPhrase);
			p.setAlignment(Element.ALIGN_JUSTIFIED);
			p.setSpacingAfter(15);

			document.add(p);
		}

		Paragraph pConfirm = new Paragraph();
		combinedPhrase = new Phrase();
		combinedPhrase.add(new Chunk("—i;k çkfIr lwpuk nsa", hindiFont));
		combinedPhrase.add(new Chunk(" / Please acknowledge receipt.", paragraphFont));
		pConfirm.add(tabSpace);
		pConfirm.add(combinedPhrase);
		pConfirm.setAlignment(Element.ALIGN_JUSTIFIED);
		pConfirm.setSpacingAfter(15);

		document.add(pConfirm);

		Paragraph pRightText = new Paragraph();
		combinedPhrase = new Phrase();
		combinedPhrase.add(new Chunk("Hkonh;", hindiFont));
		combinedPhrase.add(new Chunk(" Yours faithfully,", paragraphFont));
		pRightText.add(combinedPhrase);
		pRightText.setAlignment(Element.ALIGN_RIGHT);
		pRightText.setSpacingAfter(15);

		document.add(pRightText);
		document.add(Chunk.NEWLINE);
		document.add(Chunk.NEWLINE);

		Paragraph pRightText1 = new Paragraph();
		Phrase chunkRightText1 = new Phrase("[" + userName + "]", headLineFont);
		Phrase chunkRightText2 = new Phrase(designation, headLineFont);
		pRightText1.add(chunkRightText1);
		pRightText1.add(Chunk.NEWLINE);
		pRightText1.add(chunkRightText2);
		pRightText1.setAlignment(Element.ALIGN_RIGHT);
		pRightText1.setSpacingAfter(15);

		document.add(pRightText1);

		Paragraph pBottomText = new Paragraph();

		combinedPhrase = new Phrase();
		combinedPhrase.add(new Chunk("layXud% ;Fkksä", hindiFont));
		combinedPhrase.add(new Chunk(" Encl: As above", paragraphFont));
		pBottomText.add(combinedPhrase);
		pBottomText.setAlignment(Element.ALIGN_JUSTIFIED);
		pBottomText.setSpacingAfter(15);

		document.add(pBottomText);

		int size = 1;

		Map<Long, ProposedSchemaDTO> map = proposedSchemaDetails.stream()
				.collect(Collectors.toMap(ProposedSchemaDTO::getPrId, Function.identity()));

		// Add LoI terms conditions
		if (sanctionTermsConditionsDTOs != null && sanctionTermsConditionsDTOs.size() > 0) {
			for (SanctionTermsConditionsDTO dto : sanctionTermsConditionsDTOs) {
				document.newPage();
				PdfPTable tableS = new PdfPTable(3);

				tableS.setWidthPercentage(100f);

				tableS.setWidths(new float[] { 0.6f, 2.3f, 7.1f });

				tableS.setSpacingBefore(10);
				writeTableHeaderforAppendixOne(tableS, dto, size, map);

				document.add(tableS);
				++size;
			}

		}

		document.close();
		writer.close();
		return outputStream.toByteArray();
	}

	private void writeTableHeaderforAppendixOne(PdfPTable table, SanctionTermsConditionsDTO dto, int size,
			Map<Long, ProposedSchemaDTO> map) throws DocumentException {

		PdfPCell cellTandC = new PdfPCell(new Paragraph("Terms and Conditions of Sanction", underlineFont));
		cellTandC.setBorderWidth(0);
		cellTandC.setPaddingBottom(10);
		cellTandC.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellTandC.setColspan(3);

		Paragraph p5 = new Paragraph();
		p5.setAlignment(Element.ALIGN_CENTER);
		p5.setSpacingAfter(20);
		Phrase chunk5 = new Phrase("", FontFactory.getFont(FontFactory.HELVETICA, 10.5f, Font.BOLD | Font.UNDERLINE));
		p5.add(chunk5);
		PdfPCell cell1 = new PdfPCell(new Paragraph("1", paragraphFont));
		cell1.setPadding(5);
		cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		String fundName = "";
		String schemeName = dto.getSchemeName() != null ? dto.getSchemeName() : "";
		BigDecimal tsRAteInterest;
		String tsRoiRepayment = "";
		BigDecimal amount;
		String amountInWords = "";
		BigDecimal tsTunure;
		String tsTenureWd = "";
		String tsExtent = "";
		String tsEligibleMse = "";
		String tsEventDflt = "";
		String tsSecurity = "";
		String tsDocumentstion = "";
		String tsTimeFrame = "";
		String tsDrawaloan = "";

		String tsOtherCond = "";

		Paragraph appPara = new Paragraph("Annexure-" + size, headLineFont);
		appPara.setAlignment(Element.ALIGN_RIGHT);
		PdfPCell cellAppendix = new PdfPCell();
		cellAppendix.setBorderWidth(0);
		cellAppendix.setPaddingBottom(5);
		cellAppendix.setPaddingTop(5);
		cellAppendix.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cellAppendix.addElement(appPara);
		cellAppendix.setColspan(3);

		fundName = dto.getFundName() != null ? dto.getFundName() : "";

		if (schemeName.toUpperCase().contains("RMSE")) {
			schemeName = this.getSchemeName(dto.getFundName());
		}

		tsRAteInterest = dto.getTsRAteInterest() != null ? dto.getTsRAteInterest() : BigDecimal.ZERO;
		tsRoiRepayment = dto.getTsRoiRepayment() != null ? dto.getTsRoiRepayment() : "";
		amount = dto.getAmount() != null ? dto.getAmount().stripTrailingZeros() : BigDecimal.ZERO;
		amountInWords = dto.getAmountInWords() != null ? dto.getAmountInWords() : "";
		tsTunure = dto.getTsTenurePeriod() != null ? dto.getTsTenurePeriod() : BigDecimal.ZERO;
		tsTenureWd = dto.getTsTenureWd() != null ? dto.getTsTenureWd() : "";
		tsExtent = dto.getTsExtent() != null ? dto.getTsExtent() : "";
		tsEligibleMse = dto.getTsEligibleMse() != null ? dto.getTsEligibleMse() : "";
		tsEventDflt = dto.getTsEventDflt() != null ? dto.getTsEventDflt() : "";
		tsSecurity = dto.getTsSecurity() != null ? dto.getTsSecurity() : "";
		tsDocumentstion = dto.getTsDocumentstion() != null ? dto.getTsDocumentstion() : "";
		tsTimeFrame = dto.getTsTimeFrame() != null ? dto.getTsTimeFrame() : "";
		tsDrawaloan = dto.getTsDrawaloan() != null ? dto.getTsDrawaloan() : "";
		tsOtherCond = dto.getTsOtherCond() != null ? dto.getTsOtherCond() : "";

		PdfPCell pSanction = new PdfPCell();
		Paragraph chunkpSanction = new Paragraph(
				"Refinance under " + schemeName + " scheme to " + ifvProposalLoIDto.getIfvName(), underlineFont);
		chunkpSanction.setAlignment(Element.ALIGN_CENTER);
		pSanction.addElement(chunkpSanction);
		pSanction.setBorderWidth(0);
		pSanction.setPaddingBottom(8);
		pSanction.setHorizontalAlignment(Element.ALIGN_CENTER);
		pSanction.setColspan(3);

		PdfPCell cell2 = new PdfPCell(new Paragraph("Fund", paragraphFont));
		cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell2.setPadding(5);

		PdfPCell cell3 = new PdfPCell(new Paragraph("" + fundName, headLineFont));
		cell3.setPadding(5);
		cell3.setHorizontalAlignment(Element.ALIGN_LEFT);

		int count = 0;

		PdfPCell cell4 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell4.setPadding(5);
		cell4.setBackgroundColor(BaseColor.LIGHT_GRAY);

		PdfPCell cell5 = new PdfPCell(new Paragraph("Scheme", paragraphFont));
		cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell5.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell5.setPadding(5);

		PdfPCell cellSchemeName = new PdfPCell(new Paragraph("" + schemeName, paragraphFont));
		cellSchemeName.setPadding(5);
		cellSchemeName.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell6 = new PdfPCell();
		Paragraph pInterest = new Paragraph("Interest will be charged @ " + tsRAteInterest + " % p.a. ("
				+ CurrencyConverter.convert(tsRAteInterest, "Roi") + " per annum.)" + " \n", paragraphFont);

		Paragraph pRoiRepayments = new Paragraph("" + tsRoiRepayment, paragraphFont);

		cell6.addElement(pInterest);
		cell6.addElement(pRoiRepayments);
		cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell6.setPaddingTop(-3f);
		cell6.setPaddingLeft(5f);
		cell6.setPaddingBottom(5f);

		PdfPCell cell7 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell7.setPadding(5);
		cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell7.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell8 = new PdfPCell();

		Paragraph para = new Paragraph();
		Phrase phrase1 = new Phrase("Amount", paragraphFont);
		para.add(phrase1);

		cell8.addElement(para);
		cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell8.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell8.setPadding(5);
		cell8.setPaddingTop(-1);

		PdfPCell cellAmount = new PdfPCell();
		Chunk rupeeChunk = new Chunk("Rupee", rupeeFont);
		Paragraph pAmount = new Paragraph();
		pAmount.add(rupeeChunk);

		String finalAmountInWords;
		if (amountInWords.contains("Rupees")) {
			finalAmountInWords = CommonUtil.formatNumber(amount.toPlainString()) + " crore (" + amountInWords + ")";
		} else {
			finalAmountInWords = CommonUtil.formatNumber(amount.toPlainString()) + " crore (Rupees " + amountInWords
					+ ")";
		}

		Chunk amountChunk = new Chunk(finalAmountInWords, paragraphFont);
		pAmount.add(amountChunk);
		cellAmount.addElement(pAmount);
		cellAmount.setPadding(5);
		cellAmount.setPaddingTop(-4);
		cellAmount.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell9 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell9.setPadding(5);
		cell9.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell9.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell10 = new PdfPCell(new Paragraph("Rate of Interest", paragraphFont));
		cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell10.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell10.setPadding(5);

		String roi;

		String boldText = "";

		boolean is3MTBillBenchmark = dto.getBenchMark() != null && dto.getBenchMark().toLowerCase().contains("t-bill");
		boolean isRepoRate = dto.getBenchMark() != null && dto.getBenchMark().toLowerCase().contains("repo");

		String benchMark = dto.getBenchMark();

		if (benchMark != null && !benchMark.isBlank()) {

			if (benchMark.toUpperCase().contains("REPO RATE")) {
				benchMark = "RBI Repo rate";
			}

			StringBuilder stringBuilder = new StringBuilder(benchMark);

			if (dto.getSpread() != null && !dto.getSpread().isBlank()) {
				stringBuilder.append(" + " + dto.getSpread() + " bps.");

			}

			boldText = stringBuilder.toString();

		} else {
			roi = dto.getTsRAteInterest() != null ? formatRoi(dto.getTsRAteInterest()) : "";

			if (StringUtils.hasText(roi)) {
				boldText = roi + " % p.a " + "(" + CurrencyConverter.convert(new BigDecimal(roi), "Roi")
						+ " per annum.)";
			}

		}

		String text = "Interest will be charged @ ";

		Phrase phrase = new Phrase();
		phrase.add(new Chunk(text, paragraphFont));
		phrase.add(new Chunk(boldText, headLineFont));

		ProposedSchemaDTO proposedSchemaDTO = map.get(dto.getPrId());

		if (benchMark != null && benchMark.toLowerCase().contains("repo") && proposedSchemaDTO.getRoiNote() != null
				&& !proposedSchemaDTO.getRoiNote().isBlank()) {

			phrase.add(new Chunk(" (" + proposedSchemaDTO.getRoiNote().trim() + ")", paragraphFont));

			String regex = "(\\d+\\.\\d+)% p\\.a\\.";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(proposedSchemaDTO.getRoiNote());
			if (matcher.find()) {
				String extractedRate = matcher.group(1);
				phrase.add(new Chunk(
						" (" + CurrencyConverter.convert(new BigDecimal(extractedRate), "Roi") + " per annum).",
						paragraphFont));
			}

			if (dto.getSpread() != null && !dto.getSpread().isBlank()) {
				phrase.add(new Chunk(
						" RBI Repo to be on actuals, i.e., Repo will change as and when the same is changed by RBI. (Spread of "
								+ dto.getSpread() + " bps will remain unchanged).",
						headLineFont));
				phrase.add(Chunk.NEWLINE);
				phrase.add(Chunk.NEWLINE);
			}

		}

		Paragraph paragraph = new Paragraph(phrase);

		Paragraph pRoiRepayment = new Paragraph(tsRoiRepayment, paragraphFont);
		pRoiRepayment.setAlignment(Element.ALIGN_JUSTIFIED);
		PdfPCell cellROI = new PdfPCell();
		cellROI.addElement(paragraph);

		if (is3MTBillBenchmark) {
			if (dto.getInterestResetNote() != null && !dto.getInterestResetNote().isBlank()) {
				Phrase subPhrase = new Phrase();
				subPhrase.add(pSpace);
				subPhrase.add(new Chunk("Interest Reset: ", underlineFont));
				subPhrase.add(new Chunk(dto.getInterestResetNote(), paragraphFont));
				Paragraph subParagraph = new Paragraph(subPhrase);
				subParagraph.setAlignment(Element.ALIGN_JUSTIFIED);
				cellROI.addElement(subParagraph);
			}

			if (dto.getBenchMarkNote() != null && !dto.getBenchMarkNote().isBlank()) {
				Phrase subPhrase1 = new Phrase();

				subPhrase1.add(new Chunk("Benchmark: ", underlineFont));
				subPhrase1.add(new Chunk(dto.getBenchMarkNote() != null ? dto.getBenchMarkNote() : "", paragraphFont));
				cellROI.addElement(new Paragraph(subPhrase1));

			}

			cellROI.addElement(pRoiRepayment);

		} else if (isRepoRate) {

			cellROI.addElement(pRoiRepayment);

			if (dto.getInterestResetNote() != null && !dto.getInterestResetNote().isBlank()) {
				Phrase subPhrase = new Phrase();
				subPhrase.add(pSpace);
				subPhrase.add(new Chunk("Reset of interest rate: ", underlineFont));
				subPhrase.add(new Chunk(dto.getInterestResetNote(), paragraphFont));
				Paragraph subParagraph = new Paragraph(subPhrase);
				subParagraph.setAlignment(Element.ALIGN_JUSTIFIED);
				cellROI.addElement(subParagraph);
			}

		} else {
			cellROI.addElement(pRoiRepayment);

			if (StringUtils.hasText(proposedSchemaDTO.getInterestReset())
					&& StringUtils.hasText(dto.getInterestResetNote())) {
				Phrase subPhrase = new Phrase();
				subPhrase.add(pSpace);
				subPhrase.add(new Chunk("Interest Reset: ", underlineFont));
				subPhrase.add(new Chunk(dto.getInterestResetNote(), paragraphFont));
				Paragraph subParagraph = new Paragraph(subPhrase);
				subParagraph.setAlignment(Element.ALIGN_JUSTIFIED);
				cellROI.addElement(subParagraph);
			}
		}

		cellROI.setPadding(5);
		cellROI.setPaddingBottom(5);
		cellROI.setLeading(16, 0);
		cellROI.setPaddingTop(-3);
		cellROI.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPTable nested1 = new PdfPTable(2);
		nested1.setWidthPercentage(100f);
		nested1.setWidths(new float[] { 5f, 5f });
		nested1.setSpacingBefore(6);
		tenureRepaymentPeriod(nested1);
		tenureRepaymentPeriodDataOnEntity(nested1, dto);

		PdfPCell cellTenure = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cellTenure.setPadding(5);
		cellTenure.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellTenure.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell11 = new PdfPCell(new Paragraph("""
				Tenure of
				Refinance/
				Repayment Peroid
				""", paragraphFont));
		cell11.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell11.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell11.setLeading(16, 0);
		cell11.setPadding(5);
		cell11.setPaddingTop(1);
		PdfPCell cell12 = new PdfPCell();
		Phrase chTenure = new Phrase("Tenure: ", headLineFont);
		String tenureMsg = dto.getTsTenureApprox() != null ? dto.getTsTenureApprox() : "";
		Chunk chApprox = new Chunk(tsTunure.intValue() + " months " + tenureMsg, headLineFont);
		Paragraph pTsTenurePeriod = new Paragraph(String.valueOf("Tenure: "), paragraphFont);
		chTenure.add(pTsTenurePeriod);
		pTsTenurePeriod.add(chApprox);
		Paragraph pTsTenureWd = new Paragraph(tsTenureWd, paragraphFont);
		pTsTenureWd.setAlignment(Element.ALIGN_JUSTIFIED);
		cell12.addElement(pTsTenurePeriod);
		cell12.addElement(nested1);
		cell12.addElement(pTsTenureWd);
		cell12.setLeading(16, 0);
		cell12.setPadding(5);
		cell12.setPaddingTop(-4);
		cell12.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cellP6 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cellP6.setPaddingTop(5);
		cellP6.setPadding(5);
		cellP6.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellP6.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cellExtent = new PdfPCell(new Paragraph("Extent of Refinance", paragraphFont));
		cellExtent.setBackgroundColor(BaseColor.WHITE);
		cellExtent.setPadding(5);
		cellExtent.setPaddingTop(1);
		cellExtent.setLeading(16, 0);
		cellExtent.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cellExtent.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cellTsExtent = new PdfPCell();
		Paragraph pTsExtent = new Paragraph(String.valueOf(tsExtent), paragraphFont);
		pTsExtent.setAlignment(Element.ALIGN_JUSTIFIED);
		cellTsExtent.addElement(pTsExtent);
		cellTsExtent.setPadding(5);
		cellTsExtent.setPaddingTop(-2);

		PdfPCell cell16 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell16.setPaddingTop(5);
		cell16.setPadding(5);
		cell16.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell16.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell17 = new PdfPCell(new Paragraph("Eligible end borrowers/underlying assets", paragraphFont));
		cell17.setBackgroundColor(BaseColor.WHITE);
		cell17.setPadding(5);
		cell17.setPaddingTop(1);
		cell17.setLeading(16, 0);
		cell17.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell17.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell18 = new PdfPCell();
		Paragraph pTsEligibleMse = new Paragraph(String.valueOf(tsEligibleMse), paragraphFont);
		pTsEligibleMse.setAlignment(Element.ALIGN_JUSTIFIED);
		cell18.addElement(pTsEligibleMse);
		cell18.setPadding(5);
		cell18.setPaddingTop(-2);

		PdfPCell cell19 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell19.setPadding(5);
		cell19.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell19.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell20 = new PdfPCell(new Paragraph("Eligible activities", paragraphFont));
		cell20.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell20.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell20.setPadding(5);
		cell20.setPaddingTop(2);

		PdfPCell cell21 = new PdfPCell(new Paragraph("As defined in section 2(h) of SIDBI Act.", paragraphFont));
		cell21.setPadding(5);
		cell21.setPaddingTop(2);
		cell21.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell22 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell22.setPadding(5);
		cell22.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell22.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell23 = new PdfPCell(new Paragraph("Event of Default", paragraphFont));
		cell23.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell23.setPadding(5);
		cell23.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell24 = new PdfPCell();
		Paragraph pTsEventDflt = new Paragraph(tsEventDflt, paragraphFont);
		pTsEventDflt.setAlignment(Element.ALIGN_JUSTIFIED);
		cell24.addElement(pTsEventDflt);
		cell24.setPadding(5);
		cell24.setPaddingTop(-1);
		cell24.setLeading(14, 0);

		PdfPCell cell25 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell25.setPadding(5);
		cell25.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell25.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell26 = new PdfPCell(new Paragraph("Security", paragraphFont));
		cell26.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell26.setPadding(5);
		cell26.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell27 = new PdfPCell();
		Paragraph pTsSecurity = new Paragraph(tsSecurity, paragraphFont);
		pTsSecurity.setAlignment(Element.ALIGN_JUSTIFIED);
		cell27.addElement(pTsSecurity);
		cell27.setPadding(5);
		cell27.setLeading(14, 0);
		cell27.setPaddingTop(-1);

		PdfPCell cell28 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell28.setPadding(5);
		cell28.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell28.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell29 = new PdfPCell(new Paragraph("Documentation", paragraphFont));
		cell29.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell29.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell29.setPadding(5);

		PdfPCell cell30 = new PdfPCell();
		Paragraph pTsDocumentstion = new Paragraph(tsDocumentstion, paragraphFont);
		pTsDocumentstion.setAlignment(Element.ALIGN_JUSTIFIED);
		cell30.addElement(pTsDocumentstion);
		cell30.setPadding(5);
		cell30.setPaddingTop(1);
		cell30.setLeading(16, 0);
		cell30.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell31 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell31.setPadding(5);
		cell31.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell31.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell32 = new PdfPCell(new Paragraph("Time frame for acceptance of LOl / Disbursement", paragraphFont));
		cell32.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell32.setPadding(5);
		cell32.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell32.setPadding(4f);
		cell32.setLeading(15, 0);
		cell32.setPaddingTop(1);

		PdfPCell cell33 = new PdfPCell();
		Paragraph pTsTimeFrame = new Paragraph(tsTimeFrame, paragraphFont);
		pTsTimeFrame.setAlignment(Element.ALIGN_JUSTIFIED);
		cell33.addElement(pTsTimeFrame);
		cell33.setPadding(5);
		cell33.setPaddingTop(1);
		cell33.setLeading(16, 0);

		PdfPCell cell34 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell34.setPadding(5);
		cell34.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell34.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell35 = new PdfPCell(new Paragraph("Drawal of loan", paragraphFont));
		cell35.setPaddingTop(-1);
		cell35.setBackgroundColor(BaseColor.WHITE);
		cell35.setPadding(5);
		cell35.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell35.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell cell36 = new PdfPCell();
		Paragraph pTsDrawalloan = new Paragraph(tsDrawaloan, paragraphFont);
		pTsDrawalloan.setAlignment(Element.ALIGN_JUSTIFIED);
		cell36.addElement(pTsDrawalloan);
		cell36.setPadding(5);
		cell36.setPaddingTop(-1);
		cell36.setLeading(16, 0);

		PdfPCell cell37 = new PdfPCell(new Paragraph(Integer.toString(++count), paragraphFont));
		cell37.setPadding(5);
		cell37.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell37.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell cell38 = new PdfPCell(new Paragraph("Other Conditions", paragraphFont));
		cell38.setBackgroundColor(BaseColor.WHITE);
		cell38.setPadding(5);
		cell38.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell38.setHorizontalAlignment(Element.ALIGN_LEFT);

		List<Long> conditionNumbers = new ArrayList<>();

		if (tsOtherCond != null && !tsOtherCond.isBlank()) {
			String[] tokens = tsOtherCond.split(",");
			for (String token : tokens) {
				String trimmed = token.trim();
				if (!trimmed.isEmpty()) {
					try {
						conditionNumbers.add(Long.parseLong(trimmed));
					} catch (NumberFormatException nfe) {
						logger.warn("Ignoring invalid condition number: {}", trimmed);
					}
				}
			}
		}

		List<String> conditions = masterRepositoryData.stream().filter(e -> conditionNumbers.contains(e.getMstCode()))
				.map(MasterRepositoryDTO::getMstRemarks).collect(Collectors.toList());
		PdfPCell cell39 = new PdfPCell();
		cell39.setPaddingTop(1);
		cell39.setPadding(5);
		cell39.setHorizontalAlignment(Element.ALIGN_LEFT);
		int SrNo = 1;
		for (String con : conditions) {

			Paragraph p = new Paragraph(SrNo + ".  " + con + "\n\n", paragraphFont);
			p.setAlignment(Element.ALIGN_JUSTIFIED);
			cell39.addElement(p);
			cell39.setPaddingTop(-1);
			SrNo++;
		}

		table.addCell(cellAppendix);
		table.addCell(pSanction);
		table.addCell(cellTandC);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cellSchemeName);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cellAmount);
		table.addCell(cell9);

		table.addCell(cell10);
		table.addCell(cellROI);
		table.addCell(cellTenure);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cellP6);
		table.addCell(cellExtent);
		table.addCell(cellTsExtent);
		table.addCell(cell16);
		table.addCell(cell17);
		table.addCell(cell18);
		table.addCell(cell19);
		table.addCell(cell20);
		table.addCell(cell21);
		table.addCell(cell22);
		table.addCell(cell23);
		table.addCell(cell24);
		table.addCell(cell25);
		table.addCell(cell26);
		table.addCell(cell27);
		table.addCell(cell28);
		table.addCell(cell29);
		table.addCell(cell30);
		table.addCell(cell31);
		table.addCell(cell32);
		table.addCell(cell33);
		table.addCell(cell34);
		table.addCell(cell35);
		table.addCell(cell36);
		table.addCell(cell37);
		table.addCell(cell38);
		table.addCell(cell39);

	}

	private void tenureRepaymentPeriod(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setPadding(5);

		cell.setPhrase(new Phrase("Principal Repayment", headLineFont));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);

		cell.setPhrase(new Phrase("Interest Payment", headLineFont));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);

	}

	private void tenureRepaymentPeriodDataOnEntity(PdfPTable table, SanctionTermsConditionsDTO dto) {

		Paragraph p = new Paragraph(dto.getTsPrincipalRepayment() != null ? dto.getTsPrincipalRepayment() : "",
				paragraphFont);
		p.setAlignment(Element.ALIGN_JUSTIFIED);

		PdfPCell cellRepayment = new PdfPCell();
		cellRepayment.addElement(p);
		cellRepayment.setLeading(17, 0);
		cellRepayment.setPaddingTop(-1f);
		cellRepayment.setPaddingBottom(5f);
		cellRepayment.setPaddingLeft(5f);
		table.addCell(cellRepayment);

		Paragraph p1 = new Paragraph(dto.getTsIntrestPayment() != null ? dto.getTsIntrestPayment() : "", paragraphFont);
		p1.setAlignment(Element.ALIGN_JUSTIFIED);

		PdfPCell cellIntPayment = new PdfPCell();
		cellIntPayment.addElement(p1);
		cellIntPayment.setLeading(17, 0);
		cellIntPayment.setPaddingTop(-1f);
		cellIntPayment.setPaddingBottom(6f);
		cellIntPayment.setPaddingLeft(5f);
		table.addCell(cellIntPayment);
	}

	class FooterPageEvent extends PdfPageEventHelper {

		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			PdfContentByte cb = writer.getDirectContent();

			if (writer.getPageNumber() != 1) {

				Image leftLogo = null;
				try {
					leftLogo = Image.getInstance(new ClassPathResource("logo/SidbiLogo.png").getURL());

					float logoWidth = 100f;
					float logoHeight = 100f;
					// Scale the images to fit within the desired dimensions
					leftLogo.scaleToFit(logoWidth, logoHeight);
					// Calculate positions for the logos
					float leftLogoX = document.leftMargin();
					float leftLogoY = document.getPageSize().getHeight() - document.topMargin() + 10;

					// Add the logos to the document
					PdfContentByte canvas = writer.getDirectContent();
					leftLogo.setAbsolutePosition(leftLogoX, leftLogoY);
					canvas.addImage(leftLogo);

				} catch (IOException | DocumentException e) {
					e.printStackTrace();
					logger.error("Error Occurred while fetching all S2IFVApplicationEntities. {}", e.getMessage());
				}

				float headerRightMargin = document.right();

				float yPos = document.top() + 15;

				Paragraph headerText = new Paragraph("SIDBI: IFV: No. " + ifvProposalLoIDto.getLoiNo(),
						FontFactory.getFont(FontFactory.HELVETICA, 8.5f, Font.ITALIC | Font.UNDERLINE));
				headerText.setAlignment(Element.ALIGN_RIGHT);
				headerText.setSpacingBefore(10);

				ColumnText.showTextAligned(cb, Element.ALIGN_RIGHT, headerText, headerRightMargin, yPos, 0);

				Phrase pageNumber = new Phrase(String.format("Page %d", writer.getPageNumber()),
						new Font(FontFamily.HELVETICA, 10));
				float pageX = (document.right() + document.left()) / 2;
				float bottomMargin = document.bottomMargin();
				float pageY = bottomMargin - 20;
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, pageNumber, pageX, pageY, 0);
			}

			addWatermark(document, writer);
		}
	}

	private void addWatermark(Document document, PdfWriter writer) {
		Font font = new Font(Font.FontFamily.HELVETICA, 52, Font.BOLD, new BaseColor(0, 255, 0, 50));
		Phrase watermark = new Phrase("Draft LoI", font);
		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = document.getPageSize();
		float x = (rect.getLeft() + rect.getRight()) / 2;
		float y = (rect.getTop() + rect.getBottom()) / 2;
		ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, watermark, x, y, 45);
	}

	public String getSchemeName(String schemeName) {
		String wordToFind = "FUND";
		int index = schemeName.indexOf(wordToFind);
		if (index != -1) {
			return schemeName.substring(0, index).trim();
		}
		return schemeName;
	}

	private String formatRoi(BigDecimal roi) {
		if (roi.scale() > 0) {
			return roi.setScale(2, RoundingMode.HALF_UP).toPlainString();
		}
		return roi.toPlainString();
	}

	public String getMonthInHindi(String month) {
		Map<String, String> monthsMap = new HashMap<>();
		// Adding months with Kruti Dev encoded Hindi text
		monthsMap.put("JANUARY", "tuojh");
		monthsMap.put("FEBRUARY", "Qjojh");
		monthsMap.put("MARCH", "ekpZ");
		monthsMap.put("APRIL", "vizSy");
		monthsMap.put("MAY", "ebZ");
		monthsMap.put("JUNE", "twu");
		monthsMap.put("JULY", "tqykbZ");
		monthsMap.put("AUGUST", "vxLr");
		monthsMap.put("SEPTEMBER", "flrEcj");
		monthsMap.put("OCTOBER", "vDVwcj");
		monthsMap.put("NOVEMBER", "uoEcj");
		monthsMap.put("DECEMBER", "fnlEcj");

		return monthsMap.getOrDefault(month, "");
	}
}
