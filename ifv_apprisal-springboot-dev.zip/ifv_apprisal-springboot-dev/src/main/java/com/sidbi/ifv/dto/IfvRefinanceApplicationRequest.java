package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IfvRefinanceApplicationRequest {

	// Bank Details
	private String nameOfBank;
	private String cifNumber;
	private String typeOfBank;

	// Application Details
	private String appRefId;
	private String fundCode;
	private String fundDescription;
	private String schemeCode;
	private String schemeShortName;
	private String schemeLongName;
	private String customSchemeName;
	private String currencyType;
	private LocalDateTime submittedDateTime;
	private String applicationStatus;

	private BigDecimal frameworkParmTier;
	private BigDecimal frameworkParmCRAR;
	private BigDecimal frameworkParmCET1;
	private BigDecimal frameworkParmCCB;

	private String refinanceAppFileName;
	private String refinanceAppFilePath;

	// Account Details
	private String bankName;
	private String bankAccountNo;
	private String rtgsCode;
	private String neftCode;
	private String bankAddress;
	private String legalEntityIdentifier;
	private LocalDate leiValidity;

	// Authorized Signatories
	private List<IfvAuthorizedSignatoryDto> authorizedSignatories;
	private String authorizedSignatoryFileName;
	private String authorizedSignatoryFilePath;

	// Refinance Proposals
	private List<IfvProposalDto> proposals;

	// Meta Information
	private String submittedBy;
	private String submitByEmail;
}
