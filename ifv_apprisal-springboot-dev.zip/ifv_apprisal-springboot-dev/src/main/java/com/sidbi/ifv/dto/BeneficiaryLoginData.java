package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryLoginData {

	private Integer id;
	private String userId;
	private String userName;
	private String userShortName;
	private String userType;
	private String userActive;
	private Short userLock;
}
