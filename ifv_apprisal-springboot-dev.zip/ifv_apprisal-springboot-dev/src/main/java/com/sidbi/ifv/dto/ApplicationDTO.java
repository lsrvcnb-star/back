package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class ApplicationDTO {

	private Long ifvId;

	private String ifvName;

	private String ifvAssistance;

	private BigDecimal ifvExposureLimit;

	private BigDecimal ifvExistingOs;

	private BigDecimal ifvPropExposure;

	private BigDecimal ifvTotalExposure;

	private Date ifvRepaymentDate;

	private String ifvExternalRating;

	private String ifvEws;

	private String ifvAdverseNews;

	private String ifvMonetary;

	private String ipAddress;

	private Date modifiedDate;

	private Date createdDate;

	private String cifNumber;

	private String sfb;

	private Long ofrCode;

	private String ofrName;

	private String appNumber;

	private String otherRemarks;

	private String ifvRemarks;

	private Integer checkerId;

	private String makerName;

	private String status;

	private String ifvExpRemarks;

	private BigDecimal ifvUndisbursedSanction;

	private String ifvBankType;

	private String ifvBackground;

	private String internalRating;

	private String ifvShortName;

	private List<ProposedSchemaDTO> proposedSchemaDTOs;

	private List<AssistanceAppliedForDto> assistanceAppliedFor;

	private List<IfvAggregateExposureDto> aggregateExposure;

	private List<String> bankAppRefNos;
}
