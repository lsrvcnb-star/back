package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.TermConditionsDataDTO;
import com.sidbi.ifv.entity.S2IFVTermConditionsDataEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.TermConditionsDataRepository;
import com.sidbi.ifv.services.TermConditionDataService;
import com.sidbi.ifv.util.CommonUtil;

@Service
public class TermConditionDataServiceImpl implements TermConditionDataService {

	private static final Logger logger = LoggerFactory.getLogger(TermConditionDataServiceImpl.class);

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private TermConditionsDataRepository s2ifccTermConditionDataRepository;

	@Autowired
	private CommonUtil commonUtil;

	String msg = "";

	@Override
	public TermConditionsDataDTO getTermConditionDataById(Long id) {
		logger.info(
				"getTermConditionDataById() started in TermConditionDataServiceImpl for S2IFVTermConditionsDataEntity");
		try {
			S2IFVTermConditionsDataEntity ifccTermConditionData = s2ifccTermConditionDataRepository.findByIfvId(id);
			return modelMapper.map(ifccTermConditionData != null ? ifccTermConditionData : new TermConditionsDataDTO(),
					TermConditionsDataDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFVTermConditionsDataEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching  S2IFVTermConditionsDataEntity entity." + msg + " ", e);
		}
	}

	@Override
	public List<TermConditionsDataDTO> getAllTermConditionData() {
		logger.info(
				"getAllTermConditionData() started in TermConditionDataServiceImpl for S2IFVTermConditionsDataEntity");
		try {
			List<S2IFVTermConditionsDataEntity> list = s2ifccTermConditionDataRepository.findAll();
			return list.stream().map(ifcc -> modelMapper.map(ifcc, TermConditionsDataDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVTermConditionsDataEntity entities. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVTermConditionsDataEntity entities." + msg + " ", e);
		}
	}

	@Override
	public TermConditionsDataDTO save(TermConditionsDataDTO termConditionsDataDTO) {
		logger.info("save() started in TermConditionDataServiceImpl for S2IFVTermConditionsDataEntity");
		try {
			S2IFVTermConditionsDataEntity s2ifvTermConditionsDataEntity;

			if (termConditionsDataDTO.getTsId() != null) {
				S2IFVTermConditionsDataEntity existingEntity = s2ifccTermConditionDataRepository
						.findById(termConditionsDataDTO.getTsId())
						.orElseThrow(() -> new EntityNotFoundException("S2IFVTermConditionsDataEntity",
								termConditionsDataDTO.getTsId()));

				BeanUtils.copyProperties(termConditionsDataDTO, existingEntity,
						commonUtil.getNullPropertyNames(termConditionsDataDTO));

				s2ifvTermConditionsDataEntity = existingEntity;
			} else {
				s2ifvTermConditionsDataEntity = modelMapper.map(termConditionsDataDTO,
						S2IFVTermConditionsDataEntity.class);
			}

			s2ifccTermConditionDataRepository.save(s2ifvTermConditionsDataEntity);
			return modelMapper.map(s2ifvTermConditionsDataEntity, TermConditionsDataDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVTermConditionsDataEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  S2IFVTermConditionsDataEntity entity." + msg + " ", e);
		}
	}

}
