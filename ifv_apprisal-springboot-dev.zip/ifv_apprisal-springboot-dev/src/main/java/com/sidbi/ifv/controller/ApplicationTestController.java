package com.sidbi.ifv.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("auth")
@Tag(name = "API WORKING STATUS")
public class ApplicationTestController {
	@Operation(summary = "check  API's are working or not")
	@GetMapping("/applicationTest")
	public ResponseEntity<String> test() {

		return new ResponseEntity<>("Application is running", HttpStatus.OK);

	}

}