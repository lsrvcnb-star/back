package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.UcbAnnexureDTO;
import com.sidbi.ifv.entity.UcbAnnexureEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.UcbAnnexureRepo;
import com.sidbi.ifv.services.UcbAnnexureService;

@Service
public class UcbAnnexureServiceImpl implements UcbAnnexureService {

	private static final Logger logger = LoggerFactory.getLogger(UcbAnnexureServiceImpl.class);

	@Autowired
	private UcbAnnexureRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public UcbAnnexureDTO findById(Long id) {
		logger.info("findById() started in UcbAnnexureServiceImpl for UcbAnnexureEntity {} ", id);
		UcbAnnexureEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("UCBAnnexureEntity", id));
		return mapper.map(entity, UcbAnnexureDTO.class);
	}

	@Override
	public List<UcbAnnexureDTO> findAll() {
		logger.info("findAll() started in UcbAnnexureServiceImpl of UcbAnnexureEntity");
		try {
			List<UcbAnnexureEntity> list = repository.findAll();
			return !list.isEmpty()
					? list.stream().map(entity -> mapper.map(entity, UcbAnnexureDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all UcbAnnexureEntity .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all UcbAnnexureEntity ." + msg + " ",
					e);
		}
	}

	@Override
	public UcbAnnexureDTO save(UcbAnnexureDTO dto) {
		logger.info("save() started in UcbAnnexureServiceImpl for UcbAnnexureEntity {} ", dto);
		try {
			UcbAnnexureEntity entity = mapper.map(dto, UcbAnnexureEntity.class);
			repository.save(entity);
			return mapper.map(entity, UcbAnnexureDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating UcbAnnexureEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  UcbAnnexureEntity." + msg + " ", e);
		}
	}

	@Override
	public List<UcbAnnexureDTO> saveAll(List<UcbAnnexureDTO> dtos) {
		logger.info("saveAll() started in UcbAnnexureServiceImpl for List of UcbAnnexureEntity");
		try {

			List<UcbAnnexureEntity> entitiesToSave = dtos.stream().map(dto -> mapper.map(dto, UcbAnnexureEntity.class))
					.collect(Collectors.toList());
			List<UcbAnnexureEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, UcbAnnexureDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all UcbAnnexureEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all UcbAnnexureEntity." + msg + " ", e);
		}
	}

	@Override
	public UcbAnnexureDTO update(Long id, UcbAnnexureDTO dto) {
		logger.info("update() started in UcbAnnexureServiceImpl for UcbAnnexureEntity {} {} ", id, dto);
		try {
			UcbAnnexureEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbAnnexureEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, UcbAnnexureDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating UcbAnnexureEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating UcbAnnexureEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in UcbAnnexureServiceImpl for UcbAnnexureEntity {} ", id);
		try {
			UcbAnnexureEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbAnnexureEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting UcbAnnexureEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting UcbAnnexureEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<UcbAnnexureDTO> findAllByIfvIdAndAnnexureNo(Long ifvId, Integer annexureNo) {
		logger.info("findAllByIfvId() started in UcbAnnexureServiceImpl for UcbAnnexureEntity {} ", ifvId);
		try {

			List<UcbAnnexureEntity> list = repository.findByIfvIdAndAnnexureNo(ifvId, annexureNo);
			return (list != null && !list.isEmpty())
					? list.stream().sorted(Comparator.comparing(UcbAnnexureEntity::getId))
							.map(UcbAnnexureEntity -> mapper.map(UcbAnnexureEntity, UcbAnnexureDTO.class)).collect(
									Collectors.toList())
					: new ArrayList<>();

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId UcbAnnexureEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId UcbAnnexureEntity of id ." + msg + " " + ifvId, e);
		}
	}

	@Override
	public List<UcbAnnexureDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in UcbAnnexureServiceImpl for UcbAnnexureEntity {} ", ifvId);
		try {

			List<UcbAnnexureEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty())
					? list.stream().sorted(Comparator.comparing(UcbAnnexureEntity::getId))
							.map(UcbAnnexureEntity -> mapper.map(UcbAnnexureEntity, UcbAnnexureDTO.class)).collect(
									Collectors.toList())
					: new ArrayList<>();

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId UcbAnnexureEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId UcbAnnexureEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
