package com.sidbi.ifv.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.UploadJobResponse;
import com.sidbi.ifv.dto.ValidationError;
import com.sidbi.ifv.dto.ValidationJobStatusResponse;
import com.sidbi.ifv.services.MasterCommonAPIClient;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BeneficiaryValidateService {

	private final MasterCommonAPIClient ifvMasterClient;

	public UploadJobResponse requestValidationFromMaster(MultipartFile file, String jobId) {

		return ifvMasterClient.createValidationJob(file, jobId);
	}

	public UploadJobResponse requestValidationFromMaster(String filePath, String jobId) {

		return ifvMasterClient.createValidationJobFromPath(filePath, jobId);
	}

	public ValidationJobStatusResponse getJobStatus(String jobId) {

		return ifvMasterClient.getJobStatus(jobId);
	}

	public List<ValidationError> getValidationErrors(String jobId) {

		return ifvMasterClient.getValidationErrors(jobId);
	}
}
