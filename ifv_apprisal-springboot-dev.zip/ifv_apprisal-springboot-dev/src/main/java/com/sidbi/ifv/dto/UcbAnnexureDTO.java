package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class UcbAnnexureDTO {

	private Long id;

	private Long ifvId;

	private String particulars;

	private String remarks;

	private String note;

	private Integer annexureNo;
}
