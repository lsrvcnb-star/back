package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_PRINCIPAL")
public class S2IFVPrincipalEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PL_ID")
	private Long plId;
	
	@Column(name = "PR_ID")
	private Long prId;
	
	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "PL_REPAYMENT")
	private String plRepayment;
	
	@Column(name = "PL_INTPAYMENT")
	private String plIntPayment;
	
	@Column(name = "PL_MONTHS")
	private BigDecimal plMonths;
	
	@Column(name = "pl_period")
	private String plPeriod;
	
	@Column(name = "pl_scheme")
	private String plScheme;
	
}

