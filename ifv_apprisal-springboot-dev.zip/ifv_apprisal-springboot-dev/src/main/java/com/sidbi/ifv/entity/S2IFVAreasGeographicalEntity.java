package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_AREASGEOGRAPHICAL")
public class S2IFVAreasGeographicalEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "AG_ID")
	private Long agId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "AG_STATE")
	private String agState;

	@Column(name = "AG_BRANCH")
	private BigDecimal agBranch;

	@Column(name = "AG_TYPE")
	private String agType;

	@Column(name = "rrb_state_name")
	private String rrbStateName;

}
