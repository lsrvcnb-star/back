package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IfvRefMasterDto {

	private String custCd;

	private String refNo;

	private LocalDateTime refDate;
}
