package com.sidbi.ifv.dto;

import java.util.List;

import lombok.Data;

@Data
public class CommonDTO {

	private SfbCommondtDTO sfbCommondtDTO;

	private List<KycDTO> listKycDto;

	private List<AreasGeographicalDTO> listAreasGeographicalDTO;

	private List<InvestorDTO> listInvestorDTO;

	private SanctionMinutesDTO sanctionMinutesDTO;

	private List<SanctionMinutesDtlDTO> sanctionMinutesDtlDTOs;

	private List<FileRepositoryDTO> fileRepositoryDTOs;
}