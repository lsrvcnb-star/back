package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AssPastdisbDTO;
import com.sidbi.ifv.entity.S2IFVAssPastdisbEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AssPastdisbRepository;
import com.sidbi.ifv.services.AssPastdisbService;

import jakarta.transaction.Transactional;

@Service
public class AssPastdisbServiceImpl implements AssPastdisbService {

	private static final Logger logger = LoggerFactory.getLogger(AssPastdisbServiceImpl.class);
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	AssPastdisbRepository s2IFFCCAssPastdisbRepo;

	String msg = "";

	@Override
	public List<AssPastdisbDTO> findAll() {
		logger.info("findAll() started in AssPastdisbServiceImpl for S2IFVAssPastdisbEntity");
		try {
			List<S2IFVAssPastdisbEntity> list = s2IFFCCAssPastdisbRepo.findAll();
			return list.stream().map(m -> modelMapper.map(m, AssPastdisbDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAssPastdisbEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAssPastdisbEntities." + msg + " ", e);
		}
	}

	@Override
	public AssPastdisbDTO findById(Long id) {
		logger.info("findById() started in AssPastdisbServiceImpl for S2IFVAssPastdisbEntity {}", id);
		try {
			Optional<S2IFVAssPastdisbEntity> s2IffccAssPastdisbEntity = s2IFFCCAssPastdisbRepo.findById(id);
			if (s2IffccAssPastdisbEntity.isPresent()) {
				return modelMapper.map(s2IffccAssPastdisbEntity.get(), AssPastdisbDTO.class);
			} else {
				logger.error("Error Occurred while fetching  S2IFVAssPastdisbEntity entity.");
				throw new EntityNotFoundException("s2IFVAssPastdisbEntity", id);
			}
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAssPastdisbEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching S2IFVAssPastdisbEntity." + msg + " ",
					e);
		}
	}

	@Override
	public AssPastdisbDTO save(AssPastdisbDTO s2IFFCCAssPastdisbDTO) {
		logger.info("createNewAppraisal() started in AssPastdisbServiceImpl for S2IFVAssPastdisbEntity {}",
				s2IFFCCAssPastdisbDTO);
		try {
			S2IFVAssPastdisbEntity s2IffccAssPastdisbEntity = modelMapper.map(s2IFFCCAssPastdisbDTO,
					S2IFVAssPastdisbEntity.class);
			s2IFFCCAssPastdisbRepo.save(s2IffccAssPastdisbEntity);
			return modelMapper.map(s2IffccAssPastdisbEntity, AssPastdisbDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAssPastdisbEntity entities. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAssPastdisbEntity entities." + msg + " ", e);
		}
	}

	@Override
	public AssPastdisbDTO update(Long id, AssPastdisbDTO s2IFFCCAssPastdisbDTO) {
		logger.info("updateIfccApp() started in AssPastdisbServiceImpl for S2IFVAssPastdisbEntity {} {} ", id,
				s2IFFCCAssPastdisbDTO);
		try {
			S2IFVAssPastdisbEntity s2IffccAssPastdisbEntity = s2IFFCCAssPastdisbRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAssPastdisbEntity", id));
			BeanUtils.copyProperties(s2IFFCCAssPastdisbDTO, s2IffccAssPastdisbEntity);
			s2IFFCCAssPastdisbRepo.save(s2IffccAssPastdisbEntity);
			return modelMapper.map(s2IffccAssPastdisbEntity, AssPastdisbDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVAssPastdisbEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVAssPastdisbEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("deleteIfccApp() started in AssPastdisbServiceImpl for S2IFVAssPastdisbEntity {} ", id);
		try {
			S2IFVAssPastdisbEntity s2IffccAssPastdisbEntity = s2IFFCCAssPastdisbRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAssPastdisbEntity", id));
			s2IFFCCAssPastdisbRepo.delete(s2IffccAssPastdisbEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVAssPastdisbEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVAssPastdisbEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<AssPastdisbDTO> saveAll(List<AssPastdisbDTO> listAssPastdisbDTO) {
		logger.info("saveAll() started in AssPastdisbServiceImpl for List of S2IFVAssPastdisbEntity");
		try {
			List<S2IFVAssPastdisbEntity> assPastdisbEntitiesToSave = listAssPastdisbDTO.stream()
					.map(assPastdisbDTO -> modelMapper.map(assPastdisbDTO, S2IFVAssPastdisbEntity.class))
					.collect(Collectors.toList());

			Long ifvId = listAssPastdisbDTO.stream().map(AssPastdisbDTO::getIfvId).findFirst().orElse(null);

			s2IFFCCAssPastdisbRepo.deleteByIfvId(ifvId);

			List<S2IFVAssPastdisbEntity> savedAssPastdisbEntities = s2IFFCCAssPastdisbRepo
					.saveAll(assPastdisbEntitiesToSave);

			return savedAssPastdisbEntities.stream()
					.map(assPastdisbEntity -> modelMapper.map(assPastdisbEntity, AssPastdisbDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVAssPastdisbEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVAssPastdisbEntities." + msg + " ", e);

		}
	}

	@Override
	public List<AssPastdisbDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in AssPastdisbServiceImpl ");
		try {
			List<S2IFVAssPastdisbEntity> listAssPastdisbEntities = s2IFFCCAssPastdisbRepo.findByIfvIdOrderByAeId(ifvId);
			return listAssPastdisbEntities.stream()
					.map(assPastdisbEntity -> modelMapper.map(assPastdisbEntity, AssPastdisbDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAssPastdisbEntities based on IfvId. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAssPastdisbEntities  based on IfvId." + ifvId + " " + msg
							+ " ",
					e);

		}
	}
}
