package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.SanctionMinutesEntity;

public interface SanctionMinutesRepository
		extends JpaRepository<SanctionMinutesEntity, Long>, JpaSpecificationExecutor<SanctionMinutesEntity> {

	Long countByCommiteeCode(Integer committeeCode);

	Long countByCommiteeCodeAndMeetingNo(Integer committeeCode, Integer meetingNo);

	@Query(value = "SELECT "
			+ "COUNT(CASE WHEN sanct_stage = 'APPROVED' AND sanct_stage != 'CLOSED' THEN 1 END) AS approvedCount, "
			+ "COUNT(CASE WHEN sanct_stage != 'APPROVED' AND sanct_stage != 'CLOSED' THEN 1 END) AS nonApprovedCount "
			+ "FROM s2_minutes_sanction", nativeQuery = true)
	StatusCount getStatusCounts();

	interface StatusCount {
		Long getApprovedCount();

		Long getNonApprovedCount();
	}

	@Query(value = "SELECT "
			+ "COUNT(CASE WHEN sanct_stage = 'APPROVED' AND sanct_stage != 'CLOSED' THEN 1 END) AS approvedCount, "
			+ "COUNT(CASE WHEN sanct_stage IN (:sanctStages) THEN 1 END) AS nonApprovedCount "
			+ "FROM s2_minutes_sanction", nativeQuery = true)
	StatusCount getStatusCounts(@Param("sanctStages") List<String> sanctStages);

	@Query(value = "SELECT "
			+ "COUNT(CASE WHEN sanct_stage = 'APPROVED' AND sanct_stage != 'CLOSED' THEN 1 END) AS approvedCount, "
			+ "COUNT(CASE WHEN sanct_stage IN (:sanctStages) AND current_checker_id=:ofrType THEN 1 END) AS nonApprovedCount "
			+ "FROM s2_minutes_sanction", nativeQuery = true)
	StatusCount getStatusCounts(@Param("sanctStages") List<String> sanctStages, @Param("ofrType") Long ofrType);

}
