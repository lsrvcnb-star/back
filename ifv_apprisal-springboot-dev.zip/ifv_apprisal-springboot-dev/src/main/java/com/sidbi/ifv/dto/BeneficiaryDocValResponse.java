package com.sidbi.ifv.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class BeneficiaryDocValResponse {
	private int totalRecords;
	private int validRecords;
	private int invalidRecords;
	private List<BeneficiaryDocValError> errors = new ArrayList<>();

	public void addError(BeneficiaryDocValError error) {
		this.errors.add(error);
	}
}
