package com.sidbi.ifv.dto;

import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class TblIfvModuleFwdDTO {

	private Long fwdStatusId;

	private Long ifvId;

	private Long moduleId;

	private Long appOfficerCode;

	private Long appCurrentOfficerCode;

	private String appStatus;

	private Long appModuleCheckerCode;

	private Date createdModifiedDate;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

	private String ipAddress;

	private Long alCode;

	private String currentFwdCheckerName;

	private String currentFwdCheckerDesg;

	private Integer checker1Id;

	private String checker1Name;

	private String checker1Desg;

	private Integer checker2Id;

	private String checker2Name;

	private String checker2Desg;

	private Integer checker3Id;

	private String checker3Name;

	private String checker3Desg;

	private Integer checker4Id;

	private String checker4Name;

	private String checker4Desg;

	private LocalDateTime lockedDateTime;

	private LocalDateTime checker1FwdDate;

	private LocalDateTime checker2FwdDate;

	private LocalDateTime checker3FwdDate;

	private LocalDateTime approvedDateTime;

	private String lockComment;

	private String checker1Comment;

	private String checker2Comment;

	private String checker3Comment;

	private String checker4Comment;

	private String makerDesignation;

}
