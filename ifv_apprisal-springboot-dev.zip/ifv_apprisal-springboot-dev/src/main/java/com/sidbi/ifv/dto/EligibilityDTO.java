package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class EligibilityDTO {

	private Long ecId;

	private Long ifvId;

	private String ecRemarks;

	private String ecBfsnorms;

	private String ecRemarks1;

	private String ecBfsnorms1;

	private String ecBfnormseligibility;

	private String ecPsbs;

	private String ecSectForEignBank;

	private Date ecNnpaDate;

	private BigDecimal ecNnpaPercent;

	private String ecNnoaRemarks;

	private String ecNnpaStatus;

	private String ecRmseAssistance;

	private String ecRmseStatus;

	private String ecAssstance;

	private String ecAssstanceStatus;

	private String ecRbiCompliance;

	private String ecRbiStatus;

	private Date ecGsecDate;

	private BigDecimal ecGsecPercent;

	private BigDecimal ecSdbiFixed;

	private String ecSidbiRemarks;

	private String ecSidbiStatus;

	private Date ecRmseDate;

	private String ecRmsEmiCrofy;

	private String ecRmseRemarks;

	private String ecRmseStatus1;

	private String ecIcddRemarks;

	private String ecIcddStatus;

	private String ecFabiaRemarks;

	private String ecFabiaStatus;

	private String bankParameter;

	private String rmse1Data;

	private String rmse2Data;

	private String rmse3Data;

	private String rmse4Data;

	private String rmse5Data;

	private String rmse3Remarks;

	private String rmse4Remarks;

	private String rmse5Remarks;

	private String rmse3Status;

	private String rmse4Status;

	private String rmse5Status;
}
