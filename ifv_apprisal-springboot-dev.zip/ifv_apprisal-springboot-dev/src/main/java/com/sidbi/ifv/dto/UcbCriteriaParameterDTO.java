package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class UcbCriteriaParameterDTO {

	private Long id;

	private Long ifvId;

	private String criteriaParameters;

	private Character complied;

	private String compliance;

	private String justification;
	
	private String note;

	private String complianceDate;
}
