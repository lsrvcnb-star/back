package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.dto.PoaSignatureDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.PoaSignatureService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/poa-signature")
public class PoaSignatureController extends CrudController<PoaSignatureDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(PoaSignatureController.class);

	@Autowired
	private PoaSignatureService service;

	@Override
	public CrudService<PoaSignatureDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllByCifNumber/{cifNumber}")
	public ResponseEntity<List<PoaSignatureDTO>> findAllByCifNumber(@PathVariable String cifNumber) {
		logger.info("Started findAllByCifNumber() in PoaSignatureController");
		return ResponseEntity.ok(service.findByCifNumber(cifNumber));
	}

	@PostMapping("/savePoaSignature")
	public ResponseEntity<PoaSignatureDTO> savePoaSignature(
			@RequestParam(value = "files", required = false) MultipartFile[] files, @RequestParam("data") String data)
			throws JsonProcessingException {
		logger.info("Started savePoaSignature() in PoaSignatureController");
		PoaSignatureDTO dto = null;
		ObjectMapper objectMapper = new ObjectMapper();
		dto = objectMapper.readValue(data, PoaSignatureDTO.class);
		return ResponseEntity.ok(service.savePoaSignature(dto, files));
	}

	@GetMapping("/getAllGroupByCifnumber")
	public ResponseEntity<List<PoaSignatureDTO>> getAllGroupByCifnumber() {
		logger.info("Started findAllByCifNumber() in PoaSignatureController");
		return ResponseEntity.ok(service.getAllGroupByCifnumber());
	}

	@PostMapping("/updatePoaSignature")
	public ResponseEntity<PoaSignatureDTO> updatePoaSignature(
			@RequestParam(value = "files", required = false) MultipartFile[] files, @RequestParam("data") String data)
			throws JsonProcessingException {
		logger.info("Started updatePoaSignature() in PoaSignatureController");
		PoaSignatureDTO dto = null;
		ObjectMapper objectMapper = new ObjectMapper();
		dto = objectMapper.readValue(data, PoaSignatureDTO.class);
		return ResponseEntity.ok(service.updatePoaSignature(dto, files));
	}

}