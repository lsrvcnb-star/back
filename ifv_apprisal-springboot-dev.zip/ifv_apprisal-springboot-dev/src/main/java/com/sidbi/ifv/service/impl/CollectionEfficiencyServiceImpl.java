package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.CollectionEfficiencyDTO;
import com.sidbi.ifv.entity.CollectionEfficiencyEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.CollectionEfficiencyRepository;
import com.sidbi.ifv.services.CollectionEfficiencyService;

@Service
public class CollectionEfficiencyServiceImpl implements CollectionEfficiencyService {

	private static final Logger logger = LoggerFactory.getLogger(CollectionEfficiencyServiceImpl.class);

	@Autowired
	private CollectionEfficiencyRepository repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public CollectionEfficiencyDTO findById(Long id) {
		logger.info("findById() started in CollectionEfficiencyServiceImpl for CollectionEfficiencyEntity {} ", id);
		CollectionEfficiencyEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("CollectionEfficiencyEntity", id));
		return mapper.map(entity, CollectionEfficiencyDTO.class);
	}

	@Override
	public List<CollectionEfficiencyDTO> findAll() {
		logger.info("findAll() started in CollectionEfficiencyServiceImpl of CollectionEfficiencyEntity");
		try {
			List<CollectionEfficiencyEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, CollectionEfficiencyDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all CollectionEfficiencyEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all CollectionEfficiencyEntities ." + msg + " ", e);
		}
	}

	@Override
	public CollectionEfficiencyDTO save(CollectionEfficiencyDTO dto) {
		logger.info("save() started in CollectionEfficiencyServiceImpl for CollectionEfficiencyEntity {} ", dto);
		try {
			CollectionEfficiencyEntity entity = mapper.map(dto, CollectionEfficiencyEntity.class);
			repository.save(entity);
			return mapper.map(entity, CollectionEfficiencyDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating CollectionEfficiencyEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  CollectionEfficiencyEntity." + msg + " ", e);
		}
	}

	@Override
	public List<CollectionEfficiencyDTO> saveAll(List<CollectionEfficiencyDTO> dtos) {
		logger.info("saveAll() started in CollectionEfficiencyServiceImpl for List of CollectionEfficiencyEntity");
		try {

			List<CollectionEfficiencyEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, CollectionEfficiencyEntity.class)).collect(Collectors.toList());
			List<CollectionEfficiencyEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, CollectionEfficiencyDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all CollectionEfficiencyEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all CollectionEfficiencyEntities." + msg + " ", e);
		}
	}

	@Override
	public CollectionEfficiencyDTO update(Long id, CollectionEfficiencyDTO dto) {
		logger.info("update() started in CollectionEfficiencyServiceImpl for CollectionEfficiencyEntity {} {} ", id,
				dto);
		try {
			CollectionEfficiencyEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("collectionEfficiencyEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, CollectionEfficiencyDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating CollectionEfficiencyEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating CollectionEfficiencyEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in CollectionEfficiencyServiceImpl for CollectionEfficiencyEntity {} ", id);
		try {
			CollectionEfficiencyEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("collectionEfficiencyEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting CollectionEfficiencyEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting CollectionEfficiencyEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<CollectionEfficiencyDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in CollectionEfficiencyServiceImpl for CollectionEfficiencyEntity {} ",
				ifvId);
		try {

			List<CollectionEfficiencyEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty()) ? list.stream().map(
					collectionEfficiencyEntity -> mapper.map(collectionEfficiencyEntity, CollectionEfficiencyDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId CollectionEfficiencyEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId CollectionEfficiencyEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
