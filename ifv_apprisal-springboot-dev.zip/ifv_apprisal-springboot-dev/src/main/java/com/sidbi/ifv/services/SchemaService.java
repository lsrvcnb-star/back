package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.SchemaDTO;

public interface SchemaService {

	List<SchemaDTO> findAll();

	SchemaDTO findById(Integer id);

	SchemaDTO save(SchemaDTO s2ifccSchemaDTO);

	SchemaDTO update(Integer id, SchemaDTO s2ifccSchemaDTO);
	
	void delete(Integer id);
}
