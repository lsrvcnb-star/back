package com.sidbi.ifv.repo;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.CmtMemberMasterEntity;

public interface CmtMemberMasterRepository extends JpaRepository<CmtMemberMasterEntity, Long> {

	List<CmtMemberMasterEntity> findByCmtCode(Integer cmtCode);

	@Query("SELECT DISTINCT m.memberMailId FROM CmtMemberMasterEntity m WHERE m.memberCode IN :employeeCodes")
	Set<String> findAllMemberMailIdByMemberCode(@Param("employeeCodes") List<String> employeeCodes);

	boolean existsByMemberNameAndCmtCodeAndEnableFlag(String memberName, BigDecimal cmtCode, Character enableFlag);

	boolean existsByCmtCodeAndCmtType(BigDecimal cmtCode, String cmtType);

}