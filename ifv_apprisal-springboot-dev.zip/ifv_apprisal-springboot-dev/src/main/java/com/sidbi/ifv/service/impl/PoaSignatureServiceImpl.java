package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.PoaSignatureDTO;
import com.sidbi.ifv.entity.PoaSignatureEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.PoaSignatureRepository;
import com.sidbi.ifv.services.PoaSignatureService;

import jakarta.transaction.Transactional;

@Service
public class PoaSignatureServiceImpl implements PoaSignatureService {

	private static final Logger logger = LoggerFactory.getLogger(PoaSignatureServiceImpl.class);

	@Autowired
	private PoaSignatureRepository repository;

	String msg = "";

	@Override
	public PoaSignatureDTO findById(Long id) {
		logger.info("findById() started in PoaSignatureServiceImpl for PoaSignatureEntity {} ", id);
		PoaSignatureEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("POASignatureEntity", id));
		return toDTO(entity);
	}

	@Override
	public List<PoaSignatureDTO> findAll() {
		logger.info("findAll() started in PoaSignatureServiceImpl of PoaSignatureEntity");
		try {
			List<PoaSignatureEntity> list = repository.findAll();
			return list.isEmpty() ? new ArrayList<>() : list.stream().map(this::toDTO).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all PoaSignatureEntities .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all PoaSignatureEntities ." + msg + " ",
					e);
		}
	}

	@Override
	public PoaSignatureDTO save(PoaSignatureDTO dto) {
		logger.info("save() started in PoaSignatureServiceImpl for PoaSignatureEntity {} ", dto);
		try {
			PoaSignatureEntity entity = PoaSignatureEntity.fromDTO(dto);
			repository.save(entity);
			return toDTO(entity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating PoaSignatureEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  PoaSignatureEntity." + msg + " ", e);
		}
	}

	@Override
	public List<PoaSignatureDTO> saveAll(List<PoaSignatureDTO> dtos) {
		logger.info("saveAll() started in PoaSignatureServiceImpl for List of PoaSignatureEntity");
		try {
			List<PoaSignatureEntity> entitiesToSave = dtos.stream().map(PoaSignatureEntity::fromDTO)
					.collect(Collectors.toList());

			List<PoaSignatureEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(this::toDTO).collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all PoaSignatureEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all PoaSignatureEntities." + msg + " ",
					e);
		}
	}

	@Override
	public PoaSignatureDTO update(Long id, PoaSignatureDTO dto) {
		logger.info("update() started in PoaSignatureServiceImpl for PoaSignatureEntity {}", id);
		try {
			PoaSignatureEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("PoaSignatureEntity", id));

			existingEntity.setCifNumber(dto.getCifNumber());
			existingEntity.setBankName(dto.getBankName());
			existingEntity.setStartDate(dto.getStartDate());
			existingEntity.setEndDate(dto.getEndDate());
			existingEntity.setFileName(dto.getFileName());
			existingEntity.setFile(dto.getFile());

			PoaSignatureEntity savedEntity = repository.save(existingEntity);
			return toDTO(savedEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error occurred while updating PoaSignatureEntity {} ", msg);
			throw new DatabaseOperationException("Error occurred while updating PoaSignatureEntity " + msg, e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in PoaSignatureServiceImpl for PoaSignatureEntity {} ", id);
		try {
			PoaSignatureEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("poaSignatureEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting PoaSignatureEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting PoaSignatureEntity of id ." + msg + " " + id, e);
		}

	}

	public PoaSignatureDTO toDTO(PoaSignatureEntity entity) {
		PoaSignatureDTO dto = new PoaSignatureDTO();
		dto.setId(entity.getId());
		dto.setCifNumber(entity.getCifNumber());
		dto.setBankName(entity.getBankName());
		dto.setStartDate(entity.getStartDate());
		dto.setEndDate(entity.getEndDate());
		dto.setFile(entity.getFile());
		dto.setFileName(entity.getFileName());
		return dto;
	}

	@Override
	public List<PoaSignatureDTO> findByCifNumber(String cifNumber) {
		logger.info("findByCifNumber() started in PoaSignatureServiceImpl of PoaSignatureEntity");
		try {
			List<PoaSignatureEntity> list = repository.findByCifNumber(cifNumber);
			return !list.isEmpty() ? list.stream().map(this::toDTO).collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing findByCifNumber .{}", msg);
			throw new DatabaseOperationException("Error Occurred while executing findByCifNumber ." + msg + " ", e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public PoaSignatureDTO savePoaSignature(PoaSignatureDTO dto, MultipartFile[] files) {
		logger.info("savePoaSignature() started in PoaSignatureServiceImpl of PoaSignatureEntity");
		try {
			PoaSignatureDTO poaSignatureDTO = dto;
			if (files != null && files.length > 0) {

				List<String> fileStrings = new ArrayList<>();
				List<PoaSignatureDTO> list = findByCifNumber(dto.getCifNumber());
				if (!list.isEmpty()) {
					fileStrings = list.stream().map(PoaSignatureDTO::getFileName).collect(Collectors.toList());
				}
				for (MultipartFile file : files) {
					fileStrings.add(file.getOriginalFilename());
				}

				Map<String, Long> stringCounts = fileStrings.stream()
						.collect(Collectors.groupingBy(str -> str, Collectors.counting()));

				boolean duplicate = stringCounts.values().stream().anyMatch(count -> count > 1);
				if (duplicate) {
					throw new DatabaseOperationException("Files Names Are Duplicated..");
				}

				List<String> fileNames = new ArrayList<>();
				for (MultipartFile file : files) {
					dto.setFile(convertMultipartToByteArray(file));
					dto.setFileName(file.getOriginalFilename());
					PoaSignatureEntity entity = PoaSignatureEntity.fromDTO(dto);
					repository.save(entity);
					fileNames.add(file.getOriginalFilename());
				}
				poaSignatureDTO.setFileNames(fileNames);

			} else {
				PoaSignatureEntity entity = PoaSignatureEntity.fromDTO(dto);
				repository.save(entity);
			}
			return poaSignatureDTO;

		} catch (DatabaseOperationException e) {
			msg = e.getMessage();
			logger.error("Files Names Are Duplicated. {}", msg);
			throw new DatabaseOperationException("Files Names Are Duplicated..." + msg + " ", e);
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while savePoaSignature .{}", msg);
			throw new DatabaseOperationException("Error Occurred while savePoaSignature ." + msg + " ", e);
		}

	}

	private byte[] convertMultipartToByteArray(MultipartFile file) {
		try {
			return file.getBytes();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error while converting multipart to byte[] of file {} ", file.getOriginalFilename());
			throw new DatabaseOperationException("Error while converting multipart to byte[] of file." + msg + " " + e
					+ " " + file.getOriginalFilename());
		}
	}

	@Override
	public List<PoaSignatureDTO> getAllGroupByCifnumber() {
		logger.info("getAllGroupByCifnumber() started in PoaSignatureServiceImpl of PoaSignatureEntity");
		List<String> cifNumbers;
		cifNumbers = repository.getAllCifNumbers();
		logger.info("cifNumbers {} ", cifNumbers);
		List<PoaSignatureDTO> dtos1 = new ArrayList<>();
		try {
			if (cifNumbers != null && !cifNumbers.isEmpty()) {
				dtos1 = cifNumbers.stream().map(cifNumber -> {
					List<PoaSignatureDTO> dtos2 = findByCifNumber(cifNumber);
					if (!dtos2.isEmpty()) {
						PoaSignatureDTO dto = dtos2.get(0);
						List<String> fileNames = dtos2.stream().map(PoaSignatureDTO::getFileName)
								.collect(Collectors.toList());
						dto.setFileNames(fileNames);
						return dto;
					} else {
						return null;
					}
				}).filter(Objects::nonNull).collect(Collectors.toList());
			}
			return dtos1;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while getAllGroupByCifnumber .{}", msg);
			throw new DatabaseOperationException("Error Occurred while getAllGroupByCifnumber ." + msg + " ", e);
		}

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public PoaSignatureDTO updatePoaSignature(PoaSignatureDTO dto, MultipartFile[] files) {

		logger.info("updatePoaSignature() started in PoaSignatureServiceImpl of PoaSignatureEntity");
		try {
			PoaSignatureDTO poaSignatureDTO = dto;
			List<PoaSignatureDTO> list = findByCifNumber(dto.getCifNumber());
			if (files != null && files.length > 0) {

				List<String> fileStrings = new ArrayList<>();

				if (!list.isEmpty()) {
					fileStrings = list.stream().map(PoaSignatureDTO::getFileName).collect(Collectors.toList());
				}
				for (MultipartFile file : files) {
					fileStrings.add(file.getOriginalFilename());
				}

				Map<String, Long> stringCounts = fileStrings.stream()
						.collect(Collectors.groupingBy(str -> str, Collectors.counting()));

				boolean duplicate = stringCounts.values().stream().anyMatch(count -> count > 1);
				if (duplicate) {
					throw new DatabaseOperationException("Files Names Are Duplicated.");
				}

				List<String> fileNames = new ArrayList<>();
				for (MultipartFile file : files) {
					dto.setFile(convertMultipartToByteArray(file));
					dto.setFileName(file.getOriginalFilename());
					PoaSignatureEntity entity = PoaSignatureEntity.fromDTO(dto);
					repository.save(entity);
					fileNames.add(file.getOriginalFilename());
				}
				poaSignatureDTO.setFileNames(fileNames);

			}

			list.forEach(e -> {
				e.setStartDate(dto.getStartDate());
				e.setEndDate(dto.getEndDate());
				PoaSignatureEntity entity = PoaSignatureEntity.fromDTO(e);
				entity.setId(e.getId());
				repository.save(entity);
			});
			return poaSignatureDTO;

		} catch (DatabaseOperationException e) {
			msg = e.getMessage();
			logger.error("Files Names Are Duplicated. {}", msg);
			throw new DatabaseOperationException("Files Names Are Duplicated." + msg + " ", e);
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while savePoaSignature .{}", msg);
			throw new DatabaseOperationException("Error Occurred while savePoaSignature ." + msg + " ", e);
		}

	}
}