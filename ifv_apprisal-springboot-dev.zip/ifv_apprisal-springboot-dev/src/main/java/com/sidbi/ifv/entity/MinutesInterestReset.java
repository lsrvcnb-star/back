package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "s2_minutes_interest_reset")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MinutesInterestReset {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "minute_sanction_id", nullable = false)
	private Integer minuteSanctionId;

	@Column(name = "bank_name", nullable = false, length = 100)
	private String bankName;

	@Column(name = "cif_number", nullable = false, length = 100)
	private String cifNumber;

	@Column(precision = 20, scale = 8)
	private BigDecimal amount;

	@Column(name = "period_in_months")
	private Integer periodInMonths;

	@Column(name = "reset_date")
	private LocalDate resetDate;

	@Column(name = "rate_of_interest", precision = 5, scale = 2)
	private BigDecimal rateOfInterest;

	@Column(name = "cost_of_funds", precision = 5, scale = 2)
	private BigDecimal costOfFunds;

	@Column(name = "reset_due_date", nullable = false)
	private LocalDate resetDueDate;

	@Column(length = 1500)
	private String remarks;

	@Column(name = "created_by", length = 200)
	private String createdBy;

	@Column(name = "created_date", nullable = false)
	private LocalDate createdDate;

	@Column(name = "sanc_status", length = 150)
	private String sancStatus;
}