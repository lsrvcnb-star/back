package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.EligibilityDTO;
import com.sidbi.ifv.entity.S2IFVEligibilityEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.EligibilityRepository;
import com.sidbi.ifv.services.EligibilityService;
import com.sidbi.ifv.util.CommonUtil;

@Service
public class EligibilityServiceImpl implements EligibilityService {

	private static final Logger logger = LoggerFactory.getLogger(EligibilityServiceImpl.class);

	@Autowired
	private EligibilityRepository s2ifccEligibilityRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private CommonUtil commonUtil;

	String msg = "";

	@Override
	public List<EligibilityDTO> findAll() {
		logger.info("findAll() started in EligibilityServiceImpl for S2IFVEligibilityEntity");
		try {
			List<S2IFVEligibilityEntity> list = s2ifccEligibilityRepository.findAll();
			return list.stream().map(ifccsfbcommon -> modelMapper.map(ifccsfbcommon, EligibilityDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVEligibilityEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVEligibilityEntities." + msg + " ", e);
		}
	}

	@Override
	public EligibilityDTO findById(Long id) {
		logger.info("findById() started in EligibilityServiceImpl for S2IFVEligibilityEntity {} ", id);
		try {
			S2IFVEligibilityEntity s2ifccEligibilityEntity = s2ifccEligibilityRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVEligibilityEntity", id));
			return modelMapper.map(s2ifccEligibilityEntity, EligibilityDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFVEligibilityEntity.{} ", msg);
			throw new DatabaseOperationException("Error Occurred while fetching  S2IFVEligibilityEntity." + msg + " ",
					e);
		}
	}

	@Override
	public EligibilityDTO save(EligibilityDTO s2ifccEligibilityDTO) {
		logger.info("save() started in EligibilityServiceImpl for S2IFVEligibilityEntity {} ", s2ifccEligibilityDTO);
		try {
			S2IFVEligibilityEntity s2ifccEligibilityEntity = modelMapper.map(s2ifccEligibilityDTO,
					S2IFVEligibilityEntity.class);
			s2ifccEligibilityRepository.save(s2ifccEligibilityEntity);
			return modelMapper.map(s2ifccEligibilityEntity, EligibilityDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVEligibilityEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVEligibilityEntity." + msg + " ",
					e);
		}
	}

	@Override
	public EligibilityDTO update(Long id, EligibilityDTO s2ifccEligibilityDTO) {
		logger.info("update() started in EligibilityServiceImpl for S2IFVEligibilityEntity {} {} ", id,
				s2ifccEligibilityDTO);
		try {
			S2IFVEligibilityEntity existings2ifccEligibilityEntity = s2ifccEligibilityRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVEligibilityEntity", id));
			BeanUtils.copyProperties(s2ifccEligibilityDTO, existings2ifccEligibilityEntity,
					commonUtil.getNullPropertyNames(s2ifccEligibilityDTO));
			s2ifccEligibilityRepository.save(existings2ifccEligibilityEntity);
			return modelMapper.map(existings2ifccEligibilityEntity, EligibilityDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVEligibilityEntity.{} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVEligibilityEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in EligibilityServiceImpl for S2IFVEligibilityEntity {} ", id);
		try {
			S2IFVEligibilityEntity existings2ifccEligibilityEntity = s2ifccEligibilityRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVEligibilityEntity", id));
			s2ifccEligibilityRepository.delete(existings2ifccEligibilityEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVEligibilityEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVEligibilityEntity of id ." + id + " " + msg + " ", e);
		}

	}

	@Override
	public List<EligibilityDTO> saveAll(List<EligibilityDTO> listEligibilityDTO) {
		logger.info("saveAll() started in EligibilityServiceImpl for List of S2IFVEligibilityEntity");
		try {
			List<S2IFVEligibilityEntity> eligibilityEntitiesToSave = listEligibilityDTO.stream()
					.map(eligibilityDTO -> modelMapper.map(eligibilityDTO, S2IFVEligibilityEntity.class))
					.collect(Collectors.toList());
			List<S2IFVEligibilityEntity> savedEligibilityEntities = s2ifccEligibilityRepository
					.saveAll(eligibilityEntitiesToSave);

			return savedEligibilityEntities.stream()
					.map(eligibilityEntity -> modelMapper.map(eligibilityEntity, EligibilityDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVEligibilityEntities.{} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVEligibilityEntities." + msg + " ", e);
		}
	}

	@Override
	public EligibilityDTO findByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in EligibilityServiceImpl ");
		try {
			Optional<S2IFVEligibilityEntity> listEligibilityEntity = s2ifccEligibilityRepository.findByIfvId(ifvId);
			if (listEligibilityEntity.isPresent()) {
				return modelMapper.map(listEligibilityEntity, EligibilityDTO.class);
			} else {
				return new EligibilityDTO();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVEligibilityEntities based on IfvId.{} {}", ifvId, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVEligibilityEntities  based on IfvId." + ifvId + " " + msg
							+ " ",
					e);

		}
	}
}