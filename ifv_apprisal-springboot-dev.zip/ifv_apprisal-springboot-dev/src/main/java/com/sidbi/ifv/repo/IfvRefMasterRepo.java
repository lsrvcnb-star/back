package com.sidbi.ifv.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.IfvRefMaster;

public interface IfvRefMasterRepo extends JpaRepository<IfvRefMaster, Long> {

}
