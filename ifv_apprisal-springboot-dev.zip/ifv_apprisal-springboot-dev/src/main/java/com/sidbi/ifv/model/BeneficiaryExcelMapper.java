package com.sidbi.ifv.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.BeneficiaryDetailsDTO;

@Component
public class BeneficiaryExcelMapper {

	public List<BeneficiaryDetailsDTO> readExcel(MultipartFile file) throws IOException {

		List<BeneficiaryDetailsDTO> list = new ArrayList<>();

		try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
			Sheet sheet = workbook.getSheetAt(0);

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row == null)
					continue;

				BeneficiaryDetailsDTO dto = new BeneficiaryDetailsDTO();
				dto.setBbdUserId(getString(row.getCell(0)));
				dto.setBbdStateCode(getString(row.getCell(1)));
				dto.setBbdNameOfUnit(getString(row.getCell(2)));
				dto.setBbdPanOfUnit(getString(row.getCell(3)));
				dto.setMobileNoLinkedUrc(getLong(row.getCell(4)));
				dto.setAcctNo(getString(row.getCell(5)));

				list.add(dto);
			}
		}
		return list;
	}

	private String getString(Cell cell) {
		return cell == null ? null : cell.toString().trim();
	}

	private Long getLong(Cell cell) {
		return cell == null ? null : (long) cell.getNumericCellValue();
	}
}