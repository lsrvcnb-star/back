package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class LoITermsConditionsDTO {

	private Long id;

	private Long ifvId;

	private Long prId;

	private Long loiId;

	private Long sancDetailId;

	private Long appraisalMinuteId;

	private String fundCode;

	private String fundName;

	private String schemeCode;

	private String schemeName;

	private String amountInWords;

	private BigDecimal amount;

	private BigDecimal tsRAteInterest;

	private BigDecimal tsTenurePeriod;

	private String tsRoiRepayment;

	private String tsPrincipalRepayment;

	private String tsIntrestPayment;

	private String tsTenureWd;

	private String tsExtent;

	private String tsEligibleMse;

	private String tsEligibleActivities;

	private String tsEventDflt;

	private String tsSecurity;

	private String tsDocumentstion;

	private String tsTimeFrame;

	private String tsDrawalloan;

	private String tsOtherCond;

	private String tsOutstandingAmount;

	private String tsDrawaloan;

	private String tsTermsection;

	private String tsExtraConditions;

	private String tsTenureApprox;

	private String interestType;

	private String benchMark;

	private String spread;

	private String interestReset;

	private String benchMarkNote;

	private String interestResetNote;

}
