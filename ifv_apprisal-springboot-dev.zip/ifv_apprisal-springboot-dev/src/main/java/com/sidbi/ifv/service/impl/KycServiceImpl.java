package com.sidbi.ifv.service.impl;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.KycDTO;
import com.sidbi.ifv.dto.SfbCommondtDTO;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVKycEntity;
import com.sidbi.ifv.entity.S2IFVSfbCommondtEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.KycRepository;
import com.sidbi.ifv.repo.SfbCommondtRepository;
import com.sidbi.ifv.services.KycService;

@Service
public class KycServiceImpl implements KycService {

	private static final Logger logger = LoggerFactory.getLogger(KycServiceImpl.class);

	@Autowired
	private KycRepository kycRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private SfbCommondtRepository sfbCommondtRepository;

	@Autowired
	private ApplicationRepository ifccApplicationRepo;

	String msg = "";

	@Override
	public List<KycDTO> findAll() {
		logger.info("findAll() started in KycServiceImpl for S2IFVKycEntity");
		try {
			List<S2IFVKycEntity> list = kycRepo.findAll();
			return list.stream().map(s -> modelMapper.map(s, KycDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVKycEntity entities. {}", msg);
			throw new DatabaseOperationException(
					" Error Occurred while fetching all S2IFVKycEntity entities " + msg + " ", e);
		}
	}

	@Override
	public KycDTO findById(Long id) {
		logger.info("findById() started in KycServiceImpl for S2IFVKycEntity {} ", id);
		try {

			S2IFVKycEntity kycEntity = kycRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVKycEntity", id));
			return modelMapper.map(kycEntity, KycDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVKycEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVKycEntity entities." + msg + " ", e);
		}
	}

	@Override
	public KycDTO save(KycDTO kycDTO) {
		logger.info("createNewAppraisal() started in KycServiceImpl for S2IFVKycEntity {} ", kycDTO);
		try {
			S2IFVKycEntity kycEntity = modelMapper.map(kycDTO, S2IFVKycEntity.class);
			kycRepo.save(kycEntity);
			return modelMapper.map(kycEntity, KycDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVKycEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVKycEntity entities." + msg + " ", e);
		}
	}

	@Override
	public KycDTO update(Long id, KycDTO kycDTO) {
		logger.info("updateAppraisal() started in KycServiceImpl for S2IFVKycEntity");
		try {
			S2IFVKycEntity kycEntity = kycRepo.findById(id).

					orElseThrow(() -> new EntityNotFoundException("S2IFVKycEntity", id));
			BeanUtils.copyProperties(kycDTO, kycEntity);
			kycRepo.save(kycEntity);
			return modelMapper.map(kycDTO, KycDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Updating all S2IFVKycEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Updating all S2IFVKycEntity entities." + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("deleteAppraisal() started in KycServiceImpl for S2IFVKycEntity");
		try {
			S2IFVKycEntity kycEntity = kycRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVKycEntity", id));
			kycRepo.delete(kycEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleteing S2IFVKycEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleteing S2IFVKycEntity entity of id ." + id + " " + msg + " ", e);

		}
	}

	@Override
	public List<KycDTO> saveAll(List<KycDTO> listKycDTO) {
		logger.info("saveAll() started in KycServiceImpl for List of S2IFVKycEntity");
		try {
			List<S2IFVKycEntity> kycEntitiesToSave = listKycDTO.stream()
					.map(kycDto -> modelMapper.map(kycDto, S2IFVKycEntity.class)).collect(Collectors.toList());
			List<S2IFVKycEntity> savedKycEntities = kycRepo.saveAll(kycEntitiesToSave);

			return savedKycEntities.stream().map(kycEntity -> modelMapper.map(kycEntity, KycDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVKycEntity entities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all S2IFVKycEntity entities." + msg + " ",
					e);

		}
	}

	@Override
	public List<KycDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in KycServiceImpl ");
		try {
			List<S2IFVKycEntity> listkycEntites = kycRepo.findByIfvId(ifvId);
			return listkycEntites.stream().sorted(Comparator.comparing(S2IFVKycEntity::getKycId))
					.map(kycEntity -> modelMapper.map(kycEntity, KycDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVKycEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVKycEntities  based on IfvId." + msg + " ", e);

		}
	}

	@Override
	public CommonDTO saveCommonDTO(CommonDTO commonDTO) {
		logger.info("Started saveCommonDTO() in KycServiceImpl ");
		SfbCommondtDTO sfbCommondtDTO = commonDTO.getSfbCommondtDTO();
		logger.info("sfbCommondtDTO {} ", sfbCommondtDTO);
		List<KycDTO> kycDTOs = commonDTO.getListKycDto();
		logger.info("kycDTOs {} ", kycDTOs);
		try {
			List<S2IFVSfbCommondtEntity> s2ifvSfbCommondtEntities = sfbCommondtRepository
					.findByIfvId(sfbCommondtDTO.getIfvId());

			S2IFVSfbCommondtEntity s2ifvSfbCommondtEntity = (s2ifvSfbCommondtEntities != null
					&& !s2ifvSfbCommondtEntities.isEmpty()) ? s2ifvSfbCommondtEntities.get(0)
							: modelMapper.map(sfbCommondtDTO, S2IFVSfbCommondtEntity.class);
			s2ifvSfbCommondtEntity.setSfbShareportfoliodate(sfbCommondtDTO.getSfbShareportfoliodate());

			s2ifvSfbCommondtEntity.setUcbSegPortfolioDate(sfbCommondtDTO.getUcbSegPortfolioDate());
			s2ifvSfbCommondtEntity.setUcbSeg2PortfolioDate(sfbCommondtDTO.getUcbSeg2PortfolioDate());
			s2ifvSfbCommondtEntity.setUcbSeg2Note(sfbCommondtDTO.getUcbSeg2Note());

			S2IFVSfbCommondtEntity savedS2ifvSfbCommondtEntity = sfbCommondtRepository.save(s2ifvSfbCommondtEntity);
			logger.info("savedS2ifvSfbCommondtEntity {} ", savedS2ifvSfbCommondtEntity);
			List<S2IFVKycEntity> kycEntitiesToSave = kycDTOs.stream()
					.map(kycDto -> modelMapper.map(kycDto, S2IFVKycEntity.class)).collect(Collectors.toList());
			List<S2IFVKycEntity> savedKycEntities = kycRepo.saveAll(kycEntitiesToSave);
			logger.info("savedKycEntities {} ", savedKycEntities);
			CommonDTO commonDTO2 = new CommonDTO();
			commonDTO2.setListKycDto(savedKycEntities.stream()
					.map(kycEntity -> modelMapper.map(kycEntity, KycDTO.class)).collect(Collectors.toList()));
			commonDTO2.setSfbCommondtDTO(modelMapper.map(savedS2ifvSfbCommondtEntity, SfbCommondtDTO.class));
			logger.info("commonDTO2 {} ", commonDTO2);
			return commonDTO2;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing saveCommonDTO. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while executing saveCommonDTO." + msg + " ", e);
		}

	}

	@Override
	public CommonDTO findCommonDTOByIfvId(Long ifvId) {
		logger.info("Started findCommonDTOByIfvId() in KycServiceImpl with ifvId {} ", ifvId);
		try {
			List<S2IFVKycEntity> listkycEntites = kycRepo.findByIfvId(ifvId);
			logger.info("listkycEntites {} ", listkycEntites);
			List<S2IFVSfbCommondtEntity> listS2IFVSfbCommondtEntities = sfbCommondtRepository.findByIfvId(ifvId);
			SfbCommondtDTO sfbCommondtDTO = listS2IFVSfbCommondtEntities.stream().findFirst()
					.map(s2IFVSfbCommondtEntity -> modelMapper.map(s2IFVSfbCommondtEntity, SfbCommondtDTO.class))
					.orElse(null);
			logger.info("sfbCommondtDTO {}", sfbCommondtDTO);
			CommonDTO commonDTO = new CommonDTO();
			commonDTO.setSfbCommondtDTO(sfbCommondtDTO);
			commonDTO.setListKycDto(listkycEntites.stream().sorted(Comparator.comparing(S2IFVKycEntity::getKycId))
					.map(kycEntity -> modelMapper.map(kycEntity, KycDTO.class)).collect(Collectors.toList()));
			logger.info("commonDTO {}", commonDTO);
			return commonDTO;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing findCommonDTOByIfvId based on IfvId. {} {} ", msg, ifvId);
			throw new DatabaseOperationException(
					"Error Occurred while executing findCommonDTOByIfvId  based on IfvId." + msg + " " + ifvId + " ",
					e);

		}

	}

	@Override
	public CommonDTO findCommonDTOByIfvIdOrCifNumber(Long ifvId, String cifNumber) {
		logger.info("Started findCommonDTOByIfvIdOrCifNumber() in KycServiceImpl with ifvId {} ", ifvId);
		try {
			List<S2IFVKycEntity> listkycEntites = kycRepo.findByIfvId(ifvId);
			logger.info("listkycEntites {} ", listkycEntites);

			if (listkycEntites.isEmpty()) {
				Optional<S2IFVApplicationEntity> applicationEntity = ifccApplicationRepo
						.findSecondHighestByCifNumber(cifNumber);
				if (applicationEntity.isPresent()) {
					listkycEntites = kycRepo.findByIfvId(applicationEntity.get().getIfvId());
					listkycEntites = listkycEntites.stream().sorted(Comparator.comparing(S2IFVKycEntity::getKycId))
							.collect(Collectors.toList());
					listkycEntites.forEach(e -> {
						e.setIfvId(null);
						e.setKycId(null);
					});
				}
			}

			List<S2IFVSfbCommondtEntity> listS2IFVSfbCommondtEntities = sfbCommondtRepository.findByIfvId(ifvId);
			if (listS2IFVSfbCommondtEntities.isEmpty()) {

				Optional<S2IFVApplicationEntity> applicationEntity = ifccApplicationRepo
						.findSecondHighestByCifNumber(cifNumber);
				if (applicationEntity.isPresent()) {
					listS2IFVSfbCommondtEntities = sfbCommondtRepository
							.findByIfvId(applicationEntity.get().getIfvId());
					listS2IFVSfbCommondtEntities.forEach(e -> {
						e.setIfvId(null);
						e.setSfbId(null);
					});
				}
			}

			SfbCommondtDTO sfbCommondtDTO = listS2IFVSfbCommondtEntities.stream().findFirst()
					.map(s2IFVSfbCommondtEntity -> modelMapper.map(s2IFVSfbCommondtEntity, SfbCommondtDTO.class))
					.orElse(null);
			logger.info("sfbCommondtDTO {}", sfbCommondtDTO);
			CommonDTO commonDTO = new CommonDTO();
			commonDTO.setSfbCommondtDTO(sfbCommondtDTO);
			commonDTO.setListKycDto(listkycEntites.stream().map(kycEntity -> modelMapper.map(kycEntity, KycDTO.class))
					.collect(Collectors.toList()));
			logger.info("commonDTO {}", commonDTO);
			return commonDTO;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing findCommonDTOByIfvIdOrCifNumber based on IfvId. {} {} ", msg,
					ifvId);
			throw new DatabaseOperationException(
					"Error Occurred while executing findCommonDTOByIfvIdOrCifNumber  based on IfvId." + msg + " "
							+ ifvId + " ",
					e);

		}

	}
}
