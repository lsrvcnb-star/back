package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="S2_IFV_TERMCONDITIONS_DATA")
public class S2IFVTermConditionsDataEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TS_ID")
	private Long tsId;
	
	@Column(name = "IFV_ID")
	private Long ifvId;
	
	@Column(name = "TS_UPFRONTFEE")
	private String tsUpfrontFee;
	
	@Column(name = "TS_MONTHS")
	private BigDecimal tsMonths;
	
	@Column(name = "TS_DISBURSEMENT")
	private String tsDisbursement;
	
	@Column(name = "TS_SPECIFIC")
	private String tsSpecific;
	
	@Column(name = "TS_BORROWERS")
	private String tsBorrowers;
	
	@Column(name = "TS_RAMPE")
	private String tsRampe;
	
	@Column(name = "TS_FABIA")
	private String tsFabia;
	
	@Column(name = "TS_TERMSANCTION")
	private String tsTermSanction;
	
	@Column(name = "TS_VALIDITYSANCTION")
	private String tsValiditySanction;
	
	@Column(name = "TS_DOP_SANCTION")
	private String tsDopSanction;
	
	@Column(name = "TS_DOP_RELAXTION")
	private String tsDopRelaxtion;
	
	@Column(name = "TS_RECOMMENDATION")
	private String tsRecommendation;
	
	@Column(name = "TS_FACILITYAMOUNT")
	private String tsFacilityAmount;
	
	@Column(name = "TS_RATEINTEREST")
	private BigDecimal tsRAteInterest;
	
	@Column(name = "TS_TENURE_PERIOD")
	private BigDecimal tsTenurePeriod;
	
	@Column(name = "TS_ROI_REPAYMENT")
	private String tsRoiRepayments;
	
	@Column(name = "TS_PRINCIPAL_REPAYMENT")
	private String tsPrincipalRepayment;
	
	@Column(name = "TS_INTEREST_PAYMENT")
	private String tsIntrestPayment;
	
	@Column(name = "TS_TENURE_WD")
	private String tsTenureWd;
	
	@Column(name = "TS_EXTENT")
	private String tsExtent;
	
	@Column(name = "TS_ELIGIBLEMSE")
	private String tsEligibleMse;
	
	@Column(name = "TS_ELIGIBLEACTIVITIES")
	private String tsEligibleActivities;
	
	@Column(name = "TS_EVENTDFLT")
	private String tsEventDflt;
	
	@Column(name = "TS_SECURITY")
	private String tsSecurity;
	
	@Column(name = "TS_DOCUMENTSTION")
	private String tsDocumentstion;
	
	@Column(name = "TS_TIMEFRAME")
	private String tsTimeFrame;
	
	@Column(name = "TS_DRAWALLOAN")
	private String tsDrawalloan;
	
	@Column(name = "TS_OTHERCOND")
	private String tsOtherCond;
	
	@Column(name = "TS_OUTSTANDINGAMOUNT")
	private String tsOutstandingAmount;
	
	@Column(name = "TS_DRAWALOAN")
	private String tsDrawaloan;
	
	@Column(name = "TS_TERMSECTION")
	private String tsTermsection;

}