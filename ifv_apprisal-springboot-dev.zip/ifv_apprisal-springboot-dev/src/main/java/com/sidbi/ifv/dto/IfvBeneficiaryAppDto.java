package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IfvBeneficiaryAppDto {

	private Long id;

	private String bnRefNo;

	private String fileName;

	private String filePath;

	private String fileType;

	private LocalDateTime uploadDateTime;

	private String uploadBy;

	private String remarks;
}
