package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.PrincipalDTO;

public interface PrincipalService {

	List<PrincipalDTO> findAll();

	PrincipalDTO findById(Long id);

	PrincipalDTO save(PrincipalDTO s2ifccPrincipalDTO);

	PrincipalDTO update(Long id, PrincipalDTO s2ifccPrincipalDTO);
	
	void delete(Long id);

	List<PrincipalDTO> saveAll(List<PrincipalDTO> listPrincipalDTO);

	List<PrincipalDTO> findAllByIfvId(Long ifvId);

}