package com.sidbi.ifv.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sidbi.ifv.entity.IfvBeneficiaryApp;

public interface IfvBeneficiaryAppRepo
		extends JpaRepository<IfvBeneficiaryApp, Long>, JpaSpecificationExecutor<IfvBeneficiaryApp> {

}
