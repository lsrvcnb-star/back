package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "IFV_BANK_REFINANCE_PROPOSAL")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IfvBankRefinanceProposal {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "APPLICATION_ID", nullable = false)
	private Long applicationId;

	@Column(name = "REFINANCE_AMOUNT", precision = 18, scale = 2)
	private BigDecimal refinanceAmount;

	@Column(name = "RATE_TYPE", length = 50)
	private String rateType;

	@Column(name = "RATE_OF_INTEREST", precision = 12, scale = 4)
	private BigDecimal rateOfInterest;

	@Column(name = "BENCHMARK", length = 200)
	private String benchmark;

	@Column(name = "SPREAD", precision = 12, scale = 4)
	private BigDecimal spread;

	@Column(name = "TENURE_IN_MONTHS")
	private Integer tenureInMonths;

	@Column(name = "TENURE_IN_DAYS")
	private Integer tenureInDays;

	@Column(name = "INTEREST_RESET", length = 100)
	private String interestReset;

	@Column(name = "PRINCIPAL_REPAYMENT", length = 200)
	private String principalRepayment;

	@Column(name = "MORATORIUM_MONTHS")
	private Integer moratoriumMonths;

	@Column(name = "MATURITY_DATE")
	private LocalDate maturityDate;
}
