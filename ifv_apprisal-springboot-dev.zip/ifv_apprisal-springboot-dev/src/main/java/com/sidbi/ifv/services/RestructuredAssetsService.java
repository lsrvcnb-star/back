package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.RestructuredAssetsDTO;

public interface RestructuredAssetsService extends CrudService<RestructuredAssetsDTO, Long> {

	List<RestructuredAssetsDTO> findAllByIfvId(Long ifvId);
	
}
