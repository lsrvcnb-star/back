package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;

public interface TblIfvModuleFwdService {

	TblIfvModuleFwdDTO findById(Long id);

	TblIfvModuleFwdDTO save(TblIfvModuleFwdDTO tblIfvModuleFwdDTO);

	TblIfvModuleFwdDTO update(Long id, TblIfvModuleFwdDTO tblIfvModuleFwdDTO);

	void delete(Long id);

	List<TblIfvModuleFwdDTO> findAll();

	TblIfvModuleFwdDTO findByIfvId(Long id);
	
	List<TblIfvModuleFwdDTO> findAllByAppStatusAndIfvId(String appStatus);
	
	List<TblIfvModuleFwdDTO> findAllByAppStatusAndAlCode(String appStatus);
	
	TblIfvModuleFwdDTO findByAlCode(Long alCode);
	
	List<TblIfvModuleFwdDTO>  findByIfvIdIn(List<Long> ids);
}
