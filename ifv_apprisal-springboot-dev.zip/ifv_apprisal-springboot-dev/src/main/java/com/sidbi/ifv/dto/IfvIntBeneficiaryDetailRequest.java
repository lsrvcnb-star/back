package com.sidbi.ifv.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IfvIntBeneficiaryDetailRequest {

	private String jobId;
	private String bbdUserId;
	private String loanAccountNo;
	private String benPreDisbFlag;
	private String benRefNo;
	private String filePath;
	private LocalDateTime refDate;
	private String disbDate;
	private String cifNumber;
}
