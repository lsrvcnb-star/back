package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.entity.TblIfvModuleFwdEntity;
import com.sidbi.ifv.enums.UserTypeEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.IfvApiUsersRepo;
import com.sidbi.ifv.repo.TblIfvModuleFwdRepository;
import com.sidbi.ifv.services.IfvApiUsersService;
import com.sidbi.ifv.util.CommonUtil;

@Service
public class IfvApiUsersServiceImpl implements IfvApiUsersService {

	private static final Logger logger = LoggerFactory.getLogger(IfvApiUsersServiceImpl.class);

	@Autowired
	private IfvApiUsersRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private TblIfvModuleFwdRepository ifvModuleFwdRepository;

	@Autowired
	private IfvApiUsersRepo ifvApiUsersRepo;

	@Override
	public IfvApiUsersDTO findById(Integer id) {
		logger.info("findById() started in IfvApiUsersServiceImpl for IfvApiUsersEntity {} ", id);
		IfvApiUsersEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("IfvApiUsersEntity", id));
		return mapper.map(entity, IfvApiUsersDTO.class);
	}

	@Override
	public List<IfvApiUsersDTO> findAll() {
		logger.info("findAll() started in IfvApiUsersServiceImpl of IfvApiUsersEntity");
		try {
			List<IfvApiUsersEntity> list = repository.findAll();
			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparing(IfvApiUsersEntity::getOfrCode).reversed())
							.map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all entities {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all data" + msg + " ", e);
		}
	}

	@Override
	public IfvApiUsersDTO save(IfvApiUsersDTO dto) {
		logger.info("save() started in IfvApiUsersServiceImpl for IfvApiUsersEntity {} ", dto);
		try {
			dto.setCreatedDate(new Date());
			dto.setOfrUserActive("Y");
			dto.setOfrCreateStatus("FN");
			IfvApiUsersEntity existEntity = repository.findByOfrEmpId(dto.getOfrEmpId());
			if (existEntity != null) {
				logger.info("User Exists with Emp Id {} ", dto.getOfrEmpId());
				throw new DatabaseOperationException("User Exists with Emp Id " + dto.getOfrEmpId());
			} else {
				IfvApiUsersEntity entity = mapper.map(dto, IfvApiUsersEntity.class);
				repository.save(entity);
				return mapper.map(entity, IfvApiUsersDTO.class);
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating IfvApiUsersEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  IfvApiUsersEntity." + msg + " ", e);
		}
	}

	@Override
	public List<IfvApiUsersDTO> saveAll(List<IfvApiUsersDTO> dtos) {
		logger.info("saveAll() started in IfvApiUsersServiceImpl for List of IfvApiUsersEntity");
		try {

			List<IfvApiUsersEntity> entitiesToSave = dtos.stream().map(dto -> mapper.map(dto, IfvApiUsersEntity.class))
					.collect(Collectors.toList());
			List<IfvApiUsersEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, IfvApiUsersDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all IfvApiUsersEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all IfvApiUsersEntities." + msg + " ", e);
		}
	}

	@Override
	public IfvApiUsersDTO update(Integer id, IfvApiUsersDTO dto) {
		logger.info("update() started in IfvApiUsersServiceImpl for IfvApiUsersEntity {} {} ", id, dto);
		try {
			dto.setOfrName(null);
			dto.setModifiedDate(new Date());
			IfvApiUsersEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("ifvApiUsersEntity", id));
			BeanUtils.copyProperties(dto, existingEntity, commonUtil.getNullPropertyNames(dto));
			repository.save(existingEntity);
			return mapper.map(existingEntity, IfvApiUsersDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating IfvApiUsersEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating IfvApiUsersEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Integer id) {
		logger.info("delete() started in IfvApiUsersServiceImpl for IfvApiUsersEntity {} ", id);
		try {
			IfvApiUsersEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("ifvApiUsersEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting IfvApiUsersEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting IfvApiUsersEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<IfvApiUsersDTO> findAllOnEmpIds(List<String> empIds) {
		logger.info("findAllOnEmpIds() started in IfvApiUsersServiceImpl for IfvApiUsersEntity {} ", empIds);
		try {
			List<IfvApiUsersEntity> list = repository.findAllByOfrEmpIdIn(empIds);
			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparing(IfvApiUsersEntity::getOfrCode).reversed())
							.map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing findAllOnEmpIds .{}", msg);
			throw new DatabaseOperationException("Error Occurred while executing findAllOnEmpIds ." + msg + " ", e);
		}
	}

	@Override
	public List<IfvApiUsersDTO> findAllByOfrType(String ofrType) {
		logger.info("findAllByOfrType() started in IfvApiUsersServiceImpl of IfvApiUsersEntity");
		try {
			List<IfvApiUsersEntity> list = repository.findAllByOfrType(ofrType);
			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparing(IfvApiUsersEntity::getOfrCode).reversed())
							.map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all data : {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all entities :" + msg + " ", e);
		}
	}

	@Override
	public List<IfvApiUsersDTO> getCheckerListForForwarding(Long ifvId, Long ofrCode) {
		logger.info("getCheckerListForForwarding() started in IfvApiUsersServiceImpl of IfvApiUsersEntity");
		try {

			List<String> lUserType = new ArrayList<>();

			IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo.findByOfrCode(ofrCode.intValue());

			switch (apiUsersEntity.getOfrDesgCode().intValue()) {

			case 41:
			case 229:
				lUserType = Arrays.asList(UserTypeEnum.CHECKER.getUserType(), UserTypeEnum.ADMIN_CHECKER.getUserType(),
						UserTypeEnum.CHECKER_CONVENOR.getUserType(), UserTypeEnum.MAKER_CONVENER.getUserType(),
						UserTypeEnum.HIGHER_AUTHORITY.getUserType());
				break;

			case 26:
				lUserType = Arrays.asList(UserTypeEnum.CHECKER_CONVENOR.getUserType(),
						UserTypeEnum.MAKER_CONVENER.getUserType(), UserTypeEnum.HIGHER_AUTHORITY.getUserType());
				break;

			case 20:
				lUserType = Arrays.asList(UserTypeEnum.CHECKER_CONVENOR.getUserType(),
						UserTypeEnum.HIGHER_AUTHORITY.getUserType());
				break;

			case 12:
				lUserType = Arrays.asList(UserTypeEnum.HIGHER_AUTHORITY.getUserType());
				break;

			default:
				break;
			}

			List<IfvApiUsersEntity> list = repository.findAllByOfrTypeIn(lUserType);

			Predicate<IfvApiUsersEntity> predicate = entity -> entity.getOfrUserActive() != null
					&& entity.getOfrUserActive().equalsIgnoreCase("Y");

			return !list.isEmpty()
					? list.stream().filter(predicate)
							.sorted(Comparator.comparing(IfvApiUsersEntity::getOfrCode).reversed())
							.map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IfvApiUsersDTO .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all IfvApiUsersDTO ." + msg + " ", e);
		}
	}

	@Override
	public List<IfvApiUsersDTO> getCheckerListForSendBack(Long ifvId, Long ofrCode) {
		logger.info("getCheckerListForSendBack() started in IfvApiUsersServiceImpl of IfvApiUsersEntity");
		try {

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByIfvId(ifvId);

			List<Long> checkerIds = new ArrayList<>();

			IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo.findByOfrCode(ofrCode.intValue());

			long fwdOfrCode = fwdEntity.getAppOfficerCode().longValue();

			switch (apiUsersEntity.getOfrDesgCode().intValue()) {

			case 26:
				checkerIds.add(fwdOfrCode);
				break;

			case 20:
				checkerIds.add(fwdOfrCode);
				if (fwdEntity.getChecker1Id() != null) {
					checkerIds.add(fwdEntity.getChecker1Id().longValue());
				}

				break;

			case 12:
				checkerIds.add(fwdOfrCode);
				if (fwdEntity.getChecker1Id() != null) {
					checkerIds.add(fwdEntity.getChecker1Id().longValue());
				}
				if (fwdEntity.getChecker2Id() != null) {
					checkerIds.add(fwdEntity.getChecker2Id().longValue());
				}
				break;

			case 9:
				checkerIds.add(fwdOfrCode);
				if (fwdEntity.getChecker1Id() != null) {
					checkerIds.add(fwdEntity.getChecker1Id().longValue());
				}
				if (fwdEntity.getChecker2Id() != null) {
					checkerIds.add(fwdEntity.getChecker2Id().longValue());
				}
				if (fwdEntity.getChecker3Id() != null) {
					checkerIds.add(fwdEntity.getChecker3Id().longValue());
				}

				break;

			default:
				break;
			}

			List<IfvApiUsersEntity> list = repository.findByOfficerCode(checkerIds);

			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparing(IfvApiUsersEntity::getOfrCode).reversed())
							.map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IfvApiUsersDTO : {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all IfvApiUsersDTO:" + msg + " ", e);
		}
	}

	@Override
	public List<IfvApiUsersDTO> findAllCheckers() {

		logger.info("findAllCheckers() started in IfvApiUsersServiceImpl of IfvApiUsersEntity");
		try {

			List<String> lUserType = Arrays.asList(UserTypeEnum.CHECKER.getUserType(),
					UserTypeEnum.ADMIN_CHECKER.getUserType(), UserTypeEnum.CHECKER_CONVENOR.getUserType(),
					UserTypeEnum.MAKER_CONVENER.getUserType(), UserTypeEnum.HIGHER_AUTHORITY.getUserType());

			List<IfvApiUsersEntity> list = repository.findAllByOfrTypeIn(lUserType);

			Predicate<IfvApiUsersEntity> predicate = entity -> entity.getOfrUserActive() != null
					&& entity.getOfrUserActive().equalsIgnoreCase("Y");

			return !list.isEmpty()
					? list.stream().filter(predicate)
							.sorted(Comparator.comparing(IfvApiUsersEntity::getOfrCode).reversed())
							.map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IfvApiUsersEntities .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all IfvApiUsersEntities ." + msg + " ",
					e);
		}

	}

	@Override
	public List<IfvApiUsersDTO> findAllOnOfrCode(List<Integer> ofrCode) {
		logger.info("findAllOnOfrCode() started in IfvApiUsersServiceImpl of IfvApiUsersEntity");
		try {
			List<IfvApiUsersEntity> list = repository.findAllByOfrCodeIn(ofrCode);
			return !list.isEmpty()
					? list.stream().map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IfvApiUsersEntities .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all IfvApiUsersEntities ." + msg + " ",
					e);
		}
	}

}