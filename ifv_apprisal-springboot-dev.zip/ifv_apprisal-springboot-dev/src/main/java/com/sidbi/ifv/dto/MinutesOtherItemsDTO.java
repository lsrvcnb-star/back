package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MinutesOtherItemsDTO {

	private Long id;
	private String bankName;
	private String cifNumber;
	private String remarks;
	private String sancStatus;
}
