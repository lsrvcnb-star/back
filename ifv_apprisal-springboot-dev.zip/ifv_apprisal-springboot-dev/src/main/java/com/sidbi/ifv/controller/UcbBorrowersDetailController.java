package com.sidbi.ifv.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.UcbBorrowersDetailDto;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.UcbBorrowersDetailService;

@RestController
@CrossOrigin
@RequestMapping("/ucb-borrowers-details")
public class UcbBorrowersDetailController extends CrudController<UcbBorrowersDetailDto, Long> {

	private static final Logger logger = LoggerFactory.getLogger(UcbBorrowersDetailController.class);

	@Autowired
	private UcbBorrowersDetailService service;

	@Override
	public CrudService<UcbBorrowersDetailDto, Long> getCrudService() {
		return service;
	}

	@GetMapping("/findByIfvId/{ifvId}")
	public ResponseEntity<UcbBorrowersDetailDto> findByIfvId(@PathVariable Long ifvId) {
		logger.info("findByIfvId() started in UcbBorrowersDetailController ");
		UcbBorrowersDetailDto dto = service.findByIfvId(ifvId);
		return ResponseEntity.ok(dto);
	}
}
