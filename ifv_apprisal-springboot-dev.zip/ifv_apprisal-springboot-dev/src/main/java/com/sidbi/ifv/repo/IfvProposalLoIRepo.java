package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sidbi.ifv.entity.IfvProposalLoI;

public interface IfvProposalLoIRepo
		extends JpaRepository<IfvProposalLoI, Long>, JpaSpecificationExecutor<IfvProposalLoI> {

	List<IfvProposalLoI> findAllByIfvId(Long ifvId);

	IfvProposalLoI findTop1ByIfvNameOrderByIdDesc(String ifvName);

}
