package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "IFV_LOI_DOCUMENTS")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IfvLoiDocuments {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "LOI_DETAILS_ID", nullable = false)
	private Long loiDetailsId;

	@Column(name = "IFV_APP_NO", nullable = false)
	private String ifvAppNo;

	@Column(name = "BANK_REF_NO")
	private String bankRefNo;

	@Column(name = "BANK_NAME")
	private String bankName;

	@Column(name = "CIF_NUMBER")
	private String cifNumber;

	@Column(name = "SCHEME")
	private String scheme;

	@Column(name = "SANCTION_AMOUNT")
	private BigDecimal sanctionAmount;

	@Column(name = "SANCTIONED_DATE_TIME")
	private LocalDateTime sanctionedDateTime;

	@Column(name = "LOI_NO")
	private String loiNo;

	@Column(name = "FILE_NAME")
	private String fileName;

	@Column(name = "FILE_PATH")
	private String filePath;

	@Column(name = "FILE_SIZE")
	private Long fileSize;

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "UPLOADED_BY")
	private String uploadedBy;

	@Column(name = "UPLOADED_DATE")
	private LocalDateTime uploadedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private LocalDateTime modifiedDate;

	@Column(name = "REMARKS")
	private String remarks;
	
	@Column(name = "COUNTER_FILE_NAME")
	private String counterFileName;

	@Column(name = "COUNTER_FILE_PATH")
	private String counterFilePath;

	@Column(name = "COUNTER_UPLOADED_BY")
	private String counterUploadedBy;

	@Column(name = "COUNTER_UPLOADED_DATE")
	private LocalDateTime counterUploadedDate;

	@Column(name = "COUNTER_REMARKS")
	private String counterRemarks;
}