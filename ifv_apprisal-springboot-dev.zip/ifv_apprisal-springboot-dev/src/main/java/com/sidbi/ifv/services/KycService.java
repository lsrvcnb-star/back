package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.KycDTO;

public interface KycService {

	List<KycDTO> findAll();

	KycDTO findById(Long id);

	KycDTO save(KycDTO kycDTO);

	KycDTO update(Long id, KycDTO kycDTO);

	void delete(Long id);
	
	List<KycDTO> saveAll(List<KycDTO> listKycDTO);

	List<KycDTO> findAllByIfvId(Long ifvId);

	CommonDTO saveCommonDTO(CommonDTO commonDTO);

	CommonDTO findCommonDTOByIfvId(Long ifvId);

	CommonDTO findCommonDTOByIfvIdOrCifNumber(Long ifvId, String cifNumber);

}
