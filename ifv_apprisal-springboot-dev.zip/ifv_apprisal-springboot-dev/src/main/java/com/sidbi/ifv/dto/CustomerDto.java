package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class CustomerDto {
	private String cname;

	private String custCd;
}
