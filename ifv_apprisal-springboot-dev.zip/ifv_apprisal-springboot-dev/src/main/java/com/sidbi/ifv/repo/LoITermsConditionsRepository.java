package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.LoITermsConditionsEntity;

public interface LoITermsConditionsRepository extends JpaRepository<LoITermsConditionsEntity, Long> {

	List<LoITermsConditionsEntity> findByIfvId(Long ifvId);

	List<LoITermsConditionsEntity> findAllByIfvIdAndPrId(Long ifvId, Long prId);

	LoITermsConditionsEntity findByIfvIdAndPrId(Long ifvId, Long prId);

	void deleteByPrId(Long prId);

	List<LoITermsConditionsEntity> findByloiId(Long loiId);

	LoITermsConditionsEntity findByloiIdAndPrId(Long loiId, Long prId);

}