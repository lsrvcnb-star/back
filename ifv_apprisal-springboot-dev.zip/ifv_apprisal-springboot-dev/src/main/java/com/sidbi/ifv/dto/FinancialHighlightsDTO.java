package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class FinancialHighlightsDTO {

	private Long fhId;

	private Long ifvId;

	private BigDecimal fhFyMarch31;

	private BigDecimal fhFyResults;

	private String fhParticular;

	private BigDecimal fhFy1;

	private BigDecimal fhFy2;

	private BigDecimal fhYoy;

	private BigDecimal fhFy3;

	private String fhFinperformance;

	private Date fhLcrDate;

	private BigDecimal fhLcrValue;

	private String fhAssestProfile;

	private String fhLiabilities;

	private String fhProfitabilities;

	private String fhEqulity;

	private String fhDisclosure;

	private String fhCollection;

	private BigDecimal fhEfficiency;

	private Date fhEfficiencyDate;

	private String fhStatutory;

	private String fhStatus;

	private Integer currentYearValue;

	private Integer previousYearValue;

	private String months;

	private String fhHighlights;

	private String financialPerformanceYear1;

	private String financialPerformance2;

	private String financialPerformanceYear2;

	private String highlightsValue;

	private Date highlightsDate;

	private String rbiGuidelines;

	private String restructuredAsset;

	private String restructuredAssetFlag;

	private String fyEndedAudit;

	private String fyResultAudit;
}
