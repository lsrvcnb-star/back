package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_SANCTION_DT")
public class IfvSanctionDetailsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "BNL_REQUEST_NO")
	private String bnlRequestNo;

	@Column(name = "BNA_APPL_AMT")
	private BigDecimal bnaApplAmt;

	@Column(name = "BNA_APPL_SUBMIT_DT")
	private Date bnaApplSubmitDt;

	@Column(name = "BNA_APPL_PROJ_DESC")
	private String bnaApplProjDesc;

	@Column(name = "BNA_SANC_REMARKS")
	private String bnaSancRemarks;

	@Column(name = "BNA_PRJCT_COST")
	private BigDecimal bnaPrjctCost;

	@Column(name = "BNA_SANC_AUTH")
	private String bnaSancAuth;

	@Column(name = "BNL_CUST_CD")
	private String bnlCustCd;

	@Column(name = "BNL_SANCT_DT")
	private Date bnlSanctDt;

	@Column(name = "BNL_SANCT_AMT")
	private BigDecimal bnlSanctAmt;

	@Column(name = "BNL_DOC_RATE")
	private BigDecimal bnlDocRate;

	@Column(name = "BNL_FI_RATE")
	private BigDecimal bnlFiRate;

	@Column(name = "BNL_LD_RATE")
	private BigDecimal bnlLdRate;

	@Column(name = "BNL_INT_FREQ")
	private String bnlIntFreq;

	@Column(name = "BNL_FUND_CD")
	private String bnlFundCd;

	@Column(name = "BNL_CUT_OFF_DT")
	private Date bnlCutOffDate;

	@Column(name = "BNL_SCH_CD")
	private String bnlSchCd;

	@Column(name = "BNL_MORATORIUM")
	private BigDecimal bnlMoratorium;

	@Column(name = "BNL_CURRENCY")
	private String bnlCurrency;

	@Column(name = "BNL_DEALWISE_AVERAGE")
	private BigDecimal bnlDealwiseAverage;

	@Column(name = "BNL_INCREMENT_COST_BORROW")
	private BigDecimal bnlIncrementCostBorrow;

	@Column(name = "BNA_SL_ACCT_NO")
	private String bnlSlAcctNo;

	@Column(name = "BNA_APPL_NO")
	private String bnaApplNo;

	@Column(name = "BNL_STATUS")
	private String bnlStatus;

	@Column(name = "BNL_SR_NO")
	private Long bnlSrNo;

	@Column(name = "LOI_NO")
	private String loiNo;

	@Column(name = "LOI_DATE")
	private Date loiDate;

	@Column(name = "BNL_INTEREST_TYPE")
	private String bnlInterestType;

	@Column(name = "BNL_BENCHMARK")
	private String bnlBenchmark;

	@Column(name = "BNL_SPREAD")
	private String bnlSpread;

	@Column(name = "BNL_INTEREST_RESET")
	private String bnlInterestReset;

	@Column(name = "BNL_MATURITY_DATE")
	private Date bnlMaturityDate;

	@Column(name = "BNL_PRINCIPAL_REPAYMENT")
	private String bnlPrincipalRepayment;

	@Column(name = "BNL_TENURE")
	private Integer bnlTenure;

	@Column(name = "TRANCHE")
	private BigDecimal tranche;

	@Column(name = "incremental_cost_borrowing_type")
	private String incrementalCostBorrowingType;

	@Column(name = "icb_fixed_floating")
	private String icbFixedFloating;

	@Column(name = "icb_benchmark")
	private String icbBenchMark;

	@Column(name = "icb_spread")
	private String icbSpread;

}
