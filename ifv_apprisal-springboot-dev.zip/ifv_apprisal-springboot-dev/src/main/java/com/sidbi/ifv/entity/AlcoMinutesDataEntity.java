package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "s2_alco_minutes_data")
public class AlcoMinutesDataEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "sanc_dtl_code")
	private Long sancDtlCode;

	@Column(name = "agenda_no")
	private Integer agendaNo;

	@Column(name = "agenda_id")
	private String agendaId;

	@Column(name = "app_id")
	private String appId;

	@Column(name = "bank_name")
	private String bankName;

	@Column(name = "scheme_name")
	private String schemeName;

	@Column(name = "fund_name")
	private String fundName;

	@Column(name = "fund_code")
	private String fundCode;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "tenor")
	private BigDecimal tenor;

	@Column(name = "interest_rate")
	private BigDecimal interestRate;

	@Column(name = "cost_of_funds")
	private BigDecimal costOfFunds;

	@Column(name = "spread_margin")
	private BigDecimal spreadMargin;

	@Column(name = "principal_repayment")
	private String principalRepayment;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "status")
	private String status;

	@Column(name = "scheme_code")
	private String schemeCode;

	@Column(name = "pr_id")
	private Long prId;

}
