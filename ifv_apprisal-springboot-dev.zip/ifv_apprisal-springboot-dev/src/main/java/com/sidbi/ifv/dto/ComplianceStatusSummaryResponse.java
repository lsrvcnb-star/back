package com.sidbi.ifv.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComplianceStatusSummaryResponse {

	private String appRefNo;

	private String complianceType;

	private LocalDateTime uploadDate;

	private LocalDate dueDate;

	private LocalDate asOnDate;

	private String status;

	private String fileName;
	
	private String filePath;
}