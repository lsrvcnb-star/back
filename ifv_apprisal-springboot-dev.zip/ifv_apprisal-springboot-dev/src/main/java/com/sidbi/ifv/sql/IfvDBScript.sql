
/***************************************VIGNESHA 24-04-2024 STARTS****************************************/

CREATE TABLE public.s2_cmt_member_master (
	cmt_code numeric(38, 2) NULL,
	cmt_member_code bigserial NOT NULL,
	cmt_member_role varchar(255) NULL,
	cmt_remark varchar(255) NULL,
	cmt_type varchar(255) NULL,
	created_date timestamp(6) NULL,
	created_by varchar(255) NULL,
	member_code varchar(255) NULL,
	member_name varchar(255) NULL,
	enable_flag bpchar(1) NULL,
	CONSTRAINT s2_cmt_member_master_pkey PRIMARY KEY (cmt_member_code)
);


CREATE TABLE public.s2_ifv_alco_proposal (
	al_code bigserial NOT NULL,
	al_type varchar(500) NULL,
	al_background varchar(1000) NULL,
	al_presnt_proposal varchar(1000) NULL,
	al_tenor varchar(50) NULL,
	al_1yr numeric(15, 5) NULL,
	al_3yr numeric(15, 5) NULL,
	al_5yr numeric(15, 5) NULL,
	al_recommendation varchar(4000) NULL,
	date_of_action timestamp NULL,
	al_app_number varchar(50) NOT NULL,
	CONSTRAINT s2_ifv_alco_proposal_pkey PRIMARY KEY (al_code)
);


CREATE TABLE public.s2_ifv_application (
	ifv_id bigserial NOT NULL,
	ifv_name varchar(200) NOT NULL,
	ifv_assistance varchar(1000) NULL,
	ifv_schemename varchar(200) NULL,
	ifv_amout numeric(38, 2) NULL,
	ifv_roi numeric(38, 2) NULL,
	ifv_tenuse numeric(38, 2) NULL,
	ifv_pr_repayment varchar(50) NULL,
	ifv_exposure_limit numeric(38, 2) NULL,
	ifv_existing_os numeric(38, 2) NULL,
	ifv_prop_exposure numeric(38, 2) NULL,
	ifv_total_exposure numeric(38, 2) NULL,
	ifv_repayment_date timestamp(6) NOT NULL,
	ifv_external_rating varchar(4000) NULL,
	ifv_ews varchar(4000) NULL,
	ifv_adverse_news varchar(4000) NULL,
	ifv_monetary varchar(4000) NULL,
	ipaddress varchar(40) NULL,
	modifie_date timestamp(6) NULL,
	modifie_on varchar(100) NULL,
	created_date timestamp(6) NULL,
	created_on varchar(40) NULL,
	cif_number varchar(50) NOT NULL,
	sfb bpchar(1) NULL DEFAULT 'N'::bpchar,
	app_number varchar(15) NOT NULL,
	other_remarks varchar(4000) NULL,
	ifv_remarks varchar(4000) NULL,
	CONSTRAINT app_number_unique UNIQUE (app_number),
	CONSTRAINT s2_ifv_application_pkey PRIMARY KEY (ifv_id)
);


CREATE TABLE public.s2_ifv_poa_signature (
	id bigserial NOT NULL,
	start_date timestamp(6) NULL,
	bank_name varchar(255) NULL,
	cif_number varchar(255) NULL,
	file_name varchar(255) NULL,
	file bytea NULL,
	end_date timestamp(6) NULL,
	CONSTRAINT s2_ifv_poa_signature_pkey PRIMARY KEY (id)
);


CREATE TABLE public.s2_minutes_sanction (
	sanct_detail_code bigserial NOT NULL,
	commitee_code int4 NULL,
	meeting_date date NULL,
	sanct_stage varchar(20) NULL,
	meeting_place varchar(50) NULL,
	agenda_created_by varchar(10) NULL,
	reporting_officer varchar(10) NULL,
	created_by varchar(30) NULL,
	created_date date NULL,
	modified_by varchar(30) NULL,
	modified_date date NULL,
	convenor_code int4 NULL,
	al_convenor_code int4 NULL,
	member_code varchar(255) NULL,
	meeting_no int4 NULL,
	agenda_id varchar(20) NULL,
	chairman_code int4 NULL,
	CONSTRAINT s2_minutes_sanction_pkey PRIMARY KEY (sanct_detail_code)
);


CREATE TABLE public.tbl_ifv_login (
	ofr_code serial4 NOT NULL,
	ofr_org_code numeric(5) NULL,
	ofr_brn_code numeric(5) NULL,
	ofr_name varchar(45) NULL,
	ofr_desg_code numeric(5) NULL,
	ofr_dept_code numeric(5) NULL,
	ofr_type varchar(10) NULL,
	ofr_middle_name varchar(30) NULL,
	ofr_last_name varchar(30) NULL,
	ofr_email varchar(60) NULL,
	ofr_emp_id varchar(60) NULL,
	ofr_user_id varchar(40) NULL,
	ofr_user_password varchar(30) NULL,
	ofr_create_status varchar(3) NULL,
	ofr_user_active varchar(1) NULL,
	reporting_officer_code numeric(10) NULL,
	priv_code numeric(11) NULL,
	app_module_id numeric(11) NULL,
	priv_read bpchar(1) NULL,
	priv_write bpchar(1) NULL,
	priv_new bpchar(1) NULL,
	priv_lock bpchar(1) NULL,
	priv_unlock bpchar(1) NULL,
	priv_confirm bpchar(1) NULL,
	priv_recommend bpchar(1) NULL,
	priv_send_back_checker bpchar(1) NULL,
	priv_clear_circulation bpchar(1) NULL,
	priv_forward_branch bpchar(1) NULL,
	priv_approve bpchar(1) NULL,
	created_by varchar(30) NULL,
	created_date date NULL,
	modified_by varchar(100) NULL,
	modified_date date NULL,
	ip_address varchar(20) NULL,
	CONSTRAINT tbl_ifv_login_pkey PRIMARY KEY (ofr_code)
);


CREATE TABLE public.s2_ifv_areasgeographical (
	ag_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	ag_state varchar(500) NULL,
	ag_branch numeric(38, 2) NULL,
	ag_type varchar(50) NULL,
	CONSTRAINT s2_ifv_areasgeographical_pkey PRIMARY KEY (ag_id),
	CONSTRAINT s2_ifv_areasgeographical_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_ass_outstanding (
	os_id bigserial NOT NULL,
	ifv_id int8 NULL,
	os_periodfy numeric(38, 2) NULL,
	os_beginning_year numeric(38, 2) NULL,
	os_amountdisb numeric(38, 2) NULL,
	os_repaid numeric(38, 2) NULL,
	os_end_period numeric(38, 2) NULL,
	os_type varchar(255) NULL,
	CONSTRAINT s2_ifv_ass_outstanding_pkey PRIMARY KEY (os_id),
	CONSTRAINT fkt2tdn758inmmxtx17tlvuac0s FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_ass_pastdisb (
	ae_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	ae_periodfy varchar(50) NULL,
	ae_date timestamp(6) NULL,
	ae_amount numeric(15, 2) NULL,
	ae_scheme varchar(250) NULL,
	ae_roi numeric(15, 2) NULL,
	ae_type varchar(50) NULL,
	ae_tenure varchar(20) NULL,
	CONSTRAINT s2_ifv_ass_pastdisb_pkey PRIMARY KEY (ae_id),
	CONSTRAINT s2_ifv_ass_pastdisb_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_ass_repayments (
	rp_id bigserial NOT NULL,
	ifv_id int8 NULL,
	rp_refinance_acc varchar(255) NULL,
	rp_repayment_track varchar(255) NULL,
	rp_periodfy int4 NULL,
	rp_q1 numeric(15, 2) NULL,
	rp_q2 numeric(15, 2) NULL,
	rp_q3 numeric(15, 2) NULL,
	rp_q4 numeric(15, 2) NULL,
	rp_total numeric(15, 2) NULL,
	rp_type varchar(255) NULL,
	CONSTRAINT s2_ifv_ass_repayments_pkey PRIMARY KEY (rp_id),
	CONSTRAINT fkibk0x2quadravs36vkwkg8cqs FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_benchmark_repository (
	bm_code bigserial NOT NULL,
	ifv_id int8 NULL,
	bm_banktype varchar(500) NULL,
	bm_bankmeetingdate varchar(500) NULL,
	bm_particulars1 varchar(500) NULL,
	bm_remarks varchar(4000) NULL,
	bm_order varchar(10) NULL,
	bm_flg varchar(10) NULL,
	date_of_action timestamp NULL,
	al_code int4 NOT NULL,
	CONSTRAINT s2_ifv_benchmark_repository_pkey PRIMARY KEY (bm_code),
	CONSTRAINT s2_ifv_benchmark_repository_al_code_fkey FOREIGN KEY (al_code) REFERENCES public.s2_ifv_alco_proposal(al_code),
	CONSTRAINT s2_ifv_benchmark_repository_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_chiefboard (
	cb_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	cb_name varchar(500) NULL,
	cb_designation varchar(500) NULL,
	cb_remarks varchar(4000) NULL,
	cb_type varchar(40) NULL,
	CONSTRAINT s2_ifv_chiefboard_pkey PRIMARY KEY (cb_id),
	CONSTRAINT s2_ifv_chiefboard_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_collection_efficiency (
	id serial4 NOT NULL,
	ifv_id int4 NOT NULL,
	particulars varchar(20) NULL,
	collection_efficiency numeric(5, 2) NULL,
	CONSTRAINT s2_ifv_collection_efficiency_pkey PRIMARY KEY (id),
	CONSTRAINT ifv_id_fk FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_eligibility (
	ec_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	ec_remarks varchar(500) NULL,
	ec_bfsnorms varchar(500) NULL,
	ec_remarks1 varchar(500) NULL,
	ec_bfsnorms1 varchar(500) NULL,
	ec_bfnormseligibility varchar(500) NULL,
	ec_psbs varchar(255) NULL,
	ec_sectforeignbank varchar(255) NULL,
	ec_nnpadate timestamp(6) NULL,
	ec_nnpapercent numeric(10, 2) NULL,
	ec_nnoaremarks varchar(4000) NULL,
	ec_nnpastatus varchar(50) NULL,
	ec_rmseassistance varchar(4000) NULL,
	ec_rmsestatus varchar(50) NULL,
	ec_assstance varchar(4000) NULL,
	ec_assstancestatus varchar(50) NULL,
	ec_rbicompliance varchar(4000) NULL,
	ec_rbistatus varchar(50) NULL,
	ec_gsecdate timestamp(6) NULL,
	ec_gsecpercent numeric(10, 2) NULL,
	ec_sidbifixed numeric(38, 2) NULL,
	ec_sidbiremarks varchar(4000) NULL,
	ec_sidbistatus varchar(4000) NULL,
	ec_rmsedate timestamp(6) NULL,
	ec_rmsemicrofy int4 NULL,
	ec_rmseremarks varchar(4000) NULL,
	ec_rmsestatus1 varchar(4000) NULL,
	ec_icddremarks varchar(4000) NULL,
	ec_icddstatus varchar(4000) NULL,
	ec_fabiaremarks varchar(4000) NULL,
	ec_fabiastatus varchar(4000) NULL,
	CONSTRAINT s2_ifv_eligibility_pkey PRIMARY KEY (ec_id),
	CONSTRAINT s2_ifv_eligibility_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_financialhighlights (
	fh_id serial4 NOT NULL,
	ifv_id int4 NOT NULL,
	fh_fymarch31 numeric(8, 2) NULL,
	fh_fyresults numeric(8, 2) NULL,
	fh_particular varchar(500) NULL,
	fh_fy1 numeric(15, 2) NULL,
	fh_fy2 numeric(15, 2) NULL,
	fh_yoy numeric(15, 2) NULL,
	fh_fy3 numeric(15, 2) NULL,
	fh_finperformance varchar(4000) NULL,
	fh_lcrdate date NULL,
	fh_lcrvalue numeric(8, 2) NULL,
	fh_assestsprofile varchar(4000) NULL,
	fh_liabilities varchar(4000) NULL,
	fh_profitabilities varchar(4000) NULL,
	fh_equlity varchar(4000) NULL,
	fh_disclosure varchar(4000) NULL,
	fh_collection varchar(4000) NULL,
	fh_efficiency numeric(8, 2) NULL,
	fh_efficiencydate date NULL,
	fh_statutory varchar(4000) NULL,
	fh_status varchar(4000) NULL,
	current_year_value int4 NULL,
	previous_year_value int4 NULL,
	months varchar(20) NULL,
	fh_highlights varchar(4000) NULL,
	financial_performance_year1 varchar(150) NULL,
	financial_performance2 varchar(4000) NULL,
	financial_performance_year2 varchar(150) NULL,
	highlights_value varchar(150) NULL,
	highlights_date date NULL,
	rbi_guidelines varchar(4000) NULL,
	CONSTRAINT s2_ifv_financialhighlights_pkey PRIMARY KEY (fh_id),
	CONSTRAINT s2_ifv_financialhighlights_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_institutional (
	in_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	in_particular varchar(500) NULL,
	in_amount numeric(38, 2) NULL,
	in_date timestamp(6) NULL,
	CONSTRAINT s2_ifv_institutional_pkey PRIMARY KEY (in_id),
	CONSTRAINT s2_ifv_institutional_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_investor (
	ki_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	ki_holder varchar(500) NULL,
	ki_count numeric(38, 2) NULL,
	ki_holding numeric(38, 2) NULL,
	ki_proportion numeric(38, 2) NULL,
	ki_type varchar(50) NULL,
	CONSTRAINT s2_ifv_investor_pkey PRIMARY KEY (ki_id),
	CONSTRAINT s2_ifv_investor_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_kyc (
	kyc_id serial4 NOT NULL,
	ifv_id int4 NOT NULL,
	kyc_product_name varchar(500) NULL,
	kyc_amount numeric(8, 2) NULL,
	kyc_shareprofile numeric(8, 2) NULL,
	kyc_type varchar(20) NULL,
	CONSTRAINT s2_ifv_kyc_pkey PRIMARY KEY (kyc_id),
	CONSTRAINT s2_ifv_kyc_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_master_repository (
	mst_code bigserial NOT NULL,
	ifv_id int8 NULL,
	mst_particulars varchar(500) NULL,
	mst_remarks varchar(4000) NULL,
	mst_order varchar(10) NULL,
	mst_flg varchar(10) NULL,
	date_of_action timestamp NULL,
	CONSTRAINT s2_ifv_master_repository_pkey PRIMARY KEY (mst_code),
	CONSTRAINT s2_ifv_master_repository_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_principal (
	pl_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	pl_repayment varchar(500) NULL,
	pl_intpayment varchar(500) NULL,
	pl_months numeric(10, 4) NULL,
	CONSTRAINT s2_ifv_principal_pkey PRIMARY KEY (pl_id),
	CONSTRAINT s2_ifv_principal_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_profile_bd (
	pr_code bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	pr_first_name varchar(255) NULL,
	pr_designation varchar(1000) NULL,
	pr_brief_profile varchar(4000) NULL,
	date_of_action timestamp NULL,
	CONSTRAINT s2_ifv_profile_bd_pkey PRIMARY KEY (pr_code),
	CONSTRAINT s2_ifv_profile_bd_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);



CREATE TABLE public.s2_ifv_proposed_schema (
	pr_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	pr_schemename varchar(250) NULL,
	pr_schemecode varchar(150) NULL,
	pr_fundname varchar(250) NULL,
	pr_fundcode varchar(150) NULL,
	pr_amount numeric(15, 2) NULL,
	pr_roi numeric(12, 2) NULL,
	pr_tenure numeric(15, 2) NULL,
	pr_principal_repayment varchar(150) NULL,
	pr_maturity_date date NULL,
	CONSTRAINT s2_ifv_proposed_schema_pkey PRIMARY KEY (pr_id),
	CONSTRAINT ifv_id_fk FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_rating_repository (
	rt_code bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	rt_type varchar(500) NULL,
	rt_particulars1 varchar(500) NULL,
	rt_remarks varchar(4000) NULL,
	rt_order varchar(10) NULL,
	rt_flg varchar(10) NULL,
	date_of_action timestamp NULL,
	CONSTRAINT s2_ifv_rating_repository_pkey PRIMARY KEY (rt_code),
	CONSTRAINT s2_ifv_rating_repository_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_restructured_assets (
	id serial4 NOT NULL,
	ifv_id int4 NOT NULL,
	rs_date date NULL,
	no_of_accounts int4 NULL,
	rs_amount numeric(15, 2) NULL,
	CONSTRAINT s2_ifv_restructured_assets_pkey PRIMARY KEY (id),
	CONSTRAINT ifv_id_fk FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_sanction_terms_conditions (
	id serial4 NOT NULL,
	ifv_id int4 NOT NULL,
	pr_id int4 NOT NULL,
	fund_code varchar(50) NOT NULL,
	fund_name varchar(150) NOT NULL,
	scheme_code varchar(50) NOT NULL,
	scheme_name varchar(150) NOT NULL,
	amount_in_words varchar(250) NOT NULL,
	amount numeric(15, 2) NOT NULL,
	ts_rateinterest numeric(38, 2) NULL,
	ts_tenure_period numeric(38, 2) NULL,
	ts_roi_repayment varchar(4000) NULL,
	ts_principal_repayment varchar(4000) NULL,
	ts_interest_payment varchar(4000) NULL,
	ts_tenure_wd varchar(4000) NULL,
	ts_extent varchar(4000) NULL,
	ts_eligiblemse varchar(4000) NULL,
	ts_eligibleactivities varchar(4000) NULL,
	ts_eventdflt varchar(4000) NULL,
	ts_security varchar(4000) NULL,
	ts_documentstion varchar(4000) NULL,
	ts_timeframe varchar(4000) NULL,
	ts_drawalloan varchar(4000) NULL,
	ts_othercond varchar(4000) NULL,
	ts_outstandingamount varchar(4000) NULL,
	ts_drawaloan varchar(255) NULL,
	ts_termsection varchar(255) NULL,
	ts_extra_conditions varchar(4000) NULL,
	CONSTRAINT s2_ifv_sanction_terms_conditions_pkey PRIMARY KEY (id),
	CONSTRAINT ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id),
	CONSTRAINT pr_id_fkey FOREIGN KEY (pr_id) REFERENCES public.s2_ifv_proposed_schema(pr_id)
);


CREATE TABLE public.s2_ifv_schema (
	sc_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	sc_schemename varchar(500) NULL,
	sc_amount numeric(38, 2) NULL,
	sc_roi numeric(38, 2) NULL,
	sc_tenure varchar(20) NULL,
	fund_code varchar(50) NULL,
	interest_payment varchar(4000) NULL,
	principal_repayment varchar(4000) NULL,
	CONSTRAINT s2_ifv_schema_pkey PRIMARY KEY (sc_id),
	CONSTRAINT s2_ifv_schema_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);

CREATE TABLE public.s2_ifv_sfb_commondt (
	sfb_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	sfb_shareportfoliodate timestamp(6) NULL,
	sfb_ao_network varchar(500) NULL,
	sfb_ao_branches varchar(500) NULL,
	sfb_ao_date timestamp(6) NULL,
	sfb_shareholdingpattern timestamp(6) NULL,
	sfb_rsfb_remark varchar(4000) NULL,
	sfb_rsfb_alcosca varchar(500) NULL,
	sfb_rsfb_date timestamp(6) NULL,
	sfb_rsfb_interestrate numeric(38, 2) NULL,
	sfb_rsfb_trms numeric(38, 2) NULL,
	sfb_rsfb_margin numeric(38, 2) NULL,
	sfb_rampe_alcosca numeric(38, 2) NULL,
	sfb_rampe_alcoscadate timestamp(6) NULL,
	sfb_rampe_interestrate numeric(38, 2) NULL,
	sfb_trmv_amount numeric(38, 2) NULL,
	sfb_trmv_margin varchar(500) NULL,
	sfb_trmv_margin1 varchar(500) NULL,
	sfb_trmv_remarks varchar(4000) NULL,
	sfb_rmse_tranche varchar(500) NULL,
	sfb_rmse_tranche1 varchar(500) NULL,
	sfb_rmse_tranche2 varchar(500) NULL,
	sfb_rmse_period varchar(500) NULL,
	sfb_rmse_period_trn varchar(500) NULL,
	sfb_rmse_date timestamp(6) NULL,
	sfb_rmse_remarks varchar(4000) NULL,
	sfb_rampe_data varchar(500) NULL,
	sfb_fabia_data varchar(500) NULL,
	sfb_ao_majority_branches varchar(400) NULL,
	audit_comments varchar(4000) NULL,
	mser_fabia_rampe_selected varchar(20) NULL,
	rmse_selected varchar(20) NULL,
	alco_or_subalco varchar(150) NULL,
	discretion_involved bpchar(1) NULL,
	discretion_involved_reason varchar(4000) NULL,
	CONSTRAINT s2_ifv_sfb_commondt_pkey PRIMARY KEY (sfb_id),
	CONSTRAINT s2_ifv_sfb_commondt_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_termconditions (
	ts_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	ts_scheme varchar(500) NULL,
	ts_amount numeric(38, 2) NULL,
	ts_rateinterest numeric(8, 2) NULL,
	ts_tnure numeric(38, 2) NULL,
	rp_amount varchar(500) NULL,
	rp_interest varchar(500) NULL,
	ts_rateintrest numeric(38, 2) NULL,
	CONSTRAINT s2_ifv_termconditions_pkey PRIMARY KEY (ts_id),
	CONSTRAINT s2_ifv_termconditions_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_termconditions_data (
	ts_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	ts_upfrontfee varchar(4000) NULL,
	ts_months numeric(38, 2) NULL,
	ts_disbursement varchar(4000) NULL,
	ts_specific varchar(4000) NULL,
	ts_borrowers varchar(4000) NULL,
	ts_rampe varchar(10) NULL,
	ts_fabia varchar(10) NULL,
	ts_termsanction varchar(4000) NULL,
	ts_validitysanction varchar(4000) NULL,
	ts_dop_sanction varchar(4000) NULL,
	ts_dop_relaxtion varchar(4000) NULL,
	ts_recommendation varchar(4000) NULL,
	ts_facilityamount varchar(4000) NULL,
	ts_rateinterest numeric(38, 2) NULL,
	ts_tenure_period numeric(38, 2) NULL,
	ts_roi_repayment varchar(4000) NULL,
	ts_principal_repayment varchar(4000) NULL,
	ts_interest_payment varchar(4000) NULL,
	ts_tenure_wd varchar(4000) NULL,
	ts_extent varchar(4000) NULL,
	ts_eligiblemse varchar(4000) NULL,
	ts_eligibleactivities varchar(4000) NULL,
	ts_eventdflt varchar(4000) NULL,
	ts_security varchar(4000) NULL,
	ts_documentstion varchar(4000) NULL,
	ts_timeframe varchar(4000) NULL,
	ts_drawalloan varchar(4000) NULL,
	ts_othercond varchar(4000) NULL,
	ts_outstandingamount varchar(4000) NULL,
	ts_drawaloan varchar(255) NULL,
	ts_termsection varchar(255) NULL,
	CONSTRAINT s2_ifv_termconditions_data_pkey PRIMARY KEY (ts_id),
	CONSTRAINT s2_ifv_termconditions_data_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_ifv_termssection (
	term_id bigserial NOT NULL,
	ifv_id int8 NOT NULL,
	term_sanction_code varchar(255) NULL,
	term_sanction_desc varchar(4000) NULL,
	term_sanctionlist_type varchar(255) NULL,
	terms_sanction_condition_order varchar(255) NULL,
	terms_editable_flag varchar(255) NULL,
	terms_condition_order varchar(255) NULL,
	term_condition_order varchar(255) NULL,
	term_editable_flag varchar(255) NULL,
	term_sanction_condition_order varchar(255) NULL,
	CONSTRAINT s2_ifv_termssection_pkey PRIMARY KEY (term_id),
	CONSTRAINT s2_ifv_termssection_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_minutes_sanc_dtl (
	sanc_dtl_code bigserial NOT NULL,
	sanct_status_code int4 NOT NULL,
	appid varchar(50) NULL,
	sanct_purpose_status varchar(100) NULL,
	sanct_dscn_status varchar(100) NULL,
	min_sumry_created varchar(100) NULL,
	branch_name varchar(100) NULL,
	application_dt date NULL,
	unit_name varchar(1000) NULL,
	loan_amount numeric(8, 2) NULL,
	scheme_name varchar(500) NULL,
	scheme_cd varchar(100) NULL,
	interest_rate numeric(8, 2) NULL,
	tenor numeric(8, 2) NULL,
	principal_repayment varchar(100) NULL,
	remarks varchar(1500) NULL,
	created_by varchar(200) NULL,
	created_date date NULL,
	modified_by varchar(200) NULL,
	modified_date date NULL,
	agenda_id varchar(20) NULL,
	agenda_no int4 NULL,
	sanc_status varchar(150) NULL,
	cost_of_funds numeric(8, 2) NULL,
	spread_margin numeric(8, 2) NULL,
	CONSTRAINT s2_minutes_sanc_dtl_pkey PRIMARY KEY (sanc_dtl_code),
	CONSTRAINT sanct_status_code_fk FOREIGN KEY (sanct_status_code) REFERENCES public.s2_minutes_sanction(sanct_detail_code)
);


CREATE TABLE public.tbl_ifv_module_fwd (
	fwd_status_id bigserial NOT NULL,
	ifv_id int8 NULL,
	module_id int8 NULL,
	app_officer_code int8 NULL,
	app_current_officer_code int8 NULL,
	app_status varchar(30) NULL,
	app_module_checker_code int8 NULL,
	created_modified_date date NULL,
	created_by varchar(200) NULL,
	created_date date NULL,
	modified_by varchar(200) NULL,
	modified_date date NULL,
	ip_address varchar(20) NULL,
	al_code int4 NULL,
	CONSTRAINT tbl_ifv_module_fwd_pkey PRIMARY KEY (fwd_status_id),
	CONSTRAINT tbl_ifv_module_fwd_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);


CREATE TABLE public.s2_alco_minutes_data (
	id bigserial NOT NULL,
	sanc_dtl_code int4 NOT NULL,
	agenda_no int4 NULL,
	agenda_id varchar(20) NULL,
	app_id varchar(50) NULL,
	bank_name varchar(400) NULL,
	scheme_name varchar(150) NULL,
	fund_name varchar(150) NULL,
	fund_code varchar(50) NULL,
	amount numeric(8, 2) NULL,
	tenor int4 NULL,
	interest_rate numeric(8, 2) NULL,
	principal_repayment varchar(150) NULL,
	cost_of_funds numeric(8, 2) NULL,
	spread_margin numeric(8, 2) NULL,
	created_by varchar(200) NULL,
	created_date date NULL,
	modified_by varchar(200) NULL,
	modified_date date NULL,
	status varchar(150) NULL,
	scheme_code varchar(100) NULL,
	pr_id int4 NULL,
	CONSTRAINT s2_alco_minutes_data_pkey PRIMARY KEY (id),
	CONSTRAINT pr_id_fk FOREIGN KEY (pr_id) REFERENCES public.s2_ifv_proposed_schema(pr_id),
	CONSTRAINT sanc_dtl_code_fk FOREIGN KEY (sanc_dtl_code) REFERENCES public.s2_minutes_sanc_dtl(sanc_dtl_code)
);


CREATE TABLE public.s2_appraisal_minutes_data (
	id bigserial NOT NULL,
	sanc_dtl_code int4 NOT NULL,
	agenda_no int4 NULL,
	agenda_id varchar(20) NULL,
	app_id varchar(50) NULL,
	bank_name varchar(400) NULL,
	scheme_name varchar(150) NULL,
	fund_name varchar(150) NULL,
	fund_code varchar(50) NULL,
	loan_amount numeric(8, 2) NULL,
	interest_rate numeric(8, 2) NULL,
	tenure int4 NULL,
	principal_repayment varchar(150) NULL,
	created_by varchar(200) NULL,
	created_date date NULL,
	modified_by varchar(200) NULL,
	modified_date date NULL,
	status varchar(150) NULL,
	scheme_code varchar(100) NULL,
	pr_id int4 NULL,
	CONSTRAINT s2_appraisal_minutes_data_pkey PRIMARY KEY (id),
	CONSTRAINT pr_id_fk FOREIGN KEY (pr_id) REFERENCES public.s2_ifv_proposed_schema(pr_id),
	CONSTRAINT sanc_dtl_code_fk FOREIGN KEY (sanc_dtl_code) REFERENCES public.s2_minutes_sanc_dtl(sanc_dtl_code)
);


CREATE TABLE public.s2_ifv_alco_data (
	dt_code bigserial NOT NULL,
	dt_appl varchar(50) NULL,
	ifv_id int8 NOT NULL,
	dt_bankname varchar(1000) NULL,
	dt_amount numeric(15, 2) NULL,
	dt_scheme varchar(500) NULL,
	dt_period numeric(15, 2) NULL,
	dt_roi numeric(15, 2) NULL,
	dt_cost_of_funds numeric(15, 2) NULL,
	dt_speedmargin numeric(15, 2) NULL,
	dt_prinicipal_rep varchar(50) NULL,
	date_of_action timestamp NULL,
	al_code int4 NOT NULL,
	fund_code varchar(50) NULL,
	scheme_code varchar(50) NULL,
	pr_id int4 NULL,
	CONSTRAINT s2_ifv_alco_data_pkey PRIMARY KEY (dt_code),
	CONSTRAINT pr_id_fk FOREIGN KEY (pr_id) REFERENCES public.s2_ifv_proposed_schema(pr_id),
	CONSTRAINT s2_ifv_alco_data_al_code_fkey FOREIGN KEY (al_code) REFERENCES public.s2_ifv_alco_proposal(al_code),
	CONSTRAINT s2_ifv_alco_data_ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id)
);

CREATE TABLE public.s2_ifv_file_repository (
	file_code bigserial NOT NULL,
	file_module varchar(255) NULL,
	file_ifv_id int8 NULL,
	file_type varchar(255) NULL,
	file_data bytea NULL,
	file_name varchar(255) NULL,
	file_content_type varchar(255) NULL,
	file_domain varchar(255) NULL,
	date_of_action timestamp NULL,
	sanc_min_detail_id int4 NULL,
	file_alco_id int4 NULL,
	CONSTRAINT ifv_file_repository_pkey PRIMARY KEY (file_code),
	CONSTRAINT s2_ifv_file_repository_ifv_id_fkey FOREIGN KEY (file_ifv_id) REFERENCES public.s2_ifv_application(ifv_id),
	CONSTRAINT sanc_min_detail_id_fk FOREIGN KEY (sanc_min_detail_id) REFERENCES public.s2_minutes_sanc_dtl(sanc_dtl_code)
);


CREATE TABLE public.tbl_fwd_history (
	hst_code bigserial NOT NULL,
	fwd_status_id int8 NULL,
	hst_curr_officer_code int8 NULL,
	hst_status varchar(3) NULL,
	hst_comments varchar(4000) NULL,
	created_date date NULL,
	created_by varchar(50) NULL,
	ip_address varchar(20) NULL,
	CONSTRAINT tbl_fwd_history_pkey PRIMARY KEY (hst_code),
	CONSTRAINT tbl_fwd_history_fwd_status_id_fkey FOREIGN KEY (fwd_status_id) REFERENCES public.tbl_ifv_module_fwd(fwd_status_id)
);

/***************************************VIGNESHA 24-04-2024 ENDS****************************************/


/***************************************VIGNESHA 24-04-2024 STARTS****************************************/

ALTER TABLE public.s2_ifv_principal ADD COLUMN pl_period varchar(4000);
ALTER TABLE public.s2_ifv_application ADD COLUMN checker_id integer;
alter table public.s2_ifv_application add constraint checker_id_fk foreign key(checker_id) references tbl_ifv_login(ofr_code);

/***************************************VIGNESHA 24-04-2024 ENDS****************************************/


/***************************************VIGNESHA 25-04-2024 STARTS****************************************/

ALTER TABLE public.s2_ifv_eligibility ALTER COLUMN EC_RMSEMICROFY TYPE varchar(150);
ALTER TABLE public.s2_ifv_eligibility ALTER COLUMN ec_gsecpercent TYPE numeric(12,5);

alter table public.s2_ifv_sfb_commondt add column cm_msers_data varchar(4000);
alter table public.s2_ifv_sfb_commondt add column cm_rmse_data varchar(4000);
alter table public.s2_ifv_sfb_commondt add column cm_rsfb_data varchar(4000);
alter table public.s2_ifv_sfb_commondt add column cm_fabia_data varchar(4000);
alter table public.s2_ifv_sfb_commondt add column cm_rampe_data varchar(4000);
ALTER TABLE public.s2_ifv_principal ADD COLUMN pl_scheme varchar(150);

ALTER TABLE public.s2_ifv_application drop COLUMN ifv_schemename;
ALTER TABLE public.s2_ifv_application drop COLUMN ifv_amout;
ALTER TABLE public.s2_ifv_application drop COLUMN ifv_roi;
ALTER TABLE public.s2_ifv_application drop COLUMN ifv_tenuse;
ALTER TABLE public.s2_ifv_application drop COLUMN ifv_pr_repayment;
ALTER TABLE public.s2_ifv_application drop COLUMN modifie_on;
ALTER TABLE public.s2_ifv_application drop COLUMN created_on;

/***************************************VIGNESHA 25-04-2024 ENDS****************************************/

/***************************************VIGNESHA 29-04-2024 STARTS****************************************/
 
ALTER TABLE public.s2_ifv_sfb_commondt ADD COLUMN cm_chief_func_note varchar(500);
ALTER TABLE public.s2_ifv_sfb_commondt ADD COLUMN cm_geo_area_note varchar(500);
ALTER TABLE public.s2_ifv_sfb_commondt ADD COLUMN cm_key_investors_note varchar(500);
 
/***************************************VIGNESHA 25-04-2024 ENDS****************************************/

/***************************************VIGNESHA 09-05-2024 STARTS****************************************/

alter table s2_ifv_sfb_commondt add constraint ifv_id_unique unique (ifv_id);
alter table s2_ifv_master_repository alter column mst_particulars set not null;
alter table s2_ifv_master_repository alter column mst_remarks set not null;
 
/***************************************VIGNESHA 09-05-2024 ENDS****************************************/


/***************************************VIGNESHA 23-05-2024 STARTS****************************************/

alter table S2_IFV_ASS_REPAYMENTS alter column rp_q1 type numeric(20,15);
alter table S2_IFV_ASS_REPAYMENTS alter column rp_q2 type numeric(20,15);
alter table S2_IFV_ASS_REPAYMENTS alter column rp_q3 type numeric(20,15);
alter table S2_IFV_ASS_REPAYMENTS alter column rp_q4 type numeric(20,15);
alter table S2_IFV_ASS_REPAYMENTS alter column rp_total type numeric(20,15);

alter table s2_ifv_ass_outstanding alter column os_beginning_year type numeric(20,15);
alter table s2_ifv_ass_outstanding alter column os_amountdisb type numeric(20,15);
alter table s2_ifv_ass_outstanding alter column os_repaid type numeric(20,15);
alter table s2_ifv_ass_outstanding alter column os_end_period type numeric(20,15);

alter table s2_ifv_eligibility add column bank_parameter varchar(250);

alter table tbl_ifv_login add constraint user_name_unique unique (ofr_name);
alter table tbl_ifv_login add constraint emp_code_unique unique (ofr_emp_id);

/***************************************VIGNESHA 23-05-2024 ENDS****************************************/

/***************************************VIGNESHA 27-05-2024 STARTS****************************************/

alter table tbl_ifv_module_fwd add column current_fwd_checker_name varchar(150) null;
alter table tbl_ifv_module_fwd add column current_fwd_checker_desg varchar(150) null;
alter table tbl_ifv_module_fwd add column checker1_id integer null;
alter table tbl_ifv_module_fwd add column checker1_name varchar(150) null;
alter table tbl_ifv_module_fwd add column checker1_desg varchar(150) null;
alter table tbl_ifv_module_fwd add column checker2_id integer null;
alter table tbl_ifv_module_fwd add column checker2_name varchar(150) null;
alter table tbl_ifv_module_fwd add column checker2_desg varchar(150) null;
alter table tbl_ifv_module_fwd add column checker3_id integer null;
alter table tbl_ifv_module_fwd add column checker3_name varchar(150) null;
alter table tbl_ifv_module_fwd add column checker3_desg varchar(150) null;
alter table tbl_ifv_module_fwd add column checker4_id integer null;
alter table tbl_ifv_module_fwd add column checker4_name varchar(150) null;
alter table tbl_ifv_module_fwd add column checker4_desg varchar(150) null;

create table s2_ifv_status_of_listing(
	id serial primary key,
	ifv_id integer not null,
	column_1 varchar(150) null,
	column_2 numeric(12,2) null,
	column_3 numeric(12,2) null
);

alter table s2_ifv_status_of_listing add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);

alter table public.s2_ifv_financialhighlights add column restructured_asset varchar(150);
alter table public.s2_ifv_sanction_terms_conditions add column ts_tenure_approx varchar(150);

/***************************************VIGNESHA 27-05-2024 ENDS****************************************/

/***************************************VIGNESHA 30-05-2024 STARTS****************************************/

alter table s2_ifv_master_repository alter column mst_order set not null;

alter table s2_ifv_application add column ifv_exp_remarks varchar(4000);
alter table tbl_ifv_login add column ofr_short_name varchar(150) null;

alter table s2_minutes_sanction add constraint committee_meeting_no_unique unique(commitee_code,meeting_no);

alter table s2_minutes_sanction alter column convenor_code type varchar(10);
alter table s2_minutes_sanction alter column al_convenor_code type varchar(10);
alter table s2_minutes_sanction alter column chairman_code type varchar(10);

alter table tbl_ifv_module_fwd add column locked_date_time timestamp null;
alter table tbl_ifv_module_fwd add column checker1_fwd_date timestamp null;
alter table tbl_ifv_module_fwd add column checker2_fwd_date timestamp null;
alter table tbl_ifv_module_fwd add column checker3_fwd_date timestamp null;
alter table tbl_ifv_module_fwd add column approved_date_time timestamp null;

alter table s2_ifv_application add column ifv_undisbursed_sanction numeric(12,2);

/***************************************VIGNESHA 30-05-2024 ENDS****************************************/

/***************************************VIGNESHA 04-06-2024 STARTS****************************************/

alter table s2_ifv_application add column ifv_bank_type varchar(150) null;
alter table s2_ifv_application add column ifv_background varchar(4000) null;

alter table s2_ifv_sfb_commondt add column ucs_regulatory_environment varchar(500) null;
alter table s2_ifv_sfb_commondt add column ucs_brief_particulars varchar(500) null;
alter table s2_ifv_sfb_commondt add column ucs_director_exposure varchar(500) null;
alter table s2_ifv_sfb_commondt add column ucs_institutional_borrowings varchar(500) null;

alter table s2_ifv_sfb_commondt drop column SFB_RSFB_REMARK;
alter table s2_ifv_sfb_commondt drop column SFB_RSFB_ALCOSCA;
alter table s2_ifv_sfb_commondt drop column SFB_RSFB_DATE;
alter table s2_ifv_sfb_commondt drop column SFB_RSFB_INTERESTRATE;
alter table s2_ifv_sfb_commondt drop column SFB_RSFB_TRMS;
alter table s2_ifv_sfb_commondt drop column SFB_RSFB_MARGIN;
alter table s2_ifv_sfb_commondt drop column SFB_RAMPE_ALCOSCA;
alter table s2_ifv_sfb_commondt drop column SFB_RAMPE_ALCOSCADATE;
alter table s2_ifv_sfb_commondt drop column SFB_RAMPE_INTERESTRATE;
alter table s2_ifv_sfb_commondt drop column SFB_TRMV_AMOUNT;

alter table s2_ifv_sfb_commondt drop column SFB_TRMV_MARGIN;
alter table s2_ifv_sfb_commondt drop column SFB_TRMV_MARGIN1;
alter table s2_ifv_sfb_commondt drop column SFB_TRMV_REMARKS;
alter table s2_ifv_sfb_commondt drop column SFB_RMSE_TRANCHE;
alter table s2_ifv_sfb_commondt drop column SFB_RMSE_TRANCHE1;
alter table s2_ifv_sfb_commondt drop column SFB_RMSE_TRANCHE2;
alter table s2_ifv_sfb_commondt drop column SFB_RMSE_PERIOD;
alter table s2_ifv_sfb_commondt drop column SFB_RMSE_PERIOD_TRN;
alter table s2_ifv_sfb_commondt drop column SFB_RMSE_DATE;

alter table s2_ifv_sfb_commondt drop column SFB_RMSE_REMARKS;
alter table s2_ifv_sfb_commondt drop column SFB_RAMPE_DATA;
alter table s2_ifv_sfb_commondt drop column SFB_FABIA_DATA;
alter table s2_ifv_sfb_commondt drop column mser_fabia_rampe_selected;
alter table s2_ifv_sfb_commondt drop column rmse_selected;

/***************************************VIGNESHA 04-06-2024 ENDS****************************************/

/***************************************VIGNESHA 11-06-2024 STARTS****************************************/

update tbl_ifv_login set ofr_type ='9128' where ofr_emp_id ='058112' and ofr_name ='SUBASH KUMAR SAHOO';
update tbl_ifv_login set ofr_type ='9128' where ofr_emp_id ='056381' and ofr_name ='SUSANT KUMAR SAMAL';

alter table s2_ifv_sfb_commondt add column ucb_seg_portfolio_date timestamp null;
alter table s2_ifv_sfb_commondt add column ucb_seg2_portfolio_date timestamp null;
alter table s2_ifv_sfb_commondt add column ucb_seg2_note varchar(4000) null;

create table ucb_top_10_borrowers(
id serial primary key,
ifv_id integer not null,
customer_name varchar(250) not null,
total_os numeric(15,2) null,
nature_of_activity varchar(250) null,
borrower_note varchar(500) null
); 
alter table ucb_top_10_borrowers add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);

create table ucb_financial_performance(
id serial primary key,
ifv_id integer not null,
particulars varchar(250) not null,
amount1 numeric(15,2) null,
amount2 numeric(15,2) null,
date1 timestamp null,
date2 timestamp null,
note varchar(250) null
); 
alter table ucb_financial_performance add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);

create table ucb_eligibility_criteria(
id serial primary key,
ifv_id integer not null,
particulars varchar(4000) not null,
bfs_norm varchar(500) null,
compliance_status varchar(4000) null,
compliance_status_year varchar(20) null,
eligibility_type varchar(20) null
); 
alter table ucb_eligibility_criteria add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);

create table ucb_criteria_parameters(
id serial primary key,
ifv_id integer not null,
criteria_parameters  varchar(500) not null,
complied character null,
compliance varchar(4000) null,
justification varchar(500) null,
note varchar(4000) null,
compliance_date varchar(50) null
); 
alter table ucb_criteria_parameters add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);


create table ucb_annexures(
id serial primary key,
ifv_id integer not null,
particulars varchar(4000) not null,
remarks varchar(4000) null,
note varchar(4000) null,
annexure_no integer not null
); 
alter table ucb_annexures add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);

/***************************************VIGNESHA 11-06-2024 ENDS****************************************/

/***************************************VIGNESHA 18-06-2024 STARTS****************************************/

alter table s2_cmt_member_master add column member_vertical varchar(50);
alter table s2_cmt_member_master add column member_short_name varchar(150);

alter table s2_minutes_sanction add column grant_leaves varchar(50);
alter table s2_minutes_sanction add column note1 varchar(500);
alter table s2_minutes_sanction add column note2 varchar(500);

alter table s2_minutes_sanction add column flash_note varchar(500);

CREATE TABLE S2_IFV_SANCTION_DT (
		ID serial NOT NULL,
		BNL_REQUEST_NO VARCHAR(200) NOT NULL,
		BNA_APPL_AMT numeric(15,2) NULL,
		BNA_APPL_SUBMIT_DT DATE NULL,
		BNA_APPL_PROJ_DESC VARCHAR(500) NULL,
		BNA_SANC_REMARKS VARCHAR(500) NULL,
		BNA_PRJCT_COST numeric(15,2) NULL,
		BNA_SANC_AUTH VARCHAR(50) NULL,
		BNL_CUST_CD VARCHAR(20) NULL,
		BNL_SANCT_DT DATE NULL,
		BNL_SANCT_AMT numeric(15,2) NULL,
		BNL_DOC_RATE numeric(9,6) NULL,
		BNL_FI_RATE numeric(9,6) NULL,
		BNL_LD_RATE numeric(9,6) NULL,
		BNL_INT_FREQ CHAR(1) NULL,
		BNL_FUND_CD CHAR(2) NULL,
		BNL_CUT_OFF_DT DATE NULL,
		BNL_SCH_CD CHAR(2) NULL,
		BNL_MORATORIUM numeric(3,0) NULL,
		BNL_CURRENCY CHAR(3) NULL,
		BNL_DEALWISE_AVERAGE numeric(7,4) NULL,
		BNL_INCREMENT_COST_BORROW numeric(7,4) NULL,
		BNA_SL_ACCT_NO CHAR(8) NULL,
		BNA_APPL_NO CHAR(9) NULL,
		BNL_STATUS CHAR(1) NULL,
		CONSTRAINT SYS_C00332356 PRIMARY KEY (ID)
	);

/***************************************VIGNESHA 18-06-2024 ENDS****************************************/


/***************************************VIGNESHA 04-07-2024 STARTS****************************************/
create table loi_details(
id serial primary key,
sanc_id integer not null,
sanc_detail_id integer not null,
appraisal_minute_id integer not null,
ifv_name varchar(150) not null,
ifv_no varchar(50) not null,
header_note varchar(500) null,
ifv_date DATE null,
address_of_the_bank varchar(500) null,
note1 varchar(4000) null,
note2 varchar(4000) null,
note2_subnote1 varchar(500) null,
note2_subnote2 varchar(500) null,
note3 varchar(4000) null,
loi_user varchar(150) null,
user_designation varchar(150) null
); 
alter table loi_details add constraint sanc_id_fk foreign key(sanc_id) references s2_minutes_sanction(sanct_detail_code);
alter table loi_details add constraint sanc_detail_id_fk foreign key(sanc_detail_id) references s2_minutes_sanc_dtl(sanc_dtl_code);
alter table public.loi_details add constraint appraisal_minute_id_fk foreign key(appraisal_minute_id) references s2_appraisal_minutes_data(id);


CREATE TABLE public.s2_ifv_loi_terms_conditions (
		id serial4 NOT NULL,
		ifv_id int4 NOT NULL,
		pr_id int4 NOT NULL,
		loi_id integer not null unique,
		sanc_detail_id integer not null,
		appraisal_minute_id integer not null,
		fund_code varchar(50) NOT NULL,
		fund_name varchar(150) NOT NULL,
		scheme_code varchar(50) NOT NULL,
		scheme_name varchar(150) NOT NULL,
		amount_in_words varchar(250) NOT NULL,
		amount numeric(15, 2) NOT NULL,
		ts_rateinterest numeric(38, 2) NULL,
		ts_tenure_period numeric(38, 2) NULL,
		ts_roi_repayment varchar(4000) NULL,
		ts_principal_repayment varchar(4000) NULL,
		ts_interest_payment varchar(4000) NULL,
		ts_tenure_wd varchar(4000) NULL,
		ts_extent varchar(4000) NULL,
		ts_eligiblemse varchar(4000) NULL,
		ts_eligibleactivities varchar(4000) NULL,
		ts_eventdflt varchar(4000) NULL,
		ts_security varchar(4000) NULL,
		ts_documentstion varchar(4000) NULL,
		ts_timeframe varchar(4000) NULL,
		ts_drawalloan varchar(4000) NULL,
		ts_othercond varchar(4000) NULL,
		ts_outstandingamount varchar(4000) NULL,
		ts_drawaloan varchar(255) NULL,
		ts_termsection varchar(255) NULL,
		ts_extra_conditions varchar(4000) NULL,
		ts_tenure_approx varchar(150) NULL,
		CONSTRAINT s2_ifv_loi_terms_conditions_pkey PRIMARY KEY (id)
	);


	ALTER TABLE public.s2_ifv_loi_terms_conditions ADD CONSTRAINT ifv_id_fkey FOREIGN KEY (ifv_id) REFERENCES public.s2_ifv_application(ifv_id);
	ALTER TABLE public.s2_ifv_loi_terms_conditions ADD CONSTRAINT pr_id_fkey FOREIGN KEY (pr_id) REFERENCES public.s2_ifv_proposed_schema(pr_id);
	ALTER TABLE public.s2_ifv_loi_terms_conditions ADD CONSTRAINT loi_id_fkey FOREIGN KEY (loi_id) REFERENCES public.loi_details(id);
	ALTER TABLE public.s2_ifv_loi_terms_conditions ADD CONSTRAINT sanc_detail_id_fkey FOREIGN KEY (sanc_detail_id) REFERENCES public.s2_minutes_sanc_dtl(sanc_dtl_code);
	alter table public.s2_ifv_loi_terms_conditions add constraint appraisal_minute_id_fk foreign key(appraisal_minute_id) references s2_appraisal_minutes_data(id);

	
	alter table s2_ifv_application add column internal_rating varchar(4000);
	alter table s2_ifv_proposed_schema  add column interest_type varchar(150);
	alter table s2_ifv_proposed_schema  add column scheme_short_name varchar(50);
	alter table s2_ifv_proposed_schema  add column bench_mark varchar(150);
	alter table s2_ifv_proposed_schema  add column spread varchar(150);
	alter table s2_ifv_proposed_schema  add column interest_reset varchar(150);


	alter table s2_ifv_sanction_terms_conditions add column interest_type varchar(150);
	alter table s2_ifv_sanction_terms_conditions add column benchmark varchar(150);
	alter table s2_ifv_sanction_terms_conditions add column spread varchar(150);
	alter table s2_ifv_sanction_terms_conditions add column interest_reset varchar(150);
	alter table s2_ifv_sanction_terms_conditions add column bench_mark_note varchar(4000);
	alter table s2_ifv_sanction_terms_conditions add column interest_reset_note varchar(4000);
/***************************************VIGNESHA 04-07-2024 ENDS****************************************/
	
	
/***************************************VIGNESHA 28-07-2024 STARTS****************************************/
	alter table loi_details add column name_of_documents varchar(1000);
	alter table loi_details add column document_dated date;
	alter table loi_details add column section_or_clause_no varchar(500);
	alter table loi_details add column section_mode varchar(150);
	alter table loi_details add column kyc_documents varchar(500);

	alter table s2_ifv_loi_terms_conditions add column interest_type varchar(150);
	alter table s2_ifv_loi_terms_conditions add column benchmark varchar(150);
	alter table s2_ifv_loi_terms_conditions add column spread varchar(150);
	alter table s2_ifv_loi_terms_conditions add column interest_reset varchar(150);
	alter table s2_ifv_loi_terms_conditions add column bench_mark_note varchar(4000);
	alter table s2_ifv_loi_terms_conditions add column interest_reset_note varchar(4000);


	create table ucb_borrowers_details(
	id serial primary key,
	ifv_id integer not null,
	tot_borrowers integer,
	tot_msme_customers integer ,
	tot_corp_borrowers integer ,
	remarks varchar(4000) 
	); 
	alter table ucb_borrowers_details add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);

	alter table public.s2_ifv_financialhighlights add column restructured_asset_flag varchar(10);

	create table disclosure_divergence_details(
	id serial primary key,
	ifv_id integer not null,
	particulars varchar(4000) ,
	amount numeric(15,2) ,
	dis_type varchar(150) ,
	remarks varchar(4000) 
	); 
	alter table disclosure_divergence_details add constraint ifv_id_fk foreign key(ifv_id) references s2_ifv_application(ifv_id);

/***************************************VIGNESHA 28-07-2024 ENDS****************************************/
	
/***************************************VIGNESHA 01-09-2024 STARTS****************************************/
	alter table s2_ifv_proposed_schema add column roi_note varchar(500);
	alter table s2_ifv_application add column ifv_short_name varchar(500);
	ALTER TABLE public.s2_ifv_proposed_schema ALTER COLUMN pr_amount TYPE numeric(20,8);
	 
	ALTER TABLE public.s2_ifv_proposed_schema ALTER COLUMN pr_amount TYPE numeric(20,8);
	ALTER TABLE public.s2_ifv_sanction_terms_conditions ALTER COLUMN amount TYPE numeric(20,8);
	 
	ALTER TABLE public.s2_ifv_application ALTER COLUMN ifv_exposure_limit TYPE numeric(20,8);
	ALTER TABLE public.s2_ifv_application ALTER COLUMN ifv_existing_os TYPE numeric(20,8);
	ALTER TABLE public.s2_ifv_application ALTER COLUMN ifv_prop_exposure TYPE numeric(20,8);
	ALTER TABLE public.s2_ifv_application ALTER COLUMN ifv_total_exposure TYPE numeric(20,8);
/***************************************VIGNESHA 01-09-2024 ENDS*****************************************/
	
/***************************************Released to production on 15-09-2024 ****************************************/
	
/***************************************VIGNESHA 18-09-2024 STARTS****************************************/
	ALTER TABLE public.ucb_eligibility_criteria ADD COLUMN relaxation_cap varchar(4000);
	ALTER TABLE public.tbl_ifv_module_fwd ADD COLUMN lock_comment varchar(4000);
	ALTER TABLE public.tbl_ifv_module_fwd ADD COLUMN checker1_comment varchar(4000);
	ALTER TABLE public.tbl_ifv_module_fwd ADD COLUMN checker2_comment varchar(4000);
	ALTER TABLE public.tbl_ifv_module_fwd ADD COLUMN checker3_comment varchar(4000);
	ALTER TABLE public.tbl_ifv_module_fwd ADD COLUMN checker4_comment varchar(4000);
	
	ALTER TABLE public.s2_ifv_principal ALTER COLUMN pl_repayment TYPE varchar(4000);
ALTER TABLE public.s2_ifv_principal ALTER COLUMN pl_intpayment TYPE varchar(4000);

ALTER TABLE public.s2_ifv_file_repository DROP CONSTRAINT sanc_min_detail_id_fk;
ALTER TABLE public.s2_ifv_file_repository ADD CONSTRAINT sanc_min_detail_id_fk FOREIGN KEY (sanc_min_detail_id) REFERENCES public.s2_minutes_sanction(sanct_detail_code);

ALTER TABLE public.s2_appraisal_minutes_data ALTER COLUMN loan_amount TYPE numeric(20,8);


ALTER TABLE public.s2_minutes_sanction ADD COLUMN created_modified_user varchar(20);
ALTER TABLE public.s2_minutes_sanction ADD COLUMN forwarded_stage1_user varchar(20);
ALTER TABLE public.s2_minutes_sanction ADD COLUMN forwarded_stage2_user varchar(20);
ALTER TABLE public.s2_minutes_sanction ADD COLUMN current_user_emp_id varchar(20);

ALTER TABLE public.s2_minutes_sanction ADD COLUMN forwarded_stage1_date_time timestamp;
ALTER TABLE public.s2_minutes_sanction ADD COLUMN forwarded_stage2_date_time timestamp;


alter table s2_ifv_eligibility add column rmse1_data varchar(4000);
alter table s2_ifv_eligibility add column rmse2_data varchar(4000);
alter table s2_ifv_eligibility add column rmse3_data varchar(4000);
alter table s2_ifv_eligibility add column rmse4_data varchar(4000);
alter table s2_ifv_eligibility add column rmse5_data varchar(4000);

alter table s2_ifv_eligibility add column rmse3_remarks varchar(4000);
alter table s2_ifv_eligibility add column rmse4_remarks varchar(4000);
alter table s2_ifv_eligibility add column rmse5_remarks varchar(4000);

alter table s2_ifv_eligibility add column rmse3_status varchar(150);
alter table s2_ifv_eligibility add column rmse4_status varchar(150);
alter table s2_ifv_eligibility add column rmse5_status varchar(150);

alter table s2_ifv_file_repository add column loi_id integer;
alter table s2_ifv_file_repository add constraint loi_id_fk foreign key (loi_id) references loi_details(id);

CREATE TABLE failed_email_logs (
	    id BIGSERIAL PRIMARY KEY,
	    ifv_id BIGINT,
	    module VARCHAR(50),
	    error_message TEXT,
	    retry_attempts INTEGER,
	    email_content TEXT,
	    recipient_details TEXT,
	    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
	    CONSTRAINT fk_ifv_id FOREIGN KEY (ifv_id) REFERENCES s2_ifv_application(ifv_id)
	);
	CREATE INDEX idx_failed_email_logs_ifv_id ON failed_email_logs(ifv_id);
	CREATE INDEX idx_failed_email_logs_created_at ON failed_email_logs(created_at);
	CREATE TABLE minutes_documents (
	    id BIGSERIAL PRIMARY KEY,
	    module VARCHAR(50),
	    minute_id BIGINT,
	    document_name VARCHAR(255) NOT NULL,
	    document_type VARCHAR(100) NOT NULL,
	    document_content BYTEA NOT NULL,
	    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
	    updated_at TIMESTAMP,
	    created_by varchar(150),
	    updated_by varchar(150),
	    status varchar(50),
	    uploaded_user_id BIGINT,
	    CONSTRAINT fk_minute_id FOREIGN KEY (minute_id) REFERENCES s2_minutes_sanction(sanct_detail_code),
	    CONSTRAINT fk_uploaded_user_id FOREIGN KEY (uploaded_user_id) REFERENCES tbl_ifv_login(ofr_code)
	);

	alter table s2_appraisal_minutes_data add constraint unique_sanc unique(sanc_dtl_code,app_id,pr_id);
	
	alter table s2_ifv_loi_terms_conditions drop constraint s2_ifv_loi_terms_conditions_loi_id_key;
	
	ALTER TABLE public.s2_ifv_loi_terms_conditions ALTER COLUMN amount TYPE numeric(20,8);
/***************************************VIGNESHA 18-09-2024 ENDS******************************************/
	
/***************************************VIGNESHA 06-11-2024 STARTS******************************************/

	DELETE FROM SMART.S2_IFV_SANCTION_DT;
	ALTER TABLE SMART.S2_IFV_SANCTION_DT MODIFY BNA_APPL_AMT NUMBER(20,8);
	ALTER TABLE SMART.S2_IFV_SANCTION_DT MODIFY BNA_PRJCT_COST NUMBER(20,8);
	ALTER TABLE SMART.S2_IFV_SANCTION_DT MODIFY BNL_SANCT_AMT NUMBER(20,8);
/***************************************VIGNESHA 06-11-2024 ENDS******************************************/
	
/***************************************Released to production on 11-11-2024****************************************/
	
/***************************************VIGNESHA 29-11-2024 STARTS******************************************/
	alter table tbl_ifv_module_fwd add column maker_designation varchar(150);
	alter table s2_ifv_areasgeographical add column rrb_state_name varchar(150);
	alter table S2_IFV_SANCTION_DT add column BNL_SR_NO integer;
	
/***************************************VIGNESHA 29-11-2024 ENDS******************************************/
	
/***************************************VIGNESHA 17-12-2024 STARTS******************************************/
	ALTER TABLE S2_IFV_SANCTION_DT ADD (loi_no VARCHAR2(500));
	ALTER TABLE S2_IFV_SANCTION_DT ADD (loi_date DATE);
	alter table S2_IFV_SANCTION_DT add (BNL_SR_NO NUMBER);
	ALTER TABLE S2_IFV_SANCTION_DT ADD CONSTRAINT bnl_sr_no_unique UNIQUE (bnl_sr_no);
	
	create table dfs_error_log(
			id serial primary key,
			minute_ids varchar(200),
			error_msg varchar(4000)
			);

	alter table s2_ifv_sanction_dt add column loi_no varchar(500);
	alter table s2_ifv_sanction_dt add column loi_date date;
	alter table S2_IFV_SANCTION_DT add constraint bnl_sr_no_unique unique(bnl_sr_no);
	alter table s2_minutes_sanction add column benchmark_note varchar(4000);

/***************************************VIGNESHA 17-12-2024 ENDS******************************************/
	/***************************************Released to production on 21-12-2024****************************************/
	
	/***************************************VIGNESHA 10-01-2025 STARTS******************************************/
	alter table s2_ifv_sfb_commondt add column past_disb_note varchar(4000);
	alter table s2_ifv_sfb_commondt add column outstandings_note varchar(4000);
	alter table s2_ifv_sfb_commondt add column future_rep_note varchar(4000);
	/***************************************VIGNESHA 10-01-2025 ENDS******************************************/
	
	/***************************************Released to production on 13-01-2025****************************************/
	
	/***************************************VIGNESHA 22-01-2025 STARTS******************************************/
	alter table s2_appraisal_minutes_data add column interest_type varchar(150);
	alter table s2_appraisal_minutes_data add column bench_mark varchar(150);
	alter table s2_appraisal_minutes_data add column spread varchar(150);
	alter table s2_appraisal_minutes_data add column interest_reset varchar(150);
	alter table s2_appraisal_minutes_data add column maturity_date date;

	alter table s2_ifv_sanction_dt add column bnl_interest_type varchar(150);
	alter table s2_ifv_sanction_dt add column bnl_benchmark varchar(150);
	alter table s2_ifv_sanction_dt add column bnl_spread varchar(150);
	alter table s2_ifv_sanction_dt add column bnl_interest_reset varchar(150);
	alter table s2_ifv_sanction_dt add column bnl_maturity_date DATE;
	alter table s2_ifv_sanction_dt add column bnl_principal_repayment varchar(150);
	alter table s2_ifv_sanction_dt add column bnl_tenure integer;
	alter table s2_ifv_sanction_dt add column tranche numeric(20,8);
	
	alter table s2_ifv_proposed_schema add column incremental_cost_borrowing numeric(20,8);
	alter table s2_ifv_proposed_schema add column dealwise_average numeric(20,8);
	alter table s2_ifv_proposed_schema add column tranche numeric(20,8);
	
	CREATE TABLE assistance_applied_for (
			id bigserial NOT null primary key,
			ifv_id int8 NOT NULL,
			pr_id int8 null,
			scheme_name varchar(250) NULL,
			scheme_code varchar(150) NULL,
			fund_name varchar(250) NULL,
			fund_code varchar(150) NULL,
			amount numeric(20, 8) null,
			vide_date date null
		);

		alter table assistance_applied_for add constraint ifv_id_fk foreign key (ifv_id) references s2_ifv_application(ifv_id);
		
		alter table s2_ifv_sfb_commondt add column interest_reset varchar(4000);
		
		CREATE TABLE ifv_proposal_fwd_checker_details (
			    id BIGSERIAL PRIMARY KEY,
			    ifv_id BIGINT NOT NULL,
			    fwd_rej_status CHAR(1) NOT NULL CHECK (fwd_rej_status IN ('F', 'R','A')),
			    current_user_id BIGINT,
			    current_user_name VARCHAR(150),
			    current_user_designation VARCHAR(150),
			    current_user_action VARCHAR(20),
			    date_time_of_receipt TIMESTAMP WITH TIME ZONE NOT NULL,
			    date_time_of_action TIMESTAMP WITH TIME ZONE NOT NULL,
			    current_user_fwd_rej_comment VARCHAR(4000),
			    fwd_rej_user_id BIGINT,
			    fwd_rej_user_name VARCHAR(150),
			    fwd_rej_user_designation VARCHAR(150),
			    CONSTRAINT ifv_id_fk FOREIGN KEY (ifv_id) REFERENCES s2_ifv_application(ifv_id)
			);

			alter table s2_ifv_file_repository add column prop_loi_id integer;

			CREATE TABLE ifv_proposals_loi (
				id serial PRIMARY KEY,
				ifv_id int4 NOT NULL,
				ifv_name varchar(150) NOT NULL,
				app_number varchar(100) not null,
				pr_ids varchar(150),
				loi_no varchar(50) NOT NULL,
				loi_date Date,
				amount numeric(20,8),
				amount_in_words varchar(1000),
				fund_name varchar(250),
				scheme_name varchar(250),
				ifv_app_dated date,
				header_note varchar(500) NULL,
				address_of_the_bank varchar(4000) NULL,
				note1 varchar(4000) NULL,
				note2 varchar(4000) NULL,
				note2_subnote1 varchar(500) NULL,
				note2_subnote2 varchar(500) NULL,
				note3 varchar(4000) NULL,
				loi_user integer,
				name_of_documents varchar(1000) NULL,
				document_dated date NULL,
				section_or_clause_no varchar(500) NULL,
				section_mode varchar(150) NULL,
				kyc_documents varchar(500) NULL
			);
			
			//SMART STARTS
			alter table S2_IFV_SANCTION_DT add (BNL_INTEREST_TYPE VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (BNL_BENCHMARK VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (BNL_SPREAD VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (BNL_INTEREST_RESET VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (BNL_MATURITY_DATE DATE);
			alter table S2_IFV_SANCTION_DT add (BNL_PRINCIPAL_REPAYMENT VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (BNL_TENURE NUMBER);
			alter table S2_IFV_SANCTION_DT add (TRANCHE, NUMBER(20,8));
			//SMART ENDS
	/***************************************VIGNESHA 22-01-2025 ENDS******************************************/
			
/***************************************Released to production on 1st March 2025******************************************/

/***************************************VIGNESHA 06-03-2025 STARTS******************************************/
			
			alter table s2_cmt_member_master add column member_mail_id varchar(150);
			alter table s2_minutes_sanction add column current_checker_id integer;
			
			CREATE TABLE ifv_minutes_fwd_checker_details (
				    id BIGSERIAL PRIMARY KEY,
				    minute_id BIGINT NOT NULL,
				    minute_file_id BIGINT,
				    fwd_rej_status CHAR(1) NOT NULL CHECK (fwd_rej_status IN ('F', 'R','A')),
				    current_user_id BIGINT,
				    current_user_name VARCHAR(150),
				    current_user_designation VARCHAR(150),
				    current_user_action VARCHAR(20),
				    date_time_of_receipt TIMESTAMP WITH TIME ZONE NOT NULL,
				    date_time_of_action TIMESTAMP WITH TIME ZONE NOT NULL,
				    current_user_fwd_rej_comment VARCHAR(4000),
				    fwd_rej_user_id BIGINT,
				    fwd_rej_user_name VARCHAR(150),
				    fwd_rej_user_designation VARCHAR(150),
				    CONSTRAINT minute_id_fk FOREIGN KEY (minute_id) REFERENCES s2_minutes_sanction(sanct_detail_code)
				);
			
/***************************************VIGNESHA 06-03-2025 ENDS******************************************/
			
/***************************************VIGNESHA 25-06-2025 STARTS******************************************/
			
			alter table s2_ifv_proposed_schema add column incremental_cost_borrowing_type varchar(100);
			alter table s2_ifv_proposed_schema add column pr_moratorium_period integer;
			alter table s2_ifv_proposed_schema add column icb_fixed_floating varchar(100);
			alter table s2_ifv_proposed_schema add column icb_benchmark varchar(100);
			alter table s2_ifv_proposed_schema add column icb_spread varchar(100);
			
			alter table S2_IFV_SANCTION_DT add column incremental_cost_borrowing_type varchar(100);
			alter table S2_IFV_SANCTION_DT add column icb_fixed_floating varchar(100);
			alter table S2_IFV_SANCTION_DT add column icb_benchmark varchar(100);
			alter table S2_IFV_SANCTION_DT add column icb_spread varchar(100);
			
			alter table loi_details add column cv_language varchar(150);
			alter table loi_details add column cv_region varchar(1);
			
			//SMART
			alter table S2_IFV_SANCTION_DT add (incremental_cost_borrowing_type VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (icb_fixed_floating VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (icb_benchmark VARCHAR2(150));
			alter table S2_IFV_SANCTION_DT add (icb_spread VARCHAR2(150));
			
/***************************************VIGNESHA 25-06-2025 ENDS******************************************/
			
/***************************************VIGNESHA 04-11-2025 STARTS******************************************/
			alter table S2_IFV_FILE_REPOSITORY add column file_path varchar(150);
			
/***************************************VIGNESHA 04-11-2025 ENDS******************************************/
			
/***************************************VIGNESHA 17-03-2026 STARTS******************************************/
			CREATE TABLE ifv_rimv_apps (
				    id BIGSERIAL PRIMARY KEY,
				    rimv_ref_id varchar(20) not null,
				    cif_number varchar(150) not null,
				    bank_name varchar(150) NOT NULL,
				    current_user_id BIGINT,
				    current_user_name VARCHAR(150),
				    created_date_time timestamp,
				    fwd_status varchar(50),
				    forwarded_date_time timestamp,
				    fwd_comments VARCHAR(4000),
				    fwd_user_id BIGINT,
				    fwd_by VARCHAR(150),
				    rimv_comments varchar(4000),
				    rimv_file_path varchar(500),
				    rimv_updated_date_time TIMESTAMP,
				    single_scale_rating varchar(150),
				    combined_rating varchar(150),
				    CONSTRAINT current_user_id_fk FOREIGN KEY (current_user_id) REFERENCES tbl_ifv_login(ofr_code)
				);
			
			CREATE TABLE ifv_rimv_docs (
				    id BIGSERIAL PRIMARY KEY,
				    ifv_rimv_app_id BIGINT NOT NULL,
				    file_module varchar(150) NOT NULL,
				    file_sub_module varchar(150) NOT NULL,
				    file_name varchar(150) NOT NULL,
				    file_type varchar(100) NOT NULL,
				    file_path varchar(150) NOT NULL,
				    uploaded_date_time TIMESTAMP NOT NULL,
				    remarks VARCHAR(4000),
				    CONSTRAINT ifv_rimv_app_id_fk FOREIGN KEY (ifv_rimv_app_id) REFERENCES ifv_rimv_apps(id)
				);
			
			CREATE TABLE ifv_beneficiary_details (
				    id BIGSERIAL PRIMARY KEY,
				    bank_name VARCHAR(150),
				    cif_number VARCHAR(100),
				    file_name VARCHAR(150),
				    file_path VARCHAR(500),
				    file_type VARCHAR(150),
				    file_size BIGINT,
				    upload_date_time TIMESTAMP,
				    upload_by VARCHAR(150),
				    remarks VARCHAR(4000),
				    loan_acc_no varchar(50),
				    ben_pre_disb_flag varchar(10),
				    ben_ref_no varchar(50),
				    disb_date varchar(50),
				    ref_date timestamp
				);
			
			CREATE TABLE beneficiary_users (
				    id serial4 NOT NULL PRIMARY KEY,
				    user_id varchar(20) NOT NULL,
				    password varchar(500) NULL,
				    user_type varchar(100) NULL,
				    user_name varchar(150) NULL,
				    user_short_name varchar(150) NULL,
				    user_active char(1) NULL DEFAULT 'Y',
				    user_lock numeric(5),
				    user_lock_date_time timestamp NULL,
				    created_date_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				    created_by varchar(150) NULL DEFAULT 'ADMIN',
				    CONSTRAINT uk_beneficiary_users_user_id UNIQUE (user_id)
				);
			

			CREATE TABLE ifv_beneficiary_apps (
				id serial4 NOT NULL,
				bn_ref_no varchar(20) NULL,
				file_name varchar(150) NULL,
				file_path varchar(500) NULL,
				file_type varchar(150) NULL,
				upload_date_time timestamp NULL,
				upload_by varchar(150) NULL,
				remarks varchar(4000) NULL,
				CONSTRAINT ifv_beneficiary_apps_pkey PRIMARY KEY (id)
			);
			
			alter table s2_ifv_financialhighlights add column fy_ended_audit varchar(100);
			alter table s2_ifv_financialhighlights add column fy_result_audit varchar(100);
/***************************************VIGNESHA 17-03-2026 ENDS******************************************/	
			
	/***************************************Released to production******************************************/			
			
			
			
	/***************************************VIGNESHA 7-04-2026 STARTS******************************************/		
			
			CREATE TABLE s2_minutes_colending_limit (
					id bigserial NOT NULL,
					minute_sanction_id int4 NOT NULL,
					bank_name varchar(100) NOT NULL,
					cif_number varchar(100) NOT NULL,
					lending_limit numeric(20,8),
					scheme varchar(150),
					risk_sharing_ratio varchar(150),
					initial_operating_limit numeric(20,8),
					remarks varchar(1500) NULL,
					created_by varchar(200) NULL,
					created_date date NOT NULL,
					sanc_status varchar(150) NULL,
					CONSTRAINT s2_minutes_colending_limit_pkey PRIMARY KEY (id)
				);

				ALTER TABLE s2_minutes_colending_limit ADD CONSTRAINT minute_sanction_id_fk FOREIGN KEY (minute_sanction_id) REFERENCES s2_minutes_sanction(sanct_detail_code);
				CREATE TABLE s2_minutes_other_items (
				    id bigserial PRIMARY KEY,
				    minute_sanction_id int4 NOT NULL,
				    bank_name varchar(100) NOT NULL,
				    cif_number varchar(100) NOT NULL,
				    remarks varchar(1500),
				    created_by varchar(200),
				    created_date date NOT NULL,
				    sanc_status varchar(150)
				);

				ALTER TABLE s2_minutes_other_items
				ADD CONSTRAINT s2_minutes_other_items_minute_sanction_fk
				FOREIGN KEY (minute_sanction_id)
				REFERENCES s2_minutes_sanction (sanct_detail_code);

				CREATE TABLE s2_minutes_interest_reset (
				    id bigserial PRIMARY KEY,
				    minute_sanction_id int4 NOT NULL,
				    bank_name varchar(100) NOT NULL,
				    cif_number varchar(100) NOT NULL,
				    amount numeric(20,8),
				    period_in_months integer,
				    reset_date date,
				    rate_of_interest numeric(5,2),
				    cost_of_funds numeric(5,2),
				    reset_due_date date NOT NULL,
				    remarks varchar(1500),
				    created_by varchar(200),
				    created_date date NOT NULL,
				    sanc_status varchar(150)
				);

				ALTER TABLE s2_minutes_interest_reset
				ADD CONSTRAINT s2_minutes_interest_reset_minute_sanction_fk
				FOREIGN KEY (minute_sanction_id)
				REFERENCES s2_minutes_sanction (sanct_detail_code);
			
/***************************************VIGNESHA 7-04-2026 ENDS******************************************/

/**********************Released to prod**********************/


/***************************************VIGNESHA 27-05-2026 STARTS******************************************/		

CREATE TABLE ifv_aggregate_exposure (
    id BIGSERIAL PRIMARY KEY,
    ifv_id INTEGER NOT NULL,
    capital_funds NUMERIC(20,8) NOT NULL,
    sl_no INTEGER NOT NULL,
    particulars varchar(1000) NOT NULL,
    amount numeric(20,8) not null,
    group_name varchar(255) null,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE ifv_aggregate_exposure
ADD CONSTRAINT fk_ifv
FOREIGN KEY (ifv_id)
REFERENCES s2_ifv_application (ifv_id);

ALTER TABLE ifv_aggregate_exposure
ADD CONSTRAINT uq_ifv_slno UNIQUE (ifv_id, sl_no);

//SMART
CREATE TABLE SMART.IFV_AGG_EXPOSURE_JOB (
    ID NUMBER GENERATED BY DEFAULT AS IDENTITY
        MINVALUE 1
        MAXVALUE 9999999999999999999999999999
        INCREMENT BY 1
        START WITH 1
        CACHE 20
        NOCYCLE
        NOT NULL,

    AS_ON_DATE DATE NOT NULL,
    STATUS VARCHAR2(20),
    GROUP_NAME VARCHAR2(200),
    TOTAL_EXPOSURE NUMBER(24,8),
    FY NUMBER(4,0),
    ERROR_MSG CLOB,

    CREATED_AT TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    UPDATED_AT TIMESTAMP(6),

    CONSTRAINT PK_IFV_AGG_EXPOSURE_JOB PRIMARY KEY (ID),
    CONSTRAINT UK_IFV_JOB_DATE_GRP UNIQUE (AS_ON_DATE, GROUP_NAME)
);


/***************************************VIGNESHA 27-05-2026 STARTS******************************************/		
/*************************Released to prod on 18August2026******************************/
/**************************************************21-08-2026****************************************/
CREATE TABLE BEN_VALIDATION_JOB
(
    JOB_ID              VARCHAR2(50) PRIMARY KEY,
    FILE_NAME           VARCHAR2(500),
    FILE_SIZE           NUMBER(20),
    STATUS              VARCHAR2(20),
    TOTAL_RECORDS       NUMBER(10),
    VALID_RECORDS       NUMBER(10),
    INVALID_RECORDS     NUMBER(10),
    ERROR_COUNT         NUMBER(10),
    ERROR_MESSAGE       VARCHAR2(4000),
    CREATED_AT          TIMESTAMP DEFAULT SYSTIMESTAMP,
    STARTED_AT          TIMESTAMP,
    COMPLETED_AT        TIMESTAMP,
PROCESSED_ROWS     NUMBER(10),
TOTAL_ROWS_IN_FILE   NUMBER(10)
);
CREATE INDEX IDX_BEN_JOB_STATUS
ON BEN_VALIDATION_JOB(STATUS);

CREATE INDEX IDX_BEN_JOB_CREATED_AT
ON BEN_VALIDATION_JOB(CREATED_AT);
/**************************************************21-08-2026****************************************/
alter table ifv_beneficiary_details add column job_id varchar(250);
alter table ifv_beneficiary_details add column status varchar(150);

alter table ifv_beneficiary_details add column validated varchar(20);
alter table ifv_beneficiary_details add column return_remarks varchar(1000);
alter table ifv_beneficiary_details add column return_by varchar(150);
alter table ifv_beneficiary_details add column upload_by_email varchar(150);

alter table ifv_beneficiary_details add column ifv_file_name varchar(150);
alter table ifv_beneficiary_details add column ifv_file_path varchar(500);
alter table ifv_beneficiary_details add column ifv_submitted_date timestamp;
alter table ifv_beneficiary_details add column ifv_remarks varchar(1000);
alter table ifv_beneficiary_details add column ifv_submit_by varchar(150);
alter table ifv_beneficiary_details add column proceed_bank_upload varchar(20);

ALTER TABLE ifv_beneficiary_details
ADD CONSTRAINT uk_ifv_beneficiary_details_ben_ref_no
UNIQUE (ben_ref_no);

CREATE TABLE IFV_BANK_REFINANCE_APPLICATION (
    ID BIGSERIAL PRIMARY KEY,
    APP_REF_ID VARCHAR(50) NOT NULL UNIQUE,
    NAME_OF_BANK VARCHAR(200) NOT NULL,
    CIF_NUMBER VARCHAR(50) NOT NULL,
    TYPE_OF_BANK VARCHAR(100),
    FUND_CODE VARCHAR(20) NOT NULL,
    FUND_DESCRIPTION VARCHAR(500),
    SCHEME_CODE VARCHAR(50) NOT NULL,
    SCHEME_SHORT_NAME VARCHAR(200),
    SCHEME_LONG_NAME VARCHAR(500),
    CUSTOM_SCHEME_NAME VARCHAR(500),
    CURRENCY_TYPE VARCHAR(50),
    APPLICATION_STATUS VARCHAR(30),
    FRAMEWORK_PARM_TIER NUMERIC(10,2),
    FRAMEWORK_PARM_CRAR NUMERIC(10,2),
    FRAMEWORK_PARM_CET1 NUMERIC(10,2),
    FRAMEWORK_PARM_CCB NUMERIC(10,2),
    BANK_NAME VARCHAR(200),
    BANK_ACCOUNT_NO VARCHAR(100),
    RTGS_CODE VARCHAR(30),
    NEFT_CODE VARCHAR(30),
    BANK_ADDRESS VARCHAR(1000),
    LEGAL_ENTITY_IDENTIFIER VARCHAR(50),
    LEI_VALIDITY DATE,
    REFINANCE_APP_FILE_NAME VARCHAR(150),
    REFINANCE_APP_FILE_PATH VARCHAR(255),
    AUTH_SIGN_FILE_NAME VARCHAR(150),
    AUTH_SIGN_FILE_PATH VARCHAR(255),

    SUBMITTED_BY VARCHAR(200),

    SUBMITTED_DATE_TIME TIMESTAMP,

    CREATED_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IFV_BANK_REFINANCE_PROPOSAL (
    ID BIGSERIAL PRIMARY KEY,
    APPLICATION_ID BIGINT NOT NULL,
    REFINANCE_AMOUNT NUMERIC(18,2),
    RATE_TYPE VARCHAR(50),
    RATE_OF_INTEREST NUMERIC(12,4),
    BENCHMARK VARCHAR(200),
    SPREAD NUMERIC(12,4),
    TENURE_IN_MONTHS INTEGER,
    TENURE_IN_DAYS INTEGER,
    INTEREST_RESET VARCHAR(100),
    PRINCIPAL_REPAYMENT VARCHAR(200),
    MORATORIUM_MONTHS INTEGER,
    MATURITY_DATE DATE,

    CONSTRAINT FK_IFV_REF_APP_PROPOSAL
        FOREIGN KEY (APPLICATION_ID)
        REFERENCES IFV_BANK_REFINANCE_APPLICATION(ID)
);

CREATE TABLE IFV_BANK_REFINANCE_SIGNATORY (
    ID BIGSERIAL PRIMARY KEY,
    APPLICATION_ID BIGINT NOT NULL,
    NAME_OF_AUTH_SIGNATORY VARCHAR(255) NOT NULL,
    DESIGNATION VARCHAR(100),
    EMAIL VARCHAR(100),
    MOBILE_NUMBER BIGINT,
    CONSTRAINT FK_IFV_REF_APP_SIGNATORY
        FOREIGN KEY (APPLICATION_ID)
        REFERENCES IFV_BANK_REFINANCE_APPLICATION(ID)
);

ALTER TABLE IFV_BANK_REFINANCE_APPLICATION
ADD COLUMN RETURN_REMARKS VARCHAR(2000),
ADD COLUMN RETURN_BY VARCHAR(100),
ADD COLUMN RETURN_DATE_TIME TIMESTAMP;

ALTER TABLE IFV_BANK_REFINANCE_APPLICATION
ADD COLUMN SUBMIT_BY_EMAIL VARCHAR(150);

ALTER TABLE ifv_beneficiary_details
ADD COLUMN scheme VARCHAR(100),
ADD COLUMN refinance_amount NUMERIC(18,2);

ALTER TABLE s2_ifv_application
ADD COLUMN bank_app_ref_nos TEXT;

/*************************released to prod on 19 Sept 2026*************************/

CREATE TABLE IFV_LOI_DOCUMENTS (
    ID BIGSERIAL PRIMARY KEY,
    LOI_DETAILS_ID BIGINT NOT NULL,
    IFV_APP_NO VARCHAR(50) NOT NULL,
    BANK_REF_NO VARCHAR(100),
    SCHEME VARCHAR(100),
    SANCTION_AMOUNT NUMERIC(18,2),
    SANCTIONED_DATE_TIME TIMESTAMP,

    LOI_NO VARCHAR(100),

    FILE_NAME VARCHAR(500),

    FILE_PATH VARCHAR(1000),

    FILE_SIZE BIGINT,

    FILE_TYPE VARCHAR(100),

    STATUS VARCHAR(30),

    UPLOADED_BY VARCHAR(100),

    UPLOADED_DATE TIMESTAMP,

    MODIFIED_BY VARCHAR(100),

    MODIFIED_DATE TIMESTAMP,

    REMARKS VARCHAR(2000),

    CONSTRAINT FK_IFV_LOI_DOCUMENTS_LOI_DETAILS
        FOREIGN KEY (LOI_DETAILS_ID)
        REFERENCES LOI_DETAILS(ID)
);