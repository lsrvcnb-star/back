package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class PrincipalDTO {
	
	private Long plId;
	
	private Long prId;
	
	private Long ifvId;
	
	private String plRepayment;
	
	private String plIntPayment;
	
	private BigDecimal plMonths;
	
	private String plPeriod;
	
	private String plScheme;
}
