package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class CollectionEfficiencyDTO {

	private Long id;

	private Long ifvId;

	private String particulars;

	private BigDecimal collectionEfficiency;

}
