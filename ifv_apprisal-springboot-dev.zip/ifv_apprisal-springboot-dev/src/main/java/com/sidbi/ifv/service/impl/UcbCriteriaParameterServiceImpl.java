package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.UcbCriteriaParameterDTO;
import com.sidbi.ifv.entity.UcbCriteriaParameterEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.UcbCriteriaParameterRepo;
import com.sidbi.ifv.services.UcbCriteriaParameterService;

@Service
public class UcbCriteriaParameterServiceImpl implements UcbCriteriaParameterService {

	private static final Logger logger = LoggerFactory.getLogger(UcbCriteriaParameterServiceImpl.class);

	@Autowired
	private UcbCriteriaParameterRepo repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public UcbCriteriaParameterDTO findById(Long id) {
		logger.info("findById() started in UcbCriteriaParameterServiceImpl for UcbCriteriaParameterEntity {} ", id);
		UcbCriteriaParameterEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("UCBCriteriaParameterEntity", id));
		return mapper.map(entity, UcbCriteriaParameterDTO.class);
	}

	@Override
	public List<UcbCriteriaParameterDTO> findAll() {
		logger.info("findAll() started in UcbCriteriaParameterServiceImpl of UcbCriteriaParameterEntity");
		try {
			List<UcbCriteriaParameterEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, UcbCriteriaParameterDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all UcbCriteriaParameterEntity .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all UcbCriteriaParameterEntity ." + msg + " ", e);
		}
	}

	@Override
	public UcbCriteriaParameterDTO save(UcbCriteriaParameterDTO dto) {
		logger.info("save() started in UcbCriteriaParameterServiceImpl for UcbCriteriaParameterEntity {} ", dto);
		try {
			UcbCriteriaParameterEntity entity = mapper.map(dto, UcbCriteriaParameterEntity.class);
			repository.save(entity);
			return mapper.map(entity, UcbCriteriaParameterDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating UcbCriteriaParameterEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  UcbCriteriaParameterEntity." + msg + " ", e);
		}
	}

	@Override
	public List<UcbCriteriaParameterDTO> saveAll(List<UcbCriteriaParameterDTO> dtos) {
		logger.info("saveAll() started in UcbCriteriaParameterServiceImpl for List of UcbCriteriaParameterEntity");
		try {

			List<UcbCriteriaParameterEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, UcbCriteriaParameterEntity.class)).collect(Collectors.toList());
			List<UcbCriteriaParameterEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, UcbCriteriaParameterDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all UcbCriteriaParameterEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all UcbCriteriaParameterEntity." + msg + " ", e);
		}
	}

	@Override
	public UcbCriteriaParameterDTO update(Long id, UcbCriteriaParameterDTO dto) {
		logger.info("update() started in UcbCriteriaParameterServiceImpl for UcbCriteriaParameterEntity {} {} ", id,
				dto);
		try {
			UcbCriteriaParameterEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbCriteriaParameterEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, UcbCriteriaParameterDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating UcbCriteriaParameterEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating UcbCriteriaParameterEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in UcbCriteriaParameterServiceImpl for UcbCriteriaParameterEntity {} ", id);
		try {
			UcbCriteriaParameterEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("UcbCriteriaParameterEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting UcbCriteriaParameterEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting UcbCriteriaParameterEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<UcbCriteriaParameterDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in UcbCriteriaParameterServiceImpl for UcbCriteriaParameterEntity {} ",
				ifvId);
		try {

			List<UcbCriteriaParameterEntity> list = repository.findByIfvId(ifvId);
			return (list != null
					&& !list.isEmpty())
							? list.stream().sorted(Comparator.comparing(UcbCriteriaParameterEntity::getId))
									.map(UcbCriteriaParameterEntity -> mapper.map(UcbCriteriaParameterEntity,
											UcbCriteriaParameterDTO.class))
									.collect(Collectors.toList())
							: new ArrayList<>();

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId UcbCriteriaParameterEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId UcbCriteriaParameterEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
