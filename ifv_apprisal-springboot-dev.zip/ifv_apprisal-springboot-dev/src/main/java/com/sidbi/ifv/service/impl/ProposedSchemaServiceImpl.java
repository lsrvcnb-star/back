package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.AssistanceAppliedForDto;
import com.sidbi.ifv.dto.IfvAggregateExposureDto;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.entity.AssistanceAppliedForEntity;
import com.sidbi.ifv.entity.IfvAggregateExposure;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVEligibilityEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.AssistanceAppliedForRepository;
import com.sidbi.ifv.repo.EligibilityRepository;
import com.sidbi.ifv.repo.IfvAggregateExposureRepository;
import com.sidbi.ifv.repo.PrincipalRepository;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.repo.SanctionTermsConditionsRepository;
import com.sidbi.ifv.repo.TermConditionsDataRepository;
import com.sidbi.ifv.services.ProposedSchemaService;
import com.sidbi.ifv.util.CommonUtil;

import jakarta.transaction.Transactional;

@Service
public class ProposedSchemaServiceImpl implements ProposedSchemaService {

	private static final Logger logger = LoggerFactory.getLogger(ProposedSchemaServiceImpl.class);

	@Autowired
	private ProposedSchemaRepository repository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CommonUtil commonUtil;

	String msg = "";

	@Autowired
	private SanctionTermsConditionsRepository sanctionTermsConditionsRepository;

	@Autowired
	private TermConditionsDataRepository termConditionsDataRepository;

	@Autowired
	private PrincipalRepository principalRepository;

	@Autowired
	private EligibilityRepository eligibilityRepository;

	@Autowired
	private AssistanceAppliedForRepository assistanceAppliedForRepository;

	@Override
	public ProposedSchemaDTO findById(Long id) {
		return null;
	}

	@Autowired
	private IfvAggregateExposureRepository aggregateExposureRepository;

	@Override
	public List<ProposedSchemaDTO> findAll() {
		logger.info("findAll() started in ProposedSchemaServiceImpl of S2IFVProposedSchemaEntity");
		try {
			List<S2IFVProposedSchemaEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, ProposedSchemaDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVProposedSchemaEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVProposedSchemaEntities ." + msg + " ", e);
		}
	}

	@Override
	public ProposedSchemaDTO save(ProposedSchemaDTO dto) {
		return null;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<ProposedSchemaDTO> saveAll(List<ProposedSchemaDTO> dtos) {
		logger.info("saveAll() started in S2IFVProposedSchemaServiceImpl for List of S2IFVProposedSchemaEntity");

		try {

			List<S2IFVProposedSchemaEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, S2IFVProposedSchemaEntity.class)).collect(Collectors.toList());
			List<S2IFVProposedSchemaEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, ProposedSchemaDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVProposedSchemaEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVProposedSchemaEntities." + msg + " ", e);
		}
	}

	@Override
	public ProposedSchemaDTO update(Long id, ProposedSchemaDTO dto) {

		logger.info("update() started in S2IFVProposedSchemaServiceImpl for S2IFVProposedSchemaEntity {} {} ", id, dto);
		try {
			S2IFVProposedSchemaEntity existingProposedSchemaEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAlcoProposalEntity", id));
			BeanUtils.copyProperties(dto, existingProposedSchemaEntity, commonUtil.getNullPropertyNames(dto));
			repository.save(existingProposedSchemaEntity);
			return mapper.map(existingProposedSchemaEntity, ProposedSchemaDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVProposedSchemaEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVProposedSchemaEntity of id ." + msg + " " + id + " ", e);
		}

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public void delete(Long id) {
		logger.info("delete() started in S2IFVProposedSchemaServiceImpl for S2IFVProposedSchemaEntity {} ", id);
		try {

			S2IFVProposedSchemaEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("SanctionDtlEntity", id));
			Long prId = existingEntity.getPrId();
			Long ifvId = existingEntity.getIfvId();
			deleteSanctiontermsConditionsOnPrid(prId);
			deletePrincipalRepositoryOnPrid(prId);
			setRecommendationInTermsConditionsData(ifvId);

			repository.delete(existingEntity);

			setEligibilityCriteria(ifvId);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVProposedSchemaEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVProposedSchemaEntity of id ." + msg + " " + id, e);
		}

	}

	public void setEligibilityCriteria(Long ifvId) {
		try {
			List<S2IFVProposedSchemaEntity> listProposedSchemaEntities = repository.findByIfvId(ifvId);
			S2IFVEligibilityEntity eligibilityEntity = eligibilityRepository.getByIfvId(ifvId);
			if (eligibilityEntity != null && eligibilityEntity.getEcId() > 0) {
				boolean isRMSE = listProposedSchemaEntities.stream().map(S2IFVProposedSchemaEntity::getPrFundname)
						.anyMatch(e -> e.contains("RMSE"));
				if (isRMSE) {
					List<String> rmseRegular = listProposedSchemaEntities.stream()
							.map(S2IFVProposedSchemaEntity::getPrFundname)
							.filter(fundName -> fundName.contains("RMSE") && !fundName.contains("ICDD"))
							.collect(Collectors.toList());
					String findICDD = determineICDDData(eligibilityEntity);
					updateRMSEData(eligibilityEntity, rmseRegular.size(), findICDD);
					eligibilityRepository.save(eligibilityEntity);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String determineICDDData(S2IFVEligibilityEntity eligibilityEntity) {
		if (StringUtils.hasText(eligibilityEntity.getRmse5Data())) {
			return eligibilityEntity.getRmse5Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse4Data())) {
			return eligibilityEntity.getRmse4Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse3Data())) {
			return eligibilityEntity.getRmse3Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse2Data())) {
			return eligibilityEntity.getRmse2Data();
		} else if (StringUtils.hasText(eligibilityEntity.getRmse1Data())) {
			return eligibilityEntity.getRmse1Data();
		} else {
			return "Availability of assets in the 196 identified credit deficient districts.";
		}
	}

	private void updateRMSEData(S2IFVEligibilityEntity entity, int rmseRegularSize, String icddData) {
		String defaultEligibilityText = "Eligibility as per RBI letter dated _________, for having achived PSL target for lending to Micro enterprise in FY _____.";
		if (rmseRegularSize == 0) {
			entity.setRmse1Data(icddData);
			entity.setRmse2Data("");
			entity.setRmse3Data("");
			entity.setRmse4Data("");
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 1) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(icddData);
			entity.setRmse3Data("");
			entity.setRmse4Data("");
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 2) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(getOrDefaultText(entity.getRmse2Data(), defaultEligibilityText));
			entity.setRmse3Data(icddData);
			entity.setRmse4Data("");
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 3) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(getOrDefaultText(entity.getRmse2Data(), defaultEligibilityText));
			entity.setRmse3Data(getOrDefaultText(entity.getRmse3Data(), defaultEligibilityText));
			entity.setRmse4Data(icddData);
			entity.setRmse5Data("");
		} else if (rmseRegularSize == 4) {
			entity.setRmse1Data(getOrDefaultText(entity.getRmse1Data(), defaultEligibilityText));
			entity.setRmse2Data(getOrDefaultText(entity.getRmse2Data(), defaultEligibilityText));
			entity.setRmse3Data(getOrDefaultText(entity.getRmse3Data(), defaultEligibilityText));
			entity.setRmse4Data(getOrDefaultText(entity.getRmse4Data(), defaultEligibilityText));
			entity.setRmse5Data(icddData);
		}
	}

	private String getOrDefaultText(String currentText, String defaultText) {
		return (!StringUtils.hasText(currentText) || currentText.contains("Availability")) ? defaultText : currentText;
	}

	@Override
	public List<ProposedSchemaDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in AlcoDataServiceImpl ");
		try {
			List<S2IFVProposedSchemaEntity> listProposedSchemaEntities = repository.findByIfvId(ifvId);
			return (listProposedSchemaEntities != null && !listProposedSchemaEntities.isEmpty())
					? listProposedSchemaEntities.stream()
							.sorted(Comparator.comparing(S2IFVProposedSchemaEntity::getPrId))
							.map(proposedSchemaEntity -> mapper.map(proposedSchemaEntity, ProposedSchemaDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVProposedSchemaEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVProposedSchemaEntities  based on IfvId." + msg + " " + ifvId,
					e);

		}
	}

	@Override
	public List<ProposedSchemaDTO> findAllByappId(String appId) {
		logger.info("findAllByappId() started in AlcoDataServiceImpl ");
		try {
			List<S2IFVApplicationEntity> list = applicationRepository.findByAppNumber(appId);
			return list.stream().findFirst().map(application -> findAllByIfvId(application.getIfvId()))
					.orElse(new ArrayList<>());
		} catch (Exception e) {
			String errorMsg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVProposedSchemaEntities based on appId. {}", errorMsg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVProposedSchemaEntities based on appId." + errorMsg + " "
							+ appId,
					e);
		}
	}

	@Transactional
	public void deleteSanctiontermsConditionsOnPrid(Long prId) {
		logger.info("Started deletePrincipalRepositoryOnPrid {} ", prId);
		try {
			sanctionTermsConditionsRepository.deleteByPrId(prId);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while deleting SanctionTermsConditionsEntity while Deleting S2IFVProposedSchemaEntity. {} ",
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleting SanctionTermsConditionsEntity while Deleting S2IFVProposedSchemaEntity of id ."
							+ msg + " " + prId,
					e);
		}
	}

	@Transactional
	public void setRecommendationInTermsConditionsData(Long ifvId) {
		logger.info("Started setRecommendationInTermsConditionsData {} ", ifvId);
		try {
			termConditionsDataRepository.updateRecommendation(null, ifvId);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while setting recommendation in S2IFVTermConditionsDataEntity while Deleting S2IFVProposedSchemaEntity. {} ",
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while setting recommendation in S2IFVTermConditionsDataEntity while  Deleting S2IFVProposedSchemaEntity of ifvId ."
							+ msg + " " + ifvId,
					e);
		}
	}

	@Transactional
	public void deletePrincipalRepositoryOnPrid(Long prId) {
		logger.info("Started deletePrincipalRepositoryOnPrid {} ", prId);
		try {
			principalRepository.deleteByPrId(prId);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while deleting S2IFVPrincipalEntity while Deleting S2IFVProposedSchemaEntity. {} ",
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleting S2IFVPrincipalEntity while Deleting S2IFVProposedSchemaEntity of id ."
							+ msg + " " + prId,
					e);
		}
	}

	@Override
	public List<AssistanceAppliedForDto> findAllAssistanceByIfvId(Long ifvId) {
		logger.info("findAllAssistanceByIfvId() started in ProposedSchemaServiceImpl of AssistanceAppliedForDto");
		try {
			List<AssistanceAppliedForEntity> list = assistanceAppliedForRepository.findByIfvId(ifvId,
					Sort.by(Sort.Direction.ASC, "id"));
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, AssistanceAppliedForDto.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all AssistanceAppliedForDto .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all AssistanceAppliedForDto ." + msg + " ", e);
		}
	}

	@Override
	public AssistanceAppliedForDto findAssistanceById(Long id) {
		logger.info("findAssistanceById() started in ApplicationServiceImpl for AssistanceAppliedForDto {} ", id);
		try {
			Optional<AssistanceAppliedForEntity> assistanceAppliedForEntity = assistanceAppliedForRepository
					.findById(id);
			AssistanceAppliedForDto appliedForDto;
			if (assistanceAppliedForEntity.isPresent()) {
				appliedForDto = mapper.map(assistanceAppliedForEntity.get(), AssistanceAppliedForDto.class);

				return appliedForDto;
			} else {
				return new AssistanceAppliedForDto();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all AssistanceAppliedForDto. {}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching AssistanceAppliedForDto." + msg + "",
					e);
		}
	}

	@Override
	public void deleteAssistanceById(Long id) {
		logger.info("deleteAssistanceById() started in ApplicationServiceImpl for AssistanceAppliedForDto {} ", id);
		try {
			AssistanceAppliedForEntity appliedForEntity = assistanceAppliedForRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("AssistanceAppliedForDto", id));
			assistanceAppliedForRepository.delete(appliedForEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting AssistanceAppliedForDto. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting AssistanceAppliedForDto of id ." + id + " " + msg + " ", e);
		}

	}

	@Override
	public void deleteAggregateExposure(Long id) {
		logger.info("deleteAggregateExposure() started in ApplicationServiceImpl for aggregateExposureDtos {} ", id);
		try {
			IfvAggregateExposure appliedForEntity = aggregateExposureRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("aggregateExposureDtos", id));
			aggregateExposureRepository.delete(appliedForEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting aggregateExposureDtos. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting aggregateExposureDtos of id ." + id + " " + msg + " ", e);
		}

	}

	@Override
	public List<IfvAggregateExposureDto> findAggregateExposureByIfvId(Long id) {

		logger.info("findAggregateExposureByIfvId() started in ProposedSchemaServiceImpl of aggregateExposureDtos");
		try {
			List<IfvAggregateExposure> list = aggregateExposureRepository.findByIfvId(id,
					Sort.by(Sort.Direction.ASC, "slNo"));
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, IfvAggregateExposureDto.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all aggregateExposureDtos .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all aggregateExposureDtos ." + msg + " ", e);
		}

	}

}
