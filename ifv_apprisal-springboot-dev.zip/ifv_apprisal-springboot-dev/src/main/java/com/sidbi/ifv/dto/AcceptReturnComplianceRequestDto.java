package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AcceptReturnComplianceRequestDto {

	private String appRefNo;

	private String complianceType;

	private String status;

	private String acceptOrReturnRemarks;
}
