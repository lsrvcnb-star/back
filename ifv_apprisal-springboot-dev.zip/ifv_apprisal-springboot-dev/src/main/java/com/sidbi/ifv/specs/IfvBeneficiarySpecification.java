package com.sidbi.ifv.specs;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.FetchBeneficiaryRequest;
import com.sidbi.ifv.dto.FetchDsfSubmittedBeneficiaryRequest;
import com.sidbi.ifv.entity.IfvBeneficiaryDetails;

import jakarta.persistence.criteria.Predicate;

public class IfvBeneficiarySpecification {

	private IfvBeneficiarySpecification() {
	}

	public static Specification<IfvBeneficiaryDetails> filter(FetchBeneficiaryRequest request) {

		return (root, query, cb) -> {

			List<Predicate> predicates = new ArrayList<>();

			if (StringUtils.hasText(request.getCifNumber())) {
				predicates.add(cb.equal(root.get("cifNumber"), request.getCifNumber()));
			}

			if (StringUtils.hasText(request.getBankName())) {
				predicates
						.add(cb.like(cb.lower(root.get("bankName")), "%" + request.getBankName().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getBnRefNo())) {
				predicates.add(cb.like(cb.lower(root.get("benRefNo")), "%" + request.getBnRefNo().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getFileName())) {
				predicates
						.add(cb.like(cb.lower(root.get("fileName")), "%" + request.getFileName().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getStatus())) {
				predicates.add(cb.equal(cb.upper(root.get("status")), request.getStatus().toUpperCase()));
			}

			if (request.getUploadDateTime() != null) {

				LocalDateTime from = request.getUploadDateTime().toLocalDate().atStartOfDay();

				LocalDateTime to = request.getUploadDateTime().toLocalDate().atTime(23, 59, 59);

				predicates.add(cb.between(root.get("uploadDateTime"), from, to));
			}

			if (StringUtils.hasText(request.getGlobalFilter())) {

				String filter = "%" + request.getGlobalFilter().toLowerCase() + "%";

				predicates.add(cb.or(cb.like(cb.lower(root.get("bankName")), filter),
						cb.like(cb.lower(root.get("cifNumber")), filter),
						cb.like(cb.lower(root.get("benRefNo")), filter),
						cb.like(cb.lower(root.get("fileName")), filter),
						cb.like(cb.lower(root.get("uploadBy")), filter),
						cb.like(cb.lower(root.get("status")), filter)));
			}

			return cb.and(predicates.toArray(new Predicate[0]));
		};
	}

	public static Specification<IfvBeneficiaryDetails> filter(FetchDsfSubmittedBeneficiaryRequest request) {

		return (root, query, cb) -> {

			List<Predicate> predicates = new ArrayList<>();

			if (StringUtils.hasText(request.getBankName())) {
				predicates
						.add(cb.like(cb.lower(root.get("bankName")), "%" + request.getBankName().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getBnRefNo())) {
				predicates.add(cb.like(cb.lower(root.get("benRefNo")), "%" + request.getBnRefNo().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getFileName())) {
				predicates
						.add(cb.like(cb.lower(root.get("fileName")), "%" + request.getFileName().toLowerCase() + "%"));
			}

			if (StringUtils.hasText(request.getIfvSubmitBy())) {
				predicates.add(
						cb.like(cb.lower(root.get("ifvSubmitBy")), "%" + request.getIfvSubmitBy().toLowerCase() + "%"));
			}

			if (request.getIfvSubmittedDateFrom() != null) {

				predicates.add(cb.greaterThanOrEqualTo(root.get("ifvSubmittedDate"),
						request.getIfvSubmittedDateFrom().atStartOfDay()));
			}

			if (request.getIfvSubmittedDateTo() != null) {

				predicates.add(cb.lessThanOrEqualTo(root.get("ifvSubmittedDate"),
						request.getIfvSubmittedDateTo().atTime(23, 59, 59)));
			}

			if (StringUtils.hasText(request.getGlobalFilter())) {

				String filter = "%" + request.getGlobalFilter().toLowerCase() + "%";

				predicates.add(cb.or(cb.like(cb.lower(root.get("bankName")), filter),
						cb.like(cb.lower(root.get("benRefNo")), filter),
						cb.like(cb.lower(root.get("fileName")), filter),
						cb.like(cb.lower(root.get("ifvSubmitBy")), filter),
						cb.like(cb.lower(root.get("status")), filter)));
			}

			return cb.and(predicates.toArray(new Predicate[0]));
		};
	}
}