package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AlcoDataDTO;
import com.sidbi.ifv.entity.S2IFVAlcoDataEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AlcoDataRepository;
import com.sidbi.ifv.services.AlcoDataService;

@Service
public class AlcoDataServiceImpl implements AlcoDataService {

	private static final Logger logger = LoggerFactory.getLogger(AlcoDataServiceImpl.class);

	@Autowired
	private AlcoDataRepository alcoDataRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<AlcoDataDTO> findAll() {
		logger.info("findAll() started in AlcoDataServiceImpl of S2IFVAlcoDataEntity");
		try {
			List<S2IFVAlcoDataEntity> list = alcoDataRepository.findAll();
			return !list.isEmpty()
					? list.stream().map(alcoDataEntity -> modelMapper.map(alcoDataEntity, AlcoDataDTO.class)).collect(
							Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAlcoDataEntities.{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all S2IFVAlcoDataEntities." + msg + " ",
					e);
		}
	}

	@Override
	public AlcoDataDTO findById(Long id) {
		logger.info("findById() started in AlcoDataServiceImpl for S2IFVAlcoDataEntity {} ", id);
		S2IFVAlcoDataEntity s2ifvAlcoDataEntity = alcoDataRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("s2IFVAlcoDataEntity", id));
		return modelMapper.map(s2ifvAlcoDataEntity, AlcoDataDTO.class);
	}

	@Override
	public AlcoDataDTO save(AlcoDataDTO alcoDataDTO) {
		logger.info("save() started in AlcoDataServiceImpl for S2IFVAlcoDataEntity {} ", alcoDataDTO);
		try {
			alcoDataDTO.setDateOfAction(new Date());
			S2IFVAlcoDataEntity s2ifvAlcoDataEntity = modelMapper.map(alcoDataDTO, S2IFVAlcoDataEntity.class);
			alcoDataRepository.save(s2ifvAlcoDataEntity);
			return modelMapper.map(s2ifvAlcoDataEntity, AlcoDataDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVAlcoDataEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVAlcoDataEntity." + msg + " ", e);
		}
	}

	@Override
	public AlcoDataDTO update(Long id, AlcoDataDTO alcoDataDTO) {
		logger.info("update() started in AlcoDataServiceImpl for S2IFVAlcoDataEntity {} {} ", id, alcoDataDTO);
		try {
			S2IFVAlcoDataEntity existingS2IFVAlcoDataEntity = alcoDataRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAlcoDataEntity", id));
			BeanUtils.copyProperties(alcoDataDTO, existingS2IFVAlcoDataEntity);
			alcoDataRepository.save(existingS2IFVAlcoDataEntity);
			return modelMapper.map(existingS2IFVAlcoDataEntity, AlcoDataDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVAlcoDataEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVAlcoDataEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(String name) {

		logger.info("delete() started in AlcoDataServiceImpl for S2IFVAlcoDataEntity {} ", name);
		try {

			List<S2IFVAlcoDataEntity> existingS2IFVAlcoDataEntity = alcoDataRepository.findByDtBankname(name);

			existingS2IFVAlcoDataEntity.forEach(e -> alcoDataRepository.delete(e));

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVAlcoDataEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVAlcoDataEntity of id ." + msg + " " + name, e);
		}
	}

	@Override
	public List<AlcoDataDTO> saveAll(List<AlcoDataDTO> alcoDataDTOs) {
		logger.info("saveAll() started in AlcoDataServiceImpl for List of S2IFVAlcoDataEntity");
		try {
			Date date = new Date();
			Map<String, Map<String, Long>> countMap = alcoDataDTOs.stream()
					.collect(Collectors.groupingBy(AlcoDataDTO::getDtBankname,
							Collectors.groupingBy(AlcoDataDTO::getFundCode, Collectors.counting())));
			boolean duplicate = countMap.values().stream().flatMap(mp -> mp.values().stream())
					.anyMatch(count -> count > 1);
			if (duplicate) {
				throw new DatabaseOperationException("Duplicate Bank name with schemes");
			}

			alcoDataDTOs.forEach(alcoDataDTO -> alcoDataDTO.setDateOfAction(date));

			List<S2IFVAlcoDataEntity> alcoDataEntitiesToSave = alcoDataDTOs.stream()
					.map(alcoDataDTO -> modelMapper.map(alcoDataDTO, S2IFVAlcoDataEntity.class))
					.collect(Collectors.toList());
			List<S2IFVAlcoDataEntity> savedAlcoDataEntities = alcoDataRepository.saveAll(alcoDataEntitiesToSave);

			return savedAlcoDataEntities.stream()
					.map(alcoDataEntity -> modelMapper.map(alcoDataEntity, AlcoDataDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVAlcoDataEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all S2IFVAlcoDataEntities." + msg + " ",
					e);
		}
	}

	@Override
	public List<AlcoDataDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in AlcoDataServiceImpl ");
		try {
			List<S2IFVAlcoDataEntity> listAlcoDataEntities = alcoDataRepository.findByIfvId(ifvId);
			return (listAlcoDataEntities != null && !listAlcoDataEntities.isEmpty()) ? listAlcoDataEntities.stream()
					.map(alcoDataEntity -> modelMapper.map(alcoDataEntity, AlcoDataDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAlcoDataEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAlcoDataEntities  based on IfvId." + msg + " " + ifvId, e);

		}
	}

	@Override
	public List<AlcoDataDTO> findAllByAlCode(Long alCode) {
		logger.info("findAllByAlCode() started in AlcoDataServiceImpl ");
		try {
			List<S2IFVAlcoDataEntity> listAlcoDataEntities = alcoDataRepository.findByAlCode(alCode);
			return (listAlcoDataEntities != null && !listAlcoDataEntities.isEmpty()) ? listAlcoDataEntities.stream()
					.map(alcoDataEntity -> modelMapper.map(alcoDataEntity, AlcoDataDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAlcoDataEntities based on alCode. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAlcoDataEntities  based on alCode." + msg + " " + alCode, e);

		}
	}

	@Override
	public List<AlcoDataDTO> findAllByAlCodeIn(List<Long> alCodes) {
		logger.info("findAllByAlCodeIn() started in AlcoDataServiceImpl {} ", alCodes);
		try {
			List<S2IFVAlcoDataEntity> list = alcoDataRepository.findAllByAlCodeIn(alCodes);
			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparing(S2IFVAlcoDataEntity::getDateOfAction).reversed())
							.map(alcoDataEntity -> modelMapper.map(alcoDataEntity, AlcoDataDTO.class)).collect(
									Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAlcoDataEntities based on alCodes. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAlcoDataEntities  based on alCodes." + msg + " " + alCodes,
					e);

		}
	}

	@Override
	public List<AlcoDataDTO> findAllByDtAppl(String appId) {
		logger.info("findAllByDtAppl() started in AlcoDataServiceImpl {} ", appId);
		try {
			List<S2IFVAlcoDataEntity> list = alcoDataRepository.findAllByDtAppl(appId);
			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparing(S2IFVAlcoDataEntity::getDateOfAction).reversed())
							.map(alcoDataEntity -> modelMapper.map(alcoDataEntity, AlcoDataDTO.class)).collect(
									Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAlcoDataEntities based on appId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAlcoDataEntities  based on appId." + msg + " " + appId, e);

		}
	}
}