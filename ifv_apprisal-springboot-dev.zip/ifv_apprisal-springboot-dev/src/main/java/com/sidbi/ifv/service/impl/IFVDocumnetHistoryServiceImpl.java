package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.IFVDocumnetHistoryDTO;
import com.sidbi.ifv.entity.IFVDocumnetHistoryEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.IFVDocumnetHistoryRepo;
import com.sidbi.ifv.services.IFVDocumnetHistoryService;

@Service
public class IFVDocumnetHistoryServiceImpl implements IFVDocumnetHistoryService {

	private static final Logger logger = LoggerFactory.getLogger(IFVDocumnetHistoryServiceImpl.class);

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private IFVDocumnetHistoryRepo iFVDocumnetHistoryRepo;

	String msg = "";

	@Override
	public List<IFVDocumnetHistoryDTO> findAll() {
		logger.info("findAll() started in IFVDocumnetHistoryServiceImpl for IFVDocumnetHistoryDTO");

		try {
			List<IFVDocumnetHistoryEntity> list = iFVDocumnetHistoryRepo.findAll();
			return list.stream().map(m -> modelMapper.map(m, IFVDocumnetHistoryDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IFVDocumnetHistoryEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all IFVDocumnetHistoryEntities." + msg + " ", e);
		}
	}

	@Override
	public IFVDocumnetHistoryDTO findById(Long id) {
		logger.info("findById() started in IFVDocumnetHistoryServiceImpl for IFVDocumnetHistoryDTO {} ", id);
		try {
			Optional<IFVDocumnetHistoryEntity> iFVDocumnetHistoryEntity = iFVDocumnetHistoryRepo.findById(id);
			if (iFVDocumnetHistoryEntity.isPresent()) {
				return modelMapper.map(iFVDocumnetHistoryEntity.get(), IFVDocumnetHistoryDTO.class);
			} else {
				logger.error("Error Occurred while fetching  IFVDocumnetHistoryEntity data.");
				throw new EntityNotFoundException("IFVDocumnetHistoryEntity", id);
			}
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IFVDocumnetHistoryEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while fetching IFVDocumnetHistoryEntity ." + msg + " ",
					e);
		}
	}

	@Override
	public IFVDocumnetHistoryDTO save(IFVDocumnetHistoryDTO iFVDocumnetHistoryDTO) {
		logger.info("createDocumnetHistory() started in IFVDocumnetHistoryServiceImpl for IFVDocumnetHistoryDTO {} ",
				iFVDocumnetHistoryDTO);
		try {
			IFVDocumnetHistoryEntity iFVDocumnetHistoryEntity = modelMapper.map(iFVDocumnetHistoryDTO,
					IFVDocumnetHistoryEntity.class);
			iFVDocumnetHistoryRepo.save(iFVDocumnetHistoryEntity);
			return modelMapper.map(iFVDocumnetHistoryEntity, IFVDocumnetHistoryDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IFVDocumnetHistoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all IFVDocumnetHistoryEntity." + msg + " ", e);
		}
	}

	@Override
	public IFVDocumnetHistoryDTO update(Long id, IFVDocumnetHistoryDTO iFVDocumnetHistoryDTO) {
		logger.info("updateDocumnetHistory() started in IFVDocumnetHistoryServiceImpl for IFVDocumnetHistoryDTO {} {} ",
				id, iFVDocumnetHistoryDTO);
		try {
			IFVDocumnetHistoryEntity iFVDocumnetHistoryEntity = iFVDocumnetHistoryRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("IFVDocumnetHistoryEntity", id));
			BeanUtils.copyProperties(iFVDocumnetHistoryDTO, iFVDocumnetHistoryEntity);
			iFVDocumnetHistoryRepo.save(iFVDocumnetHistoryEntity);
			return modelMapper.map(iFVDocumnetHistoryEntity, IFVDocumnetHistoryDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating IFVDocumnetHistoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating IFVDocumnetHistoryEntity data of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("deleteDocumentHistory() started in IFVDocumnetHistoryServiceImpl for IFVDocumnetHistoryDTO {} ",
				id);
		try {
			IFVDocumnetHistoryEntity iFVDocumnetHistoryEntity = iFVDocumnetHistoryRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("iFVDocumnetHistoryEntity", id));
			iFVDocumnetHistoryRepo.delete(iFVDocumnetHistoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting iFVDocumnetHistoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting iFVDocumnetHistoryEntity of id ." + id + " " + msg + " ", e);
		}
	}
}