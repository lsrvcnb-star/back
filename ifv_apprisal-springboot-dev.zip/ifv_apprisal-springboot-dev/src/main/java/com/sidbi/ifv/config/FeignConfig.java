package com.sidbi.ifv.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.RequestInterceptor;

@Configuration
public class FeignConfig {

	@Bean
	RequestInterceptor serviceTokenInterceptor(ServiceAuthConfig serviceAuthConfig) {
		return template -> {
			String token = serviceAuthConfig.generateServiceToken();
			template.header("X-Service-Token", token);
		};
	}
}
