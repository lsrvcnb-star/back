package com.sidbi.ifv.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class DatabaseOperationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DatabaseOperationException(String message) {
		super(message);
	}

	public DatabaseOperationException(String message, Throwable cause) {
		super(message, cause);
	}
}
