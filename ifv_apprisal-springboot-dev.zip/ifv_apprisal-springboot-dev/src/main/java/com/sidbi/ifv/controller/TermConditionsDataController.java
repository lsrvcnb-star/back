package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.TermConditionsDataDTO;
import com.sidbi.ifv.services.TermConditionDataService;

@RestController
@RequestMapping("/ifv/ifvtermcondata")
@CrossOrigin(origins = "*")
public class TermConditionsDataController {

	@Autowired
	private TermConditionDataService conditionDataService;

	private static final Logger logger = LoggerFactory.getLogger(TermConditionsDataController.class);

	@GetMapping("/getByIfvId/{ifvId}")
	public ResponseEntity<TermConditionsDataDTO> getTermConditionData(@PathVariable Long ifvId) {
		logger.info("getTermConditionData() started TermConditionsDataController {} ",ifvId);
		TermConditionsDataDTO termConditionDataDTO = conditionDataService.getTermConditionDataById(ifvId);
		return ResponseEntity.ok(termConditionDataDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<TermConditionsDataDTO>> getAllTermConditionData() {
		logger.info("getAllTermConditionData() started TermConditionsDataController ");
		List<TermConditionsDataDTO> list = conditionDataService.getAllTermConditionData();
		return ResponseEntity.ok(list);
	}
	
	@PostMapping("/save")
	public ResponseEntity<TermConditionsDataDTO> save(@RequestBody TermConditionsDataDTO termConditionsDataDTO) {
		logger.info("save() started TermConditionsDataController {} ",termConditionsDataDTO);
		TermConditionsDataDTO savedTermConditionsDataDTO = conditionDataService.save(termConditionsDataDTO);
        return ResponseEntity.ok(savedTermConditionsDataDTO);
    }
	
}