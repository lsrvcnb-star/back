package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.services.CmtMemberMasterService;
import com.sidbi.ifv.services.CrudService;

@RestController
@CrossOrigin
@RequestMapping("/api/cmt-member")
public class CmtMemberMasterController extends CrudController<CmtMemberMasterDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(CmtMemberMasterController.class);

	@Autowired
	private CmtMemberMasterService service;

	@Override
	public CrudService<CmtMemberMasterDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllByCmtCode/{cmtCode}")
	public ResponseEntity<List<CmtMemberMasterDTO>> getAllByCmtCode(@PathVariable Integer cmtCode) {
		logger.info("Started getAllByCmtCode() in CmtMemberMasterController {}", cmtCode);
		return ResponseEntity.ok(service.findAllByCmtCode(cmtCode));
	}
}
