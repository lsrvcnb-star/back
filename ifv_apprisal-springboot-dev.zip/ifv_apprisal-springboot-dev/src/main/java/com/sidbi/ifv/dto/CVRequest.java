package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class CVRequest {
	private String username;
	private String documentName;
	private String region;
	private String language;
	private String folderId;
	private String sessionId;
}
