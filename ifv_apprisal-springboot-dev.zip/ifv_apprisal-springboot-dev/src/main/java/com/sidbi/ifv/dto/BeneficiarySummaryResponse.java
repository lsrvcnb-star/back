package com.sidbi.ifv.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BeneficiarySummaryResponse {
	private Long id;
	private String cifNumber;
	private String bankName;
}
