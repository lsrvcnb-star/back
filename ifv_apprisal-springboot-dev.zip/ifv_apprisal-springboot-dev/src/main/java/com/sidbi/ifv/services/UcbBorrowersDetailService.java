package com.sidbi.ifv.services;

import com.sidbi.ifv.dto.UcbBorrowersDetailDto;

public interface UcbBorrowersDetailService extends CrudService<UcbBorrowersDetailDto, Long> {

	UcbBorrowersDetailDto findByIfvId(Long ifvId);

}
