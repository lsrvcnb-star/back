package com.sidbi.ifv.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.sidbi.ifv.entity.IfvBeneficiaryDetails;

public interface BenificiaryRepository
		extends JpaRepository<IfvBeneficiaryDetails, Long>, JpaSpecificationExecutor<IfvBeneficiaryDetails> {

	IfvBeneficiaryDetails findByJobId(String jobId);

	@Modifying
	@Transactional
	@Query("""
			DELETE FROM IfvBeneficiaryDetails b
			 WHERE b.jobId = :jobId
			""")
	int deleteDocumentByJobId(@Param("jobId") String jobId);

	@Modifying
	@Transactional
	@Query("""
			    UPDATE IfvBeneficiaryDetails b
			       SET b.status = 'SUBMITTED',
			           b.ifvSubmittedDate = CURRENT_TIMESTAMP
			     WHERE b.jobId = :jobId
			       AND b.status = 'VALIDATED'
			""")
	int updateStatusToSubmitted(@Param("jobId") String jobId);

	@Modifying
	@Transactional
	@Query("""
			    UPDATE IfvBeneficiaryDetails b
			       SET b.status = 'VALIDATED'
			     WHERE b.jobId = :jobId
			       AND b.status = 'PENDING'
			""")
	int updateStatusToValidated(@Param("jobId") String jobId);

	@Modifying
	@Transactional
	@Query("""
			 UPDATE IfvBeneficiaryDetails b
			    SET b.status = :status,
			        b.returnRemarks = :returnRemarks,
			        b.returnBy = :returnBy
			  WHERE b.benRefNo = :benRefNo
			""")
	int updateIfvBeneficiaryDetailStatus(@Param("benRefNo") String benRefNo, @Param("status") String status,
			@Param("returnRemarks") String returnRemarks, @Param("returnBy") String returnBy);

	Optional<IfvBeneficiaryDetails> findByBenRefNo(String benRefNo);

	@Modifying
	@Transactional
	@Query("""
			    UPDATE IfvBeneficiaryDetails b
			       SET b.status = 'VALIDATED'
			     WHERE b.benRefNo = :benRefNo
			       AND b.status = 'PENDING'
			""")
	int updateDocumentStatusToValidatedByRefId(@Param("benRefNo") String benRefNo);
}
