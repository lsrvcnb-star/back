package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.LoITermsConditionsDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.LoITermsConditionsService;

@RestController
@CrossOrigin
@RequestMapping("/api/loi-termconditions")
public class LoITermsConditionsController extends CrudController<LoITermsConditionsDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(LoITermsConditionsController.class);

	@Autowired
	private LoITermsConditionsService service;

	@Override
	public CrudService<LoITermsConditionsDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<LoITermsConditionsDTO>> getLoITermsConditionsDTOOnIfvId(@PathVariable Long ifvId) {
		logger.info("getLoITermsConditionsDTOOnIfvId() started in LoITermsConditionsController ");
		List<LoITermsConditionsDTO> dtos = service.findAllByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}

	@GetMapping("/getAllOnIfvIdAndPrId/{ifvId}/{prId}")
	public ResponseEntity<LoITermsConditionsDTO> getLoITermsConditionsDTOOnIfvIdAndPrId(@PathVariable Long ifvId,
			@PathVariable Long prId) {
		logger.info("getLoITermsConditionsDTOOnIfvIdAndPrId() started in LoITermsConditionsController ");
		return ResponseEntity.ok(service.findByIfvIdAndPrId(ifvId, prId));
	}

	@GetMapping("/findByloiId/{loiId}")
	public ResponseEntity<List<LoITermsConditionsDTO>> findByloiId(@PathVariable Long loiId) {
		logger.info("findByloiId() started in LoITermsConditionsController ");
		List<LoITermsConditionsDTO> dto = service.findByloiId(loiId);
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/findByloiIdAndPrId/{loiId}/{prId}")
	public ResponseEntity<LoITermsConditionsDTO> findByloiId(@PathVariable Long loiId, @PathVariable Long prId) {
		logger.info("findByloiIdAndPrId() started in LoITermsConditionsController ");
		LoITermsConditionsDTO dto = service.findByloiIdAndPrId(loiId, prId);
		return ResponseEntity.ok(dto);
	}

}
