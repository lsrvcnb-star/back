package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class CommonRequestDto {

	private String filePath;

	private String action;
}
