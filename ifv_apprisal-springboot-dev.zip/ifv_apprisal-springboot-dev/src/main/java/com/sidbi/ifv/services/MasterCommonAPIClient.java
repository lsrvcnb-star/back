package com.sidbi.ifv.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.AggregateExposureRequestDto;
import com.sidbi.ifv.dto.AggregateExposureResponseDto;
import com.sidbi.ifv.dto.BeneficiaryDocValResponse;
import com.sidbi.ifv.dto.CustomerDto;
import com.sidbi.ifv.dto.HrmsEmpNameDesignationDTO;
import com.sidbi.ifv.dto.IfvIntBeneficiaryDetailRequest;
import com.sidbi.ifv.dto.IfvRefMasterDto;
import com.sidbi.ifv.dto.IfvSanctionDetailsDTO;
import com.sidbi.ifv.dto.StatusResponseDto;
import com.sidbi.ifv.dto.TriggerResponseDto;
import com.sidbi.ifv.dto.UploadJobResponse;
import com.sidbi.ifv.dto.ValidationError;
import com.sidbi.ifv.dto.ValidationJobStatusResponse;
import com.sidbi.ifv.dto.VerticalDto;

@FeignClient(url = "${masterdbms.url}", value = "CommonService")
public interface MasterCommonAPIClient {

	@GetMapping("/api/getdistcdaname")
	List<Object> getBcmLocationCodes();

	@GetMapping("/api/getcustexpo/{cifNumber}/{date}")
	List<Object> getCustExpo(@PathVariable String cifNumber, @PathVariable String date);

	@GetMapping("/api/getcustos/{cifNumber}/{date}")
	List<Object> getCustOs(@PathVariable String cifNumber, @PathVariable String date);

	@GetMapping("/api/getPastDisbursements/{cifNumber}/{year}")
	List<Object> getPastDisbursements(@PathVariable String cifNumber, @PathVariable Integer year);

	@GetMapping("/api/getOSDetails/{cifNumber}")
	List<Object> outStandingDetails(@PathVariable String cifNumber);

	@GetMapping("/api/getFundDetails/{fundAvailable}")
	List<Object> bcmFundCodeDetails(@PathVariable String fundAvailable);

	@GetMapping("/api/getRePaymentDetails/{cifNumber}/{year}")
	List<Object> futureRepayOfExistingOutStandingDTO(@PathVariable String cifNumber, @PathVariable Integer year);

	@GetMapping("/api/getExpouserDetails/{cifNumber}/{year}")
	BigDecimal exposureLimitForBarwBank(@PathVariable String cifNumber, @PathVariable Integer year);

	@GetMapping("/api/gethrmsempdetails/{list}")
	List<HrmsEmpNameDesignationDTO> getHrmsEmpDetails(@PathVariable List<String> list);

	@GetMapping("/api/getfundcodeanddesc")
	List<Object> getFundCodeAndDesc();

	@PostMapping("/api/saveIfvSncDetails")
	Boolean postDataToDFS(@RequestBody List<IfvSanctionDetailsDTO> sanctionDtDTOs);

	@GetMapping("/api/getAllSanctionDetails")
	List<Object> getAllSanctionDetails();

	@GetMapping("/api/getAllEmpNames")
	List<String> getAllEmpNames();

	@GetMapping("/api/getEmpDetails/{empName}")
	HrmsEmpNameDesignationDTO getEmpDetailsOnEmpName(@PathVariable String empName);

	@GetMapping("/api/getEmpCodeAndDesc")
	Map<String, String> getEmpCodeAndDesc();

	@GetMapping("/api/getBankType/{custCd}")
	String getBankType(@PathVariable String custCd);

	@GetMapping("/api/findBankDetailsByCifNumber/{custCd}")
	Object findBankDetailsByCifNumber(@PathVariable String custCd);

	@GetMapping("/api/getBenchmarkDetails")
	List<String> getBenchmarkDetails();

	@GetMapping("/api/getAddressByCifNumber/{custCd}")
	String getAddressByCifNumber(@PathVariable String custCd);

	@GetMapping("/api/getBankShortName/{custCd}")
	String getBankShortName(@PathVariable String custCd);

	@GetMapping("/api/getDistrictsByState/{stateCode}")
	List<Object> getDistrictsByState(@PathVariable String stateCode);

	@GetMapping("/api/getSanctionDetailsOnPage")
	Page<IfvSanctionDetailsDTO> getSanctionDetailsOnPage(@RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter,
			@RequestParam(required = false) String status);

	@GetMapping("/api/getSanctionedProposalsCount")
	Long getSanctionedProposalsCount();

	@GetMapping("/api/getBenchMarkRateByName/{benchMarkName}")
	String getBenchMarkRateByName(@PathVariable String benchMarkName);

	@GetMapping("/api/getAllTrancheOnFundCode/{fundCode}")
	List<BigDecimal> getAllTrancheOnFundCode(@PathVariable String fundCode);

	@GetMapping("/beneficiary/fetchLoanAccNoOnCif")
	List<String> fetchLoanAccNoOnCif(@RequestParam String cifNumber);

	@PostMapping("/beneficiary/savePreDisbData")
	Boolean savePreDisbData(@RequestBody IfvRefMasterDto ifvRefMasterDto);

	@PostMapping("/beneficiary/saveIfvBeneficiaryDetails")
	String saveIfvBeneficiaryDetails(@RequestParam String filePath);

	@GetMapping("/beneficiary/processingStatus/{jobId}")
	Map<String, Object> processingStatus(@PathVariable String jobId);

	@PostMapping("/beneficiary/saveIfvBeneficiaryDetailsAsync")
	String saveIfvBeneficiaryDetailsAsync(@RequestBody IfvIntBeneficiaryDetailRequest beneficiaryDetailRequest);

	@GetMapping("/beneficiary/fetchDisbDateOnAccNo/{accNo}")
	List<String> fetchDisbDateOnAccNo(@PathVariable String accNo);

	@GetMapping("/beneficiary/getIfvVerticals")
	List<VerticalDto> getIfvVerticals();

	@GetMapping("/beneficiary/fetchCustomersOnVertical")
	List<CustomerDto> fetchCustomersOnVertical(@RequestParam String vertical);

	@PostMapping(value = "/beneficiary/validateBeneficiaryData", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	BeneficiaryDocValResponse validateBeneficiaryDoc(@RequestPart("file") MultipartFile file);

	@GetMapping("/beneficiary/countByAcctNoAndDisbDtAndCifNo")
	Long countByAcctNoAndDisbDtAndCifNo(@RequestParam("accNo") String accNo, @RequestParam("disbDate") String disbDate,
			@RequestParam("cifNumber") String cifNumber);

	@PostMapping("/api/getAggregateExposureStatus")
	StatusResponseDto checkStatus(@RequestBody AggregateExposureRequestDto dto);

	@PostMapping("/api/triggerAggregateExposure")
	TriggerResponseDto triggerProcedure(@RequestBody AggregateExposureRequestDto dto);

	@PostMapping("/api/getAggregateExposureData")
	AggregateExposureResponseDto getAggregateExposureData(@RequestBody AggregateExposureRequestDto dto);

	@GetMapping("/api/getGroupNameByCif/{cifNumber}")
	String getGroupNameByCif(@PathVariable String cifNumber);

	@PostMapping("/api/getAggregateExposureOnGroup")
	BigDecimal getAggregateExposureOnGroup(@RequestBody AggregateExposureRequestDto dto);

	@PostMapping(value = "/beneficiary/createValidationJob", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	UploadJobResponse createValidationJob(@RequestPart("file") MultipartFile file, @RequestParam("jobId") String jobId);

	@PostMapping("/beneficiary/createValidationJobFromPath")
	UploadJobResponse createValidationJobFromPath(@RequestParam String filePath, @RequestParam String jobId);

	@GetMapping("/beneficiary/getJobStatus/{jobId}")
	ValidationJobStatusResponse getJobStatus(@PathVariable("jobId") String jobId);

	@GetMapping("/beneficiary/getValidationErrors/{jobId}")
	List<ValidationError> getValidationErrors(@PathVariable("jobId") String jobId);

}