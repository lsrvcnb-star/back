package com.sidbi.ifv.reports;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.DocumentException;
import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.dto.HrmsEmpNameDesignationDTO;
import com.sidbi.ifv.dto.IfvProposalLoIDto;
import com.sidbi.ifv.dto.LoIDetailDTO;
import com.sidbi.ifv.dto.LoITermsConditionsDTO;
import com.sidbi.ifv.dto.MasterRepositoryDTO;
import com.sidbi.ifv.dto.MinutesColendingLimitDTO;
import com.sidbi.ifv.dto.MinutesInterestResetDTO;
import com.sidbi.ifv.dto.MinutesOtherItemsDTO;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.dto.ReportResponseJsonDTO;
import com.sidbi.ifv.dto.SanctionMinutesDTO;
import com.sidbi.ifv.dto.SanctionTermsConditionsDTO;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.entity.S2IFVAlcoDataEntity;
import com.sidbi.ifv.entity.S2IFVAlcoProposalEntity;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVBenchmarkRepositoryEntity;
import com.sidbi.ifv.entity.SanctionMinutesDtlEntity;
import com.sidbi.ifv.entity.TblIfvModuleFwdEntity;
import com.sidbi.ifv.enums.CommitteeEnum;
import com.sidbi.ifv.enums.FileModule;
import com.sidbi.ifv.enums.FileSubModuleEnum;
import com.sidbi.ifv.enums.UserDesignationEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.exception.FileUploadException;
import com.sidbi.ifv.exception.ReportGenerationException;
import com.sidbi.ifv.repo.AlcoDataRepository;
import com.sidbi.ifv.repo.AlcoProposalRepository;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.BenchmarkRepository;
import com.sidbi.ifv.repo.IfvApiUsersRepo;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.repo.SanctionMinutesDtlRepository;
import com.sidbi.ifv.repo.TblIfvModuleFwdRepository;
import com.sidbi.ifv.service.impl.MinutesAdditionalDetailService;
import com.sidbi.ifv.services.AppraisalMinutesDataService;
import com.sidbi.ifv.services.CmtMemberMasterService;
import com.sidbi.ifv.services.FileRepositoryService;
import com.sidbi.ifv.services.IfvProposalLoIService;
import com.sidbi.ifv.services.LoIDetailService;
import com.sidbi.ifv.services.LoITermsConditionsService;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.services.MasterRepositoryService;
import com.sidbi.ifv.services.ProposedSchemaService;
import com.sidbi.ifv.services.ReportService;
import com.sidbi.ifv.services.SanctionMinutesService;
import com.sidbi.ifv.services.SanctionTermsConditionsService;
import com.sidbi.ifv.util.FileUploadUtility;
import com.sidbi.ifv.util.FlashMinutesPdf;
import com.sidbi.ifv.util.SubCommitteeALCOPdf;

@RestController
@RequestMapping("/api/pdfreport")
public class ReportController {

	private static final Logger logger = LoggerFactory.getLogger(ReportController.class);

	@Autowired
	private ApplicationRepository applicationRepo;

	@Autowired
	private MasterRepositoryService masterRepositoryService;

	@Autowired
	private AlcoDataRepository alcoDataRepository;

	@Autowired
	private AlcoProposalRepository alcoProposalRepository;

	@Autowired
	private BenchmarkRepository benchmarkRepository;

	@Autowired
	private MasterDbService masterDbService;

	@Autowired
	private ProposedSchemaService proposedSchemaService;

	@Autowired
	private TblIfvModuleFwdRepository tblIfvModuleFwdRepository;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	@Autowired
	private FileRepositoryService fileRepositoryService;

	@Autowired
	private ReportService reportService;

	@Autowired
	private IfvApiUsersRepo ifvApiUsersRepo;

	@Autowired
	private SanctionMinutesService sanctionMinutesService;

	@Autowired
	private SanctionMinutesDtlRepository sanctionMinutesDtlRepository;

	@Autowired
	private AppraisalMinutesDataService appraisalMinutesDataService;

	@Autowired
	private CmtMemberMasterService cmtMemberMasterService;

	@Autowired
	private LoIDetailService loiDetailService;

	@Autowired
	private LoITermsConditionsService loITermsConditionsService;

	@Autowired
	private IfvProposalLoIService ifvProposalLoIService;

	@Autowired
	private SanctionTermsConditionsService sanctionTermsConditionsService;

	@Autowired
	private FileUploadUtility fileUploadUtility;

	@Autowired
	private MinutesAdditionalDetailService additionalDetailService;

	private String msg;

	private static final String LOI_DATED = " LoI_dated ";
	private static final String CONTENT_DISPOSITION = "Content-Disposition";
	private static final String DATE_FORMATE = "dd-MM-yyyy";

	@GetMapping(value = "/apraisalMerged/{ifvId}")
	public ResponseEntity<ReportResponseJsonDTO> appraisalMergedPdf(@PathVariable(value = "ifvId") Long ifvId) {

		logger.info("Started appraisalMergedPdf for ifvId: {}", ifvId);

		try {
			byte[] mergedPdf = reportService.generateAppraisalReportData(ifvId);

			S2IFVApplicationEntity entity = applicationRepo.findByIfvId(ifvId).get(0);

			String fileName = generateFileName(entity);

			String uploadedFilePath = fileUploadUtility.uploadFile(mergedPdf, fileName, FileModule.APPRAISAL,
					FileSubModuleEnum.PROPOSAL, entity.getAppNumber());
			logger.info("File uploaded successfully to: {} for ifvId: {}", uploadedFilePath, ifvId);

			fileRepositoryService.savePDF(mergedPdf, ifvId, fileName, "appraisal", uploadedFilePath, entity);

			ReportResponseJsonDTO response = new ReportResponseJsonDTO(fileName, mergedPdf);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			logger.info("Successfully completed appraisalMergedPdf for ifvId: {}", ifvId);
			return ResponseEntity.ok().headers(headers).body(response);
		} catch (IOException e) {
			msg = e.getMessage();
			logger.error("Failed to upload file for ifvId: {} Msg: {}", ifvId, msg);
			throw new FileUploadException("Failed to upload appraisal file for ifvId: " + ifvId, e);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Unexpected error generating appraisal report for ifvId: {} Msg: {}", ifvId, msg);
			throw new ReportGenerationException("Failed to generate appraisal report for ifvId: " + ifvId, e);
		}
	}

	private String generateFileName(S2IFVApplicationEntity entity) {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DATE_FORMATE);
		String dateFormatted = LocalDate.now().format(dateFormatter);
		return entity.getIfvName() + "_" + dateFormatted + ".pdf";
	}

	@GetMapping(value = "/subCommALCO/{alCode}")
	public ResponseEntity<ReportResponseJsonDTO> subCommitteALCO(@PathVariable("alCode") Long alCode)
			throws DocumentException, IOException {
		byte[] pdfData;
		logger.info(" started subCommitteALCO {} ", alCode);

		S2IFVAlcoProposalEntity ifvALCOProposal = null;
		List<S2IFVAlcoDataEntity> ifvALCOData = null;
		List<MasterRepositoryDTO> masterRepositoryData = null;
		List<S2IFVBenchmarkRepositoryEntity> benchmarkBanksRepoList = null;
		List<S2IFVBenchmarkRepositoryEntity> benchmarkSFBsRepoList = null;

		ifvALCOProposal = alcoProposalRepository.findByAlCode(alCode);
		ifvALCOData = alcoDataRepository.findByAlCode(alCode);
		masterRepositoryData = masterRepositoryService.findAll();
		benchmarkBanksRepoList = benchmarkRepository.findByAlCodeAndBmBanktype(alCode, "Banks");
		benchmarkSFBsRepoList = benchmarkRepository.findByAlCodeAndBmBanktype(alCode, "SFBs");
		TblIfvModuleFwdEntity ifvUsersDetails = tblIfvModuleFwdRepository.findByAlCode(alCode);

		if (ifvUsersDetails == null) {
			ifvUsersDetails = new TblIfvModuleFwdEntity();
			ifvUsersDetails.setCreatedBy("");
		}
		long officerCode = ifvUsersDetails.getAppCurrentOfficerCode() != null
				? ifvUsersDetails.getAppCurrentOfficerCode()
				: 0;
		List<String> offCodeList = new ArrayList<>();
		setOfrCodes(officerCode, offCodeList);
		List<HrmsEmpNameDesignationDTO> hrmsEmpName = masterDbService.getEmployeeNames(offCodeList);

		try {
			SubCommitteeALCOPdf exporter = new SubCommitteeALCOPdf(ifvALCOData, ifvALCOProposal, masterRepositoryData,
					benchmarkBanksRepoList, benchmarkSFBsRepoList, hrmsEmpName);
			pdfData = exporter.export();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error Occurred while generating pdf..");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ReportResponseJsonDTO());
		}
		ReportResponseJsonDTO flashMinutesDTO = new ReportResponseJsonDTO("subCommALCO.pdf", pdfData);
		fileRepositoryService.savePDF(pdfData, alCode, "AlcoReport", "alco", null, null);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(CONTENT_DISPOSITION, "attachment; filename=subCommALCO.json");

		return ResponseEntity.ok().headers(headers).body(flashMinutesDTO);

	}

	private void setOfrCodes(long officerCode, List<String> offCodeList) {
		StringBuilder sb = new StringBuilder();
		if (officerCode != 0) {
			String offCode = String.valueOf(officerCode);
			if (offCode.length() < 6) {
				sb.append("0");
				sb.append(offCode);
			}
		}
		String officerCodeString = sb.toString();
		offCodeList.add(officerCodeString);
	}

	@GetMapping(value = "/flashMinutes/{sanctDetailCode}")
	public ResponseEntity<ReportResponseJsonDTO> flashMinutesJson(
			@PathVariable("sanctDetailCode") Long sanctDetailCode) {

		logger.info("Started flash minutes generation for sanctDetailCode: {}", sanctDetailCode);

		SanctionMinutesDTO sanctionMinutesDetails = sanctionMinutesService.findById(sanctDetailCode);
		if (sanctionMinutesDetails == null) {
			throw new EntityNotFoundException("SanctionMinutesDTO", sanctDetailCode);
		}

		List<SanctionMinutesDtlEntity> sanctionMinutesDtl = sanctionMinutesDtlRepository
				.findBySanctStatusCode(sanctDetailCode);
		if (sanctionMinutesDtl.isEmpty()) {
			throw new EntityNotFoundException("SanctionMinutesDtlEntity", sanctDetailCode);
		}

		Integer committeeCode = sanctionMinutesDetails.getCommiteeCode();
		String committeeName = CommitteeEnum.getCommitteeNameByCode(committeeCode);
		String agendaId = sanctionMinutesDtl.get(0).getAgendaId();

		List<AppraisalMinutesDataDTO> appraisalMinutesDataDetails = appraisalMinutesDataService
				.findByAgendaId(agendaId);
		List<CmtMemberMasterDTO> committeeMembers = cmtMemberMasterService.findAllByCmtCode(committeeCode);

		List<MinutesColendingLimitDTO> limits = additionalDetailService
				.getByMinuteSanctionId(sanctDetailCode.intValue());
		List<MinutesInterestResetDTO> intResets = additionalDetailService
				.getInterestResetsByMinuteSanctionId(sanctDetailCode.intValue());
		List<MinutesOtherItemsDTO> others = additionalDetailService.fetchOtherItems(sanctDetailCode.intValue());

		// Generate filename
		String dateFormatted = LocalDate.now().format(DateTimeFormatter.ofPattern(DATE_FORMATE));
		String fileName = String.format("Flash Minutes_%s_%dth_mtg_%s.pdf", committeeName,
				sanctionMinutesDetails.getMeetingNo(), dateFormatted);

		// Generate PDF
		byte[] pdfData;
		try {
			FlashMinutesPdf exporter = new FlashMinutesPdf(sanctionMinutesDetails, sanctionMinutesDtl,
					appraisalMinutesDataDetails, committeeName, committeeMembers, proposedSchemaRepository, limits,
					intResets, others);
			pdfData = exporter.generatePdfData();

			// Upload if meeting number is valid
			if (sanctionMinutesDetails.getMeetingNo() > 0) {
				fileRepositoryService.savePDF(pdfData, sanctDetailCode, fileName, "FLASH MINUTES", null, null);
			}

			return ResponseEntity.ok(new ReportResponseJsonDTO(fileName, pdfData));

		} catch (DocumentException e) {
			msg = e.getMessage();
			logger.error("Error generating PDF for sanctDetailCode: {}, Error: {}", sanctDetailCode, msg);
			throw new DatabaseOperationException("Error occurred while generating PDF: " + msg, e);
		}
	}

	@GetMapping(value = "/finalMinutes/{sanctDetailCode}")
	public ResponseEntity<ReportResponseJsonDTO> finalMinutesPdf(
			@PathVariable("sanctDetailCode") Long sanctDetailCode) {
		logger.info(" started finalMinutesPdf {} ", sanctDetailCode);
		ReportResponseJsonDTO flashMinutesDTO = reportService.finalMinutesReport(sanctDetailCode);
		fileRepositoryService.savePDF(flashMinutesDTO.getFileDataBytea(), sanctDetailCode,
				flashMinutesDTO.getFileName(), "minutes", null, null);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(CONTENT_DISPOSITION, "attachment; filename=FinalMinutes.json");
		return ResponseEntity.ok().headers(headers).body(flashMinutesDTO);
	}

	@GetMapping(value = "/downLoadFinalMinutes/{sanctDetailCode}")
	public ResponseEntity<byte[]> downloadFinalMinutes(@PathVariable long sanctDetailCode)
			throws UnsupportedEncodingException {
		logger.info(" started downloadFinalMinutes {} ", sanctDetailCode);
		ReportResponseJsonDTO flashMinutesDTO = reportService.finalMinutesReport(sanctDetailCode);
		String fileName = "FinalMinutes.pdf";
		ByteArrayResource resource = new ByteArrayResource(flashMinutesDTO.getFileDataBytea());
		String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8.toString());
		String contentDisposition = encodedFileName;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_PDF);
		headers.setContentDispositionFormData("attachment", contentDisposition);
		return ResponseEntity.ok().headers(headers).body(resource.getByteArray());
	}

	@GetMapping(value = "/generateLOIReport/{loiId}")
	public ResponseEntity<ReportResponseJsonDTO> generateLOIReport(@PathVariable("loiId") Long loiId)
			throws IOException, DocumentException {
		logger.info(" started generateLOIReport {} ", loiId);
		byte[] pdfData;

		LoIDetailDTO loIDetailDTO = loiDetailService.findById(loiId);
		List<LoITermsConditionsDTO> loITermsConditionsDTOs = loITermsConditionsService.findByloiId(loiId);
		List<MasterRepositoryDTO> masterRepositoryData = masterRepositoryService.findAll();

		SanctionMinutesDtlEntity sanctionMinutesDtlEntity = sanctionMinutesDtlRepository
				.findBySancDtlCode(loIDetailDTO.getSancDetailId());
		S2IFVApplicationEntity applicationEntity = applicationRepo.findByAppNumber(sanctionMinutesDtlEntity.getAppid())
				.get(0);
		List<ProposedSchemaDTO> proposedSchemaDetails = proposedSchemaService
				.findAllByIfvId(applicationEntity.getIfvId());
		String fileName = "";

		try {
			LoIReport exporter = new LoIReport(loIDetailDTO, loITermsConditionsDTOs, masterRepositoryData,
					proposedSchemaDetails);
			pdfData = exporter.generatePdfData();

			String[] arrOfStr = loIDetailDTO.getIfvNo().split("/");
			String schemeName = arrOfStr[2];
			String bankName = StringUtils.hasText(applicationEntity.getIfvShortName())
					? applicationEntity.getIfvShortName().replace(".", "")
					: applicationEntity.getIfvName().replace(".", "");

			String dateTimeFormatted = "";
			DateTimeFormatter dateformate = DateTimeFormatter.ofPattern(DATE_FORMATE);
			LocalDate ld = loIDetailDTO.getIfvDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			dateTimeFormatted = ld.format(dateformate);

			fileName = bankName.toUpperCase() + LOI_DATED + dateTimeFormatted + " " + schemeName;

			fileRepositoryService.savePDF(pdfData, loiId, fileName, "loi", null, null);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error Occurred while generating report");
			throw new DatabaseOperationException("Error occurred while generating Report. " + e.getMessage());
		}
		ReportResponseJsonDTO flashMinutesDTO = new ReportResponseJsonDTO(fileName, pdfData);
		return ResponseEntity.ok().body(flashMinutesDTO);
	}

	@GetMapping("/final-minutes-word/{sanctDetailCode}")
	public ResponseEntity<ByteArrayResource> generateFInalMinutesWord(
			@PathVariable("sanctDetailCode") Long sanctDetailCode) {
		ReportResponseJsonDTO document = reportService.generateFInalMinutesWord(sanctDetailCode);
		String fileName = document.getFileName();
		ByteArrayResource resource = new ByteArrayResource(document.getFileDataBytea());
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
		headers.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
	}

	@GetMapping(value = "/generateLOIReportForAppraisal/{loiId}")
	public ResponseEntity<ReportResponseJsonDTO> generateLOIReportForAppraisal(@PathVariable("loiId") Long loiId)
			throws IOException, DocumentException {
		logger.info(" started generateLOIReport {} ", loiId);
		byte[] pdfData;

		IfvProposalLoIDto ifvProposalLoIDto = ifvProposalLoIService.findById(loiId);
		List<SanctionTermsConditionsDTO> sanctionTermsConditionsDTOs = sanctionTermsConditionsService
				.findAllByIfvId(ifvProposalLoIDto.getIfvId());
		sanctionTermsConditionsDTOs = sanctionTermsConditionsDTOs.stream()
				.filter(e -> e.getFundName().equalsIgnoreCase(ifvProposalLoIDto.getFundName())
						&& (e.getSchemeName().contains("RMSE")
								|| e.getSchemeName().equalsIgnoreCase(ifvProposalLoIDto.getSchemeName())))
				.sorted(Comparator.comparing(SanctionTermsConditionsDTO::getId)).collect(Collectors.toList());

		List<MasterRepositoryDTO> masterRepositoryData = masterRepositoryService.findAll();

		List<ProposedSchemaDTO> proposedSchemaDetails = proposedSchemaService
				.findAllByIfvId(ifvProposalLoIDto.getIfvId());
		String fileName = "";

		IfvApiUsersEntity ifvApiUsersDetails = ifvApiUsersRepo.findByOfrCode(ifvProposalLoIDto.getLoiUser());

		String userName = StringUtils.hasText(ifvApiUsersDetails.getOfrShortName())
				? ifvApiUsersDetails.getOfrShortName()
				: "";
		String designation = UserDesignationEnum.getNameByCode(ifvApiUsersDetails.getOfrDesgCode());

		S2IFVApplicationEntity applicationEntity = applicationRepo.findByIfvId(ifvProposalLoIDto.getIfvId()).get(0);

		try {
			LoIReportFromAppraisal exporter = new LoIReportFromAppraisal(ifvProposalLoIDto, sanctionTermsConditionsDTOs,
					masterRepositoryData, proposedSchemaDetails, userName, designation);
			pdfData = exporter.generatePdfData();

			String schemeName = ifvProposalLoIDto.getSchemeName();
			String bankName = StringUtils.hasText(applicationEntity.getIfvShortName())
					? applicationEntity.getIfvShortName().replace(".", "")
					: applicationEntity.getIfvName().replace(".", "");

			String dateTimeFormatted = "";
			DateTimeFormatter dateformate = DateTimeFormatter.ofPattern(DATE_FORMATE);
			LocalDate ld = ifvProposalLoIDto.getLoiDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			dateTimeFormatted = ld.format(dateformate);
			fileName = bankName.toUpperCase() + LOI_DATED + dateTimeFormatted + " " + schemeName;

			fileRepositoryService.savePDF(pdfData, loiId, fileName, "PropLoI", null, null);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error Occurred while generating pdf ");
			throw new DatabaseOperationException("Error occurred while generating PDF " + e.getMessage());
		}
		ReportResponseJsonDTO flashMinutesDTO = new ReportResponseJsonDTO(fileName, pdfData);
		return ResponseEntity.ok().body(flashMinutesDTO);
	}

	@GetMapping("/loi-report-word/{loiId}")
	public ResponseEntity<ByteArrayResource> generateLoIReportWord(@PathVariable("loiId") Long loiId) {
		byte[] pdfData;

		IfvProposalLoIDto ifvProposalLoIDto = ifvProposalLoIService.findById(loiId);
		List<SanctionTermsConditionsDTO> sanctionTermsConditionsDTOs = sanctionTermsConditionsService
				.findAllByIfvId(ifvProposalLoIDto.getIfvId());
		sanctionTermsConditionsDTOs = sanctionTermsConditionsDTOs.stream()
				.filter(e -> e.getFundName().equalsIgnoreCase(ifvProposalLoIDto.getFundName())
						&& (e.getSchemeName().contains("RMSE")
								|| e.getSchemeName().equalsIgnoreCase(ifvProposalLoIDto.getSchemeName())))
				.sorted(Comparator.comparing(SanctionTermsConditionsDTO::getId)).collect(Collectors.toList());

		List<MasterRepositoryDTO> masterRepositoryData = masterRepositoryService.findAll();

		List<ProposedSchemaDTO> proposedSchemaDetails = proposedSchemaService
				.findAllByIfvId(ifvProposalLoIDto.getIfvId());
		String fileName = "";

		IfvApiUsersEntity ifvApiUsersDetails = ifvApiUsersRepo.findByOfrCode(ifvProposalLoIDto.getLoiUser());

		String userName = StringUtils.hasText(ifvApiUsersDetails.getOfrShortName())
				? ifvApiUsersDetails.getOfrShortName()
				: "";
		String designation = UserDesignationEnum.getNameByCode(ifvApiUsersDetails.getOfrDesgCode());

		S2IFVApplicationEntity applicationEntity = applicationRepo.findByIfvId(ifvProposalLoIDto.getIfvId()).get(0);

		try {
			LoIReportWord exporter = new LoIReportWord(ifvProposalLoIDto, sanctionTermsConditionsDTOs,
					masterRepositoryData, proposedSchemaDetails, userName, designation);
			pdfData = exporter.generateWordDocument();

			String schemeName = ifvProposalLoIDto.getSchemeName();
			String bankName = StringUtils.hasText(applicationEntity.getIfvShortName())
					? applicationEntity.getIfvShortName().replace(".", "")
					: applicationEntity.getIfvName().replace(".", "");
			String dateTimeFormatted = "";
			DateTimeFormatter dateformate = DateTimeFormatter.ofPattern(DATE_FORMATE);
			LocalDate ld = ifvProposalLoIDto.getLoiDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			dateTimeFormatted = ld.format(dateformate);
			fileName = bankName.toUpperCase() + LOI_DATED + dateTimeFormatted + " " + schemeName;

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error Occurred while generating pdf ");
			throw new DatabaseOperationException("Error occurred while generating PDF " + e.getMessage());
		}

		ReportResponseJsonDTO document = new ReportResponseJsonDTO(fileName, pdfData);

		ByteArrayResource resource = new ByteArrayResource(document.getFileDataBytea());
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
		headers.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
	}

	@GetMapping("/viewDoc")
	public ResponseEntity<Resource> viewDoc(@RequestParam(value = "ifvId", required = false) Long ifvId,
			@RequestParam(value = "module", required = false) String module) {
		logger.info("Started viewDoc() in ReportController() {}", ifvId);
		return fileRepositoryService.viewOrDownloadDoc(ifvId, module, false);
	}

	@GetMapping("/downloadDoc")
	public ResponseEntity<Resource> downloadDoc(@RequestParam(value = "ifvId", required = false) Long ifvId,
			@RequestParam(value = "module", required = false) String module) {
		logger.info("Started downloadDoc() in ReportController() {}", ifvId);
		return fileRepositoryService.viewOrDownloadDoc(ifvId, module, true);
	}

}
