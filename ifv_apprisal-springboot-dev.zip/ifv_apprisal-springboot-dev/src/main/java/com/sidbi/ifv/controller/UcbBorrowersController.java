package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.UcbTop10BorrowersDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.UcbBorrowersService;

@RestController
@CrossOrigin
@RequestMapping("/ucb-borrowers")
public class UcbBorrowersController extends CrudController<UcbTop10BorrowersDTO, Long> {

	private static final Logger logger = LoggerFactory.getLogger(UcbBorrowersController.class);

	@Autowired
	private UcbBorrowersService service;

	@Override
	public CrudService<UcbTop10BorrowersDTO, Long> getCrudService() {
		return service;
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<UcbTop10BorrowersDTO>> getUcbBorrowersOnIfvId(@PathVariable Long ifvId) {
		logger.info("getUcbBorrowersOnIfvId() started in UcbTop10BorrowersController ");
		List<UcbTop10BorrowersDTO> dtos = service.findAllByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}
}