package com.sidbi.ifv.service.impl;

import java.io.InputStream;

import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.client.FileServerFeignClient;
import com.sidbi.ifv.dto.CommonRequestDto;
import com.sidbi.ifv.services.FileStorageService;
import com.sidbi.ifv.util.CommonRimvServiceSupport;

import feign.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Profile({ "uat", "prod" })
@RequiredArgsConstructor
public class RemoteFileStorageService implements FileStorageService {

	private final FileServerFeignClient feignClient;
	private final CommonRimvServiceSupport commonRimvServiceSupport;

	@Override
	public ResponseEntity<StreamingResponseBody> handleFile(CommonRequestDto requestDto) {

		log.info("File download request received. action={}, filePath={}", requestDto.getAction(),
				requestDto.getFilePath());

		try {

			Response feignResponse = feignClient.fetchFile(requestDto.getFilePath());

			log.info("File server responded successfully for path={}", requestDto.getFilePath());

			String fileName = extractFileName(requestDto.getFilePath());

			MediaType mediaType = commonRimvServiceSupport.determineContentType(fileName);

			log.info("Preparing response. fileName={}, contentType={}", fileName, mediaType);

			StreamingResponseBody stream = outputStream -> {
				try (InputStream in = feignResponse.body().asInputStream()) {

					log.info("Streaming file to client. fileName={}", fileName);

					in.transferTo(outputStream);

					outputStream.flush();

					log.info("File streamed successfully. fileName={}", fileName);

				} catch (Exception ex) {

					log.error("Error while streaming file. fileName={}", fileName, ex);

					throw ex;
				}
			};

			ResponseEntity.BodyBuilder responseBuilder = ResponseEntity.ok().contentType(mediaType);

			if ("download".equalsIgnoreCase(requestDto.getAction())) {

				responseBuilder.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");

				log.info("Content-Disposition header added. fileName={}", fileName);
			}

			return responseBuilder.body(stream);

		} catch (Exception e) {

			log.error("File download failed. action={}, filePath={}", requestDto.getAction(), requestDto.getFilePath(),
					e);

			throw new RuntimeException("Failed to download file: " + requestDto.getFilePath(), e);
		}
	}

	private String extractFileName(String filePath) {
		return filePath.substring(filePath.lastIndexOf("/") + 1);
	}
}
