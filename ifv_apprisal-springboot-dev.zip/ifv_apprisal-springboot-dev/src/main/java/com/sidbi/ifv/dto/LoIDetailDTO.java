package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class LoIDetailDTO {

	private Long id;

	private Long sancId;

	private Long sancDetailId;

	private Long appraisalMnuteId;

	private String ifvName;

	private String ifvNo;

	private Date ifvDate;

	private String addressOfTheBank;

	private String note1;

	private String note2;

	private String note2Subnote1;

	private String note2Subnote2;

	private String note3;

	private String loiUser;

	private String userDesignation;

	private String headerNote;

	private String nameOfDocuments;

	private Date documentDated;

	private String sectionOrClauseNo;

	private String sectionMode;

	private String kycDocuments;

	private String cvLanguage;

	private String cvRegion;
}
