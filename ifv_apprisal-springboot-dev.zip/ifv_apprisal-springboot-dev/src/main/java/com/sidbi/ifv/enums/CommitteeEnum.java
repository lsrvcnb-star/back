package com.sidbi.ifv.enums;

import java.util.Arrays;

public enum CommitteeEnum {

	IFCC_CGM(101, "IFCC-CGM"), SUB_ALCO(102, "SUB-ALCO");

	private final int committeeCode;

	private final String committeeName;

	CommitteeEnum(int committeeCode, String committeeName) {
		this.committeeCode = committeeCode;
		this.committeeName = committeeName;
	}

	public int getCommitteeCode() {
		return committeeCode;
	}

	public String getCommitteeName() {
		return committeeName;
	}

	public static String getCommitteeNameByCode(int committeeCode) {
		return Arrays.stream(CommitteeEnum.values()).filter(e -> e.getCommitteeCode() == committeeCode).findFirst()
				.map(CommitteeEnum::getCommitteeName)
				.orElseThrow(() -> new IllegalArgumentException("No matching status found for flag: " + committeeCode));
	}

}
