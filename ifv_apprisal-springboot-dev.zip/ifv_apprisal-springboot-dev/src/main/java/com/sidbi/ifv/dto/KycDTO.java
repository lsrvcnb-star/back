package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class KycDTO {

	private Long kycId;

	private Long ifvId;

	private String kycProductName;

	private BigDecimal kycAmount;

	private BigDecimal kycShareProfile;

	private String kycType;
	
}
