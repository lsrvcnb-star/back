package com.sidbi.ifv.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sidbi.ifv.entity.LoIDetailEntity;

public interface LoIDetailRepo extends JpaRepository<LoIDetailEntity, Long>, JpaSpecificationExecutor<LoIDetailEntity> {

	LoIDetailEntity findBySancId(Long sancId);

	LoIDetailEntity findLoIBySancIdAndSancDetailIdAndAppraisalMnuteId(Long sancId, Long sancDetailId,
			Long appraisalMnuteId);

	LoIDetailEntity findTop1ByIfvNameOrderByIdDesc(String ifvName);

}
