package com.sidbi.ifv.controller;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.RatingRepositoryDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.RatingRepositoryService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/rating")
public class RatingRepositoryController {

	private static final Logger logger = LoggerFactory.getLogger(RatingRepositoryController.class);

	@Autowired
	private RatingRepositoryService ratingRepositoryService;

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/get/{id}")
	public ResponseEntity<RatingRepositoryDTO> findById(@PathVariable Long id) {
		logger.info("findById() started RatingRepositoryController {} ", id);
		RatingRepositoryDTO masterRepositoryDTO = ratingRepositoryService.findById(id);
		return ResponseEntity.ok(masterRepositoryDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<RatingRepositoryDTO>> findAll() {
		logger.info("findAll() started RatingRepositoryController ");
		List<RatingRepositoryDTO> list = ratingRepositoryService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<RatingRepositoryDTO> save(@RequestBody RatingRepositoryDTO masterRepositoryDTO) {
		logger.info("save() started RatingRepositoryController {} ", masterRepositoryDTO);
		RatingRepositoryDTO savedRatingRepositoryDTO = ratingRepositoryService.save(masterRepositoryDTO);
		return ResponseEntity.ok(savedRatingRepositoryDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<RatingRepositoryDTO>> saveAll(
			@RequestBody List<RatingRepositoryDTO> listRatingRepositoryDTO) {
		logger.info("saveAll() started in RatingRepositoryController ");
		List<RatingRepositoryDTO> savedRatingRepositoryDTOs = ratingRepositoryService.saveAll(listRatingRepositoryDTO);
		return ResponseEntity.ok(savedRatingRepositoryDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<RatingRepositoryDTO> update(@PathVariable Long id,
			@RequestBody RatingRepositoryDTO ratingRepositoryDTO) {
		logger.info("update() started RatingRepositoryController {} ", ratingRepositoryDTO);
		RatingRepositoryDTO updatedRatingRepositoryDTO = ratingRepositoryService.update(id, ratingRepositoryDTO);
		return ResponseEntity.ok(updatedRatingRepositoryDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started RatingRepositoryController {} ", id);
		ratingRepositoryService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<RatingRepositoryDTO>> getAllS2IFVRatingRepositoryEntityOnIfvId(
			@PathVariable Long ifvId) {
		logger.info("getAllS2IFVRatingRepositoryEntityOnIfvId() started in RatingRepositoryController ");
		List<RatingRepositoryDTO> ratingRepositoryDTOs = ratingRepositoryService.findAllByIfvId(ifvId);

		if (CollectionUtils.isEmpty(ratingRepositoryDTOs)) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				List<RatingRepositoryDTO> dtos2 = ratingRepositoryService.findAllByIfvId(applicationDTO.getIfvId());
				if (!CollectionUtils.isEmpty(dtos2)) {
					dtos2.forEach(dto -> {
						dto.setIfvId(ifvId);
						dto.setRtCode(null);
					});
					return ResponseEntity.ok(dtos2);
				}
			}
			return ResponseEntity.ok(Collections.emptyList());
		} else {
			return ResponseEntity.ok(ratingRepositoryDTOs);
		}

	}

}
