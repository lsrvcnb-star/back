package com.sidbi.ifv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ucb_criteria_parameters")
public class UcbCriteriaParameterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "criteria_parameters")
	private String criteriaParameters;

	@Column(name = "complied")
	private Character complied;

	@Column(name = "compliance")
	private String compliance;

	@Column(name = "justification")
	private String justification;

	@Column(name = "note")
	private String note;

	@Column(name = "compliance_date")
	private String complianceDate;

}
