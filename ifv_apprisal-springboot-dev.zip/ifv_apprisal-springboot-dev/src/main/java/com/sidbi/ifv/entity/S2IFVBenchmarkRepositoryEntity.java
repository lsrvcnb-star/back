package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_BENCHMARK_REPOSITORY")
public class S2IFVBenchmarkRepositoryEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bm_code")
	private Long bmCode;
	
	@Column(name = "ifv_id")
	private Long ifvId;
	
	@Column(name = "bm_banktype")
	private String bmBanktype;
	
	@Column(name = "bm_bankmeetingdate")
	private String bmBankmeetingdate;
	
	@Column(name = "bm_particulars1")
	private String bmParticulars1;
	
	@Column(name = "bm_remarks")
	private String bmRemarks;
	
	@Column(name = "bm_order")
	private String bmOrder;
	
	@Column(name = "bm_flg")
	private String bmFlg;
	
	@Column(name = "date_of_action")
	private Date dateOfAction;
	
	@Column(name = "al_code")
	private Long alCode;

}