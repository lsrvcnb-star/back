package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sidbi.ifv.entity.PoaSignatureEntity;

public interface PoaSignatureRepository extends JpaRepository<PoaSignatureEntity, Long> {

	List<PoaSignatureEntity> findByCifNumber(String cifNumber);
	
	@Query(value = "SELECT distinct cif_number FROM S2_IFV_POA_SIGNATURE" , nativeQuery = true)
	List<String> getAllCifNumbers();
}
