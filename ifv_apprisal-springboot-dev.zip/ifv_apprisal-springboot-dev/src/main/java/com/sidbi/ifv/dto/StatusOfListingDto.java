package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class StatusOfListingDto {

	private Long id;

	private Long ifvId;

	private String column1;

	private BigDecimal column2;

	private BigDecimal column3;

}
