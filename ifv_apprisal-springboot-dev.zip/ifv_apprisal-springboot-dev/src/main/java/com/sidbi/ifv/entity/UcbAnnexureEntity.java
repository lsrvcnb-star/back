package com.sidbi.ifv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ucb_annexures")
public class UcbAnnexureEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "particulars")
	private String particulars;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "note")
	private String note;

	@Column(name = "annexure_no")
	private Integer annexureNo;

}
