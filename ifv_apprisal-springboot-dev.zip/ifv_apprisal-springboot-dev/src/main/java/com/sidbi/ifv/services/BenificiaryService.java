package com.sidbi.ifv.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.BeneficiaryDocValResponse;
import com.sidbi.ifv.dto.BeneficiaryDocsResponse;
import com.sidbi.ifv.dto.BeneficiaryLoginData;
import com.sidbi.ifv.dto.BeneficiaryLoginRequestDTO;
import com.sidbi.ifv.dto.BeneficiarySummaryResponse;
import com.sidbi.ifv.dto.FetchBeneficiaryRequest;
import com.sidbi.ifv.dto.FetchDsfSubmittedBeneficiaryRequest;
import com.sidbi.ifv.dto.IfvBeneficiaryAppDto;
import com.sidbi.ifv.dto.IfvBeneficiaryDetailsDto;
import com.sidbi.ifv.dto.ReturnBankForwardedDocumentRequest;
import com.sidbi.ifv.dto.UploadAndValidateBeneficiaryRequestDTO;
import com.sidbi.ifv.dto.UploadJobResponse;
import com.sidbi.ifv.util.ApiResponse;

public interface BenificiaryService {

	BeneficiaryLoginData authenticate(BeneficiaryLoginRequestDTO loginRequest);

	ApiResponse<Void> uploadBenificiaryDoc(MultipartFile file, UploadAndValidateBeneficiaryRequestDTO request);

	IfvBeneficiaryDetailsDto getBenificiaryById(Long id);

	boolean deleteBenificiary(Long id);

	Page<IfvBeneficiaryDetailsDto> getBenificiaryList(Pageable pageable, String filters, String sorting,
			String globalFilter);

	Page<IfvBeneficiaryDetailsDto> fetchBenificiaryDetailsByCifNo(String cifNumber, Pageable pageable, String filters,
			String sorting, String globalFilter);

	Page<IfvBeneficiaryAppDto> fetchBenificiaryApps(Pageable pageable, String filters, String sorting,
			String globalFilter);

	boolean uploadBenificiaryAppDoc(MultipartFile file, IfvBeneficiaryAppDto request);

	IfvBeneficiaryAppDto getBenificiaryAppById(Long id);

	boolean deleteBenificiaryApp(Long id);

	BeneficiaryDocValResponse validateBeneficiaryDoc(MultipartFile file);

	ResponseEntity<Page<BeneficiarySummaryResponse>> fetchBeneficiaryDataFromService(FetchBeneficiaryRequest request);

	ResponseEntity<Page<BeneficiaryDocsResponse>> fetchBeneficiaryDocsByCif(FetchBeneficiaryRequest request);

	void deleteDocumentByJobId(String jobId);

	void updateDocumentStatusByJobId(String jobId);

	void forwardBeneficiaryDataToDFS(String jobId);

	void updateDocumentToSubmittedByJobId(String jobId);

	void saveFwdDocFromBanks(BeneficiaryDocsResponse docsResponse);

	Page<IfvBeneficiaryDetailsDto> fetchBeneficiaryUploadsForAllBanks(FetchBeneficiaryRequest request);

	IfvBeneficiaryDetailsDto returnForwardedApplication(ReturnBankForwardedDocumentRequest request);

	Page<IfvBeneficiaryDetailsDto> fetchDfsSubmittedBeneficiaries(FetchDsfSubmittedBeneficiaryRequest request);

	UploadJobResponse startValidationIfRequired(MultipartFile file, UploadAndValidateBeneficiaryRequestDTO request);

	void validateBeneficiaryFile(MultipartFile file);
}
