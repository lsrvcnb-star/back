package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class AggregateExposureResponseDto {

	private String bankGroup;

	private BigDecimal percCapitalFund;

	private BigDecimal exposureLimit;

	private BigDecimal actualExposure;

	private BigDecimal percUtilization;

	private String errorMsg;
}
