package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.UcbFinancialPerformanceDTO;

public interface UcbFinancialPerformanceService extends CrudService<UcbFinancialPerformanceDTO, Long> {

	List<UcbFinancialPerformanceDTO> findAllByIfvId(Long ifvId);

}
