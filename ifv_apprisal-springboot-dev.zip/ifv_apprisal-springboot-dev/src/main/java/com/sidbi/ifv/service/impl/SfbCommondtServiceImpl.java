package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.SfbCommondtDTO;
import com.sidbi.ifv.entity.S2IFVSfbCommondtEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.SfbCommondtRepository;
import com.sidbi.ifv.services.SfbCommondtService;
import com.sidbi.ifv.util.CommonUtil;

@Service
public class SfbCommondtServiceImpl implements SfbCommondtService {

	private static final Logger logger = LoggerFactory.getLogger(SfbCommondtServiceImpl.class);

	@Autowired
	private SfbCommondtRepository s2ifccSfbCommondtRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Autowired
	private CommonUtil commonUtil;

	@Override
	public List<SfbCommondtDTO> findAll() {
		logger.info("findAll() started in SfbCommondtServiceImpl for S2IFVSfbCommondtEntity");
		try {
			List<S2IFVSfbCommondtEntity> list = s2ifccSfbCommondtRepository.findAll();
			return list.stream().map(ifccsfbcommon -> modelMapper.map(ifccsfbcommon, SfbCommondtDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVSfbCommondtEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVSfbCommondtEntity entities." + msg + " ", e);
		}
	}

	@Override
	public SfbCommondtDTO findById(Long id) {
		logger.info("findById() started in SfbCommondtServiceImpl for S2IFVSfbCommondtEntity {} ", id);
		try {
			S2IFVSfbCommondtEntity s2ifccSfbCommondtEntity = s2ifccSfbCommondtRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVSfbCommondtEntity", id));
			return modelMapper.map(s2ifccSfbCommondtEntity, SfbCommondtDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching  S2IFVSfbCommondtEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while fetching  S2IFVSfbCommondtEntity." + msg + " ",
					e);
		}
	}

	@Override
	public SfbCommondtDTO save(SfbCommondtDTO s2ifccSfbCommondtDTO) {
		logger.info("save() started in SfbCommondtServiceImpl for S2IFVSfbCommondtEntity {} ", s2ifccSfbCommondtDTO);
		try {

			if (s2ifccSfbCommondtDTO.getSfbId() != null && s2ifccSfbCommondtDTO.getSfbId() > 0) {
				return update(s2ifccSfbCommondtDTO.getSfbId(), s2ifccSfbCommondtDTO);
			} else {
				S2IFVSfbCommondtEntity s2ifccSfbCommondtEntity = modelMapper.map(s2ifccSfbCommondtDTO,
						S2IFVSfbCommondtEntity.class);
				s2ifccSfbCommondtRepository.save(s2ifccSfbCommondtEntity);
				return modelMapper.map(s2ifccSfbCommondtEntity, SfbCommondtDTO.class);
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVSfbCommondtEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVSfbCommondtEntity." + msg + " ",
					e);
		}
	}

	@Override
	public SfbCommondtDTO update(Long id, SfbCommondtDTO s2ifccSfbCommondtDTO) {

		logger.info("update() started in SfbCommondtServiceImpl for S2IFVSfbCommondtEntity {} {} ", id,
				s2ifccSfbCommondtDTO);
		try {
			S2IFVSfbCommondtEntity existings2ifccSfbCommondtEntity = s2ifccSfbCommondtRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVSfbCommondtEntity", id));
			BeanUtils.copyProperties(s2ifccSfbCommondtDTO, existings2ifccSfbCommondtEntity,
					commonUtil.getNullPropertyNames(s2ifccSfbCommondtDTO));
			s2ifccSfbCommondtRepository.save(existings2ifccSfbCommondtEntity);
			return modelMapper.map(existings2ifccSfbCommondtEntity, SfbCommondtDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVSfbCommondtEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVSfbCommondtEntity of id ." + id + " " + msg + " ", e);
		}

	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in SfbCommondtServiceImpl for S2IFVSfbCommondtEntity {} ", id);
		try {
			S2IFVSfbCommondtEntity existings2ifccSfbCommondtEntity = s2ifccSfbCommondtRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVSfbCommondtEntity", id));
			s2ifccSfbCommondtRepository.delete(existings2ifccSfbCommondtEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVSfbCommondtEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVSfbCommondtEntity of id ." + id + " " + msg + " ", e);
		}

	}

	@Override
	public List<SfbCommondtDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in SfbCommondtServiceImpl ");
		try {
			List<S2IFVSfbCommondtEntity> listS2IFVSfbCommondtEntities = s2ifccSfbCommondtRepository.findByIfvId(ifvId);
			return listS2IFVSfbCommondtEntities.stream()
					.map(sfbCommondtEntitiy -> modelMapper.map(sfbCommondtEntitiy, SfbCommondtDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVSfbCommondtEntities based on IfvId. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVSfbCommondtEntities  based on IfvId." + ifvId + " " + msg
							+ " ",
					e);

		}
	}

	@Override
	public SfbCommondtDTO saveOrUpdateAuditComment(Long ifvId, String auditComment) {
		logger.info("saveOrUpdateAuditComment() started in SfbCommondtServiceImpl ");
		try {
			List<S2IFVSfbCommondtEntity> listS2IFVSfbCommondtEntities = s2ifccSfbCommondtRepository.findByIfvId(ifvId);
			if (listS2IFVSfbCommondtEntities != null && !listS2IFVSfbCommondtEntities.isEmpty()) {
				S2IFVSfbCommondtEntity entity = listS2IFVSfbCommondtEntities.get(0);
				entity.setAuditComments(auditComment);
				S2IFVSfbCommondtEntity savedEntity = s2ifccSfbCommondtRepository.save(entity);
				return modelMapper.map(savedEntity, SfbCommondtDTO.class);

			} else {
				S2IFVSfbCommondtEntity entity = new S2IFVSfbCommondtEntity();
				entity.setAuditComments(auditComment);
				entity.setIfvId(ifvId);
				S2IFVSfbCommondtEntity savedEntity = s2ifccSfbCommondtRepository.save(entity);
				return modelMapper.map(savedEntity, SfbCommondtDTO.class);
			}
		} catch (DatabaseOperationException e) {
			throw e;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while executing saveOrUpdateAuditComment. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while executing saveOrUpdateAuditComment. {}." + ifvId + " " + msg + " ", e);

		}
	}

}
