package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "s2_minutes_colending_limit")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MinutesColendingLimit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "minute_sanction_id", nullable = false)
	private Integer minuteSanctionId;

	@Column(name = "bank_name", nullable = false, length = 100)
	private String bankName;

	@Column(name = "cif_number", nullable = false, length = 100)
	private String cifNumber;

	@Column(name = "lending_limit", precision = 20, scale = 8)
	private BigDecimal lendingLimit;

	@Column(length = 150)
	private String scheme;

	@Column(name = "risk_sharing_ratio", length = 150)
	private String riskSharingRatio;

	@Column(name = "initial_operating_limit", precision = 20, scale = 8)
	private BigDecimal initialOperatingLimit;

	@Column(length = 1500)
	private String remarks;

	@Column(name = "created_by", length = 200)
	private String createdBy;

	@Column(name = "created_date")
	private LocalDate createdDate;

	@Column(name = "sanc_status", length = 150)
	private String sancStatus;
}