package com.sidbi.ifv.enums;

import java.util.Arrays;

public enum AppStatusEnum {

	NEW("NW", "New"), LOCK("LK", "Lock"), UN_LOCK("UL", "Unlock"), CONFIRM("CN", "Confirm"), APPROVE("AP", "Approve");

	private final String shortName;
	private final String fullName;

	AppStatusEnum(String shortName, String fullName) {
		this.shortName = shortName;
		this.fullName = fullName;
	}

	public String getShortName() {
		return shortName;
	}

	public String getFullName() {
		return fullName;
	}

	public static String getFullNameByShortName(String shortName) {
		return Arrays.stream(AppStatusEnum.values()).filter(e -> e.getShortName().equalsIgnoreCase(shortName))
				.findFirst().map(AppStatusEnum::getFullName).orElseThrow(
						() -> new IllegalArgumentException("No matching status found for short name: " + shortName));
	}
}
