package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.RestructuredAssetsEntity;

public interface RestructuredAssetsRepository extends JpaRepository<RestructuredAssetsEntity, Long> {

	List<RestructuredAssetsEntity> findByIfvId(Long ifvId);

}
