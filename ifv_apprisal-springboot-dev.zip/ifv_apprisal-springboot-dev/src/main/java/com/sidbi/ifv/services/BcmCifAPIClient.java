package com.sidbi.ifv.services;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;


@FeignClient(url = "${masterdbms.url}" , value = "BcmCifService")
public interface BcmCifAPIClient {
	
	@GetMapping("/api/bcmcif/getCustCDLongName")
	List<Object> findCustCDLongName();
	
}