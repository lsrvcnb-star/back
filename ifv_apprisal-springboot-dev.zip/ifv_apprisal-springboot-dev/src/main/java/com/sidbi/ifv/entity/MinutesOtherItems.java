package com.sidbi.ifv.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "s2_minutes_other_items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MinutesOtherItems {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "minute_sanction_id", nullable = false)
	private Integer minuteSanctionId;

	@Column(name = "bank_name", nullable = false)
	private String bankName;

	@Column(name = "cif_number", nullable = false)
	private String cifNumber;

	@Column(length = 1500)
	private String remarks;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date", nullable = false)
	private LocalDate createdDate;

	@Column(name = "sanc_status")
	private String sancStatus;
}
