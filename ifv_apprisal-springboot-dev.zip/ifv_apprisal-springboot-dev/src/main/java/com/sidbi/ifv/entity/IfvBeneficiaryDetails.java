package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ifv_beneficiary_details")
public class IfvBeneficiaryDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "bank_name", length = 100)
	private String bankName;

	@Column(name = "cif_number", length = 50)
	private String cifNumber;

	@Column(name = "loan_acc_no", length = 50)
	private String loanAccountNo;

	@Column(name = "ben_pre_disb_flag")
	private String benPreDisbFlag;// Y or N

	@Column(name = "ben_ref_no")
	private String benRefNo;

	@Column(name = "file_name", length = 150)
	private String fileName;

	@Column(name = "file_path", length = 500)
	private String filePath;

	@Column(name = "file_type", length = 50)
	private String fileType;

	@Column(name = "file_size")
	private Long fileSize;

	@Column(name = "upload_date_time")
	private LocalDateTime uploadDateTime;

	@Column(name = "upload_by", length = 100)
	private String uploadBy;

	@Column(name = "remarks", length = 4000)
	private String remarks;

	@Column(name = "disb_date")
	private String disbDate;

	@Column(name = "ref_date")
	private LocalDateTime refDate;

	@Column(name = "job_id")
	private String jobId;

	@Column(name = "status")
	private String status;

	@Column(name = "validated")
	private String validated;

	@Column(name = "return_remarks")
	private String returnRemarks;

	@Column(name = "return_by")
	private String returnBy;

	@Column(name = "upload_by_email")
	private String uploadByEmail;

	@Column(name = "ifv_file_name", length = 150)
	private String ifvFileName;

	@Column(name = "ifv_file_path", length = 500)
	private String ifvFilePath;

	@Column(name = "ifv_submitted_date")
	private LocalDateTime ifvSubmittedDate;

	@Column(name = "ifv_remarks")
	private String ifvRemarks;

	@Column(name = "ifv_submit_by")
	private String ifvSubmitBy;

	@Column(name = "proceed_bank_upload")
	private String proceedBankUpload;

	@Column(name = "scheme")
	private String scheme;

	@Column(name = "refinance_amount")
	private BigDecimal refinanceAmount;

}
