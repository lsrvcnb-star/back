package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.IfvProposalLoIDto;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.IfvProposalLoIService;

@RestController
@CrossOrigin
@RequestMapping("/ifv-proposals-loi")
public class IfvProposalLoIController extends CrudController<IfvProposalLoIDto, Long> {

	private static final Logger logger = LoggerFactory.getLogger(IfvProposalLoIController.class);

	@Autowired
	private IfvProposalLoIService service;

	@Override
	public CrudService<IfvProposalLoIDto, Long> getCrudService() {
		return service;
	}

	@GetMapping("/findAllLoIByIfvId/{ifvId}")
	public ResponseEntity<List<IfvProposalLoIDto>> findAllLoIByIfvId(@PathVariable Long ifvId) {
		logger.info("findAllLoIByIfvId() started in IfvProposalLoIController ");
		List<IfvProposalLoIDto> dtos = service.findAllByIfvId(ifvId);
		return ResponseEntity.ok(dtos);
	}

	@GetMapping("/getAllOnUserTypeOnPage/{userType}/{userCode}")
	public ResponseEntity<Page<IfvProposalLoIDto>> getAllOnUserTypeOnPage(@PathVariable String userType,
			@PathVariable String userCode, @RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter,
			@RequestParam(required = false) String status) {

		logger.info("getAllOnUserTypeOnPage() started IfvProposalLoIController {} ", userType);

		int page = start / size;
		return ResponseEntity.ok(
				service.getAllOnUserTypeOnPage(userType, userCode, page, size, filters, sorting, globalFilter, status));
	}

	@GetMapping("/getLoIDocumentByPropLoIId/{id}")
	public ResponseEntity<FileRepositoryDTO> getDocumentByMinuteId(@PathVariable Long id) {
		FileRepositoryDTO document = service.getLoIDocumentByPropLoIId(id);
		return ResponseEntity.ok(document);
	}

	@GetMapping("/fetchLoIDetailsByPropId/{id}")
	public ResponseEntity<List<IfvProposalLoIDto>> fetchLoIDetailsByPropId(@PathVariable Long id) {
		logger.info("fetchLoIDetailsByPropId() started in IfvProposalLoIController {} ", id);
		List<IfvProposalLoIDto> dtos = service.fetchLoIDetailsByPropId(id);
		return ResponseEntity.ok(dtos);
	}

	@GetMapping("/getCountOfLoIs")
	public ResponseEntity<Long> getCountOfLoIs() {
		logger.info("getCountOfLoIs() started in IfvProposalLoIController ");
		Long count = service.getCountOfLoIs();
		return ResponseEntity.ok(count);
	}

}
