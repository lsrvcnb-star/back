package com.sidbi.ifv.model;

import lombok.Data;

@Data
public class CVWebLoginRequest {
	private String username;
	private String password;
	private Integer folderId;
	private String localAddress;
	private String sessionId;
}
