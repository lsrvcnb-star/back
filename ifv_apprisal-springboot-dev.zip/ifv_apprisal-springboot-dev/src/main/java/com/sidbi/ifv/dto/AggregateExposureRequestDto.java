package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class AggregateExposureRequestDto {

	private String cifNumber;

	private Date asOnDate;

	private String groupName;
}
