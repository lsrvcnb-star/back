package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.RestructuredAssetsDTO;
import com.sidbi.ifv.entity.RestructuredAssetsEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.RestructuredAssetsRepository;
import com.sidbi.ifv.services.RestructuredAssetsService;

@Service
public class RestructuredAssetsServiceImpl implements RestructuredAssetsService {

	private static final Logger logger = LoggerFactory.getLogger(RestructuredAssetsServiceImpl.class);

	@Autowired
	private RestructuredAssetsRepository repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public RestructuredAssetsDTO findById(Long id) {
		logger.info("findById() started in RestructuredAssetsServiceImpl for RestructuredAssetsEntity {} ", id);
		RestructuredAssetsEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("RestructuredAssetsEntity", id));
		return mapper.map(entity, RestructuredAssetsDTO.class);
	}

	@Override
	public List<RestructuredAssetsDTO> findAll() {
		logger.info("findAll() started in RestructuredAssetsServiceImpl of RestructuredAssetsEntity");
		try {
			List<RestructuredAssetsEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, RestructuredAssetsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all RestructuredAssetsEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all RestructuredAssetsEntities ." + msg + " ", e);
		}
	}

	@Override
	public RestructuredAssetsDTO save(RestructuredAssetsDTO dto) {
		logger.info("save() started in RestructuredAssetsServiceImpl for RestructuredAssetsEntity {} ", dto);
		try {
			RestructuredAssetsEntity entity = mapper.map(dto, RestructuredAssetsEntity.class);
			repository.save(entity);
			return mapper.map(entity, RestructuredAssetsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating RestructuredAssetsEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  RestructuredAssetsEntity." + msg + " ",
					e);
		}
	}

	@Override
	public List<RestructuredAssetsDTO> saveAll(List<RestructuredAssetsDTO> dtos) {
		logger.info("saveAll() started in RestructuredAssetsServiceImpl for List of RestructuredAssetsEntity");
		try {

			List<RestructuredAssetsEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, RestructuredAssetsEntity.class)).collect(Collectors.toList());
			List<RestructuredAssetsEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, RestructuredAssetsDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all RestructuredAssetsEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all RestructuredAssetsEntities." + msg + " ", e);
		}
	}

	@Override
	public RestructuredAssetsDTO update(Long id, RestructuredAssetsDTO dto) {
		logger.info("update() started in RestructuredAssetsServiceImpl for RestructuredAssetsEntity {} {} ", id, dto);
		try {
			RestructuredAssetsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("restructuredAssetsEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, RestructuredAssetsDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating RestructuredAssetsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating RestructuredAssetsEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in RestructuredAssetsServiceImpl for RestructuredAssetsEntity {} ", id);
		try {
			RestructuredAssetsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("restructuredAssetsEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting RestructuredAssetsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting RestructuredAssetsEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<RestructuredAssetsDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in RestructuredAssetsServiceImpl for RestructuredAssetsEntity {} ",
				ifvId);
		try {

			List<RestructuredAssetsEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty()) ? list.stream()
					.map(restructuredAssetsEntity -> mapper.map(restructuredAssetsEntity, RestructuredAssetsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId RestructuredAssetsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId RestructuredAssetsEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
