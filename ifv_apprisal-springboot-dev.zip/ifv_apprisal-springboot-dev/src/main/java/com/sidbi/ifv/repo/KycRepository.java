package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVKycEntity;

public interface KycRepository extends JpaRepository<S2IFVKycEntity, Long> {
	
	List<S2IFVKycEntity> findByIfvId(Long ifvId);

}
