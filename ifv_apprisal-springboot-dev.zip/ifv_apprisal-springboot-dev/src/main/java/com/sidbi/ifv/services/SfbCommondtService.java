package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.SfbCommondtDTO;

public interface SfbCommondtService {
	List<SfbCommondtDTO> findAll();
 
	SfbCommondtDTO findById(Long id);

	SfbCommondtDTO save(SfbCommondtDTO s2ifccSfbCommondtDTO);

	SfbCommondtDTO update(Long id, SfbCommondtDTO s2ifccSfbCommondtDTO);

	void delete(Long id);

	List<SfbCommondtDTO> findAllByIfvId(Long ifvId);
	
	SfbCommondtDTO saveOrUpdateAuditComment(Long ifvId, String auditComment);
}
