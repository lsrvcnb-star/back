package com.sidbi.ifv.model;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JwtResponse implements Serializable {
	private static final long serialVersionUID = -8091879091924046844L;
	private String jwttoken;
	private transient Object data;
	private String message;

	public JwtResponse(String jwttoken) {
		this.jwttoken = jwttoken;
		this.data = null;
		this.message = "Authentication successful";
	}

	public JwtResponse(String jwttoken, Object data, String message) {
		this.jwttoken = jwttoken;
		this.data = data;
		this.message = message;
	}
}