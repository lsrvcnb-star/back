package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVRatingRepositoryEntity;

public interface RatingRepository extends JpaRepository<S2IFVRatingRepositoryEntity, Long> {

	List<S2IFVRatingRepositoryEntity> findByIfvId(Long ifvId);
	
	List<S2IFVRatingRepositoryEntity> getByIfvId(Long ifvId);
}