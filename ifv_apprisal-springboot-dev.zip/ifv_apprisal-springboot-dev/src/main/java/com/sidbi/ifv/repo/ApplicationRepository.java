package com.sidbi.ifv.repo;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.S2IFVApplicationEntity;

public interface ApplicationRepository
		extends JpaRepository<S2IFVApplicationEntity, Long>, JpaSpecificationExecutor<S2IFVApplicationEntity> {

	List<S2IFVApplicationEntity> findByIfvId(Long ifvId);

	@Query(value = """
			SELECT
			EXISTS(SELECT 1 FROM S2_IFV_AREASGEOGRAPHICAL WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_ASS_OUTSTANDING WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_ASS_PASTDISB WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_ASS_REPAYMENTS WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_CHIEFBOARD WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_ELIGIBILITY WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_FINANCIALHIGHLIGHTS WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_INSTITUTIONAL WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_INVESTOR WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_KYC WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_PRINCIPAL WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_SCHEMA WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_SFB_AGGREGATE WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_SFB_COMMONDT WHERE ifv_id = :ifvId),
			EXISTS(SELECT 1 FROM S2_IFV_TERMCONDITIONS_DATA WHERE ifv_id = :ifvId)
			""", nativeQuery = true)
	List<Boolean> checkIfvIdExistsInChildTables(@Param("ifvId") Long ifvId);

	@Query(value = "SELECT  max(ifv_id) FROM s2_ifv_application", nativeQuery = true)
	Long findMaxIfvId();

	List<S2IFVApplicationEntity> findAllByIfvIdIn(List<Long> ifvIds);

	List<S2IFVApplicationEntity> findByAppNumber(String appNumber);

	@Modifying
	@Query(value = "UPDATE S2_IFV_APPLICATION set SFB = :sfb  WHERE IFV_ID = :ifvId ", nativeQuery = true)
	void updateSfb(String sfb, Long ifvId);

	@Query(value = "select*from s2_ifv_application sia where cif_number =:cifNo order by ifv_id desc limit 1", nativeQuery = true)
	Optional<S2IFVApplicationEntity> findByCifNumber(@Param("cifNo") String cifNo);

	@Query(value = "SELECT * FROM s2_ifv_application sia WHERE sia.cif_number = :cifNumber ORDER BY sia.ifv_id DESC LIMIT 1 OFFSET 1", nativeQuery = true)
	Optional<S2IFVApplicationEntity> findSecondHighestByCifNumber(@Param("cifNumber") String cifNumber);

	@Query(value = "select * from s2_ifv_application sia where sia.cif_number in (select cif_number from s2_ifv_application sia2 where sia2.ifv_id=:ifvId) order by sia.ifv_id desc limit 1 offset 1", nativeQuery = true)
	Optional<S2IFVApplicationEntity> findSecondHighestByIfvId(@Param("ifvId") Long ifvId);

	@Query(value = "select count(case when t2.app_status ='AP' then 1 end) as approvedCount,count(case when t2.app_status !='AP' then 1 end) as nonApprovedCount from s2_ifv_application t1 join tbl_ifv_module_fwd t2 on t1.ifv_id =t2.ifv_id", nativeQuery = true)
	StatusCount getStatusCounts();

	interface StatusCount {
		Long getApprovedCount();

		Long getNonApprovedCount();
	}

	@Query(value = "select count(case when t2.app_status ='AP' then 1 end) as approvedCount,count(case when t2.app_status !='AP' and t1.checker_id =:userCode then 1 end) as nonApprovedCount from s2_ifv_application t1 join tbl_ifv_module_fwd t2 on t1.ifv_id =t2.ifv_id", nativeQuery = true)
	StatusCount getStatusCounts(@Param("userCode") Long userCode);

	@Query("SELECT a.appNumber FROM S2IFVApplicationEntity a WHERE a.createdDate >= :startDate ORDER BY a.createdDate DESC LIMIT 1")
	String findLatestAppNoFromDate(@Param("startDate") Date startDate);

	@Modifying
	@Query(value = "DELETE FROM ifv_proposal_fwd_checker_details where ifv_id=:ifvId and fwd_rej_status='A'", nativeQuery = true)
	void deleteApprovedRecordFromProposalCheckerDetail(Long ifvId);

	@Query("""
			select a.bankAppRefNos
			from S2IFVApplicationEntity a
			where a.appNumber in :appIds
			""")
	List<String> findBankAppRefNosByAppNumberIn(@Param("appIds") List<String> appIds);

}
