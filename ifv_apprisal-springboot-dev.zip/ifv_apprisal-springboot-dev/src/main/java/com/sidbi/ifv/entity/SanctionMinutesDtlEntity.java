package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_MINUTES_SANC_DTL")
public class SanctionMinutesDtlEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sanc_dtl_code")
	private Long sancDtlCode;

	@Column(name = "sanct_status_code")
	private Long sanctStatusCode;

	@Column(name = "agenda_no")
	private Integer agendaNo;

	@Column(name = "agenda_id")
	private String agendaId;

	@Column(name = "appid")
	private String appid;

	@Column(name = "sanct_purpose_status")
	private String sanctPurposeStatus;

	@Column(name = "sanct_dscn_status")
	private String sanctDscnStatus;

	@Column(name = "min_sumry_created")
	private String minSumryCreated;

	@Column(name = "branch_name")
	private String branchName;

	@Column(name = "application_dt")
	private Date applicationDt;

	@Column(name = "unit_name")
	private String unitName;

	@Column(name = "loan_amount")
	private BigDecimal loanAmount;

	@Column(name = "scheme_name")
	private String schemeName;

	@Column(name = "scheme_cd")
	private String schemeCd;

	@Column(name = "interest_rate")
	private BigDecimal interestRate;

	@Column(name = "tenor")
	private BigDecimal tenor;

	@Column(name = "principal_repayment")
	private String principalRepayment;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "sanc_status")
	private String sancStatus;

	@Column(name = "cost_of_funds")
	private BigDecimal costOfFunds;

	@Column(name = "spread_margin")
	private BigDecimal spreadMargin;

}