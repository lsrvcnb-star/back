package com.sidbi.ifv.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sidbi.ifv.entity.MinutesDocumentsEntity;

@Repository
public interface MinutesDocumentsRepo extends JpaRepository<MinutesDocumentsEntity, Long> {
	Optional<MinutesDocumentsEntity> findByMinuteId(Long minuteId);

	boolean existsByMinuteId(Long id);
}
