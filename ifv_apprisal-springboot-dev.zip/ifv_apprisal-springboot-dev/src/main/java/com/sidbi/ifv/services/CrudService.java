package com.sidbi.ifv.services;

import java.util.List;

public interface CrudService<T, I> {

	T findById(I id);

	List<T> findAll();

	T save(T dto);

	List<T> saveAll(List<T> dtos);

	T update(I id, T dto);

	void delete(I id);

}