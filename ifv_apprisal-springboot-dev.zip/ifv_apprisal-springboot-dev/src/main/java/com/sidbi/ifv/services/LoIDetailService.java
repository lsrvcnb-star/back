package com.sidbi.ifv.services;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.IfvLoIDocumentUploadRequest;
import com.sidbi.ifv.dto.IfvSignedLoiRequestDTO;
import com.sidbi.ifv.dto.IfvSignedLoiResponseDTO;
import com.sidbi.ifv.dto.LoIDetailDTO;
import com.sidbi.ifv.dto.LoiEmailNotificationDTO;
import com.sidbi.ifv.dto.LoiStatusCountResponse;
import com.sidbi.ifv.entity.IfvLoiDocuments;

public interface LoIDetailService extends CrudService<LoIDetailDTO, Long> {

	LoIDetailDTO findBySancId(Long sancId);

	LoIDetailDTO findLoIBySancIdAndSancDetailCode(Long sancId, Long sancDetailId, Long minuteId);

	Page<LoIDetailDTO> getAllOnUserTypeOnPage(int page, int size, String filters, String sorting, String globalFilter);

	LoiEmailNotificationDTO submitSignedLoI(MultipartFile file, IfvLoIDocumentUploadRequest request);

	IfvLoiDocuments getSignedLoIDocument(Long loiDetailsId);

	Page<IfvSignedLoiResponseDTO> fetchSignedLoiSummary(IfvSignedLoiRequestDTO request);

	LoiEmailNotificationDTO submitCounterSignedLoI(MultipartFile file, Long loiDetailsId);

	ResponseEntity<LoiStatusCountResponse> fetchLoiStatusCounts(String cifNumber);

}
