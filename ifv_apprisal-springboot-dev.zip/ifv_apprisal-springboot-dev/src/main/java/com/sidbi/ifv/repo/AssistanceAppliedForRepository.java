package com.sidbi.ifv.repo;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.AssistanceAppliedForEntity;

public interface AssistanceAppliedForRepository extends JpaRepository<AssistanceAppliedForEntity, Long> {

	List<AssistanceAppliedForEntity> findByIfvId(Long ifvId, Sort sort);

	AssistanceAppliedForEntity findByPrId(Long prId);

	@Query(value = "SELECT p FROM AssistanceAppliedForEntity p INNER JOIN S2IFVApplicationEntity a ON p.ifvId = a.ifvId WHERE a.appNumber = :appId")
	List<AssistanceAppliedForEntity> findByAppNo(@Param("appId") String appId);

	List<AssistanceAppliedForEntity> findAllByIfvIdIn(Set<Long> sIfvIds);

	List<AssistanceAppliedForEntity> findAllByIfvIdAndSchemeNameAndFundName(Long ifvId, String schemeName,
			String fundName);

	List<AssistanceAppliedForEntity> findAllByIfvIdAndSchemeNameAndFundNameAndAmount(Long ifvId, String schemeName,
			String fundName, BigDecimal amount);
}
