package com.sidbi.ifv.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.sidbi.ifv.dto.CommonRequestDto;
import com.sidbi.ifv.services.FileStorageService;
import com.sidbi.ifv.util.CommonRimvServiceSupport;

import lombok.RequiredArgsConstructor;

@Service
@Profile("local")
@RequiredArgsConstructor
public class LocalFileStorageService implements FileStorageService {

	private final CommonRimvServiceSupport commonRimvServiceSupport;

	@Override
	public ResponseEntity<StreamingResponseBody> handleFile(CommonRequestDto requestDto) {
		String fileName = extractFileName(requestDto.getFilePath());
		Path filePath = Paths.get(requestDto.getFilePath());

		if (!Files.exists(filePath)) {
			return ResponseEntity.notFound().build();
		}

		MediaType mediaType = commonRimvServiceSupport.determineContentType(fileName);

		StreamingResponseBody stream = outputStream -> {
			try (InputStream in = Files.newInputStream(filePath)) {
				in.transferTo(outputStream);
			} catch (IOException e) {
				throw new UncheckedIOException(e);
			}
		};

		ResponseEntity.BodyBuilder responseBuilder = null;
		try {
			responseBuilder = ResponseEntity.ok().contentType(mediaType).contentLength(Files.size(filePath));
		} catch (IOException e) {
			return ResponseEntity.notFound().build();
		}

		if ("download".equalsIgnoreCase(requestDto.getAction())) {
			responseBuilder.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
		}

		return responseBuilder.body(stream);
	}

	private String extractFileName(String filePath) {
		return filePath.substring(filePath.lastIndexOf("/") + 1);
	}
}
