package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.UcbEligibilityCriteriaEntity;

public interface UcbEligibilityCriteriaRepo extends JpaRepository<UcbEligibilityCriteriaEntity, Long> {

	List<UcbEligibilityCriteriaEntity> findByIfvId(Long ifvId);

}
