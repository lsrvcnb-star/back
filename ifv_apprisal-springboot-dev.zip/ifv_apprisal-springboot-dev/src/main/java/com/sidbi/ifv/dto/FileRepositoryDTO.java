package com.sidbi.ifv.dto;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class FileRepositoryDTO {

	private Long fileCode;

	private String fileModule;

	private Long fileIfvId;

	private String fileType;

	private MultipartFile fileData;

	private String fileName;

	private String fileContentType;

	private String fileDomain;

	private Date dateOfAction;

	private byte[] fileDataBytea;

	private Long sancMinDetailId;

	private Long fileAlcoId;

	private Long loiId;

	private Long propLoiId;

	private String filePath;

}
