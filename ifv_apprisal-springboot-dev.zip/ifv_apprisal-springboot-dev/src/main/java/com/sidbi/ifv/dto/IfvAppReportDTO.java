package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class IfvAppReportDTO {

	private Long ifvId;

	private String ifvName;

	private String ifvAssistance;

	private String ifvSchemeName;

	private BigDecimal ifvAmount;

	private BigDecimal ifvRoi;

	private BigDecimal ifvTenure;

	private String ifvPrRepayment;

	private BigDecimal ifvExposureLimit;

	private BigDecimal ifvExistingOs;

	private BigDecimal ifvPropExposure;

	private BigDecimal ifvTotalExposure;

	private Date ifvRepaymentDate;

	private String ifvExternalRating;

	private String ifvEws;

	private String ifvAdverseNews;

	private String ifvMonetary;

	private String ipAddress;

	private Date modifiedDate;

	private String modifiedOn;

	private Date createdDate;

	private String createdOn;

	private SfbAggregateDTO aggregateDTO;

	private String cifNumber;

	private String sfb;

	private Long ofrCode;

	private String ofrName;

	private String appNumber;
	
	private String makerName;
	
	private String status;
}
