package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.TermsSectionDTO;

public interface TermSanctionService {
	
	TermsSectionDTO getTermSanctionById(Long id);
	
	List<TermsSectionDTO> getAllTermSanction();

}
