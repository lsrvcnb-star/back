package com.sidbi.ifv.services;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.BankRefinanceAppResponse;
import com.sidbi.ifv.dto.IfvBeneficiaryDetailsDto;
import com.sidbi.ifv.dto.IfvRimvAppForwardDto;
import com.sidbi.ifv.dto.LoiEmailNotificationDTO;
import com.sidbi.ifv.dto.SanctionMinutesDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.dto.UserEmailDto;

public interface EmailService {

	void sendEmailWithRetry(String string, ApplicationDTO applicationDTO2, TblIfvModuleFwdDTO fwdDTO, String fileName,
			byte[] fileData);

	void sendEmailWithRetryForMinutes(SanctionMinutesDTO sanctionMinutesDTO, UserEmailDto userEmailDto, String fileName,
			byte[] fileData);

	void sendFwdEmailToRimv(IfvRimvAppForwardDto ifvRimvAppForwardDto);

	void sendApplicationReturnedForCorrectionEmail(IfvBeneficiaryDetailsDto dto);

	void sendBankAppReturnEmail(BankRefinanceAppResponse dto);

	void signedLoiSubmissionNotification(LoiEmailNotificationDTO emailResponse);

	void counterSignedLoiSubmissionNotification(LoiEmailNotificationDTO emailResponse);

}
