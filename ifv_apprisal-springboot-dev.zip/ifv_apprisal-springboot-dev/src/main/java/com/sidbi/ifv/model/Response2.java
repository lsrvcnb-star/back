package com.sidbi.ifv.model;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Response2<T> {
	private String message;
	private HttpStatus status;
	private String errorCode;
	private T data;

	public static <T> ResponseEntity<Response2<T>> generateResponse(String message, HttpStatus status,
			String errorCode) {
		Response2<T> response = new Response2<>();
		response.setMessage(message);
		response.setStatus(status);
		response.setErrorCode(errorCode);
		return new ResponseEntity<>(response, status);
	}

}