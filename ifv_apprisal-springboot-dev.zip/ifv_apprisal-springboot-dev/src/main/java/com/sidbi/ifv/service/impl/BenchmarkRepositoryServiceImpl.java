package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.BenchmarkRepositoryDTO;
import com.sidbi.ifv.entity.S2IFVBenchmarkRepositoryEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.BenchmarkRepository;
import com.sidbi.ifv.services.BenchmarkRepositoryService;

@Service
public class BenchmarkRepositoryServiceImpl implements BenchmarkRepositoryService {

	private static final Logger logger = LoggerFactory.getLogger(BenchmarkRepositoryServiceImpl.class);

	@Autowired
	private BenchmarkRepository benchmarkRepository;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<BenchmarkRepositoryDTO> findAll() {
		logger.info("findAll() started in BenchmarkRepositoryServiceImpl of S2IFVBenchmarkRepositoryEntity");
		try {
			List<S2IFVBenchmarkRepositoryEntity> list = benchmarkRepository.findAll();
			return !list
					.isEmpty()
							? list.stream()
									.map(benchmarkRepositoryEntity -> modelMapper.map(benchmarkRepositoryEntity,
											BenchmarkRepositoryDTO.class))
									.collect(Collectors.toList())
							: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVBenchmarkRepositoryEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVBenchmarkRepositoryEntities." + msg + " ", e);
		}
	}

	@Override
	public BenchmarkRepositoryDTO findById(Long id) {
		logger.info("findById() started in BenchmarkRepositoryServiceImpl for S2IFVBenchmarkRepositoryEntity {} ", id);
		S2IFVBenchmarkRepositoryEntity s2ifvBenchmarkRepositoryEntity = benchmarkRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("s2IFVBenchmarkRepositoryEntity", id));
		return modelMapper.map(s2ifvBenchmarkRepositoryEntity, BenchmarkRepositoryDTO.class);

	}

	@Override
	public BenchmarkRepositoryDTO save(BenchmarkRepositoryDTO benchmarkRepositoryDTO) {
		logger.info("save() started in BenchmarkRepositoryServiceImpl for S2IFVBenchmarkRepositoryEntity {} ",
				benchmarkRepositoryDTO);
		try {
			benchmarkRepositoryDTO.setDateOfAction(new Date());
			S2IFVBenchmarkRepositoryEntity s2ifvBenchmarkRepositoryEntity = modelMapper.map(benchmarkRepositoryDTO,
					S2IFVBenchmarkRepositoryEntity.class);
			benchmarkRepository.save(s2ifvBenchmarkRepositoryEntity);
			return modelMapper.map(s2ifvBenchmarkRepositoryEntity, BenchmarkRepositoryDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVBenchmarkRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating  S2IFVBenchmarkRepositoryEntity." + msg + " ", e);
		}
	}

	@Override
	public BenchmarkRepositoryDTO update(Long id, BenchmarkRepositoryDTO benchmarkRepositoryDTO) {
		logger.info("update() started in BenchmarkRepositoryServiceImpl for S2IFVBenchmarkRepositoryEntity {} {} ", id,
				benchmarkRepositoryDTO);
		try {
			S2IFVBenchmarkRepositoryEntity existingS2IFVBenchmarkRepositoryEntity = benchmarkRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVBenchmarkRepositoryEntity", id));
			BeanUtils.copyProperties(benchmarkRepositoryDTO, existingS2IFVBenchmarkRepositoryEntity);
			benchmarkRepository.save(existingS2IFVBenchmarkRepositoryEntity);
			return modelMapper.map(existingS2IFVBenchmarkRepositoryEntity, BenchmarkRepositoryDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVBenchmarkRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVBenchmarkRepositoryEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in BenchmarkRepositoryServiceImpl for S2IFVBenchmarkRepositoryEntity {} ", id);
		try {
			S2IFVBenchmarkRepositoryEntity existingS2IFVBenchmarkRepositoryEntity = benchmarkRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVBenchmarkRepositoryEntity", id));
			benchmarkRepository.delete(existingS2IFVBenchmarkRepositoryEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVBenchmarkRepositoryEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVBenchmarkRepositoryEntity of id ." + msg + " " + id, e);
		}
	}

	@Override
	public List<BenchmarkRepositoryDTO> saveAll(List<BenchmarkRepositoryDTO> benchmarkRepositoryDTOs) {
		logger.info("saveAll() started in BenchmarkRepositoryServiceImpl for List of S2IFVBenchmarkRepositoryEntity");
		try {
			Date date = new Date();
			benchmarkRepositoryDTOs.forEach(benchmarkRepositoryDTO -> benchmarkRepositoryDTO.setDateOfAction(date));
			List<S2IFVBenchmarkRepositoryEntity> benchmarkRepositoryEntitiesToSave = benchmarkRepositoryDTOs.stream()
					.map(benchmarkRepositoryDTO -> modelMapper.map(benchmarkRepositoryDTO,
							S2IFVBenchmarkRepositoryEntity.class))
					.collect(Collectors.toList());
			List<S2IFVBenchmarkRepositoryEntity> savedBenchmarkRepositoryEntities = benchmarkRepository
					.saveAll(benchmarkRepositoryEntitiesToSave);

			return savedBenchmarkRepositoryEntities.stream().map(benchmarkRepositoryEntity -> modelMapper
					.map(benchmarkRepositoryEntity, BenchmarkRepositoryDTO.class)).collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVBenchmarkRepositoryEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVBenchmarkRepositoryEntities." + msg + " ", e);
		}
	}

	@Override
	public List<BenchmarkRepositoryDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in BenchmarkRepositoryServiceImpl ");
		try {
			List<S2IFVBenchmarkRepositoryEntity> listBenchmarkRepositoryEntities = benchmarkRepository
					.findByIfvId(ifvId);
			return (listBenchmarkRepositoryEntities != null && !listBenchmarkRepositoryEntities.isEmpty())
					? listBenchmarkRepositoryEntities.stream()
							.map(benchmarkRepositoryEntity -> modelMapper.map(benchmarkRepositoryEntity,
									BenchmarkRepositoryDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVBenchmarkRepositoryEntities based on IfvId. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVBenchmarkRepositoryEntities  based on IfvId." + msg + " "
							+ ifvId,
					e);

		}
	}

	@Override
	public List<BenchmarkRepositoryDTO> findAllByBmBanktype(String bmBankType) {
		logger.info("findAllByBmBanktype() started in BenchmarkRepositoryServiceImpl ");
		try {
			List<S2IFVBenchmarkRepositoryEntity> listBenchmarkRepositoryEntities = benchmarkRepository
					.findByBmBanktype(bmBankType);
			return (listBenchmarkRepositoryEntities != null && !listBenchmarkRepositoryEntities.isEmpty())
					? listBenchmarkRepositoryEntities.stream()
							.map(benchmarkRepositoryEntity -> modelMapper.map(benchmarkRepositoryEntity,
									BenchmarkRepositoryDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVBenchmarkRepositoryEntities based on bmBankType. {}",
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVBenchmarkRepositoryEntities  based on bmBankType." + msg
							+ " " + bmBankType,
					e);

		}
	}

	@Override
	public List<BenchmarkRepositoryDTO> findAllByAlCodeAndBmBanktype(Long alCode, String bankType) {
		logger.info("findAllByAlCode() started in BenchmarkRepositoryServiceImpl {} {} ", alCode, bankType);
		try {
			List<S2IFVBenchmarkRepositoryEntity> listBenchmarkRepositoryEntities = benchmarkRepository
					.findByAlCodeAndBmBanktype(alCode, bankType);
			return (listBenchmarkRepositoryEntities != null && !listBenchmarkRepositoryEntities.isEmpty())
					? listBenchmarkRepositoryEntities.stream()
							.map(benchmarkRepositoryEntity -> modelMapper.map(benchmarkRepositoryEntity,
									BenchmarkRepositoryDTO.class))
							.collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while Finding all S2IFVBenchmarkRepositoryEntities based on alCode and bankType. {}",
					msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVBenchmarkRepositoryEntities  based on alCode and bankType."
							+ msg + " " + alCode + " " + bankType + " ",
					e);

		}
	}
}