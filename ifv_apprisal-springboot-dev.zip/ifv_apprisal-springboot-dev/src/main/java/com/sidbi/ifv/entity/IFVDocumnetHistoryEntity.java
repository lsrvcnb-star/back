package com.sidbi.ifv.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "TBL_FWD_HISTORY")
public class IFVDocumnetHistoryEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HST_CODE")
	private Long hstCode;

	@Column(name = "FWD_STATUS_ID")
	private Long fwdStatusID;

	@Column(name = "HST_CURR_OFFICER_CODE")
	private Long hstCurrOfficerCode;

	@Column(name = "HST_STATUS")
	private String gstStatus;

	@Column(name = "HST_COMMENTS")
	private String hstComments;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "IP_ADDRESS")
	private String ipAddress;

}
