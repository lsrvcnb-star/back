package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class AlcoProposalDTO {

	private Long alCode;

	private String alType;

	private String alBackground;

	private String alPresntProposal;

	private String alTenor;

	private BigDecimal al1yr;

	private BigDecimal al3yr;

	private BigDecimal al5yr;

	private String alRecommendation;

	private Date dateOfAction;

	private String alAppNumber;

	private Long ofrCode;

	private String ofrName;

	private String ipAddress;
	
	private String makerName;

	private String status;

}