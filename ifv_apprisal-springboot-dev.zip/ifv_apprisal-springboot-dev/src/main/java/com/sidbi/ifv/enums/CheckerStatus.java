package com.sidbi.ifv.enums;

import java.util.Arrays;

public enum CheckerStatus {
	FORWARD('F', "Forward"), REJECT('R', "Reject"), APPROVE('A', "Approved");

	private final Character statusFlag;

	private final String statusValue;

	CheckerStatus(Character statusFlag, String statusValue) {
		this.statusFlag = statusFlag;
		this.statusValue = statusValue;
	}

	public Character getStatusFlag() {
		return statusFlag;
	}

	public String getStatusValue() {
		return statusValue;
	}

	public static String getStatusByFlag(Character statusFlag) {
		return Arrays.stream(CheckerStatus.values()).filter(e -> e.getStatusFlag().equals(statusFlag)).findFirst()
				.map(CheckerStatus::getStatusValue)
				.orElseThrow(() -> new IllegalArgumentException("No matching status found for flag: " + statusFlag));
	}

}