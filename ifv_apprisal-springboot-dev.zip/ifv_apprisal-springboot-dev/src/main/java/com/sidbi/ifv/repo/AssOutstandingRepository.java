package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVAssOutstandingEntity;

public interface AssOutstandingRepository extends JpaRepository<S2IFVAssOutstandingEntity, Long> {

	List<S2IFVAssOutstandingEntity> findByIfvId(Long ifvId);

	void deleteByIfvId(Long ifvId);

}
