package com.sidbi.ifv.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.AlcoDataDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.services.AlcoDataService;
import com.sidbi.ifv.services.TblIfvModuleFwdService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/alcodata")
public class AlcoDataController {

	private static final Logger logger = LoggerFactory.getLogger(AlcoDataController.class);

	@Autowired
	private AlcoDataService alcoDataService;

	@Autowired
	private TblIfvModuleFwdService tblIfvModuleFwdService;

	@GetMapping("/get/{id}")
	public ResponseEntity<AlcoDataDTO> findById(@PathVariable Long id) {
		logger.info("findById() started AlcoDataController {} ", id);
		AlcoDataDTO masterRepositoryDTO = alcoDataService.findById(id);
		return ResponseEntity.ok(masterRepositoryDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<AlcoDataDTO>> findAll() {
		logger.info("findAll() started AlcoDataController ");
		List<AlcoDataDTO> list = alcoDataService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<AlcoDataDTO> save(@RequestBody AlcoDataDTO masterRepositoryDTO) {
		logger.info("save() started AlcoDataController {} ", masterRepositoryDTO);
		AlcoDataDTO savedAlcoDataDTO = alcoDataService.save(masterRepositoryDTO);
		return ResponseEntity.ok(savedAlcoDataDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<AlcoDataDTO>> saveAll(@RequestBody List<AlcoDataDTO> listAlcoDataDTO) {
		logger.info("saveAll() started in AlcoDataController ");
		List<AlcoDataDTO> savedAlcoDataDTOs = alcoDataService.saveAll(listAlcoDataDTO);
		return ResponseEntity.ok(savedAlcoDataDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<AlcoDataDTO> update(@PathVariable Long id, @RequestBody AlcoDataDTO alcoDataDTO) {
		logger.info("update() started AlcoDataController {} ", alcoDataDTO);
		AlcoDataDTO updatedAlcoDataDTO = alcoDataService.update(id, alcoDataDTO);
		return ResponseEntity.ok(updatedAlcoDataDTO);
	}

	@DeleteMapping("/delete/{name}")
	public ResponseEntity<Void> delete(@PathVariable String name) {
		logger.info("delete() started AlcoDataController {} ", name);
		alcoDataService.delete(name);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<AlcoDataDTO>> getAllS2IFVAlcoDataEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllS2IFVAlcoDataEntityOnIfvId() started in AlcoDataController ");
		List<AlcoDataDTO> alcoDataDTOs = alcoDataService.findAllByIfvId(ifvId);
		return ResponseEntity.ok(alcoDataDTOs);
	}

	@GetMapping("/getAllOnAlCode/{alCode}")
	public ResponseEntity<List<AlcoDataDTO>> getAllS2IFVAlcoDataEntityOnAlCode(@PathVariable Long alCode) {
		logger.info("getAllS2IFVAlcoDataEntityOnAlCode() started in AlcoDataController ");
		List<AlcoDataDTO> alcoDataDTOs = alcoDataService.findAllByAlCode(alCode);
		return ResponseEntity.ok(alcoDataDTOs);
	}

	@GetMapping("/getAllOnAppStatusAndAlCode/{status}")
	public ResponseEntity<List<AlcoDataDTO>> getAllIfvAppsOnStatus(@PathVariable String status) {
		logger.info("getAllOnAppStatusAndAlCode() started in AlcoDataController {} ", status);
		List<TblIfvModuleFwdDTO> tblIfvModuleFwdDTOs = tblIfvModuleFwdService.findAllByAppStatusAndAlCode(status);
		if (tblIfvModuleFwdDTOs.isEmpty()) {
			return ResponseEntity.ok(new ArrayList<>());
		} else {
			List<Long> alCodes = tblIfvModuleFwdDTOs.stream().map(TblIfvModuleFwdDTO::getAlCode)
					.collect(Collectors.toList());
			List<AlcoDataDTO> alcoDataDTOs = alcoDataService.findAllByAlCodeIn(alCodes);
			return ResponseEntity.ok(alcoDataDTOs);
		}
	}
	
	@GetMapping("/getAllOnAppId/{appId}")
	public ResponseEntity<List<AlcoDataDTO>> getAllOnAppId(@PathVariable String appId) {
		logger.info("getAllOnAppId() started in AlcoDataController ");
		List<AlcoDataDTO> alcoDataDTOs = alcoDataService.findAllByDtAppl(appId);
		return ResponseEntity.ok(alcoDataDTOs);
	}
}