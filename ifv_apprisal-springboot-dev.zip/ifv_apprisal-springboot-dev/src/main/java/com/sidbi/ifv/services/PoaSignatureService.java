package com.sidbi.ifv.services;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.sidbi.ifv.dto.PoaSignatureDTO;

public interface PoaSignatureService extends CrudService<PoaSignatureDTO, Long> {

	List<PoaSignatureDTO> findByCifNumber(String cifNumber);
	
	PoaSignatureDTO savePoaSignature(PoaSignatureDTO dto, MultipartFile[] files);

	List<PoaSignatureDTO> getAllGroupByCifnumber();
	
	PoaSignatureDTO updatePoaSignature(PoaSignatureDTO dto, MultipartFile[] files);

}
