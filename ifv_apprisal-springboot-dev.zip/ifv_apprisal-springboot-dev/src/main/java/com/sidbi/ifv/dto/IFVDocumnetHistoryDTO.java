package com.sidbi.ifv.dto;

import java.util.Date;

import lombok.Data;

@Data
public class IFVDocumnetHistoryDTO {
	
	private Long hstCode;
	private Long fwdStatusID;
	private Long hstCurrOfficerCode;
	private String  gstStatus;
	private String hstComments;
	private Date createdDate;
	private String createdBy;
	private String ipAddress;
}
