package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AlcoMinutesDataDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.SanctionMinutesDtlDTO;
import com.sidbi.ifv.entity.AlcoMinutesDataEntity;
import com.sidbi.ifv.entity.AppraisalMinutesDataEntity;
import com.sidbi.ifv.entity.SanctionMinutesDtlEntity;
import com.sidbi.ifv.enums.SanctionStageEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AlcoMinutesDataRepository;
import com.sidbi.ifv.repo.AppraisalMinutesDataRepository;
import com.sidbi.ifv.repo.SanctionMinutesDtlRepository;
import com.sidbi.ifv.services.FileRepositoryService;
import com.sidbi.ifv.services.SanctionMinutesDtlService;
import com.sidbi.ifv.util.CommonUtil;

import jakarta.transaction.Transactional;

@Service
public class SanctionMinutesDtlServiceImpl implements SanctionMinutesDtlService {

	private static final Logger logger = LoggerFactory.getLogger(SanctionMinutesDtlServiceImpl.class);

	@Autowired
	private SanctionMinutesDtlRepository repository;

	@Autowired
	private AppraisalMinutesDataRepository appraisalMinutesDataRepository;

	@Autowired
	private FileRepositoryService fileRepositoryService;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private AlcoMinutesDataRepository alcoMinutesDataRepository;

	@Override
	public SanctionMinutesDtlDTO findById(Long id) {
		logger.info("findById() started in SanctionMinutesDtlServiceImpl for SanctionMinutesDtlEntity {} ", id);
		SanctionMinutesDtlEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("sanctionMinutesDtlEntity", id));
		return mapper.map(entity, SanctionMinutesDtlDTO.class);
	}

	@Override
	public List<SanctionMinutesDtlDTO> findAll() {
		logger.info("findAll() started in SanctionMinutesDtlServiceImpl of SanctionMinutesDtlEntity");
		try {
			List<SanctionMinutesDtlEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, SanctionMinutesDtlDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all SanctionMinutesDtlEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all SanctionMinutesDtlEntities ." + msg + " ", e);
		}
	}

	@Override
	public SanctionMinutesDtlDTO save(SanctionMinutesDtlDTO dto) {
		logger.info("save() started in SanctionMinutesDtlServiceImpl for SanctionMinutesDtlEntity {} ", dto);
		try {
			SanctionMinutesDtlEntity entity = mapper.map(dto, SanctionMinutesDtlEntity.class);
			repository.save(entity);
			return mapper.map(entity, SanctionMinutesDtlDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating SanctionMinutesDtlEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  SanctionMinutesDtlEntity." + msg + " ",
					e);
		}
	}

	@Override
	public List<SanctionMinutesDtlDTO> saveAll(List<SanctionMinutesDtlDTO> dtos) {
		logger.info("saveAll() started in SanctionMinutesDtlServiceImpl for List of SanctionMinutesDtlEntity");
		try {

			List<SanctionMinutesDtlEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, SanctionMinutesDtlEntity.class)).collect(Collectors.toList());
			List<SanctionMinutesDtlEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, SanctionMinutesDtlDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all SanctionMinutesDtlEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all SanctionMinutesDtlEntities." + msg + " ", e);
		}
	}

	@Override
	public SanctionMinutesDtlDTO update(Long id, SanctionMinutesDtlDTO dto) {
		logger.info("update() started in SanctionMinutesDtlServiceImpl for SanctionMinutesDtlEntity {} {} ", id, dto);
		try {
			SanctionMinutesDtlEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("SanctionMinutesDtlEntity", id));
			BeanUtils.copyProperties(dto, existingEntity, commonUtil.getNullPropertyNames(dto));
			repository.save(existingEntity);
			return mapper.map(existingEntity, SanctionMinutesDtlDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating SanctionMinutesDtlEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating SanctionMinutesDtlEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public void delete(Long id) {
		logger.info("delete() started in SanctionMinutesDtlServiceImpl for SanctionMinutesDtlEntity {}", id);
		try {

			SanctionMinutesDtlEntity existingEntity = repository.findBySancDtlCode(id);

			FileRepositoryDTO fileRepositoryEntity = fileRepositoryService.findBySancMinDetailId(id);
			if (fileRepositoryEntity != null && fileRepositoryEntity.getFileCode() != null) {
				fileRepositoryService.delete(id);
			}

			List<AppraisalMinutesDataEntity> minutesDataEntities = appraisalMinutesDataRepository.findBySancDtlCode(id);
			minutesDataEntities.forEach(e -> appraisalMinutesDataRepository.delete(e));

			repository.delete(existingEntity);

		} catch (Exception e) {
			throw new DatabaseOperationException("Error occurred while deleting SanctionMinutesDtlEntity with id " + id,
					e);
		}

	}

	@Override
	public List<SanctionMinutesDtlDTO> findBySanctStatusCode(Long sancStatusCode, CommonDTO commonDTO) {
		logger.info("findBySanctStatusCode() started in SanctionMinutesDtlServiceImpl ");
		try {
			List<SanctionMinutesDtlEntity> dtlEntities = repository.findBySanctStatusCode(sancStatusCode);
			if (!dtlEntities.isEmpty()) {
				setFileRepo(commonDTO, dtlEntities);
				return dtlEntities.stream().sorted(Comparator.comparing(SanctionMinutesDtlEntity::getSancDtlCode))
						.map(e -> mapper.map(e, SanctionMinutesDtlDTO.class)).collect(Collectors.toList());
			} else {
				return new ArrayList<>();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all SanctionMinutesDtlEntity based on sancStatusCode. {} {} ",
					sancStatusCode, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all SanctionMinutesDtlEntity  based on sancStatusCode." + msg + " ",
					e);

		}
	}

	private void setFileRepo(CommonDTO commonDTO, List<SanctionMinutesDtlEntity> dtlEntities) {
		try {
			List<Long> ids = dtlEntities.stream().map(SanctionMinutesDtlEntity::getSancDtlCode)
					.collect(Collectors.toList());
			List<FileRepositoryDTO> fileRepositoryDTOs = fileRepositoryService.findAllBySancMinDetailIdIn(ids);
			if (!fileRepositoryDTOs.isEmpty()) {
				commonDTO.setFileRepositoryDTOs(fileRepositoryDTOs);
			}
		} catch (Exception e) {
			logger.error("Error occurred while getting file details based on  SanctionMinutesDtlEntity ids");
		}
	}

	@Override
	public Long circulateAgenda(Long sancMinDtlId) {
		logger.info("circulateAgenda() started in SanctionMinutesDtlServiceImpl for sancMinId {} ", sancMinDtlId);
		try {
			SanctionMinutesDtlEntity entity = repository.findById(sancMinDtlId)
					.orElseThrow(() -> new EntityNotFoundException("sanctionMinutesDtlEntity", sancMinDtlId));
			entity.setSancStatus(SanctionStageEnum.CIRC_AGNDA.getStatus());
			repository.save(entity);

			return sancMinDtlId;

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while circulateAgenda sanctionMinutesDtlEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while circulateAgenda sanctionMinutesDtlEntity of id ."
					+ sancMinDtlId + " " + msg + " ", e);
		}

	}

	@Override
	public Boolean saveAllAlcoMinutesData(List<AlcoMinutesDataDTO> data) {
		logger.info(
				"saveAllAlcoMinutesData() started in SanctionMinutesDtlServiceImpl for List of AlcoMinutesDataEntityD");
		try {

			List<AlcoMinutesDataEntity> entitiesToSave = data.stream()
					.map(dto -> mapper.map(dto, AlcoMinutesDataEntity.class)).collect(Collectors.toList());
			Long sancDtlCode = data.stream().map(AlcoMinutesDataDTO::getSancDtlCode).findFirst().orElse(null);
			entitiesToSave.forEach(e -> {
				e.setStatus(SanctionStageEnum.CR_MIN.getStatus());
				e.setCreatedDate(new Date());
			});
			alcoMinutesDataRepository.saveAll(entitiesToSave);
			if (sancDtlCode != null) {
				Optional<SanctionMinutesDtlEntity> existingEntity = repository.findById(sancDtlCode);
				if (existingEntity.isPresent()) {
					SanctionMinutesDtlEntity entity = existingEntity.get();
					entity.setSancStatus(SanctionStageEnum.CR_MIN.getStatus());
					repository.save(entity);
				}
			}

			return true;

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all AlcoMinutesDataEntityD. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all AlcoMinutesDataEntityD." + msg + " ",
					e);
		}
	}

	@Override
	public List<AlcoMinutesDataDTO> getAllAlcoMinutesDataBySancDtlCode(Long sancDtlCode) {
		logger.info("getAllAlcoMinutesDataBySancDtlCode() started in SanctionMinutesDtlServiceImpl ");
		try {
			List<AlcoMinutesDataEntity> dtlEntities = alcoMinutesDataRepository.findBySancDtlCode(sancDtlCode);
			if (!dtlEntities.isEmpty()) {

				return dtlEntities.stream().sorted(Comparator.comparing(AlcoMinutesDataEntity::getId))
						.map(e -> mapper.map(e, AlcoMinutesDataDTO.class)).collect(Collectors.toList());
			} else {
				return new ArrayList<>();
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all AlcoMinutesDataEntity based on sancDtlCode. {} {} ",
					sancDtlCode, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all AlcoMinutesDataEntity  based on sancStatusCode." + msg + " ", e);

		}
	}
}