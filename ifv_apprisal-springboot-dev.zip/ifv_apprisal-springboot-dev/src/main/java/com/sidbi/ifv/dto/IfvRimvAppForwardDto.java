package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class IfvRimvAppForwardDto {
	private Long ifvRimvAppId;
	private String fwdComments;
	private Long fwdUserId;
	private String fwdBy;
}