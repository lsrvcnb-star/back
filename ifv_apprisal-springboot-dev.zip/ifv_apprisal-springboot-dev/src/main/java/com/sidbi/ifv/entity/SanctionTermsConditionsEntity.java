package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_SANCTION_TERMS_CONDITIONS")
public class SanctionTermsConditionsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "PR_ID")
	private Long prId;

	@Column(name = "FUND_CODE")
	private String fundCode;

	@Column(name = "FUND_NAME")
	private String fundName;

	@Column(name = "SCHEME_CODE")
	private String schemeCode;

	@Column(name = "SCHEME_NAME")
	private String schemeName;

	@Column(name = "amount_in_words")
	private String amountInWords;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "TS_RATEINTEREST")
	private BigDecimal tsRAteInterest;

	@Column(name = "TS_TENURE_PERIOD")
	private BigDecimal tsTenurePeriod;

	@Column(name = "TS_ROI_REPAYMENT")
	private String tsRoiRepayment;

	@Column(name = "TS_PRINCIPAL_REPAYMENT")
	private String tsPrincipalRepayment;

	@Column(name = "TS_INTEREST_PAYMENT")
	private String tsIntrestPayment;

	@Column(name = "TS_TENURE_WD")
	private String tsTenureWd;

	@Column(name = "TS_EXTENT")
	private String tsExtent;

	@Column(name = "TS_ELIGIBLEMSE")
	private String tsEligibleMse;

	@Column(name = "TS_ELIGIBLEACTIVITIES")
	private String tsEligibleActivities;

	@Column(name = "TS_EVENTDFLT")
	private String tsEventDflt;

	@Column(name = "TS_SECURITY")
	private String tsSecurity;

	@Column(name = "TS_DOCUMENTSTION")
	private String tsDocumentstion;

	@Column(name = "TS_TIMEFRAME")
	private String tsTimeFrame;

	@Column(name = "TS_DRAWALLOAN")
	private String tsDrawalloan;

	@Column(name = "TS_OTHERCOND")
	private String tsOtherCond;

	@Column(name = "TS_OUTSTANDINGAMOUNT")
	private String tsOutstandingAmount;

	@Column(name = "TS_DRAWALOAN")
	private String tsDrawaloan;

	@Column(name = "TS_TERMSECTION")
	private String tsTermsection;

	@Column(name = "ts_extra_conditions")
	private String tsExtraConditions;

	@Column(name = "ts_tenure_approx")
	private String tsTenureApprox;

	@Column(name = "interest_type")
	private String interestType;

	@Column(name = "benchmark")
	private String benchMark;

	@Column(name = "spread")
	private String spread;

	@Column(name = "interest_reset")
	private String interestReset;

	@Column(name = "bench_mark_note")
	private String benchMarkNote;

	@Column(name = "interest_reset_note")
	private String interestResetNote;

}
