package com.sidbi.ifv.repo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sidbi.ifv.entity.IfvBankRefinanceApplication;

public interface IfvBankRefinanceApplicationRepository extends JpaRepository<IfvBankRefinanceApplication, Long>,
		JpaSpecificationExecutor<IfvBankRefinanceApplication> {

	boolean existsByAppRefId(String appRefId);

	Optional<IfvBankRefinanceApplication> findByAppRefId(String appRefId);

	@Modifying
	@Query("""
			UPDATE IfvBankRefinanceApplication a
			   SET a.applicationStatus = :status,
			       a.returnRemarks = :returnRemarks,
			       a.returnBy = :returnBy,
			       a.returnDateTime = :returnDateTime
			 WHERE a.appRefId = :appRefId
			""")
	int updateReturnedApplication(@Param("appRefId") String appRefId, @Param("status") String status,
			@Param("returnRemarks") String returnRemarks, @Param("returnBy") String returnBy,
			@Param("returnDateTime") LocalDateTime returnDateTime);

	@Modifying
	@Query("""
			UPDATE IfvBankRefinanceApplication a
			   SET a.applicationStatus = :status
			 WHERE a.appRefId = :appRefId
			""")
	int updateApplicationStatus(@Param("appRefId") String appRefId, @Param("status") String status);

	List<IfvBankRefinanceApplication> findByAppRefIdIn(List<String> appRefIds);

	@Modifying
	@Query("""
			UPDATE IfvBankRefinanceApplication a
			   SET a.applicationStatus = :status
			 WHERE a.appRefId IN :appRefIds
			""")
	int updateApplicationStatusForAppRefIds(@Param("appRefIds") List<String> appRefIds, @Param("status") String status);
}
