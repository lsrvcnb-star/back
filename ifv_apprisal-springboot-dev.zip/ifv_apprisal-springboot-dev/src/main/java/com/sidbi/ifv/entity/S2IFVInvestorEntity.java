package com.sidbi.ifv.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_INVESTOR")
public class S2IFVInvestorEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "KI_ID")
	private Long kiId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "KI_HOLDER")
	private String kiHolder;

	@Column(name = "KI_COUNT")
	private BigDecimal kiCount;

	@Column(name = "KI_HOLDING")
	private BigDecimal kiHolding;

	@Column(name = "KI_PROPORTION")
	private BigDecimal kiPproportion;

	@Column(name = "KI_TYPE")
	private String kiType;

}
