package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AlcoMinutesDataDTO;

public interface AlcoMinutesDataService extends CrudService<AlcoMinutesDataDTO, Long> {

	List<AlcoMinutesDataDTO> getAllAlcoMinutesDataByAgendaIdAndAppId(String agendaId, String appId);

}
