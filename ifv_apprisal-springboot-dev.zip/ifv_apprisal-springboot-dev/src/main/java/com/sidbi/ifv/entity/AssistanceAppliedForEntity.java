package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "assistance_applied_for")
public class AssistanceAppliedForEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "pr_id")
	private Long prId;

	@Column(name = "scheme_name")
	private String schemeName;

	@Column(name = "scheme_code")
	private String schemeCode;

	@Column(name = "fund_name")
	private String fundName;

	@Column(name = "fund_code")
	private String fundCode;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "vide_date")
	private Date videDate;
}
