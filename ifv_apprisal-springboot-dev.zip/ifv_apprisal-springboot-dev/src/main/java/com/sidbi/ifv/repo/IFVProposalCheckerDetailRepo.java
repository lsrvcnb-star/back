package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.IFVProposalCheckerDetail;

public interface IFVProposalCheckerDetailRepo extends JpaRepository<IFVProposalCheckerDetail, Long> {

	List<IFVProposalCheckerDetail> findAllByIfvIdOrderByIdAsc(Long ifvId);

	IFVProposalCheckerDetail findTop1ByIfvIdOrderByIdDesc(Long ifvId);

}
