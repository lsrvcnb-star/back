package com.sidbi.ifv.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sidbi.ifv.entity.BeneficiaryUser;

@Repository
public interface BeneficiaryUserRepository extends JpaRepository<BeneficiaryUser, Integer> {

	Optional<BeneficiaryUser> findByUserId(String userId);

	boolean existsByUserId(String userId);
}
