package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.services.CrudService;
import com.sidbi.ifv.services.IfvApiUsersService;
import com.sidbi.ifv.util.CommonUtil;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin
@RequestMapping("/api/users")
public class IfvApiUsersController extends CrudController<IfvApiUsersDTO, Integer> {

	private static final Logger logger = LoggerFactory.getLogger(IfvApiUsersController.class);

	@Autowired
	private IfvApiUsersService service;

	@Override
	public CrudService<IfvApiUsersDTO, Integer> getCrudService() {
		return service;
	}

	@PostMapping("/saveUser")
	public ResponseEntity<IfvApiUsersDTO> saveUser(@RequestBody IfvApiUsersDTO apiUsersDTO,
			HttpServletRequest request) {
		logger.info("save() started IfvApiUsersController {} ", apiUsersDTO);
		String ipAddress = CommonUtil.getClientIpAddress(request);
		logger.info("ipAddress save() in IfvApiUsersController {} ", ipAddress);
		apiUsersDTO.setIpAddress(ipAddress);
		IfvApiUsersDTO dto = service.save(apiUsersDTO);
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/findAllByOfrType/{ofrType}")
	public ResponseEntity<List<IfvApiUsersDTO>> findAllByOfrType(@PathVariable String ofrType) {
		logger.info("findAllByOfrType() started IfvApiUsersController {} ", ofrType);
		List<IfvApiUsersDTO> dto = service.findAllByOfrType(ofrType);
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/getCheckerListForForwarding/{ifvId}/{ofrCode}")
	public ResponseEntity<List<IfvApiUsersDTO>> getCheckerListForForwarding(@PathVariable Long ifvId,
			@PathVariable Long ofrCode) {
		logger.info("getCheckerListForForwarding() started IfvApiUsersController {} ", ifvId);
		List<IfvApiUsersDTO> list = service.getCheckerListForForwarding(ifvId, ofrCode);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/getCheckerListForSendBack/{ifvId}/{ofrCode}")
	public ResponseEntity<List<IfvApiUsersDTO>> getCheckerListForSendBack(@PathVariable Long ifvId,
			@PathVariable Long ofrCode) {
		logger.info("getCheckerListForSendBack() started IfvApiUsersController {} ", ifvId);
		List<IfvApiUsersDTO> list = service.getCheckerListForSendBack(ifvId, ofrCode);
		return ResponseEntity.ok(list);
	}

	@GetMapping("/findAllCheckers")
	public ResponseEntity<List<IfvApiUsersDTO>> findAllCheckers() {
		logger.info("findAllCheckers() started in IfvApiUsersController");
		List<IfvApiUsersDTO> dto = service.findAllCheckers();
		return ResponseEntity.ok(dto);
	}
}