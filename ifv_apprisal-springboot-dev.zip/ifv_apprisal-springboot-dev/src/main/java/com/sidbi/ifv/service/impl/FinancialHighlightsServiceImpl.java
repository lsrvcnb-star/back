package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.FinancialHighlightsDTO;
import com.sidbi.ifv.entity.S2IFVFinancialHighlightsEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.FinancialHighlightsRepository;
import com.sidbi.ifv.services.FinancialHighlightsService;

@Service
public class FinancialHighlightsServiceImpl implements FinancialHighlightsService {

	private static final Logger logger = LoggerFactory.getLogger(FinancialHighlightsServiceImpl.class);

	@Autowired
	private FinancialHighlightsRepository financialHighlightsRepo;

	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<FinancialHighlightsDTO> findAll() {
		logger.info("findAll() started in FinancialHighlightsServiceImpl for S2IFVFinancialHighlightsEntity");
		try {
			List<S2IFVFinancialHighlightsEntity> list = financialHighlightsRepo.findAll();
			return list.stream().map(financialHigh -> modelMapper.map(financialHigh, FinancialHighlightsDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(" Error Occurred while fetching all S2IFVFinancialHighlightsEntities.{} ", msg);
			throw new DatabaseOperationException(
					" Error Occurred while fetching all S2IFVFinancialHighlightsEntities." + msg + " ", e);
		}
	}

	@Override
	public FinancialHighlightsDTO findById(Long id) {
		logger.info("findById() started in FinancialHighlightsServiceImpl for S2IFVFinancialHighlightsEntity {} ", id);
		try {

			S2IFVFinancialHighlightsEntity financialHighlights = financialHighlightsRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("s2IFVFinancialHighlightsEntity", id));
			return modelMapper.map(financialHighlights, FinancialHighlightsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVFinancialHighlightsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVFinancialHighlightsEntity." + msg + " ", e);
		}
	}

	@Override
	public FinancialHighlightsDTO save(FinancialHighlightsDTO financialHighlightsDTO) {
		logger.info(
				"createNewAppraisal() started in FinancialHighlightsServiceImpl for S2IFVFinancialHighlightsEntity {} ",
				financialHighlightsDTO);
		try {
			S2IFVFinancialHighlightsEntity financialHighlights = modelMapper.map(financialHighlightsDTO,
					S2IFVFinancialHighlightsEntity.class);

			financialHighlightsRepo.save(financialHighlights);

			return modelMapper.map(financialHighlights, FinancialHighlightsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVFinancialHighlightsEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVFinancialHighlightsEntities." + msg + " ", e);
		}
	}

	@Override
	public FinancialHighlightsDTO update(Long id, FinancialHighlightsDTO financialHighlightsDTO) {
		logger.info(
				"createNewAppraisal() started in FinancialHighlightsServiceImpl for S2IFVFinancialHighlightsEntity {} {} ",
				id, financialHighlightsDTO);
		try {
			S2IFVFinancialHighlightsEntity financialHighlightsExisting = financialHighlightsRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVFinancialHighlightsEntity", id));
			BeanUtils.copyProperties(financialHighlightsDTO, financialHighlightsExisting);
			financialHighlightsRepo.save(financialHighlightsExisting);
			return modelMapper.map(financialHighlightsExisting, FinancialHighlightsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVFinancialHighlightsEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVFinancialHighlightsEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void deleteAppraisal(Long id) {
		logger.info(
				"deleteAppraisal() started in FinancialHighlightsServiceImpl for S2IFVFinancialHighlightsEntity {} ",
				id);
		try {
			S2IFVFinancialHighlightsEntity financialHighlightsEntity = financialHighlightsRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVFinancialHighlightsEntity", id));
			financialHighlightsRepo.delete(financialHighlightsEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleteing S2IFVFinancialHighlightsEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleteing S2IFVFinancialHighlightsEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public List<FinancialHighlightsDTO> saveAll(List<FinancialHighlightsDTO> listFinancialHighlightsDTO) {
		logger.info("saveAll() started in FinancialHighlightsServiceImpl for List of S2IFVFinancialHighlightsEntity");
		try {

			List<S2IFVFinancialHighlightsEntity> financialHighlightsEntitiesToSave = listFinancialHighlightsDTO.stream()
					.map(eligibilityDTO -> modelMapper.map(eligibilityDTO, S2IFVFinancialHighlightsEntity.class))
					.collect(Collectors.toList());
			List<S2IFVFinancialHighlightsEntity> savedFinancialHighlightsEntities = financialHighlightsRepo
					.saveAll(financialHighlightsEntitiesToSave);

			return savedFinancialHighlightsEntities.stream().map(financialHighlightsEntity -> modelMapper
					.map(financialHighlightsEntity, FinancialHighlightsDTO.class)).collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVFinancialHighlightsEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVFinancialHighlightsEntities." + msg + " ", e);
		}
	}

	@Override
	public List<FinancialHighlightsDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in FinancialHighlightsServiceImpl ");
		try {
			List<S2IFVFinancialHighlightsEntity> listFinancialHighlightsEntities = financialHighlightsRepo
					.findByIfvId(ifvId);
			return listFinancialHighlightsEntities.stream().map(financialHighlightsEntity -> modelMapper
					.map(financialHighlightsEntity, FinancialHighlightsDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVFinancialHighlightsEntities based on IfvId. {} {} ",
					ifvId, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVFinancialHighlightsEntities  based on IfvId." + msg + " ",
					e);

		}
	}

	@Override
	public String getDisclosureStatus(Long ifvId) {
		logger.info("getDisclosureStatus() started in FinancialHighlightsServiceImpl ");
		try {
			List<S2IFVFinancialHighlightsEntity> listFinancialHighlightsEntities = financialHighlightsRepo
					.findByIfvId(ifvId);

			return listFinancialHighlightsEntities.stream()
					.filter(e -> e.getRestructuredAssetFlag() != null && !e.getRestructuredAssetFlag().isBlank())
					.map(S2IFVFinancialHighlightsEntity::getRestructuredAssetFlag).findFirst().orElse("");
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error(
					"Error Occurred while getDisclosureStatus S2IFVFinancialHighlightsEntities based on IfvId. {} {} ",
					ifvId, msg);
			throw new DatabaseOperationException(
					"Error Occurred while getDisclosureStatus S2IFVFinancialHighlightsEntities based on IfvId." + msg
							+ " ",
					e);
		}
	}

}