package com.sidbi.ifv.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.client.BankPortalClient;
import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.CreateProposalRequest;
import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.IfvAppReportDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.model.ApplicationSummaryModel;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.FileRepositoryService;
import com.sidbi.ifv.services.ProposedSchemaService;
import com.sidbi.ifv.services.TblIfvModuleFwdService;
import com.sidbi.ifv.util.CommonUtil;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifcapp")
public class ApplicationController {

	private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private TblIfvModuleFwdService tblIfvModuleFwdService;

	@Autowired
	private FileRepositoryService fileRepositoryService;

	@Autowired
	private ProposedSchemaService proposedSchemaService;

	@Value("${pdf.folder.path}")
	private String pdfFolderPath;

	@Autowired
	private EmailService emailService;

	@Autowired
	private BankPortalClient bankPortalClient;

	@GetMapping("/get/{id}")
	public ResponseEntity<ApplicationDTO> findById(@PathVariable Long id) {
		logger.info("findById() started ApplicationController {} ", id);
		ApplicationDTO s2ifccApplicationDTO = applicationService.findById(id);
		return ResponseEntity.ok(s2ifccApplicationDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<ApplicationDTO>> findAll() {
		logger.info("findAll() started ApplicationController ");
		List<ApplicationDTO> list = applicationService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<ApplicationDTO> save(@RequestBody ApplicationDTO applicationDTO, HttpServletRequest request) {

		logger.info("save() started ApplicationController {} ", applicationDTO);

		String ipAddress = CommonUtil.getClientIpAddress(request);

		logger.info("ipAddress save() in ApplicationController {} ", ipAddress);

		applicationDTO.setIpAddress(ipAddress);

		ApplicationDTO createdApplication = applicationService.save(applicationDTO);

		if (!CollectionUtils.isEmpty(createdApplication.getBankAppRefNos())) {

			try {

				bankPortalClient.updateAppStatusToInProgress(applicationDTO.getBankAppRefNos());

			} catch (Exception ex) {

				logger.error("Failed to update Bank Portal application status to IN_PROGRESS for appRefIds : {}",
						applicationDTO.getBankAppRefNos(), ex);
			}
		}

		return ResponseEntity.ok(createdApplication);
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<ApplicationDTO> update(@PathVariable Long id, @RequestBody ApplicationDTO applicationDTO,
			HttpServletRequest request) {
		logger.info("update() started ApplicationController {} ", applicationDTO);
		String ipAddress = CommonUtil.getClientIpAddress(request);
		logger.info("ipAddress update() in ApplicationController {} ", ipAddress);
		applicationDTO.setIpAddress(ipAddress);
		ApplicationDTO updatedApplication = applicationService.update(id, applicationDTO);
		return ResponseEntity.ok(updatedApplication);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started ApplicationController {} ", id);
		applicationService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@PostMapping("/lockDocument")
	public ResponseEntity<TblIfvModuleFwdDTO> lockDocument(@RequestBody ApplicationDTO applicationDTO) {
		logger.info("documentForward started ApplicationController {} ", applicationDTO.getIfvId());
		TblIfvModuleFwdDTO ifvModuleFwdDTO = applicationService.lockDocument(applicationDTO);
		return ResponseEntity.ok(ifvModuleFwdDTO);
	}

	@GetMapping("/validateapp/{ifvId}")
	public ResponseEntity<Boolean> checkIfvIdInChildTables(@PathVariable Long ifvId) {
		logger.info("checkIfvIdInChildTables() started ApplicationController {} ", ifvId);
		return ResponseEntity.ok(applicationService.checkIfvIdExistsInChildTables(ifvId));
	}

	@GetMapping("/getAllOnUserType/{userType}/{userCode}")
	public ResponseEntity<List<ApplicationDTO>> getAllOnUserType(@PathVariable String userType,
			@PathVariable Long userCode) {
		logger.info("getAllOnUserType() started ApplicationController {} ", userType);
		List<ApplicationDTO> list = applicationService.getAllOnUserType(userType, userCode);
		return ResponseEntity.ok(list);
	}

	@PostMapping("/unlockDocument")
	public ResponseEntity<TblIfvModuleFwdDTO> unlockDocument(@RequestBody ApplicationDTO applicationDTO) {
		logger.info("unlockDocument started ApplicationController {} ", applicationDTO.getIfvId());
		TblIfvModuleFwdDTO ifvModuleFwdDTO = applicationService.unlockDocument(applicationDTO);
		return ResponseEntity.ok(ifvModuleFwdDTO);
	}

	@PostMapping("/confirmDocument")
	public ResponseEntity<TblIfvModuleFwdDTO> confirmDocument(@RequestBody ApplicationDTO applicationDTO) {
		logger.info("confirmDocument started ApplicationController {} ", applicationDTO.getIfvId());
		TblIfvModuleFwdDTO ifvModuleFwdDTO = applicationService.confirmDocument(applicationDTO);
		return ResponseEntity.ok(ifvModuleFwdDTO);
	}

	@PostMapping("/approveDocument")
	public ResponseEntity<TblIfvModuleFwdDTO> approveDocument(@RequestBody ApplicationDTO applicationDTO) {
		logger.info("approveDocument started ApplicationController {} ", applicationDTO.getIfvId());
		TblIfvModuleFwdDTO ifvModuleFwdDTO = applicationService.approveDocument(applicationDTO);
		applicationService.sendEmail(applicationDTO.getIfvId());
		return ResponseEntity.ok(ifvModuleFwdDTO);
	}

	@GetMapping("/getAllBanks")
	public ResponseEntity<Map<Long, String>> getAllBanks() {
		logger.info("findAll() started ApplicationController ");
		List<ApplicationDTO> list = applicationService.findAll();
		Map<Long, String> m = list.stream()
				.collect(Collectors.toMap(ApplicationDTO::getIfvId, ApplicationDTO::getIfvName));
		return ResponseEntity.ok(m);
	}

	@GetMapping("/getAllIfvAppsOnStatus/{status}")
	public ResponseEntity<List<ApplicationDTO>> getAllByAppStatusAndIfvId(@PathVariable String status) {
		logger.info("getAllByAppStatusAndIfvId() started in ApplicationController {} ", status);
		List<TblIfvModuleFwdDTO> tblIfvModuleFwdDTOs = tblIfvModuleFwdService.findAllByAppStatusAndIfvId(status);
		if (tblIfvModuleFwdDTOs.isEmpty()) {
			return ResponseEntity.ok(new ArrayList<>());
		} else {
			List<Long> ifvIds = tblIfvModuleFwdDTOs.stream().map(TblIfvModuleFwdDTO::getIfvId)
					.collect(Collectors.toList());
			List<ApplicationDTO> applicationDTOs = applicationService.findAllByIfvIdIn(ifvIds);
			applicationDTOs = applicationDTOs.stream().sorted(Comparator.comparing(ApplicationDTO::getIfvId).reversed())
					.collect(Collectors.toList());
			return ResponseEntity.ok(applicationDTOs);
		}
	}

	@GetMapping("/getIfvAppsReportData")
	public ResponseEntity<List<IfvAppReportDTO>> getIfvAppsReportData() {
		logger.info("getIfvAppsReportData() started ApplicationController ");
		List<IfvAppReportDTO> list = applicationService.getIfvAppsReportData();
		return ResponseEntity.ok(list);
	}

	@GetMapping("/downloadusermanual/{module}")
	public ResponseEntity<FileRepositoryDTO> downloadUserManual(@PathVariable String module) {
		logger.info("downloadUserManual() started ApplicationController ");
		FileRepositoryDTO dto = fileRepositoryService.findByFileModule(module);
		return ResponseEntity.ok(dto);
	}

	@PostMapping("/revertApprovedDocument")
	public ResponseEntity<TblIfvModuleFwdDTO> revertApprovedDocument(@RequestBody ApplicationDTO applicationDTO) {
		logger.info("revertApprovedDocument started ApplicationController {} ", applicationDTO.getIfvId());
		TblIfvModuleFwdDTO ifvModuleFwdDTO = applicationService.revertApprovedDocument(applicationDTO);
		return ResponseEntity.ok(ifvModuleFwdDTO);
	}

	@GetMapping("/findBankDetailsByAppNumber/{appNo}")
	public ResponseEntity<Object> findBankDetailsByAppNumber(@PathVariable String appNo) {
		logger.info("Started findBankDetailsByAppNumber() in ApplicationController");
		Object bank = applicationService.findBankDetailsByAppNumber(appNo);
		return ResponseEntity.ok(bank);
	}

	@GetMapping("/getByCifNumber/{cifNo}")
	public ResponseEntity<ApplicationDTO> findById(@PathVariable String cifNo) {
		logger.info("getByCifNumber() started ApplicationController {} ", cifNo);
		ApplicationDTO s2ifccApplicationDTO = applicationService.findByCifNumber(cifNo);
		return ResponseEntity.ok(s2ifccApplicationDTO);
	}

	@GetMapping("/getApplicationOnPage")
	public ResponseEntity<Page<ApplicationDTO>> getApplicationOnPage(@RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting) {
		logger.info("getApplicationOnPage() started ApplicationController {} ", start);
		int page = start / size;
		return ResponseEntity.ok(applicationService.getApplicationOnPage(page, size, filters, sorting));
	}

	@GetMapping("/getAllOnUserTypeOnPage/{userType}/{userCode}")
	public ResponseEntity<Page<ApplicationSummaryModel>> getAllOnUserTypeOnPage(@PathVariable String userType,
			@PathVariable Long userCode, @RequestParam(defaultValue = "0") int start,
			@RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String filters,
			@RequestParam(required = false) String sorting, @RequestParam(required = false) String globalFilter,
			@RequestParam(required = false) String status) {

		logger.info("getAllOnUserTypeOnPage() started ApplicationController {} ", userType);

		int page = start / size;
		return ResponseEntity.ok(applicationService.getAllOnUserTypeOnPage(userType, userCode, page, size, filters,
				sorting, globalFilter, status));
	}

	@GetMapping("/getAddressByCifNumber/{appNo}")
	public ResponseEntity<String> getAddressByCifNumber(@PathVariable String appNo) {
		logger.info("Started getAddressByCifNumber() in ApplicationController");
		String bank = applicationService.getAddressByCifNumber(appNo);
		return ResponseEntity.ok(bank);
	}

	@GetMapping("/getDetailsOfEmptyData/{ifvNo}")
	public ResponseEntity<String> getDetailsOfEmptyData(@PathVariable Long ifvNo) {
		logger.info("Started getDetailsOfEmptyData() in ApplicationController");
		String data = applicationService.getDetailsOfEmptyData(ifvNo);
		return ResponseEntity.ok(data);
	}

	@GetMapping("/status-counts/{userType}/{userCode}")
	public ResponseEntity<Map<String, Long>> getStatusCounts(@PathVariable String userType,
			@PathVariable Long userCode) {
		logger.info("getStatusCounts() started ApplicationController");
		return ResponseEntity.ok(applicationService.getStatusCounts(userType, userCode));
	}

	@DeleteMapping("/deleteAssistanceApplied/{id}")
	public ResponseEntity<Void> deleteAssistanceApplied(@PathVariable Long id) {
		logger.info("deleteAssistanceApplied() started ApplicationController {} ", id);
		proposedSchemaService.deleteAssistanceById(id);
		return ResponseEntity.noContent().build();
	}

	@DeleteMapping("/deleteAggregateExposure/{id}")
	public ResponseEntity<Void> deleteAggregateExposure(@PathVariable Long id) {
		logger.info("deleteAggregateExposure() started ApplicationController {} ", id);
		proposedSchemaService.deleteAggregateExposure(id);
		return ResponseEntity.noContent().build();
	}

	@PostMapping("/loadProposalData")
	public ResponseEntity<ApplicationDTO> loadProposalData(@RequestBody CreateProposalRequest request) {
		logger.info("loadProposalData() started ApplicationController");
		return ResponseEntity.ok(applicationService.loadProposalData(request));
	}
}