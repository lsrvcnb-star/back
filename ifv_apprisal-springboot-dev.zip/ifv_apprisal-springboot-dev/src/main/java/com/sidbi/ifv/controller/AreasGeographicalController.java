package com.sidbi.ifv.controller;

import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.AreasGeographicalDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.AreasGeographicalService;

@RestController
@RequestMapping("/ifv/geographical-area")
@CrossOrigin
public class AreasGeographicalController {

	private static final Logger logger = LoggerFactory.getLogger(AreasGeographicalController.class);

	@Autowired
	private AreasGeographicalService s2ifccAreaOfGeographicalService;

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/get/{id}")
	public ResponseEntity<AreasGeographicalDTO> findById(@PathVariable Long id) {
		logger.info("findById() started AreasGeographicalController {} ", id);
		AreasGeographicalDTO s2ifccApplicationDTO = s2ifccAreaOfGeographicalService.findById(id);
		return ResponseEntity.ok(s2ifccApplicationDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<AreasGeographicalDTO>> findAll() {
		logger.info("findAll() started AreasGeographicalController ");
		List<AreasGeographicalDTO> list = s2ifccAreaOfGeographicalService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<AreasGeographicalDTO> save(@RequestBody AreasGeographicalDTO applicationDTO) {
		logger.info("create() started AreasGeographicalController {} ", applicationDTO);
		AreasGeographicalDTO createdApplication = s2ifccAreaOfGeographicalService.save(applicationDTO);
		return ResponseEntity.ok(createdApplication);
	}

	@PostMapping("/saveCommonDTO")
	public ResponseEntity<CommonDTO> saveCommonDTO(@RequestBody CommonDTO commonDTO) {
		logger.info("saveCommonDTO() started in AreasGeographicalController ");
		CommonDTO savedCommonDTO = s2ifccAreaOfGeographicalService.saveCommonDTO(commonDTO);
		return ResponseEntity.ok(savedCommonDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<AreasGeographicalDTO>> saveAll(
			@RequestBody List<AreasGeographicalDTO> listAreasGeographicalDTO) {
		logger.info("saveAll() started in AreasGeographicalController ");
		List<AreasGeographicalDTO> list = s2ifccAreaOfGeographicalService.saveAll(listAreasGeographicalDTO);
		return ResponseEntity.ok(list);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<AreasGeographicalDTO> update(@PathVariable Long id,
			@RequestBody AreasGeographicalDTO applicationDTO) {
		logger.info("update() started AreasGeographicalController {} ", applicationDTO);
		AreasGeographicalDTO updatedApplication = s2ifccAreaOfGeographicalService.update(id, applicationDTO);
		return ResponseEntity.ok(updatedApplication);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started AreasGeographicalController {} ", id);
		s2ifccAreaOfGeographicalService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<CommonDTO> getAllAreasGeographicalEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllKycEntityOnIfvId() started in AreasGeographicalController ");
		CommonDTO commonDTO = s2ifccAreaOfGeographicalService.findCommonDTOByIfvId(ifvId);
		return ResponseEntity.ok(commonDTO);
	}

	@GetMapping("/getAllOnIfvIdOnST/{ifvId}")
	public ResponseEntity<CommonDTO> getAllAreasGeographicalEntityOnIfvIdOnStAgType(@PathVariable Long ifvId) {
		logger.info("getAllAreasGeographicalEntityOnIfvIdOnStAgType() started in AreasGeographicalController ");

		CommonDTO commonDTO = s2ifccAreaOfGeographicalService.findCommonDTOByIfvIdAndAgType(ifvId, "ST");

		if (commonDTO == null || CollectionUtils.isEmpty(commonDTO.getListAreasGeographicalDTO())) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				CommonDTO commonDTO2 = s2ifccAreaOfGeographicalService
						.findCommonDTOByIfvIdAndAgType(applicationDTO.getIfvId(), "ST");
				if (commonDTO2 != null && !CollectionUtils.isEmpty(commonDTO2.getListAreasGeographicalDTO())) {
					commonDTO2.getListAreasGeographicalDTO().sort(Comparator.comparing(AreasGeographicalDTO::getAgId));
					commonDTO2.getListAreasGeographicalDTO().forEach(dto -> {
						dto.setIfvId(ifvId);
						dto.setAgId(null);
					});
					commonDTO2.getSfbCommondtDTO().setSfbId(null);
					commonDTO2.getSfbCommondtDTO().setIfvId(ifvId);
					return ResponseEntity.ok(commonDTO2);
				}
			}
			return ResponseEntity.ok(new CommonDTO());
		} else {
			return ResponseEntity.ok(commonDTO);
		}
	}

	@GetMapping("/getAllOnIfvIdOnCT/{ifvId}")
	public ResponseEntity<List<AreasGeographicalDTO>> getAllAreasGeographicalEntityOnIfvIdOnCtAgType(
			@PathVariable Long ifvId) {
		logger.info("getAllAreasGeographicalEntityOnIfvIdOnCtAgType() started in AreasGeographicalController ");
		List<AreasGeographicalDTO> areasGeographicalDTOs = s2ifccAreaOfGeographicalService.findByIfvIdAndCtAgType(ifvId,
				"CT");
		return ResponseEntity.ok(areasGeographicalDTOs);
	}

	@DeleteMapping("/deleteGeographicalArea/{id}")
	public ResponseEntity<Void> deleteGeographicalArea(@PathVariable Long id) {
		logger.info("deleteGeographicalArea() started AreasGeographicalController {} ", id);
		s2ifccAreaOfGeographicalService.deleteGeographicalArea(id);
		return ResponseEntity.noContent().build();
	}
}
