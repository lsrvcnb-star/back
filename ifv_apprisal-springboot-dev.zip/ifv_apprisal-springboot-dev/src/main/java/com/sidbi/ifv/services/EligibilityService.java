package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.EligibilityDTO;

public interface EligibilityService {

	List<EligibilityDTO> findAll();

	EligibilityDTO findById(Long id);

	EligibilityDTO save(EligibilityDTO s2ifccEligibilityDTO);

	EligibilityDTO update(Long id, EligibilityDTO s2ifccEligibilityDTO);
	
	void delete(Long id);

	List<EligibilityDTO> saveAll(List<EligibilityDTO> listEligibilityDTO);

	EligibilityDTO findByIfvId(Long ifvId);

	
	
}
