package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_FINANCIALHIGHLIGHTS")
public class S2IFVFinancialHighlightsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FH_ID")
	private Long fhId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "FH_FYMARCH31")
	private BigDecimal fhFyMarch31;

	@Column(name = "FH_FYRESULTS")
	private BigDecimal fhFyResults;

	@Column(name = "FH_PARTICULAR")
	private String fhParticular;

	@Column(name = "FH_FY1")
	private BigDecimal fhFy1;

	@Column(name = "FH_FY2")
	private BigDecimal fhFy2;

	@Column(name = "FH_FY3")
	private BigDecimal fhFy3;

	@Column(name = "FH_YOY")
	private BigDecimal fhYoy;

	@Column(name = "FH_FINPERFORMANCE")
	private String fhFinperformance;

	@Column(name = "FH_LCRDATE")
	private Date fhLcrDate;

	@Column(name = "FH_LCRVALUE")
	private BigDecimal fhLcrValue;

	@Column(name = "FH_ASSESTSPROFILE")
	private String fhAssestProfile;

	@Column(name = "FH_LIABILITIES")
	private String fhLiabilities;

	@Column(name = "FH_PROFITABILITIES")
	private String fhProfitabilities;

	@Column(name = "FH_EQULITY")
	private String fhEqulity;

	@Column(name = "FH_DISCLOSURE")
	private String fhDisclosure;

	@Column(name = "FH_COLLECTION")
	private String fhCollection;

	@Column(name = "FH_EFFICIENCY")
	private BigDecimal fhEfficiency;

	@Column(name = "FH_EFFICIENCYDATE")
	private Date fhEfficiencyDate;

	@Column(name = "FH_STATUTORY")
	private String fhStatutory;

	@Column(name = "FH_STATUS")
	private String fhStatus;

	@Column(name = "CURRENT_YEAR_VALUE")
	private Integer currentYearValue;

	@Column(name = "PREVIOUS_YEAR_VALUE")
	private Integer previousYearValue;

	@Column(name = "MONTHS")
	private String months;

	@Column(name = "fh_highlights")
	private String fhHighlights;

	@Column(name = "financial_performance_year1")
	private String financialPerformanceYear1;

	@Column(name = "financial_performance2")
	private String financialPerformance2;

	@Column(name = "financial_performance_year2")
	private String financialPerformanceYear2;

	@Column(name = "highlights_value")
	private String highlightsValue;

	@Column(name = "highlights_date")
	private Date highlightsDate;

	@Column(name = "rbi_guidelines")
	private String rbiGuidelines;

	@Column(name = "restructured_asset")
	private String restructuredAsset;

	@Column(name = "restructured_asset_flag")
	private String restructuredAssetFlag;

	@Column(name = "fy_ended_audit")
	private String fyEndedAudit;

	@Column(name = "fy_result_audit")
	private String fyResultAudit;
}