package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVSfbAggregateEntity;

public interface SfbAggregateRepository extends JpaRepository<S2IFVSfbAggregateEntity, Long>{

	S2IFVSfbAggregateEntity findByIfvId(Long id);
	
	List<S2IFVSfbAggregateEntity> getByIfvId(Long id);

}
