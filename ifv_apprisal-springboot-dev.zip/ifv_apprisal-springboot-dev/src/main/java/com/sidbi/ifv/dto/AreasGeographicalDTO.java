package com.sidbi.ifv.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class AreasGeographicalDTO {

	private Long agId;

	private Long ifvId;

	private String agState;

	private BigDecimal agBranch;

	private String agType;

	private String rrbStateName;
}
