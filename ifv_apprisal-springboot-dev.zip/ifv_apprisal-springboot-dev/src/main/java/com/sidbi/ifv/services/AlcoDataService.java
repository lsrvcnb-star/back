package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AlcoDataDTO;

public interface AlcoDataService {
	
	List<AlcoDataDTO> findAll();

	AlcoDataDTO findById(Long id);

	AlcoDataDTO save(AlcoDataDTO alcoDataDTO);

	AlcoDataDTO update(Long id, AlcoDataDTO alcoDataDTO);
	
	void delete(String name);

	List<AlcoDataDTO> saveAll(List<AlcoDataDTO> alcoDataDTOs);

	List<AlcoDataDTO> findAllByIfvId(Long ifvId);

	List<AlcoDataDTO> findAllByAlCode(Long alCode);

	List<AlcoDataDTO> findAllByAlCodeIn(List<Long> alCodes);

	List<AlcoDataDTO> findAllByDtAppl(String appId);

}
