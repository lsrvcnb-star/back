package com.sidbi.ifv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReturnBankForwardedDocumentRequest {

	private String benRefNo;

	private String returnRemarks;

	private String returnBy;

}
