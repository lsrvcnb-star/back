package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.IfvBankRefinanceSignatory;

public interface IfvBankRefinanceSignatoryRepository extends JpaRepository<IfvBankRefinanceSignatory, Long> {

	void deleteByApplicationId(Long id);

	List<IfvBankRefinanceSignatory> findAllByApplicationId(Long id);

}
