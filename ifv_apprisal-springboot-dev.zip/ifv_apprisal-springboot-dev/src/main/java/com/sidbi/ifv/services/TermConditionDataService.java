package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.TermConditionsDataDTO;

public interface TermConditionDataService {
	
	TermConditionsDataDTO getTermConditionDataById(Long id);
	
	List<TermConditionsDataDTO> getAllTermConditionData();

	TermConditionsDataDTO save(TermConditionsDataDTO termConditionsDataDTO);

}
