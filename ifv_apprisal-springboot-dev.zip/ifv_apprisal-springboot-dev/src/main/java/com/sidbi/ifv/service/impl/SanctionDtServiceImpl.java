package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.IfvSanctionDetailsDTO;
import com.sidbi.ifv.entity.IfvSanctionDetailsEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.SanctionDtRepository;
import com.sidbi.ifv.services.SanctionDtService;

@Service
public class SanctionDtServiceImpl implements SanctionDtService {

	private static final Logger logger = LoggerFactory.getLogger(SanctionDtServiceImpl.class);

	@Autowired
	private SanctionDtRepository repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public IfvSanctionDetailsDTO findById(Long id) {
		logger.info("findById() started in SanctionDtServiceImpl for SanctionDtEntity {} ", id);
		IfvSanctionDetailsEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("SanctionDtEntity", id));
		return mapper.map(entity, IfvSanctionDetailsDTO.class);
	}

	@Override
	public List<IfvSanctionDetailsDTO> findAll() {
		logger.info("findAll() started in SanctionDtServiceImpl of SanctionDtEntity");
		try {
			List<IfvSanctionDetailsEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, IfvSanctionDetailsDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all SanctionDtEntities .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all SanctionDtEntities ." + msg + " ",
					e);
		}
	}

	@Override
	public IfvSanctionDetailsDTO save(IfvSanctionDetailsDTO dto) {
		logger.info("save() started in SanctionDtServiceImpl for SanctionDtEntity {} ", dto);
		try {
			IfvSanctionDetailsEntity entity = mapper.map(dto, IfvSanctionDetailsEntity.class);
			repository.save(entity);
			return mapper.map(entity, IfvSanctionDetailsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating SanctionDtEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  SanctionDtEntity." + msg + " ", e);
		}
	}

	@Override
	public List<IfvSanctionDetailsDTO> saveAll(List<IfvSanctionDetailsDTO> dtos) {
		logger.info("saveAll() started in SanctionDtServiceImpl for List of SanctionDtEntity");
		try {

			List<IfvSanctionDetailsEntity> entitiesToSave = dtos.stream().map(dto -> mapper.map(dto, IfvSanctionDetailsEntity.class))
					.collect(Collectors.toList());
			List<IfvSanctionDetailsEntity> savedEntities = repository.saveAll(entitiesToSave);
			return savedEntities.stream().map(entity -> mapper.map(entity, IfvSanctionDetailsDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all SanctionDtEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all SanctionDtEntities." + msg + " ", e);
		}
	}

	@Override
	public IfvSanctionDetailsDTO update(Long id, IfvSanctionDetailsDTO dto) {
		logger.info("update() started in SanctionDtServiceImpl for SanctionDtEntity {} {} ", id, dto);
		try {
			IfvSanctionDetailsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("sanctionDtEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, IfvSanctionDetailsDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating SanctionDtEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating SanctionDtEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in SanctionDtServiceImpl for SanctionDtEntity {} ", id);
		try {
			IfvSanctionDetailsEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("sanctionDtEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting SanctionDtEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting SanctionDtEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<IfvSanctionDetailsDTO> findAllByBnlSrNoIn(List<Long> minuteIds) {
		logger.info("findAllByBnlSrNoIn() started in SanctionDtServiceImpl for SanctionDtEntity {} ", minuteIds);
		try {

			List<IfvSanctionDetailsEntity> dtEntities = repository.findAllByBnlSrNoIn(minuteIds);

			return !dtEntities.isEmpty() ? dtEntities.stream()
					.map(entity -> mapper.map(entity, IfvSanctionDetailsDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByBnlSrNoIn SanctionDtEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByBnlSrNoIn SanctionDtEntity of id ." + msg + " " + minuteIds, e);
		}
	}

}
