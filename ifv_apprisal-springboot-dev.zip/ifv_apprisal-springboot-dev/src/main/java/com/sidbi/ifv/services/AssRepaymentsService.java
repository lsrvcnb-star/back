package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.AssRepaymentsDTO;

public interface AssRepaymentsService {
	List<AssRepaymentsDTO> findAll();

	AssRepaymentsDTO findById(Long id);

	AssRepaymentsDTO save(AssRepaymentsDTO s2IFCCAssRepaymentsDTO);

	AssRepaymentsDTO update(Long id, AssRepaymentsDTO s2IFCCAssRepaymentsDTO);

	void delete(Long id);

	List<AssRepaymentsDTO> saveAll(List<AssRepaymentsDTO> listAssRepaymentsDTO);

	List<AssRepaymentsDTO> findAllByIfvId(Long ifvId);

}