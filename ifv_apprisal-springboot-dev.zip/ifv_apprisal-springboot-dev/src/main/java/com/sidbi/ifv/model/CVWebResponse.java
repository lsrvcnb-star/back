package com.sidbi.ifv.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CVWebResponse {
	private boolean success;
	private String sessionId;
	private Integer errorCode;
	private String errorMessage;
	private String responseText;
	private String documentId;
}
