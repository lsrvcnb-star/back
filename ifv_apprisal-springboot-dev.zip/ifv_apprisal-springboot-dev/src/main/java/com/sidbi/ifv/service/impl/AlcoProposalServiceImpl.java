package com.sidbi.ifv.service.impl;

import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AlcoProposalDTO;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.entity.IFVDocumnetHistoryEntity;
import com.sidbi.ifv.entity.S2IFVAlcoProposalEntity;
import com.sidbi.ifv.entity.TblIfvModuleFwdEntity;
import com.sidbi.ifv.enums.AppStatusEnum;
import com.sidbi.ifv.enums.ModuleIdEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AlcoProposalRepository;
import com.sidbi.ifv.repo.IFVDocumnetHistoryRepo;
import com.sidbi.ifv.repo.TblIfvModuleFwdRepository;
import com.sidbi.ifv.services.AlcoProposalService;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.GenericSpecification;
import com.sidbi.ifv.util.SortingUtil;

@Service
public class AlcoProposalServiceImpl implements AlcoProposalService {

	private static final Logger logger = LoggerFactory.getLogger(AlcoProposalServiceImpl.class);

	@Autowired
	private AlcoProposalRepository alcoProposalRepository;

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private TblIfvModuleFwdRepository ifvModuleFwdRepository;

	String msg = "";

	@Autowired
	private IFVDocumnetHistoryRepo docHistoryRepo;

	@Override
	public List<AlcoProposalDTO> findAll() {
		logger.info("findAll() started in AlcoProposalServiceImpl of S2IFVAlcoProposalEntity");
		try {
			List<S2IFVAlcoProposalEntity> list = alcoProposalRepository.findAll();
			return !list.isEmpty() ? list.stream()
					.map(alcoProposalEntity -> modelMapper.map(alcoProposalEntity, AlcoProposalDTO.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAlcoProposalEntities.{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAlcoProposalEntities." + msg + " ", e);
		}
	}

	@Override
	public AlcoProposalDTO findById(Long id) {
		logger.info("findById() started in AlcoProposalServiceImpl for S2IFVAlcoProposalEntity {} ", id);
		S2IFVAlcoProposalEntity s2ifvAlcoProposalEntity = alcoProposalRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("s2IFVAlcoProposalEntity", id));
		return modelMapper.map(s2ifvAlcoProposalEntity, AlcoProposalDTO.class);

	}

	@Override
	public AlcoProposalDTO save(AlcoProposalDTO alcoProposalDTO) {
		logger.info("save() started in AlcoProposalServiceImpl for S2IFVAlcoProposalEntity {} ", alcoProposalDTO);
		try {
			Long maxId = alcoProposalRepository.findMaxAlCode();
			logger.info("maxId in save() in AlcoProposalServiceImpl {} ", maxId);
			int alId = 1;
			if (maxId != null) {
				alId = (int) (maxId + 1);
			}

			alcoProposalDTO.setAlAppNumber(createAlcoNo(alId));
			alcoProposalDTO.setDateOfAction(new Date());
			S2IFVAlcoProposalEntity s2ifvAlcoProposalEntity = modelMapper.map(alcoProposalDTO,
					S2IFVAlcoProposalEntity.class);
			alcoProposalRepository.save(s2ifvAlcoProposalEntity);

			Date currentDate = new Date();

			TblIfvModuleFwdEntity fwdEntity = new TblIfvModuleFwdEntity();
			fwdEntity.setAlCode(s2ifvAlcoProposalEntity.getAlCode());
			fwdEntity.setModuleId(ModuleIdEnum.ALCO.getModuleId());
			fwdEntity.setAppOfficerCode(alcoProposalDTO.getOfrCode());
			fwdEntity.setAppCurrentOfficerCode(alcoProposalDTO.getOfrCode());
			fwdEntity.setAppStatus(AppStatusEnum.NEW.getShortName());
			fwdEntity.setCreatedDate(currentDate);
			fwdEntity.setCreatedModifiedDate(currentDate);
			fwdEntity.setCreatedBy(alcoProposalDTO.getOfrName());
			fwdEntity.setIpAddress(alcoProposalDTO.getIpAddress());

			ifvModuleFwdRepository.save(fwdEntity);

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();
			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(alcoProposalDTO.getOfrName());
			docHistoryEntity.setCreatedDate(currentDate);
			docHistoryEntity.setGstStatus(AppStatusEnum.NEW.getShortName());
			docHistoryEntity.setHstCurrOfficerCode(alcoProposalDTO.getOfrCode());
			docHistoryEntity.setHstComments(AppStatusEnum.NEW.getFullName());
			docHistoryEntity.setIpAddress(alcoProposalDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);

			return modelMapper.map(s2ifvAlcoProposalEntity, AlcoProposalDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVAlcoProposalEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVAlcoProposalEntity." + msg + " ",
					e);
		}
	}

	@Override
	public AlcoProposalDTO update(Long id, AlcoProposalDTO alcoProposalDTO) {
		logger.info("update() started in AlcoProposalServiceImpl for S2IFVAlcoProposalEntity {} {} ", id,
				alcoProposalDTO);
		try {
			S2IFVAlcoProposalEntity existingS2IFVAlcoProposalEntity = alcoProposalRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAlcoProposalEntity", id));
			BeanUtils.copyProperties(alcoProposalDTO, existingS2IFVAlcoProposalEntity,
					commonUtil.getNullPropertyNames(alcoProposalDTO));

			alcoProposalRepository.save(existingS2IFVAlcoProposalEntity);

			Date date = new Date();

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByAlCode(id);
			if (fwdEntity != null) {
				fwdEntity.setAppCurrentOfficerCode(alcoProposalDTO.getOfrCode());
				fwdEntity.setModifiedDate(date);
				fwdEntity.setCreatedModifiedDate(date);
				fwdEntity.setModifiedBy(alcoProposalDTO.getOfrName());
				fwdEntity.setIpAddress(alcoProposalDTO.getIpAddress());
				ifvModuleFwdRepository.save(fwdEntity);
			}

			return modelMapper.map(existingS2IFVAlcoProposalEntity, AlcoProposalDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVAlcoProposalEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVAlcoProposalEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in AlcoProposalServiceImpl for S2IFVAlcoProposalEntity {} ", id);
		try {
			S2IFVAlcoProposalEntity existingS2IFVAlcoProposalEntity = alcoProposalRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAlcoProposalEntity", id));
			alcoProposalRepository.delete(existingS2IFVAlcoProposalEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVAlcoProposalEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVAlcoProposalEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<AlcoProposalDTO> saveAll(List<AlcoProposalDTO> alcoProposalDTOs) {
		logger.info("saveAll() started in AlcoProposalServiceImpl for List of S2IFVAlcoProposalEntity");
		try {
			List<S2IFVAlcoProposalEntity> alcoProposalEntitiesToSave = alcoProposalDTOs.stream()
					.map(alcoProposalDTO -> modelMapper.map(alcoProposalDTO, S2IFVAlcoProposalEntity.class))
					.collect(Collectors.toList());
			List<S2IFVAlcoProposalEntity> savedAlcoProposalEntities = alcoProposalRepository
					.saveAll(alcoProposalEntitiesToSave);

			return savedAlcoProposalEntities.stream()
					.map(alcoProposalEntity -> modelMapper.map(alcoProposalEntity, AlcoProposalDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVAlcoProposalEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVAlcoProposalEntities." + msg + " ", e);
		}
	}

	public String createAlcoNo(int alId) {
		logger.info("createAlcoNo() started in AlcoProposalServiceImpl {} ", alId);
		try {
			String prefix = "ALC";
			int year = Year.now().getValue() % 100;
			int month = LocalDate.now().getMonthValue();
			String yearStr = (month >= 4) ? "F" + (year + 1) : String.valueOf(year);
			String id = String.format("%04d", alId);
			return prefix + yearStr + id;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating createAlcoNo. {}", msg);
			throw new DatabaseOperationException("Error Occurred while creating createAlcoNo " + msg + "", e);
		}

	}

	@Override
	public TblIfvModuleFwdDTO updateDocument(String status, AlcoProposalDTO alcoProposalDTO) {

		logger.info("updateDocument() started in AlcoProposalServiceImpl for AlcoProposalDTO {} ",
				alcoProposalDTO.getAlCode());
		try {

			String updateStatus = null;
			switch (status) {

			case "LK":
				updateStatus = AppStatusEnum.LOCK.getFullName();
				break;

			case "UL":
				updateStatus = AppStatusEnum.NEW.getFullName();
				break;

			case "AP":
				updateStatus = AppStatusEnum.APPROVE.getFullName();
				break;

			case "CN":
				updateStatus = AppStatusEnum.CONFIRM.getFullName();
				break;

			default:
				break;
			}

			if (status.equalsIgnoreCase("UL")) {
				status = AppStatusEnum.NEW.getShortName();
			}

			TblIfvModuleFwdEntity fwdEntity = ifvModuleFwdRepository.findByAlCode(alcoProposalDTO.getAlCode());
			fwdEntity.setAppCurrentOfficerCode(alcoProposalDTO.getOfrCode());
			fwdEntity.setAppStatus(status);

			ifvModuleFwdRepository.save(fwdEntity);

			IFVDocumnetHistoryEntity docHistoryEntity = new IFVDocumnetHistoryEntity();
			docHistoryEntity.setFwdStatusID(fwdEntity.getFwdStatusId());
			docHistoryEntity.setCreatedBy(alcoProposalDTO.getOfrName());
			docHistoryEntity.setCreatedDate(new Date());
			docHistoryEntity.setGstStatus(status);
			docHistoryEntity.setHstCurrOfficerCode(alcoProposalDTO.getOfrCode());
			docHistoryEntity.setHstComments(updateStatus);
			docHistoryEntity.setIpAddress(alcoProposalDTO.getIpAddress());

			docHistoryRepo.save(docHistoryEntity);

			return modelMapper.map(fwdEntity, TblIfvModuleFwdDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updateDocument TblIfvModuleFwdEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while updateDocument TblIfvModuleFwdEntity of id ."
					+ alcoProposalDTO.getAlCode() + " " + msg + " ", e);
		}

	}

	@Override
	public List<AlcoProposalDTO> getAlcoProposalsOnUserType(String userType) {

		logger.info("Started getAlcoProposalsOnUserType() in AlcoProposalServiceImpl with userType {} ", userType);
		List<S2IFVAlcoProposalEntity> list = alcoProposalRepository.findAll();
		if (list.isEmpty()) {
			return new ArrayList<>();
		} else {
			List<AlcoProposalDTO> alcoProposalDTOs = list.stream()
					.sorted(Comparator.comparing(S2IFVAlcoProposalEntity::getDateOfAction).reversed())
					.map(applicationEntity -> modelMapper.map(applicationEntity, AlcoProposalDTO.class))
					.collect(Collectors.toList());

			List<Long> ids = list.stream().map(S2IFVAlcoProposalEntity::getAlCode).collect(Collectors.toList());
			List<TblIfvModuleFwdEntity> entities = ifvModuleFwdRepository.findByAlCodeIn(ids);

			Map<Long, TblIfvModuleFwdEntity> m = entities.stream()
					.collect(Collectors.toMap(TblIfvModuleFwdEntity::getAlCode, Function.identity(), (e1, e2) -> e1));

			alcoProposalDTOs.forEach(e -> {
				TblIfvModuleFwdEntity obj = m.get(e.getAlCode());
				if (obj != null) {

					e.setMakerName(obj.getCreatedBy());
					e.setStatus(AppStatusEnum.getFullNameByShortName(obj.getAppStatus()));
				}

			});

			switch (userType) {

			// Maker
			case "9092":
				break;

			// Checker
			case "9093":
				List<TblIfvModuleFwdEntity> fwdEntities = ifvModuleFwdRepository.findAll();
				List<Long> lockedIds = fwdEntities.stream()
						.filter(moduleFwdEntity -> moduleFwdEntity.getAppStatus()
								.equalsIgnoreCase(AppStatusEnum.LOCK.getShortName()))
						.map(TblIfvModuleFwdEntity::getAlCode).collect(Collectors.toList());
				alcoProposalDTOs = alcoProposalDTOs.stream().filter(e -> lockedIds.contains(e.getAlCode()))
						.collect(Collectors.toList());
				break;

			// Approver
			case "9095":
			case "10489":
				List<TblIfvModuleFwdEntity> fwdEntities2 = ifvModuleFwdRepository.findAll();
				List<Long> confirmedIds = fwdEntities2.stream()
						.filter(moduleFwdEntity -> moduleFwdEntity.getAppStatus()
								.equalsIgnoreCase(AppStatusEnum.CONFIRM.getShortName()))
						.map(TblIfvModuleFwdEntity::getAlCode).collect(Collectors.toList());
				alcoProposalDTOs = alcoProposalDTOs.stream().filter(e -> confirmedIds.contains(e.getAlCode()))
						.collect(Collectors.toList());
				break;

			default:
				alcoProposalDTOs = new ArrayList<>();
				break;
			}

			alcoProposalDTOs.sort(Comparator.comparing(AlcoProposalDTO::getDateOfAction).reversed());

			return alcoProposalDTOs;
		}

	}

	@Override
	public List<AlcoProposalDTO> findAllByAlCodeIn(List<Long> alCodes) {
		logger.info("started findAllByAlCodeIn() in AlcoProposalServiceImpl with alCodes {} ", alCodes);
		List<S2IFVAlcoProposalEntity> list = alcoProposalRepository.findAllByAlCodeIn(alCodes);
		return !list.isEmpty()
				? list.stream().sorted(Comparator.comparing(S2IFVAlcoProposalEntity::getDateOfAction).reversed())
						.map(alcoProposalEntity -> modelMapper.map(alcoProposalEntity, AlcoProposalDTO.class)).collect(
								Collectors.toList())
				: new ArrayList<>();
	}

	@Override
	public List<AlcoProposalDTO> getAlcoReportData() {
		logger.info("findAll() started in AlcoProposalServiceImpl of S2IFVAlcoProposalEntity");
		try {
			List<S2IFVAlcoProposalEntity> list = alcoProposalRepository.findAll();

			List<AlcoProposalDTO> alcoReportDTOs = list.stream().map(m -> modelMapper.map(m, AlcoProposalDTO.class))
					.sorted(Comparator.comparing(AlcoProposalDTO::getDateOfAction).reversed())
					.collect(Collectors.toList());

			List<Long> ids = list.stream().map(S2IFVAlcoProposalEntity::getAlCode).collect(Collectors.toList());
			List<TblIfvModuleFwdEntity> entities = ifvModuleFwdRepository.findByAlCodeIn(ids);

			Map<Long, TblIfvModuleFwdEntity> m = entities.stream()
					.collect(Collectors.toMap(TblIfvModuleFwdEntity::getAlCode, Function.identity(), (e1, e2) -> e1));

			alcoReportDTOs.forEach(e -> {
				TblIfvModuleFwdEntity obj = m.get(e.getAlCode());
				if (obj != null) {

					e.setMakerName(obj.getCreatedBy());
					e.setStatus(AppStatusEnum.getFullNameByShortName(obj.getAppStatus()));
				}

			});

			return alcoReportDTOs;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAlcoProposalEntities.{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAlcoProposalEntities." + msg + " ", e);
		}
	}

	public Page<AlcoProposalDTO> getAlcoReportDataOnPage(int page, int size, String filters, String sorting,
			String globalFilter) {
		logger.info("getAlcoReportDataOnPage() started in AlcoProposalServiceImpl");
		try {
			Pageable pageable = PageRequest.of(page, size, SortingUtil.parseSort(sorting));
			Specification<S2IFVAlcoProposalEntity> spec = new GenericSpecification<>(filters);
			Page<S2IFVAlcoProposalEntity> entityPage = alcoProposalRepository.findAll(spec, pageable);
			List<Long> ids = entityPage.getContent().stream().map(S2IFVAlcoProposalEntity::getAlCode)
					.collect(Collectors.toList());
			List<TblIfvModuleFwdEntity> entities = ifvModuleFwdRepository.findByAlCodeIn(ids);
			Map<Long, TblIfvModuleFwdEntity> entityMap = entities.stream()
					.collect(Collectors.toMap(TblIfvModuleFwdEntity::getAlCode, Function.identity(), (e1, e2) -> e1));
			List<AlcoProposalDTO> alcoReportDTOs = entityPage.getContent().stream()
					.map(entity -> convertToDto(entity, entityMap)).collect(Collectors.toList());
			return new PageImpl<>(alcoReportDTOs, pageable, entityPage.getTotalElements());
		} catch (Exception e) {
			throw new DatabaseOperationException(
					"Error Occurred while fetching filtered and sorted data. " + e.getMessage(), e);
		}
	}

	private AlcoProposalDTO convertToDto(S2IFVAlcoProposalEntity entity, Map<Long, TblIfvModuleFwdEntity> entityMap) {
		AlcoProposalDTO dto = modelMapper.map(entity, AlcoProposalDTO.class);
		TblIfvModuleFwdEntity relatedEntity = entityMap.get(dto.getAlCode());
		if (relatedEntity != null) {
			dto.setMakerName(relatedEntity.getCreatedBy());
			dto.setStatus(AppStatusEnum.getFullNameByShortName(relatedEntity.getAppStatus()));
		}
		return dto;
	}

}