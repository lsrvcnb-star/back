package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.AssOutstandingDTO;
import com.sidbi.ifv.services.AssOutstandingService;

@RestController
@RequestMapping("/ifv/ifccOustanding")
@CrossOrigin
public class AssOutstandingController {

	private static final Logger logger = LoggerFactory.getLogger(AssOutstandingController.class);

	@Autowired
	private AssOutstandingService s2ifccAssOutstandingService;

	@GetMapping("/get/{id}")
	public ResponseEntity<AssOutstandingDTO> findById(@PathVariable Long id) {
		logger.info("findById() started AssOutstandingController {} ",id);
		AssOutstandingDTO s2ifccApplicationDTO = s2ifccAssOutstandingService.findById(id);
		return ResponseEntity.ok(s2ifccApplicationDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<AssOutstandingDTO>> findAll() {
		logger.info("findAll() started AssOutstandingController ");
		List<AssOutstandingDTO> list = s2ifccAssOutstandingService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<AssOutstandingDTO> save(@RequestBody AssOutstandingDTO applicationDTO) {
		logger.info("save() started AssOutstandingController {} ",applicationDTO);
		AssOutstandingDTO createdApplication = s2ifccAssOutstandingService.save(applicationDTO);
		return ResponseEntity.ok(createdApplication);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<AssOutstandingDTO> update(@PathVariable Long id,
			@RequestBody AssOutstandingDTO applicationDTO) {
		logger.info("update() started AssOutstandingController {} ",applicationDTO);
		AssOutstandingDTO updatedApplication = s2ifccAssOutstandingService.update(id, applicationDTO);
		return ResponseEntity.ok(updatedApplication);
	}
	
	@PostMapping("/saveAll")
	public ResponseEntity<List<AssOutstandingDTO>> saveAll(@RequestBody List<AssOutstandingDTO> listAssOutstandingDTO) {
		logger.info("saveAll() started in AssOutstandingController ");
		List<AssOutstandingDTO> savedAssOutstandingDTOs = s2ifccAssOutstandingService.saveAll(listAssOutstandingDTO);
		return ResponseEntity.ok(savedAssOutstandingDTOs);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started AssOutstandingController {} ",id);
		s2ifccAssOutstandingService.delete(id);
		return ResponseEntity.noContent().build();
	}
	
	@GetMapping("/getAllOnIfvId/{ifvId}")
	 public ResponseEntity<List<AssOutstandingDTO>> getAllAssOutstandingEntityOnIfvId(@PathVariable Long ifvId) {
		 logger.info("getAllAssOutstandingEntityOnIfvId() started in AssOutstandingController ");
		 List<AssOutstandingDTO> assOutstandingDTOs = s2ifccAssOutstandingService.findAllByIfvId(ifvId);
		 return ResponseEntity.ok(assOutstandingDTOs);
	 }
}
