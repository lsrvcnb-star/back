package com.sidbi.ifv.entity;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_INSTITUTIONAL")
public class S2IFVInstitutionalEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IN_ID")
	private Long inId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "IN_PARTICULAR")
	private String inParticular;

	@Column(name = "IN_AMOUNT")
	private BigDecimal inAmount;
	
	@Column(name = "IN_DATE")
	private Date inDate;

}