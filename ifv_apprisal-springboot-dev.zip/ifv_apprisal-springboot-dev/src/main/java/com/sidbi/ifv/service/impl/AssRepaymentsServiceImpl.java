package com.sidbi.ifv.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.AssRepaymentsDTO;
import com.sidbi.ifv.entity.S2IFVAssRepaymentsEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AssRepaymentsRepository;
import com.sidbi.ifv.services.AssRepaymentsService;

import jakarta.transaction.Transactional;

@Service
public class AssRepaymentsServiceImpl implements AssRepaymentsService {
	private static final Logger logger = LoggerFactory.getLogger(AssRepaymentsServiceImpl.class);
	@Autowired
	private AssRepaymentsRepository s2IFFCCAssRepaymentsRepo;
	@Autowired
	private ModelMapper modelMapper;

	String msg = "";

	@Override
	public List<AssRepaymentsDTO> findAll() {
		logger.info("findAll() started in AssRepaymentsServiceImpl for S2IFVAssRepaymentsEntity");
		try {
			List<S2IFVAssRepaymentsEntity> list = s2IFFCCAssRepaymentsRepo.findAll();
			return list.stream().map(m -> modelMapper.map(m, AssRepaymentsDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAssRepaymentsEntities.{} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all S2IFVAssRepaymentsEntities." + msg + "", e);
		}
	}

	@Override
	public AssRepaymentsDTO findById(Long id) {
		logger.info("findById() started in AssRepaymentsServiceImpl for S2IFVAssRepaymentsEntity {} ", id);
		try {
			Optional<S2IFVAssRepaymentsEntity> ifccApplication = s2IFFCCAssRepaymentsRepo.findById(id);
			if (ifccApplication.isPresent()) {
				return modelMapper.map(ifccApplication.get(), AssRepaymentsDTO.class);
			} else {
				logger.error("Error Occurred while fetching  S2IFVAssRepaymentsEntity entity.");
				throw new EntityNotFoundException("s2IFVAssRepaymentsEntity", id);
			}

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all S2IFVAssRepaymentsEntity.{} ", msg);
			throw new DatabaseOperationException("Error Occurred while fetching S2IFVAssRepaymentsEntity." + msg + "",
					e);
		}

	}

	@Override
	public AssRepaymentsDTO save(AssRepaymentsDTO s2IFFCCAssRepaymentsDTO) {
		logger.info("save() started in AssRepaymentsServiceImpl for S2IFVAssRepaymentsEntity {} ",
				s2IFFCCAssRepaymentsDTO);
		try {
			S2IFVAssRepaymentsEntity s2IffccAssRepaymentsEntity = modelMapper.map(s2IFFCCAssRepaymentsDTO,
					S2IFVAssRepaymentsEntity.class);
			s2IFFCCAssRepaymentsRepo.save(s2IffccAssRepaymentsEntity);
			return modelMapper.map(s2IffccAssRepaymentsEntity, AssRepaymentsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating S2IFVAssRepaymentsEntity.{} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  S2IFVAssRepaymentsEntity." + msg + "",
					e);
		}
	}

	@Override
	public AssRepaymentsDTO update(Long id, AssRepaymentsDTO s2IFFCCAssRepaymentsDTO) {
		logger.info("updateIfccApp() started in AssRepaymentsServiceImpl for S2IFVAssRepaymentsEntity {} {} ", id,
				s2IFFCCAssRepaymentsDTO);
		try {
			S2IFVAssRepaymentsEntity s2IffccAssRepaymentsEntity = s2IFFCCAssRepaymentsRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAssRepaymentsEntity", id));

			BeanUtils.copyProperties(s2IFFCCAssRepaymentsDTO, s2IffccAssRepaymentsEntity);

			s2IFFCCAssRepaymentsRepo.save(s2IffccAssRepaymentsEntity);
			return modelMapper.map(s2IffccAssRepaymentsEntity, AssRepaymentsDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating S2IFVAssRepaymentsEntity.{} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating S2IFVAssRepaymentsEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("deleteIfccApp() started in AssRepaymentsServiceImpl for S2IFVAssRepaymentsEntity {} ", id);
		try {
			S2IFVAssRepaymentsEntity s2IffccAssRepaymentsEntity = s2IFFCCAssRepaymentsRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("S2IFVAssRepaymentsEntity", id));
			s2IFFCCAssRepaymentsRepo.delete(s2IffccAssRepaymentsEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting S2IFVAssRepaymentsEntity.{} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting S2IFVAssRepaymentsEntity of id ." + id + " " + msg + " ", e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<AssRepaymentsDTO> saveAll(List<AssRepaymentsDTO> listAssRepaymentsDTO) {
		logger.info("saveAll() started in AssRepaymentsServiceImpl for List of S2IFVAssRepaymentsEntity");
		try {
			List<S2IFVAssRepaymentsEntity> assRepaymentsEntitiesToSave = listAssRepaymentsDTO.stream()
					.map(assRepaymentsDTO -> modelMapper.map(assRepaymentsDTO, S2IFVAssRepaymentsEntity.class))
					.collect(Collectors.toList());

			Long ifvId = listAssRepaymentsDTO.stream().map(AssRepaymentsDTO::getIfvId).findFirst().orElse(null);

			s2IFFCCAssRepaymentsRepo.deleteByIfvId(ifvId);

			List<S2IFVAssRepaymentsEntity> savedAssRepaymentsEntities = s2IFFCCAssRepaymentsRepo
					.saveAll(assRepaymentsEntitiesToSave);

			return savedAssRepaymentsEntities.stream()
					.map(assRepaymentsEntity -> modelMapper.map(assRepaymentsEntity, AssRepaymentsDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all S2IFVAssRepaymentsEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all S2IFVAssRepaymentsEntities." + msg + " ", e);
		}
	}

	@Override
	public List<AssRepaymentsDTO> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in AssRepaymentsServiceImpl ");
		try {
			List<S2IFVAssRepaymentsEntity> listAssRepaymentsEntities = s2IFFCCAssRepaymentsRepo.findByIfvId(ifvId);
			return listAssRepaymentsEntities.stream()
					.map(assRepaymentsEntity -> modelMapper.map(assRepaymentsEntity, AssRepaymentsDTO.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all S2IFVAssRepaymentsEntities based on IfvId. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all S2IFVAssRepaymentsEntities  based on IfvId." + ifvId + " " + msg
							+ " ",
					e);

		}
	}

}
