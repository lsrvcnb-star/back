package com.sidbi.ifv.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itextpdf.text.DocumentException;
import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.dto.AssistanceAppliedForDto;
import com.sidbi.ifv.dto.CmtMemberMasterDTO;
import com.sidbi.ifv.dto.DisclosureDivergenceDto;
import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.HrmsEmpNameDesignationDTO;
import com.sidbi.ifv.dto.IFVProposalCheckerDetailDTO;
import com.sidbi.ifv.dto.IfvAggregateExposureDto;
import com.sidbi.ifv.dto.MasterRepositoryDTO;
import com.sidbi.ifv.dto.MinutesColendingLimitDTO;
import com.sidbi.ifv.dto.MinutesInterestResetDTO;
import com.sidbi.ifv.dto.MinutesOtherItemsDTO;
import com.sidbi.ifv.dto.ProposedSchemaDTO;
import com.sidbi.ifv.dto.ReportResponseJsonDTO;
import com.sidbi.ifv.dto.RestructuredAssetsDTO;
import com.sidbi.ifv.dto.SanctionMinutesDTO;
import com.sidbi.ifv.dto.StatusOfListingDto;
import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.dto.UcbAnnexureDTO;
import com.sidbi.ifv.dto.UcbBorrowersDetailDto;
import com.sidbi.ifv.dto.UcbCriteriaParameterDTO;
import com.sidbi.ifv.dto.UcbEligibilityCriteriaDTO;
import com.sidbi.ifv.dto.UcbFinancialPerformanceDTO;
import com.sidbi.ifv.dto.UcbTop10BorrowersDTO;
import com.sidbi.ifv.entity.CollectionEfficiencyEntity;
import com.sidbi.ifv.entity.IFVDocumnetHistoryEntity;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVAreasGeographicalEntity;
import com.sidbi.ifv.entity.S2IFVAssOutstandingEntity;
import com.sidbi.ifv.entity.S2IFVAssPastdisbEntity;
import com.sidbi.ifv.entity.S2IFVAssRepaymentsEntity;
import com.sidbi.ifv.entity.S2IFVChiefBoardEntity;
import com.sidbi.ifv.entity.S2IFVEligibilityEntity;
import com.sidbi.ifv.entity.S2IFVFinancialHighlightsEntity;
import com.sidbi.ifv.entity.S2IFVInstitutionalEntity;
import com.sidbi.ifv.entity.S2IFVInvestorEntity;
import com.sidbi.ifv.entity.S2IFVKycEntity;
import com.sidbi.ifv.entity.S2IFVPrincipalEntity;
import com.sidbi.ifv.entity.S2IFVProfileBdEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.entity.S2IFVRatingRepositoryEntity;
import com.sidbi.ifv.entity.S2IFVSchemaEntity;
import com.sidbi.ifv.entity.S2IFVSfbCommondtEntity;
import com.sidbi.ifv.entity.S2IFVTermConditionsDataEntity;
import com.sidbi.ifv.entity.SanctionMinutesDtlEntity;
import com.sidbi.ifv.entity.SanctionTermsConditionsEntity;
import com.sidbi.ifv.entity.TblIfvModuleFwdEntity;
import com.sidbi.ifv.enums.CommitteeEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.AreasGeographicalRepository;
import com.sidbi.ifv.repo.AssOutstandingRepository;
import com.sidbi.ifv.repo.AssPastdisbRepository;
import com.sidbi.ifv.repo.AssRepaymentsRepository;
import com.sidbi.ifv.repo.ChiefBoardRepository;
import com.sidbi.ifv.repo.CollectionEfficiencyRepository;
import com.sidbi.ifv.repo.EligibilityRepository;
import com.sidbi.ifv.repo.FinancialHighlightsRepository;
import com.sidbi.ifv.repo.IFVDocumnetHistoryRepo;
import com.sidbi.ifv.repo.IfvApiUsersRepo;
import com.sidbi.ifv.repo.InstitutionalRepository;
import com.sidbi.ifv.repo.InvestorRepository;
import com.sidbi.ifv.repo.KycRepository;
import com.sidbi.ifv.repo.PrincipalRepository;
import com.sidbi.ifv.repo.ProfileDbRepository;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.repo.RatingRepository;
import com.sidbi.ifv.repo.SanctionMinutesDtlRepository;
import com.sidbi.ifv.repo.SanctionTermsConditionsRepository;
import com.sidbi.ifv.repo.SchemaRepository;
import com.sidbi.ifv.repo.SfbCommondtRepository;
import com.sidbi.ifv.repo.TblIfvModuleFwdRepository;
import com.sidbi.ifv.repo.TermConditionsDataRepository;
import com.sidbi.ifv.reports.FinalMinutesWord;
import com.sidbi.ifv.reports.UCBAppraisalReport;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.AppraisalMinutesDataService;
import com.sidbi.ifv.services.CmtMemberMasterService;
import com.sidbi.ifv.services.DisclosureDivergenceService;
import com.sidbi.ifv.services.FileRepositoryService;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.services.MasterRepositoryService;
import com.sidbi.ifv.services.ProposedSchemaService;
import com.sidbi.ifv.services.ReportService;
import com.sidbi.ifv.services.RestructuredAssetsService;
import com.sidbi.ifv.services.SanctionMinutesService;
import com.sidbi.ifv.services.StatusOfListingService;
import com.sidbi.ifv.services.TblIfvModuleFwdService;
import com.sidbi.ifv.services.UcbAnnexureService;
import com.sidbi.ifv.services.UcbBorrowersDetailService;
import com.sidbi.ifv.services.UcbBorrowersService;
import com.sidbi.ifv.services.UcbCriteriaParameterService;
import com.sidbi.ifv.services.UcbEligibilityCriteriaService;
import com.sidbi.ifv.services.UcbFinancialPerformanceService;
import com.sidbi.ifv.util.AppraisalMergedPdf;
import com.sidbi.ifv.util.FinalMinutesPdf;

@Service
public class ReportServiceImpl implements ReportService {

	private static final Logger logger = LoggerFactory.getLogger(ReportServiceImpl.class);

	@Autowired
	private SanctionMinutesService sanctionMinutesService;

	@Autowired
	private SanctionMinutesDtlRepository sanctionMinutesDtlRepository;

	@Autowired
	private AppraisalMinutesDataService appraisalMinutesDataService;

	@Autowired
	private CmtMemberMasterService cmtMemberMasterService;

	String msg = "";

	@Autowired
	private ApplicationRepository applicationRepo;

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private KycRepository kycService;

	@Autowired
	private ChiefBoardRepository boardService;

	@Autowired
	private AreasGeographicalRepository areaOfGeographicalService;

	@Autowired
	private InvestorRepository investorService;

	@Autowired
	private AssPastdisbRepository assPastdisbService;

	@Autowired
	private AssOutstandingRepository assOutstandingService;

	@Autowired
	private AssRepaymentsRepository assRepaymentsService;

	@Autowired
	private SchemaRepository s2ifccSchemaService;

	@Autowired
	private PrincipalRepository principalService;

	@Autowired
	private InstitutionalRepository institutionalService;

	@Autowired
	private TermConditionsDataRepository termConditionDataService;

	@Autowired
	private FinancialHighlightsRepository financialHighlightsService;

	@Autowired
	private EligibilityRepository eligibilityRepository;

	@Autowired
	private SfbCommondtRepository commondtRepository;

	@Autowired
	private RatingRepository ratingRepository;

	@Autowired
	private MasterRepositoryService masterRepositoryService;

	@Autowired
	private ProfileDbRepository profileDbRepository;

	@Autowired
	private MasterDbService masterDbService;

	@Autowired
	private ProposedSchemaService proposedSchemaService;

	@Autowired
	private TblIfvModuleFwdRepository tblIfvModuleFwdRepository;

	@Autowired
	private CollectionEfficiencyRepository collectionEfficiencyRepository;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	@Autowired
	private RestructuredAssetsService restructuredAssetsService;

	@Autowired
	private SanctionTermsConditionsRepository sanctionTermsConditionsRepository;

	@Autowired
	private FileRepositoryService fileRepositoryService;

	@Autowired
	private IFVDocumnetHistoryRepo iFVDocumnetHistoryRepo;

	@Autowired
	private IfvApiUsersRepo ifvApiUsersRepo;

	FileRepositoryDTO fileRepositoryDTO = null;

	@Autowired
	private StatusOfListingService statusOfListingService;

	@Autowired
	private TblIfvModuleFwdService ifvModuleFwdService;

	@Autowired
	private UcbBorrowersService borrowersService;

	@Autowired
	private UcbFinancialPerformanceService financialPerformanceService;

	@Autowired
	private UcbEligibilityCriteriaService eligibilityCriteriaService;

	@Autowired
	private UcbCriteriaParameterService criteriaParameterService;

	@Autowired
	private UcbAnnexureService annexureService;

	@Autowired
	private UcbBorrowersDetailService borrowersDetailService;

	@Autowired
	private DisclosureDivergenceService disclosureDivergenceService;

	@Autowired
	private MinutesAdditionalDetailService additionalDetailService;

	private static final String DATE_FORMATE = "dd-MM-yyyy";

	@Override
	public byte[] generateAppraisalReportData(Long ifvId) {
		logger.info(" started generateReportForEmail {} ", ifvId);

		List<S2IFVApplicationEntity> s2IFCCApplicationList = null;

		List<S2IFVKycEntity> kycDtoList = null;

		List<S2IFVChiefBoardEntity> chiefBoardDTOList = null;

		List<S2IFVAreasGeographicalEntity> areaOfGeographicalDTOList = null;

		List<S2IFVInvestorEntity> investorDTOList = null;

		List<S2IFVAssPastdisbEntity> assPastdisbDTOList = null;

		List<S2IFVAssOutstandingEntity> assOutstandingDTOList = null;

		List<S2IFVAssRepaymentsEntity> assRepaymentsDTOList = null;

		List<S2IFVSchemaEntity> s2ifccSchemaDTOList = null;

		List<S2IFVPrincipalEntity> principalDTOList = null;

		List<S2IFVInstitutionalEntity> institutionalDTOList = null;

		S2IFVTermConditionsDataEntity conditionDataDTOList = null;

		List<S2IFVAreasGeographicalEntity> listOfCtAgType = null;

		List<S2IFVAreasGeographicalEntity> listOfStAgType = null;

		List<S2IFVFinancialHighlightsEntity> highlightsDTOList = null;

		S2IFVEligibilityEntity eligibilityEntitiesDTOList = null;

		S2IFVSfbCommondtEntity commondtEntityData = null;

		List<S2IFVRatingRepositoryEntity> ratingRepositoryData = null;

		List<DisclosureDivergenceDto> disclosureDivergenceDtos = null;

		List<AssistanceAppliedForDto> assistanceAppliedForDtos = null;

		List<IFVProposalCheckerDetailDTO> ifvProposalCheckerDetailDTOs = null;

		List<IfvAggregateExposureDto> aggregateExposure = null;

		String bankType = "";

		boolean isRRB = false;
		boolean isUCBAppraisal = false;

		byte[] mergedPdf = null;

		try {
			s2IFCCApplicationList = applicationRepo.findByIfvId(ifvId);
			if (s2IFCCApplicationList == null) {
				throw new DatabaseOperationException("S2IFCCApplicationList Data is not found for this used id ");
			}

			String bankTypeUCB = s2IFCCApplicationList.stream().filter(e -> e.getIfvBankType() != null)
					.map(S2IFVApplicationEntity::getIfvBankType).findFirst().orElse(null);
			if (bankTypeUCB != null && bankTypeUCB.equalsIgnoreCase("UCB")) {
				isUCBAppraisal = true;
			}

			if (bankTypeUCB != null && bankTypeUCB.equalsIgnoreCase("RRB")) {
				isRRB = true;
			}

			kycDtoList = setKyc(ifvId);
			chiefBoardDTOList = setChiefBoard(ifvId);
			areaOfGeographicalDTOList = setGeo(ifvId);

			investorDTOList = setInvestors(ifvId);
			assPastdisbDTOList = setPastDisb(ifvId);
			assOutstandingDTOList = setOutstanding(ifvId);
			assRepaymentsDTOList = setRepayment(ifvId);
			s2ifccSchemaDTOList = s2ifccSchemaService.findByIfvId(ifvId);
			if (s2ifccSchemaDTOList == null) {
				s2ifccSchemaDTOList = new ArrayList<>();
			}
			principalDTOList = principalService.findByIfvId(ifvId);
			if (principalDTOList == null) {
				principalDTOList = new ArrayList<>();
			}
			institutionalDTOList = institutionalService.findByIfvId(ifvId);
			if (institutionalDTOList == null) {
				institutionalDTOList = new ArrayList<>();
			}

			conditionDataDTOList = setCommonDataDTO(ifvId);

			highlightsDTOList = financialHighlightsService.findByIfvId(ifvId);
			if (highlightsDTOList == null) {
				highlightsDTOList = new ArrayList<>();
			}

			eligibilityEntitiesDTOList = setEligibility(ifvId);
			commondtEntityData = setCommonData(ifvId);

			ratingRepositoryData = setRatingRepo(ifvId);

			listOfCtAgType = setAreaOfGeo(ifvId);

			listOfStAgType = setListOfAgg(ifvId);

			List<MasterRepositoryDTO> masterRepositoryData = setMasterRepo();
			List<S2IFVProfileBdEntity> profileBdList = setProfileBorad(ifvId);
			List<ProposedSchemaDTO> proposedSchemaDetails = setProposals(ifvId);

			TblIfvModuleFwdEntity ifvUsersDetails = setTblData(ifvId);

			long officerCode = ifvUsersDetails.getAppCurrentOfficerCode() != null
					? ifvUsersDetails.getAppCurrentOfficerCode()
					: 0;
			List<String> offCodeList = new ArrayList<>();
			setOfrCodes(officerCode, offCodeList);
			List<HrmsEmpNameDesignationDTO> hrmsEmpName = masterDbService.getEmployeeNames(offCodeList);

			List<CollectionEfficiencyEntity> collectionEfficiencyDto = setCollEfficiency(ifvId);

			List<S2IFVProposedSchemaEntity> proposedSchemaDto = setProposedSchemes(ifvId);

			List<RestructuredAssetsDTO> restructuredAssetsDto = setResAssets(ifvId);
			List<SanctionTermsConditionsEntity> sanctionTermsConditionsDto = setSanctionTerms(ifvId);

			Long fwdStatusId = ifvUsersDetails.getFwdStatusId() != null ? ifvUsersDetails.getFwdStatusId() : null;
			List<Long> statusId = setStatusId(fwdStatusId);

			List<IfvApiUsersEntity> ifvApiUsersDetails = setApiUser(statusId);

			S2IFVApplicationEntity entity = null;

			if (!s2IFCCApplicationList.isEmpty()) {
				entity = s2IFCCApplicationList.stream().findFirst().orElse(null);
				if (entity != null) {
					bankType = masterDbService.getBankType(entity.getCifNumber());
				}
				setBankName(s2IFCCApplicationList, entity);
			}

			fileRepositoryDTO = fileRepositoryService.findByFileIfvIdAndFileModule(ifvId, "Annexure-II");
			List<IFVDocumnetHistoryEntity> iFVDocumnetHistoryDetails = iFVDocumnetHistoryRepo
					.findAllByFwdStatusID(fwdStatusId);

			List<StatusOfListingDto> statusOfListingDto = setStatusListing(ifvId);

			assistanceAppliedForDtos = proposedSchemaService.findAllAssistanceByIfvId(ifvId);

			ifvProposalCheckerDetailDTOs = applicationService.findAllCheckerDetailsByIfvId(ifvId);

			aggregateExposure = proposedSchemaService.findAggregateExposureByIfvId(ifvId);

			TblIfvModuleFwdDTO fwdDTO = ifvModuleFwdService.findByIfvId(ifvId);
			mergedPdf = setMergedData(ifvId, s2IFCCApplicationList, kycDtoList, chiefBoardDTOList,
					areaOfGeographicalDTOList, investorDTOList, assPastdisbDTOList, assOutstandingDTOList,
					assRepaymentsDTOList, s2ifccSchemaDTOList, principalDTOList, institutionalDTOList,
					conditionDataDTOList, listOfCtAgType, listOfStAgType, highlightsDTOList, eligibilityEntitiesDTOList,
					commondtEntityData, ratingRepositoryData, disclosureDivergenceDtos, assistanceAppliedForDtos,
					ifvProposalCheckerDetailDTOs, bankType, isRRB, isUCBAppraisal, masterRepositoryData, profileBdList,
					proposedSchemaDetails, hrmsEmpName, collectionEfficiencyDto, proposedSchemaDto,
					restructuredAssetsDto, sanctionTermsConditionsDto, ifvApiUsersDetails, entity,
					iFVDocumnetHistoryDetails, statusOfListingDto, fwdDTO, aggregateExposure);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error Occurred while generating pdf. {} ", e.getMessage());
		}
		return mergedPdf;
	}

	private List<S2IFVAssRepaymentsEntity> setRepayment(Long ifvId) {
		List<S2IFVAssRepaymentsEntity> assRepaymentsDTOList;
		assRepaymentsDTOList = assRepaymentsService.findByIfvId(ifvId);
		if (assRepaymentsDTOList == null) {
			assRepaymentsDTOList = new ArrayList<>();
		}
		return assRepaymentsDTOList;
	}

	private List<S2IFVAssOutstandingEntity> setOutstanding(Long ifvId) {
		List<S2IFVAssOutstandingEntity> assOutstandingDTOList;
		assOutstandingDTOList = assOutstandingService.findByIfvId(ifvId);
		if (assOutstandingDTOList == null) {
			assOutstandingDTOList = new ArrayList<>();
		}
		return assOutstandingDTOList;
	}

	private List<S2IFVAssPastdisbEntity> setPastDisb(Long ifvId) {
		List<S2IFVAssPastdisbEntity> assPastdisbDTOList;
		assPastdisbDTOList = assPastdisbService.findByIfvId(ifvId);
		if (assPastdisbDTOList == null) {
			assPastdisbDTOList = new ArrayList<>();
		}
		return assPastdisbDTOList;
	}

	private List<S2IFVInvestorEntity> setInvestors(Long ifvId) {
		List<S2IFVInvestorEntity> investorDTOList;
		investorDTOList = investorService.findByIfvId(ifvId);
		if (investorDTOList == null) {
			investorDTOList = new ArrayList<>();
		}
		return investorDTOList;
	}

	private List<S2IFVRatingRepositoryEntity> setRatingRepo(Long ifvId) {
		List<S2IFVRatingRepositoryEntity> ratingRepositoryData;
		ratingRepositoryData = ratingRepository.getByIfvId(ifvId);
		if (ratingRepositoryData == null) {
			ratingRepositoryData = new ArrayList<>();
		}
		return ratingRepositoryData;
	}

	private List<S2IFVAreasGeographicalEntity> setAreaOfGeo(Long ifvId) {
		List<S2IFVAreasGeographicalEntity> listOfCtAgType;
		listOfCtAgType = areaOfGeographicalService.findByIfvIdAndAgType(ifvId, "CT");
		if (listOfCtAgType == null) {
			listOfCtAgType = new ArrayList<>();
		}
		return listOfCtAgType;
	}

	private List<S2IFVAreasGeographicalEntity> setListOfAgg(Long ifvId) {
		List<S2IFVAreasGeographicalEntity> listOfStAgType;
		listOfStAgType = areaOfGeographicalService.findByIfvIdAndAgType(ifvId, "ST");
		if (listOfStAgType == null) {
			listOfStAgType = new ArrayList<>();
		}
		return listOfStAgType;
	}

	private List<StatusOfListingDto> setStatusListing(Long ifvId) {
		List<StatusOfListingDto> statusOfListingDto = statusOfListingService.findAllByIfvId(ifvId);
		if (statusOfListingDto == null) {
			statusOfListingDto = new ArrayList<>();
		}
		return statusOfListingDto;
	}

	private List<MasterRepositoryDTO> setMasterRepo() {
		List<MasterRepositoryDTO> masterRepositoryData = masterRepositoryService.findAll();
		if (masterRepositoryData == null) {
			masterRepositoryData = new ArrayList<>();
		}
		return masterRepositoryData;
	}

	private List<IfvApiUsersEntity> setApiUser(List<Long> statusId) {
		List<IfvApiUsersEntity> ifvApiUsersDetails = ifvApiUsersRepo.findByOfficerCode(statusId);
		if (ifvApiUsersDetails == null) {
			ifvApiUsersDetails = new ArrayList<>();
		}
		return ifvApiUsersDetails;
	}

	private List<Long> setStatusId(Long fwdStatusId) {
		List<Long> statusId = new ArrayList<>();
		if (fwdStatusId != null) {
			statusId = iFVDocumnetHistoryRepo.findByfwdStatusID(fwdStatusId);
		}
		return statusId;
	}

	private List<RestructuredAssetsDTO> setResAssets(Long ifvId) {
		List<RestructuredAssetsDTO> restructuredAssetsDto = restructuredAssetsService.findAllByIfvId(ifvId);
		if (restructuredAssetsDto == null) {
			restructuredAssetsDto = new ArrayList<>();
		}
		return restructuredAssetsDto;
	}

	private List<S2IFVAreasGeographicalEntity> setGeo(Long ifvId) {
		List<S2IFVAreasGeographicalEntity> areaOfGeographicalDTOList;
		areaOfGeographicalDTOList = areaOfGeographicalService.findByIfvId(ifvId);
		if (areaOfGeographicalDTOList == null) {
			areaOfGeographicalDTOList = new ArrayList<>();
		}
		return areaOfGeographicalDTOList;
	}

	private List<S2IFVChiefBoardEntity> setChiefBoard(Long ifvId) {
		List<S2IFVChiefBoardEntity> chiefBoardDTOList;
		chiefBoardDTOList = boardService.findByIfvId(ifvId);
		if (chiefBoardDTOList == null) {
			chiefBoardDTOList = new ArrayList<>();
		}
		return chiefBoardDTOList;
	}

	private List<S2IFVKycEntity> setKyc(Long ifvId) {
		List<S2IFVKycEntity> kycDtoList;
		kycDtoList = kycService.findByIfvId(ifvId);
		if (kycDtoList == null) {
			kycDtoList = new ArrayList<>();
		}
		return kycDtoList;
	}

	private void setOfrCodes(long officerCode, List<String> offCodeList) {
		StringBuilder sb = new StringBuilder();
		if (officerCode != 0) {
			String offCode = String.valueOf(officerCode);
			if (offCode.length() < 6) {
				sb.append("0");
				sb.append(offCode);
			}
		}
		String officerCodeString = sb.toString();
		offCodeList.add(officerCodeString);
	}

	private void setBankName(List<S2IFVApplicationEntity> s2IFCCApplicationList, S2IFVApplicationEntity entity) {
		if (entity.getIfvShortName() == null || entity.getIfvShortName().isBlank()) {
			String bankShortName = masterDbService.getBankShortName(entity.getCifNumber());

			s2IFCCApplicationList.forEach(e -> e.setIfvShortName(bankShortName));
		}
	}

	private List<ProposedSchemaDTO> setProposals(Long ifvId) {
		List<ProposedSchemaDTO> proposedSchemaDetails = proposedSchemaService.findAllByIfvId(ifvId);

		if (proposedSchemaDetails == null) {
			proposedSchemaDetails = new ArrayList<>();
		}

		proposedSchemaDetails = proposedSchemaDetails.stream().sorted(Comparator.comparing(ProposedSchemaDTO::getPrId))
				.collect(Collectors.toList());
		return proposedSchemaDetails;
	}

	private List<SanctionTermsConditionsEntity> setSanctionTerms(Long ifvId) {
		List<SanctionTermsConditionsEntity> sanctionTermsConditionsDto = sanctionTermsConditionsRepository
				.findByIfvId(ifvId);
		if (sanctionTermsConditionsDto == null) {
			sanctionTermsConditionsDto = new ArrayList<>();
		}

		sanctionTermsConditionsDto = sanctionTermsConditionsDto.stream()
				.sorted(Comparator.comparing(SanctionTermsConditionsEntity::getId)).collect(Collectors.toList());
		return sanctionTermsConditionsDto;
	}

	private List<S2IFVProposedSchemaEntity> setProposedSchemes(Long ifvId) {
		List<S2IFVProposedSchemaEntity> proposedSchemaDto = proposedSchemaRepository.findByIfvId(ifvId);
		if (proposedSchemaDto == null) {
			proposedSchemaDto = new ArrayList<>();
		}

		proposedSchemaDto = proposedSchemaDto.stream().sorted(Comparator.comparing(S2IFVProposedSchemaEntity::getPrId))
				.collect(Collectors.toList());
		return proposedSchemaDto;
	}

	private List<CollectionEfficiencyEntity> setCollEfficiency(Long ifvId) {
		List<CollectionEfficiencyEntity> collectionEfficiencyDto = collectionEfficiencyRepository.findByIfvId(ifvId);
		if (collectionEfficiencyDto == null) {
			collectionEfficiencyDto = new ArrayList<>();
		}
		return collectionEfficiencyDto;
	}

	private TblIfvModuleFwdEntity setTblData(Long ifvId) {
		TblIfvModuleFwdEntity ifvUsersDetails = tblIfvModuleFwdRepository.findByIfvId(ifvId);

		if (ifvUsersDetails == null) {
			ifvUsersDetails = new TblIfvModuleFwdEntity();
			ifvUsersDetails.setCreatedBy("");
		}
		return ifvUsersDetails;
	}

	private List<S2IFVProfileBdEntity> setProfileBorad(Long ifvId) {
		List<S2IFVProfileBdEntity> profileBdList = profileDbRepository.findByIfvId(ifvId);
		if (profileBdList == null) {
			profileBdList = new ArrayList<>();
		} else {
			profileBdList = profileBdList.stream().sorted(Comparator.comparing(S2IFVProfileBdEntity::getPrCode))
					.collect(Collectors.toList());
		}
		return profileBdList;
	}

	private S2IFVTermConditionsDataEntity setCommonDataDTO(Long ifvId) {
		S2IFVTermConditionsDataEntity conditionDataDTOList;
		conditionDataDTOList = termConditionDataService.findByIfvId(ifvId);
		if (conditionDataDTOList == null) {
			conditionDataDTOList = new S2IFVTermConditionsDataEntity();
			conditionDataDTOList.setIfvId(ifvId);
			conditionDataDTOList.setTsBorrowers("");
			conditionDataDTOList.setTsDisbursement("");
			conditionDataDTOList.setTsDocumentstion("");
			conditionDataDTOList.setTsDopRelaxtion("");
			conditionDataDTOList.setTsDrawalloan("");
			conditionDataDTOList.setTsDrawaloan("");
			conditionDataDTOList.setTsEligibleActivities("");
			conditionDataDTOList.setTsEligibleMse("");
			conditionDataDTOList.setTsEventDflt("");
			conditionDataDTOList.setTsExtent("");
			conditionDataDTOList.setTsFabia("");
			conditionDataDTOList.setTsFacilityAmount("");
			conditionDataDTOList.setTsId(0l);
			conditionDataDTOList.setTsIntrestPayment("");
			conditionDataDTOList.setTsMonths(BigDecimal.ZERO);
			conditionDataDTOList.setTsOtherCond("");
			conditionDataDTOList.setTsOutstandingAmount("");
			conditionDataDTOList.setTsPrincipalRepayment("");
			conditionDataDTOList.setTsRampe("");
			conditionDataDTOList.setTsRAteInterest(BigDecimal.ZERO);
			conditionDataDTOList.setTsRecommendation("");
			conditionDataDTOList.setTsRoiRepayments("");
			conditionDataDTOList.setTsDopRelaxtion("");
			conditionDataDTOList.setTsSecurity("");
			conditionDataDTOList.setTsSpecific("");
			conditionDataDTOList.setTsTenurePeriod(BigDecimal.ZERO);
			conditionDataDTOList.setTsTenureWd("");
			conditionDataDTOList.setTsTermSanction("");
			conditionDataDTOList.setTsTermsection("");
			conditionDataDTOList.setTsTimeFrame("");
			conditionDataDTOList.setTsUpfrontFee("");
			conditionDataDTOList.setTsValiditySanction("");

		}
		return conditionDataDTOList;
	}

	private S2IFVSfbCommondtEntity setCommonData(Long ifvId) {
		S2IFVSfbCommondtEntity commondtEntityData;
		commondtEntityData = commondtRepository.getByIfvId(ifvId);
		if (commondtEntityData == null) {
			commondtEntityData = new S2IFVSfbCommondtEntity();
			commondtEntityData.setIfvId(ifvId);
			commondtEntityData.setSfbAoBranches("");
			commondtEntityData.setSfbAoDate(new Date());
			commondtEntityData.setSfbAoMajorityBranches("");
			commondtEntityData.setSfbAoNetwork("");
			commondtEntityData.setSfbId(0l);
			commondtEntityData.setSfbShareportfoliodate(new Date());
			commondtEntityData.setSfShareholdingpattern(new Date());
		}
		return commondtEntityData;
	}

	private S2IFVEligibilityEntity setEligibility(Long ifvId) {
		S2IFVEligibilityEntity eligibilityEntitiesDTOList;
		eligibilityEntitiesDTOList = eligibilityRepository.getByIfvId(ifvId);
		if (eligibilityEntitiesDTOList == null) {
			eligibilityEntitiesDTOList = new S2IFVEligibilityEntity();
			eligibilityEntitiesDTOList.setEcAssstance("");
			eligibilityEntitiesDTOList.setEcAssstanceStatus("");
			eligibilityEntitiesDTOList.setEcBfnormseligibility("");
			eligibilityEntitiesDTOList.setEcBfsnorms("");
			eligibilityEntitiesDTOList.setEcBfsnorms1("");
			eligibilityEntitiesDTOList.setEcFabiaRemarks("");
			eligibilityEntitiesDTOList.setEcFabiaStatus("");
			eligibilityEntitiesDTOList.setEcGsecDate(new Date());
			eligibilityEntitiesDTOList.setEcGsecPercent(BigDecimal.ZERO);
			eligibilityEntitiesDTOList.setEcIcddRemarks("");
			eligibilityEntitiesDTOList.setEcIcddStatus("");
			eligibilityEntitiesDTOList.setEcId(0l);
			eligibilityEntitiesDTOList.setEcNnoaRemarks("");
			eligibilityEntitiesDTOList.setEcNnpaDate(new Date());
			eligibilityEntitiesDTOList.setEcNnpaPercent(BigDecimal.ZERO);
			eligibilityEntitiesDTOList.setEcNnpaStatus("");
			eligibilityEntitiesDTOList.setEcPsbs("");
			eligibilityEntitiesDTOList.setEcRbiCompliance("");
			eligibilityEntitiesDTOList.setEcRbiStatus("");
			eligibilityEntitiesDTOList.setEcRemarks("");
			eligibilityEntitiesDTOList.setEcRemarks1("");
			eligibilityEntitiesDTOList.setEcRmseAssistance("");
			eligibilityEntitiesDTOList.setEcRmseDate(new Date());
			eligibilityEntitiesDTOList.setEcRmsEmiCrofy("");
			eligibilityEntitiesDTOList.setEcRmseRemarks("");
			eligibilityEntitiesDTOList.setEcRmseStatus("");
			eligibilityEntitiesDTOList.setEcRmseStatus1("");
			eligibilityEntitiesDTOList.setEcSdbiFixed(BigDecimal.ZERO);
			eligibilityEntitiesDTOList.setEcSectForEignBank("");
			eligibilityEntitiesDTOList.setEcSidbiRemarks("");
			eligibilityEntitiesDTOList.setEcSidbiStatus("");
			eligibilityEntitiesDTOList.setIfvId(ifvId);
		}
		return eligibilityEntitiesDTOList;
	}

	private byte[] setMergedData(Long ifvId, List<S2IFVApplicationEntity> s2IFCCApplicationList,
			List<S2IFVKycEntity> kycDtoList, List<S2IFVChiefBoardEntity> chiefBoardDTOList,
			List<S2IFVAreasGeographicalEntity> areaOfGeographicalDTOList, List<S2IFVInvestorEntity> investorDTOList,
			List<S2IFVAssPastdisbEntity> assPastdisbDTOList, List<S2IFVAssOutstandingEntity> assOutstandingDTOList,
			List<S2IFVAssRepaymentsEntity> assRepaymentsDTOList, List<S2IFVSchemaEntity> s2ifccSchemaDTOList,
			List<S2IFVPrincipalEntity> principalDTOList, List<S2IFVInstitutionalEntity> institutionalDTOList,
			S2IFVTermConditionsDataEntity conditionDataDTOList, List<S2IFVAreasGeographicalEntity> listOfCtAgType,
			List<S2IFVAreasGeographicalEntity> listOfStAgType, List<S2IFVFinancialHighlightsEntity> highlightsDTOList,
			S2IFVEligibilityEntity eligibilityEntitiesDTOList, S2IFVSfbCommondtEntity commondtEntityData,
			List<S2IFVRatingRepositoryEntity> ratingRepositoryData,
			List<DisclosureDivergenceDto> disclosureDivergenceDtos,
			List<AssistanceAppliedForDto> assistanceAppliedForDtos,
			List<IFVProposalCheckerDetailDTO> ifvProposalCheckerDetailDTOs, String bankType, boolean isRRB,
			boolean isUCBAppraisal, List<MasterRepositoryDTO> masterRepositoryData,
			List<S2IFVProfileBdEntity> profileBdList, List<ProposedSchemaDTO> proposedSchemaDetails,
			List<HrmsEmpNameDesignationDTO> hrmsEmpName, List<CollectionEfficiencyEntity> collectionEfficiencyDto,
			List<S2IFVProposedSchemaEntity> proposedSchemaDto, List<RestructuredAssetsDTO> restructuredAssetsDto,
			List<SanctionTermsConditionsEntity> sanctionTermsConditionsDto, List<IfvApiUsersEntity> ifvApiUsersDetails,
			S2IFVApplicationEntity entity, List<IFVDocumnetHistoryEntity> iFVDocumnetHistoryDetails,
			List<StatusOfListingDto> statusOfListingDto, TblIfvModuleFwdDTO fwdDTO,
			List<IfvAggregateExposureDto> aggregateExposure) throws DocumentException, IOException {
		byte[] pdfData;
		List<UcbTop10BorrowersDTO> borrowersDTOs;
		List<UcbFinancialPerformanceDTO> financialPerformanceDTOs;
		List<UcbEligibilityCriteriaDTO> eligibilityCriteriaDTOs;
		List<UcbCriteriaParameterDTO> criteriaParameterDTOs;
		List<UcbAnnexureDTO> annexureDTOs;
		UcbBorrowersDetailDto ucbBorrowersDetailDto;
		AppraisalMergedPdf exporter;
		UCBAppraisalReport ucbExporter;
		byte[] mergedPdf;
		if (isUCBAppraisal || isRRB) {

			fileRepositoryDTO = fileRepositoryService.findByFileIfvIdAndFileModule(ifvId, "UCB-Annexure-I");

			borrowersDTOs = borrowersService.findAllByIfvId(ifvId);
			financialPerformanceDTOs = financialPerformanceService.findAllByIfvId(ifvId);
			eligibilityCriteriaDTOs = eligibilityCriteriaService.findAllByIfvId(ifvId);
			criteriaParameterDTOs = criteriaParameterService.findAllByIfvId(ifvId);
			annexureDTOs = annexureService.findAllByIfvId(ifvId);
			ucbBorrowersDetailDto = borrowersDetailService.findByIfvId(ifvId);

			String status = highlightsDTOList.stream()
					.filter(e -> e.getRestructuredAssetFlag() != null && !e.getRestructuredAssetFlag().isBlank())
					.map(S2IFVFinancialHighlightsEntity::getRestructuredAssetFlag).findFirst().orElse("");

			if (status.equalsIgnoreCase("Yes")) {
				disclosureDivergenceDtos = disclosureDivergenceService.findByIfvId(ifvId);
			}

			ucbExporter = new UCBAppraisalReport(s2IFCCApplicationList, kycDtoList, chiefBoardDTOList,
					areaOfGeographicalDTOList, investorDTOList, assPastdisbDTOList, assOutstandingDTOList,
					assRepaymentsDTOList, s2ifccSchemaDTOList, principalDTOList, institutionalDTOList,
					conditionDataDTOList, highlightsDTOList, eligibilityEntitiesDTOList, commondtEntityData,
					ratingRepositoryData, listOfCtAgType, listOfStAgType, masterRepositoryData, profileBdList,
					proposedSchemaDetails, hrmsEmpName, collectionEfficiencyDto, proposedSchemaDto,
					restructuredAssetsDto, sanctionTermsConditionsDto, ifvApiUsersDetails, iFVDocumnetHistoryDetails,
					bankType, fileRepositoryDTO, statusOfListingDto, fwdDTO, borrowersDTOs, financialPerformanceDTOs,
					eligibilityCriteriaDTOs, criteriaParameterDTOs, annexureDTOs, ucbBorrowersDetailDto,
					disclosureDivergenceDtos, isRRB, assistanceAppliedForDtos, ifvProposalCheckerDetailDTOs,
					aggregateExposure);

			pdfData = ucbExporter.export();
			mergedPdf = pdfData;
			if (isUCBAppraisal) {

				fileRepositoryDTO = fileRepositoryService.findByFileIfvIdAndFileModule(ifvId, "UCB-Annexure-VIII");

				byte[] originalUcbAnnexureByteData = (fileRepositoryDTO != null
						&& fileRepositoryDTO.getFileDataBytea() != null) ? fileRepositoryDTO.getFileDataBytea() : null;
				if (originalUcbAnnexureByteData != null) {
					mergedPdf = addUCBAdditionalData(pdfData, originalUcbAnnexureByteData);
				}

			}

		} else {
			exporter = new AppraisalMergedPdf(s2IFCCApplicationList /* , S2IFVSfbAggregateList */, kycDtoList,
					chiefBoardDTOList, areaOfGeographicalDTOList, investorDTOList, assPastdisbDTOList,
					assOutstandingDTOList, assRepaymentsDTOList, s2ifccSchemaDTOList, principalDTOList,
					institutionalDTOList, conditionDataDTOList, highlightsDTOList, eligibilityEntitiesDTOList,
					commondtEntityData, ratingRepositoryData, listOfCtAgType, listOfStAgType, masterRepositoryData,
					profileBdList, proposedSchemaDetails, hrmsEmpName, collectionEfficiencyDto, proposedSchemaDto,
					restructuredAssetsDto, sanctionTermsConditionsDto, ifvApiUsersDetails, iFVDocumnetHistoryDetails,
					bankType, fileRepositoryDTO, statusOfListingDto, fwdDTO, assistanceAppliedForDtos,
					ifvProposalCheckerDetailDTOs, aggregateExposure);

			pdfData = exporter.export();
			mergedPdf = pdfData;
			byte[] originalAnnexureIIByteData = (fileRepositoryDTO != null
					&& fileRepositoryDTO.getFileDataBytea() != null) ? fileRepositoryDTO.getFileDataBytea() : null;

			mergedPdf = addAdditionalData(pdfData, bankType, entity, mergedPdf, originalAnnexureIIByteData);

		}
		return mergedPdf;
	}

	private byte[] addAdditionalData(byte[] pdfData, String bankType, S2IFVApplicationEntity entity, byte[] mergedPdf,
			byte[] originalAnnexureIIByteData) throws IOException {
		if (originalAnnexureIIByteData != null && ((bankType != null && (bankType.equalsIgnoreCase("PUBLIC SECTOR BANK")
				|| bankType.equalsIgnoreCase("PRIVATE SECTOR BANK") || bankType.equalsIgnoreCase("FOREIGN BANKS")))
				|| entity.getSfb().equalsIgnoreCase("Y"))) {
			byte[] annexureII = null;
			if (fileRepositoryDTO.getFileType().equalsIgnoreCase("pdf")) {
				annexureII = originalAnnexureIIByteData;
			}
			ByteArrayInputStream inputStream1 = new ByteArrayInputStream(pdfData);
			ByteArrayInputStream inputStream2 = new ByteArrayInputStream(annexureII);
			PDFMergerUtility merger = new PDFMergerUtility();
			merger.addSource(inputStream1);
			merger.addSource(inputStream2);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			merger.setDestinationStream(outputStream);
			merger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());
			mergedPdf = outputStream.toByteArray();
			inputStream1.close();
			inputStream2.close();
			outputStream.close();
		}
		return mergedPdf;
	}

	private byte[] addUCBAdditionalData(byte[] pdfData, byte[] originalUcbAnnexureByteData) throws IOException {
		ByteArrayInputStream inputStream1 = new ByteArrayInputStream(pdfData);
		ByteArrayInputStream inputStream2 = new ByteArrayInputStream(originalUcbAnnexureByteData);
		PDFMergerUtility merger = new PDFMergerUtility();
		merger.addSource(inputStream1);
		merger.addSource(inputStream2);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		merger.setDestinationStream(outputStream);
		merger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());

		byte[] mergedPdfResult = outputStream.toByteArray();

		inputStream1.close();
		inputStream2.close();
		outputStream.close();
		return mergedPdfResult;
	}

	@Override
	public ReportResponseJsonDTO finalMinutesReport(Long sanctDetailCode) {
		logger.info(" started finalMinutesPdf {} ", sanctDetailCode);
		byte[] pdfData;

		SanctionMinutesDTO sanctionMinutesDetails = sanctionMinutesService.findById(sanctDetailCode);
		if (sanctionMinutesDetails == null) {
			sanctionMinutesDetails = new SanctionMinutesDTO();
			sanctionMinutesDetails.setConvenorCode("");
			sanctionMinutesDetails.setMemberCode("");
			sanctionMinutesDetails.setCommiteeCode(0);
			sanctionMinutesDetails.setMeetingNo(0);
			sanctionMinutesDetails.setMeetingDate(new Date());
			sanctionMinutesDetails.setMemberCode("");
		}

		List<SanctionMinutesDtlEntity> sanctionMinutesDtl = sanctionMinutesDtlRepository
				.findBySanctStatusCode(sanctDetailCode);

		Integer commiteeCode = sanctionMinutesDetails.getCommiteeCode();

		String committeeName = CommitteeEnum.getCommitteeNameByCode(commiteeCode);

		String agendaId = sanctionMinutesDtl.stream().map(SanctionMinutesDtlEntity::getAgendaId).findFirst().orElse("");

		List<AppraisalMinutesDataDTO> appraisalMinutesDataDetails = appraisalMinutesDataService
				.findByAgendaId(agendaId);

		List<CmtMemberMasterDTO> lCommitteeMembers = cmtMemberMasterService
				.findAllByCmtCode(sanctionMinutesDetails.getCommiteeCode());

		List<MinutesColendingLimitDTO> limits = additionalDetailService
				.getByMinuteSanctionId(sanctDetailCode.intValue());
		List<MinutesInterestResetDTO> intResets = additionalDetailService
				.getInterestResetsByMinuteSanctionId(sanctDetailCode.intValue());
		List<MinutesOtherItemsDTO> others = additionalDetailService.fetchOtherItems(sanctDetailCode.intValue());

		String dateTimeFormatted = "";
		DateTimeFormatter dateformate = DateTimeFormatter.ofPattern(DATE_FORMATE);
		LocalDate ld = (new Date()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		dateTimeFormatted = ld.format(dateformate);

		String fileName = "Final Minutes_" + committeeName + "_" + sanctionMinutesDetails.getMeetingNo() + "th_mtg_"
				+ dateTimeFormatted;

		try {
			FinalMinutesPdf exporter = new FinalMinutesPdf(sanctionMinutesDetails, sanctionMinutesDtl,
					appraisalMinutesDataDetails, committeeName, lCommitteeMembers, proposedSchemaRepository, limits,
					intResets, others);
			pdfData = exporter.export();
		} catch (DocumentException e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error occurred while getting PDF Data {} ", msg);
			throw new DatabaseOperationException("Error occurred while getting PDF Data " + msg);
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error occurred while executing finalMinutesReport {} ", msg);
			throw new DatabaseOperationException("Error occurred while executing finalMinutesReport " + msg);
		}
		return new ReportResponseJsonDTO(fileName, pdfData);
	}

	@Override
	public ReportResponseJsonDTO generateFInalMinutesWord(Long sanctDetailCode) {

		logger.info(" started finalMinutesPdf {} ", sanctDetailCode);
		byte[] data;

		SanctionMinutesDTO sanctionMinutesDetails = sanctionMinutesService.findById(sanctDetailCode);
		if (sanctionMinutesDetails == null) {
			sanctionMinutesDetails = new SanctionMinutesDTO();
			sanctionMinutesDetails.setConvenorCode("");
			sanctionMinutesDetails.setMemberCode("");
			sanctionMinutesDetails.setCommiteeCode(0);
			sanctionMinutesDetails.setMeetingNo(0);
			sanctionMinutesDetails.setMeetingDate(new Date());
			sanctionMinutesDetails.setMemberCode("");
		}

		List<SanctionMinutesDtlEntity> sanctionMinutesDtl = sanctionMinutesDtlRepository
				.findBySanctStatusCode(sanctDetailCode);

		Integer commiteeCode = sanctionMinutesDetails.getCommiteeCode();

		String committeeName = CommitteeEnum.getCommitteeNameByCode(commiteeCode);

		String agendaId = sanctionMinutesDtl.stream().map(SanctionMinutesDtlEntity::getAgendaId).findFirst().orElse("");

		List<AppraisalMinutesDataDTO> appraisalMinutesDataDetails = appraisalMinutesDataService
				.findByAgendaId(agendaId);

		List<CmtMemberMasterDTO> lCommitteeMembers = cmtMemberMasterService
				.findAllByCmtCode(sanctionMinutesDetails.getCommiteeCode());

		String dateTimeFormatted = "";
		DateTimeFormatter dateformate = DateTimeFormatter.ofPattern(DATE_FORMATE);
		LocalDate ld = (new Date()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		dateTimeFormatted = ld.format(dateformate);

		String fileName = "Final Minutes_" + committeeName + "_" + sanctionMinutesDetails.getMeetingNo() + "th_mtg_"
				+ dateTimeFormatted + ".docx";

		try {
			FinalMinutesWord exporter = new FinalMinutesWord(sanctionMinutesDetails, sanctionMinutesDtl,
					appraisalMinutesDataDetails, committeeName, lCommitteeMembers, proposedSchemaRepository);
			data = exporter.export();
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error occurred while executing finalMinutesReport {} ", msg);
			throw new DatabaseOperationException("Error occurred while executing finalMinutesReport " + msg);
		}
		return new ReportResponseJsonDTO(fileName, data);

	}

}
