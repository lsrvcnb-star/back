package com.sidbi.ifv.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class AppraisalMinutesDataDTO {

	private Long id;

	private Long sancDtlCode;

	private Long agendaNo;

	private String agendaId;

	private String appId;

	private String bankName;

	private String schemeName;

	private String fundName;

	private String fundCode;

	private BigDecimal loanAmount;

	private BigDecimal interestRate;

	private Integer tenure;

	private String principalRepayment;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

	private String status;

	private String schemeCode;

	private Long prId;

	private String interestType;

	private String benchMark;

	private String spread;

	private String interestReset;

	private Date maturityDate;

}
