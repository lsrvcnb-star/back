package com.sidbi.ifv.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.SfbCommondtDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.SfbCommondtService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifccmmon")
public class SfbCommondtController {

	private static final Logger logger = LoggerFactory.getLogger(SfbCommondtController.class);

	@Autowired
	private SfbCommondtService sfbCommondtService;

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/get/{id}")
	public ResponseEntity<SfbCommondtDTO> findById(@PathVariable Long id) {
		logger.info("findById() started SfbCommondtController {} ", id);
		SfbCommondtDTO s2ifccSfbCommondtDTO = sfbCommondtService.findById(id);
		return ResponseEntity.ok(s2ifccSfbCommondtDTO);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<SfbCommondtDTO>> findAll() {
		logger.info("findAll() started SfbCommondtController ");
		List<SfbCommondtDTO> list = sfbCommondtService.findAll();
		return ResponseEntity.ok(list);
	}

	@PostMapping("/save")
	public ResponseEntity<SfbCommondtDTO> save(@RequestBody SfbCommondtDTO s2ifccSfbCommondtDTO) {
		logger.info("save() started SfbCommondtController {} ", s2ifccSfbCommondtDTO);
		SfbCommondtDTO savedS2ifccSfbCommondtDTO = sfbCommondtService.save(s2ifccSfbCommondtDTO);
		return ResponseEntity.ok(savedS2ifccSfbCommondtDTO);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<SfbCommondtDTO> update(@PathVariable Long id,
			@RequestBody SfbCommondtDTO s2ifccSfbCommondtDTO) {
		logger.info("update() started SfbCommondtController {} ", s2ifccSfbCommondtDTO);
		SfbCommondtDTO updatedS2ifccSfbCommondtDTO = sfbCommondtService.update(id, s2ifccSfbCommondtDTO);
		return ResponseEntity.ok(updatedS2ifccSfbCommondtDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started SfbCommondtController {} ", id);
		sfbCommondtService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<SfbCommondtDTO>> getAllS2IFVSfbCommondtEntityOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllS2IFVSfbCommondtEntityOnIfvId() started in SfbCommondtController ");
		List<SfbCommondtDTO> sfbCommondtDTOs = sfbCommondtService.findAllByIfvId(ifvId);
		return ResponseEntity.ok(sfbCommondtDTOs);
	}

	@GetMapping("/getByIfvId/{ifvId}")
	public ResponseEntity<SfbCommondtDTO> getByIfvId(@PathVariable Long ifvId) {
		logger.info("getByIfvId() started in SfbCommondtController ");
		List<SfbCommondtDTO> sfbCommondtDTOs = sfbCommondtService.findAllByIfvId(ifvId);
		
		if (CollectionUtils.isEmpty(sfbCommondtDTOs)) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				List<SfbCommondtDTO> dtos2 = sfbCommondtService.findAllByIfvId(applicationDTO.getIfvId());
				if (!CollectionUtils.isEmpty(dtos2)) {
					dtos2.forEach(dto -> {
						dto.setIfvId(ifvId);
						dto.setSfbId(null);
					});
					return ResponseEntity.ok(dtos2.get(0));
				}
			}
			return ResponseEntity.ok(new SfbCommondtDTO());
		} else {
			return ResponseEntity.ok(sfbCommondtDTOs.get(0));
		}

	}

	@PostMapping("/saveOrUpdateAuditComment/{ifvId}/{auditComment}")
	public ResponseEntity<SfbCommondtDTO> saveOrUpdateAuditComment(@PathVariable Long ifvId,
			@PathVariable String auditComment) {
		logger.info("save() started SfbCommondtController {} ", ifvId);
		SfbCommondtDTO savedS2ifccSfbCommondtDTO = sfbCommondtService.saveOrUpdateAuditComment(ifvId, auditComment);
		return ResponseEntity.ok(savedS2ifccSfbCommondtDTO);
	}

}
