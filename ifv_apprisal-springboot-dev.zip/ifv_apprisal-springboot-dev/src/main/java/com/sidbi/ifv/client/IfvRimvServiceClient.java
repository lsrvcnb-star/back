package com.sidbi.ifv.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sidbi.ifv.config.FeignConfig;
import com.sidbi.ifv.dto.IfvRimvAppDto;

@FeignClient(name = "ifvServiceClient", url = "${service.remote.rimv-service-url}", configuration = FeignConfig.class)
public interface IfvRimvServiceClient {

	@PostMapping("/internal/ifv/forwardDocumentsToRimv")
	Boolean forwardDocumentsToRimv(@RequestBody IfvRimvAppDto rimvAppDto);

}