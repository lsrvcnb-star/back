package com.sidbi.ifv.entity;

import java.util.Date;

import com.sidbi.ifv.dto.PoaSignatureDTO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "S2_IFV_POA_SIGNATURE")
public class PoaSignatureEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "cif_number")
	private String cifNumber;

	@Column(name = "bank_name")
	private String bankName;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "file")
	private byte[] file;

	@Column(name = "file_name")
	private String fileName;

	public static PoaSignatureEntity fromDTO(PoaSignatureDTO dto) {
		PoaSignatureEntity entity = new PoaSignatureEntity();
		entity.setCifNumber(dto.getCifNumber());
		entity.setBankName(dto.getBankName());
		entity.setStartDate(dto.getStartDate());
		entity.setEndDate(dto.getEndDate());
		entity.setFileName(dto.getFileName());
		entity.setFile(dto.getFile());

		return entity;
	}

}