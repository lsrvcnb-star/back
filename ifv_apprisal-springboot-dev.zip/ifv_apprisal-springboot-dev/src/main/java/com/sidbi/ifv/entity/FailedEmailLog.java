package com.sidbi.ifv.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "failed_email_logs")
@Getter
@Setter
public class FailedEmailLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "ifv_id")
	private Long ifvId;

	@Column(name = "module")
	private String module;

	@Column(name = "error_message", columnDefinition = "text")
	private String errorMessage;

	@Column(name = "retry_attempts")
	private Integer retryAttempts;

	@Column(name = "email_content", columnDefinition = "text")
	private String emailContent;

	@Column(name = "recipient_details", columnDefinition = "text")
	private String recipientDetails;

	@Column(name = "created_at")
	private LocalDateTime createdAt;

	@PrePersist
	protected void onCreate() {
		createdAt = LocalDateTime.now();
	}
}
