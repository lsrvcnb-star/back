package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class VerticalDto {
	private String vcName;

	private String slSidbiProductLine;
}