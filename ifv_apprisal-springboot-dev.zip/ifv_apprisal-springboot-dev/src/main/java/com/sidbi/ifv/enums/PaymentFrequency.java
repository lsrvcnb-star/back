package com.sidbi.ifv.enums;

public enum PaymentFrequency {
	MONTHLY('M', "Monthly"), QUARTERLY('Q', "Quarterly"), HALF_YEARLY('H', "Half-yearly"), YEARLY('Y', "Yearly"),
	BULLET('B', "Bullet"), OTHER('O', "Other");

	private final Character code;
	private final String description;

	PaymentFrequency(Character code, String description) {
		this.code = code;
		this.description = description;
	}

	public Character getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	// Get enum by code
	public static PaymentFrequency fromCode(Character code) {
		if (code == null)
			return null;
		for (PaymentFrequency frequency : values()) {
			if (frequency.code.equals(code)) {
				return frequency;
			}
		}
		throw new IllegalArgumentException("Unknown code: " + code);
	}

	// Get enum by description
	public static PaymentFrequency fromDescription(String description) {
		if (description == null)
			return null;
		for (PaymentFrequency frequency : values()) {
			if (frequency.description.equalsIgnoreCase(description)) {
				return frequency;
			}
		}
		throw new IllegalArgumentException("Unknown description: " + description);
	}
}
