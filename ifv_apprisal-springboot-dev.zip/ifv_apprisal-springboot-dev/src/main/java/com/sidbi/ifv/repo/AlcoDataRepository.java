package com.sidbi.ifv.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidbi.ifv.entity.S2IFVAlcoDataEntity;

public interface AlcoDataRepository extends JpaRepository<S2IFVAlcoDataEntity, Long> {

	List<S2IFVAlcoDataEntity> findByIfvId(Long ifvId);

	List<S2IFVAlcoDataEntity> findByAlCode(Long alCode);

	List<S2IFVAlcoDataEntity> findAllByAlCodeIn(List<Long> alCodes);

	List<S2IFVAlcoDataEntity> findAllByDtAppl(String appId);

	List<S2IFVAlcoDataEntity> findByDtBankname(String name);

}
