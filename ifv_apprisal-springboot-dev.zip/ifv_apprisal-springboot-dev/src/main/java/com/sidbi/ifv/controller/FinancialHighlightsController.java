package com.sidbi.ifv.controller;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.ApplicationDTO;
import com.sidbi.ifv.dto.FinancialHighlightsDTO;
import com.sidbi.ifv.services.ApplicationService;
import com.sidbi.ifv.services.FinancialHighlightsService;

@RestController
@CrossOrigin
@RequestMapping("/ifv/ifchighlights")
public class FinancialHighlightsController {

	private static final Logger logger = LoggerFactory.getLogger(FinancialHighlightsController.class);

	@Autowired
	private FinancialHighlightsService financialHighlightsService;

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/getAll")
	public List<FinancialHighlightsDTO> findAll() {
		logger.info("findAll() started FinancialHighlightsController");
		return financialHighlightsService.findAll();
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<FinancialHighlightsDTO> findById(@PathVariable Long id) {
		logger.info("findById() started FinancialHighlightsController {} ", id);
		FinancialHighlightsDTO financialHighlightsDTO = financialHighlightsService.findById(id);
		return ResponseEntity.ok(financialHighlightsDTO);
	}

	@PostMapping("/save")
	public ResponseEntity<FinancialHighlightsDTO> save(@RequestBody FinancialHighlightsDTO financialHighlightsDTO) {
		logger.info("save() started FinancialHighlightsController {} ", financialHighlightsDTO);
		FinancialHighlightsDTO createFinancialHighlightsDTO = financialHighlightsService.save(financialHighlightsDTO);
		return ResponseEntity.ok(createFinancialHighlightsDTO);
	}

	@PostMapping("/saveAll")
	public ResponseEntity<List<FinancialHighlightsDTO>> saveAll(
			@RequestBody List<FinancialHighlightsDTO> listFinancialHighlightsDTO) {
		logger.info("saveAll() started in FinancialHighlightsController ");
		List<FinancialHighlightsDTO> savedFinancialHighlightsDTOs = financialHighlightsService
				.saveAll(listFinancialHighlightsDTO);
		return ResponseEntity.ok(savedFinancialHighlightsDTOs);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<FinancialHighlightsDTO> update(@PathVariable Long id,
			@RequestBody FinancialHighlightsDTO financialHighlightsDTO) {
		logger.info("update() started FinancialHighlightsController {} ", financialHighlightsDTO);
		FinancialHighlightsDTO updatedFinancialHighlightsDTO = financialHighlightsService.update(id,
				financialHighlightsDTO);
		return ResponseEntity.ok(updatedFinancialHighlightsDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started FinancialHighlightsController {} ", id);
		financialHighlightsService.deleteAppraisal(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/getAllOnIfvId/{ifvId}")
	public ResponseEntity<List<FinancialHighlightsDTO>> getAllOnIfvId(@PathVariable Long ifvId) {
		logger.info("getAllOnIfvId() started in FinancialHighlightsController");
		List<FinancialHighlightsDTO> financialHighlightsDTOs = financialHighlightsService.findAllByIfvId(ifvId);
		if (CollectionUtils.isEmpty(financialHighlightsDTOs)) {
			ApplicationDTO applicationDTO = applicationService.findSecondHighestByIfvId(ifvId);
			if (applicationDTO != null) {
				List<FinancialHighlightsDTO> financialHighlightsDTOs2 = financialHighlightsService
						.findAllByIfvId(applicationDTO.getIfvId());
				if (!CollectionUtils.isEmpty(financialHighlightsDTOs2)) {
					financialHighlightsDTOs2.sort(Comparator.comparing(FinancialHighlightsDTO::getFhId));
					financialHighlightsDTOs2.forEach(dto -> {
						dto.setIfvId(ifvId);
						dto.setFhId(null);
					});
					return ResponseEntity.ok(financialHighlightsDTOs2);
				}
			}
			return ResponseEntity.ok(Collections.emptyList());
		} else {
			financialHighlightsDTOs.sort(Comparator.comparing(FinancialHighlightsDTO::getFhId));
			return ResponseEntity.ok(financialHighlightsDTOs);
		}
	}

	@GetMapping("/getDisclosureStatus/{ifvId}")
	public ResponseEntity<String> getDisclosureStatus(@PathVariable Long ifvId) {
		logger.info("getDisclosureStatus() started in FinancialHighlightsController ");
		return ResponseEntity.ok(financialHighlightsService.getDisclosureStatus(ifvId));
	}
}
