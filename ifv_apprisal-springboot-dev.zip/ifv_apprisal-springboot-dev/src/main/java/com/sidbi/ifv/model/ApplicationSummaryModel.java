package com.sidbi.ifv.model;

import lombok.Data;

@Data
public class ApplicationSummaryModel {

	private Long ifvId;

	private String ifvName;

	private String appNumber;

	private String sfb;

	private String createdDate;

	private String schemeName;

	private String makerName;

	private String status;

	private String checker;

	private String checker1;

	private String checker2;

	private String checker3;

	private String checker4;

	private String cifNumber;

	private String approvedBy;

}