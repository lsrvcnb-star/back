package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.TblIfvModuleFwdDTO;
import com.sidbi.ifv.entity.TblIfvModuleFwdEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.TblIfvModuleFwdRepository;
import com.sidbi.ifv.services.TblIfvModuleFwdService;

@Service
public class TblIfvModuleFwdserviceImpl implements TblIfvModuleFwdService {
	private static final Logger logger = LoggerFactory.getLogger(TblIfvModuleFwdserviceImpl.class);

	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private TblIfvModuleFwdRepository tblIfvModuleFwdRepository;

	String msg = "";

	@Override
	public TblIfvModuleFwdDTO findById(Long id) {
		logger.info("findById() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO {} ", id);
		try {
			TblIfvModuleFwdEntity tblIfvModuleFwdEntity = tblIfvModuleFwdRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("tblIfvModuleFwdEntity", id));
			return modelMapper.map(tblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all TblIfvModuleFwdEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all TblIfvModuleFwdEntity." + msg + " ",
					e);
		}
	}

	@Override
	public TblIfvModuleFwdDTO save(TblIfvModuleFwdDTO tblIfvModuleFwdDTO) {
		logger.info("save() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO ");
		try {
			TblIfvModuleFwdEntity tblIfvModuleFwdEntity = modelMapper.map(tblIfvModuleFwdDTO,
					TblIfvModuleFwdEntity.class);
			tblIfvModuleFwdRepository.save(tblIfvModuleFwdEntity);
			return modelMapper.map(tblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating TblIfvModuleFwdEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while creating TblIfvModuleFwdEntity entity." + msg + " ", e);
		}
	}

	@Override
	public TblIfvModuleFwdDTO update(Long id, TblIfvModuleFwdDTO tblIfvModuleFwdDTO) {
		logger.info("save() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO ");
		try {
			TblIfvModuleFwdEntity existingTblIfvModuleFwdEntity = tblIfvModuleFwdRepository.findById(id)

					.orElseThrow(() -> new EntityNotFoundException("TblIfvModuleFwdEntity", id));
			BeanUtils.copyProperties(tblIfvModuleFwdDTO, existingTblIfvModuleFwdEntity);
			tblIfvModuleFwdRepository.save(existingTblIfvModuleFwdEntity);
			return modelMapper.map(existingTblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating TblIfvModuleFwdEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating TblIfvModuleFwdEntity entity." + msg + " ", e);

		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO ");
		try {
			TblIfvModuleFwdEntity tblIfvModuleFwdEntity = tblIfvModuleFwdRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("TblIfvModuleFwdEntity", id));
			tblIfvModuleFwdRepository.delete(tblIfvModuleFwdEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting TblIfvModuleFwdEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleting TblIfvModuleFwdEntity entity." + msg + " ", e);
		}
	}

	@Override
	public List<TblIfvModuleFwdDTO> findAll() {
		logger.info("findAll() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO ");
		try {
			List<TblIfvModuleFwdEntity> list = tblIfvModuleFwdRepository.findAll();
			return list.stream().map(s -> modelMapper.map(s, TblIfvModuleFwdDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findAll TblIfvModuleFwdEntity entity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAll TblIfvModuleFwdEntity entity." + msg + " ", e);
		}
	}

	@Override
	public TblIfvModuleFwdDTO findByIfvId(Long id) {
		logger.info("findByIfvId() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO {} ", id);
		try {
			TblIfvModuleFwdEntity tblIfvModuleFwdEntity = tblIfvModuleFwdRepository.findByIfvId(id);
			return tblIfvModuleFwdEntity != null ? modelMapper.map(tblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class)
					: new TblIfvModuleFwdDTO();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all TblIfvModuleFwdEntity entities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all TblIfvModuleFwdEntity entities." + msg + " ", e);
		}
	}

	@Override
	public List<TblIfvModuleFwdDTO> findAllByAppStatusAndIfvId(String appStatus) {
		logger.info("findAllByAppStatusAndIfvId() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO {} ", appStatus);
		List<TblIfvModuleFwdEntity> list = tblIfvModuleFwdRepository.findAllByAppStatusAndIfvId(appStatus);
		return !list.isEmpty() ? list.stream()
				.map(tblIfvModuleFwdEntity -> modelMapper.map(tblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class))
				.collect(Collectors.toList()) : new ArrayList<>();

	}
	
	@Override
	public TblIfvModuleFwdDTO findByAlCode(Long alCode) {
		logger.info("findByAlCode() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO {} ", alCode);
		try {
			TblIfvModuleFwdEntity tblIfvModuleFwdEntity = tblIfvModuleFwdRepository.findByAlCode(alCode);
			return tblIfvModuleFwdEntity != null ? modelMapper.map(tblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class)
					: new TblIfvModuleFwdDTO();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all TblIfvModuleFwdEntity on alCode. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all TblIfvModuleFwdEntity on alCode ." + msg + " "+alCode+" ", e);
		}
	}

	@Override
	public List<TblIfvModuleFwdDTO> findAllByAppStatusAndAlCode(String appStatus) {
		logger.info("findAllByAppStatusAndAlCode() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO {} ", appStatus);
		List<TblIfvModuleFwdEntity> list = tblIfvModuleFwdRepository.findAllByAppStatusAndAlCode(appStatus);
		return !list.isEmpty() ? list.stream()
				.map(tblIfvModuleFwdEntity -> modelMapper.map(tblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class))
				.collect(Collectors.toList()) : new ArrayList<>();
	}

	@Override
	public List<TblIfvModuleFwdDTO> findByIfvIdIn(List<Long> ids) {
		logger.info("findByIfvIdIn() started in TblIfvModuleFwdserviceIMPL for TblIfvModuleFwdDTO {} ", ids);
		List<TblIfvModuleFwdEntity> list = tblIfvModuleFwdRepository.findByIfvIdIn(ids);
		return !list.isEmpty() ? list.stream()
				.map(tblIfvModuleFwdEntity -> modelMapper.map(tblIfvModuleFwdEntity, TblIfvModuleFwdDTO.class))
				.collect(Collectors.toList()) : new ArrayList<>();
	}
}
