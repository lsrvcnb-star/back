package com.sidbi.ifv.services;

import java.util.List;

import com.sidbi.ifv.dto.LoITermsConditionsDTO;

public interface LoITermsConditionsService extends CrudService<LoITermsConditionsDTO, Long> {

	List<LoITermsConditionsDTO> findAllByIfvId(Long ifvId);

	List<LoITermsConditionsDTO> findAllByIfvIdAndPrId(Long ifvId, Long prId);

	LoITermsConditionsDTO findByIfvIdAndPrId(Long ifvId, Long prId);

	List<LoITermsConditionsDTO> findByloiId(Long loiId);

	LoITermsConditionsDTO findByloiIdAndPrId(Long loiId, Long prId);
}
