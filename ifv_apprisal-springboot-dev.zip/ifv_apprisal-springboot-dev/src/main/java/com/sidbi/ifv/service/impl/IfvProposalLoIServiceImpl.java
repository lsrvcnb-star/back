package com.sidbi.ifv.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.dto.IfvProposalLoIDto;
import com.sidbi.ifv.entity.AssistanceAppliedForEntity;
import com.sidbi.ifv.entity.IfvProposalLoI;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVFileRepositoryEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.AssistanceAppliedForRepository;
import com.sidbi.ifv.repo.FileRepository;
import com.sidbi.ifv.repo.IfvProposalLoIRepo;
import com.sidbi.ifv.repo.LoIDetailRepo;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.services.IfvProposalLoIService;
import com.sidbi.ifv.services.MasterCommonAPIClient;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.GenericSpecification;
import com.sidbi.ifv.util.NumberToWordsInCrores;
import com.sidbi.ifv.util.SortingUtil;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class IfvProposalLoIServiceImpl implements IfvProposalLoIService {
	private final IfvProposalLoIRepo ifvProposalLoIRepo;
	private final ModelMapper mapper;

	public IfvProposalLoIServiceImpl(IfvProposalLoIRepo ifvProposalLoIRepo, ModelMapper mapper) {
		this.ifvProposalLoIRepo = ifvProposalLoIRepo;
		this.mapper = mapper;
	}

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	@Autowired
	private MasterCommonAPIClient masterCommonAPIClient;

	@Autowired
	private LoIDetailRepo loIDetailRepo;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private AssistanceAppliedForRepository appliedForRepository;

	@Autowired
	private FileRepository fileRepository;

	@Override
	public IfvProposalLoIDto findById(Long id) {
		try {
			return ifvProposalLoIRepo.findById(id).map(entity -> mapper.map(entity, IfvProposalLoIDto.class))
					.orElseThrow(() -> new EntityNotFoundException("IfvProposalLoI not found with id, " + id, ""));
		} catch (Exception e) {
			log.error("Error occurred while fetching IfvProposalLoI with id: {}", id, e);
			throw new DatabaseOperationException(
					"Error retrieving IfvProposalLoI with id: " + id + " | " + e.getMessage());
		}
	}

	@Override
	public List<IfvProposalLoIDto> findAll() {
		try {
			return ifvProposalLoIRepo.findAll().stream().map(entity -> mapper.map(entity, IfvProposalLoIDto.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			log.error("Error occurred while fetching all IfvProposalLoI records", e);
			throw new DatabaseOperationException("Error retrieving all IfvProposalLoI records: " + e.getMessage());
		}
	}

	@Override
	@Transactional
	public IfvProposalLoIDto save(IfvProposalLoIDto dto) {
		try {
			if (dto == null) {
				throw new IllegalArgumentException("IfvProposalLoIDto cannot be null");
			}
			IfvProposalLoI entity;
			if (dto.getId() != null && dto.getId() > 0) {
				entity = ifvProposalLoIRepo.findById(dto.getId()).orElseGet(() -> new IfvProposalLoI());
				BeanUtils.copyProperties(dto, entity, commonUtil.getNullPropertyNames(dto));
			} else {
				entity = mapper.map(dto, IfvProposalLoI.class);
			}
			IfvProposalLoI savedEntity = ifvProposalLoIRepo.save(entity);
			return mapper.map(savedEntity, IfvProposalLoIDto.class);
		} catch (IllegalArgumentException e) {
			throw e;
		} catch (Exception e) {
			log.error("Error occurred while saving/updating IfvProposalLoI: {}", dto, e);
			throw new DatabaseOperationException("Error saving/updating IfvProposalLoI: " + e.getMessage());
		}
	}

	@Override
	@Transactional
	public List<IfvProposalLoIDto> saveAll(List<IfvProposalLoIDto> dtos) {
		return Collections.emptyList();
	}

	@Override
	@Transactional
	public void delete(Long id) {
		try {
			if (id == null) {
				throw new IllegalArgumentException("Id cannot be null");
			}
			if (!ifvProposalLoIRepo.existsById(id)) {
				throw new EntityNotFoundException("IfvProposalLoI not found with id: " + id, "");
			}
			ifvProposalLoIRepo.deleteById(id);
		} catch (EntityNotFoundException | IllegalArgumentException e) {
			throw e;
		} catch (Exception e) {
			log.error("Error occurred while deleting IfvProposalLoI with id: {}", id, e);
			throw new DatabaseOperationException("Error deleting IfvProposalLoI: " + e.getMessage());
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<IfvProposalLoIDto> findAllByIfvId(Long ifvId) {
		log.info("Finding all IfvProposalLoI by ifvId: {}", ifvId);
		try {
			if (ifvId == null) {
				throw new IllegalArgumentException("ifvId cannot be null");
			}
			S2IFVApplicationEntity applicationEntity = applicationRepository.findByIfvId(ifvId).stream().findFirst()
					.orElseThrow(() -> new IllegalStateException("Application not found for ifvId: " + ifvId));
			List<IfvProposalLoI> existingLoIs = ifvProposalLoIRepo.findAllByIfvId(ifvId);
			String addressOfTheBank = determineAddressOfTheBank(existingLoIs, applicationEntity);
			List<Long> existingPrIds = existingLoIs.stream().flatMap(loi -> Arrays.stream(loi.getPrIds().split(",")))
					.filter(s -> !s.isEmpty()).map(String::trim).map(Long::parseLong).collect(Collectors.toList());
			List<S2IFVProposedSchemaEntity> proposedSchemas = proposedSchemaRepository.findByIfvId(ifvId);
			Map<Long, S2IFVProposedSchemaEntity> originProposedSchemas = proposedSchemas.stream()
					.collect(Collectors.toMap(S2IFVProposedSchemaEntity::getPrId, Function.identity()));
			proposedSchemas.forEach(e -> {
				if (e.getPrSchemeName().equalsIgnoreCase("RMSE")) {
					e.setPrSchemeName(CommonUtil.getSchemeName(e.getPrFundname()));
				}
			});
			Map<String, List<S2IFVProposedSchemaEntity>> schemeGroups = proposedSchemas.stream()
					.filter(e -> !existingPrIds.contains(e.getPrId())).collect(Collectors.groupingBy(
							S2IFVProposedSchemaEntity::getPrSchemeName, LinkedHashMap::new, Collectors.toList()));
			List<IfvProposalLoI> newLoIs = schemeGroups
					.entrySet().stream().map(entry -> createNewLoI(entry.getKey(), entry.getValue(),
							originProposedSchemas, ifvId, addressOfTheBank, applicationEntity))
					.collect(Collectors.toList());
			List<IfvProposalLoI> allLoIs = new ArrayList<>(existingLoIs);
			allLoIs.addAll(newLoIs);

			return allLoIs.stream().map(entity -> mapper.map(entity, IfvProposalLoIDto.class))
					.collect(Collectors.toList());
		} catch (IllegalArgumentException e) {
			throw e;
		} catch (Exception e) {
			log.error("Error occurred while fetching IfvProposalLoI by ifvId: {}", ifvId, e);
			throw new DatabaseOperationException("Error fetching IfvProposalLoI by ifvId: " + e.getMessage());
		}
	}

	private String determineAddressOfTheBank(List<IfvProposalLoI> existingLoIs,
			S2IFVApplicationEntity applicationEntity) {
		if (!CollectionUtils.isEmpty(existingLoIs)) {
			return existingLoIs.get(0).getAddressOfTheBank();
		} else {
			IfvProposalLoI ifvProposalLoI = ifvProposalLoIRepo
					.findTop1ByIfvNameOrderByIdDesc(applicationEntity.getIfvName());
			if (ifvProposalLoI != null && StringUtils.hasText(ifvProposalLoI.getAddressOfTheBank())) {
				return ifvProposalLoI.getAddressOfTheBank();
			}
		}
		var loiDetail = loIDetailRepo.findTop1ByIfvNameOrderByIdDesc(applicationEntity.getIfvName());
		if (loiDetail == null || !StringUtils.hasText(loiDetail.getAddressOfTheBank())) {
			try {
				return masterCommonAPIClient.getAddressByCifNumber(applicationEntity.getCifNumber());
			} catch (Exception e) {
				log.error("Error occurred while fetching getAddressByCifNumber", e);
				return "";
			}
		}
		return loiDetail.getAddressOfTheBank();
	}

	private IfvProposalLoI createNewLoI(String schemeName, List<S2IFVProposedSchemaEntity> schemas,
			Map<Long, S2IFVProposedSchemaEntity> originProposedSchemas, Long ifvId, String addressOfTheBank,
			S2IFVApplicationEntity applicationEntity) {
		S2IFVProposedSchemaEntity originProposedSchema = originProposedSchemas.get(schemas.get(0).getPrId());
		BigDecimal totalAmount = schemas.stream().map(S2IFVProposedSchemaEntity::getPrAmount).filter(Objects::nonNull)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		String prIds = schemas.stream().map(s -> String.valueOf(s.getPrId())).collect(Collectors.joining(",")) + ",";
		IfvProposalLoI object = new IfvProposalLoI();
		object.setIfvId(ifvId);
		object.setAppNumber(applicationEntity.getAppNumber());
		object.setPrIds(prIds);
		object.setSchemeName(originProposedSchema.getPrSchemeName());
		object.setFundName(originProposedSchema.getPrFundname());
		object.setAmount(totalAmount);
		object.setAmountInWords(NumberToWordsInCrores.numberToWordsInCrores(totalAmount));
		object.setAddressOfTheBank(addressOfTheBank);
		Date appraisalDate = determineAppraisalDate(applicationEntity.getIfvAssistance(), ifvId, schemeName,
				schemas.get(0).getPrFundname());
		object.setIfvAppDated(appraisalDate);
		object.setIfvName(applicationEntity.getIfvName());
		object.setLoiNo(String.format("%s/%s/%s", applicationEntity.getAppNumber(), applicationEntity.getIfvShortName(),
				schemeName));
		return object;
	}

	private Date determineAppraisalDate(String ifvAssistance, Long ifvId, String schemeName, String fundName) {
		if (StringUtils.hasText(ifvAssistance)) {
			String regex = "(\\b\\w+\\b\\s\\d{2},\\s\\d{4})";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(ifvAssistance);
			if (matcher.find()) {
				try {
					SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy", Locale.ENGLISH);
					return dateFormat.parse(matcher.group(1));
				} catch (ParseException e) {
					log.warn("Failed to parse date from ifvAssistance: {}", matcher.group(1));
				}
			}
		}
		List<AssistanceAppliedForEntity> appliedForEntities = appliedForRepository
				.findAllByIfvIdAndSchemeNameAndFundName(ifvId, schemeName, fundName);
		if (!CollectionUtils.isEmpty(appliedForEntities)) {
			return appliedForEntities.get(0).getVideDate();
		}
		return null;
	}

	@Override
	public IfvProposalLoIDto update(Long id, IfvProposalLoIDto dto) {
		return null;
	}

	@Override
	public Page<IfvProposalLoIDto> getAllOnUserTypeOnPage(String userType, String userCode, int page, int size,
			String filters, String sorting, String globalFilter, String status) {
		log.info("getAllOnUserTypeOnPage() started in IfvProposalLoIServiceImpl for status {} ", status);
		try {

			Sort baseSort = Sort.by(Sort.Order.desc("id"));
			if (StringUtils.hasText(sorting)) {
				Sort additionalSort = SortingUtil.parseSort(sorting);
				baseSort = baseSort.and(additionalSort);
			}
			Specification<IfvProposalLoI> spec = new GenericSpecification<>(filters);
			Pageable pageable = PageRequest.of(page, size, baseSort);
			Page<IfvProposalLoI> entityPage = ifvProposalLoIRepo.findAll(spec, pageable);
			List<IfvProposalLoIDto> sanctionMinutesDTOs = entityPage.getContent().stream()
					.map(entity -> mapper.map(entity, IfvProposalLoIDto.class)).collect(Collectors.toList());
			return new PageImpl<>(sanctionMinutesDTOs, pageable, entityPage.getTotalElements());

		} catch (Exception e) {
			log.error("Error Occurred while getAllOnUserTypeOnPage IfvProposalLoIDto: {}", e);
			throw new DatabaseOperationException(
					"Error Occurred while getAllOnUserTypeOnPage IfvProposalLoIDto: " + e.getMessage());
		}
	}

	@Override
	public FileRepositoryDTO getLoIDocumentByPropLoIId(Long id) {
		log.info("getLoIDocumentByPropLoIId() started in IfvProposalLoIServiceImpl for prop loi Id {} ", id);
		try {

			S2IFVFileRepositoryEntity entity = fileRepository.findByPropLoiId(id)
					.orElse(new S2IFVFileRepositoryEntity());
			return ifvFileRepositoryEntityToDTO(entity);
		} catch (Exception e) {
			log.error("Error Occurred while getLoIDocumentByPropLoIId FileRepositoryDTO. {}", e);
			throw new DatabaseOperationException(
					"Error Occurred while getAllOnUserTypeOnPage FileRepositoryDTO: " + e.getMessage());
		}
	}

	public FileRepositoryDTO ifvFileRepositoryEntityToDTO(S2IFVFileRepositoryEntity s2ifvFileRepositoryEntity) {
		FileRepositoryDTO fileRepositoryDTO2 = new FileRepositoryDTO();
		fileRepositoryDTO2.setFileCode(s2ifvFileRepositoryEntity.getFileCode());
		fileRepositoryDTO2.setFileIfvId(s2ifvFileRepositoryEntity.getFileIfvId());
		fileRepositoryDTO2.setFileDomain(s2ifvFileRepositoryEntity.getFileDomain());
		fileRepositoryDTO2.setDateOfAction(s2ifvFileRepositoryEntity.getDateOfAction());
		fileRepositoryDTO2.setFileDataBytea(s2ifvFileRepositoryEntity.getFileData());
		fileRepositoryDTO2.setFileName(s2ifvFileRepositoryEntity.getFileName());
		fileRepositoryDTO2.setFileModule(s2ifvFileRepositoryEntity.getFileModule());
		fileRepositoryDTO2.setFileContentType(s2ifvFileRepositoryEntity.getFileContentType());
		fileRepositoryDTO2.setFileType(s2ifvFileRepositoryEntity.getFileType());
		fileRepositoryDTO2.setSancMinDetailId(s2ifvFileRepositoryEntity.getSancMinDetailId());
		fileRepositoryDTO2.setFileAlcoId(s2ifvFileRepositoryEntity.getFileAlcoId());
		fileRepositoryDTO2.setLoiId(s2ifvFileRepositoryEntity.getLoiId());
		fileRepositoryDTO2.setPropLoiId(s2ifvFileRepositoryEntity.getPropLoiId());
		return fileRepositoryDTO2;
	}

	@Override
	public List<IfvProposalLoIDto> fetchLoIDetailsByPropId(Long id) {
		try {
			IfvProposalLoIDto dto = ifvProposalLoIRepo.findById(id)
					.map(entity -> mapper.map(entity, IfvProposalLoIDto.class))
					.orElseThrow(() -> new EntityNotFoundException("IfvProposalLoI not found with id: " + id, ""));
			List<IfvProposalLoIDto> list = new ArrayList<>();
			list.add(dto);
			return list;
		} catch (Exception e) {
			log.error("Error occurred while fetching IfvProposalLoI with id: {}", id, e);
			throw new DatabaseOperationException(
					"Error retrieving IfvProposalLoI with id: " + id + " | " + e.getMessage());
		}
	}

	@Override
	public Long getCountOfLoIs() {
		try {
			return ifvProposalLoIRepo.count();
		} catch (Exception e) {
			log.error("Error occurred while fetching IfvProposalLoI ", e);
			throw new DatabaseOperationException("Error retrieving IfvProposalLoI | " + e.getMessage());
		}
	}
}