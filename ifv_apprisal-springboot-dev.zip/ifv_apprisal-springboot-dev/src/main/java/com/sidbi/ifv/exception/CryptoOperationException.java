package com.sidbi.ifv.exception;

public class CryptoOperationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CryptoOperationException(String message) {
		super(message);
	}

	public CryptoOperationException(String message, Throwable cause) {
		super(message, cause);
	}
}
