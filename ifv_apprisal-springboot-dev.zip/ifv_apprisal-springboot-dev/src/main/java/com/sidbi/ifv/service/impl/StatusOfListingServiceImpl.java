package com.sidbi.ifv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sidbi.ifv.dto.StatusOfListingDto;
import com.sidbi.ifv.entity.StatusOfListingEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.StatusOfListingRepository;
import com.sidbi.ifv.services.StatusOfListingService;

@Service
public class StatusOfListingServiceImpl implements StatusOfListingService {

	private static final Logger logger = LoggerFactory.getLogger(StatusOfListingServiceImpl.class);

	@Autowired
	private StatusOfListingRepository repository;

	@Autowired
	private ModelMapper mapper;

	String msg = "";

	@Override
	public StatusOfListingDto findById(Long id) {
		logger.info("findById() started in StatusOfListingServiceImpl for StatusOfListingEntity {} ", id);
		StatusOfListingEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("STatusOfListingEntity", id));
		return mapper.map(entity, StatusOfListingDto.class);
	}

	@Override
	public List<StatusOfListingDto> findAll() {
		logger.info("findAll() started in StatusOfListingServiceImpl of StatusOfListingEntity");
		try {
			List<StatusOfListingEntity> list = repository.findAll();
			return !list.isEmpty() ? list.stream().map(entity -> mapper.map(entity, StatusOfListingDto.class))
					.collect(Collectors.toList()) : new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all StatusOfListingEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all StatusOfListingEntities ." + msg + " ", e);
		}
	}

	@Override
	public StatusOfListingDto save(StatusOfListingDto dto) {
		logger.info("save() started in StatusOfListingServiceImpl for StatusOfListingEntity {} ", dto);
		try {
			StatusOfListingEntity entity = mapper.map(dto, StatusOfListingEntity.class);
			repository.save(entity);
			return mapper.map(entity, StatusOfListingDto.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating StatusOfListingEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  StatusOfListingEntity." + msg + " ",
					e);
		}
	}

	@Override
	public List<StatusOfListingDto> saveAll(List<StatusOfListingDto> dtos) {
		logger.info("saveAll() started in StatusOfListingServiceImpl for List of StatusOfListingEntity");
		try {

			List<StatusOfListingEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, StatusOfListingEntity.class)).collect(Collectors.toList());
			List<StatusOfListingEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, StatusOfListingDto.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all StatusOfListingEntities. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Saving all StatusOfListingEntities." + msg + " ", e);
		}
	}

	@Override
	public StatusOfListingDto update(Long id, StatusOfListingDto dto) {
		logger.info("update() started in StatusOfListingServiceImpl for StatusOfListingEntity {} {} ", id, dto);
		try {
			StatusOfListingEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("StatusOfListingEntity", id));
			BeanUtils.copyProperties(dto, existingEntity);
			repository.save(existingEntity);
			return mapper.map(existingEntity, StatusOfListingDto.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating StatusOfListingEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating StatusOfListingEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in StatusOfListingServiceImpl for StatusOfListingEntity {} ", id);
		try {
			StatusOfListingEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("StatusOfListingEntity", id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting StatusOfListingEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting StatusOfListingEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public List<StatusOfListingDto> findAllByIfvId(Long ifvId) {
		logger.info("findAllByIfvId() started in StatusOfListingServiceImpl for StatusOfListingEntity {} ", ifvId);
		try {

			List<StatusOfListingEntity> list = repository.findByIfvId(ifvId);
			return (list != null && !list.isEmpty()) ? list.stream()
					.map(StatusOfListingEntity -> mapper.map(StatusOfListingEntity, StatusOfListingDto.class))
					.collect(Collectors.toList()) : new ArrayList<>();

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while findAllByIfvId StatusOfListingEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while findAllByIfvId StatusOfListingEntity of id ." + msg + " " + ifvId, e);
		}
	}

}
