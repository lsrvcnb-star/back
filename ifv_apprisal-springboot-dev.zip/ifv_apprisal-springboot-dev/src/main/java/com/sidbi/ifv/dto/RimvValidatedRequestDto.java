package com.sidbi.ifv.dto;

import lombok.Data;

@Data
public class RimvValidatedRequestDto {

	private Long ifvRimvAppId;

	private String rimvFilePath;

	private String rimvComments;

	private String rimvStatus;

	private String singleScaleRating;

	private String combinedRating;
}
