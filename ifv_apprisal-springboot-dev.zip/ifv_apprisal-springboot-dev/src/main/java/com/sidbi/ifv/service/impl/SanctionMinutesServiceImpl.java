package com.sidbi.ifv.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sidbi.ifv.client.BankPortalClient;
import com.sidbi.ifv.dto.AppraisalMinutesDataDTO;
import com.sidbi.ifv.dto.CommonDTO;
import com.sidbi.ifv.dto.IFVMinutesCheckerDetailDTO;
import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.dto.MinutesDocumentsDto;
import com.sidbi.ifv.dto.MinutesForwardRequest;
import com.sidbi.ifv.dto.SanctionMinutesDTO;
import com.sidbi.ifv.dto.SanctionMinutesDtlDTO;
import com.sidbi.ifv.dto.UserEmailDto;
import com.sidbi.ifv.entity.AlcoMinutesDataEntity;
import com.sidbi.ifv.entity.AppraisalMinutesDataEntity;
import com.sidbi.ifv.entity.AssistanceAppliedForEntity;
import com.sidbi.ifv.entity.IFVMinutesCheckerDetail;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.entity.IfvSanctionDetailsEntity;
import com.sidbi.ifv.entity.LoIDetailEntity;
import com.sidbi.ifv.entity.MinutesDocumentsEntity;
import com.sidbi.ifv.entity.S2IFVApplicationEntity;
import com.sidbi.ifv.entity.S2IFVFileRepositoryEntity;
import com.sidbi.ifv.entity.S2IFVProposedSchemaEntity;
import com.sidbi.ifv.entity.SanctionMinutesDtlEntity;
import com.sidbi.ifv.entity.SanctionMinutesEntity;
import com.sidbi.ifv.enums.CheckerStatus;
import com.sidbi.ifv.enums.CommitteeEnum;
import com.sidbi.ifv.enums.PaymentFrequency;
import com.sidbi.ifv.enums.RefinanceApplicationStatus;
import com.sidbi.ifv.enums.SanctionStageEnum;
import com.sidbi.ifv.enums.UserDesignationEnum;
import com.sidbi.ifv.enums.UserTypeEnum;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.exception.EntityNotFoundException;
import com.sidbi.ifv.repo.AlcoMinutesDataRepository;
import com.sidbi.ifv.repo.ApplicationRepository;
import com.sidbi.ifv.repo.AppraisalMinutesDataRepository;
import com.sidbi.ifv.repo.AssistanceAppliedForRepository;
import com.sidbi.ifv.repo.CmtMemberMasterRepository;
import com.sidbi.ifv.repo.FileRepository;
import com.sidbi.ifv.repo.IFVMinutesCheckerDetailRepo;
import com.sidbi.ifv.repo.IfvApiUsersRepo;
import com.sidbi.ifv.repo.IfvBankRefinanceApplicationRepository;
import com.sidbi.ifv.repo.LoIDetailRepo;
import com.sidbi.ifv.repo.MinutesDocumentsRepo;
import com.sidbi.ifv.repo.ProposedSchemaRepository;
import com.sidbi.ifv.repo.SanctionDtRepository;
import com.sidbi.ifv.repo.SanctionMinutesDtlRepository;
import com.sidbi.ifv.repo.SanctionMinutesRepository;
import com.sidbi.ifv.services.AppraisalMinutesDataService;
import com.sidbi.ifv.services.EmailService;
import com.sidbi.ifv.services.MasterDbService;
import com.sidbi.ifv.services.SanctionMinutesService;
import com.sidbi.ifv.util.CommonUtil;
import com.sidbi.ifv.util.GenericSpecification;
import com.sidbi.ifv.util.ProfileService;
import com.sidbi.ifv.util.SortingUtil;

import jakarta.transaction.Transactional;

@Service
public class SanctionMinutesServiceImpl implements SanctionMinutesService {

	private static final Logger logger = LoggerFactory.getLogger(SanctionMinutesServiceImpl.class);

	@Autowired
	private SanctionMinutesRepository repository;

	@Autowired
	private SanctionMinutesDtlRepository sanctionMinutesDtlRepository;

	@Autowired
	private AppraisalMinutesDataRepository appraisalMinutesDataRepository;

	@Autowired
	private AlcoMinutesDataRepository alcoMinutesDataRepository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private SanctionDtRepository sanctionDtRepository;

	@Autowired
	private ProposedSchemaRepository proposedSchemaRepository;

	@Autowired
	private MasterDbService masterDbService;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private AppraisalMinutesDataService appraisalMinutesDataService;

	@Autowired
	private ApplicationRepository appRepository;

	@Autowired
	private MinutesDocumentsRepo minutesDocumentsRepo;

	@Autowired
	private LoIDetailRepo loIDetailRepo;

	@Autowired
	private AssistanceAppliedForRepository appliedForRepository;

	@Autowired
	private IfvApiUsersRepo ifvApiUsersRepo;

	@Autowired
	private IFVMinutesCheckerDetailRepo checkerDetailRepo;

	@Autowired
	private EmailService emailService;

	@Autowired
	private FileRepository fileRepository;

	@Autowired
	private CmtMemberMasterRepository cmtMemberMasterRepository;

	@Autowired
	private ProfileService profileService;

	@Autowired
	private BankPortalClient bankPortalClient;

	@Autowired
	private IfvBankRefinanceApplicationRepository ifvBankRefinanceApplicationRepository;

	String msg = "";

	private static final String SANCT_ENTITY = "SanctionMinutesEntity";

	private static final String SYSTEM = "System";

	private static final ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public SanctionMinutesDTO findById(Long id) {
		logger.info("findById() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} ", id);
		SanctionMinutesEntity entity = repository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, id));
		return mapper.map(entity, SanctionMinutesDTO.class);
	}

	@Override
	public List<SanctionMinutesDTO> findAll() {
		logger.info("findAll() started in SanctionMinutesServiceImpl of SanctionMinutesEntity");
		try {
			List<SanctionMinutesEntity> list = repository.findAll();
			return !list.isEmpty()
					? list.stream().sorted(Comparator.comparing(SanctionMinutesEntity::getSanctDetailCode).reversed())
							.map(entity -> mapper.map(entity, SanctionMinutesDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all SanctionMinutesEntities .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all SanctionMinutesEntities ." + msg + " ", e);
		}
	}

	@Override
	public SanctionMinutesDTO save(SanctionMinutesDTO dto) {
		logger.info("save() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} ", dto);
		try {
			SanctionMinutesEntity entity = mapper.map(dto, SanctionMinutesEntity.class);
			repository.save(entity);
			return mapper.map(entity, SanctionMinutesDTO.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while creating SanctionMinutesEntity. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while creating  SanctionMinutesEntity." + msg + " ",
					e);
		}
	}

	@Override
	public List<SanctionMinutesDTO> saveAll(List<SanctionMinutesDTO> dtos) {
		logger.info("saveAll() started in SanctionMinutesServiceImpl for List of SanctionMinutesEntity");
		try {

			List<SanctionMinutesEntity> entitiesToSave = dtos.stream()
					.map(dto -> mapper.map(dto, SanctionMinutesEntity.class)).collect(Collectors.toList());
			List<SanctionMinutesEntity> savedEntities = repository.saveAll(entitiesToSave);

			return savedEntities.stream().map(entity -> mapper.map(entity, SanctionMinutesDTO.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Saving all SanctionMinutesEntities. {} ", msg);
			throw new DatabaseOperationException("Error Occurred while Saving all SanctionMinutesEntities." + msg + " ",
					e);
		}
	}

	@Override
	public SanctionMinutesDTO update(Long id, SanctionMinutesDTO dto) {
		logger.info("update() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} {} ", id, dto);
		try {
			SanctionMinutesEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, id));
			BeanUtils.copyProperties(dto, existingEntity, commonUtil.getNullPropertyNames(dto));
			repository.save(existingEntity);
			return mapper.map(existingEntity, SanctionMinutesDTO.class);

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while updating SanctionMinutesEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while updating SanctionMinutesEntity of id ." + msg + " " + id + " ", e);
		}
	}

	@Override
	public void delete(Long id) {
		logger.info("delete() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} ", id);
		try {
			SanctionMinutesEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, id));
			repository.delete(existingEntity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleting SanctionMinutesEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while Deleting SanctionMinutesEntity of id ." + msg + " " + id, e);
		}

	}

	@Override
	public Long getCount(Integer committeeCode) {
		logger.info("getCount() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} ", committeeCode);
		return committeeCode != null ? repository.countByCommiteeCode(committeeCode) : repository.count();
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public Long saveSanctionMinutes(CommonDTO commonDTO) {
		logger.info("saveSanctionMinutes() started in SanctionMinutesServiceImpl for SanctionMinutesEntity ");
		try {

			List<SanctionMinutesDtlDTO> sanctionMinutesDtlDTOs = commonDTO.getSanctionMinutesDtlDTOs();
			if (sanctionMinutesDtlDTOs != null && !sanctionMinutesDtlDTOs.isEmpty()) {

				Map<String, Long> fieldCountMap = sanctionMinutesDtlDTOs.stream()
						.collect(Collectors.groupingBy(SanctionMinutesDtlDTO::getAppid, Collectors.counting()));

				boolean duplicate = fieldCountMap.values().stream().anyMatch(count -> count > 1);

				if (duplicate) {
					throw new DatabaseOperationException("Minutes Details are Duplicates with AppNo or UnitName");
				}
			}

			SanctionMinutesEntity sanctionMinutesEntity = new SanctionMinutesEntity();
			List<SanctionMinutesDtlEntity> sanctionMinutesDtlEntities = new ArrayList<>();
			SanctionMinutesDTO sanctionMinutesDTO = commonDTO.getSanctionMinutesDTO();

			String chairmanCode = sanctionMinutesDTO.getChairmanCode();

			List<String> employeCodes = new LinkedList<>();

			if (sanctionMinutesDTO.getMemberCode() != null && !sanctionMinutesDTO.getMemberCode().isEmpty()) {
				String[] memberList = sanctionMinutesDTO.getMemberCode().split(",");
				employeCodes.addAll(Arrays.asList(memberList));
			}

			if (employeCodes.contains(chairmanCode)) {
				throw new DatabaseOperationException("Please select appropriate chairman and members");
			}

			boolean isNew = !(sanctionMinutesDTO.getSanctDetailCode() != null
					&& sanctionMinutesDTO.getSanctDetailCode() > 0);

			Long count = repository.countByCommiteeCodeAndMeetingNo(sanctionMinutesDTO.getMeetingNo(),
					sanctionMinutesDTO.getCommiteeCode());

			if (count > 0) {
				throw new DatabaseOperationException("Meeting No already exists!");
			}

			sanctionMinutesEntity = setSanctionMinutesEntity(sanctionMinutesEntity, sanctionMinutesDTO, isNew);

			SanctionMinutesEntity savedsanctionMinutesEntity = repository.save(sanctionMinutesEntity);
			Long id = savedsanctionMinutesEntity.getSanctDetailCode();

			setSanctionMinutesDtDTO(sanctionMinutesDtlDTOs, sanctionMinutesDtlEntities, sanctionMinutesDTO, id);
			sanctionMinutesDtlRepository.saveAll(sanctionMinutesDtlEntities);

			return id;
		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error occurred in saveSanctionMinutes commonDto o {} ", msg);
			throw new DatabaseOperationException("Error Occurred in saving minutes ." + msg + " ", e);
		}

	}

	private SanctionMinutesEntity setSanctionMinutesEntity(SanctionMinutesEntity sanctionMinutesEntity,
			SanctionMinutesDTO sanctionMinutesDTO, boolean isNew) {
		if (isNew) {
			sanctionMinutesDTO.setSanctStage(SanctionStageEnum.CR_AGNDA.getStatus());
			sanctionMinutesDTO.setCreatedDate(new Date());
			sanctionMinutesDTO.setAgendaCreatedBy(sanctionMinutesDTO.getCreatedBy());
			sanctionMinutesEntity = mapper.map(sanctionMinutesDTO, SanctionMinutesEntity.class);
			BeanUtils.copyProperties(sanctionMinutesDTO, sanctionMinutesEntity,
					commonUtil.getNullPropertyNames(sanctionMinutesDTO));

		} else {
			sanctionMinutesDTO.setModifiedDate(new Date());
			Optional<SanctionMinutesEntity> option = repository.findById(sanctionMinutesDTO.getSanctDetailCode());
			if (option.isPresent()) {
				sanctionMinutesEntity = option.get();
				sanctionMinutesDTO.setModifiedBy(sanctionMinutesDTO.getCreatedBy());
				BeanUtils.copyProperties(sanctionMinutesDTO, sanctionMinutesEntity,
						commonUtil.getNullPropertyNames(sanctionMinutesDTO));
			}
		}
		return sanctionMinutesEntity;
	}

	private void setSanctionMinutesDtDTO(List<SanctionMinutesDtlDTO> sanctionMinutesDtlDTOs,
			List<SanctionMinutesDtlEntity> sanctionMinutesDtlEntities, SanctionMinutesDTO sanctionMinutesDTO, Long id) {
		sanctionMinutesDtlDTOs.forEach(sanctionMinutesDtlDTO -> {

			boolean newDto = !(sanctionMinutesDtlDTO.getSancDtlCode() != null
					&& sanctionMinutesDTO.getSanctDetailCode() > 0);

			if (newDto) {

				sanctionMinutesDtlDTO.setSanctStatusCode(id);
				sanctionMinutesDtlDTO.setSancStatus(SanctionStageEnum.CR_AGNDA.getStatus());
				sanctionMinutesDtlDTO.setAgendaId(sanctionMinutesDTO.getAgendaId());
				sanctionMinutesDtlDTO.setCreatedDate(sanctionMinutesDTO.getCreatedDate());
				sanctionMinutesDtlDTO.setCreatedBy(sanctionMinutesDTO.getCreatedBy());
				SanctionMinutesDtlEntity sanctionMinutesDtlEntity = mapper.map(sanctionMinutesDtlDTO,
						SanctionMinutesDtlEntity.class);
				BeanUtils.copyProperties(sanctionMinutesDtlDTO, sanctionMinutesDtlEntity,
						commonUtil.getNullPropertyNames(sanctionMinutesDtlDTO));
				sanctionMinutesDtlEntities.add(sanctionMinutesDtlEntity);

			} else {
				sanctionMinutesDtlDTO.setModifiedBy(sanctionMinutesDTO.getCreatedBy());
				sanctionMinutesDtlDTO.setModifiedDate(new Date());
				Optional<SanctionMinutesDtlEntity> option = sanctionMinutesDtlRepository
						.findById(sanctionMinutesDtlDTO.getSancDtlCode());
				if (option.isPresent()) {
					SanctionMinutesDtlEntity sanctionMinutesDtlEntity = option.get();
					BeanUtils.copyProperties(sanctionMinutesDtlDTO, sanctionMinutesDtlEntity,
							commonUtil.getNullPropertyNames(sanctionMinutesDtlDTO));
					sanctionMinutesDtlEntities.add(sanctionMinutesDtlEntity);
				}
			}
		});
	}

	@Override
	public Long circulateAllInOne(Long sancMinId) {
		logger.info("circulateAllInOne() started in SanctionMinutesServiceImpl for sancMinId {} ", sancMinId);
		try {

			SanctionMinutesEntity entity = repository.findById(sancMinId)
					.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, sancMinId));

			entity.setSanctStage(SanctionStageEnum.CIRC_AGNDA.getStatus());
			repository.save(entity);

			List<SanctionMinutesDtlEntity> dtlEntities = sanctionMinutesDtlRepository.findBySanctStatusCode(sancMinId);
			dtlEntities.forEach(e -> e.setSancStatus(SanctionStageEnum.CIRC_AGNDA.getStatus()));
			sanctionMinutesDtlRepository.saveAll(dtlEntities);
			return sancMinId;

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while circulateAllInOne sanctionMinutesEntity. {}", msg);
			throw new DatabaseOperationException("Error Occurred while circulateAllInOne sanctionMinutesEntity of id ."
					+ sancMinId + " " + msg + " ", e);
		}

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public SanctionMinutesDTO approveSanction(String status, Long id) {

		logger.info("approveSanction() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} {} ", status,
				id);
		try {
			SanctionMinutesEntity existingEntity = repository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, id));

			if (!minutesDocumentsRepo.existsByMinuteId(id)) {
				throw new EntityNotFoundException("MinutesDocumentsEntity", id);
			}

			existingEntity.setSanctStage(SanctionStageEnum.APPRV_MIN.getStatus());

			repository.save(existingEntity);

			Integer committe = existingEntity.getCommiteeCode();
			List<SanctionMinutesDtlEntity> dtlEntities = sanctionMinutesDtlRepository.findBySanctStatusCode(id);
			dtlEntities.forEach(e -> {
				if (committe.intValue() == CommitteeEnum.IFCC_CGM.getCommitteeCode()) {
					List<AppraisalMinutesDataEntity> appraisalMinutesDataEntities = appraisalMinutesDataRepository
							.findByAgendaIdAndAppId(e.getAgendaId(), e.getAppid());
					appraisalMinutesDataEntities.forEach(item -> {
						S2IFVApplicationEntity app = applicationRepository.findByAppNumber(item.getAppId()).get(0);
						List<S2IFVProposedSchemaEntity> entities = proposedSchemaRepository.findByIfvId(app.getIfvId());
						S2IFVProposedSchemaEntity proposedSchemaEntity = entities.stream()
								.filter(m -> m.getPrId().equals(item.getPrId())).findFirst().get();

						IfvSanctionDetailsEntity sanctionDtEntity = new IfvSanctionDetailsEntity();
						sanctionDtEntity.setBnlRequestNo(item.getAppId());
						sanctionDtEntity
								.setBnaApplAmt(CommonUtil.convertCoresToRupees(proposedSchemaEntity.getPrAmount()));
						sanctionDtEntity.setBnaApplSubmitDt(new Date());
						sanctionDtEntity.setBnaApplProjDesc(app.getIfvName());
						sanctionDtEntity.setBnaSancRemarks(SYSTEM);
						sanctionDtEntity.setBnaSancAuth(CommitteeEnum.IFCC_CGM.getCommitteeName());
						sanctionDtEntity.setBnlCustCd(app.getCifNumber());
						sanctionDtEntity.setBnlSanctDt(item.getCreatedDate());
						sanctionDtEntity.setBnlSanctAmt(CommonUtil.convertCoresToRupees(item.getLoanAmount()));
						sanctionDtEntity.setBnlDocRate(item.getInterestRate());
						sanctionDtEntity.setBnlFiRate(null);
						sanctionDtEntity.setBnlLdRate(null);
						sanctionDtEntity.setBnlIntFreq(null);
						sanctionDtEntity.setBnlFundCd(proposedSchemaEntity.getPrFundcode());
						sanctionDtEntity.setBnlCutOffDate(null);
						sanctionDtEntity.setBnlSchCd(proposedSchemaEntity.getPrSchemecode());
						sanctionDtEntity.setBnlMoratorium(BigDecimal.ZERO);
						sanctionDtEntity.setBnlCurrency("INR");
						sanctionDtEntity.setBnlDealwiseAverage(BigDecimal.ZERO);
						sanctionDtEntity.setBnlIncrementCostBorrow(BigDecimal.ZERO);
						sanctionDtEntity.setBnlSlAcctNo(null);
						sanctionDtEntity.setBnlSrNo(item.getId());
						sanctionDtEntity.setBnlPrincipalRepayment(item.getPrincipalRepayment());
						sanctionDtEntity.setBnlTenure(item.getTenure());
						sanctionDtEntity.setBnlInterestType(item.getInterestType());
						sanctionDtEntity.setBnlBenchmark(item.getBenchMark());
						sanctionDtEntity.setBnlSpread(item.getSpread());
						sanctionDtEntity.setBnlInterestReset(item.getInterestReset());
						sanctionDtEntity.setBnlMaturityDate(item.getMaturityDate());

						sanctionDtRepository.save(sanctionDtEntity);

						masterDbService.saveSanctionDt(sanctionDtEntity);
					});

				}

				if (committe.intValue() == CommitteeEnum.SUB_ALCO.getCommitteeCode()) {
					List<AlcoMinutesDataEntity> alcoMinutesDataEntities = alcoMinutesDataRepository
							.findByAgendaIdAndAppId(e.getAgendaId(), e.getAppid());

					alcoMinutesDataEntities.forEach(item -> {

						IfvSanctionDetailsEntity sanctionDtEntity = new IfvSanctionDetailsEntity();
						sanctionDtEntity.setBnlRequestNo(item.getAppId());
						sanctionDtEntity.setBnaApplAmt(item.getAmount());
						sanctionDtEntity.setBnaApplSubmitDt(new Date());
						sanctionDtEntity.setBnaApplProjDesc(item.getBankName());
						sanctionDtEntity.setBnaSancRemarks(SYSTEM);
						sanctionDtEntity.setBnaSancAuth(CommitteeEnum.SUB_ALCO.getCommitteeName());
						sanctionDtEntity.setBnlSanctDt(item.getCreatedDate());
						sanctionDtEntity.setBnlSanctAmt(item.getAmount());
						sanctionDtEntity.setBnlDocRate(item.getInterestRate());
						sanctionDtEntity.setBnlFiRate(null);
						sanctionDtEntity.setBnlLdRate(null);
						sanctionDtEntity.setBnlIntFreq(null);
						sanctionDtEntity.setBnlFundCd(item.getFundCode());
						sanctionDtEntity.setBnlCutOffDate(null);
						sanctionDtEntity.setBnlSchCd(item.getSchemeCode());
						sanctionDtEntity.setBnlMoratorium(BigDecimal.ZERO);
						sanctionDtEntity.setBnlCurrency("INR");
						sanctionDtEntity.setBnlDealwiseAverage(BigDecimal.ZERO);
						sanctionDtEntity.setBnlIncrementCostBorrow(BigDecimal.ZERO);
						sanctionDtEntity.setBnlSlAcctNo(null);
						sanctionDtRepository.save(sanctionDtEntity);
						masterDbService.saveSanctionDt(sanctionDtEntity);
					});
				}
			});

			return mapper.map(existingEntity, SanctionMinutesDTO.class);

		} catch (Exception e) {
			e.printStackTrace();
			msg = e.getMessage();
			logger.error("Error Occurred while approveSanction SanctionMinutesEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while approveSanction SanctionMinutesEntity of id ." + msg + " " + id + " ", e);
		}

	}

	@Override
	public Long checkMeetingNoExistence(Integer meetingNo, Integer committee) {

		return repository.countByCommiteeCodeAndMeetingNo(committee, meetingNo);
	}

	@Override
	public List<AppraisalMinutesDataDTO> getAllAppraisalMinutesDataBySancId(Long sancId) {
		logger.info("getAllAppraisalMinutesDataBySancId() started in SanctionMinutesServiceImpl ");
		try {
			List<SanctionMinutesDtlEntity> dtlEntities = sanctionMinutesDtlRepository.findBySanctStatusCode(sancId);
			List<AppraisalMinutesDataDTO> alcoMinutesDataDTOs = new ArrayList<>();
			dtlEntities.forEach(e -> alcoMinutesDataDTOs
					.addAll(appraisalMinutesDataService.getAllAppraisalMinutesDataBySancDtlCode(e.getSancDtlCode())));

			alcoMinutesDataDTOs.forEach(e -> {
				if (e.getSchemeName().toUpperCase().contains("RMSE")) {
					e.setSchemeName(this.getSchemeName(e.getFundName()));
				}
			});

			// Group by both schemeName and appId
			return alcoMinutesDataDTOs.stream()
					.collect(Collectors.groupingBy(
							dto -> new AbstractMap.SimpleEntry<>(dto.getSchemeName(), dto.getAppId()),
							Collectors.reducing(new AppraisalMinutesDataDTO(), // initial value
									(dto1, dto2) -> {
										AppraisalMinutesDataDTO mergedDTO = new AppraisalMinutesDataDTO();
										if (dto1.getId() == null) {
											// If this is the first element, copy from dto2
											copyFields(mergedDTO, dto2);
											mergedDTO.setLoanAmount(dto2.getLoanAmount() != null ? dto2.getLoanAmount()
													: BigDecimal.ZERO);
										} else {
											// Copy from dto1 and add loan amounts
											copyFields(mergedDTO, dto1);
											BigDecimal totalLoanAmount = (dto1.getLoanAmount() != null
													? dto1.getLoanAmount()
													: BigDecimal.ZERO)
													.add(dto2.getLoanAmount() != null ? dto2.getLoanAmount()
															: BigDecimal.ZERO);
											mergedDTO.setLoanAmount(totalLoanAmount);
										}
										return mergedDTO;
									})))
					.values().stream()
					.sorted(Comparator.comparing(AppraisalMinutesDataDTO::getSchemeName)
							.thenComparing(AppraisalMinutesDataDTO::getAppId)
							.thenComparing(AppraisalMinutesDataDTO::getId))
					.collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while Finding all AppraisalMinutesDataBySancId. {} {} ", sancId, msg);
			throw new DatabaseOperationException(
					"Error Occurred while Finding all AppraisalMinutesDataBySancId." + msg + " ", e);
		}
	}

	private void copyFields(AppraisalMinutesDataDTO target, AppraisalMinutesDataDTO source) {
		target.setId(source.getId());
		target.setSancDtlCode(source.getSancDtlCode());
		target.setAgendaNo(source.getAgendaNo());
		target.setAgendaId(source.getAgendaId());
		target.setAppId(source.getAppId());
		target.setBankName(source.getBankName());
		target.setSchemeName(source.getSchemeName());
		target.setFundName(source.getFundName());
		target.setFundCode(source.getFundCode());
		target.setInterestRate(source.getInterestRate());
		target.setTenure(source.getTenure());
		target.setPrincipalRepayment(source.getPrincipalRepayment());
		target.setCreatedBy(source.getCreatedBy());
		target.setCreatedDate(source.getCreatedDate());
		target.setModifiedBy(source.getModifiedBy());
		target.setModifiedDate(source.getModifiedDate());
		target.setStatus(source.getStatus());
		target.setSchemeCode(source.getSchemeCode());
		target.setPrId(source.getPrId());
	}

	public String getSchemeName(String schemeName) {
		String wordToFind = "FUND";
		int index = schemeName.indexOf(wordToFind);
		if (index != -1) {
			return schemeName.substring(0, index).trim();
		}
		return schemeName;
	}

	@Override
	public String getAppraisalDateByAppId(String appNo, Long minuteId) {
		logger.info("Getting appraisal date for appNo: {} and minuteId: {}", appNo, minuteId);
		try {

			String appraisalDate = "";

			S2IFVApplicationEntity entity = appRepository.findByAppNumber(appNo).get(0);

			String ifvAssistance = entity.getIfvAssistance();

			if (StringUtils.hasText(ifvAssistance)) {
				String regex = "(\\b\\w+\\b\\s\\d{2},\\s\\d{4})";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(ifvAssistance);
				if (matcher.find()) {
					appraisalDate = matcher.group(1);
				}
			} else {
				AppraisalMinutesDataEntity appraisalMinutesDataEntity = appraisalMinutesDataRepository
						.findById(minuteId).orElse(null);

				if (appraisalMinutesDataEntity != null) {
					String fundName = appraisalMinutesDataEntity.getFundName();
					String schemeName = appraisalMinutesDataEntity.getSchemeName();

					List<AssistanceAppliedForEntity> appliedForEntities = appliedForRepository
							.findAllByIfvIdAndSchemeNameAndFundName(entity.getIfvId(), schemeName, fundName);

					if (!CollectionUtils.isEmpty(appliedForEntities)) {
						Date date = appliedForEntities.get(0).getVideDate();

						LocalDate localDate = date.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
						appraisalDate = localDate.format(formatter);
					}
				}

			}

			return appraisalDate;
		} catch (Exception e) {
			throw new DatabaseOperationException("Failed to get appraisal date: " + e.getMessage(), e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public Long forwardMinutes(Long sancMinId, int stage, String empId) {
		logger.info("forwardMinutes() started in SanctionMinutesServiceImpl for sancMinId {} ", sancMinId);
		try {

			SanctionMinutesEntity entity = repository.findById(sancMinId)
					.orElseThrow(() -> new EntityNotFoundException("sanctionMinutesEntity", sancMinId));

			entity.setSanctStage(SanctionStageEnum.LOCK.getStatus());
			if (stage == 1) {
				entity.setForwardedStage1User(empId);
				entity.setForwardedStage1DateTime(LocalDateTime.now());
			} else if (stage == 2) {
				entity.setForwardedStage2User(empId);
				entity.setForwardedStage2DateTime(LocalDateTime.now());
			} else {
				throw new DatabaseOperationException("Error Occurred while forwarding minutes...");
			}
			entity.setCurrentUserEmpId(empId);

			repository.save(entity);

			return sancMinId;

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while forwardMinutes sanctionMinutesEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while forwardMinutes sanctionMinutesEntity of id ." + sancMinId + " " + msg + " ",
					e);
		}
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public Long rejectMinutes(Long sancMinId) {
		logger.info("forwardMinutes() started in SanctionMinutesServiceImpl for sancMinId {} ", sancMinId);
		try {

			SanctionMinutesEntity entity = repository.findById(sancMinId)
					.orElseThrow(() -> new EntityNotFoundException("sanctionMinutesEntity", sancMinId));

			entity.setSanctStage(SanctionStageEnum.CR_AGNDA.getStatus());
			entity.setForwardedStage1User(null);
			entity.setForwardedStage1DateTime(null);
			entity.setForwardedStage2User(null);
			entity.setForwardedStage2DateTime(null);
			entity.setCurrentUserEmpId(null);
			repository.save(entity);

			return sancMinId;

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while forwardMinutes sanctionMinutesEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while forwardMinutes sanctionMinutesEntity of id ." + sancMinId + " " + msg + " ",
					e);
		}
	}

	@Override
	public Page<SanctionMinutesDTO> getAllOnUserTypeOnPage(String userType, String userCode, int page, int size,
			String filters, String sorting, String globalFilter, String status) {
		logger.info("getAllOnUserTypeOnPage() started in SanctionMinutesServiceImpl for status {} ", status);
		try {

			Sort baseSort = Sort.by(Sort.Order.desc("sanctDetailCode"));
			if (StringUtils.hasText(sorting)) {
				Sort additionalSort = SortingUtil.parseSort(sorting);
				baseSort = baseSort.and(additionalSort);
			}

			List<String> sanctStages = switch (status) {
			case "LOI" -> List.of(SanctionStageEnum.APPRV_MIN.getStatus());
			case "AP" -> List.of(SanctionStageEnum.APPRV_MIN.getStatus());
			default -> {
				yield userType.equals(UserTypeEnum.MAKER.getUserType())
						|| userType.equals(UserTypeEnum.ADMIN_CHECKER.getUserType())
						|| userType.equals(UserTypeEnum.CHECKER.getUserType())
								? List.of(SanctionStageEnum.CR_AGNDA.getStatus(), SanctionStageEnum.LOCK.getStatus())
								: List.of(SanctionStageEnum.LOCK.getStatus());
			}
			};

			Specification<SanctionMinutesEntity> spec = new GenericSpecification<>(filters);
			spec = spec.and((root, query, cb) -> root.get("sanctStage").in(sanctStages));
			if (userType.equals(UserTypeEnum.HIGHER_AUTHORITY.getUserType()) && !"AP".equalsIgnoreCase(status)
					&& !"LOI".equalsIgnoreCase(status)) {
				IfvApiUsersEntity apiCurrentUsersEntity = ifvApiUsersRepo.findByOfrEmpId(userCode);
				Long ofrCode = apiCurrentUsersEntity.getOfrCode().longValue();
				spec = spec.and((root, query, cb) -> cb.and(cb.isNotNull(root.get("currentCheckerId")),
						cb.equal(root.get("currentCheckerId"), ofrCode)));
			}

			Pageable pageable = PageRequest.of(page, size, baseSort);
			Page<SanctionMinutesEntity> entityPage = repository.findAll(spec, pageable);

			List<SanctionMinutesDTO> sanctionMinutesDTOs = entityPage.getContent().stream()
					.map(entity -> mapper.map(entity, SanctionMinutesDTO.class)).collect(Collectors.toList());

			if (!"AP".equalsIgnoreCase(status) && !"LOI".equalsIgnoreCase(status)) {
				sanctionMinutesDTOs.forEach(e -> {
					IFVMinutesCheckerDetail checkerDetail = checkerDetailRepo
							.findTop1ByMinuteIdOrderByIdDesc(e.getSanctDetailCode());

					if (checkerDetail != null) {
						String remarks = checkerDetail.getCurrentUserAction() + " By "
								+ checkerDetail.getCurrentUserName() + " To " + checkerDetail.getForwardedUserName();
						e.setRemarks(remarks);
					}

				});
			}

			return new PageImpl<>(sanctionMinutesDTOs, pageable, entityPage.getTotalElements());

		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while getAllOnUserTypeOnPage sanctionMinutesEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while getAllOnUserTypeOnPage sanctionMinutesEntity of id ." + status + " " + msg
							+ " ",
					e);
		}
	}

	@Override
	public Map<String, Long> getStatusCounts(String userType, Long userCode) {
		logger.info("getStatusCounts() started in SanctionMinutesServiceImpl");
		try {
			SanctionMinutesRepository.StatusCount counts;
			List<String> sanctStages = switch (userType) {
			case "9092", "9128", "9093" ->
				List.of(SanctionStageEnum.CR_AGNDA.getStatus(), SanctionStageEnum.LOCK.getStatus());
			default -> List.of(SanctionStageEnum.LOCK.getStatus());
			};
			if (userType.equals("9095")) {
				counts = repository.getStatusCounts(sanctStages, userCode);
			} else {
				counts = repository.getStatusCounts(sanctStages);
			}

			return Map.of("LOI", counts.getApprovedCount(), "MIN", counts.getNonApprovedCount());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while getStatusCounts sanctionMinutesEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while getStatusCounts sanctionMinutesEntity of id: " + msg + " ", e);
		}
	}

	@Override
	@Transactional
	public MinutesDocumentsDto saveOrUpdateDocument(MinutesDocumentsDto dto) {
		logger.info("saveOrUpdateDocument() started for minuteId: {}", dto.getMinuteId());
		try {
			MultipartFile file = dto.getFile();
			// Validate file basics
			if (file == null || file.isEmpty()) {
				throw new IllegalArgumentException("File is empty or not provided");
			}
			if (file.getSize() > 5 * 1024 * 1024) {
				throw new IllegalArgumentException("File size exceeds 5MB limit");
			}
			if (!"application/pdf".equals(file.getContentType())) {
				throw new IllegalArgumentException("Only PDF files are allowed");
			}

			// Read the file content
			byte[] content = file.getBytes();

			MinutesDocumentsEntity entity = minutesDocumentsRepo.findByMinuteId(dto.getMinuteId())
					.orElse(new MinutesDocumentsEntity());
			entity.setModule(dto.getModule());
			entity.setMinuteId(dto.getMinuteId());
			entity.setStatus(dto.getStatus());
			entity.setUploadedUserId(dto.getUploadedUserId());
			entity.setDocumentName(file.getOriginalFilename());
			entity.setDocumentType(file.getContentType());
			entity.setDocumentContent(content);
			if (entity.getId() == null) {
				entity.setCreatedBy(dto.getCreatedBy());
			}
			entity.setUpdatedBy(dto.getCreatedBy());
			logger.info("Saving document: name={}, type={}, size={}, minuteId={}, uploadedUserId={}",
					entity.getDocumentName(), entity.getDocumentType(), entity.getDocumentContent().length,
					entity.getMinuteId(), entity.getUploadedUserId());
			MinutesDocumentsEntity savedEntity = minutesDocumentsRepo.save(entity);
			MinutesDocumentsDto savedDto = new MinutesDocumentsDto();
			BeanUtils.copyProperties(savedEntity, savedDto);
			savedDto.setFile(null);
			return savedDto;
		} catch (IOException e) {
			throw new DatabaseOperationException("Error reading file content", e);
		} catch (Exception e) {
			throw new DatabaseOperationException("Error occurred while saving or updating document: " + e.getMessage(),
					e);
		}
	}

	@Override
	public MinutesDocumentsDto getDocumentByMinuteId(Long minuteId) {
		logger.info("getDocumentsByMinuteId() started in SanctionMinutesServiceImpl for minuteId {} ", minuteId);
		try {

			MinutesDocumentsEntity entity = minutesDocumentsRepo.findByMinuteId(minuteId)
					.orElse(new MinutesDocumentsEntity());

			return mapper.map(entity, MinutesDocumentsDto.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while getDocumentsByMinuteId MinutesDocumentsEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while getDocumentsByMinuteId MinutesDocumentsEntity of id: " + msg + " ", e);
		}

	}

	@Override
	public MinutesDocumentsDto getDocumentById(Long id) {
		logger.info("getDocument() started in SanctionMinutesServiceImpl for minuteId {} ", id);
		try {

			MinutesDocumentsEntity entity = minutesDocumentsRepo.findById(id).orElse(new MinutesDocumentsEntity());

			return mapper.map(entity, MinutesDocumentsDto.class);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while getDocument MinutesDocumentsEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while getDocument MinutesDocumentsEntity of id: " + msg + " ", e);
		}
	}

	@Override
	public void deleteDocument(Long id) {
		logger.info("deleteDocument() started in SanctionMinutesServiceImpl for minuteId {} ", id);
		try {
			MinutesDocumentsEntity entity = minutesDocumentsRepo.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("MinutesDocumentsEntity", id));
			minutesDocumentsRepo.delete(entity);
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while deleteDocument MinutesDocumentsEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while deleteDocument MinutesDocumentsEntity of id: " + msg + " ", e);
		}

	}

	@Override
	public Map<Long, Long> getMinuteIdByLoiIdAndPrId(Long loiId, Long prId) {
		logger.info("getMinuteIdBySanctionDtlCode() started in SanctionMinutesServiceImpl for minuteId {} ", loiId);
		try {

			LoIDetailEntity loIDetailEntity = loIDetailRepo.findById(loiId)
					.orElseThrow(() -> new EntityNotFoundException("LoIDetailEntity", loiId));

			SanctionMinutesDtlEntity sanctionMinutesDtlEntity = sanctionMinutesDtlRepository
					.findBySancDtlCode(loIDetailEntity.getSancDetailId());

			AppraisalMinutesDataEntity entity = appraisalMinutesDataRepository
					.findBySancDtlCodeAndAgendaIdAndAppIdAndPrId(sanctionMinutesDtlEntity.getSancDtlCode(),
							sanctionMinutesDtlEntity.getAgendaId(), sanctionMinutesDtlEntity.getAppid(), prId);

			Map<Long, Long> map = new HashMap<>();
			map.put(loIDetailEntity.getSancDetailId(), entity.getId());
			return map;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while getMinuteIdBySanctionDtlCode MinutesDocumentsEntity. {}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while getMinuteIdBySanctionDtlCode MinutesDocumentsEntity of id: " + msg + " ", e);
		}
	}

	@Override
	@org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
	public List<Long> approveSanctionMinutes(Long mtCode, Integer userId) {

		logger.info("approveSanctionMinutes() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} {} ",
				mtCode, userId);
		try {
			SanctionMinutesEntity existingEntity = repository.findById(mtCode)
					.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, mtCode));

			FileInfo fileInfo = getFileInfo(mtCode);

			if (!StringUtils.hasText(fileInfo.fileName())) {
				throw new DatabaseOperationException("Flash Minutes is required");
			}

			existingEntity.setSanctStage(SanctionStageEnum.APPRV_MIN.getStatus());

			repository.save(existingEntity);

			MinutesDocumentsEntity minutesDocumentsEntity = minutesDocumentsRepo.findByMinuteId(mtCode).orElse(null);
			IfvApiUsersEntity apiCurrentUsersEntity = ifvApiUsersRepo.findByOfrCode(userId);
			LocalDateTime localDateTime = LocalDateTime.now();
			IFVMinutesCheckerDetail detail = new IFVMinutesCheckerDetail();
			detail.setMinuteId(mtCode);
			detail.setMinuteFileId(minutesDocumentsEntity != null ? minutesDocumentsEntity.getId() : null);
			detail.setStatus(CheckerStatus.APPROVE.getStatusFlag());
			detail.setCurrentUserId(Long.valueOf(userId));
			detail.setCurrentUserName(apiCurrentUsersEntity.getOfrShortName());
			detail.setCurrentUserDesignation(
					UserDesignationEnum.getNameByCode(apiCurrentUsersEntity.getOfrDesgCode().intValue()));
			detail.setCurrentUserAction("Approve");
			detail.setDateTimeOfAction(localDateTime);

			IFVMinutesCheckerDetail detail2 = checkerDetailRepo.findTop1ByMinuteIdOrderByIdDesc(mtCode);

			extracted(localDateTime, detail, detail2);

			checkerDetailRepo.save(detail);

			List<Long> minuteIds = new ArrayList<>();

			Integer committe = existingEntity.getCommiteeCode();
			List<SanctionMinutesDtlEntity> dtlEntities = sanctionMinutesDtlRepository.findBySanctStatusCode(mtCode);
			dtlEntities.forEach(e -> {
				if (committe.intValue() == CommitteeEnum.IFCC_CGM.getCommitteeCode()) {
					List<AppraisalMinutesDataEntity> appraisalMinutesDataEntities = appraisalMinutesDataRepository
							.findByAgendaIdAndAppId(e.getAgendaId(), e.getAppid());
					appraisalMinutesDataEntities.forEach(item -> {

						String benchMarkRate = null;
						if (StringUtils.hasText(item.getBenchMark())) {
							benchMarkRate = masterDbService.getBenchMarkRateByName(item.getBenchMark());
						}

						S2IFVApplicationEntity app = applicationRepository.findByAppNumber(item.getAppId()).get(0);
						List<S2IFVProposedSchemaEntity> entities = proposedSchemaRepository.findByIfvId(app.getIfvId());
						S2IFVProposedSchemaEntity proposedSchemaEntity = entities.stream()
								.filter(m -> m.getPrId().equals(item.getPrId())).findFirst().get();

						List<AssistanceAppliedForEntity> appliedForEntities = appliedForRepository
								.findAllByIfvIdAndSchemeNameAndFundName(proposedSchemaEntity.getIfvId(),
										proposedSchemaEntity.getPrSchemeName(), proposedSchemaEntity.getPrFundname());

						Date sancDate = item.getCreatedDate();
						sancDate = getSancDate(app, appliedForEntities, sancDate);

						BigDecimal tranche = null;

						tranche = getTranche(proposedSchemaEntity, tranche);

						String intFrequency = PaymentFrequency.fromDescription(item.getPrincipalRepayment().trim())
								.getCode().toString();

						IfvSanctionDetailsEntity sanctionDtEntity = new IfvSanctionDetailsEntity();
						sanctionDtEntity.setBnlRequestNo(item.getAppId());
						sanctionDtEntity
								.setBnaApplAmt(CommonUtil.convertCoresToRupees(proposedSchemaEntity.getPrAmount()));
						sanctionDtEntity.setBnaApplSubmitDt(sancDate);
						sanctionDtEntity.setBnaApplProjDesc(app.getIfvName());
						sanctionDtEntity.setBnaSancRemarks(SYSTEM);
						sanctionDtEntity.setBnaSancAuth(CommitteeEnum.IFCC_CGM.getCommitteeName());
						sanctionDtEntity.setBnlCustCd(app.getCifNumber());
						sanctionDtEntity.setBnlSanctDt(existingEntity.getMeetingDate());
						sanctionDtEntity.setBnlSanctAmt(CommonUtil.convertCoresToRupees(item.getLoanAmount()));
						sanctionDtEntity.setBnlDocRate(item.getInterestRate());
						sanctionDtEntity.setBnlFiRate(item.getInterestRate());
						sanctionDtEntity.setBnlLdRate(null);
						sanctionDtEntity.setBnlIntFreq(null);
						sanctionDtEntity.setBnlFundCd(proposedSchemaEntity.getPrFundcode());
						sanctionDtEntity.setBnlCutOffDate(null);
						sanctionDtEntity.setBnlSchCd(proposedSchemaEntity.getPrSchemecode());
						BigDecimal moratoriumPeriod = proposedSchemaEntity.getPrMoratoriumPeriod() != null
								? BigDecimal.valueOf(proposedSchemaEntity.getPrMoratoriumPeriod())
								: BigDecimal.ZERO;
						sanctionDtEntity.setBnlMoratorium(moratoriumPeriod);
						sanctionDtEntity.setBnlCurrency("INR");
						sanctionDtEntity.setBnlDealwiseAverage(proposedSchemaEntity.getDealwiseAverage());
						sanctionDtEntity.setBnlIncrementCostBorrow(proposedSchemaEntity.getIncrementalCostBorrowing());
						sanctionDtEntity.setBnlSlAcctNo(null);
						sanctionDtEntity.setBnlSrNo(item.getId());
						sanctionDtEntity.setBnlInterestType(item.getInterestType());
						sanctionDtEntity.setBnlBenchmark(benchMarkRate);
						sanctionDtEntity.setBnlSpread(item.getSpread());
						sanctionDtEntity.setBnlInterestReset(item.getInterestReset());
						sanctionDtEntity.setBnlMaturityDate(item.getMaturityDate());
						sanctionDtEntity.setBnlPrincipalRepayment(intFrequency);
						sanctionDtEntity.setBnlTenure(item.getTenure());
						sanctionDtEntity.setTranche(tranche);
						sanctionDtEntity.setIncrementalCostBorrowingType(
								proposedSchemaEntity.getIncrementalCostBorrowingType());
						sanctionDtEntity.setIcbFixedFloating(proposedSchemaEntity.getIcbFixedFloating());
						sanctionDtEntity.setIcbBenchMark(proposedSchemaEntity.getIcbBenchMark());
						sanctionDtEntity.setIcbSpread(proposedSchemaEntity.getIcbSpread());

						sanctionDtRepository.save(sanctionDtEntity);
						minuteIds.add(item.getId());
					});
				}
			});

			return minuteIds;
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while approveSanctionMinutes SanctionMinutesEntity. {} ", msg);
			throw new DatabaseOperationException(
					"Error Occurred while approveSanctionMinutes SanctionMinutesEntity of id ." + msg + " " + mtCode
							+ " ",
					e);
		}

	}

	private void extracted(LocalDateTime localDateTime, IFVMinutesCheckerDetail detail,
			IFVMinutesCheckerDetail detail2) {
		if (detail2 != null && detail2.getDateTimeOfAction() != null) {
			detail.setDateTimeOfReceipt(detail2.getDateTimeOfAction());
		} else {
			detail.setDateTimeOfReceipt(localDateTime);
		}
	}

	private BigDecimal getTranche(S2IFVProposedSchemaEntity proposedSchemaEntity, BigDecimal tranche) {
		if (!proposedSchemaEntity.getPrFundcode().equals("01") && !proposedSchemaEntity.getPrFundcode().equals("59")
				&& !proposedSchemaEntity.getPrFundcode().equals("75")) {
			tranche = proposedSchemaEntity.getTranche();
		}
		return tranche;
	}

	private Date getSancDate(S2IFVApplicationEntity app, List<AssistanceAppliedForEntity> appliedForEntities,
			Date sancDate) {
		if (!CollectionUtils.isEmpty(appliedForEntities)) {
			sancDate = appliedForEntities.get(0).getVideDate();
		} else {
			if (StringUtils.hasText(app.getIfvAssistance())) {
				String regex = "(\\b\\w+\\b\\s\\d{2},\\s\\d{4})";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(app.getIfvAssistance());
				if (matcher.find()) {
					try {
						SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy", Locale.ENGLISH);
						sancDate = dateFormat.parse(matcher.group(1));
					} catch (ParseException ex) {
						logger.warn("Failed to parse date from ifvAssistance: {}", matcher.group(1));
					}
				}
			}
		}
		return sancDate;
	}

	@Override
	public Boolean fwdOrRejMinutes(MinutesForwardRequest forwardRequest) {
		logger.info("fwdOrRejMinutes() started in SanctionMinutesServiceImpl for SanctionMinutesEntity {} ",
				forwardRequest.getFwdRejFlag());
		try {
			Long minuteId = forwardRequest.getMinuteId();

			MinutesDocumentsEntity minutesDocumentsEntity = minutesDocumentsRepo.findByMinuteId(minuteId).orElse(null);

			IfvApiUsersEntity apiUsersEntity = ifvApiUsersRepo.findByOfrCode(forwardRequest.getCheckerId().intValue());
			IfvApiUsersEntity apiCurrentUsersEntity = ifvApiUsersRepo
					.findByOfrCode(forwardRequest.getOfrCode().intValue());

			SanctionMinutesEntity existingEntity = repository.findById(minuteId)
					.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, minuteId));

			boolean isForwarding = forwardRequest.getFwdRejFlag().equals(CheckerStatus.FORWARD.getStatusFlag());
			String action = isForwarding ? "Accept and Forward" : "Reject";

			if (apiCurrentUsersEntity.getOfrType().equalsIgnoreCase(UserTypeEnum.MAKER.getUserType())) {
				action = "Originator";
			}

			if (apiUsersEntity.getOfrType().trim().equalsIgnoreCase(UserTypeEnum.MAKER.getUserType())) {
				existingEntity.setSanctStage(SanctionStageEnum.CR_AGNDA.getStatus());
			} else {
				existingEntity.setSanctStage(SanctionStageEnum.LOCK.getStatus());
			}

			existingEntity.setCurrentCheckerId(forwardRequest.getCheckerId());

			repository.save(existingEntity);

			String ofrName = apiUsersEntity.getOfrName();
			if (apiUsersEntity.getOfrShortName() != null && !apiUsersEntity.getOfrShortName().isEmpty()) {
				ofrName = apiUsersEntity.getOfrShortName();
			}

			LocalDateTime localDateTime = LocalDateTime.now();

			IFVMinutesCheckerDetail detail = new IFVMinutesCheckerDetail();
			detail.setMinuteId(minuteId);
			detail.setMinuteFileId(minutesDocumentsEntity != null ? minutesDocumentsEntity.getId() : null);
			detail.setStatus(
					isForwarding ? CheckerStatus.FORWARD.getStatusFlag() : CheckerStatus.REJECT.getStatusFlag());
			detail.setCurrentUserComment(forwardRequest.getComment());
			detail.setCurrentUserId(forwardRequest.getOfrCode());
			detail.setCurrentUserName(forwardRequest.getUserName());
			detail.setCurrentUserDesignation(
					UserDesignationEnum.getNameByCode(apiCurrentUsersEntity.getOfrDesgCode().intValue()));
			detail.setCurrentUserAction(action);
			detail.setDateTimeOfAction(localDateTime);

			IFVMinutesCheckerDetail detail2 = checkerDetailRepo.findTop1ByMinuteIdOrderByIdDesc(minuteId);

			if (detail2 != null && detail2.getDateTimeOfAction() != null) {
				detail.setDateTimeOfReceipt(detail2.getDateTimeOfAction());
			} else {
				detail.setDateTimeOfReceipt(localDateTime);
			}

			detail.setForwardedUserId(forwardRequest.getCheckerId());
			detail.setForwardedUserName(ofrName);
			detail.setForwardedUserDesignation(
					UserDesignationEnum.getNameByCode(apiUsersEntity.getOfrDesgCode().intValue()));

			checkerDetailRepo.save(detail);

			return true;
		} catch (Exception e) {
			throw new DatabaseOperationException("Unable to forward the document due to unexpected error", e);
		}
	}

	@Override
	public List<IFVMinutesCheckerDetailDTO> getMinutesFwdRejDetails(Long minuteId) {
		logger.info("getMinutesFwdRejDetails() started in SanctionMinutesServiceImpl of IFVMinutesCheckerDetailDTO");
		try {
			List<IFVMinutesCheckerDetail> list = checkerDetailRepo.findAllByMinuteId(minuteId);
			return !list.isEmpty() ? list.stream().sorted(Comparator.comparing(IFVMinutesCheckerDetail::getId))
					.map(entity -> mapper.map(entity, IFVMinutesCheckerDetailDTO.class)).collect(Collectors.toList())
					: new ArrayList<>();
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IFVMinutesCheckerDetailDTO .{}", msg);
			throw new DatabaseOperationException(
					"Error Occurred while fetching all IFVMinutesCheckerDetailDTO ." + msg + " ", e);
		}
	}

	@Override
	public List<IfvApiUsersDTO> getUserListForRejectingMinutes(Long minuteId) {
		logger.info("getUserListForRejectingMinutes() started in SanctionMinutesServiceImpl of IfvApiUsersDTO");
		try {
			List<IFVMinutesCheckerDetail> checkerDetails = checkerDetailRepo.findAllByMinuteId(minuteId);
			Integer lastUserId = checkerDetails.stream().max(Comparator.comparing(IFVMinutesCheckerDetail::getId))
					.map(detail -> detail.getForwardedUserId().intValue())
					.orElseThrow(() -> new IllegalStateException("No checker details found"));
			IfvApiUsersEntity fwdUsersEntity = ifvApiUsersRepo.findByOfrCode(lastUserId);
			List<Integer> lUserDesigCode = switch (fwdUsersEntity.getOfrDesgCode().intValue()) {
			case 26 -> List.of(UserDesignationEnum.MANAGER.getCode());
			case 20 ->
				List.of(UserDesignationEnum.MANAGER.getCode(), UserDesignationEnum.ASSISTANT_GENERAL_MANAGER.getCode());
			case 12 ->
				List.of(UserDesignationEnum.MANAGER.getCode(), UserDesignationEnum.ASSISTANT_GENERAL_MANAGER.getCode(),
						UserDesignationEnum.DEPUTY_GENERAL_MANAGER.getCode());
			case 9 ->
				List.of(UserDesignationEnum.MANAGER.getCode(), UserDesignationEnum.ASSISTANT_GENERAL_MANAGER.getCode(),
						UserDesignationEnum.DEPUTY_GENERAL_MANAGER.getCode(),
						UserDesignationEnum.GENERAL_MANAGER.getCode());
			default -> List.of();
			};
			List<Integer> lUserIds = checkerDetails.stream().map(m -> m.getCurrentUserId().intValue()).distinct()
					.collect(Collectors.toList());
			return ifvApiUsersRepo.findAllByOfrCodeIn(lUserIds).stream()
					.filter(e -> lUserDesigCode.contains(e.getOfrDesgCode()))
					.map(entity -> mapper.map(entity, IfvApiUsersDTO.class)).collect(Collectors.toList());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error Occurred while fetching all IfvApiUsersDTO .{}", msg);
			throw new DatabaseOperationException("Error Occurred while fetching all IfvApiUsersDTO ." + msg + " ", e);
		}
	}

	@Override
	public void sendMail(Long mtCode) {
		logger.info("sendMail() started in SanctionMinutesServiceImpl for mtCode: {}", mtCode);
		try {
			SanctionMinutesEntity existingEntity = repository.findById(mtCode)
					.orElseThrow(() -> new EntityNotFoundException(SANCT_ENTITY, mtCode));
			SanctionMinutesDTO sanctionMinutesDTO = mapper.map(existingEntity, SanctionMinutesDTO.class);

			FileInfo fileInfo = getFileInfo(mtCode);
			UserEmailDto userEmailDto = prepareEmailRecipients(sanctionMinutesDTO, mtCode);
			emailService.sendEmailWithRetryForMinutes(sanctionMinutesDTO, userEmailDto, fileInfo.fileName(),
					fileInfo.fileData());
		} catch (Exception e) {
			msg = e.getMessage();
			logger.error("Error occurred while sending email: {}", msg);
		}
	}

	private FileInfo getFileInfo(Long mtCode) {
		return minutesDocumentsRepo.findByMinuteId(mtCode).filter(doc -> StringUtils.hasText(doc.getDocumentName()))
				.map(doc -> new FileInfo(doc.getDocumentName(), doc.getDocumentContent())).orElseGet(() -> {
					S2IFVFileRepositoryEntity fileEntity = fileRepository
							.findBySancMinDetailIdAndFileModule(mtCode, "FLASH MINUTES")
							.orElseThrow(() -> new EntityNotFoundException("S2IFVFileRepositoryEntity", mtCode));
					return new FileInfo(fileEntity.getFileName(), fileEntity.getFileData());
				});
	}

	private UserEmailDto prepareEmailRecipients(SanctionMinutesDTO sanctionMinutesDTO, Long mtCode) {
		UserEmailDto userEmailDto = new UserEmailDto();
		List<String> employeeCodes = new ArrayList<>();
		Optional.ofNullable(sanctionMinutesDTO.getChairmanCode()).filter(code -> !code.isEmpty())
				.ifPresent(employeeCodes::add);
		Optional.ofNullable(sanctionMinutesDTO.getMemberCode()).filter(code -> !code.isEmpty())
				.ifPresent(memberCode -> employeeCodes.addAll(Arrays.asList(memberCode.split(","))));
		// Get member email IDs
		Set<String> memberEmailIds = cmtMemberMasterRepository.findAllMemberMailIdByMemberCode(employeeCodes);
		if (profileService.isProfileActive("prod")) {
			userEmailDto.setToEmailIds(memberEmailIds);
		}
		// Get CC email IDs
		List<IFVMinutesCheckerDetail> checkerDetails = checkerDetailRepo.findAllByMinuteId(mtCode);
		List<Integer> lUserIds = checkerDetails.stream().map(IFVMinutesCheckerDetail::getCurrentUserId).distinct()
				.map(Long::intValue).collect(Collectors.toList());
		if (!lUserIds.isEmpty()) {
			List<IfvApiUsersEntity> apiUsersEntities = ifvApiUsersRepo.findAllByOfrCodeIn(lUserIds);
			Set<String> ccEmails = apiUsersEntities.stream().map(IfvApiUsersEntity::getOfrEmail)
					.collect(Collectors.toSet());
			// Remove cc emails if emailID already present in to Emails
			if (userEmailDto.getToEmailIds() != null) {
				ccEmails.removeAll(userEmailDto.getToEmailIds());
			}
			userEmailDto.setCcEmailIds(ccEmails);
			// If UAT, consider first checker email as TO and remaining as CC
			if (profileService.isProfileActive("uat") && !ccEmails.isEmpty()) {
				String firstEmail = ccEmails.iterator().next();
				userEmailDto.setToEmailIds(Collections.singleton(firstEmail));
				// Remove this email from CC list to avoid duplication
				Set<String> remainingCcEmails = new HashSet<>(ccEmails);
				remainingCcEmails.remove(firstEmail);
				userEmailDto.setCcEmailIds(remainingCcEmails);
			}

		} else {
			userEmailDto.setCcEmailIds(Collections.emptySet());
		}
		return userEmailDto;
	}

	private record FileInfo(String fileName, byte[] fileData) {
	}

	@Transactional
	@Override
	public void createCompliances(List<Long> minuteIds) {

		try {

			logger.info("Creating compliances for minuteIds={}", minuteIds);

			List<String> appIds = appraisalMinutesDataRepository.findDistinctAppIdsByIdIn(minuteIds);

			logger.info("Found {} distinct IFV appIds: {}", appIds.size(), appIds);

			if (appIds.isEmpty()) {

				logger.warn("No appIds found for minuteIds={}", minuteIds);

				return;
			}

			List<String> bankAppRefNosJsonList = applicationRepository.findBankAppRefNosByAppNumberIn(appIds);

			logger.info("Found bankAppRefNos for {} applications", bankAppRefNosJsonList.size());

			List<String> appRefIds = new ArrayList<>();

			for (String bankAppRefNosJson : bankAppRefNosJsonList) {

				List<String> bankAppRefNos = objectMapper.readValue(bankAppRefNosJson,
						new TypeReference<List<String>>() {
						});

				appRefIds.addAll(bankAppRefNos);
			}

			List<String> distinctAppRefIds = appRefIds.stream().distinct().toList();

			logger.info("Prepared {} unique appRefIds for compliance creation: {}", distinctAppRefIds.size(),
					distinctAppRefIds);

			ifvBankRefinanceApplicationRepository.updateApplicationStatusForAppRefIds(distinctAppRefIds,
					RefinanceApplicationStatus.SANCTIONED.name());

			bankPortalClient.createCompliances(distinctAppRefIds);

		} catch (Exception e) {
			logger.error("Error occurred while sending email", e);
		}

	}

}
