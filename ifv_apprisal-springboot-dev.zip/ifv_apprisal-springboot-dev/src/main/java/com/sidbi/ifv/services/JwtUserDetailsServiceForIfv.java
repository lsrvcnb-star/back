package com.sidbi.ifv.services;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.sidbi.ifv.dto.IfvApiUsersDTO;
import com.sidbi.ifv.entity.IfvApiUsersEntity;
import com.sidbi.ifv.exception.DatabaseOperationException;
import com.sidbi.ifv.repo.IfvApiUsersRepo;

@Service
public class JwtUserDetailsServiceForIfv {

	@Autowired
	private IfvApiUsersRepo ifvuserRepo;

	@Autowired
	private ModelMapper modelMapper;

	Logger logger = LoggerFactory.getLogger(JwtUserDetailsServiceForIfv.class);

	@Transactional(readOnly = true)
	public IfvApiUsersDTO loadUserByUsername(String username) {

		if (!StringUtils.hasText(username)) {
			throw new IllegalArgumentException("Username must not be blank");
		}

		IfvApiUsersEntity user = ifvuserRepo.findByOfrUserId(username);

		if (user == null) {
			throw new UsernameNotFoundException("User not found");
		}

		if (!"Y".equalsIgnoreCase(user.getOfrUserActive())) {
			throw new DatabaseOperationException("User is not enabled. Please contact admin.");
		}

		return modelMapper.map(user, IfvApiUsersDTO.class);
	}

}
