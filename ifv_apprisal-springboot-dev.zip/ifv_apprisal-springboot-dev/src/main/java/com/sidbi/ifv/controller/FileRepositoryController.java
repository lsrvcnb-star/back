package com.sidbi.ifv.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sidbi.ifv.dto.FileRepositoryDTO;
import com.sidbi.ifv.services.FileRepositoryService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/ifv/filerepo")
public class FileRepositoryController {

	private static final Logger logger = LoggerFactory.getLogger(FileRepositoryController.class);

	@Autowired
	private FileRepositoryService fileRepositoryService;

	@GetMapping("/get/{id}")
	public ResponseEntity<FileRepositoryDTO> findById(@PathVariable Long id) {
		logger.info("findById() started FileRepositoryController {} ", id);
		FileRepositoryDTO fileRepositoryDTO = fileRepositoryService.findById(id);
		return ResponseEntity.ok(fileRepositoryDTO);
	}

	@PostMapping("/save")
	public ResponseEntity<FileRepositoryDTO> save(@RequestBody @Valid FileRepositoryDTO fileRepositoryDTO) {
		logger.info("Started save() in FileRepositoryController {} ", fileRepositoryDTO);
		FileRepositoryDTO savedFileRepositoryDTO = fileRepositoryService.save(fileRepositoryDTO);
		return ResponseEntity.ok(savedFileRepositoryDTO);
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<FileRepositoryDTO> update(@PathVariable Long id,
			@RequestBody FileRepositoryDTO fileRepositoryDTO) {
		logger.info("update() started FileRepositoryController {} ", id);
		FileRepositoryDTO updatedFileRepositoryDTO = fileRepositoryService.update(id, fileRepositoryDTO);
		return ResponseEntity.ok(updatedFileRepositoryDTO);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		logger.info("delete() started FileRepositoryController {} ", id);
		fileRepositoryService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/findBySancMinDetailId/{id}")
	public ResponseEntity<FileRepositoryDTO> findBySancMinDetailId(@PathVariable Long id) {
		logger.info("findBySancMinDetailId() started FileRepositoryController {} ", id);
		return ResponseEntity.ok(fileRepositoryService.findBySancMinDetailId(id));
	}

	@GetMapping("/findByFileIfvIdAndFileModule/{ifvId}/{fileModule}")
	public ResponseEntity<FileRepositoryDTO> findBySancMinDetailId(@PathVariable Long ifvId,
			@PathVariable String fileModule) {
		logger.info("findByFileIfvIdAndFileModule() started FileRepositoryController {} ", ifvId);
		return ResponseEntity.ok(fileRepositoryService.findByFileIfvIdAndFileModule(ifvId, fileModule));
	}

	@DeleteMapping("/deleteByFileCode/{id}")
	public ResponseEntity<Void> deleteByFileCode(@PathVariable Long id) {
		logger.info("deleteByFileCode() started FileRepositoryController {} ", id);
		fileRepositoryService.deleteByFileCode(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/findByFileAlcoId/{alcoId}")
	public ResponseEntity<FileRepositoryDTO> findByFileAlcoId(@PathVariable Long alcoId) {
		logger.info("findByFileAlcoId() started FileRepositoryController {} ", alcoId);
		return ResponseEntity.ok(fileRepositoryService.findByFileAlcoId(alcoId));
	}

	@GetMapping("/findByLoiId/{id}")
	public ResponseEntity<FileRepositoryDTO> findByLoiId(@PathVariable Long id) {
		logger.info("findByLoiId() started FileRepositoryController {} ", id);
		return ResponseEntity.ok(fileRepositoryService.findByLoiId(id));
	}

}
