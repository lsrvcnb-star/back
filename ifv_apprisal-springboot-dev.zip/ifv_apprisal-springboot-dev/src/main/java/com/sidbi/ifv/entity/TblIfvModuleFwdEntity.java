package com.sidbi.ifv.entity;

import java.time.LocalDateTime;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "TBL_IFV_MODULE_FWD")
public class TblIfvModuleFwdEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FWD_STATUS_ID")
	private Long fwdStatusId;

	@Column(name = "IFV_ID")
	private Long ifvId;

	@Column(name = "MODULE_ID")
	private Long moduleId;

	@Column(name = "APP_OFFICER_CODE")
	private Long appOfficerCode;

	@Column(name = "APP_CURRENT_OFFICER_CODE")
	private Long appCurrentOfficerCode;

	@Column(name = "APP_STATUS")
	private String appStatus;

	@Column(name = "APP_MODULE_CHECKER_CODE")
	private Long appModuleCheckerCode;

	@Column(name = "CREATED_MODIFIED_DATE")
	private Date createdModifiedDate;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "IP_ADDRESS")
	private String ipAddress;

	@Column(name = "AL_CODE")
	private Long alCode;

	@Column(name = "current_fwd_checker_name")
	private String currentFwdCheckerName;

	@Column(name = "current_fwd_checker_desg")
	private String currentFwdCheckerDesg;

	@Column(name = "checker1_id")
	private Integer checker1Id;

	@Column(name = "checker1_name")
	private String checker1Name;

	@Column(name = "checker1_desg")
	private String checker1Desg;

	@Column(name = "checker2_id")
	private Integer checker2Id;

	@Column(name = "checker2_name")
	private String checker2Name;

	@Column(name = "checker2_desg")
	private String checker2Desg;

	@Column(name = "checker3_id")
	private Integer checker3Id;

	@Column(name = "checker3_name")
	private String checker3Name;

	@Column(name = "checker3_desg")
	private String checker3Desg;

	@Column(name = "checker4_id")
	private Integer checker4Id;

	@Column(name = "checker4_name")
	private String checker4Name;

	@Column(name = "checker4_desg")
	private String checker4Desg;

	@Column(name = "locked_date_time")
	private LocalDateTime lockedDateTime;

	@Column(name = "checker1_fwd_date")
	private LocalDateTime checker1FwdDate;

	@Column(name = "checker2_fwd_date")
	private LocalDateTime checker2FwdDate;

	@Column(name = "checker3_fwd_date")
	private LocalDateTime checker3FwdDate;

	@Column(name = "approved_date_time")
	private LocalDateTime approvedDateTime;

	@Column(name = "lock_comment")
	private String lockComment;

	@Column(name = "checker1_comment")
	private String checker1Comment;

	@Column(name = "checker2_comment")
	private String checker2Comment;

	@Column(name = "checker3_comment")
	private String checker3Comment;

	@Column(name = "checker4_comment")
	private String checker4Comment;

	@Column(name = "maker_designation")
	private String makerDesignation;

}
