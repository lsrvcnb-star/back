import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { Label } from "./components/ui/label";
import { Button } from "./components/ui/button";
import { Badge } from "./components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "./components/ui/toggle-group";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./components/ui/table";
import { cn } from "./lib/utils";
import { Download, AlertTriangle, ExternalLink, Info, TrendingUp, CalendarIcon, FileSpreadsheet, FileText, ChevronDown, ChevronUp, X, Trash2 } from "lucide-react";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, } from "./components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "./components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "./components/ui/alert-dialog";
import { Popover, PopoverContent, PopoverTrigger } from "./components/ui/popover";
import { Calendar } from "./components/ui/calendar";
import { format } from "date-fns";
import { FREQUENCIES, schemeAmounts, effectiveRateForFreq, effectiveRateWindow, combinedCashflows, xirr, irrAnnualPct, combinedMonthlyCashflows, irrPeriodic, mserFloor, marginBps, discretionMaxBps, schemeSchedule, weightedAvgRate, legSchedules, baseLegAmount, splitTotal, withTenureMonths, RMSE_FIXED_RATE, RMSE_MARGIN_BPS, } from "./lib/pricing";
import { BANKS, BANK_TYPES, DEFAULT_DEAL, COF_OPTION_DEFS, BENCHMARK_OPTION_DEFS, COF_STATIC_RATES, COF_FLOATING_MAP, RMSE_MATURITY_DATE, roundedMonthsBetween, } from "./lib/pricing-data";
import { MARKET_INSTRUMENTS } from "./lib/market-history";
import { useMarket } from "./lib/market-client";
import { useCounterparty } from "./lib/counterparty-client";
import { exportDealToExcel } from "./lib/pricing-export";
import { exportDealToPdf } from "./lib/pricing-pdf";
import { buildNegotiationAuditMetadata, recordDocumentExport } from "./lib/document-export-audit";
import { counterpartyMarketDeals, treasuryDeals } from "./lib/market-deals";
import { LineChart, Line, XAxis, YAxis, Tooltip as RTooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid, ReferenceLine, AreaChart, Area, } from "recharts";
import { getPreviousProposals } from "./lib/previous-proposal";


/** A CoF row carries a spread over a benchmark: Treasury floating rows + custom floating. */
const isFloatingCofOpt = (c) => c?.type === "floating" || c?.key === "custom_float";
/** Resolved CoF % for a key = base rate (+ spread when the row is floating). */
const resolveCofPct = (key, opts, spreads) => {
    const o = opts.find((c) => c.key === key);
    const raw = o?.ratePct ?? null;
    const sp = isFloatingCofOpt(o) ? (spreads[key ?? ""] ?? 0) : 0;
    return raw !== null ? raw + sp / 100 : null;
};

export default function NegotiationDashboard() {
    const [previousProposalOpen, setPreviousProposalOpen] = useState(false);
    const [previousProposals, setPreviousProposals] = useState([]);
    const [loadingPreviousProposals, setLoadingPreviousProposals] = useState(false);

    const [s, setS] = useState(DEFAULT_DEAL);
    const [openInstrument, setOpenInstrument] = useState(null);
    const market = useMarket();
    // Treasury CoF list — seeded with the official 05–31 Jul 2025 IFV-Banks table.
    // Users can still override any row in the UI.
    const [cofList, setCofList] = useState(COF_OPTION_DEFS.map((c) => ({ ...c, ratePct: COF_STATIC_RATES[c.key] ?? null })));
    // Overlay live market rates onto floating CoF rows so they always reflect the
    // latest Repo / 3M T-Bill from RBI/FBIL. User overrides on fixed rows are preserved.
    const [customCofPct, setCustomCofPct] = useState(null);
    // Custom floating CoF — user picks the benchmark and types its value; the
    // spread over it (shared per-key store below) completes the CoF.
    const [customFloatBench, setCustomFloatBench] = useState("repo");
    const [customFloatBase, setCustomFloatBase] = useState(null);
    const cofListLive = useMemo(() => cofList.map((c) => {
        if (c.key === "custom_float")
            return { ...c, ratePct: customFloatBase, benchmark: customFloatBench };
        if (c.type === "custom")
            return { ...c, ratePct: customCofPct };
        if (c.type !== "floating")
            return c;
        const mk = c.benchmark ?? COF_FLOATING_MAP[c.key];
        if (!mk)
            return c;
        const v = market.data[mk]?.value ?? null;
        return { ...c, ratePct: v };
    }), [cofList, market.data, customCofPct, customFloatBase, customFloatBench]);
    const [cofKey, setCofKey] = useState("1y3y_repo_float");
    const cof = cofListLive.find((c) => c.key === cofKey);
    const isFloatingCof = isFloatingCofOpt(cof);
    const isCustomCof = cof.key === "custom";
    const isCustomFloatCof = cof.key === "custom_float";
    // Spread over the floating benchmark (bps) — user-entered, blank by default.
    // Kept per key so switching options preserves each spread.
    const [floatingSpreadBps, setFloatingSpreadBps] = useState({});
    const floatSpread = isFloatingCof ? (floatingSpreadBps[cofKey] ?? 0) : 0;
    const baseCofPct = cof.ratePct ?? 0;
    const cofPct = baseCofPct + floatSpread / 100;
    const cofSet = cof.ratePct !== null;
    // When floating spread changes, preserve the current margin over CoF by
    // shifting the MSER rate along with the new CoF.
    const setFloatingSpread = (bps, key = cofKey) => {
        const capped = Math.max(0, Math.min(1000, Math.round(bps)));
        const prevSpread = floatingSpreadBps[key] ?? 0;
        const delta = (capped - prevSpread) / 100;
        setFloatingSpreadBps((prev) => ({ ...prev, [key]: capped }));
        setS((prev) => ({
            ...prev,
            mser: key === cofKey && cofSet ? { ...prev.mser, ratePct: prev.mser.ratePct + delta } : prev.mser,
            splits: (prev.splits ?? []).map((sp) => sp.scheme === "mser" && (sp.cofKey ?? cofKey) === key
                ? { ...sp, ratePct: +(sp.ratePct + delta).toFixed(2) }
                : sp),
        }));
    };
    // When custom CoF changes, shift MSER rate to preserve margin.
    const setCustomCof = (v) => {
        const prev = customCofPct ?? 0;
        const next = v ?? 0;
        const delta = next - prev;
        setCustomCofPct(v);
        if (v !== null) {
            setS((prevS) => ({ ...prevS, mser: { ...prevS.mser, ratePct: prevS.mser.ratePct + delta } }));
        }
    };
    // Custom floating: benchmark value typed by the user. Shift MSER rate to keep margin.
    const setCustomFloatValue = (v) => {
        const prev = customFloatBase ?? 0;
        const delta = (v ?? 0) - prev;
        setCustomFloatBase(v);
        if (v !== null && cofKey === "custom_float") {
            setS((prevS) => ({ ...prevS, mser: { ...prevS.mser, ratePct: prevS.mser.ratePct + delta } }));
        }
    };
    // If CoF is a fixed-tenor option, clamp MSER tenure to the CoF tenor.
    useEffect(() => {
        if (cof.type !== "fixed")
            return;
        setS((prev) => prev.mser.tenureMonths > cof.tenorMonths
            ? { ...prev, mser: { ...prev.mser, tenureMonths: cof.tenorMonths } }
            : prev);
    }, [cofKey, cof.type, cof.tenorMonths]);
    // Benchmark list — Policy Repo comes from RBI live, others editable.
    const benchmarkList = useMemo(() => {
        return BENCHMARK_OPTION_DEFS.map((b) => {
            if (b.key === "repo")
                return { ...b, ratePct: market.data.repo.value };
            if (b.key === "gsec10")
                return { ...b, ratePct: market.data.gsec10.value };
            if (b.key === "tbill3m")
                return { ...b, ratePct: market.data.tbill3m.value };
            return { ...b, ratePct: null };
        });
    }, [market.data]);
    // Once RBI repo arrives, seed the deal's benchmark if user hasn't customised.
    useEffect(() => {
        if (market.data.repo.value !== null && s.benchmarkPct === 0 && s.benchmarkLabel === "Policy Repo Rate") {
            setS((prev) => ({ ...prev, benchmarkPct: market.data.repo.value }));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [market.data.repo.value]);
    const bank = BANKS.find((b) => b.id === s.bankId);
    const counterparty = useCounterparty(bank.id, bank.nseSymbol ?? null, bank.rating);
    const [deskQuotes] = useManualQuotes();
    const patch = (p) => setS((prev) => ({ ...prev, ...p }));
    const patchScheme = (k, p) => setS((prev) => ({ ...prev, [k]: { ...prev[k], ...p } }));
    // MSER rate ⇄ Discretion linkage.
    // The MSER Rate input is the source of truth for what we're quoting the borrower.
    // Editing it back-solves the discretion (clamped to [0, SCA max]); the rate itself
    // is accepted as typed even if it's below the achievable floor — the negotiation
    // card will flag "below floor" in that case.
    const patchMserScheme = (p) => {
        if (p.ratePct !== undefined && cofSet) {
            const minM = marginBps(bank.category) / 100;
            const standard = cofPct + minM;
            // Floor MSER rate at CoF — cannot go below Treasury cost.
            const clampedRate = Math.max(cofPct, p.ratePct);
            const discBps = Math.round((standard - clampedRate) * 100);
            const clampedDisc = Math.max(0, discBps);
            setS((prev) => ({
                ...prev,
                discretionBps: clampedDisc,
                mser: { ...prev.mser, ...p, ratePct: clampedRate },
            }));
            return;
        }
        patchScheme("mser", p);
    };
    // Discretion slider → drive MSER rate = cof + minMargin − disc/100.
    // Discretion is capped at min margin so rate never drops below CoF.
    const setDiscretion = (bps) => {
        if (!cofSet) {
            patch({ discretionBps: bps });
            return;
        }
        const minMBps = marginBps(bank.category);
        const cappedBps = Math.min(bps, minMBps);
        const finalRate = cofPct + minMarginPct - cappedBps / 100;
        setS((prev) => ({ ...prev, discretionBps: cappedBps, mser: { ...prev.mser, ratePct: finalRate } }));
    };
    const onBankChange = (id) => {
        const b = BANKS.find((x) => x.id === id);
        const maxD = discretionMaxBps(b.category);
        const newDisc = Math.min(b.suggestedDiscretionBps, maxD);
        const newMinM = marginBps(b.category) / 100;
        setS((prev) => {
            const finalRate = cofSet
                ? Math.max(cofPct, cofPct + newMinM - newDisc / 100)
                : prev.mser.ratePct;
            return { ...prev, bankId: id, discretionBps: newDisc, mser: { ...prev.mser, ratePct: finalRate } };
        });
    };
    const setCofRate = (key, v) => {
        setCofList((prev) => prev.map((c) => (c.key === key ? { ...c, ratePct: v } : c)));
        // If the user is editing the currently-selected CoF tenor, retune MSER rate.
        if (key === cofKey && v !== null) {
            const finalRate = Math.max(v, v + minMarginPct - s.discretionBps / 100);
            setS((prev) => ({ ...prev, mser: { ...prev.mser, ratePct: finalRate } }));
        }
    };
    const setBenchmarkFromList = (label) => {
        const b = benchmarkList.find((x) => x.label === label);
        if (!b)
            return;
        patch({ benchmarkLabel: b.label, benchmarkPct: b.ratePct ?? s.benchmarkPct });
    };
    const { mserAmt, rmseAmt } = schemeAmounts(s);
    const compute = useMemo(() => {
        // WAR (12 month) — same deal structure re-cut with a 12-month tenor on every tranche.
        const war12Of = (freq) => effectiveRateWindow(s, freq, 12).effective;
        const perFreq = FREQUENCIES.filter((f) => f.key !== "custom").map((f) => {
            const r = effectiveRateForFreq(s, f.key);
            const cf = combinedCashflows(s, f.key);
            const irr = xirr(cf);
            const irrA = irrAnnualPct(s, f.key);
            return { key: f.key, label: f.label, ...r, xirr: irr, irr: irrA, war12: war12Of(f.key) };
        });
        const chosen = s.repaymentFreq === "custom"
            ? (() => {
                const r = effectiveRateForFreq(s, "custom");
                const cf = combinedCashflows(s, "custom");
                const tail = s.customTailMonths ?? 3;
                return { key: "custom", label: `Custom · last ${tail}m`, ...r, xirr: xirr(cf), irr: irrAnnualPct(s, "custom"), war12: war12Of("custom") };
            })()
            : perFreq.find((r) => r.key === s.repaymentFreq);
        const floor = mserFloor(s, bank.category, cofPct);
        const rmseRate = s.rmse.ratePct;
        // MSER rate quoted to the borrower = user-controlled s.mser.ratePct (linked to discretion slider).
        const mserQuoted = s.mser.ratePct;
        const denom = Math.max(1e-9, mserAmt * (s.mser.tenureMonths / 12) + rmseAmt * (s.rmse.tenureMonths / 12));
        // Post-negotiation blended rate — weighted by Amt × Tenure_yr (Excel Entry Sheet D24 pattern).
        const blendedFinal = (mserQuoted * mserAmt * (s.mser.tenureMonths / 12) +
            rmseRate * rmseAmt * (s.rmse.tenureMonths / 12)) / denom;
        // WAR — weighted avg of the CURRENTLY QUOTED scheme rates (Excel "WAR" sheet).
        const war = weightedAvgRate(s);
        // MSER Cost of Funds (from Treasury). RMSE CoF is fixed by policy and excluded.
        const fundingCoF = cofPct;
        return { perFreq, chosen, floor, rmseRate, mserQuoted, blendedFinal, war: war.war, fundingCoF };
    }, [s, bank, cofPct, mserAmt, rmseAmt]);
    const maxDiscretion = discretionMaxBps(bank.category);
    const minMarginPct = marginBps(bank.category) / 100;
    // MSER rows (base + splits) with their own CoF — used for per-split rate pills
    // and per-split floor build-ups in Live Output.
    const mserRateRows = useMemo(() => {
        const mserSplits = (s.splits ?? []).filter((sp) => sp.scheme === "mser");
        const resolve = (k) => ({
            pct: resolveCofPct(k, cofListLive, floatingSpreadBps),
            label: cofListLive.find((c) => c.key === k)?.tenorLabel ?? "—",
        });
        const rows = [
            {
                id: "base",
                label: mserSplits.length > 0 ? "MSER 1" : "MSER",
                ratePct: s.mser.ratePct,
                cofPct: cofSet ? cofPct : null,
                cofLabel: cof.tenorLabel,
            },
            ...mserSplits.map((sp, i) => {
                const c = resolve(sp.cofKey ?? cofKey);
                return {
                    id: sp.id,
                    label: `MSER ${i + 2}`,
                    ratePct: sp.ratePct,
                    cofPct: c.pct,
                    cofLabel: c.label,
                };
            }),
        ];
        return rows;
    }, [s, cofListLive, customCofPct, floatingSpreadBps, cofKey, cofPct, cofSet, cof]);
    // RMSE rows (base + splits) — each split draws from its own tranche, so the
    // rate can differ per leg. Used for per-leg rate pills in Live Output.
    const rmseRateRows = useMemo(() => {
        const rmseSplits = (s.splits ?? []).filter((sp) => sp.scheme === "rmse");
        return [
            {
                id: "rmse-base",
                label: rmseSplits.length > 0 ? "RMSE 1" : "RMSE",
                ratePct: s.rmse.ratePct,
                sub: rmseSplits.length > 0 ? "base tranche" : `fixed ${s.rmse.ratePct.toFixed(2)}%`,
            },
            ...rmseSplits.map((sp, i) => ({
                id: sp.id,
                label: `RMSE ${i + 2}`,
                ratePct: sp.ratePct,
                sub: sp.label || "tranche",
            })),
        ];
    }, [s]);

    const handlePreviousProposal = async () => {
        try {
            setLoadingPreviousProposals(true);

            const data = await getPreviousProposals();

            setPreviousProposals(data || []);
            setPreviousProposalOpen(true);
        } catch (error) {
            console.error("Failed to load previous proposals", error);
        } finally {
            setLoadingPreviousProposals(false);
        }
    };

    // MSER rate is now user-editable and driven explicitly by the discretion slider,
    // CoF, and bank handlers above — no force-sync effect (that used to overwrite typed values).
    // RMSE rate is fixed by policy: 3.50% (RBI fund) + 75 bps = 4.25%. Hard cap.
    return (
        
        _jsxs("div", {
        className: "min-h-screen bg-mds-surface", children: [_jsxs(Tabs, {
            defaultValue: "negotiation", className: "space-y-0", children: [_jsx("header", {
                className: "bg-white border-b border-border sticky top-0 z-20", children: _jsxs("div", {
                    className: "max-w-[1400px] mx-auto px-6 py-3 flex flex-col gap-3 d-flex items-center justify-center", children: [_jsx("h1", { className: "text-lg font-bold text-mds-navy leading-tight", children: "Pricing Negotiation Dashboard" }), _jsxs(TabsList, { className: "w-fit", children: [_jsx(TabsTrigger, { value: "negotiation", children: "Negotiation" }), _jsx(TabsTrigger, { value: "calculations", children: "Detailed Calculations" })] }), _jsxs("div", {
                        className: "flex items-center gap-3", children: [
                            _jsx(BankSelector, { bank: bank.id, onChange: onBankChange }),
                            _jsxs(DropdownMenu, {
                                children: [_jsx(DropdownMenuTrigger, { asChild: true, children: _jsxs(Button, { variant: "outline", size: "sm", disabled: !cofSet, className: "gap-2", children: [_jsx(Download, { className: "h-4 w-4" }), " Export ", _jsx(ChevronDown, { className: "h-3 w-3 opacity-70" })] }) }),
                                _jsxs(DropdownMenuContent, {
                                    align: "end",
                                    className: "w-56",
                                    children: [_jsxs(DropdownMenuItem, {
                                        className: "gap-2 cursor-pointer",
                                        onClick: () => exportDealToExcel(s, bank, cofPct, cof.label, market.data),
                                        children: [_jsx(FileSpreadsheet, {
                                            className: "h-4 w-4 text-mds-success"
                                        }), " Excel workbook"]
                                    }),
                                    _jsxs(DropdownMenuItem, {
                                        className: "gap-2 cursor-pointer",
                                        onClick: () => exportDealToPdf(s, bank, {
                                            floating: isFloatingCof,
                                            benchmarkName: cof.benchmark === "tbill3m" ? "3M T-Bill" : cof.benchmark === "repo" ? "Repo Rate" : undefined,
                                            benchmarkPct: isFloatingCof ? (cof.ratePct ?? undefined) : undefined,
                                            spreadBps: floatSpread,
                                            cofPct,
                                            baseTrancheId: (() => {
                                                try {
                                                    return window.localStorage.getItem("sidbi.rmse.baseTranche") ?? undefined;
                                                }
                                                catch {
                                                    return undefined;
                                                }
                                            })(),
                                        }), children: [_jsx(FileText, { className: "h-4 w-4 text-mds-danger" }), " Counterparty term sheet (PDF)"]
                                    }),
                                    _jsxs(DropdownMenuItem, {
                                        className: "gap-2 cursor-pointer",
                                        onClick: () => { void recordDocumentExport(buildNegotiationAuditMetadata(s, bank, cofPct, "PRINT", "print", "SIDBI_Pricing_" + bank.id + "_print", cofSet)); window.print(); },
                                        children: [_jsx(FileText, { className: "h-4 w-4 text-muted-foreground" }), " Print current view"]
                                    })]
                                })]
                            }),
                            _jsxs(Button, {
                                variant: "outline",
                                size: "sm",
                                className: "gap-2",
                                onClick: handlePreviousProposal,
                                children: [
                                    _jsx(FileText, {
                                        className: "h-4 w-4"
                                    }),
                                    " Previous Proposal"
                                ]
                            })
                        ]
                    })]
                })
            }),

            _jsxs("main", {
                className: "max-w-[1400px] mx-auto px-6 py-6 space-y-6", children: [_jsx("div", {
                    className: "grid grid-cols-1 gap-4", children: _jsx(Card, {
                        className: "bg-gradient-to-br from-mds-blue via-[oklch(0.48_0.16_255)] to-mds-purple text-white border-0", children: _jsxs(CardContent, {
                            className: "p-6", children: [_jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsxs("div", { className: "text-[10px] uppercase tracking-widest text-white/60", children: ["WAR \u00B7 ", compute.chosen.label] }), _jsxs("div", { className: "text-5xl font-bold tabular mt-2", children: [cofSet ? compute.chosen.effective.toFixed(2) : "—", _jsx("span", { className: "text-2xl text-white/70", children: "%" })] }), _jsxs("div", { className: "text-xs text-white/70 mt-1", children: ["MSER ", cofSet ? compute.mserQuoted.toFixed(2) : "—", "% \u00B7 RMSE ", compute.rmseRate.toFixed(2), "%"] }), cofSet && s.discretionBps === 0 && compute.mserQuoted > compute.floor.standard + 1e-6 && (_jsxs("div", { className: "mt-2 inline-flex items-center gap-1.5 rounded-md bg-mds-success/25 border border-mds-success/40 px-2.5 py-1 text-[11px] font-medium text-white", children: [_jsx(TrendingUp, { className: "h-3 w-3" }), "Margin +", Math.round((compute.mserQuoted - compute.floor.standard) * 100), " bps above min prescribed"] }))] }), _jsx("div", { className: "flex flex-col items-end gap-2", children: _jsx(Badge, { className: "bg-white/15 hover:bg-white/15 text-white border-0", children: bank.name }) })] }), _jsxs("div", {
                                className: "mt-5 grid grid-cols-2 md:grid-cols-6 gap-4 text-white/90", children: [_jsx(MiniStat, { label: "WAR (12 MONTH)", value: cofSet ? `${compute.chosen.war12.toFixed(2)}%` : "—" }), _jsx(MiniStat, { label: `XIRR · ${compute.chosen.label}`, value: cofSet && isFinite(compute.chosen.xirr) ? `${compute.chosen.xirr.toFixed(2)}%` : "—" }), _jsx(MiniStat, { label: `IRR (ann.) · ${compute.chosen.label}`, value: cofSet && isFinite(compute.chosen.irr) ? `${compute.chosen.irr.toFixed(2)}%` : "—" }), _jsx(MiniStat, { label: "MSER CoF", value: cofSet ? `${compute.fundingCoF.toFixed(2)}%` : "—" }), _jsx(MiniStat, { label: "Margin over CoF", value: cofSet ? `${Math.round((compute.mserQuoted - compute.fundingCoF) * 100)} bps` : "—" }), _jsx(MiniStat, {
                                    label: "Spread + Margin", value: cofSet ? `${Math.round(floatSpread + (compute.mserQuoted - compute.fundingCoF) * 100)} bps` : "—", note: cofSet
                                        ? `Spread ${Math.round(floatSpread)} bps · Margin ${Math.round((compute.mserQuoted - compute.fundingCoF) * 100)} bps`
                                        : undefined
                                })]
                            }), _jsx("div", {
                                className: "mt-5 pt-4 border-t border-white/15", children: _jsxs("div", {
                                    className: "rounded-md bg-white/5 px-3 py-2", children: [_jsx("div", { className: "text-[11px] text-white/50 uppercase tracking-wider mb-1", children: "Deal Composition" }), _jsx("div", {
                                        className: "divide-y divide-white/10", children: [
                                            {
                                                label: "MSER",
                                                structure: compute.chosen.label,
                                                amt: mserAmt,
                                                share: s.mserSharePct,
                                                rate: compute.mserQuoted,
                                                tenure: s.mser.tenureMonths,
                                                morat: s.mser.moratoriumMonths,
                                                cof: cofSet ? `${cofPct.toFixed(2)}%` : "—",
                                            },
                                            {
                                                label: "RMSE",
                                                structure: "Bullet",
                                                amt: rmseAmt,
                                                share: 100 - s.mserSharePct,
                                                rate: compute.rmseRate,
                                                tenure: s.rmse.tenureMonths,
                                                morat: s.rmse.moratoriumMonths,
                                                cof: `${RMSE_FIXED_RATE.toFixed(2)}%`,
                                            },
                                        ].map((row) => (_jsxs("div", { className: "py-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm font-semibold text-white tabular", children: [_jsxs("span", { className: "min-w-[140px]", children: [row.label, " \u00B7 ", row.structure] }), _jsxs("span", { className: "min-w-[150px]", children: ["\u20B9", row.amt.toFixed(2), " Cr ", _jsxs("span", { className: "text-white/70", children: ["\u00B7 ", row.share.toFixed(2), "%"] })] }), _jsxs("div", { className: "flex flex-wrap gap-x-4 gap-y-1 ml-auto", children: [_jsxs("span", { children: ["Rate ", _jsxs("span", { children: [row.rate.toFixed(2), "%"] })] }), _jsxs("span", { children: ["Tenure ", _jsxs("span", { children: [row.tenure, "m"] })] }), _jsxs("span", { children: ["Morat ", _jsxs("span", { children: [row.morat, "m"] })] }), _jsxs("span", { children: ["CoF ", _jsx("span", { children: row.cof })] })] })] }, row.label)))
                                    })]
                                })
                            }), (() => {
                                const minMBps = marginBps(bank.category);
                                const overBps = Math.max(0, s.discretionBps - maxDiscretion);
                                const scaBps = Math.min(s.discretionBps, maxDiscretion);
                                const quoted = compute.mserQuoted;
                                const belowCof = cofSet && quoted < cofPct - 1e-6;
                                const premiumBps = cofSet && s.discretionBps === 0
                                    ? Math.round((quoted - compute.floor.standard) * 100)
                                    : 0;
                                const hasPremium = premiumBps > 0;
                                let approval;
                                if (belowCof)
                                    approval = { label: "ALCO + Treasury Approval", tone: "danger" };
                                else if (overBps > 0)
                                    approval = { label: `ALCO Approval (+${overBps} bps over SCA)`, tone: "danger" };
                                else if (scaBps > 0)
                                    approval = { label: `SCA Approval (${scaBps} bps discretion)`, tone: "warning" };
                                else if (hasPremium)
                                    approval = { label: `Priced +${premiumBps} bps above Min Margin · no approval`, tone: "success" };
                                else
                                    approval = { label: "Within Standard · no approval needed", tone: "neutral" };
                                const toneCls = approval.tone === "danger" ? "bg-mds-danger/25  border-mds-danger/40  text-white" :
                                    approval.tone === "warning" ? "bg-mds-warning/25 border-mds-warning/40 text-white" :
                                        approval.tone === "success" ? "bg-mds-success/25 border-mds-success/40 text-white" :
                                            "bg-white/10 border-white/20 text-white/90";
                                return (_jsxs("div", { className: "mt-3 grid grid-cols-2 md:grid-cols-3 gap-3 text-[11px]", children: [_jsxs("div", { className: "rounded-md bg-white/5 px-3 py-2", children: [_jsx("div", { className: "text-white/50 uppercase tracking-wider", children: "Min Margin" }), _jsxs("div", { className: "text-sm font-semibold text-white tabular", children: [minMBps, " bps \u00B7 ", bank.categoryLabel] })] }), _jsxs("div", { className: "rounded-md bg-white/5 px-3 py-2", children: [_jsx("div", { className: "text-white/50 uppercase tracking-wider", children: "Discretion Applied" }), _jsxs("div", { className: "text-sm font-semibold text-white tabular", children: [s.discretionBps, " / ", maxDiscretion, " bps", overBps > 0 && _jsxs("span", { className: "ml-1 text-mds-danger", children: ["\u00B7 +", overBps, " over"] })] })] }), _jsxs("div", { className: cn("rounded-md px-3 py-2 border", toneCls), children: [_jsx("div", { className: "text-white/60 uppercase tracking-wider", children: "Approval Status" }), _jsx("div", { className: "text-sm font-semibold", children: approval.label })] })] }));
                            })(), !cofSet && (_jsx("div", { className: "mt-4 text-[11px] text-white/70 border-t border-white/15 pt-3", children: "Enter Treasury Cost of Funds below to see the negotiation floor and spread." }))]
                        })
                    })
                }), _jsx(TabsContent, {
                    value: "negotiation", className: "space-y-4", children: _jsxs("div", {
                        className: "grid grid-cols-1 lg:grid-cols-12 gap-4", children: [_jsxs("div", {
                            className: "lg:col-span-6 flex flex-col gap-4", children: [_jsxs(Card, {
                                children: [_jsx(CardHeader, { className: "pb-3", children: _jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-blue rounded" }), " Deal Structure"] }) }), _jsxs(CardContent, {
                                    className: "space-y-4", children: [_jsxs("div", {
                                        className: "grid grid-cols-3 gap-3", children: [_jsx(Field, { label: "Principal (\u20B9 Cr)", children: _jsx(NumberField, { value: s.principalCr, onCommit: (v) => patch({ principalCr: v ?? 0 }), className: "h-9 tabular" }) }), _jsx(Field, {
                                            label: "MSER Amount (\u20B9 Cr)", children: _jsx(NumberField, {
                                                value: Number(mserAmt.toFixed(2)), step: "0.01", min: 0, max: s.principalCr, onCommit: (raw) => {
                                                    const v = Math.max(0, Math.min(s.principalCr, raw ?? 0));
                                                    patch({ mserSharePct: s.principalCr > 0 ? (v / s.principalCr) * 100 : 0 });
                                                }, className: "h-9 tabular"
                                            })
                                        }), _jsx(Field, {
                                            label: "RMSE Amount (\u20B9 Cr)", children: _jsx(NumberField, {
                                                value: Number(rmseAmt.toFixed(2)), step: "0.01", min: 0, max: s.principalCr, onCommit: (raw) => {
                                                    const v = Math.max(0, Math.min(s.principalCr, raw ?? 0));
                                                    const mser = Math.max(0, s.principalCr - v);
                                                    patch({ mserSharePct: s.principalCr > 0 ? (mser / s.principalCr) * 100 : 0 });
                                                }, className: "h-9 tabular"
                                            })
                                        })]
                                    }), _jsxs("section", { className: "space-y-2", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx(SubHead, { title: "MSER" }), _jsxs(Badge, { variant: "outline", className: "text-[10px] font-normal", children: ["\u20B9", mserAmt.toFixed(2), " Cr"] })] }), _jsx(MserLegs, { state: s, mserAmt: mserAmt, cofOptions: cofListLive, cofKey: cofKey, setCofKey: setCofKey, cofPct: cofPct, cofSet: cofSet, minMarginBps: marginBps(bank.category), maxDiscretionBps: maxDiscretion, isFloatingCof: isFloatingCof, isCustomCof: isCustomCof, floatSpread: floatSpread, floatingSpreadBps: floatingSpreadBps, setFloatingSpread: setFloatingSpread, customCofPct: customCofPct, setCustomCof: setCustomCof, customFloatBench: customFloatBench, setCustomFloatBench: setCustomFloatBench, customFloatBase: customFloatBase, setCustomFloatValue: setCustomFloatValue, benchmarkLabel: cof.benchmark === "repo" ? "Repo" : "3M T-Bill", cofTenorMax: cof.type === "fixed" ? cof.tenorMonths ?? undefined : undefined, patch: patch, patchMserScheme: patchMserScheme, onAdd: () => patch({ splits: [...(s.splits ?? []), nextSplit(s, "mser", mserAmt, rmseAmt)] }), canAdd: (s.splits ?? []).length < MAX_SPLITS })] }), _jsxs("section", { className: "space-y-2", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx(SubHead, { title: "RMSE" }), _jsxs(Badge, { variant: "outline", className: "text-[10px] font-normal", children: ["\u20B9", rmseAmt.toFixed(2), " Cr"] })] }), _jsx(RmseLegs, { state: s, rmseAmt: rmseAmt, patch: patch, patchScheme: patchScheme, onAdd: () => patch({ splits: [...(s.splits ?? []), nextSplit(s, "rmse", mserAmt, rmseAmt)] }), canAdd: (s.splits ?? []).length < MAX_SPLITS })] })]
                                })]
                            }), _jsxs(Card, {
                                className: "flex-1 flex flex-col", children: [_jsx(CardHeader, { className: "pb-3", children: _jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center justify-between", children: [_jsxs("span", { className: "flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-navy rounded" }), " Market Rates", _jsx("span", { className: "inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5", children: "Illustrative" })] }), _jsxs("span", { className: "text-[10px] font-normal normal-case tracking-normal text-muted-foreground inline-flex items-center gap-1", children: [_jsx(Info, { className: "h-3 w-3" }), " Click for details"] })] }) }), _jsxs(CardContent, {
                                    className: "flex-1 flex flex-col gap-4", children: [_jsx(CounterpartyActivitySection, { bank: bank, live: counterparty.data.deposits, activity: counterparty.data.announcements, loading: counterparty.loading, fetchedAt: counterparty.data.fetchedAt }), _jsxs("div", {
                                        className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-2 mb-2", children: [_jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-mds-success" }), _jsx("span", { className: "text-[10px] uppercase tracking-widest text-muted-foreground font-semibold", children: "Govt Securities" })] }), _jsx("div", {
                                            className: "grid grid-cols-3 gap-2", children: MARKET_INSTRUMENTS.filter((m) => m.category !== "policy" && m.key !== "cd1y" && m.key !== "cp1y").map((m) => {
                                                const live = market.data[m.key];
                                                const displayValue = live?.value ?? null;
                                                return (_jsx(InstrumentTile, { inst: m, onOpen: () => setOpenInstrument(m), accent: "navy", liveValue: displayValue, liveAsOf: market.data.fetchedAt }, m.key));
                                            })
                                        })]
                                    }), _jsxs("div", {
                                        children: [_jsxs("div", { className: "flex items-center gap-2 mb-2", children: [_jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-mds-blue" }), _jsx("span", { className: "text-[10px] uppercase tracking-widest text-muted-foreground font-semibold", children: "Policy Corridor \u00B7 RBI" })] }), _jsx("div", {
                                            className: "grid grid-cols-3 gap-2", children: MARKET_INSTRUMENTS.filter((m) => m.category === "policy").map((m) => {
                                                const live = market.data[m.key];
                                                return (_jsx(InstrumentTile, { inst: m, onOpen: () => setOpenInstrument(m), accent: "blue", liveValue: live?.value ?? null, liveAsOf: market.data.fetchedAt }, m.key));
                                            })
                                        })]
                                    })]
                                })]
                            })]
                        }), _jsxs("div", {
                            className: "lg:col-span-6 flex flex-col gap-4", children: [_jsxs(Card, {
                                children: [_jsx(CardHeader, { className: "pb-3", children: _jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-success rounded" }), " Live Output"] }) }), _jsxs(CardContent, {
                                    className: "space-y-4", children: [!cofSet && (_jsxs("div", { className: "flex items-start gap-2 rounded-md bg-mds-warning/10 border border-mds-warning/30 p-3 text-xs", children: [_jsx(AlertTriangle, { className: "h-4 w-4 mt-0.5 shrink-0 text-mds-warning" }), _jsxs("div", { children: ["Enter Treasury ", _jsx("strong", { children: "Cost of Funds" }), " in the input panel to see the floor."] })] })), _jsxs("div", {
                                        className: "grid grid-cols-2 lg:grid-cols-3 gap-3", children: [_jsx(MultiRatePill, {
                                            label: "MSER Rate", tone: "blue", rows: mserRateRows.map((r) => ({
                                                id: r.id,
                                                label: r.label,
                                                sub: r.cofPct !== null ? `CoF ${r.cofPct.toFixed(2)}% · ${r.cofLabel}` : undefined,
                                                value: r.cofPct !== null ? r.ratePct : null,
                                            }))
                                        }), _jsx(MultiRatePill, { label: "RMSE Rate", tone: "navy", rows: rmseRateRows.map((r) => ({ id: r.id, label: r.label, sub: r.sub, value: r.ratePct })) }), _jsx(FinalPill, { label: "WAR", sub: compute.chosen.label, value: cofSet ? compute.chosen.effective : null, tone: "success" }), _jsx(FinalPill, { label: "WAR (12 month)", sub: "12-month tenor", value: cofSet ? compute.chosen.war12 : null, tone: "success" }), _jsx(FinalPill, { label: "XIRR", sub: "dated cashflows", value: cofSet && isFinite(compute.chosen.xirr) ? compute.chosen.xirr : null, tone: "purple" }), _jsx(FinalPill, { label: "IRR", sub: "annualised", value: cofSet && isFinite(compute.chosen.irr) ? compute.chosen.irr : null, tone: "purple" })]
                                    }), mserRateRows.map((row) => (_jsx(MserFloorPanel, { title: mserRateRows.length > 1 ? `${row.label} — Floor Build-up` : "MSER Floor Build-up", rateLabel: mserRateRows.length > 1 ? `Final ${row.label} Rate` : "Final MSER Rate", ratePct: row.ratePct, cofPct: row.cofPct, cofLabel: row.cofLabel, minMarginBps: marginBps(bank.category), maxDiscretionBps: maxDiscretion, categoryLabel: bank.categoryLabel }, row.id))), _jsxs("div", {
                                        className: "rounded-lg border border-mds-purple/30 bg-mds-purple/5 px-3 py-2.5 flex items-center justify-between gap-3", children: [_jsxs("div", { children: [_jsx("div", { className: "text-[11px] font-semibold uppercase tracking-wider text-mds-navy", children: "Solve for target" }), _jsx("div", { className: "text-[10px] text-muted-foreground", children: "Reverse-solve deal parameters for a target XIRR or WAR" })] }), _jsx(GoalSeekLauncher, {
                                            state: s, chosenFreq: s.repaymentFreq, currentXirr: compute.chosen.xirr, currentWar: compute.war, onApply: (variable, value, legId) => {
                                                if (legId === "base") {
                                                    if (variable === "mserRate")
                                                        patchMserScheme({ ratePct: value });
                                                    else if (variable === "mserShare")
                                                        patch({ mserSharePct: value });
                                                    else if (variable === "mserTenure")
                                                        patchScheme("mser", { tenureMonths: Math.round(value) });
                                                    else if (variable === "mserFreq")
                                                        patch({ repaymentFreq: value });
                                                    return;
                                                }
                                                const next = (s.splits ?? []).map((sp) => {
                                                    if (sp.id !== legId)
                                                        return sp;
                                                    if (variable === "mserRate")
                                                        return { ...sp, ratePct: value };
                                                    if (variable === "mserShare")
                                                        return { ...sp, amountCr: value };
                                                    if (variable === "mserTenure")
                                                        return { ...sp, tenureMonths: Math.round(value) };
                                                    return { ...sp, freq: value };
                                                });
                                                patch({ splits: next });
                                            }
                                        })]
                                    })]
                                })]
                            }), cofSet && (() => {
                                const liveDepRates = (counterparty.data.deposits.rows ?? [])
                                    .flatMap((d) => [d.callable, d.nonCallable, d.nonCallableMax ?? null])
                                    .filter((v) => v !== null && v !== undefined);
                                const staticDepRates = bank.deposits
                                    .flatMap((d) => [d.nonCallable, d.callable])
                                    .filter((v) => v !== null && v !== undefined);
                                const depRates = liveDepRates.length ? liveDepRates : staticDepRates;
                                const maxBulk = depRates.length ? Math.max(...depRates) : null;
                                const gsecInst = MARKET_INSTRUMENTS.find((m) => m.key === "gsec10");
                                const cpInst = MARKET_INSTRUMENTS.find((m) => m.key === "cp1y");
                                const cdInst = MARKET_INSTRUMENTS.find((m) => m.key === "cd1y");
                                const gsec10 = market.data.gsec10.value ?? gsecInst?.latest ?? null;
                                const cp1y = market.data.cp1y.value ?? cpInst?.latest ?? null;
                                const cd1y = market.data.cd1y.value ?? cdInst?.latest ?? null;
                                const quote = latestQuoteRate(deskQuotes);
                                const standard = compute.floor.standard;
                                const upper = [maxBulk, cd1y, quote?.rate ?? null].filter((v) => v !== null);
                                const ceiling = upper.length ? Math.max(...upper) : Math.max(standard + 1.5, cofPct + 2);
                                return (_jsxs(Card, {
                                    children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-blue rounded" }), " Negotiation Range"] }), _jsx("div", { className: "text-[10px] text-muted-foreground mt-1", children: "Treasury cost of funds to bank funding alternative" })] }), _jsx(CardContent, {
                                        children: _jsx(NegotiationRangeBar, {
                                            min: cofPct, max: ceiling, markers: [
                                                { key: "cof", label: "Cost of Funds", value: cofPct, color: "var(--mds-success)", position: "top" },
                                                { key: "current", label: "MSER Quote", value: compute.mserQuoted, color: "var(--mds-blue)", position: "top" },
                                                { key: "war", label: `WAR · ${compute.chosen.label}`, value: compute.chosen.effective, color: "var(--mds-navy)", position: "top" },
                                                ...(quote !== null ? [{ key: "deskquote", label: quote.label, value: quote.rate, color: "#B3202C", position: "bottom" }] : []),
                                                ...(gsec10 !== null ? [{ key: "gsec", label: "10Y G-Sec", value: gsec10, color: "var(--mds-purple)", position: "bottom" }] : []),
                                                ...(cd1y !== null ? [{ key: "cd", label: "CD 1Y (bulk)", value: cd1y, color: "#7C3AED", position: "bottom" }] : []),
                                                ...(cp1y !== null ? [{ key: "cp", label: "CP 1Y", value: cp1y, color: "#0E7C66", position: "bottom" }] : []),
                                                ...(maxBulk !== null ? [{ key: "bulkmax", label: "Bulk Deposit Max", value: maxBulk, color: "var(--mds-warning)", position: "bottom" }] : []),
                                            ]
                                        })
                                    })]
                                }));
                            })(), _jsx(PastDealsCard, { deals: bank.pastDeals, bankName: bank.name, bankId: bank.id, bankCategory: bank.category, cofOptions: cofListLive })]
                        })]
                    })
                }), _jsx(TabsContent, { value: "calculations", className: "space-y-4", children: _jsx(DetailedCalcs, { state: s, cofPct: cofPct, cofLabel: cof.label, chosenFreq: s.repaymentFreq }) })]
            })]
        }), _jsx(InstrumentDetail, { inst: openInstrument, onClose: () => setOpenInstrument(null) })]
    })


);

}


// ============ Small components ============
function BankSelector({ bank, onChange }) {
    const current = BANKS.find((b) => b.id === bank);
    const [type, setType] = useState(current?.bankType ?? "PVT");
    useEffect(() => {
        if (current && current.bankType !== type)
            setType(current.bankType);
    }, [bank]);
    const inType = BANKS.filter((b) => b.bankType === type)
        .slice()
        .sort((a, b) => a.name.localeCompare(b.name));
    const onTypeChange = (t) => {
        const next = t;
        setType(next);
        const first = BANKS.filter((b) => b.bankType === next)
            .slice()
            .sort((a, b) => a.name.localeCompare(b.name))[0];
        if (first && first.id !== bank)
            onChange(first.id);
    };
    return (_jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Select, { value: type, onValueChange: onTypeChange, children: [_jsx(SelectTrigger, { className: "h-9 w-[190px]", children: _jsx(SelectValue, { placeholder: "Type of bank" }) }), _jsx(SelectContent, { children: BANK_TYPES.map((t) => (_jsx(SelectItem, { value: t.key, children: t.label }, t.key))) })] }), _jsxs(Select, { value: bank, onValueChange: onChange, children: [_jsx(SelectTrigger, { className: "h-9 w-[250px]", children: _jsx(SelectValue, { placeholder: "Select bank" }) }), _jsx(SelectContent, { children: inType.map((bk) => (_jsx(SelectItem, { value: bk.id, children: _jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "w-5 h-5 rounded-sm flex items-center justify-center text-[10px] font-bold text-white", style: { background: bk.color }, children: bk.logoText.slice(0, 3) }), _jsx("span", { children: bk.name })] }) }, bk.id))) })] })] }));
}
/* ============================================================
   Deal structure — up to 5 additional splits across MSER / RMSE.
   Each split is one compact row: scheme, basis, amount, rate, tenure,
   moratorium, repayment.
   ============================================================ */
const MAX_SPLITS = 5;
function nextSplit(state, scheme, mserAmt, rmseAmt) {
    const base = scheme === "mser" ? state.mser : state.rmse;
    const room = Math.max(0, (scheme === "mser" ? mserAmt : rmseAmt) - splitTotal(state, scheme));
    const n = (state.splits ?? []).filter((s) => s.scheme === scheme).length + 2;
    return {
        id: `${scheme}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        scheme,
        label: `${scheme.toUpperCase()} ${n}`,
        basis: scheme === "mser" ? "floating" : undefined,
        amountCr: Math.round((room > 0 ? room / 2 : 0) * 100) / 100,
        ratePct: base.ratePct,
        tenureMonths: base.tenureMonths,
        moratoriumMonths: base.moratoriumMonths,
        freq: scheme === "mser" ? state.repaymentFreq : "bullet",
    };
}
const LEG_INPUT = "h-9 text-sm tabular bg-white";
const LEG_SELECT = "h-9 text-sm bg-white";
/** One labelled input inside a deal row — same format as Principal / MSER / RMSE amount. */
function Cell({ label, children, span }) {
    return (_jsxs("div", { className: cn("min-w-0 space-y-1.5", span), children: [_jsx(Label, { className: "text-xs text-muted-foreground leading-tight block", children: label }), children] }));
}
/**
 * A single deal row. `label` (e.g. "MSER 2") is only shown when there is more
 * than one row of that scheme — a lone row needs no numbering.
 */
function LegRow({ label, right, onRemove, children }) {
    const showHeader = !!label || !!right || !!onRemove;
    return (_jsxs("div", { className: "py-3 first:pt-0 last:pb-0", children: [showHeader && (_jsxs("div", { className: "flex items-center justify-between gap-2 mb-2", children: [_jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [label && (_jsx("span", { className: "rounded bg-mds-blue/10 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-mds-blue", children: label })), right] }), onRemove && (_jsx("button", { type: "button", onClick: onRemove, "aria-label": `Remove ${label ?? "row"}`, className: "h-6 w-6 inline-flex items-center justify-center rounded text-muted-foreground hover:text-destructive", children: _jsx(X, { className: "h-3.5 w-3.5" }) }))] })), _jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-x-3 gap-y-2.5", children: children })] }));
}
function LegReadonly({ value }) {
    return (_jsx("div", { className: "h-9 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-sm tabular text-foreground", children: value }));
}
/* ============================================================
   MSER rows — first row plus splits, all rendered identically.
   ============================================================ */
function MserLegs({ state, mserAmt, cofOptions, cofKey, setCofKey, cofPct, cofSet, minMarginBps, maxDiscretionBps, isFloatingCof, isCustomCof, floatSpread, floatingSpreadBps, setFloatingSpread, customCofPct, setCustomCof, customFloatBench, setCustomFloatBench, customFloatBase, setCustomFloatValue, benchmarkLabel, cofTenorMax, patch, patchMserScheme, onAdd, canAdd, }) {
    const allSplits = state.splits ?? [];
    const splits = allSplits.filter((sp) => sp.scheme === "mser");
    const updateSplit = (id, p) => patch({ splits: allSplits.map((x) => (x.id === id ? { ...x, ...p } : x)) });
    const removeSplit = (id) => patch({ splits: allSplits.filter((x) => x.id !== id) });
    const cofRate = (k) => cofOptions.find((c) => c.key === k)?.ratePct ?? null;
    const baseAmt = baseLegAmount(state, "mser");
    const baseMarginBps = cofSet ? Math.round((state.mser.ratePct - cofPct) * 100) : 0;
    const maxMarginBps = 500;
    // Margin over CoF per MSER row — read-only status, driven by the Margin input.
    const rowCof = (k) => resolveCofPct(k, cofOptions, floatingSpreadBps);
    const marginRows = [
        ...(cofSet ? [{
            id: "base",
            label: splits.length > 0 ? "MSER 1" : "MSER",
            bps: Math.round((state.mser.ratePct - cofPct) * 100),
        }] : []),
        ...splits.flatMap((sp, i) => {
            const base = rowCof(sp.cofKey ?? cofKey);
            return base === null ? [] : [{
                id: sp.id,
                label: `MSER ${i + 2}`,
                bps: Math.round((sp.ratePct - base) * 100),
            }];
        }),
    ];
    const scaFloorBps = Math.max(0, minMarginBps - maxDiscretionBps);
    const over = splitTotal(state, "mser") > mserAmt + 1e-6;
    const showTail = state.repaymentFreq === "custom" || splits.some((sp) => (sp.freq ?? state.repaymentFreq) === "custom");
    void showTail;
    const cofSelect = (value, onChange) => (_jsxs(Select, {
        value: value, onValueChange: onChange, children: [_jsx(SelectTrigger, { className: LEG_SELECT, children: _jsx(SelectValue, { placeholder: "CoF" }) }), _jsx(SelectContent, {
            children: cofOptions.map((c) => {
                const bench = c.benchmark === "repo" ? "Repo" : "3M T-Bill";
                const type = c.type === "fixed" ? "Fixed"
                    : c.type === "floating" ? "Floating"
                        : c.key === "custom_float" ? "Floating · user" : "Fixed · user";
                const rate = c.type === "floating" ? bench : c.ratePct !== null ? `${c.ratePct.toFixed(2)}%` : "—";
                return (_jsx(SelectItem, { value: c.key, className: "text-xs", children: _jsxs("span", { className: "tabular", children: [_jsx("span", { className: "font-medium", children: c.tenorLabel }), _jsxs("span", { className: "text-muted-foreground", children: [" \u00B7 ", type] }), _jsxs("span", { children: [" \u00B7 ", rate] })] }) }, c.key));
            })
        })]
    }));
    return (_jsxs("div", {
        className: "space-y-3", children: [_jsxs("div", {
            className: "divide-y divide-border/70", children: [_jsxs(LegRow, {
                label: splits.length > 0 ? "MSER 1" : undefined, children: [_jsx(Cell, { label: "Treasury CoF", span: "col-span-2", children: cofSelect(cofKey, setCofKey) }), cofKey === "custom_float" && (_jsxs(_Fragment, { children: [_jsx(Cell, { label: "Benchmark", children: _jsxs(Select, { value: customFloatBench, onValueChange: (v) => setCustomFloatBench(v), children: [_jsx(SelectTrigger, { className: LEG_SELECT, children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "repo", className: "text-sm", children: "Repo" }), _jsx(SelectItem, { value: "tbill3m", className: "text-sm", children: "3M T-Bill" })] })] }) }), _jsx(Cell, { label: "Benchmark %", children: _jsx(NumberField, { value: customFloatBase, step: "0.01", allowNull: true, onCommit: (v) => setCustomFloatValue(v), className: LEG_INPUT }) })] })), _jsx(Cell, { label: "Spread (bps)", children: isFloatingCof ? (_jsx(NumberField, { value: floatSpread, step: "1", min: 0, onCommit: (v) => setFloatingSpread(Math.max(0, Math.round(v ?? 0))), className: LEG_INPUT })) : (_jsx(LegReadonly, { value: "\u2014" })) }), _jsx(Cell, { label: "CoF %", children: isCustomCof ? (_jsx(NumberField, { value: customCofPct, step: "0.01", allowNull: true, onCommit: (v) => setCustomCof(v), className: LEG_INPUT })) : (_jsx(LegReadonly, { value: cofSet ? `${cofPct.toFixed(2)}%` : "—" })) }), _jsx(Cell, {
                    label: "Margin (bps)", children: _jsx(NumberField, {
                        value: baseMarginBps, step: "1", min: 0, max: maxMarginBps, disabled: !cofSet, onCommit: (v) => {
                            if (cofSet)
                                patchMserScheme({ ratePct: cofPct + Math.max(0, Math.round(v ?? 0)) / 100 });
                        }, className: LEG_INPUT
                    })
                }), _jsx(Cell, { label: "Rate %", children: _jsx(LegReadonly, { value: cofSet ? `${state.mser.ratePct.toFixed(2)}%` : "—" }) }), _jsx(Cell, {
                    label: "Amount \u20B9Cr", children: _jsx(NumberField, {
                        value: +baseAmt.toFixed(2), step: "0.01", min: 0, max: state.principalCr, onCommit: (v) => {
                            const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                            const newMser = Math.min(state.principalCr, amt + splitTotal(state, "mser"));
                            patch({ mserSharePct: state.principalCr > 0 ? (newMser / state.principalCr) * 100 : 0 });
                        }, className: LEG_INPUT
                    })
                }), _jsx(Cell, { label: "Repayment", children: _jsxs(Select, { value: state.repaymentFreq, onValueChange: (v) => patch({ repaymentFreq: v }), children: [_jsx(SelectTrigger, { className: LEG_SELECT, children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: FREQUENCIES.map((f) => _jsx(SelectItem, { value: f.key, className: "text-sm", children: f.label }, f.key)) })] }) }), _jsx(Cell, { label: "Tenure (mo)", children: _jsx(NumberField, { value: state.mser.tenureMonths, step: "1", min: 1, max: cofTenorMax, onCommit: (v) => patchMserScheme({ tenureMonths: Math.max(1, Math.round(v ?? 1)) }), className: LEG_INPUT }) }), _jsx(Cell, { label: "Moratorium (mo)", children: _jsx(NumberField, { value: state.mser.moratoriumMonths, step: "1", min: 0, onCommit: (v) => patchMserScheme({ moratoriumMonths: Math.max(0, Math.round(v ?? 0)) }), className: LEG_INPUT }) }), state.repaymentFreq === "custom" && (_jsx(Cell, { label: "Repay last (mo)", children: _jsx(NumberField, { value: state.customTailMonths ?? 3, step: "1", min: 1, max: state.mser.tenureMonths, onCommit: (v) => patch({ customTailMonths: Math.max(1, Math.min(state.mser.tenureMonths, Math.round(v ?? 3))) }), className: LEG_INPUT }) }))]
            }), splits.map((r, i) => {
                const key = r.cofKey ?? cofKey;
                const opt = cofOptions.find((c) => c.key === key);
                const isFloat = isFloatingCofOpt(opt);
                const isCustomFixed = key === "custom";
                const isCustomFloat = key === "custom_float";
                // Spread over the benchmark is tracked per CoF option, so each split
                // with a floating CoF can carry (and edit) its own spread.
                const rowSpread = isFloat ? (floatingSpreadBps[key] ?? 0) : 0;
                const base = resolveCofPct(key, cofOptions, floatingSpreadBps);
                const freq = r.freq ?? state.repaymentFreq;
                return (_jsxs(LegRow, {
                    label: `MSER ${i + 2}`, onRemove: () => removeSplit(r.id), children: [_jsx(Cell, {
                        label: "Treasury CoF", span: "col-span-2", children: cofSelect(key, (v) => {
                            const rate = resolveCofPct(v, cofOptions, floatingSpreadBps);
                            updateSplit(r.id, {
                                cofKey: v,
                                ratePct: rate !== null ? +(rate + (r.marginBps ?? minMarginBps) / 100).toFixed(2) : r.ratePct,
                            });
                        })
                    }), isCustomFloat && (_jsxs(_Fragment, { children: [_jsx(Cell, { label: "Benchmark", children: _jsxs(Select, { value: customFloatBench, onValueChange: (v) => setCustomFloatBench(v), children: [_jsx(SelectTrigger, { className: LEG_SELECT, children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "repo", className: "text-sm", children: "Repo" }), _jsx(SelectItem, { value: "tbill3m", className: "text-sm", children: "3M T-Bill" })] })] }) }), _jsx(Cell, { label: "Benchmark %", children: _jsx(NumberField, { value: customFloatBase, step: "0.01", allowNull: true, onCommit: (v) => setCustomFloatValue(v), className: LEG_INPUT }) })] })), _jsx(Cell, { label: "Spread (bps)", children: isFloat ? (_jsx(NumberField, { value: rowSpread, step: "1", min: 0, onCommit: (v) => setFloatingSpread(Math.max(0, Math.round(v ?? 0)), key), className: LEG_INPUT })) : (_jsx(LegReadonly, { value: "\u2014" })) }), _jsx(Cell, { label: "CoF %", children: isCustomFixed ? (_jsx(NumberField, { value: customCofPct, step: "0.01", allowNull: true, onCommit: (v) => setCustomCof(v), className: LEG_INPUT })) : (_jsx(LegReadonly, { value: base !== null ? `${base.toFixed(2)}%` : "—" })) }), _jsx(Cell, {
                        label: "Margin (bps)", children: _jsx(NumberField, {
                            value: r.marginBps ?? minMarginBps, step: "1", min: 0, onCommit: (v) => {
                                const bps = Math.max(0, Math.round(v ?? 0));
                                updateSplit(r.id, {
                                    marginBps: bps,
                                    ratePct: base !== null ? +(base + bps / 100).toFixed(2) : r.ratePct,
                                });
                            }, className: LEG_INPUT
                        })
                    }), _jsx(Cell, { label: "Rate %", children: _jsx(LegReadonly, { value: `${r.ratePct.toFixed(2)}%` }) }), _jsx(Cell, {
                        label: "Amount \u20B9Cr", children: _jsx(NumberField, {
                            value: r.amountCr, step: "0.01", min: 0, max: state.principalCr, onCommit: (v) => {
                                const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                                const others = splitTotal(state, "mser") - r.amountCr;
                                const needed = amt + others;
                                const p = { splits: allSplits.map((x) => (x.id === r.id ? { ...x, amountCr: amt } : x)) };
                                if (needed > mserAmt + 1e-9 && state.principalCr > 0)
                                    p.mserSharePct = (Math.min(needed, state.principalCr) / state.principalCr) * 100;
                                patch(p);
                            }, className: LEG_INPUT
                        })
                    }), _jsx(Cell, { label: "Repayment", children: _jsxs(Select, { value: freq, onValueChange: (v) => updateSplit(r.id, { freq: v }), children: [_jsx(SelectTrigger, { className: LEG_SELECT, children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: FREQUENCIES.map((f) => _jsx(SelectItem, { value: f.key, className: "text-sm", children: f.label }, f.key)) })] }) }), _jsx(Cell, { label: "Tenure (mo)", children: _jsx(NumberField, { value: r.tenureMonths, step: "1", min: 1, onCommit: (v) => updateSplit(r.id, { tenureMonths: Math.max(1, Math.round(v ?? 1)) }), className: LEG_INPUT }) }), _jsx(Cell, { label: "Moratorium (mo)", children: _jsx(NumberField, { value: r.moratoriumMonths, step: "1", min: 0, onCommit: (v) => updateSplit(r.id, { moratoriumMonths: Math.max(0, Math.round(v ?? 0)) }), className: LEG_INPUT }) }), freq === "custom" && (_jsx(Cell, { label: "Repay last (mo)", children: _jsx(NumberField, { value: r.customTailMonths ?? 3, step: "1", min: 1, max: r.tenureMonths, onCommit: (v) => updateSplit(r.id, { customTailMonths: Math.max(1, Math.min(r.tenureMonths, Math.round(v ?? 3))) }), className: LEG_INPUT }) }))]
                }, r.id));
            })]
        }), _jsxs("div", { className: "flex items-center justify-between gap-2", children: [_jsx("span", { className: cn("text-[10px] tabular", over ? "text-mds-danger font-semibold" : "text-muted-foreground"), children: over ? "Exceeds scheme amount" : "" }), _jsx("button", { type: "button", onClick: onAdd, disabled: !canAdd, className: "h-7 rounded bg-mds-blue px-2.5 text-[10px] font-semibold uppercase tracking-wider text-white disabled:opacity-40", children: "+ Add MSER split" })] })]
    }));
}
function SubHead({ title, hint }) {
    return (_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "h-4 w-1 shrink-0 rounded bg-mds-blue" }), _jsx("span", { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy", children: title }), hint && _jsxs("span", { className: "text-[11px] text-muted-foreground truncate", children: ["\u00B7 ", hint] })] }));
}
function MicroField({ label, children }) {
    return (_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-[9px] uppercase tracking-wider text-muted-foreground", children: label }), children] }));
}
function Field({ label, children }) {
    return (_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { className: "text-xs text-muted-foreground", children: label }), children] }));
}
function monthsBetween(from, to) {
    return roundedMonthsBetween(from, to);
}
function toISODate(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
}
const TRANCHE_STORE_KEY = "sidbi.rmse.tranches.v4";
function defaultTranches() {
    return [
        { id: "t1", label: "RMSE-XV-Regular", date: toISODate(RMSE_MATURITY_DATE), fundRatePct: 3.50, marginBps: 75 },
        { id: "t2", label: "RMSE-XIV-Regular", date: toISODate(new Date(2028, 6, 30)), fundRatePct: 3.74, marginBps: 75 },
        { id: "t3", label: "RMSE-XIII-Regular", date: toISODate(new Date(2028, 5, 4)), fundRatePct: 4.46, marginBps: 75 },
    ];
}
function parseISODate(s) {
    const [y, m, d] = s.split("-").map(Number);
    return new Date(y, (m ?? 1) - 1, d ?? 1);
}
/* ============================================================
   RMSE rows — first row plus splits, all rendered identically.
   Owns the tranche master (add / delete) used by every RMSE row.
   ============================================================ */
function RmseLegs({ state, rmseAmt, patch, patchScheme, onAdd, canAdd, }) {
    const today = useMemo(() => {
        const n = new Date();
        return new Date(n.getFullYear(), n.getMonth(), n.getDate());
    }, []);
    const [tranches, setTranches] = useState(defaultTranches);
    const [baseTrancheId, setBaseTrancheId] = useState("t1");
    // Expose the selected base tranche so the term-sheet PDF can quote its maturity date.
    useEffect(() => {
        try {
            window.localStorage.setItem("sidbi.rmse.baseTranche", baseTrancheId);
        }
        catch { /* ignore */ }
    }, [baseTrancheId]);
    const [adjust, setAdjust] = useState({});
    const [manageOpen, setManageOpen] = useState(false);
    const [pendingDelete, setPendingDelete] = useState(null);
    const [newLabel, setNewLabel] = useState("");
    const [newDate, setNewDate] = useState(null);
    const [newFund, setNewFund] = useState("3.50");
    const [newMargin, setNewMargin] = useState("75");
    const [editId, setEditId] = useState(null);
    const [editDraft, setEditDraft] = useState({ label: "", date: null, fund: "3.50", margin: "75" });
    useEffect(() => {
        try {
            const raw = window.localStorage.getItem(TRANCHE_STORE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed) && parsed.length) {
                    setTranches(parsed);
                    setBaseTrancheId(parsed[0].id);
                }
            }
        }
        catch { /* ignore */ }
    }, []);
    const persist = (next) => {
        setTranches(next);
        try {
            window.localStorage.setItem(TRANCHE_STORE_KEY, JSON.stringify(next));
        }
        catch { /* ignore */ }
    };
    const trancheOf = (id) => tranches.find((t) => t.id === id) ?? tranches[0];
    const baseTenureOf = (id) => {
        const t = trancheOf(id);
        return t ? roundedMonthsBetween(today, parseISODate(t.date)) : 12;
    };
    const derived = (id, legId) => {
        const t = trancheOf(id);
        const adj = adjust[legId] ?? 0;
        const baseTen = baseTenureOf(id);
        return {
            tranche: t,
            tenure: Math.max(1, baseTen + adj),
            rate: t ? +(t.fundRatePct + t.marginBps / 100).toFixed(2) : 0,
            adj,
            baseTen,
        };
    };
    const baseD = derived(baseTrancheId, "rmse-base");
    // Keep the base RMSE leg in sync with its tranche.
    useEffect(() => {
        if (baseD.tenure !== state.rmse.tenureMonths)
            patchScheme("rmse", { tenureMonths: baseD.tenure });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [baseD.tenure]);
    useEffect(() => {
        if (baseD.rate && baseD.rate !== state.rmse.ratePct)
            patchScheme("rmse", { ratePct: baseD.rate });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [baseD.rate]);
    const allSplits = state.splits ?? [];
    const splits = allSplits.filter((sp) => sp.scheme === "rmse");
    const updateSplit = (id, p) => patch({ splits: allSplits.map((x) => (x.id === id ? { ...x, ...p } : x)) });
    const removeSplit = (id) => patch({ splits: allSplits.filter((x) => x.id !== id) });
    const baseAmt = baseLegAmount(state, "rmse");
    const over = splitTotal(state, "rmse") > rmseAmt + 1e-6;
    const showTail = splits.some((sp) => (sp.freq ?? "bullet") === "custom");
    void showTail;
    // Tenure is derived from the tranche maturity but fully editable — typing a
    // value simply stores the offset from the tranche-implied tenure (no cap).
    const stepper = (legId, tenure, baseTen) => (_jsxs("div", {
        className: "flex items-center h-9 rounded-md border border-input bg-white pl-0.5 pr-0.5", children: [_jsx(NumberField, {
            value: tenure, step: "1", min: 1, onCommit: (v) => {
                const t = Math.max(1, Math.round(v ?? 1));
                setAdjust((a) => ({ ...a, [legId]: t - baseTen }));
            }, className: "h-8 border-0 shadow-none focus-visible:ring-0 px-1.5 text-sm tabular flex-1 bg-transparent"
        }), _jsxs("div", { className: "flex flex-col", children: [_jsx("button", { type: "button", className: "h-3 px-0.5 flex items-center text-muted-foreground hover:text-foreground", onClick: () => setAdjust((a) => ({ ...a, [legId]: (a[legId] ?? 0) + 1 })), children: _jsx(ChevronUp, { className: "h-2.5 w-2.5" }) }), _jsx("button", { type: "button", className: "h-3 px-0.5 flex items-center text-muted-foreground hover:text-foreground disabled:opacity-30", disabled: tenure <= 1, onClick: () => setAdjust((a) => ({ ...a, [legId]: (a[legId] ?? 0) - 1 })), children: _jsx(ChevronDown, { className: "h-2.5 w-2.5" }) })] })]
    }));
    // Re-picking the SAME tranche must also reset the tenure back to the
    // tranche-implied value, so we handle the item click directly (Radix skips
    // onValueChange when the value is unchanged).
    const trancheSelect = (value, onChange) => (_jsxs(Select, {
        value: value, onValueChange: onChange, children: [_jsx(SelectTrigger, { className: LEG_SELECT, children: _jsx(SelectValue, { placeholder: "Tranche" }) }), _jsx(SelectContent, {
            children: tranches.map((t) => (_jsx(SelectItem, {
                value: t.id, className: "text-xs", children: _jsxs("span", {
                    onPointerDown: () => {
                        if (t.id === value)
                            setTimeout(() => onChange(t.id), 0);
                    }, children: [t.label, " \u00B7 ", format(parseISODate(t.date), "dd MMM yyyy"), " \u00B7 ", (t.fundRatePct + t.marginBps / 100).toFixed(2), "%"]
                })
            }, t.id)))
        })]
    }));
    const addTranche = () => {
        if (!newDate)
            return;
        const id = `t${Date.now()}`;
        const label = newLabel.trim() || `RMSE-${tranches.length + 1}-Regular`;
        persist([...tranches, {
            id, label, date: toISODate(newDate),
            fundRatePct: Number(newFund) || 0,
            marginBps: Number(newMargin) || 0,
        }]);
        setBaseTrancheId(id);
        setAdjust((a) => ({ ...a, "rmse-base": 0 }));
        setNewLabel("");
        setNewDate(null);
        setNewFund("3.50");
        setNewMargin("75");
    };
    const startEdit = (t) => {
        setEditId(t.id);
        setEditDraft({
            label: t.label,
            date: parseISODate(t.date),
            fund: t.fundRatePct.toFixed(2),
            margin: String(t.marginBps),
        });
    };
    const saveEdit = () => {
        if (!editId || !editDraft.date)
            return;
        const updated = {
            id: editId,
            label: editDraft.label.trim() || "RMSE-Regular",
            date: toISODate(editDraft.date),
            fundRatePct: Number(editDraft.fund) || 0,
            marginBps: Number(editDraft.margin) || 0,
        };
        persist(tranches.map((x) => (x.id === editId ? updated : x)));
        // Re-sync any RMSE split drawing on this tranche.
        const rate = +(updated.fundRatePct + updated.marginBps / 100).toFixed(2);
        const tenure = roundedMonthsBetween(today, parseISODate(updated.date));
        const touched = allSplits.some((x) => x.scheme === "rmse" && (x.trancheId ?? baseTrancheId) === editId);
        if (touched) {
            patch({
                splits: allSplits.map((x) => x.scheme === "rmse" && (x.trancheId ?? baseTrancheId) === editId
                    ? { ...x, ratePct: rate, tenureMonths: tenure }
                    : x),
            });
        }
        setEditId(null);
    };
    const deleteTranche = (t) => {
        const next = tranches.filter((x) => x.id !== t.id);
        const final = next.length ? next : defaultTranches();
        persist(final);
        if (baseTrancheId === t.id) {
            setBaseTrancheId(final[0].id);
            setAdjust((a) => ({ ...a, "rmse-base": 0 }));
        }
        setPendingDelete(null);
    };
    return (_jsxs("div", {
        className: "space-y-3", children: [_jsxs("div", {
            className: "divide-y divide-border/70", children: [_jsxs(LegRow, {
                label: splits.length > 0 ? "RMSE 1" : undefined, right: _jsx("span", { className: "text-xs tabular text-muted-foreground", children: "Bullet" }), children: [_jsx(Cell, { label: "Tranche (maturity)", span: "col-span-2 xl:col-span-3", children: trancheSelect(baseTrancheId, (v) => { setBaseTrancheId(v); setAdjust((a) => ({ ...a, "rmse-base": 0 })); }) }), _jsx(Cell, { label: "Rate %", children: _jsx(LegReadonly, { value: `${state.rmse.ratePct.toFixed(2)}%` }) }), _jsx(Cell, {
                    label: "Amount \u20B9Cr", children: _jsx(NumberField, {
                        value: +baseAmt.toFixed(2), step: "0.01", min: 0, max: state.principalCr, onCommit: (v) => {
                            const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                            const newRmse = Math.min(state.principalCr, amt + splitTotal(state, "rmse"));
                            patch({ mserSharePct: state.principalCr > 0 ? ((state.principalCr - newRmse) / state.principalCr) * 100 : 100 });
                        }, className: LEG_INPUT
                    })
                }), _jsx(Cell, { label: "Tenure (mo)", children: stepper("rmse-base", baseD.tenure, baseD.baseTen) }), _jsx(Cell, { label: "Moratorium (mo)", children: _jsx(NumberField, { value: state.rmse.moratoriumMonths, step: "1", min: 0, onCommit: (v) => patchScheme("rmse", { moratoriumMonths: Math.max(0, Math.round(v ?? 0)) }), className: LEG_INPUT }) })]
            }), splits.map((r, i) => {
                const d = derived(r.trancheId ?? baseTrancheId, r.id);
                if ((r.freq ?? "bullet") !== "bullet")
                    queueMicrotask(() => updateSplit(r.id, { freq: "bullet" }));
                return (_jsxs(LegRow, {
                    label: `RMSE ${i + 2}`, right: _jsxs("span", { className: "text-[10px] tabular text-muted-foreground", children: ["\u20B9", r.amountCr.toFixed(2), " Cr \u00B7 Bullet"] }), onRemove: () => removeSplit(r.id), children: [_jsx(Cell, {
                        label: "Tranche (maturity)", span: "col-span-2 xl:col-span-3", children: trancheSelect(r.trancheId ?? baseTrancheId, (v) => {
                            setAdjust((a) => ({ ...a, [r.id]: 0 }));
                            const t = trancheOf(v);
                            updateSplit(r.id, {
                                trancheId: v,
                                ratePct: t ? +(t.fundRatePct + t.marginBps / 100).toFixed(2) : r.ratePct,
                                tenureMonths: t ? roundedMonthsBetween(today, parseISODate(t.date)) : r.tenureMonths,
                            });
                        })
                    }), _jsx(Cell, { label: "Rate %", children: _jsx(LegReadonly, { value: `${r.ratePct.toFixed(2)}%` }) }), _jsx(Cell, {
                        label: "Amount \u20B9Cr", children: _jsx(NumberField, {
                            value: r.amountCr, step: "0.01", min: 0, max: state.principalCr, onCommit: (v) => {
                                const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                                const others = splitTotal(state, "rmse") - r.amountCr;
                                const needed = amt + others;
                                const p = { splits: allSplits.map((x) => (x.id === r.id ? { ...x, amountCr: amt } : x)) };
                                if (needed > rmseAmt + 1e-9 && state.principalCr > 0)
                                    p.mserSharePct = ((state.principalCr - Math.min(needed, state.principalCr)) / state.principalCr) * 100;
                                patch(p);
                            }, className: LEG_INPUT
                        })
                    }), _jsx(Cell, {
                        label: "Tenure (mo)", children: (() => {
                            if (d.tenure !== r.tenureMonths) {
                                queueMicrotask(() => updateSplit(r.id, { tenureMonths: d.tenure }));
                            }
                            return stepper(r.id, d.tenure, d.baseTen);
                        })()
                    }), _jsx(Cell, { label: "Moratorium (mo)", children: _jsx(NumberField, { value: r.moratoriumMonths, step: "1", min: 0, onCommit: (v) => updateSplit(r.id, { moratoriumMonths: Math.max(0, Math.round(v ?? 0)) }), className: LEG_INPUT }) })]
                }, r.id));
            })]
        }), _jsxs("div", { className: "flex items-center justify-between gap-2", children: [_jsx("span", { className: cn("text-[10px] tabular", over ? "text-mds-danger font-semibold" : "text-muted-foreground"), children: over ? "Exceeds scheme amount" : "" }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx("button", { type: "button", onClick: onAdd, disabled: !canAdd, className: "h-7 rounded bg-mds-blue px-2.5 text-[10px] font-semibold uppercase tracking-wider text-white disabled:opacity-40", children: "+ Add RMSE split" }), _jsx(Button, { type: "button", size: "sm", onClick: () => setManageOpen(true), className: "h-7 px-2.5 text-[10px] font-semibold uppercase tracking-wider bg-mds-blue hover:bg-mds-blue-hover text-white", children: "Manage tranches" })] })] }), _jsx(Dialog, {
            open: manageOpen, onOpenChange: setManageOpen, children: _jsxs(DialogContent, {
                className: "max-w-md", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { className: "text-base text-mds-navy", children: "RMSE tranche master" }), _jsx(DialogDescription, { className: "text-xs", children: "Add a newly announced tranche once \u2014 it becomes available in the tranche dropdown. Remove tranches that are fully utilised." })] }), _jsxs("div", {
                    className: "space-y-2", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Existing tranches" }), _jsx("div", {
                        className: "rounded-md border border-border divide-y", children: tranches.map((t) => (editId === t.id ? (_jsxs("div", {
                            className: "space-y-2 px-3 py-2 bg-mds-blue/5", children: [_jsxs("div", {
                                className: "grid grid-cols-2 gap-2", children: [_jsx(Input, { value: editDraft.label, onChange: (e) => setEditDraft((d) => ({ ...d, label: e.target.value })), className: "h-9 text-sm bg-white" }), _jsxs(Popover, {
                                    children: [_jsx(PopoverTrigger, { asChild: true, children: _jsxs(Button, { variant: "outline", className: "h-9 justify-start text-sm bg-white font-normal", children: [_jsx(CalendarIcon, { className: "h-3.5 w-3.5 mr-2" }), editDraft.date ? format(editDraft.date, "dd MMM yyyy") : "Maturity date"] }) }), _jsx(PopoverContent, {
                                        className: "w-auto p-2", align: "start", children: _jsx(Calendar, {
                                            mode: "single", selected: editDraft.date ?? undefined, onSelect: (dt) => {
                                                if (!dt || dt <= today)
                                                    return;
                                                setEditDraft((d) => ({ ...d, date: new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()) }));
                                            }, disabled: (dt) => dt <= today, defaultMonth: editDraft.date ?? RMSE_MATURITY_DATE, captionLayout: "dropdown", startMonth: new Date(today.getFullYear(), today.getMonth()), endMonth: new Date(today.getFullYear() + 30, 11), className: cn("p-0 pointer-events-auto")
                                        })
                                    })]
                                })]
                            }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "RBI fund rate %" }), _jsx(Input, { value: editDraft.fund, onChange: (e) => setEditDraft((d) => ({ ...d, fund: e.target.value })), inputMode: "decimal", className: "h-9 text-sm bg-white tabular" })] }), _jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Margin (bps)" }), _jsx(Input, { value: editDraft.margin, onChange: (e) => setEditDraft((d) => ({ ...d, margin: e.target.value })), inputMode: "numeric", className: "h-9 text-sm bg-white tabular" })] })] }), _jsxs("div", { className: "text-[10px] text-muted-foreground tabular", children: ["Tranche rate = ", ((Number(editDraft.fund) || 0) + (Number(editDraft.margin) || 0) / 100).toFixed(2), "%"] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Button, { size: "sm", className: "h-8 flex-1 text-xs", disabled: !editDraft.date, onClick: saveEdit, children: "Save changes" }), _jsx(Button, { size: "sm", variant: "ghost", className: "h-8 text-xs", onClick: () => setEditId(null), children: "Cancel" })] })]
                        }, t.id)) : (_jsxs("div", { className: "flex items-center justify-between gap-2 px-3 py-2", children: [_jsxs("div", { children: [_jsx("div", { className: "text-xs font-semibold text-mds-navy", children: t.label }), _jsxs("div", { className: "text-[10px] text-muted-foreground tabular", children: ["Matures ", format(parseISODate(t.date), "dd MMM yyyy"), " \u00B7 fund ", t.fundRatePct.toFixed(2), "% + ", t.marginBps, " bps = ", (t.fundRatePct + t.marginBps / 100).toFixed(2), "%"] })] }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Button, { variant: "ghost", size: "sm", className: "h-7 text-[11px] text-mds-blue", onClick: () => startEdit(t), children: "Edit" }), _jsx(Button, { variant: "ghost", size: "sm", className: "h-7 text-[11px] text-destructive hover:text-destructive", onClick: () => setPendingDelete(t), children: "Delete" })] })] }, t.id))))
                    })]
                }), _jsxs("div", {
                    className: "space-y-2 rounded-md border border-mds-blue/30 bg-mds-blue/5 p-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Add new tranche" }), _jsxs("div", {
                        className: "grid grid-cols-2 gap-2", children: [_jsx(Input, { value: newLabel, onChange: (e) => setNewLabel(e.target.value), className: "h-9 text-sm bg-white" }), _jsxs(Popover, {
                            children: [_jsx(PopoverTrigger, { asChild: true, children: _jsxs(Button, { variant: "outline", className: "h-9 justify-start text-sm bg-white font-normal", children: [_jsx(CalendarIcon, { className: "h-3.5 w-3.5 mr-2" }), newDate ? format(newDate, "dd MMM yyyy") : "Maturity date"] }) }), _jsx(PopoverContent, {
                                className: "w-auto p-2", align: "start", children: _jsx(Calendar, {
                                    mode: "single", selected: newDate ?? undefined, onSelect: (dt) => {
                                        if (!dt || dt <= today)
                                            return;
                                        setNewDate(new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()));
                                    }, disabled: (dt) => dt <= today, defaultMonth: newDate ?? RMSE_MATURITY_DATE, captionLayout: "dropdown", startMonth: new Date(today.getFullYear(), today.getMonth()), endMonth: new Date(today.getFullYear() + 30, 11), className: cn("p-0 pointer-events-auto")
                                })
                            })]
                        })]
                    }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "RBI fund rate %" }), _jsx(Input, { value: newFund, onChange: (e) => setNewFund(e.target.value), inputMode: "decimal", className: "h-9 text-sm bg-white tabular" })] }), _jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Margin (bps)" }), _jsx(Input, { value: newMargin, onChange: (e) => setNewMargin(e.target.value), inputMode: "numeric", className: "h-9 text-sm bg-white tabular" })] })] }), _jsxs("div", { className: "text-[10px] text-muted-foreground tabular", children: ["Tranche rate = ", ((Number(newFund) || 0) + (Number(newMargin) || 0) / 100).toFixed(2), "% (fixed for this tranche)"] }), _jsx(Button, { size: "sm", className: "h-8 w-full text-xs", disabled: !newDate, onClick: addTranche, children: "Add tranche" })]
                })]
            })
        }), _jsx(AlertDialog, {
            open: !!pendingDelete, onOpenChange: (o) => {
                if (!o)
                    setPendingDelete(null);
            }, children: _jsxs(AlertDialogContent, {
                children: [_jsxs(AlertDialogHeader, {
                    children: [_jsx(AlertDialogTitle, { className: "text-base", children: "Delete this tranche?" }), _jsx(AlertDialogDescription, {
                        className: "text-xs", children: pendingDelete
                            ? `${pendingDelete.label} (matures ${format(parseISODate(pendingDelete.date), "dd MMM yyyy")}) will be removed from the tranche dropdown. This cannot be undone.`
                            : ""
                    })]
                }), _jsxs(AlertDialogFooter, { children: [_jsx(AlertDialogCancel, { className: "text-xs", children: "Keep tranche" }), _jsx(AlertDialogAction, { className: "text-xs bg-destructive text-destructive-foreground hover:bg-destructive/90", onClick: () => pendingDelete && deleteTranche(pendingDelete), children: "Yes, delete" })] })]
            })
        })]
    }));
}
function NumberField({ value, onCommit, step, className, placeholder = "0", allowNull, disabled, max, min, }) {
    const [draft, setDraft] = useState(null);
    const display = value === null || value === undefined || value === 0
        ? ""
        : String(value);
    const shown = draft ?? display;
    const clamp = (n) => {
        let v = n;
        if (typeof max === "number" && v > max)
            v = max;
        if (typeof min === "number" && v < min)
            v = min;
        return v;
    };
    return (_jsx(Input, {
        type: "number", step: step ?? "any", max: max, min: min, value: shown, placeholder: placeholder, onFocus: (e) => {
            e.currentTarget.select();
        }, onChange: (e) => {
            const raw = e.target.value;
            if (raw === "" || raw === "-" || raw === ".") {
                setDraft(raw);
                return;
            }
            const n = parseFloat(raw);
            if (Number.isNaN(n)) {
                setDraft(raw);
                return;
            }
            const c = clamp(n);
            if (c !== n) {
                setDraft(String(c));
                onCommit(c);
            }
            else {
                setDraft(raw);
                onCommit(n);
            }
        }, onBlur: () => {
            if (draft === "" && allowNull)
                onCommit(null);
            setDraft(null);
        }, className: className, disabled: disabled
    }));
}
function NumInput({ label, value, onChange, step, locked, max, hint }) {
    return (_jsxs("div", {
        className: "space-y-1", children: [_jsxs("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground whitespace-nowrap flex items-center gap-1", children: [_jsx("span", { children: label }), hint && _jsxs("span", { className: "text-[10px] text-mds-blue/70 font-semibold", children: ["\u00B7 ", hint] })] }), _jsx(NumberField, {
            value: value, step: step ?? 1, max: max, onCommit: (v) => {
                let n = v ?? 0;
                if (max !== undefined && n > max)
                    n = max;
                onChange(n);
            }, disabled: locked, className: cn("h-9 text-sm tabular px-2 w-full", locked
                ? "bg-white border-input text-black cursor-not-allowed opacity-100"
                : "bg-white border-input")
        })]
    }));
}
function FixedDisplay({ label, value, hint, strong }) {
    return (_jsxs("div", { className: "space-y-1", children: [_jsxs("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground whitespace-nowrap flex items-center gap-1", children: [_jsx("span", { children: label }), hint && _jsxs("span", { className: "text-[10px] text-mds-blue/70 font-semibold", children: ["\u00B7 ", hint] })] }), _jsx("div", { className: cn("h-9 rounded-md border flex items-center px-2 text-sm tabular", "bg-white border-input text-black"), children: value })] }));
}
function MiniStat({ label, value, note }) {
    return (_jsxs("div", { children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-white/60", children: label }), _jsx("div", { className: "text-lg font-bold tabular mt-0.5", children: value }), note ? _jsx("div", { className: "text-[11px] text-white/70 mt-0.5", children: note }) : null] }));
}
function MiniKV({ k, v }) {
    return (_jsxs("div", { className: "flex items-baseline justify-between gap-3 text-[11px]", children: [_jsx("span", { className: "text-muted-foreground", children: k }), _jsx("span", { className: "tabular text-mds-navy font-medium text-right", children: v })] }));
}
// Short badges shown directly on the bar. The full label + value lives in
// the legend below, so we only need a compact identifier per tick.
const SHORT_LABEL = {
    cof: "CoF",
    counterparty: "Bank-Alt",
    std: "Std",
    sug: "Sug",
    current: "MSER Quote",
    gsec: "G-Sec",
    cd: "CD",
    cp: "CP",
    dep: "Bulk Deposit",
    war: "WAR (Quote)",
    bulkmax: "Bulk Deposit",
    deskquote: "CP Quote",
};
// Stack overlapping badges into rows so they never collide.
function stackRows(items, minGap = 12) {
    const sorted = [...items].sort((a, b) => a.pct - b.pct);
    const lastPctInRow = [];
    return sorted.map((m) => {
        let row = 0;
        while (lastPctInRow[row] !== undefined && m.pct - lastPctInRow[row] < minGap)
            row++;
        lastPctInRow[row] = m.pct;
        return { ...m, row };
    });
}
function NegotiationRangeBar({ min, max, markers, onDark }) {
    // Build a strictly left-to-right numerical domain from every visible value.
    // This makes marker position monotonic: a higher rate can never render to the
    // left of a lower rate, even when quotes exceed the bulk-deposit ceiling.
    const cleanMarkers = markers.filter((m) => Number.isFinite(m.value));
    const values = [min, max, ...cleanMarkers.map((m) => m.value)].filter((v) => Number.isFinite(v));
    const lo = Math.min(...values);
    const hi = Math.max(...values);
    const rawSpan = Math.max(0.01, hi - lo);
    const pad = Math.max(0.05, rawSpan * 0.08);
    const domainMin = lo - pad;
    const domainMax = hi + pad;
    const span = Math.max(0.01, domainMax - domainMin);
    const pct = (v) => Math.max(0, Math.min(100, ((v - domainMin) / span) * 100));
    // Auto-balance: if too many markers land on one side, push the densest
    // ones from bottom → top (or vice versa) to keep stack height compact.
    const rebalanced = (() => {
        const tops = cleanMarkers.filter((m) => m.position === "top");
        const bots = cleanMarkers.filter((m) => m.position === "bottom");
        // No rebalance needed if already fairly split
        if (Math.abs(tops.length - bots.length) <= 1)
            return cleanMarkers;
        return cleanMarkers;
    })();
    const enriched = rebalanced.map((m) => ({
        ...m,
        pct: pct(m.value),
        short: SHORT_LABEL[m.key] ?? m.label.slice(0, 4),
    }));
    const chipTranslate = (positionPct) => {
        if (positionPct <= 8)
            return "translateX(0)";
        if (positionPct >= 92)
            return "translateX(-100%)";
        return "translateX(-50%)";
    };
    const chipAlign = (positionPct) => {
        if (positionPct <= 8)
            return "items-start";
        if (positionPct >= 92)
            return "items-end";
        return "items-center";
    };
    // Chip is ~72px wide; require at least that much horizontal gap between
    // chips on the same row. Convert to a % of the bar so stacking is
    // container-aware. Assume ~560px typical bar width → ~13%.
    const MIN_GAP_PCT = 14;
    const topItems = stackRows(enriched.filter((m) => m.position === "top"), MIN_GAP_PCT);
    const bottomItems = stackRows(enriched.filter((m) => m.position === "bottom"), MIN_GAP_PCT);
    const topRows = Math.max(1, ...topItems.map((m) => m.row + 1));
    const bottomRows = Math.max(1, ...bottomItems.map((m) => m.row + 1));
    const ROW_H = 22;
    const chip = (m) => (_jsxs("div", { className: "px-1.5 py-0.5 rounded text-[10px] font-semibold leading-none whitespace-nowrap text-white shadow-sm flex items-center gap-1", style: { background: m.color }, title: `${m.label}: ${m.value.toFixed(2)}%`, children: [_jsx("span", { children: m.short }), _jsx("span", { className: "tabular opacity-90", children: m.value.toFixed(2) })] }));
    return (_jsxs("div", {
        className: "px-1", children: [_jsx("div", {
            className: "relative mb-1.5", style: { height: topRows * ROW_H }, children: topItems.map((m) => {
                const bottom = m.row * ROW_H;
                return (_jsxs("div", { className: cn("absolute flex flex-col", chipAlign(m.pct)), style: { left: `${m.pct}%`, bottom, transform: chipTranslate(m.pct) }, children: [chip(m), _jsx("div", { className: cn("w-px", onDark ? "bg-white/40" : "bg-border"), style: { height: bottom + 2 } })] }, m.key));
            })
        }), _jsxs("div", { className: cn("relative h-4 rounded-full bg-gradient-to-r from-mds-success/30 via-mds-warning/40 to-mds-danger/40 border", onDark ? "border-white/25" : "border-border/40"), children: [_jsxs("div", { className: cn("absolute -bottom-4 left-0 text-[10px] tabular", onDark ? "text-white/60" : "text-muted-foreground"), children: [domainMin.toFixed(2), "%"] }), _jsxs("div", { className: cn("absolute -bottom-4 right-0 text-[10px] tabular", onDark ? "text-white/60" : "text-muted-foreground"), children: [domainMax.toFixed(2), "%"] }), enriched.map((m) => (_jsx("div", { className: "absolute -top-1 h-6 w-0.5 rounded", style: { left: `${m.pct}%`, background: m.color } }, `tick-${m.key}`)))] }), _jsx("div", {
            className: "relative mt-5", style: { height: bottomRows * ROW_H }, children: bottomItems.map((m) => {
                const top = m.row * ROW_H;
                return (_jsxs("div", { className: cn("absolute flex flex-col", chipAlign(m.pct)), style: { left: `${m.pct}%`, top: 0, transform: chipTranslate(m.pct) }, children: [_jsx("div", { className: cn("w-px", onDark ? "bg-white/40" : "bg-border"), style: { height: top + 2 } }), chip(m)] }, m.key));
            })
        })]
    }));
}
function RangeStat({ label, value, tone, swatch }) {
    const color = tone === "warning" ? "text-mds-warning"
        : tone === "success" ? "text-mds-success"
            : tone === "navy" ? "text-mds-navy"
                : tone === "blue" ? "text-mds-blue"
                    : "text-mds-navy";
    return (_jsxs("div", { className: "rounded-md border border-border bg-secondary/30 p-2", children: [_jsxs("div", { className: "flex items-center gap-1.5", children: [swatch && _jsx("span", { className: "w-2 h-2 rounded-sm shrink-0", style: { background: swatch } }), _jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground truncate", children: label })] }), _jsx("div", { className: cn("text-sm font-bold tabular mt-0.5", color), children: value })] }));
}
/** Floor build-up + approval status for one MSER row (base or split). */
function MserFloorPanel({ title, rateLabel, ratePct, cofPct, cofLabel, minMarginBps, maxDiscretionBps, categoryLabel, }) {
    if (cofPct === null)
        return null;
    const marginBpsRow = Math.round((ratePct - cofPct) * 100);
    const standard = cofPct + minMarginBps / 100;
    const premiumBps = Math.max(0, marginBpsRow - minMarginBps);
    const discBps = Math.max(0, minMarginBps - marginBpsRow);
    const belowCof = marginBpsRow < 0;
    const overSca = discBps > maxDiscretionBps || belowCof;
    const needsScaOnly = discBps > 0 && !overSca;
    const hasPremium = premiumBps > 0;
    return (_jsxs("div", {
        className: cn("rounded-lg border p-4", overSca ? "border-mds-danger/40 bg-mds-danger/5"
            : needsScaOnly ? "border-mds-warning/40 bg-mds-warning/5"
                : hasPremium ? "border-mds-success/40 bg-mds-success/5"
                    : "border-border bg-secondary/40"), children: [_jsx("div", { className: "text-[10px] uppercase tracking-widest text-muted-foreground mb-2", children: title }), _jsx(FloorRow, { label: "Cost of Funds", sub: `Treasury · ${cofLabel}`, value: cofPct }), _jsx(FloorRow, { label: "+ Min Margin", sub: `${minMarginBps} bps · ${categoryLabel}`, value: minMarginBps / 100, plus: true }), _jsx("div", { className: "border-t border-border my-2" }), _jsx(FloorRow, { label: "Standard Rate", value: standard, strong: true }), hasPremium && (_jsx(FloorRow, { label: "+ Margin", sub: `+${premiumBps} bps above min prescribed margin\u00a0`, value: premiumBps / 100, plus: true })), needsScaOnly && (_jsx(FloorRow, { label: "\u2212 Discretion (SCA)", sub: `${discBps} of ${maxDiscretionBps} bps · SCA approval required`, value: discBps / 100, minus: true })), overSca && (_jsx(FloorRow, {
                        label: "\u2212 Discretion (ALCO)", sub: belowCof
                            ? `${discBps} bps · rate below Cost of Funds · ALCO approval required`
                            : `${discBps} bps · exceeds SCA limit of ${maxDiscretionBps} bps · ALCO approval required`, value: discBps / 100, minus: true, danger: true
                    })), _jsx("div", { className: "border-t border-border my-2" }), _jsx(FloorRow, { label: rateLabel, sub: `margin ${marginBpsRow} bps over CoF`, value: ratePct, big: true, danger: overSca }), _jsx("div", {
                        className: cn("text-[11px] font-semibold mt-2 pt-2 border-t border-border uppercase tracking-wider", overSca ? "text-mds-danger"
                            : needsScaOnly ? "text-mds-warning"
                                : hasPremium ? "text-mds-success"
                                    : "text-muted-foreground"), children: belowCof
                                        ? "ALCO + Treasury approval required · below Cost of Funds"
                                        : overSca
                                            ? "ALCO approval required"
                                            : needsScaOnly
                                                ? "SCA approval required"
                                                : hasPremium
                                                    ? `Margin above min prescribed margin · +${premiumBps} bps`
                                                    : "Within standard · no approval required"
                    })]
    }));
}
function FloorRow({ label, sub, value, plus, minus, strong, big, danger }) {
    return (_jsxs("div", { className: cn("flex items-baseline justify-between py-1.5", big && "py-2"), children: [_jsxs("div", { children: [_jsx("span", { className: cn("text-sm", strong && "font-semibold", big && "font-bold", big && (danger ? "text-mds-danger" : "text-mds-navy")), children: label }), sub && _jsx("span", { className: cn("text-[11px] ml-2", danger && !big ? "text-mds-danger font-semibold" : "text-muted-foreground"), children: sub })] }), _jsxs("span", { className: cn("tabular text-sm font-medium", plus && "text-mds-success", minus && !danger && "text-mds-danger", minus && danger && "text-mds-danger font-semibold", big && "text-2xl font-bold", big && (danger ? "text-mds-danger" : "text-mds-blue")), children: [plus && "+ ", minus && "− ", value.toFixed(2), "%"] })] }));
}
function FinalPill({ label, sub, value, tone }) {
    const bg = tone === "blue" ? "bg-mds-blue/10 text-mds-blue"
        : tone === "success" ? "bg-mds-success/10 text-mds-success"
            : tone === "purple" ? "bg-mds-purple/10 text-mds-purple"
                : "bg-mds-navy/10 text-mds-navy";
    return (_jsxs("div", { className: cn("rounded-md p-3", bg), children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider opacity-80", children: label }), _jsx("div", { className: "text-xl font-bold tabular mt-1", children: value !== null ? `${value.toFixed(2)}%` : "—" }), sub && _jsx("div", { className: "text-[10px] mt-0.5 opacity-70 truncate", children: sub })] }));
}
function MultiRatePill({ label, rows, tone }) {
    if (rows.length === 0)
        return null;
    if (rows.length === 1) {
        return _jsx(FinalPill, { label: label, sub: rows[0].sub, value: rows[0].value, tone: tone });
    }
    const bg = tone === "blue" ? "bg-mds-blue/10 text-mds-blue"
        : tone === "success" ? "bg-mds-success/10 text-mds-success"
            : "bg-mds-navy/10 text-mds-navy";
    return (_jsxs("div", { className: cn("rounded-md p-3", bg), children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider opacity-80", children: label }), _jsx("div", { className: "mt-1 space-y-1", children: rows.map((r) => (_jsxs("div", { children: [_jsxs("div", { className: "flex items-baseline justify-between gap-2", children: [_jsx("span", { className: "text-[11px] font-medium opacity-80 truncate", children: r.label }), _jsx("span", { className: "text-base font-bold tabular", children: r.value !== null ? `${r.value.toFixed(2)}%` : "—" })] }), r.sub && _jsx("div", { className: "text-[10px] opacity-70 truncate", children: r.sub })] }, r.id))) })] }));
}
function MarketTile({ name, point, loading, sourceLabel, compact, pending }) {
    const hasValue = point.value !== null;
    return (_jsx(Card, { className: cn(pending && !hasValue && "border-dashed bg-secondary/20"), children: _jsxs(CardContent, { className: cn("p-4", compact && "p-3"), children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: name }), _jsx("span", { className: "text-[10px] tabular text-muted-foreground", children: point.source ?? sourceLabel })] }), _jsxs("div", { className: cn("font-bold tabular text-mds-navy mt-1", compact ? "text-xl" : "text-2xl"), children: [loading && !hasValue ? "…" : hasValue ? point.value.toFixed(2) : "—", _jsx("span", { className: "text-sm text-muted-foreground", children: "%" })] }), !hasValue && !loading && (_jsx("div", { className: "text-[10px] text-muted-foreground mt-1", children: pending ? "Feed pending" : "Not available" }))] }) }));
}
// ============ Market Instrument Tile ============
function InstrumentTile({ inst, onOpen, accent = "navy", liveValue = null, liveAsOf = null }) {
    const stroke = accent === "blue" ? "var(--mds-blue)" : "var(--mds-success)";
    const gradId = `grad-${inst.key}`;
    const shown = liveValue ?? inst.latest;
    const isLive = liveValue !== null && liveValue !== undefined;
    // If live, splice latest live value onto the tail of the sparkline
    const trendData = isLive
        ? [...inst.trend.slice(0, -1), { ...inst.trend[inst.trend.length - 1], value: liveValue }]
        : inst.trend;
    const asOfLabel = isLive && liveAsOf
        ? new Date(liveAsOf).toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" })
        : inst.asOf;
    return (_jsxs("button", { onClick: onOpen, style: { ["--tile-accent"]: stroke }, className: "relative text-left rounded-lg border border-border bg-white hover:border-[var(--tile-accent)] hover:shadow-md hover:-translate-y-0.5 transition-all p-3 group overflow-hidden", children: [_jsx("span", { className: "absolute inset-x-0 top-0 h-0.5", style: { background: stroke } }), _jsxs("div", { className: "flex items-start justify-between gap-2", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground truncate font-semibold", children: inst.short }), _jsxs("div", { className: "flex items-center gap-1 shrink-0", children: [isLive && _jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-mds-success animate-pulse", title: "Live" }), _jsx(Info, { className: "h-3 w-3 text-muted-foreground/60 group-hover:text-[var(--tile-accent)] mt-0.5" })] })] }), _jsxs("div", { className: "mt-1.5 flex items-baseline gap-0.5", children: [_jsx("span", { className: "text-xl font-bold tabular text-mds-navy leading-none", children: shown.toFixed(2) }), _jsx("span", { className: "text-[11px] text-muted-foreground", children: "%" })] }), _jsx("div", { className: "h-10 mt-2 -mx-1", children: _jsx(ResponsiveContainer, { width: "100%", height: "100%", children: _jsxs(AreaChart, { data: trendData, margin: { top: 2, right: 2, bottom: 0, left: 2 }, children: [_jsx("defs", { children: _jsxs("linearGradient", { id: gradId, x1: "0", y1: "0", x2: "0", y2: "1", children: [_jsx("stop", { offset: "0%", stopColor: stroke, stopOpacity: 0.28 }), _jsx("stop", { offset: "100%", stopColor: stroke, stopOpacity: 0 })] }) }), _jsx(Area, { type: "monotone", dataKey: "value", stroke: stroke, strokeWidth: 1.5, fill: `url(#${gradId})`, dot: false, isAnimationActive: false })] }) }) }), _jsx("div", { className: "text-[10px] text-muted-foreground/70 mt-1 truncate", children: isLive ? `Live · ${asOfLabel}` : asOfLabel })] }));
}
// ============ Market Instrument Detail Dialog ============
function InstrumentDetail({ inst, onClose }) {
    return (_jsx(Dialog, {
        open: inst !== null, onOpenChange: (v) => !v && onClose(), children: _jsx(DialogContent, {
            className: "max-w-3xl max-h-[90vh] overflow-auto", children: inst && (_jsxs(_Fragment, {
                children: [_jsxs(DialogHeader, { children: [_jsxs(DialogTitle, { className: "text-mds-navy flex items-center gap-3", children: [inst.name, _jsx(Badge, { variant: "outline", className: "text-[10px] font-normal", children: inst.source })] }), _jsxs(DialogDescription, { className: "text-xs", children: ["Latest ", _jsxs("span", { className: "font-semibold text-mds-navy tabular", children: [inst.latest.toFixed(2), "%"] }), " \u00B7 ", inst.asOf, " \u00B7", " ", _jsxs("button", { type: "button", onClick: () => window.open(inst.sourceUrl, "_blank", "noopener,noreferrer"), className: "text-mds-blue underline inline-flex items-center gap-0.5 cursor-pointer", children: ["source ", _jsx(ExternalLink, { className: "h-3 w-3" })] })] })] }), _jsxs("div", {
                    className: "space-y-4 text-sm", children: [_jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [_jsxs("div", { className: "rounded-md bg-secondary/40 p-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1", children: "What it is" }), _jsx("div", { className: "text-xs leading-relaxed text-mds-navy", children: inst.what })] }), _jsxs("div", { className: "rounded-md bg-mds-blue/5 border border-mds-blue/20 p-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-mds-blue mb-1", children: "Implication for pricing" }), _jsx("div", { className: "text-xs leading-relaxed text-mds-navy", children: inst.implication })] })] }), _jsxs("div", { className: "rounded-lg border border-border p-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-widest text-mds-navy font-semibold mb-2", children: "12-Month Trend" }), _jsx("div", { className: "h-56", children: _jsx(ResponsiveContainer, { width: "100%", height: "100%", children: _jsxs(LineChart, { data: inst.trend, margin: { top: 8, right: 12, bottom: 4, left: 0 }, children: [_jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)" }), _jsx(XAxis, { dataKey: "month", tick: { fontSize: 10 }, stroke: "var(--muted-foreground)" }), _jsx(YAxis, { tick: { fontSize: 10 }, stroke: "var(--muted-foreground)", domain: ["auto", "auto"], tickFormatter: (v) => `${v.toFixed(2)}%` }), _jsx(RTooltip, { formatter: (v) => `${v.toFixed(2)}%`, contentStyle: { fontSize: 11 } }), _jsx(ReferenceLine, { y: inst.latest, stroke: "var(--mds-navy)", strokeDasharray: "4 2", strokeWidth: 1 }), _jsx(Line, { type: "monotone", dataKey: "value", stroke: "var(--mds-blue)", strokeWidth: 2, dot: { r: 2 } })] }) }) })] }), inst.curve && !inst.ratingCurves && (_jsxs("div", { className: "rounded-lg border border-border p-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-widest text-mds-navy font-semibold mb-2", children: "Term Structure (Yield Curve)" }), _jsx("div", { className: "h-52", children: _jsx(ResponsiveContainer, { width: "100%", height: "100%", children: _jsxs(BarChart, { data: inst.curve, margin: { top: 8, right: 12, bottom: 4, left: 0 }, children: [_jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)" }), _jsx(XAxis, { dataKey: "tenor", tick: { fontSize: 10 } }), _jsx(YAxis, { tick: { fontSize: 10 }, tickFormatter: (v) => `${v.toFixed(1)}%`, domain: ["auto", "auto"] }), _jsx(RTooltip, { formatter: (v) => `${v.toFixed(2)}%`, contentStyle: { fontSize: 11 } }), _jsx(Bar, { dataKey: "value", fill: "var(--mds-blue)", radius: [4, 4, 0, 0] })] }) }) })] })), inst.ratingCurves && (_jsxs("div", { className: "rounded-lg border border-border p-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-widest text-mds-navy font-semibold mb-2", children: "Term Structure by Rating" }), _jsx("div", { className: "h-56", children: _jsx(ResponsiveContainer, { width: "100%", height: "100%", children: _jsxs(LineChart, { margin: { top: 8, right: 12, bottom: 4, left: 0 }, children: [_jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)" }), _jsx(XAxis, { dataKey: "tenor", type: "category", allowDuplicatedCategory: false, tick: { fontSize: 10 } }), _jsx(YAxis, { tick: { fontSize: 10 }, tickFormatter: (v) => `${v.toFixed(1)}%`, domain: ["auto", "auto"] }), _jsx(RTooltip, { formatter: (v) => `${v.toFixed(2)}%`, contentStyle: { fontSize: 11 } }), inst.ratingCurves.map((rc, i) => (_jsx(Line, { data: rc.points, type: "monotone", dataKey: "value", name: rc.rating, stroke: ["var(--mds-blue)", "var(--mds-navy)", "var(--mds-warning)", "var(--mds-danger)"][i % 4], strokeWidth: 2, dot: { r: 3 } }, rc.rating)))] }) }) }), _jsx("div", { className: "flex flex-wrap gap-3 mt-2 text-[10px]", children: inst.ratingCurves.map((rc, i) => (_jsxs("span", { className: "inline-flex items-center gap-1", children: [_jsx("span", { className: "w-2.5 h-2.5 rounded-sm", style: { background: ["var(--mds-blue)", "var(--mds-navy)", "var(--mds-warning)", "var(--mds-danger)"][i % 4] } }), rc.rating] }, rc.rating))) })] })), inst.curve && (_jsx("div", {
                        className: "rounded-lg border border-border overflow-hidden", children: _jsxs(Table, {
                            className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Tenor" }), _jsx(TableHead, { className: "text-right", children: "Yield (% p.a.)" }), _jsx(TableHead, { className: "text-right", children: "vs 1Y" })] }) }), _jsx(TableBody, {
                                children: inst.curve.map((c) => {
                                    const base = inst.curve.find((x) => x.months === 12)?.value ?? inst.curve[0].value;
                                    const spread = (c.value - base) * 100;
                                    return (_jsxs(TableRow, { children: [_jsx(TableCell, { className: "font-medium", children: c.tenor }), _jsxs(TableCell, { className: "text-right tabular text-mds-navy font-semibold", children: [c.value.toFixed(2), "%"] }), _jsxs(TableCell, { className: "text-right tabular text-muted-foreground", children: [spread >= 0 ? "+" : "", spread.toFixed(0), " bps"] })] }, c.tenor));
                                })
                            })]
                        })
                    }))]
                })]
            }))
        })
    }));
}
// ============ Live Bulk Deposit Card ============
/** 1Y-and-above tenor filter shared by the counterparty deposit views. */
function only1yPlus(rows) {
    return rows?.filter((r) => {
        const t = r.tenor.toLowerCase();
        if (/<\s*1\s*year|less\s+than\s+1\s*year/.test(t))
            return false;
        if (/\bday|\bdays\b/.test(t) && !/year|yr/.test(t))
            return false;
        const monthMatches = [...t.matchAll(/(\d+(?:\.\d+)?)\s*months?/g)].map((m) => Number(m[1]));
        if (monthMatches.length > 0 && !/year|yr/.test(t))
            return monthMatches.some((m) => m >= 12);
        return /\byear|\byr\b|\byrs\b/.test(t);
    }) ?? null;
}
function depositAmountLabel(bank, hasBuckets) {
    if (hasBuckets)
        return "≥ ₹3 Cr (bucketed)";
    if (bank.id === "sbi")
        return "≥ ₹3 Cr (Domestic Bulk Term Deposits)";
    if (bank.id === "tmb")
        return "≥ ₹2 Cr";
    return "≥ ₹2 Cr (Bulk)";
}
/** Tile matching the market-instrument tile styling, used for counterparty cards. */
function CounterpartyTile({ label, value, unit = "%", meta, sub, accent, onOpen, loading, }) {
    return (_jsxs("button", { type: "button", onClick: onOpen, style: { ["--tile-accent"]: accent }, className: "relative text-left rounded-lg border border-border bg-white hover:border-[var(--tile-accent)] hover:shadow-md hover:-translate-y-0.5 transition-all p-3 group overflow-hidden", children: [_jsx("span", { className: "absolute inset-x-0 top-0 h-0.5", style: { background: accent } }), _jsxs("div", { className: "flex items-start justify-between gap-2", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground truncate font-semibold", children: label }), _jsx(Info, { className: "h-3 w-3 shrink-0 text-muted-foreground/60 group-hover:text-[var(--tile-accent)] mt-0.5" })] }), _jsxs("div", { className: "mt-1.5 flex items-baseline gap-0.5", children: [_jsx("span", { className: "text-xl font-bold tabular text-mds-navy leading-none", children: loading && value === null ? "…" : value !== null ? value.toFixed(2) : "—" }), value !== null && _jsx("span", { className: "text-[11px] text-muted-foreground", children: unit })] }), _jsx("div", { className: "mt-2 text-[10px] text-mds-navy leading-snug line-clamp-2 min-h-[26px]", children: meta }), _jsx("div", { className: "text-[10px] text-muted-foreground/70 mt-1 truncate", children: sub })] }));
}
/** Counterparty section inside Market Rates — bulk deposit, money-market CD and bond tiles. */
function CounterpartyActivitySection({ bank, live, activity, loading, fetchedAt, }) {
    const [open, setOpen] = useState(null);
    const rows = only1yPlus(live.rows);
    const bucketLabel = depositAmountLabel(bank, live.hasAmountBuckets);
    const peak = useMemo(() => {
        let best = null;
        for (const r of rows ?? []) {
            const cands = live.hasAmountBuckets
                ? [
                    { v: r.callable, bucket: "≥ ₹3 Cr < ₹5 Cr" },
                    { v: r.nonCallableMax ?? r.nonCallable, bucket: "≥ ₹5 Cr" },
                ]
                : [
                    { v: r.callable, bucket: bucketLabel },
                    { v: r.nonCallable, bucket: bucketLabel },
                ];
            for (const c of cands) {
                if (c.v === null || c.v === undefined)
                    continue;
                if (!best || c.v > best.rate)
                    best = { rate: c.v, tenor: r.tenor, bucket: c.bucket };
            }
        }
        return best;
    }, [rows, live.hasAmountBuckets, bucketLabel]);
    const { latestMm, latestBond, mmCount, bondCount } = useMemo(() => {
        const all = baseActivityRows(bank, activity).sort((a, b) => actTime(b.date) - actTime(a.date));
        const mm = all.filter((r) => r.group === "mm");
        const bd = all.filter((r) => r.group === "bond");
        // Prefer the most recent bond print that carries a quotable coupon.
        const bondPick = bd.find((r) => actRateNum(r.rate) !== null) ?? bd[0] ?? null;
        return { latestMm: mm[0] ?? null, latestBond: bondPick, mmCount: mm.length, bondCount: bd.length };
    }, [bank, activity]);
    return (_jsxs("div", { children: [_jsxs("div", { className: "flex items-center gap-2 mb-2", children: [_jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-mds-navy" }), _jsxs("span", { className: "text-[10px] uppercase tracking-widest text-muted-foreground font-semibold", children: ["Counterparty \u00B7 ", bank.name] })] }), _jsxs("div", { className: "grid grid-cols-3 gap-2", children: [_jsx(CounterpartyTile, { label: "Money market", value: actRateNum(latestMm?.rate ?? null), meta: latestMm ? `${latestMm.instrument}${latestMm.tenor ? ` · ${fmtActTenor(latestMm.tenor)}` : ""}` : "No recent prints", sub: latestMm ? `${fmtActDate(latestMm.date)} · ${latestMm.source}` : "Treasury / Bloomberg", accent: "var(--mds-purple)", loading: loading, onOpen: () => setOpen("mm") }), _jsx(CounterpartyTile, { label: "Bonds \u00B7 latest", value: actRateNum(latestBond?.rate ?? null), meta: latestBond ? `${latestBond.instrument}${latestBond.tenor ? ` · ${fmtActTenor(latestBond.tenor)}` : ""}` : "No recent issuance", sub: latestBond ? `${fmtActDate(latestBond.date)} · ${latestBond.source}` : "News / filings", accent: "var(--mds-purple)", loading: loading, onOpen: () => setOpen("bond") }), _jsx(CounterpartyTile, { label: "Bulk deposit \u00B7 max", value: peak?.rate ?? null, meta: peak ? `${peak.tenor} · ${peak.bucket}` : `Applicable amount ${bucketLabel}`, sub: live.asOf ? `Rate card · ${live.asOf}` : "Published rate card", accent: "var(--mds-purple)", loading: loading, onOpen: () => setOpen("deposit") })] }), _jsx(Dialog, { open: open === "deposit", onOpenChange: (v) => !v && setOpen(null), children: _jsxs(DialogContent, { className: "max-w-2xl max-h-[85vh] overflow-auto", children: [_jsxs(DialogHeader, { children: [_jsxs(DialogTitle, { className: "text-mds-navy text-base flex items-center gap-2", children: ["Bulk Deposit Rates \u2014 1Y & Above", live.illustrative && _jsx("span", { className: "inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5", children: "Illustrative" })] }), _jsxs(DialogDescription, { className: "text-xs", children: [bank.name, " \u00B7 applicable amount ", bucketLabel, live.asOf ? ` · as of ${live.asOf}` : ""] })] }), rows && rows.length > 0 ? (_jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Tenor" }), live.hasAmountBuckets ? (_jsxs(_Fragment, { children: [_jsx(TableHead, { className: "text-right", children: "\u2265 \u20B93 Cr < \u20B95 Cr (%)" }), _jsx(TableHead, { className: "text-right", children: "\u2265 \u20B95 Cr (%)" })] })) : (_jsx(TableHead, { className: "text-right", children: "Rate (%)" }))] }) }), _jsx(TableBody, { children: rows.map((d, i) => (_jsxs(TableRow, { className: peak && d.tenor === peak.tenor ? "bg-mds-navy/5" : undefined, children: [_jsx(TableCell, { children: d.tenor }), live.hasAmountBuckets ? (_jsxs(_Fragment, { children: [_jsx(TableCell, { className: "text-right tabular", children: d.callable != null ? d.callable.toFixed(2) : "—" }), _jsx(TableCell, { className: "text-right tabular", children: d.nonCallableMax != null ? d.nonCallableMax.toFixed(2) : d.nonCallable != null ? d.nonCallable.toFixed(2) : "—" })] })) : (_jsx(TableCell, { className: "text-right tabular", children: d.callable != null ? d.callable.toFixed(2) : d.nonCallable != null ? d.nonCallable.toFixed(2) : "—" }))] }, i))) })] })) : (_jsx("div", { className: "rounded border border-dashed p-4 text-xs text-muted-foreground", children: live.note ?? "No 1Y+ rates available for this bank." })), _jsx("div", { className: "pt-1", children: _jsxs("button", { type: "button", onClick: () => window.open(live.sourceUrl ?? bank.bulkRateSourceUrl, "_blank", "noopener,noreferrer"), className: "text-[11px] text-mds-blue inline-flex items-center gap-1 hover:underline cursor-pointer", children: ["Official source ", _jsx(ExternalLink, { className: "h-3 w-3" })] }) })] }) }), _jsx(Dialog, { open: open === "mm" || open === "bond", onOpenChange: (v) => !v && setOpen(null), children: _jsxs(DialogContent, { className: "max-w-5xl max-h-[85vh] overflow-auto p-0", children: [_jsxs(DialogHeader, { className: "sr-only", children: [_jsx(DialogTitle, { children: open === "bond" ? "Bond activity" : "Money market activity" }), _jsx(DialogDescription, { children: "Recent counterparty market activity" })] }), open && open !== "deposit" && (_jsx(MarketActivityCard, { bank: bank, live: activity, loading: loading, fetchedAt: fetchedAt, groupFilter: open, title: open === "bond" ? "Bond activity" : "Money market activity", bare: true })), _jsx("div", { className: "px-6 pb-4 text-[10px] text-muted-foreground", children: open === "bond" ? `${bondCount} bond entries` : `${mmCount} money-market entries` })] }) })] }));
}
function LiveBulkDepositCard({ bank, live, loading, fetchedAt, }) {
    const allRows = live.rows;
    // Show only 1-year-and-above tenors
    const rows = allRows?.filter((r) => {
        const t = r.tenor.toLowerCase();
        if (/<\s*1\s*year|less\s+than\s+1\s*year/.test(t))
            return false;
        if (/\bday|\bdays\b/.test(t) && !/year|yr/.test(t))
            return false;
        const monthMatches = [...t.matchAll(/(\d+(?:\.\d+)?)\s*months?/g)].map((m) => Number(m[1]));
        if (monthMatches.length > 0 && !/year|yr/.test(t))
            return monthMatches.some((m) => m >= 12);
        return /\byear|\byr\b|\byrs\b/.test(t);
    }) ?? null;
    const sourceUrl = live.sourceUrl ?? bank.bulkRateSourceUrl;
    // Applicable amount range per bank's published bulk-deposit rate card.
    const amountRangeLabel = live.hasAmountBuckets
        ? "≥ ₹3 Cr (bucketed)"
        : bank.id === "sbi"
            ? "≥ ₹3 Cr (Domestic Bulk Term Deposits)"
            : bank.id === "tmb"
                ? "≥ ₹2 Cr"
                : "≥ ₹2 Cr (Bulk)";
    return (_jsxs(Card, {
        className: "lg:col-span-2", children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center justify-between", children: [_jsxs("span", { className: "flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-navy rounded" }), " Bulk Deposit Rates \u2014 1Y & Above", live.illustrative && _jsx("span", { className: "inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5", children: "Illustrative" })] }), _jsxs("button", { type: "button", onClick: () => window.open(sourceUrl, "_blank", "noopener,noreferrer"), className: "text-[11px] text-mds-blue font-normal normal-case tracking-normal inline-flex items-center gap-1 hover:underline cursor-pointer", children: ["Official source ", _jsx(ExternalLink, { className: "h-3 w-3" })] })] }), _jsxs("div", { className: "text-[11px] text-muted-foreground mt-1", children: ["Applicable amount: ", _jsx("span", { className: "font-medium text-mds-navy", children: amountRangeLabel })] })] }), _jsx(CardContent, {
            className: "space-y-3", children: loading && !rows ? (_jsx("div", { className: "text-xs text-muted-foreground py-6", children: "Fetching live rate card\u2026" })) : rows && rows.length > 0 ? (_jsx(_Fragment, {
                children: _jsxs(Table, {
                    className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Tenor" }), live.hasAmountBuckets ? (_jsxs(_Fragment, { children: [_jsx(TableHead, { className: "text-right", children: "\u2265 \u20B93 Cr < \u20B95 Cr (%)" }), _jsx(TableHead, { className: "text-right", children: "\u2265 \u20B95 Cr (%)" })] })) : (_jsx(TableHead, { className: "text-right", children: "Rate (%)" }))] }) }), _jsx(TableBody, {
                        children: rows.map((d, i) => (_jsxs(TableRow, {
                            children: [_jsx(TableCell, { children: d.tenor }), live.hasAmountBuckets ? (_jsxs(_Fragment, {
                                children: [_jsx(TableCell, { className: "text-right tabular", children: d.callable != null ? d.callable.toFixed(2) : "—" }), _jsx(TableCell, {
                                    className: "text-right tabular", children: d.nonCallableMax != null
                                        ? d.nonCallableMax.toFixed(2)
                                        : d.nonCallable != null ? d.nonCallable.toFixed(2) : "—"
                                })]
                            })) : (_jsx(TableCell, { className: "text-right tabular", children: d.callable != null ? d.callable.toFixed(2) : (d.nonCallable != null ? d.nonCallable.toFixed(2) : "—") }))]
                        }, i)))
                    })]
                })
            })) : (_jsxs("div", { className: "rounded border border-dashed p-4 text-xs text-muted-foreground", children: [_jsx("div", { className: "font-medium text-mds-navy mb-1", children: "No 1Y+ rates available" }), _jsxs("div", { children: [live.note ?? "This bank's bulk deposit page uses a format that isn't parsed yet.", " ", "Open the official source to view current rates."] })] }))
        })]
    }));
}
const BOND_RX = /bond|debenture|ncd|tier[- ]?2|tier[- ]?ii|at1|infra|perpetual|msf|notes/i;
/** Consistent display formatters so live and tape rows read identically. */
const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function fmtActDate(v) {
    if (!v)
        return "—";
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v.trim());
    if (m)
        return `${m[3]} ${MONTHS_SHORT[+m[2] - 1]} ${m[1].slice(2)}`;
    const d = new Date(v);
    if (!isNaN(d.getTime()))
        return `${String(d.getDate()).padStart(2, "0")} ${MONTHS_SHORT[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`;
    return v;
}
/** Sortable timestamp from any date string ("2026-08-03", "24-Jun-2026", "FY25"). */
function actTime(v) {
    if (!v)
        return 0;
    const s = v.trim();
    const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
    if (iso)
        return Date.UTC(+iso[1], +iso[2] - 1, +iso[3]);
    const dmy = /^(\d{1,2})[-/\s]([A-Za-z]{3,})[-/\s](\d{2,4})/.exec(s);
    if (dmy) {
        const mi = MONTHS_SHORT.findIndex((m) => m.toLowerCase() === dmy[2].slice(0, 3).toLowerCase());
        const yr = +dmy[3] < 100 ? 2000 + +dmy[3] : +dmy[3];
        if (mi >= 0)
            return Date.UTC(yr, mi, +dmy[1]);
    }
    const my = /^([A-Za-z]{3,})[-/\s](\d{2,4})/.exec(s);
    if (my) {
        const mi = MONTHS_SHORT.findIndex((m) => m.toLowerCase() === my[1].slice(0, 3).toLowerCase());
        const yr = +my[2] < 100 ? 2000 + +my[2] : +my[2];
        if (mi >= 0)
            return Date.UTC(yr, mi, 1);
    }
    const fy = /^FY\s?(\d{2,4})/i.exec(s);
    if (fy) {
        const yr = +fy[1] < 100 ? 2000 + +fy[1] : +fy[1];
        return Date.UTC(yr, 2, 31);
    }
    const d = new Date(s);
    return isNaN(d.getTime()) ? 0 : d.getTime();
}
/** Any amount string / number → "₹X,XXX Cr". */
function fmtActAmount(v) {
    if (v == null)
        return "—";
    if (typeof v === "number")
        return `₹${Math.round(v).toLocaleString("en-IN")} Cr`;
    const txt = v.replace(/,/g, "");
    const num = parseFloat((/-?\d+(\.\d+)?/.exec(txt) ?? [""])[0]);
    if (isNaN(num))
        return v;
    const cr = /cr/i.test(txt) ? num : /lakh|lac/i.test(txt) ? num / 100 : /\bbn|billion/i.test(txt) ? num * 100 : num;
    return `₹${Math.round(cr).toLocaleString("en-IN")} Cr`;
}
/** Any rate string / number → "X.XX%". */
function fmtActRate(v) {
    if (v == null)
        return "—";
    if (typeof v === "number")
        return `${v.toFixed(2)}%`;
    const num = parseFloat((/-?\d+(\.\d+)?/.exec(v.replace(/,/g, "")) ?? [""])[0]);
    return isNaN(num) ? v : `${num.toFixed(2)}%`;
}
/** Tenor strings → compact, uppercase units (e.g. "10Y (call 5Y)", "3M"). */
function fmtActTenor(v) {
    if (!v)
        return "—";
    const t = v.trim().replace(/\s*years?/gi, "Y").replace(/\s*months?/gi, "M").replace(/\s*days?/gi, "D");
    return t.replace(/(\d)\s*([ymd])/gi, (_, d, u) => `${d}${u.toUpperCase()}`);
}
const titleCase = (s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
const QUOTES_KEY = "sidbi.marketQuotes.v1";
const QUOTE_SOURCES = ["Treasury", "Bloomberg", "News", "Desk quote"];
/** Money-market instruments the desk quotes on — CDs across tenors, incl. bulk. */
const QUOTE_INSTRUMENTS = [
    { label: "Certificate of Deposit (CD)", tenor: "1M" },
    { label: "Certificate of Deposit (CD)", tenor: "3M" },
    { label: "Certificate of Deposit (CD)", tenor: "6M" },
    { label: "Certificate of Deposit (CD)", tenor: "9M" },
    { label: "Certificate of Deposit (CD)", tenor: "1Y" },
    { label: "Certificate of Deposit (CD)", tenor: "2Y" },
    { label: "CD · bulk (₹3 Cr+)", tenor: "1Y" },
    { label: "CD · bulk (₹5 Cr+)", tenor: "1Y" },
    { label: "Commercial Paper (CP)", tenor: "3M" },
    { label: "Term money", tenor: "3M" },
];
const quoteKey = (i) => `${i.label} · ${i.tenor}`;
function emptyQuote() {
    return {
        id: `q${Date.now()}`,
        date: new Date().toISOString().slice(0, 10),
        instrument: "", tenor: "", ratePct: "", amountCr: "",
        source: "Treasury", notes: "",
    };
}
const QUOTES_EVENT = "sidbi-quotes-changed";
/** Shared manual-quote store (localStorage) so the range bar reflects new quotes. */
function useManualQuotes() {
    const [quotes, setQuotes] = useState([]);
    useEffect(() => {
        const load = () => {
            try {
                const raw = window.localStorage.getItem(QUOTES_KEY);
                setQuotes(raw ? JSON.parse(raw) : []);
            }
            catch { /* ignore */ }
        };
        load();
        window.addEventListener(QUOTES_EVENT, load);
        return () => window.removeEventListener(QUOTES_EVENT, load);
    }, []);
    const persist = (next) => {
        setQuotes(next);
        try {
            window.localStorage.setItem(QUOTES_KEY, JSON.stringify(next));
        }
        catch { /* ignore */ }
        window.dispatchEvent(new Event(QUOTES_EVENT));
    };
    return [quotes, persist];
}
/** Short instrument form for range-bar labels: "1Y CD (bulk ₹5 Cr+)", "3M CP". */
function shortInstrument(instrument, tenor) {
    const i = instrument.toLowerCase();
    let base = instrument;
    if (i.includes("bulk")) {
        const cr = instrument.match(/₹\s*\d+\s*Cr\+?/i)?.[0];
        base = cr ? `CD bulk ${cr}` : "CD bulk";
    }
    else if (i.includes("certificate of deposit") || i.startsWith("cd"))
        base = "CD";
    else if (i.includes("commercial paper") || i.startsWith("cp"))
        base = "CP";
    else if (i.includes("term money"))
        base = "Term money";
    return [tenor, base].filter(Boolean).join(" ");
}
/** Most recent counterparty quote carrying a numeric rate. */
function latestQuoteRate(quotes) {
    const sorted = [...quotes].sort((a, b) => (a.date < b.date ? 1 : -1));
    for (const q of sorted) {
        const n = actRateNum(q.ratePct);
        if (n !== null) {
            const short = shortInstrument(q.instrument, q.tenor);
            return { rate: n, label: short ? `CP Quote · ${short}` : "CP Quote" };
        }
    }
    return null;
}
/** Bond filings + Bloomberg tape + Treasury prints, unsorted. Shared by tiles and the table. */
function baseActivityRows(bank, live) {
    const bonds = live.rows.map((r) => ({
        date: r.date,
        group: "bond",
        instrument: r.securityType ?? "Bond",
        tenor: r.tenure,
        rate: r.coupon,
        amount: r.amount,
        status: r.status,
        side: "Issued",
        counterparty: null,
        rating: r.rating ?? null,
        market: r.market,
        desc: r.desc,
        url: r.attachmentUrl ?? live.sourceUrl,
        source: "News",
        illustrative: !!live.illustrative,
    }));
    const tape = counterpartyMarketDeals(bank).map((d) => ({
        date: d.date,
        group: BOND_RX.test(d.instrument) ? "bond" : "mm",
        instrument: d.instrument,
        tenor: d.tenor,
        rate: `${d.ratePct.toFixed(2)}%`,
        amount: `₹${d.amountCr} Cr`,
        status: "Settled",
        side: d.side,
        counterparty: d.counterpartyType,
        rating: bank.rating,
        market: "Domestic",
        desc: null,
        url: null,
        source: "Bloomberg",
        illustrative: true,
    }));
    const treasury = treasuryDeals().map((d) => ({
        date: d.date,
        group: BOND_RX.test(d.instrument) ? "bond" : "mm",
        instrument: d.instrument,
        tenor: d.tenor,
        rate: `${d.ratePct.toFixed(2)}%`,
        amount: `₹${d.amountCr} Cr`,
        status: "Settled",
        side: null,
        counterparty: d.counterparty,
        rating: null,
        market: "Domestic",
        desc: d.note ?? null,
        url: null,
        source: d.source,
        illustrative: true,
    }));
    return [...bonds, ...tape, ...treasury];
}
/** Numeric rate from a display string like "7.35%". */
function actRateNum(v) {
    if (!v)
        return null;
    const m = /(\d+(?:\.\d+)?)/.exec(v);
    return m ? Number(m[1]) : null;
}
function MarketActivityCard({ bank, live, loading, fetchedAt, groupFilter, title, bare, }) {
    const [openIdx, setOpenIdx] = useState(null);
    const [quotes, persistQuotes] = useManualQuotes();
    const [addOpen, setAddOpen] = useState(false);
    const [draft, setDraft] = useState(emptyQuote);
    const rows = useMemo(() => {
        const manual = quotes.map((q) => ({
            date: q.date,
            group: BOND_RX.test(q.instrument) ? "bond" : "mm",
            instrument: q.instrument || "Quote",
            tenor: q.tenor || null,
            rate: q.ratePct || null,
            amount: q.amountCr || null,
            status: "Quoted",
            side: null,
            counterparty: bank.name,
            rating: null,
            market: null,
            desc: q.notes || null,
            url: null,
            source: q.source,
            illustrative: false,
        }));
        const all = [...baseActivityRows(bank, live), ...manual]
            .sort((a, b) => actTime(b.date) - actTime(a.date));
        return groupFilter ? all.filter((r) => r.group === groupFilter) : all;
    }, [live, bank, quotes, groupFilter]);
    const [showAll, setShowAll] = useState(false);
    const shown = showAll ? rows : rows.slice(0, 5);
    const saveQuote = () => {
        if (!draft.instrument.trim())
            return;
        persistQuotes([{ ...draft, id: `q${Date.now()}` }, ...quotes]);
        setDraft(emptyQuote());
        setAddOpen(false);
    };
    return (_jsxs(Card, {
        className: bare ? "border-0 shadow-none" : undefined, children: [_jsx(CardHeader, { className: "pb-3", children: _jsxs("div", { className: "grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2 flex-wrap", children: [_jsx("span", { className: "w-1 h-4 bg-mds-blue rounded" }), " ", title ?? "Recent Market Activity", _jsx("span", { className: "inline-flex items-center px-1.5 py-0.5 rounded bg-mds-navy/10 text-mds-navy text-[10px] font-semibold tracking-normal", children: bank.rating }), _jsx("span", { className: "inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5", children: "Illustrative" })] }), _jsxs("div", { className: "mt-1 text-[10px] text-muted-foreground", children: ["Funds raised, money-market prints and CD quotes \u00B7 Treasury, Bloomberg & news", fetchedAt ? ` · ${fetchedAt}` : ""] })] }), groupFilter !== "bond" && (_jsx(Button, { size: "sm", className: "h-8 shrink-0 bg-mds-blue text-white hover:bg-mds-blue/90 text-[11px]", onClick: () => { setDraft(emptyQuote()); setAddOpen(true); }, children: "Add quote" }))] }) }), _jsx(CardContent, {
            className: "p-0", children: loading && rows.length === 0 ? (_jsx("div", { className: "p-6 text-xs text-muted-foreground", children: "Fetching market activity\u2026" })) : shown.length === 0 ? (_jsx("div", { className: "p-6 text-xs text-muted-foreground", children: live.note ?? "No recent market activity surfaced for this counterparty." })) : (_jsxs(_Fragment, {
                children: [_jsxs(Table, {
                    className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { className: "w-[32px]" }), _jsx(TableHead, { className: "w-[85px]", children: "Date" }), !groupFilter && _jsx(TableHead, { className: "w-[95px]", children: "Type" }), _jsx(TableHead, { children: "Instrument" }), _jsx(TableHead, { className: "w-[140px]", children: "Counterparty" }), _jsx(TableHead, { className: "text-right w-[100px]", children: "Amount" }), _jsx(TableHead, { className: "text-center w-[100px]", children: "Tenor" }), _jsx(TableHead, { className: "text-right w-[75px]", children: "Rate" }), _jsx(TableHead, { className: "w-[95px]", children: "Status" }), _jsx(TableHead, { className: "w-[95px]", children: "Source" })] }) }), _jsx(TableBody, {
                        children: shown.map((r, i) => {
                            const key = `${r.group}-${r.date}-${i}`;
                            const open = openIdx === key;
                            return (_jsxs(Fragment, {
                                children: [_jsxs(TableRow, {
                                    className: "cursor-pointer hover:bg-mds-blue/5", onClick: () => setOpenIdx(open ? null : key), children: [_jsx(TableCell, { className: "w-[32px] p-2", children: _jsx(ChevronDown, { className: `h-3 w-3 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}` }) }), _jsx(TableCell, { className: "tabular whitespace-nowrap", children: fmtActDate(r.date) }), !groupFilter && (_jsx(TableCell, { children: _jsx("span", { className: `inline-block px-1.5 py-0.5 rounded text-[10px] font-medium whitespace-nowrap ${r.group === "bond" ? "bg-mds-blue/10 text-mds-blue" : "bg-mds-navy/10 text-mds-navy"}`, children: r.group === "bond" ? "Bond" : "Money mkt" }) })), _jsx(TableCell, { className: "font-medium text-mds-navy", children: r.instrument }), _jsx(TableCell, { className: "whitespace-nowrap text-mds-navy", children: r.counterparty ?? "—" }), _jsx(TableCell, { className: "text-right tabular whitespace-nowrap", children: fmtActAmount(r.amount) }), _jsx(TableCell, { className: "text-center tabular whitespace-nowrap", children: fmtActTenor(r.tenor) }), _jsx(TableCell, { className: "text-right tabular font-semibold whitespace-nowrap", children: fmtActRate(r.rate) }), _jsx(TableCell, {
                                        className: "whitespace-nowrap", children: r.status ? (_jsxs("span", {
                                            className: `inline-flex items-center gap-1 ${/approval|expected|proposed|quoted/i.test(r.status) ? "text-mds-warning"
                                                : /active|issued|settled|closed/i.test(r.status) ? "text-mds-success"
                                                    : "text-muted-foreground"}`, children: [_jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-current" }), titleCase(r.status)]
                                        })) : "—"
                                    }), _jsx(TableCell, { className: "whitespace-nowrap text-muted-foreground", children: r.source })]
                                }), open && (_jsx(TableRow, {
                                    className: "bg-mds-blue/5 hover:bg-mds-blue/5", children: _jsxs(TableCell, {
                                        colSpan: groupFilter ? 9 : 10, className: "p-4", children: [_jsx("div", {
                                            className: "grid grid-cols-2 md:grid-cols-4 gap-4 text-xs", children: [
                                                ["Date", fmtActDate(r.date)],
                                                ["Segment", r.group === "bond" ? "Bonds / primary issuance" : "Money market"],
                                                ["Instrument", r.instrument],
                                                ["Side", r.side ? titleCase(r.side) : "—"],
                                                ["Amount", fmtActAmount(r.amount)],
                                                ["Tenor / maturity", fmtActTenor(r.tenor)],
                                                ["Rate / coupon", fmtActRate(r.rate)],
                                                ["Rating", r.rating ?? "—"],
                                                ["Market", r.market ?? "—"],
                                                ["Counterparty", r.counterparty ?? "—"],
                                                ["Status", r.status ? titleCase(r.status) : "—"],
                                                ["Source", r.source],
                                            ].map(([label, val]) => (_jsxs("div", { children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1", children: label }), _jsx("div", { className: "text-mds-navy tabular", children: val })] }, label)))
                                        }), r.desc && (_jsxs("div", { className: "mt-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1", children: "Notes" }), _jsx("div", { className: "text-xs text-mds-navy whitespace-pre-wrap break-words leading-relaxed", children: r.desc })] })), r.url && (_jsx("div", { className: "mt-3", children: _jsxs("a", { href: r.url, target: "_blank", rel: "noopener noreferrer", className: "text-[11px] text-mds-blue inline-flex items-center gap-1 hover:underline", children: ["Open source ", _jsx(ExternalLink, { className: "h-3 w-3" })] }) }))]
                                    })
                                }))]
                            }, key));
                        })
                    })]
                }), rows.length > 5 && (_jsx("div", {
                    className: "border-t border-border p-2 flex justify-center", children: _jsx(Button, {
                        variant: "ghost", size: "sm", className: "h-7 text-[11px] text-mds-blue hover:bg-mds-blue/5", onClick: () => setShowAll((v) => !v), children: showAll
                            ? _jsxs(_Fragment, { children: ["Show less ", _jsx(ChevronDown, { className: "h-3 w-3 ml-1 rotate-180" })] })
                            : _jsxs(_Fragment, { children: ["Show all ", rows.length, " entries ", _jsx(ChevronDown, { className: "h-3 w-3 ml-1" })] })
                    })
                }))]
            }))
        }), _jsx(Dialog, {
            open: addOpen, onOpenChange: setAddOpen, children: _jsxs(DialogContent, {
                className: "max-w-lg", children: [_jsxs(DialogHeader, { children: [_jsxs(DialogTitle, { className: "text-sm uppercase tracking-wider text-mds-navy", children: ["Add market quote \u00B7 ", bank.name] }), _jsx(DialogDescription, { className: "text-xs", children: "Record a quote or print picked up from Treasury, Bloomberg or news. Counterparty is the bank selected above." })] }), _jsxs("div", {
                    className: "grid grid-cols-2 gap-3", children: [_jsx(MicroField, {
                        label: "Date", children: _jsx(Input, {
                            type: "date", value: draft.date, max: new Date().toISOString().slice(0, 10), onChange: (e) => {
                                const t = new Date().toISOString().slice(0, 10);
                                setDraft({ ...draft, date: e.target.value > t ? t : e.target.value });
                            }, className: "h-8 text-xs bg-white tabular"
                        })
                    }), _jsx(MicroField, { label: "Source", children: _jsxs(Select, { value: draft.source, onValueChange: (v) => setDraft({ ...draft, source: v }), children: [_jsx(SelectTrigger, { className: "h-8 text-xs bg-white", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: QUOTE_SOURCES.map((sr) => _jsx(SelectItem, { value: sr, className: "text-xs", children: sr }, sr)) })] }) }), _jsx("div", {
                        className: "col-span-2", children: _jsx(MicroField, {
                            label: "Instrument", children: _jsxs(Select, {
                                value: draft.instrument ? quoteKey({ label: draft.instrument, tenor: draft.tenor }) : undefined, onValueChange: (v) => {
                                    const opt = QUOTE_INSTRUMENTS.find((i) => quoteKey(i) === v);
                                    if (opt)
                                        setDraft({ ...draft, instrument: opt.label, tenor: opt.tenor });
                                }, children: [_jsx(SelectTrigger, { className: "h-8 text-xs bg-white", children: _jsx(SelectValue, { placeholder: "Select instrument" }) }), _jsx(SelectContent, { children: QUOTE_INSTRUMENTS.map((i) => (_jsxs(SelectItem, { value: quoteKey(i), className: "text-xs", children: [i.label, " \u00B7 ", i.tenor] }, quoteKey(i)))) })]
                            })
                        })
                    }), _jsx(MicroField, { label: "Rate %", children: _jsx(Input, { value: draft.ratePct, inputMode: "decimal", onChange: (e) => setDraft({ ...draft, ratePct: e.target.value }), className: "h-8 text-xs bg-white tabular" }) }), _jsx(MicroField, { label: "Tenor", children: _jsx(Input, { value: draft.tenor, onChange: (e) => setDraft({ ...draft, tenor: e.target.value }), className: "h-8 text-xs bg-white" }) }), _jsx(MicroField, { label: "Amount (\u20B9 Cr)", children: _jsx(Input, { value: draft.amountCr, inputMode: "decimal", onChange: (e) => setDraft({ ...draft, amountCr: e.target.value }), className: "h-8 text-xs bg-white tabular" }) }), _jsx("div", { className: "col-span-2", children: _jsx(MicroField, { label: "Notes", children: _jsx(Input, { value: draft.notes, onChange: (e) => setDraft({ ...draft, notes: e.target.value }), className: "h-8 text-xs bg-white" }) }) })]
                }), quotes.length > 0 && (_jsxs("div", { className: "space-y-1 border-t border-border pt-3", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Saved quotes" }), quotes.map((q) => (_jsxs("div", { className: "flex items-center justify-between text-[11px] text-mds-navy", children: [_jsxs("span", { className: "truncate", children: [fmtActDate(q.date), " \u00B7 ", q.instrument, " \u00B7 ", fmtActRate(q.ratePct)] }), _jsx("button", { type: "button", onClick: () => persistQuotes(quotes.filter((x) => x.id !== q.id)), className: "text-muted-foreground hover:text-mds-danger shrink-0", "aria-label": "Delete quote", children: _jsx(X, { className: "h-3.5 w-3.5" }) })] }, q.id)))] })), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", size: "sm", className: "h-8 text-xs", onClick: () => setAddOpen(false), children: "Cancel" }), _jsx(Button, { size: "sm", className: "h-8 text-xs bg-mds-blue text-white hover:bg-mds-blue/90", disabled: !draft.instrument.trim(), onClick: saveQuote, children: "Save quote" })] })]
            })
        })]
    }));
}
const NEGOTIATION_STATUSES = ["closed", "quoted", "proposed", "on hold", "declined"];
function statusClass(s) {
    if (s === "closed")
        return "border-mds-success/40 text-mds-success";
    if (s === "quoted" || s === "proposed")
        return "border-mds-blue/40 text-mds-blue";
    if (s === "on hold")
        return "border-amber-400 text-amber-700";
    return "border-destructive/40 text-destructive";
}
const NEGOTIATION_STORE_PREFIX = "sidbi.pastNegotiations.";
/** Repayment options mirror the dashboard exactly. */
const NEGO_FREQS = FREQUENCIES.map((f) => f.label);
/** First CoF option that actually carries a live/static rate. */
function pickCof(cofOptions) {
    return cofOptions.find((c) => c.ratePct !== null) ?? cofOptions[0];
}
function newRow(scheme, minMarginBps, cofOptions, tranche, today) {
    const c = pickCof(cofOptions);
    const t = tranche;
    const tenure = t && today ? roundedMonthsBetween(today, parseISODate(t.date)) : 0;
    return {
        scheme,
        cofKey: c?.key ?? COF_OPTION_DEFS[2]?.key ?? "1y3y_fixed",
        cofPct: c?.ratePct != null ? c.ratePct.toFixed(2) : "",
        marginBps: String(scheme === "RMSE" ? (t?.marginBps ?? RMSE_MARGIN_BPS) : minMarginBps),
        discretionBps: "0",
        trancheId: scheme === "RMSE" ? (t?.id ?? "") : "",
        trancheName: scheme === "RMSE" ? (t?.label ?? "") : "",
        fundRatePct: scheme === "RMSE" && t ? t.fundRatePct.toFixed(2) : "",
        amountCr: "",
        freq: scheme === "RMSE" ? "Bullet" : "Quarterly",
        moratoriumMonths: "",
        tenureMonths: scheme === "RMSE" && tenure > 0 ? String(tenure) : "",
    };
}
/** Derived rate for a row, exactly as the dashboard builds it. */
function rowRate(r) {
    const n = (s) => (s.trim() === "" ? 0 : Number(s) || 0);
    if (r.scheme === "RMSE")
        return n(r.fundRatePct) + n(r.marginBps) / 100;
    const cof = n(r.cofPct);
    return Math.max(cof, cof + n(r.marginBps) / 100 - n(r.discretionBps) / 100);
}
function emptyDraft(minMarginBps, cofOptions, tranches, today) {
    return {
        date: toISODate(new Date()), status: "quoted",
        principalCr: "",
        rows: [
            newRow("MSER", minMarginBps, cofOptions),
            newRow("RMSE", RMSE_MARGIN_BPS, cofOptions, tranches[0], today),
        ],
        counterpartyAskPct: "", proposedRatePct: "", warPct: "", note: "",
    };
}
function PastDealsCard({ deals, bankName, bankId, bankCategory, cofOptions }) {
    const minMargin = marginBps(bankCategory);
    const maxDisc = discretionMaxBps(bankCategory);
    const [openIdx, setOpenIdx] = useState(null);
    const [added, setAdded] = useState([]);
    const [addOpen, setAddOpen] = useState(false);
    const [pendingDeal, setPendingDeal] = useState(null);
    const today = useMemo(() => {
        const n = new Date();
        return new Date(n.getFullYear(), n.getMonth(), n.getDate());
    }, []);
    // Same RMSE tranche master the dashboard inputs use.
    const [tranches, setTranches] = useState(defaultTranches);
    useEffect(() => {
        try {
            const raw = window.localStorage.getItem(TRANCHE_STORE_KEY);
            const parsed = raw ? JSON.parse(raw) : null;
            if (parsed && parsed.length)
                setTranches(parsed);
        }
        catch { /* keep defaults */ }
    }, [addOpen]);
    const [draft, setDraft] = useState(() => emptyDraft(minMargin, cofOptions, defaultTranches(), today));
    const storeKey = NEGOTIATION_STORE_PREFIX + bankId;
    useEffect(() => {
        try {
            const raw = window.localStorage.getItem(storeKey);
            setAdded(raw ? JSON.parse(raw) : []);
        }
        catch {
            setAdded([]);
        }
    }, [storeKey]);
    const allDeals = useMemo(() => [...added, ...deals].sort((a, b) => (a.date < b.date ? 1 : -1)), [added, deals]);
    const open = openIdx !== null ? allDeals[openIdx] : null;
    const num = (s) => (s.trim() === "" ? 0 : Number(s) || 0);
    const setRow = (i, patch) => setDraft((d) => ({ ...d, rows: d.rows.map((r, j) => (j === i ? { ...r, ...patch } : r)) }));
    const addRow = (scheme) => setDraft((d) => ({ ...d, rows: [...d.rows, newRow(scheme, minMargin, cofOptions, tranches[0], today)] }));
    const removeRow = (i) => setDraft((d) => ({ ...d, rows: d.rows.filter((_, j) => j !== i) }));
    /** Reset the draft with fresh live CoF / tranche values each time the dialog opens. */
    const openAdd = () => {
        setDraft(emptyDraft(minMargin, cofOptions, tranches, today));
        setAddOpen(true);
    };
    const draftTotal = draft.rows.reduce((s, r) => s + num(r.amountCr), 0);
    // Blended offer implied by the rows (amount-weighted).
    const impliedWar = useMemo(() => {
        const t = draft.rows.reduce((s, r) => s + num(r.amountCr), 0);
        if (t <= 0)
            return null;
        return draft.rows.reduce((s, r) => s + num(r.amountCr) * rowRate(r), 0) / t;
    }, [draft.rows]);
    const offerPct = draft.proposedRatePct.trim() === "" ? impliedWar : num(draft.proposedRatePct);
    const askPct = draft.counterpartyAskPct.trim() === "" ? null : num(draft.counterpartyAskPct);
    const gapBps = offerPct !== null && askPct !== null ? Math.round((offerPct - askPct) * 100) : null;
    const matched = gapBps !== null && Math.abs(gapBps) <= 1;
    // A deal can only be closed when what we offered meets the counterparty ask.
    const statusOptions = matched
        ? NEGOTIATION_STATUSES
        : NEGOTIATION_STATUSES.filter((s) => s !== "closed");
    useEffect(() => {
        if (!matched && draft.status === "closed")
            setDraft((d) => ({ ...d, status: "quoted" }));
    }, [matched, draft.status]);
    const saveDraft = () => {
        const comps = draft.rows
            .filter((r) => num(r.amountCr) > 0 || rowRate(r) > 0)
            .map((r) => ({
                scheme: r.scheme,
                label: r.scheme === "RMSE"
                    ? (r.trancheName.trim() || undefined)
                    : (COF_OPTION_DEFS.find((c) => c.key === r.cofKey)?.label ?? undefined),
                amountCr: num(r.amountCr),
                freq: r.scheme === "RMSE" ? "Bullet" : (r.freq || "—"),
                ratePct: rowRate(r),
                moratoriumMonths: num(r.moratoriumMonths),
                tenureMonths: num(r.tenureMonths),
                cofLabel: r.scheme === "MSER" ? (COF_OPTION_DEFS.find((c) => c.key === r.cofKey)?.label ?? null) : null,
                cofPct: r.scheme === "MSER" ? num(r.cofPct) : null,
                marginBps: num(r.marginBps),
                discretionBps: r.scheme === "MSER" ? num(r.discretionBps) : null,
                fundRatePct: r.scheme === "RMSE" ? num(r.fundRatePct) : null,
            }));
        const mserRows = comps.filter((c) => c.scheme === "MSER");
        const rmseRows = comps.filter((c) => c.scheme === "RMSE");
        const sum = (xs) => xs.reduce((s, c) => s + c.amountCr, 0);
        const wAvg = (xs) => {
            const t = sum(xs);
            return t > 0 ? xs.reduce((s, c) => s + c.amountCr * c.ratePct, 0) / t : (xs[0]?.ratePct ?? 0);
        };
        const mser = sum(mserRows);
        const rmse = sum(rmseRows);
        const rec = {
            date: draft.date,
            status: matched ? draft.status : (draft.status === "closed" ? "quoted" : draft.status),
            counterpartyAskPct: askPct,
            principalCr: draft.principalCr.trim() === "" ? mser + rmse : num(draft.principalCr),
            mserCr: mser,
            rmseCr: rmse,
            mserTenureMonths: mserRows[0]?.tenureMonths ?? 0,
            rmseTenureMonths: rmseRows[0]?.tenureMonths ?? 0,
            mserFreq: mserRows[0]?.freq ?? "—",
            cofPct: mserRows[0]?.cofPct ?? 0,
            cofStructure: mserRows[0]?.cofLabel ?? "—",
            marginPct: (mserRows[0]?.marginBps ?? 0) / 100,
            discretionBps: mserRows[0]?.discretionBps ?? null,
            proposedRatePct: draft.proposedRatePct.trim() === "" ? wAvg(mserRows) : num(draft.proposedRatePct),
            rmseRatePct: rmseRows.length ? wAvg(rmseRows) : RMSE_FIXED_RATE,
            xirrPct: null,
            warPct: draft.warPct.trim() === "" ? wAvg(comps) : num(draft.warPct),
            note: draft.note.trim() || undefined,
            components: comps,
        };
        const next = [rec, ...added];
        setAdded(next);
        try {
            window.localStorage.setItem(storeKey, JSON.stringify(next));
        }
        catch { /* ignore */ }
        setDraft(emptyDraft(minMargin, cofOptions, tranches, today));
        setAddOpen(false);
    };
    const deleteDeal = (rec) => {
        const next = added.filter((d) => d !== rec);
        setAdded(next);
        try {
            window.localStorage.setItem(storeKey, JSON.stringify(next));
        }
        catch { /* ignore */ }
        setPendingDeal(null);
        setOpenIdx(null);
    };
    const D = ({ label, k, placeholder, mode = "decimal" }) => (_jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: label }), _jsx(Input, { value: draft[k], placeholder: placeholder, inputMode: mode === "text" ? undefined : mode, onChange: (e) => setDraft((d) => ({ ...d, [k]: e.target.value })), className: "h-9 text-sm bg-white tabular" })] }));
    return (_jsxs(_Fragment, {
        children: [_jsxs(Card, {
            children: [_jsx(CardHeader, { className: "pb-3", children: _jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center justify-between", children: [_jsxs("span", { className: "flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-navy rounded" }), " Past Negotiations", _jsx("span", { className: "inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5", children: "Illustrative" })] }), _jsxs("span", { className: "flex items-center gap-3", children: [_jsx("span", { className: "text-[10px] font-normal normal-case tracking-normal text-muted-foreground", children: "Click a row for full detail" }), _jsx(Button, { type: "button", size: "sm", className: "h-8 text-xs bg-mds-blue hover:bg-mds-blue-hover text-white normal-case tracking-normal", onClick: openAdd, children: "Add negotiation" })] })] }) }), _jsx(CardContent, {
                className: "p-0", children: allDeals.length === 0 ? (_jsx("div", { className: "p-6 text-sm text-muted-foreground", children: "No prior negotiations on record for this counterparty." })) : (_jsxs(Table, {
                    className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Date" }), _jsx(TableHead, { children: "Status" }), _jsx(TableHead, { className: "text-right", children: "Principal (Cr)" }), _jsx(TableHead, { children: "Mix (MSER / RMSE)" }), _jsx(TableHead, { children: "MSER Tenure / Freq" }), _jsx(TableHead, { className: "text-right", children: "Our Offer" }), _jsx(TableHead, { className: "text-right", children: "CP Ask" }), _jsx(TableHead, { className: "text-right", children: "Gap" }), _jsx(TableHead, { className: "text-right", children: "WAR" }), _jsx(TableHead, { className: "w-8" })] }) }), _jsx(TableBody, {
                        children: allDeals.map((d, i) => {
                            const gap = d.counterpartyAskPct != null
                                ? Math.round((d.proposedRatePct - d.counterpartyAskPct) * 100) : null;
                            return (_jsxs(TableRow, {
                                onClick: () => setOpenIdx(i), className: "cursor-pointer hover:bg-mds-blue/5", children: [_jsx(TableCell, { className: "tabular", children: d.date }), _jsx(TableCell, { children: _jsx(Badge, { variant: "outline", className: cn("capitalize", statusClass(d.status)), children: d.status }) }), _jsx(TableCell, { className: "text-right tabular font-medium", children: d.principalCr }), _jsxs(TableCell, { className: "tabular", children: ["\u20B9", d.mserCr, " / \u20B9", d.rmseCr, " Cr"] }), _jsxs(TableCell, { className: "tabular", children: [d.mserTenureMonths, "m \u00B7 ", d.mserFreq] }), _jsxs(TableCell, { className: "text-right tabular text-muted-foreground", children: [d.proposedRatePct.toFixed(2), "%"] }), _jsx(TableCell, { className: "text-right tabular", children: d.counterpartyAskPct != null ? `${d.counterpartyAskPct.toFixed(2)}%` : "—" }), _jsx(TableCell, {
                                    className: cn("text-right tabular", gap === null ? "text-muted-foreground"
                                        : Math.abs(gap) <= 1 ? "text-mds-success font-semibold" : "text-amber-700"), children: gap === null ? "—" : `${gap > 0 ? "+" : ""}${gap} bps`
                                }), _jsxs(TableCell, { className: "text-right tabular font-semibold text-mds-blue", children: [d.warPct.toFixed(2), "%"] }), _jsx(TableCell, { className: "p-1 text-right", children: added.includes(d) ? (_jsx("button", { type: "button", "aria-label": "Delete negotiation", title: "Delete negotiation", className: "inline-flex h-7 w-7 items-center justify-center rounded text-muted-foreground hover:bg-destructive/10 hover:text-destructive", onClick: (e) => { e.stopPropagation(); setPendingDeal(d); }, children: _jsx(Trash2, { className: "h-3.5 w-3.5" }) })) : null })]
                            }, i));
                        })
                    })]
                }))
            })]
        }), _jsx(AlertDialog, {
            open: !!pendingDeal, onOpenChange: (o) => {
                if (!o)
                    setPendingDeal(null);
            }, children: _jsxs(AlertDialogContent, {
                children: [_jsxs(AlertDialogHeader, {
                    children: [_jsx(AlertDialogTitle, { className: "text-base", children: "Delete this negotiation?" }), _jsx(AlertDialogDescription, {
                        children: pendingDeal
                            ? `${pendingDeal.date} · ₹${pendingDeal.principalCr} Cr · WAR ${pendingDeal.warPct.toFixed(2)}% will be removed permanently.`
                            : ""
                    })]
                }), _jsxs(AlertDialogFooter, { children: [_jsx(AlertDialogCancel, { children: "Cancel" }), _jsx(AlertDialogAction, { className: "bg-destructive text-destructive-foreground hover:bg-destructive/90", onClick: () => pendingDeal && deleteDeal(pendingDeal), children: "Delete" })] })]
            })
        }), _jsx(Dialog, {
            open: addOpen, onOpenChange: setAddOpen, children: _jsxs(DialogContent, {
                className: "max-w-4xl", children: [_jsxs(DialogHeader, { children: [_jsxs(DialogTitle, { className: "text-base text-mds-navy", children: ["Add negotiation \u00B7 ", bankName] }), _jsx(DialogDescription, { className: "text-xs", children: "Enter one row per fund component. Total principal is the sum of the rows below." })] }), _jsxs("div", {
                    className: "grid grid-cols-3 gap-3", children: [_jsxs("div", {
                        className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Date" }), _jsx(Input, {
                            type: "date", value: draft.date, max: new Date().toISOString().slice(0, 10), onChange: (e) => setDraft((d) => {
                                const t = new Date().toISOString().slice(0, 10);
                                return { ...d, date: e.target.value > t ? t : e.target.value };
                            }), className: "h-9 text-sm bg-white tabular"
                        })]
                    }), _jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Status" }), _jsxs(Select, { value: draft.status, onValueChange: (v) => setDraft((d) => ({ ...d, status: v })), children: [_jsx(SelectTrigger, { className: "h-9 text-sm bg-white", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: statusOptions.map((s) => (_jsx(SelectItem, { value: s, className: "text-xs capitalize", children: s }, s))) })] })] }), _jsxs("div", {
                        className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Total principal (Cr)" }), _jsx(Input, { value: draft.principalCr, inputMode: "decimal", placeholder: draftTotal > 0 ? draftTotal.toFixed(2) : "", onChange: (e) => setDraft((d) => ({ ...d, principalCr: e.target.value })), className: "h-9 text-sm bg-white tabular" }), (() => {
                            const stated = draft.principalCr.trim() === "" ? null : num(draft.principalCr);
                            if (stated === null)
                                return (_jsxs("div", { className: "text-[10px] text-muted-foreground tabular", children: ["Split total \u20B9", draftTotal.toFixed(2), " Cr"] }));
                            const diff = +(stated - draftTotal).toFixed(2);
                            return (_jsx("div", {
                                className: cn("text-[10px] tabular", Math.abs(diff) > 0.01 ? "text-mds-warning font-semibold" : "text-muted-foreground"), children: Math.abs(diff) > 0.01
                                    ? `Unallocated ₹${diff.toFixed(2)} Cr across splits`
                                    : `Fully allocated across splits`
                            }));
                        })()]
                    })]
                }), _jsxs("div", {
                    className: "rounded-lg border border-border overflow-hidden", children: [_jsx("div", {
                        className: "overflow-x-auto max-h-[45vh]", children: _jsxs("div", {
                            className: "min-w-[1080px]", children: [_jsxs("div", { className: "grid grid-cols-[28px_74px_1.4fr_76px_72px_78px_76px_84px_104px_68px_68px_28px] gap-2 px-3 py-2 bg-secondary/50 text-[10px] uppercase tracking-wider font-semibold text-mds-navy", children: [_jsx("div", { children: "#" }), _jsx("div", { children: "Scheme" }), _jsx("div", { children: "Funding basis" }), _jsx("div", { children: "CoF / fund %" }), _jsx("div", { children: "Margin bps" }), _jsx("div", { children: "Discr. bps" }), _jsx("div", { children: "Rate %" }), _jsx("div", { children: "Amount (Cr)" }), _jsx("div", { children: "Repayment" }), _jsx("div", { children: "Morat." }), _jsx("div", { children: "Tenure" }), _jsx("div", {})] }), draft.rows.map((r, i) => (_jsxs("div", {
                                className: "grid grid-cols-[28px_74px_1.4fr_76px_72px_78px_76px_84px_104px_68px_68px_28px] gap-2 px-3 py-2 border-t border-border/60 items-center", children: [_jsx("div", { className: "text-[11px] tabular text-muted-foreground", children: i + 1 }), _jsx("div", {
                                    children: _jsxs(Select, {
                                        value: r.scheme, onValueChange: (v) => {
                                            const scheme = v;
                                            const fresh = newRow(scheme, minMargin, cofOptions, tranches[0], today);
                                            setRow(i, { ...fresh, amountCr: r.amountCr, moratoriumMonths: r.moratoriumMonths });
                                        }, children: [_jsx(SelectTrigger, { className: "h-8 text-xs bg-white", children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "MSER", className: "text-xs", children: "MSER" }), _jsx(SelectItem, { value: "RMSE", className: "text-xs", children: "RMSE" })] })]
                                    })
                                }), _jsx("div", {
                                    children: r.scheme === "MSER" ? (_jsxs(Select, {
                                        value: r.cofKey, onValueChange: (v) => {
                                            const c = cofOptions.find((o) => o.key === v);
                                            setRow(i, {
                                                cofKey: v,
                                                cofPct: c?.ratePct != null ? c.ratePct.toFixed(2) : "",
                                            });
                                        }, children: [_jsx(SelectTrigger, { className: "h-8 text-xs bg-white", children: _jsx(SelectValue, { placeholder: "Select CoF" }) }), _jsx(SelectContent, { children: cofOptions.map((c) => (_jsxs(SelectItem, { value: c.key, className: "text-xs", children: [c.label, c.ratePct != null ? ` · ${c.ratePct.toFixed(2)}%` : ""] }, c.key))) })]
                                    })) : (_jsxs(Select, {
                                        value: r.trancheId || undefined, onValueChange: (v) => {
                                            const t = tranches.find((x) => x.id === v);
                                            if (!t)
                                                return;
                                            const tenure = roundedMonthsBetween(today, parseISODate(t.date));
                                            setRow(i, {
                                                trancheId: t.id,
                                                trancheName: t.label,
                                                fundRatePct: t.fundRatePct.toFixed(2),
                                                marginBps: String(t.marginBps),
                                                tenureMonths: String(tenure),
                                            });
                                        }, children: [_jsx(SelectTrigger, { className: "h-8 text-xs bg-white", children: _jsx(SelectValue, { placeholder: "Select tranche" }) }), _jsx(SelectContent, { children: tranches.map((t) => (_jsx(SelectItem, { value: t.id, className: "text-xs", children: t.label }, t.id))) })]
                                    }))
                                }), _jsx("div", { children: _jsx(Input, { value: r.scheme === "MSER" ? r.cofPct : r.fundRatePct, inputMode: "decimal", onChange: (e) => setRow(i, r.scheme === "MSER" ? { cofPct: e.target.value } : { fundRatePct: e.target.value }), className: "h-8 text-xs bg-white tabular" }) }), _jsx("div", { children: _jsx(Input, { value: r.marginBps, inputMode: "numeric", onChange: (e) => setRow(i, { marginBps: e.target.value }), className: "h-8 text-xs bg-white tabular" }) }), _jsx("div", { children: r.scheme === "MSER" ? (_jsx(Input, { value: r.discretionBps, inputMode: "numeric", onChange: (e) => setRow(i, { discretionBps: e.target.value }), className: "h-8 text-xs bg-white tabular" })) : (_jsx("div", { className: "h-8 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-xs text-muted-foreground", children: "\u2014" })) }), _jsx("div", { className: "h-8 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-xs tabular font-semibold text-mds-navy", children: rowRate(r).toFixed(2) }), _jsx("div", { children: _jsx(Input, { value: r.amountCr, inputMode: "decimal", onChange: (e) => setRow(i, { amountCr: e.target.value }), className: "h-8 text-xs bg-white tabular" }) }), _jsx("div", { children: r.scheme === "RMSE" ? (_jsx("div", { className: "h-8 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-xs text-mds-navy", children: "Bullet" })) : (_jsxs(Select, { value: r.freq, onValueChange: (v) => setRow(i, { freq: v }), children: [_jsx(SelectTrigger, { className: "h-8 text-xs bg-white", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: NEGO_FREQS.map((f) => _jsx(SelectItem, { value: f, className: "text-xs", children: f }, f)) })] })) }), _jsx("div", { children: _jsx(Input, { value: r.moratoriumMonths, inputMode: "numeric", onChange: (e) => setRow(i, { moratoriumMonths: e.target.value }), className: "h-8 text-xs bg-white tabular" }) }), _jsx("div", { children: _jsx(Input, { value: r.tenureMonths, inputMode: "numeric", onChange: (e) => setRow(i, { tenureMonths: e.target.value }), className: "h-8 text-xs bg-white tabular" }) }), _jsx("button", { type: "button", "aria-label": "Remove row", onClick: () => removeRow(i), disabled: draft.rows.length <= 1, className: "h-6 w-6 inline-flex items-center justify-center rounded text-muted-foreground hover:text-destructive disabled:opacity-30", children: _jsx(X, { className: "h-3.5 w-3.5" }) })]
                            }, i)))]
                        })
                    }), _jsx("div", { className: "px-3 py-2 border-t border-border bg-secondary/30", children: _jsx("button", { type: "button", onClick: () => addRow("MSER"), className: "text-[11px] text-mds-blue hover:underline", children: "+ Add row" }) })]
                }), _jsxs("div", { className: "grid grid-cols-4 gap-3", children: [_jsx(D, { label: "Counterparty ask %", k: "counterpartyAskPct" }), _jsx(D, { label: "SIDBI Offer %", k: "proposedRatePct" }), _jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "WAR %" }), _jsx(Input, { value: draft.warPct === "" && impliedWar !== null ? impliedWar.toFixed(2) : draft.warPct, inputMode: "decimal", onChange: (e) => setDraft((d) => ({ ...d, warPct: e.target.value })), className: "h-9 text-sm bg-white tabular" })] }), _jsx(D, { label: "Status note", k: "note", mode: "text", placeholder: "Why it closed / where it stands" })] }), _jsx("div", {
                    className: cn("rounded-md border px-3 py-2 text-xs", gapBps === null ? "border-border bg-secondary/30 text-muted-foreground"
                        : matched ? "border-mds-success/40 bg-mds-success/5 text-mds-success"
                            : "border-amber-400 bg-amber-50 text-amber-800"), children: gapBps === null ? ("Enter the counterparty ask to check whether the offer matches — a deal can only be marked closed when offer = ask.") : matched ? (_jsxs(_Fragment, { children: ["Offer ", offerPct.toFixed(2), "% matches ask ", askPct.toFixed(2), "% \u2014 this negotiation can be marked ", _jsx("span", { className: "font-semibold", children: "closed" }), "."] })) : (_jsxs(_Fragment, { children: ["Offer ", offerPct.toFixed(2), "% vs ask ", askPct.toFixed(2), "% \u2014 gap of ", _jsxs("span", { className: "font-semibold tabular", children: [gapBps > 0 ? "+" : "", gapBps, " bps"] }), ". Not closed; record it as quoted / proposed / on hold / declined."] }))
                }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", size: "sm", className: "h-8 text-xs", onClick: () => setAddOpen(false), children: "Cancel" }), _jsx(Button, { size: "sm", className: "h-8 text-xs bg-mds-blue hover:bg-mds-blue-hover text-white", onClick: saveDraft, children: "Save negotiation" })] })]
            })
        }), _jsx(Dialog, {
            open: open !== null, onOpenChange: (v) => !v && setOpenIdx(null), children: _jsxs(DialogContent, {
                className: "max-w-2xl", children: [_jsxs(DialogHeader, {
                    children: [_jsxs(DialogTitle, { className: "text-mds-navy", children: ["Deal detail \u00B7 ", bankName, " \u00B7 ", open?.date] }), _jsx(DialogDescription, {
                        children: open?.status === "closed"
                            ? "Closed — our offer met the counterparty ask."
                            : "Open negotiation — offer and ask have not met yet."
                    })]
                }), open && (_jsxs("div", {
                    className: "space-y-4 text-sm", children: [_jsxs("div", { className: "grid grid-cols-3 gap-3", children: [_jsx(StatBlock, { label: "Total Principal", value: `₹${open.principalCr} Cr` }), _jsx(StatBlock, { label: "External Rating", value: open.externalRating ?? "—" }), _jsx(StatBlock, { label: "WAR", value: `${open.warPct.toFixed(2)}%`, accent: true })] }), _jsxs("div", {
                        className: "grid grid-cols-3 gap-3", children: [_jsx(StatBlock, { label: "SIDBI Offer", value: `${open.proposedRatePct.toFixed(2)}%` }), _jsx(StatBlock, { label: "Counterparty ask", value: open.counterpartyAskPct != null ? `${open.counterpartyAskPct.toFixed(2)}%` : "—" }), _jsx(StatBlock, {
                            label: "Gap (offer \u2212 ask)", value: open.counterpartyAskPct != null
                                ? `${Math.round((open.proposedRatePct - open.counterpartyAskPct) * 100) > 0 ? "+" : ""}${Math.round((open.proposedRatePct - open.counterpartyAskPct) * 100)} bps`
                                : "—"
                        })]
                    }), open.components && open.components.length > 0 ? (_jsxs("div", {
                        className: "rounded-lg border border-border overflow-hidden", children: [_jsxs("div", { className: "grid grid-cols-[70px_1fr_90px_100px_70px_70px_80px] gap-2 px-3 py-2 bg-secondary/50 text-[10px] uppercase tracking-wider text-muted-foreground", children: [_jsx("div", { children: "Scheme" }), _jsx("div", { children: "Build-up" }), _jsx("div", { className: "text-right", children: "Amount" }), _jsx("div", { children: "Repayment" }), _jsx("div", { className: "text-right", children: "Rate" }), _jsx("div", { className: "text-right", children: "Morat." }), _jsx("div", { className: "text-right", children: "Tenure" })] }), open.components.map((c, i) => (_jsxs("div", {
                            className: "grid grid-cols-[70px_1fr_90px_100px_70px_70px_80px] gap-2 px-3 py-2 text-xs border-t border-border/60 items-center", children: [_jsx("div", { className: "font-semibold text-mds-navy", children: c.scheme }), _jsxs("div", {
                                className: "text-mds-navy", children: [_jsx("div", { className: "truncate", children: c.label ?? "—" }), _jsx("div", {
                                    className: "text-[10px] text-muted-foreground tabular", children: c.scheme === "MSER"
                                        ? `CoF ${c.cofPct != null ? c.cofPct.toFixed(2) + "%" : "—"} + ${c.marginBps ?? "—"} bps margin − ${c.discretionBps ?? 0} bps discretion`
                                        : `Fund ${c.fundRatePct != null ? c.fundRatePct.toFixed(2) + "%" : "—"} + ${c.marginBps ?? "—"} bps margin`
                                })]
                            }), _jsxs("div", { className: "text-right tabular", children: ["\u20B9", c.amountCr, " Cr"] }), _jsx("div", { className: "text-mds-navy", children: c.freq }), _jsxs("div", { className: "text-right tabular font-semibold text-mds-blue", children: [c.ratePct.toFixed(2), "%"] }), _jsxs("div", { className: "text-right tabular", children: [c.moratoriumMonths, " mo"] }), _jsxs("div", { className: "text-right tabular", children: [c.tenureMonths, " mo"] })]
                        }, i)))]
                    })) : (_jsxs(_Fragment, { children: [_jsxs("div", { className: "rounded-lg border border-border p-3 space-y-2 bg-secondary/20", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-mds-navy font-semibold", children: "MSER Scheme" }), _jsxs("div", { className: "grid grid-cols-4 gap-2 text-xs", children: [_jsx(KV, { k: "Amount", v: `₹${open.mserCr} Cr` }), _jsx(KV, { k: "Tenure", v: `${open.mserTenureMonths} mo` }), _jsx(KV, { k: "Repayment", v: open.mserFreq }), _jsx(KV, { k: "Rate", v: `${open.proposedRatePct.toFixed(2)}%`, strong: true })] }), _jsxs("div", { className: "grid grid-cols-4 gap-2 text-xs pt-1 border-t border-border", children: [_jsx(KV, { k: "CoF", v: `${open.cofPct.toFixed(2)}%` }), _jsx(KV, { k: "CoF Structure", v: open.cofStructure }), _jsx(KV, { k: "Margin", v: `${(open.marginPct * 100).toFixed(0)} bps` }), _jsx(KV, { k: "Discretion", v: open.discretionBps === null ? "nil" : `${open.discretionBps} bps` })] })] }), open.rmseCr > 0 && (_jsxs("div", { className: "rounded-lg border border-border p-3 space-y-2 bg-secondary/20", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-mds-navy font-semibold", children: "RMSE Scheme" }), _jsxs("div", { className: "grid grid-cols-4 gap-2 text-xs", children: [_jsx(KV, { k: "Amount", v: `₹${open.rmseCr} Cr` }), _jsx(KV, { k: "Tenure", v: `${open.rmseTenureMonths} mo` }), _jsx(KV, { k: "Repayment", v: "Bullet" }), _jsx(KV, { k: "Rate", v: `${open.rmseRatePct.toFixed(2)}%`, strong: true })] })] }))] })), _jsxs("div", { className: "grid grid-cols-2 gap-3", children: [_jsx(StatBlock, { label: "XIRR", value: open.xirrPct !== null ? `${open.xirrPct.toFixed(2)}%` : "—" }), _jsx(StatBlock, { label: "Spread over CoF", value: `${((open.proposedRatePct - open.cofPct) * 100).toFixed(0)} bps` })] }), open.note && (_jsx("div", { className: "text-xs text-muted-foreground border-l-2 border-mds-blue pl-3 py-1", children: open.note }))]
                }))]
            })
        })]
    }));
}
function StatBlock({ label, value, accent }) {
    return (_jsxs("div", { className: cn("rounded-md p-3", accent ? "bg-mds-blue/10" : "bg-secondary/40"), children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: label }), _jsx("div", { className: cn("text-lg font-bold tabular mt-0.5", accent ? "text-mds-blue" : "text-mds-navy"), children: value })] }));
}
function KV({ k, v, strong }) {
    return (_jsxs("div", { children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: k }), _jsx("div", { className: cn("tabular", strong ? "font-bold text-mds-blue" : "text-mds-navy"), children: v })] }));
}
// ============ Detailed Calculations — mirrors WAR_Sheet.xlsx methodology ============
// Sources: Entry Sheet C6:I9 (deal composition), C16:D24 (WAR), Working I11/O11/C23/I23
// (Effective RoI), Qtly/HY/Annual/Bullet Princ Pmt sheets (amortisation).
/**
 * The monthly cash flows WAR is built from: interest = opening × rate/12 on every
 * leg, principal per the chosen repayment structure. Σ interest ÷ (Σ opening ÷ 12)
 * is exactly the WAR shown below the table.
 */
function WarCashflowSchedule({ state, freq, caption }) {
    const legs = legSchedules(state, freq);
    const maxN = legs.reduce((m, l) => Math.max(m, l.rows.length), 0);
    const rows = Array.from({ length: maxN }, (_, i) => {
        const m = i + 1;
        let opening = 0, interest = 0, principal = 0, closing = 0;
        for (const l of legs) {
            const r = l.rows[i];
            if (!r)
                continue;
            opening += r.opening;
            interest += r.interest;
            principal += r.principal;
            closing += r.closing;
        }
        return { m, opening, interest, principal, closing };
    });
    const sumInt = rows.reduce((t, r) => t + r.interest, 0);
    const sumOpen = rows.reduce((t, r) => t + r.opening, 0);
    const sumPrin = rows.reduce((t, r) => t + r.principal, 0);
    return (_jsxs("div", { className: "mx-4 space-y-2", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: caption }), _jsx("div", { className: "text-[10px] text-muted-foreground", children: legs.map((l) => `${l.leg.label} · ₹${l.leg.amountCr.toFixed(2)} Cr @ ${l.leg.scheme_.ratePct.toFixed(2)}% · ${Math.round(l.leg.scheme_.tenureMonths)}m`).join("  |  ") }), _jsx("div", { className: "rounded-md border max-h-72 overflow-auto", children: _jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { className: "sticky top-0 bg-background z-10", children: _jsxs(TableRow, { children: [_jsx(TableHead, { className: "w-14", children: "Month" }), _jsx(TableHead, { className: "text-right", children: "Opening (Cr)" }), _jsx(TableHead, { className: "text-right", children: "Interest (Cr)" }), _jsx(TableHead, { className: "text-right", children: "Principal (Cr)" }), _jsx(TableHead, { className: "text-right", children: "Closing (Cr)" })] }) }), _jsxs(TableBody, { children: [rows.map((r) => (_jsxs(TableRow, { className: r.principal > 1e-9 ? "bg-mds-blue/5" : "", children: [_jsx(TableCell, { className: "tabular", children: r.m }), _jsx(TableCell, { className: "text-right tabular", children: r.opening.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular", children: r.interest.toFixed(4) }), _jsx(TableCell, { className: "text-right tabular", children: r.principal > 1e-9 ? r.principal.toFixed(2) : "—" }), _jsx(TableCell, { className: "text-right tabular text-muted-foreground", children: r.closing.toFixed(2) })] }, r.m))), _jsxs(TableRow, { className: "border-t-2 bg-secondary/40 sticky bottom-0", children: [_jsx(TableCell, { className: "font-semibold", children: "\u03A3" }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: sumOpen.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: sumInt.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: sumPrin.toFixed(2) }), _jsx(TableCell, {})] })] })] }) }), _jsxs("div", { className: "text-[10px] text-muted-foreground", children: ["\u03A3 Interest = ", sumInt.toFixed(2), " Cr \u00B7 Weighted principal = \u03A3 Opening \u00F7 12 = ", sumOpen.toFixed(2), " \u00F7 12 = ", (sumOpen / 12).toFixed(2), " Cr-yrs", " ", "\u2192 WAR = ", sumOpen > 0 ? ((sumInt / (sumOpen / 12)) * 100).toFixed(2) : "—", "%. Rows shaded blue = principal repayment months."] })] }));
}
const CONT_SEEK_META = {
    mserRate: { label: "MSER Rate", unit: "%", min: 0.5, max: 20, step: 0.001, fmt: (v) => `${v.toFixed(2)} %` },
    mserShare: { label: "MSER Share", unit: "%", min: 1, max: 99, step: 0.01, fmt: (v) => `${v.toFixed(2)} %` },
    mserTenure: { label: "MSER Tenure", unit: "mo", min: 6, max: 120, step: 1, fmt: (v) => `${Math.round(v)} months` },
};
const SEEK_LABELS = {
    mserRate: "Rate (%)",
    mserShare: "Share of principal (%)",
    mserTenure: "Tenure (months)",
    mserFreq: "Principal repayment frequency",
};
const SEEK_LABELS_SPLIT = {
    ...SEEK_LABELS,
    mserShare: "Amount (₹ Cr)",
};
/** Bounds for the chosen lever, widened for split amounts (₹ Cr, not %). */
function seekMeta(variable, legId, principalCr) {
    const base = CONT_SEEK_META[variable];
    if (variable === "mserShare" && legId !== "base") {
        return { ...base, label: "Amount", unit: "₹ Cr", min: 0.01, max: Math.max(0.02, principalCr), step: 0.01, fmt: (v) => `₹${v.toFixed(2)} Cr` };
    }
    return base;
}
function evalMetric(state, freq, metric) {
    // WAR here matches the "WAR (Quote)" chip on the negotiation range bar and
    // the hero's blended-final rate — the Excel WAR sheet formula
    //   Σ (Amt × Rate × Tenure_yr) ÷ Σ (Amt × Tenure_yr).
    // Frequency-independent (unlike effectiveRateForFreq).
    return metric === "war"
        ? weightedAvgRate(state).war
        : xirr(combinedCashflows(state, freq));
}
/** Apply a candidate lever value to a copy of the deal state for the chosen leg. */
function applySeek(state, legId, variable, v) {
    const s = { ...state, mser: { ...state.mser }, rmse: { ...state.rmse }, splits: (state.splits ?? []).map((x) => ({ ...x })) };
    if (legId === "base") {
        if (variable === "mserRate")
            s.mser.ratePct = v;
        else if (variable === "mserShare")
            s.mserSharePct = v;
        else if (variable === "mserTenure")
            s.mser.tenureMonths = Math.round(v);
        else
            s.repaymentFreq = v;
        return s;
    }
    s.splits = (s.splits ?? []).map((sp) => {
        if (sp.id !== legId)
            return sp;
        if (variable === "mserRate")
            return { ...sp, ratePct: v };
        if (variable === "mserShare")
            return { ...sp, amountCr: v };
        if (variable === "mserTenure")
            return { ...sp, tenureMonths: Math.round(v) };
        return { ...sp, freq: v };
    });
    return s;
}
function solveContinuous(state, freq, variable, target, metric = "xirr", legId = "base") {
    const meta = seekMeta(variable, legId, state.principalCr);
    const snap = (v) => {
        if (variable === "mserTenure")
            return Math.max(meta.min, Math.min(meta.max, Math.round(v)));
        const clamped = Math.max(meta.min, Math.min(meta.max, v));
        return Math.round(clamped / meta.step) * meta.step;
    };
    const evalAt = (v) => evalMetric(applySeek(state, legId, variable, v), freq, metric);
    // Tenure is discrete — enumerate integer months and pick the closest match.
    if (variable === "mserTenure") {
        let best = null;
        for (let m = meta.min; m <= meta.max; m += 1) {
            const x = evalAt(m);
            if (!isFinite(x))
                continue;
            if (!best || Math.abs(x - target) < Math.abs(best.x - target))
                best = { v: m, x };
        }
        if (!best)
            return { value: null, achieved: NaN };
        const reachable = Math.abs(best.x - target) < 0.01;
        return reachable ? { value: best.v, achieved: best.x } : { value: null, achieved: best.x };
    }
    let lo = meta.min, hi = meta.max;
    const fLo = evalAt(lo), fHi = evalAt(hi);
    if (!isFinite(fLo) || !isFinite(fHi))
        return { value: null, achieved: NaN };
    const increasing = fHi > fLo;
    const lower = increasing ? fLo : fHi;
    const upper = increasing ? fHi : fLo;
    if (Math.abs(upper - lower) < 1e-6) {
        return { value: null, achieved: fLo };
    }
    if (target < lower - 1e-6 || target > upper + 1e-6) {
        const boundary = target < lower ? (increasing ? lo : hi) : (increasing ? hi : lo);
        return { value: null, achieved: evalAt(boundary) };
    }
    for (let i = 0; i < 200; i++) {
        const mid = (lo + hi) / 2;
        const fMid = evalAt(mid);
        if (!isFinite(fMid))
            break;
        const goHigher = increasing ? fMid < target : fMid > target;
        if (goHigher)
            lo = mid;
        else
            hi = mid;
        if ((hi - lo) < meta.step / 100)
            break;
    }
    const rawMid = (lo + hi) / 2;
    const snapped = snap(rawMid);
    const achieved = evalAt(snapped);
    return { value: snapped, achieved };
}
function solveFrequency(state, target, metric = "xirr", legId = "base", chosenFreq = "quarterly") {
    const all = FREQUENCIES.filter((f) => f.key !== "custom").map((f) => ({
        freq: f.key,
        value: evalMetric(applySeek(state, legId, "mserFreq", f.key), legId === "base" ? f.key : chosenFreq, metric),
    }));
    const valid = all.filter((r) => isFinite(r.value));
    if (valid.length === 0)
        return { value: null, achieved: NaN, all };
    const best = valid.reduce((a, b) => Math.abs(b.value - target) < Math.abs(a.value - target) ? b : a);
    return { value: best.freq, achieved: best.value, all };
}
/** Compact solver summary in the output column; opens the full solver in a dialog. */
function GoalSeekLauncher(props) {
    const [open, setOpen] = useState(false);
    return (_jsxs(_Fragment, { children: [_jsx(Button, { size: "sm", className: "h-8 shrink-0 bg-mds-purple text-white hover:bg-mds-purple/90 text-[11px]", onClick: () => setOpen(true), children: "Open solver" }), _jsx(Dialog, { open: open, onOpenChange: setOpen, children: _jsxs(DialogContent, { className: "max-w-4xl max-h-[85vh] overflow-auto p-0", children: [_jsxs(DialogHeader, { className: "sr-only", children: [_jsx(DialogTitle, { children: "Solve for target" }), _jsx(DialogDescription, { children: "Reverse-solve deal parameters for a target XIRR or WAR" })] }), _jsx(GoalSeek, { ...props, bare: true })] }) })] }));
}
function GoalSeek({ state, chosenFreq, currentXirr, currentWar, onApply, bare }) {
    const [metric, setMetric] = useState("xirr");
    const currentValue = metric === "war" ? currentWar : currentXirr;
    // Target is a string so the user can freely edit / clear the field.
    const [targetStr, setTargetStr] = useState(() => currentValue.toFixed(2));
    // When the metric toggles, reset the target to the current value of that metric.
    useEffect(() => { setTargetStr(currentValue.toFixed(2)); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [metric]);
    const parsed = parseFloat(targetStr);
    const target = Number.isFinite(parsed) ? parsed : currentValue;
    const [variable, setVariable] = useState("mserRate");
    const { mserAmt, rmseAmt } = schemeAmounts(state);
    const allSplits = state.splits ?? [];
    const mserSplits = allSplits.filter((sp) => sp.scheme === "mser");
    // Only MSER parameters are negotiable, so the leg picker lists the base MSER
    // leg plus every MSER split. One leg, one lever at a time.
    const legs = useMemo(() => [
        { id: "base", label: mserSplits.length > 0 ? "MSER 1" : "MSER", amountCr: baseLegAmount(state, "mser") },
        ...mserSplits.map((sp, i) => ({ id: sp.id, label: `MSER ${i + 2}`, amountCr: sp.amountCr })),
        // eslint-disable-next-line react-hooks/exhaustive-deps
    ], [state]);
    const [legId, setLegId] = useState("base");
    useEffect(() => {
        if (!legs.some((l) => l.id === legId))
            setLegId("base");
    }, [legs, legId]);
    const legLabel = legs.find((l) => l.id === legId)?.label ?? "MSER";
    const labels = legId === "base" ? SEEK_LABELS : SEEK_LABELS_SPLIT;
    // WAR (Amt×Rate×Tenure) is frequency-independent, so the Frequency
    // lever cannot move it — hide that option in WAR mode.
    useEffect(() => {
        if (metric === "war" && variable === "mserFreq")
            setVariable("mserRate");
    }, [metric, variable]);
    const stateRef = useRef(state);
    const freqRef = useRef(chosenFreq);
    useEffect(() => { stateRef.current = state; freqRef.current = chosenFreq; });
    const [contSolved, setContSolved] = useState(null);
    const [freqSolved, setFreqSolved] = useState(null);
    const [solvedSnapshot, setSolvedSnapshot] = useState(null);
    // Re-solve whenever the target, leg, lever, metric, OR the underlying deal state
    // changes, so the recommendation stays in sync with the live inputs.
    const stateKey = JSON.stringify({
        p: state.principalCr, sh: state.mserSharePct,
        m: state.mser, r: state.rmse, f: chosenFreq, tail: state.customTailMonths,
        sp: allSplits,
    });
    useEffect(() => {
        const s = stateRef.current;
        const f = freqRef.current;
        if (variable === "mserFreq") {
            setContSolved(null);
            setFreqSolved(solveFrequency(s, target, metric, legId, f));
        }
        else {
            setFreqSolved(null);
            setContSolved(solveContinuous(s, f, variable, target, metric, legId));
        }
        setSolvedSnapshot({ principalCr: s.principalCr, mserSharePct: s.mserSharePct });
    }, [target, variable, metric, legId, stateKey]);
    const currentFreqLabel = FREQUENCIES.find((f) => f.key === chosenFreq)?.label ?? chosenFreq;
    const freqLabelOf = (f) => FREQUENCIES.find((x) => x.key === f)?.label ?? f;
    // Solved cells only decorate the selected leg — every other row stays "current only".
    const solvedRate = variable === "mserRate" && contSolved?.value != null ? `${contSolved.value.toFixed(2)} %` : null;
    const solvedShare = variable === "mserShare" && contSolved?.value != null
        ? (legId === "base" ? `${contSolved.value.toFixed(2)} %`
            : `${state.principalCr > 0 ? ((contSolved.value / state.principalCr) * 100).toFixed(2) : "0.00"} %`)
        : null;
    const solvedAmt = variable === "mserShare" && contSolved?.value != null
        ? (legId === "base" && solvedSnapshot
            ? `₹${((solvedSnapshot.principalCr * contSolved.value) / 100).toFixed(2)} Cr`
            : `₹${contSolved.value.toFixed(2)} Cr`)
        : null;
    const solvedTenure = variable === "mserTenure" && contSolved?.value != null ? `${Math.round(contSolved.value)} months` : null;
    const solvedFreq = variable === "mserFreq" && freqSolved?.value ? freqLabelOf(freqSolved.value) : null;
    const outOfRange = variable !== "mserFreq" && contSolved != null && contSolved.value === null;
    const solvedAchieved = variable === "mserFreq" ? (freqSolved?.achieved ?? NaN) : (contSolved?.achieved ?? NaN);
    // "Not exact" = solver returned a value but it can't hit the target to within 1 bp.
    const notExact = isFinite(solvedAchieved) && Math.abs(solvedAchieved - target) > 0.01;
    const unreachable = outOfRange || notExact;
    // Manual apply — user reviews the solved value and clicks Apply.
    const contValue = contSolved?.value ?? null;
    const freqValue = freqSolved?.value ?? null;
    const legFreq = legId === "base"
        ? chosenFreq
        : (mserSplits.find((sp) => sp.id === legId)?.freq ?? state.repaymentFreq);
    // Allow applying the nearest-achievable value even when not exact; only block when truly out of range.
    const canApply = !outOfRange && (variable === "mserFreq"
        ? !!freqValue && freqValue !== legFreq
        : contValue != null);
    const handleApply = () => {
        if (!onApply || !canApply)
            return;
        if (variable === "mserFreq") {
            if (freqValue)
                onApply(variable, freqValue, legId);
        }
        else if (contValue != null) {
            const next = variable === "mserTenure" ? Math.round(contValue) : contValue;
            onApply(variable, next, legId);
        }
    };
    const COLS = ["Scheme", "Share", "Amount", "Rate", "Tenure", "Moratorium", "Principal Repayment"];
    const pct = (amt) => state.principalCr > 0 ? (amt / state.principalCr) * 100 : 0;
    const sel = (id) => id === legId;
    const rows = [
        {
            id: "base",
            label: legs[0].label,
            accent: "bg-mds-blue",
            cells: {
                Share: { current: `${pct(baseLegAmount(state, "mser")).toFixed(2)} %`, solved: sel("base") ? solvedShare : null },
                Amount: { current: `₹${baseLegAmount(state, "mser").toFixed(2)} Cr`, solved: sel("base") ? solvedAmt : null },
                Rate: { current: `${state.mser.ratePct.toFixed(2)} %`, solved: sel("base") ? solvedRate : null },
                Tenure: { current: `${state.mser.tenureMonths} months`, solved: sel("base") ? solvedTenure : null },
                Moratorium: { current: `${state.mser.moratoriumMonths} months`, solved: null },
                "Principal Repayment": { current: currentFreqLabel, solved: sel("base") ? solvedFreq : null },
            },
        },
        ...mserSplits.map((sp, i) => ({
            id: sp.id,
            label: `MSER ${i + 2}`,
            accent: "bg-mds-blue/60",
            cells: {
                Share: { current: `${pct(sp.amountCr).toFixed(2)} %`, solved: sel(sp.id) ? solvedShare : null },
                Amount: { current: `₹${sp.amountCr.toFixed(2)} Cr`, solved: sel(sp.id) ? solvedAmt : null },
                Rate: { current: `${sp.ratePct.toFixed(2)} %`, solved: sel(sp.id) ? solvedRate : null },
                Tenure: { current: `${sp.tenureMonths} months`, solved: sel(sp.id) ? solvedTenure : null },
                Moratorium: { current: `${sp.moratoriumMonths} months`, solved: null },
                "Principal Repayment": { current: freqLabelOf(sp.freq ?? state.repaymentFreq), solved: sel(sp.id) ? solvedFreq : null },
            },
        })),
        {
            id: "rmse",
            label: "RMSE",
            accent: "bg-mds-purple",
            cells: {
                Share: { current: `${pct(rmseAmt).toFixed(2)} %`, solved: null },
                Amount: { current: `₹${rmseAmt.toFixed(2)} Cr`, solved: null },
                Rate: { current: `${state.rmse.ratePct.toFixed(2)} %`, solved: null },
                Tenure: { current: `${state.rmse.tenureMonths} months`, solved: null },
                Moratorium: { current: `${state.rmse.moratoriumMonths} months`, solved: null },
                "Principal Repayment": { current: "Bullet", solved: null },
            },
        },
    ];
    void mserAmt;
    const renderCell = (c) => (_jsxs("div", { className: "tabular text-mds-navy leading-tight", children: [_jsx("div", { children: c.current }), c.solved && (_jsxs("div", { className: "mt-0.5 text-mds-purple font-bold", children: ["\u2192 ", c.solved] }))] }));
    const GRID = "grid grid-cols-[0.9fr_0.8fr_0.9fr_0.9fr_0.9fr_1fr_1.2fr]";
    return (_jsxs(Card, {
        className: bare ? "border-0 shadow-none" : undefined, children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-purple rounded" }), "Solve for Target ", metric === "war" ? "WAR" : "XIRR"] }), _jsxs("div", { className: "pt-1 text-[11px] text-muted-foreground", children: [legs.length > 1 ? "Pick the MSER split and the single parameter to solve." : "Pick the single MSER parameter to solve.", " The solved value is shown in purple next to the current value."] })] }), _jsxs(CardContent, {
            className: "space-y-4", children: [_jsx("div", { className: "px-2", children: _jsx("div", { className: "inline-flex rounded-md border border-border bg-white p-0.5", role: "tablist", "aria-label": "Target metric", children: ["xirr", "war"].map((m) => (_jsx("button", { type: "button", role: "tab", "aria-selected": metric === m, onClick: () => setMetric(m), className: `px-3 py-1.5 text-xs font-semibold uppercase tracking-wider rounded ${metric === m ? "bg-mds-navy text-white" : "text-muted-foreground hover:text-mds-navy"}`, children: m === "war" ? "WAR" : "XIRR" }, m))) }) }), _jsxs("div", {
                className: cn("grid grid-cols-1 gap-4 px-2", legs.length > 1 ? "md:grid-cols-3" : "md:grid-cols-2"), children: [_jsxs("div", {
                    className: "space-y-1.5", children: [_jsxs(Label, { className: "text-xs text-muted-foreground", children: ["Target ", metric === "war" ? "WAR" : "XIRR", " (%)"] }), _jsx(Input, {
                        type: "number", step: 0.01, value: targetStr, onChange: (e) => setTargetStr(e.target.value), onBlur: () => {
                            if (!Number.isFinite(parseFloat(targetStr)))
                                setTargetStr(currentValue.toFixed(2));
                        }, className: "tabular font-semibold text-lg h-11"
                    }), _jsxs("div", { className: "text-[10px] text-muted-foreground", children: ["Current ", metric === "war" ? "WAR" : `XIRR (${currentFreqLabel})`, ": ", _jsxs("span", { className: "tabular font-semibold text-mds-navy", children: [currentValue.toFixed(2), "%"] }), isFinite(solvedAchieved) && !unreachable && (_jsxs(_Fragment, { children: ["  \u00B7  Target: ", _jsxs("span", { className: "tabular font-semibold text-mds-blue", children: [solvedAchieved.toFixed(2), "%"] })] }))] })]
                }), legs.length > 1 && (_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { className: "text-xs text-muted-foreground", children: "MSER split" }), _jsxs(Select, { value: legId, onValueChange: (v) => setLegId(v), children: [_jsx(SelectTrigger, { className: "h-11 bg-white", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: legs.map((l) => (_jsxs(SelectItem, { value: l.id, children: [l.label, " \u00B7 \u20B9", l.amountCr.toFixed(2), " Cr"] }, l.id))) })] })] })), _jsxs("div", {
                    className: "space-y-1.5", children: [_jsx(Label, { className: "text-xs text-muted-foreground", children: "Solve for parameter" }), _jsxs(Select, {
                        value: variable, onValueChange: (v) => setVariable(v), children: [_jsx(SelectTrigger, { className: "h-11 bg-white", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, {
                            children: Object.keys(labels)
                                .filter((k) => !(metric === "war" && k === "mserFreq"))
                                .map((k) => (_jsx(SelectItem, { value: k, children: labels[k] }, k)))
                        })]
                    })]
                })]
            }), _jsxs("div", { className: "mx-2 rounded-md border border-border overflow-hidden", children: [_jsx("div", { className: cn(GRID, "bg-mds-navy/5 text-[10px] uppercase tracking-wider text-muted-foreground px-3 py-2 font-semibold"), children: COLS.map((c) => _jsx("div", { children: c }, c)) }), rows.map((r) => (_jsxs("div", { className: cn(GRID, "px-3 py-2.5 text-xs border-t border-border items-center", r.id === legId && "bg-mds-purple/5"), children: [_jsxs("div", { className: "flex items-center gap-2 font-semibold text-mds-navy", children: [_jsx("span", { className: cn("w-1 h-4 rounded", r.accent) }), r.label] }), COLS.filter((c) => c !== "Scheme").map((c) => (_jsx("div", { children: renderCell(r.cells[c]) }, c)))] }, r.id)))] }), unreachable && (_jsxs("div", { className: "mx-2 rounded-md border border-mds-warning/40 bg-mds-warning/5 p-3 flex items-start gap-2", children: [_jsx(AlertTriangle, { className: "w-4 h-4 text-mds-warning mt-0.5 shrink-0" }), _jsxs("div", { className: "text-xs text-mds-navy", children: ["Target ", metric === "war" ? "WAR" : "XIRR", " of ", _jsxs("span", { className: "tabular font-semibold", children: [target.toFixed(2), "%"] }), " ", outOfRange ? "is outside the reachable range" : "can't be hit exactly", " by adjusting ", _jsxs("span", { className: "font-semibold", children: [legLabel, " \u00B7 ", labels[variable]] }), " alone. Nearest achievable: ", _jsx("span", { className: "tabular font-semibold text-mds-blue", children: isFinite(solvedAchieved) ? `${solvedAchieved.toFixed(2)}%` : "—" }), outOfRange ? ". Try a different split or parameter." : "."] })] })), _jsx("div", { className: "flex justify-end px-2", children: _jsx(Button, { type: "button", onClick: handleApply, disabled: !canApply, className: "bg-mds-blue hover:bg-mds-blue-hover text-white", children: "Apply to inputs" }) })]
        })]
    }));
}
function DetailedCalcs({ state, cofPct, cofLabel, chosenFreq }) {
    const { mserAmt, rmseAmt } = schemeAmounts(state);
    const total = state.principalCr;
    const mYr = state.mser.tenureMonths / 12;
    const rYr = state.rmse.tenureMonths / 12;
    const customTail = Math.max(1, Math.min(state.mser.tenureMonths, Math.round(state.customTailMonths ?? 3)));
    const freqLabelBase = FREQUENCIES.find((f) => f.key === chosenFreq)?.label ?? chosenFreq;
    const freqLabel = chosenFreq === "custom" ? `Custom · last ${customTail}m` : freqLabelBase;
    // WAR (Entry Sheet C16:D24 methodology)
    const war = weightedAvgRate(state);
    // Funding Cost of Funds (Treasury for MSER, RBI fund for RMSE)
    // Effective RoI per frequency
    const basePerFreq = FREQUENCIES.filter((f) => f.key !== "custom").map((f) => {
        const r = effectiveRateForFreq(state, f.key);
        const cf = combinedCashflows(state, f.key);
        return { key: f.key, label: f.label, ...r, xirr: xirr(cf), irr: irrAnnualPct(state, f.key) };
    });
    const customRow = (() => {
        const r = effectiveRateForFreq(state, "custom");
        const cf = combinedCashflows(state, "custom");
        const tail = customTail;
        return { key: "custom", label: `Custom · last ${tail}m`, ...r, xirr: xirr(cf), irr: irrAnnualPct(state, "custom") };
    })();
    const perFreq = chosenFreq === "custom" ? [...basePerFreq, customRow] : basePerFreq;
    const chosen = chosenFreq === "custom" ? customRow : basePerFreq.find((r) => r.key === chosenFreq);
    // XIRR is inspectable under any MSER principal-repayment structure.
    const [xirrFreq, setXirrFreq] = useState(chosenFreq);
    // Follow the dashboard's selected repayment schedule; users can still override via the toggle below.
    useEffect(() => { setXirrFreq(chosenFreq); }, [chosenFreq]);
    const cf = combinedCashflows(state, xirrFreq);
    const irr = xirr(cf);
    const monthlyCf = combinedMonthlyCashflows(state, xirrFreq);
    const irrMonthly = irrPeriodic(monthlyCf);
    const irrAnn = isFinite(irrMonthly) ? (Math.pow(1 + irrMonthly, 12) - 1) * 100 : NaN;
    const xirrFreqBase = FREQUENCIES.find((f) => f.key === xirrFreq)?.label ?? xirrFreq;
    const xirrFreqLabel = xirrFreq === "custom" ? `Custom · last ${customTail}m` : xirrFreqBase;
    const mserSched = schemeSchedule(state.mser, mserAmt, xirrFreq, state.customTailMonths);
    const rmseSched = schemeSchedule(state.rmse, rmseAmt, "bullet");
    const propMser = total > 0 ? (mserAmt / total) * 100 : 0;
    const propRmse = total > 0 ? (rmseAmt / total) * 100 : 0;
    // WAR intermediate step — chosen frequency
    const mserWtdPrin = chosen.denom - (rmseAmt * rYr); // approximation split
    // Better: compute exactly
    const rmseWtdPrin = rmseAmt * rYr; // bullet: opening constant → Σopen/12 = amt × yrs
    const mserWtdPrinExact = chosen.denom - rmseWtdPrin;
    return (_jsxs("div", {
        className: "space-y-4", children: [_jsxs(Card, { children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-success rounded" }), "WAR \u2014 Weighted Average Rate"] }), _jsx("div", { className: "pt-1 text-[11px] text-muted-foreground", children: "Total interest accrued over the loan life, divided by the weighted-principal (\u03A3 opening balance \u00F7 12)." })] }), _jsxs(CardContent, { className: "space-y-3", children: [_jsx("div", { className: "pt-2", children: _jsx(WarCashflowSchedule, { state: state, freq: chosenFreq, caption: `Step 1 · Monthly cash flows (${freqLabel}) — all tranches combined` }) }), _jsxs("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-2", children: ["Step 2 \u00B7 Chosen frequency (", freqLabel, ") \u2014 per-scheme breakdown"] }), _jsx("div", { className: "mx-4", children: _jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Scheme" }), _jsx(TableHead, { className: "text-right", children: "Amount (Cr)" }), _jsx(TableHead, { className: "text-right", children: "Rate" }), _jsx(TableHead, { className: "text-right", children: "Interest accrued (\u03A3 monthly)" }), _jsx(TableHead, { className: "text-right", children: "Weighted principal (\u03A3 open \u00F7 12)" })] }) }), _jsxs(TableBody, { children: [_jsxs(TableRow, { children: [_jsxs(TableCell, { children: ["MSER (", freqLabel, ")"] }), _jsx(TableCell, { className: "text-right tabular", children: mserAmt.toFixed(2) }), _jsxs(TableCell, { className: "text-right tabular", children: [state.mser.ratePct.toFixed(2), "%"] }), _jsx(TableCell, { className: "text-right tabular", children: chosen.mserInt.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular", children: mserWtdPrinExact.toFixed(2) })] }), _jsxs(TableRow, { children: [_jsx(TableCell, { children: "RMSE (Bullet)" }), _jsx(TableCell, { className: "text-right tabular", children: rmseAmt.toFixed(2) }), _jsxs(TableCell, { className: "text-right tabular", children: [state.rmse.ratePct.toFixed(2), "%"] }), _jsx(TableCell, { className: "text-right tabular", children: chosen.rmseInt.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular", children: rmseWtdPrin.toFixed(2) })] }), _jsxs(TableRow, { className: "border-t-2 bg-secondary/30", children: [_jsx(TableCell, { className: "font-semibold", colSpan: 3, children: "\u03A3 Total" }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: chosen.total.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: chosen.denom.toFixed(2) })] })] })] }) }), _jsxs("div", { className: "rounded-md bg-mds-success/10 p-4 space-y-2 mx-4 border border-mds-success/30", children: [_jsxs("div", { className: "font-mono text-[11px] text-mds-navy leading-relaxed space-y-1", children: [_jsx("div", { children: "WAR = ( \u03A3 Interest \u00F7 \u03A3 Weighted Principal ) \u00D7 100" }), _jsxs("div", { children: ["\u00A0\u00A0\u00A0= ( ", chosen.mserInt.toFixed(2), " + ", chosen.rmseInt.toFixed(2), " ) \u00F7 ( ", mserWtdPrinExact.toFixed(2), " + ", rmseWtdPrin.toFixed(2), " ) \u00D7 100"] }), _jsxs("div", { children: ["\u00A0\u00A0\u00A0= ", chosen.total.toFixed(2), " \u00F7 ", chosen.denom.toFixed(2), " \u00D7 100"] })] }), _jsxs("div", { className: "text-2xl font-bold tabular text-mds-success", children: ["= ", chosen.effective.toFixed(2), "%"] })] }), _jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-2", children: "All frequencies (sensitivity)" }), _jsx("div", { className: "mx-4 mb-4", children: _jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Principal Repmt." }), _jsx(TableHead, { className: "text-right", children: "MSER Interest" }), _jsx(TableHead, { className: "text-right", children: "RMSE Interest" }), _jsx(TableHead, { className: "text-right", children: "Total Interest" }), _jsx(TableHead, { className: "text-right", children: "\u00F7 Wtd. Principal" }), _jsx(TableHead, { className: "text-right", children: "WAR" }), _jsx(TableHead, { className: "text-right", children: "IRR (ann.)" }), _jsx(TableHead, { className: "text-right", children: "XIRR" })] }) }), _jsx(TableBody, { children: perFreq.map((r) => (_jsxs(TableRow, { className: r.key === chosenFreq ? "bg-mds-blue/5" : "", children: [_jsx(TableCell, { className: "font-medium", children: r.label }), _jsx(TableCell, { className: "text-right tabular", children: r.mserInt.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular", children: r.rmseInt.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: r.total.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular text-muted-foreground", children: r.denom.toFixed(2) }), _jsxs(TableCell, { className: "text-right tabular font-bold text-mds-success", children: [r.effective.toFixed(2), "%"] }), _jsx(TableCell, { className: "text-right tabular font-semibold text-mds-navy", children: isFinite(r.irr) ? `${r.irr.toFixed(2)}%` : "—" }), _jsxs(TableCell, { className: "text-right tabular font-semibold text-mds-blue", children: [r.xirr.toFixed(2), "%"] })] }, r.key))) })] }) }), _jsxs("div", { className: "text-[10px] text-muted-foreground px-4 pb-3", children: ["Row highlighted in blue = currently selected principal-repayment frequency (", freqLabel, ")."] })] })] }), (() => {
            const w = effectiveRateWindow(state, chosenFreq, 12);
            const state12 = withTenureMonths(state, 12);
            return (_jsxs(Card, {
                children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-success rounded" }), "WAR (12 month)"] }), _jsx("div", { className: "pt-1 text-[11px] text-muted-foreground", children: "The same deal structure (amounts, mix, rates, repayment frequency) re-cut with a 12-month tenor on every tranche, then priced with the same WAR formula: \u03A3 interest \u00F7 weighted principal." })] }), _jsxs(CardContent, {
                    className: "space-y-3", children: [_jsx("div", { className: "pt-2", children: _jsx(WarCashflowSchedule, { state: state12, freq: chosenFreq, caption: `Step 1 · Updated monthly cash flows (${freqLabel}) — every tranche re-cut to 12 months` }) }), _jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-2", children: "Step 2 \u00B7 Per-tranche breakdown" }), _jsx("div", { className: "mx-4", children: _jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsxs(TableHead, { children: ["Tranche (", freqLabel, ") \u00B7 12-month tenor"] }), _jsx(TableHead, { className: "text-right", children: "Amount" }), _jsx(TableHead, { className: "text-right", children: "Rate" }), _jsx(TableHead, { className: "text-right", children: "Interest" }), _jsx(TableHead, { className: "text-right", children: "Wtd. principal (Cr-yrs)" })] }) }), _jsxs(TableBody, { children: [w.legs.map((l) => (_jsxs(TableRow, { children: [_jsx(TableCell, { className: "font-medium", children: l.leg.label }), _jsxs(TableCell, { className: "text-right tabular", children: [l.leg.amountCr.toFixed(2), " Cr"] }), _jsxs(TableCell, { className: "text-right tabular", children: [l.leg.scheme_.ratePct.toFixed(2), "%"] }), _jsxs(TableCell, { className: "text-right tabular", children: [l.interest.toFixed(2), " Cr"] }), _jsx(TableCell, { className: "text-right tabular", children: l.weightedPrincipal.toFixed(2) })] }, l.leg.id))), _jsxs(TableRow, { className: "border-t-2 bg-secondary/30", children: [_jsx(TableCell, { className: "font-semibold", children: "Total" }), _jsx(TableCell, {}), _jsx(TableCell, {}), _jsxs(TableCell, { className: "text-right tabular font-semibold", children: [w.interest.toFixed(2), " Cr"] }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: w.weightedPrincipal.toFixed(2) })] })] })] }) }), _jsxs("div", { className: "rounded-md bg-mds-success/10 p-4 space-y-2 mx-4 border border-mds-success/30", children: [_jsxs("div", { className: "font-mono text-[11px] text-mds-navy leading-relaxed space-y-1", children: [_jsx("div", { children: "Every tranche tenor set to 12 months (moratorium clamped to \u2264 11m)" }), _jsxs("div", { children: ["WAR (12 month) = \u03A3 Interest \u00F7 \u03A3 Weighted principal = ", w.interest.toFixed(2), " \u00F7 ", w.weightedPrincipal.toFixed(2)] })] }), _jsxs("div", { className: "text-2xl font-bold tabular text-mds-success", children: ["= ", w.effective.toFixed(2), "%"] }), _jsxs("div", { className: "text-[10px] text-muted-foreground", children: ["Full-life WAR ", chosen.effective.toFixed(2), "% \u00B7 difference ", (w.effective - chosen.effective).toFixed(2), " pp"] })] }), _jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-1", children: "All frequencies" }), _jsx("div", {
                        className: "mx-4 mb-4", children: _jsxs(Table, {
                            className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Principal Repmt." }), _jsx(TableHead, { className: "text-right", children: "Interest (12m tenor)" }), _jsx(TableHead, { className: "text-right", children: "WAR (full life)" }), _jsx(TableHead, { className: "text-right", children: "WAR (12 month)" })] }) }), _jsx(TableBody, {
                                children: perFreq.map((r) => {
                                    const wf = effectiveRateWindow(state, r.key, 12);
                                    return (_jsxs(TableRow, { className: r.key === chosenFreq ? "bg-mds-blue/5" : "", children: [_jsx(TableCell, { className: "font-medium", children: r.label }), _jsxs(TableCell, { className: "text-right tabular", children: [wf.interest.toFixed(2), " Cr"] }), _jsxs(TableCell, { className: "text-right tabular", children: [r.effective.toFixed(2), "%"] }), _jsxs(TableCell, { className: "text-right tabular font-bold text-mds-success", children: [wf.effective.toFixed(2), "%"] })] }, r.key));
                                })
                            })]
                        })
                    })]
                })]
            }));
        })(), _jsxs(Card, {
            children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-blue rounded" }), "XIRR \u2014 Dated Cashflow IRR"] }), _jsx("div", { className: "pt-1 text-[11px] text-muted-foreground", children: "Toggle the MSER principal-repayment structure to see how the dated cashflow schedule and XIRR shift. RMSE always pays bullet." })] }), _jsxs(CardContent, {
                className: "space-y-3", children: [_jsxs("div", {
                    className: "px-4 pt-2 space-y-1.5", children: [_jsx("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground font-semibold", children: "MSER Repayment Structure \u2014 click to recompute XIRR" }), _jsx(ToggleGroup, {
                        type: "single", value: xirrFreq, onValueChange: (v) => v && setXirrFreq(v), className: "justify-start flex-wrap gap-1", children: FREQUENCIES.map((f) => {
                            const tail = state.customTailMonths ?? 3;
                            const label = f.key === "custom" ? `Custom · last ${tail}m` : f.label;
                            return (_jsx(ToggleGroupItem, { value: f.key, className: "text-xs border border-border bg-background hover:bg-mds-blue/5 hover:border-mds-blue/40 data-[state=on]:bg-mds-blue data-[state=on]:text-white data-[state=on]:border-mds-blue cursor-pointer transition-colors", children: label }, f.key));
                        })
                    })]
                }), _jsx("div", { className: "rounded-md border border-border p-3 space-y-2 mx-4", children: _jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px]", children: [_jsxs("div", { children: [_jsx("div", { className: "text-muted-foreground", children: "Initial outflow (t=0)" }), _jsxs("div", { className: "tabular font-semibold text-mds-danger", children: ["\u2212", state.principalCr.toFixed(2), " Cr"] })] }), _jsxs("div", { children: [_jsx("div", { className: "text-muted-foreground", children: "MSER structure" }), _jsxs("div", { className: "tabular font-semibold", children: [state.mser.tenureMonths, " mo \u00B7 ", xirrFreqLabel] })] }), _jsxs("div", { children: [_jsx("div", { className: "text-muted-foreground", children: "RMSE structure" }), _jsxs("div", { className: "tabular font-semibold", children: [state.rmse.tenureMonths, " mo \u00B7 Bullet"] })] }), _jsxs("div", { children: [_jsx("div", { className: "text-muted-foreground", children: "# cashflows" }), _jsx("div", { className: "tabular font-semibold", children: cf.length })] })] }) }), _jsxs("div", { className: "rounded-md bg-secondary/40 p-3 font-mono text-[11px] leading-relaxed text-mds-navy mx-4", children: ["XIRR(values, dates) \u2192 solve\u00A00 = \u03A3 CF", _jsx("sub", { children: "i" }), " / (1 + r)", _jsxs("sup", { children: ["(date", _jsx("sub", { children: "i" }), " \u2212 date", _jsx("sub", { children: "0" }), ") / 365"] }), ",\u00A0\u00A0date", _jsx("sub", { children: "0" }), " = today"] }), _jsxs("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground px-4", children: ["Cashflow schedule (", xirrFreqLabel, ") \u2014 dated from today"] }), _jsx("div", { className: "rounded-md border border-border max-h-72 overflow-auto mx-4", children: _jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "#" }), _jsx(TableHead, { children: "Date" }), _jsx(TableHead, { className: "text-right", children: "Months from t\u2080" }), _jsx(TableHead, { className: "text-right", children: "Year frac" }), _jsx(TableHead, { className: "text-right", children: "Cash flow (Cr)" }), _jsxs(TableHead, { className: "text-right", children: ["PV @ ", irr.toFixed(2), "%"] })] }) }), _jsx(TableBody, { children: cf.map((f, i) => (_jsxs(TableRow, { children: [_jsx(TableCell, { className: "tabular", children: i }), _jsx(TableCell, { className: "tabular", children: f.date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) }), _jsx(TableCell, { className: "text-right tabular", children: Math.round(f.t * 12) }), _jsx(TableCell, { className: "text-right tabular", children: f.t.toFixed(2) }), _jsx(TableCell, { className: cn("text-right tabular", f.cf < 0 ? "text-mds-danger" : "text-mds-navy"), children: f.cf.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular text-muted-foreground", children: (f.cf / Math.pow(1 + irr / 100, f.t)).toFixed(2) })] }, i))) })] }) }), _jsxs("div", { className: "rounded-md bg-mds-blue/10 p-3 space-y-1 mx-4 mb-4", children: [_jsx("div", { className: "font-mono text-[11px] text-mds-navy", children: "Newton-Raphson converged (\u03A3 PV \u2248 0)" }), _jsxs("div", { className: "text-2xl font-bold tabular text-mds-blue", children: ["XIRR (", xirrFreqLabel, ") = ", isFinite(irr) ? `${irr.toFixed(2)}%` : "—"] })] })]
            })]
        }), _jsxs(Card, { children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-navy rounded" }), "IRR \u2014 ANNUALISED"] }), _jsxs("div", { className: "pt-1 text-[11px] text-muted-foreground", children: ["Classic Excel IRR on equally-spaced monthly cashflows for the currently toggled MSER structure (", _jsx("span", { className: "font-semibold", children: xirrFreqLabel }), "). Solves for the monthly rate ", _jsxs("em", { children: ["r", _jsx("sub", { children: "m" })] }), ", then annualises as (1 + r", _jsx("sub", { children: "m" }), ")", _jsx("sup", { children: "12" }), " \u2212 1. Ignores exact calendar days (unlike XIRR above)."] })] }), _jsxs(CardContent, { className: "space-y-3", children: [_jsxs("div", { className: "rounded-md bg-secondary/40 p-3 font-mono text-[11px] leading-relaxed text-mds-navy mx-4", children: ["IRR: solve\u00A00 = \u03A3 CF", _jsx("sub", { children: "t" }), " / (1 + r", _jsx("sub", { children: "m" }), ")", _jsx("sup", { children: "t" }), ",\u00A0\u00A0t = 0, 1, \u2026, N months\u00A0\u00A0\u2192\u00A0\u00A0 IRR", _jsx("sub", { children: "annual" }), " = (1 + r", _jsx("sub", { children: "m" }), ")", _jsx("sup", { children: "12" }), " \u2212 1"] }), _jsxs("div", { className: "text-[10px] uppercase tracking-wider text-muted-foreground px-4", children: ["Monthly cashflow vector (", xirrFreqLabel, ") \u2014 ", monthlyCf.length, " periods"] }), _jsx("div", { className: "rounded-md border border-border max-h-72 overflow-auto mx-4", children: _jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Month (t)" }), _jsx(TableHead, { className: "text-right", children: "Cash flow (Cr)" }), _jsxs(TableHead, { className: "text-right", children: ["PV @ ", isFinite(irrMonthly) ? `${(irrMonthly * 100).toFixed(4)}%/mo` : "—"] })] }) }), _jsx(TableBody, { children: monthlyCf.map((c, t) => (_jsxs(TableRow, { children: [_jsx(TableCell, { className: "tabular", children: t }), _jsx(TableCell, { className: cn("text-right tabular", c < 0 ? "text-mds-danger" : c > 0 ? "text-mds-navy" : "text-muted-foreground"), children: c.toFixed(4) }), _jsx(TableCell, { className: "text-right tabular text-muted-foreground", children: isFinite(irrMonthly) ? (c / Math.pow(1 + irrMonthly, t)).toFixed(4) : "—" })] }, t))) })] }) }), _jsxs("div", { className: "rounded-md bg-mds-navy/5 p-3 space-y-1 mx-4 mb-4 border border-mds-navy/10", children: [_jsxs("div", { className: "font-mono text-[11px] text-mds-navy", children: ["Monthly r", _jsx("sub", { children: "m" }), " = ", isFinite(irrMonthly) ? `${(irrMonthly * 100).toFixed(4)}%` : "—", "\u00A0\u2192\u00A0(1 + r", _jsx("sub", { children: "m" }), ")", _jsx("sup", { children: "12" }), " \u2212 1"] }), _jsxs("div", { className: "text-2xl font-bold tabular text-mds-navy", children: ["IRR (", xirrFreqLabel, ") = ", isFinite(irrAnn) ? `${irrAnn.toFixed(2)}%` : "—"] })] })] })] }), _jsxs(Card, {
            children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: "w-1 h-4 bg-mds-navy rounded" }), "Cashflow Structure"] }), _jsxs("div", { className: "pt-1 text-[11px] text-muted-foreground", children: [legSchedules(state, xirrFreq).map((l, i) => (_jsxs("span", { children: [i > 0 && _jsx("span", { className: "mx-2", children: "+" }), _jsxs("span", { className: `font-semibold ${l.leg.scheme === "mser" ? "text-mds-blue" : "text-mds-success"}`, children: [l.leg.label, " \u00B7 ", FREQUENCIES.find((f) => f.key === l.leg.freq)?.label] })] }, l.leg.id))), _jsx("span", { className: "mx-2", children: "\u00B7" }), "Interest paid ", _jsx("span", { className: "tabular font-semibold text-mds-navy", children: "monthly (all legs)" })] })] }), _jsx(CardContent, {
                children: _jsx("div", {
                    className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: legSchedules(state, xirrFreq).map((l) => {
                        const isMser = l.leg.scheme === "mser";
                        const legFreqLabel = FREQUENCIES.find((f) => f.key === l.leg.freq)?.label ?? "";
                        return (_jsxs(Card, { children: [_jsxs(CardHeader, { className: "pb-3", children: [_jsxs(CardTitle, { className: "text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2", children: [_jsx("span", { className: `w-1 h-4 rounded ${isMser ? "bg-mds-blue" : "bg-mds-success"}` }), l.leg.label, " \u2014 ", legFreqLabel, l.leg.basis && (_jsxs("span", { className: "text-[10px] normal-case tracking-normal text-muted-foreground", children: ["(", l.leg.basis, ")"] }))] }), _jsxs("div", { className: "pt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] text-muted-foreground", children: [_jsxs("div", { children: ["Loan Amt ", _jsx("span", { className: "tabular text-mds-navy font-medium", children: l.leg.amountCr.toFixed(2) })] }), _jsxs("div", { children: ["Int p.a. ", _jsxs("span", { className: "tabular text-mds-navy font-medium", children: [l.leg.scheme_.ratePct.toFixed(2), "%"] })] }), _jsxs("div", { children: ["Int/month ", _jsxs("span", { className: "tabular text-mds-navy font-medium", children: [(l.leg.scheme_.ratePct / 12).toFixed(2), "%"] })] }), _jsxs("div", { children: ["Tenure (months) ", _jsx("span", { className: "tabular text-mds-navy font-medium", children: Math.round(l.leg.scheme_.tenureMonths) })] })] })] }), _jsx(CardContent, { className: "p-0 max-h-[440px] overflow-auto border-t", children: _jsxs(Table, { className: "text-xs", children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "Period" }), _jsx(TableHead, { className: "text-right", children: "Opening Bal" }), _jsx(TableHead, { className: "text-right", children: "Interest paid" }), _jsx(TableHead, { className: "text-right", children: "Principal Paid" }), _jsx(TableHead, { className: "text-right", children: "Balance" })] }) }), _jsxs(TableBody, { children: [l.rows.map((m, i) => (_jsxs(TableRow, { children: [_jsx(TableCell, { className: "tabular", children: i + 1 }), _jsx(TableCell, { className: "text-right tabular", children: m.opening.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular", children: m.interest.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular", children: m.principal.toFixed(2) }), _jsx(TableCell, { className: "text-right tabular", children: m.closing.toFixed(2) })] }, i))), _jsxs(TableRow, { className: "bg-secondary/40 border-t-2", children: [_jsx(TableCell, { className: "font-semibold", children: "Total" }), _jsx(TableCell, {}), _jsx(TableCell, { className: "text-right tabular font-semibold", children: l.rows.reduce((s, x) => s + x.interest, 0).toFixed(2) }), _jsx(TableCell, { className: "text-right tabular font-semibold", children: l.rows.reduce((s, x) => s + x.principal, 0).toFixed(2) }), _jsx(TableCell, {})] })] })] }) })] }, l.leg.id));
                    })
                })
            })]
        })]
    }));
}
