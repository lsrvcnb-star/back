import { useEffect } from "react";
import NegotiationDashboard from "negotiation-runtime/NegotiationDashboard";
import "assets/css/negotiation.css";

export default function NegotiationTool() {
  // Radix popups portal into document.body, outside .ifv-negotiation-tool.
  // Expose the design tokens on <body> for exactly as long as this tool is
  // mounted, so dropdowns/popovers/dialogs are not transparent, and so nothing
  // leaks onto other IFV pages after navigating away.
  useEffect(() => {
    document.body.classList.add("neg-portal-scope");
    return () => document.body.classList.remove("neg-portal-scope");
  }, []);

  return (
    <div className="ifv-negotiation-tool">
      <NegotiationDashboard />
    </div>
  );
}
