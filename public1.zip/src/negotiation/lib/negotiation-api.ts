/**
 * Negotiation endpoints (/api/public/market, /api/public/counterparty) are served
 * by the Spring Boot backend, so they default to the same origin as every other
 * IFV API. REACT_APP_NEGOTIATION_API_ENDPOINT is kept only as an override for
 * pointing at a separately deployed negotiation service.
 */
export function negotiationApiBase(): string {
  const base =
    process.env.REACT_APP_NEGOTIATION_API_ENDPOINT ||
    process.env.REACT_APP_API_ENDPOINT ||
    "";
  return base.replace(/\/$/, "");
}
