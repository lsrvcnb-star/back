import { createFileRoute } from "@tanstack/react-router";
import { latestTenor, validRate, tenorHistory, tenorCurve } from "@/lib/market-validation";
import { fetchGsecHistory, yearQuery } from "@/lib/fbil-history";
import { policyHistory } from "@/lib/policy-history";

// -----------------------------------------------------------------------------
// /api/public/market
// Server-only endpoint that scrapes official rate sources and returns a
// unified snapshot. Cached per-Worker-instance for 30 minutes.
//
// Sources (all official):
//   • RBI homepage (rbi.org.in) — Policy Repo, Reverse Repo, SDF, MSF, Bank Rate
//   • FBIL (fbil.org.in) public JSON APIs — T-Bill (3M), CD (12M) benchmark rates
//   • FBIL Par Yield sheet — 10-year G-Sec par yield (XLSX parsed server-side)
//
// CP is an issuer-activity category, not a benchmark.
// -----------------------------------------------------------------------------

interface RatePoint { value: number | null; source: string | null; asOf?: string | null; sourceUrl?: string | null; }
interface Snapshot {
  fetchedAt: string;
  repo: RatePoint; reverseRepo: RatePoint; sdf: RatePoint; msf: RatePoint;
  bankRate: RatePoint; gsec10: RatePoint; tbill3m: RatePoint;
  cd1y: RatePoint;
  notes: string[];
  history: Record<string, { month: string; value: number }[]>;
  curves: Record<string, { tenor: string; months: number; value: number }[]>;
}

// per-Worker-instance cache
let cache: { at: number; data: Snapshot } | null = null;
const TTL_MS = 30 * 60 * 1000;

const UA = "Mozilla/5.0 (compatible; SIDBIPricingDashboard/1.0)";
const nullPoint = (): RatePoint => ({ value: null, source: null });

async function scrapeRbi(): Promise<Partial<Snapshot>> {
  const res = await fetch("https://www.rbi.org.in/", {
    headers: { "User-Agent": UA, "Accept": "text/html,application/xhtml+xml" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`RBI ${res.status}`);
  const html = (await res.text()).replace(/<[^>]*>/g, " ").replace(/&nbsp;|&#160;/g, " ").replace(/\s+/g, " ");
  const gsDate = html.match(/#\s*as on\s+([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i)?.[1] ?? null;

  const grab = (label: string): RatePoint => {
    const re = new RegExp(label.replace(/ /g, "\\s+") + "[\\s\\S]{0,300}?([0-9]+\\.[0-9]+)\\s*%");
    const m = html.match(re);
    return m ? { value: parseFloat(m[1]), source: "RBI", sourceUrl: "https://www.rbi.org.in/", asOf: null } : nullPoint();
  };

  // Government Securities Market table on rbi.org.in — pick the bond whose
  // maturity year is nearest to today + 10 years for the "10Y G-Sec" proxy.
  let gsec10: RatePoint = nullPoint();
  const gsMatches = [...html.matchAll(/([0-9]+\.[0-9]+)%\s*GS\s*(\d{4})[\s\S]{0,120}?:\s*([0-9]+\.[0-9]+)\s*%/g)];
  if (gsMatches.length > 0) {
    const targetYear = new Date().getFullYear() + 10;
    let best: { year: number; ytm: number } | null = null;
    for (const m of gsMatches) {
      const year = parseInt(m[2], 10);
      const ytm = parseFloat(m[3]);
      if (!best || Math.abs(year - targetYear) < Math.abs(best.year - targetYear)) {
        best = { year, ytm };
      }
    }
    if (best) gsec10 = { value: best.ytm, source: `RBI (GS ${best.year})`, sourceUrl: "https://www.rbi.org.in/", asOf: gsDate };
  }

  // 91-day T-bill cut-off from the same GSM table.
  let tbill3m: RatePoint = nullPoint();
  const tbillM = html.match(/91\s*day\s*T-?bills[\s\S]{0,400}?([0-9]+\.[0-9]+)\s*%/i);
  if (tbillM) tbill3m = { value: parseFloat(tbillM[1]), source: "RBI (91-day T-Bill cut-off)", sourceUrl: "https://www.rbi.org.in/", asOf: null };


  return {
    repo:        grab("Policy Repo Rate"),
    reverseRepo: grab("Reverse Repo Rate"),
    sdf:         grab("Standing Deposit"),
    msf:         grab("Marginal Standing"),
    bankRate:    grab("Bank Rate"),
    gsec10,
    tbill3m,
  };
}


interface FbilTenorRow { tenorName: string; rate: number; processRunDate: string; }

async function fetchFbilTenorRates(kind: "tbill" | "cd"): Promise<FbilTenorRow[] | null> {
  const res = await fetch(`https://www.fbil.org.in/wasdm/${kind}/fetchfiltered?${yearQuery()}`, {
    headers: { "User-Agent": UA, "Accept": "application/json" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) return null;
  const j = await res.json() as FbilTenorRow[];
  return Array.isArray(j) ? j : null;
}

function pickTenor(rows: FbilTenorRow[] | null, tenor: string): RatePoint {
  if (!rows) return nullPoint();
  const picked = latestTenor(rows, tenor);
  return { ...picked, source: picked.value !== null ? "FBIL" : null, sourceUrl: "https://www.fbil.org.in/" };
}

async function buildSnapshot(): Promise<Snapshot> {
  const snap: Snapshot = {
    fetchedAt: new Date().toISOString(),
    repo: nullPoint(), reverseRepo: nullPoint(), sdf: nullPoint(), msf: nullPoint(),
    bankRate: nullPoint(), gsec10: nullPoint(), tbill3m: nullPoint(),
    cd1y: nullPoint(),
    notes: [], history: {}, curves: {},
  };

  const [rbi, tbillRows, cdRows, gsec10] = await Promise.allSettled([
    scrapeRbi(),
    fetchFbilTenorRates("tbill"),
    fetchFbilTenorRates("cd"),
    fetchGsecHistory(),
  ]);

  if (rbi.status === "fulfilled") {
    Object.assign(snap, rbi.value);
    snap.notes.push("Policy rates: rbi.org.in (official).");
  } else {
    snap.notes.push(`RBI fetch failed: ${(rbi.reason as Error).message}`);
  }

  // Use the FBIL daily tenor benchmark for T-Bill, not the weekly auction cut-off.
  if (tbillRows.status === "fulfilled" && tbillRows.value) {
    const point = pickTenor(tbillRows.value, "3 Months");
    if (point.value !== null) snap.tbill3m = point;
    snap.notes.push("T-Bill 3M: FBIL daily tenor benchmark; RBI auction cut-off only if unavailable.");
  }
  if (cdRows.status === "fulfilled") {
    snap.cd1y = pickTenor(cdRows.value, "12 Months");
    if (snap.cd1y.value !== null) snap.notes.push("CD 1Y: FBIL (fbil.org.in).");
  }
  // Keep the latest value and historical chart on the same constant-tenor definition.
  const gsecPoints = gsec10.status === "fulfilled" ? gsec10.value : [];
  const latestGsec = gsecPoints.at(-1);
  snap.gsec10 = latestGsec ? { value: latestGsec.value, source: "FBIL (10Y par yield, annualized)", asOf: latestGsec.month, sourceUrl: "https://www.fbil.org.in/" } : nullPoint();


  for (const key of ["repo", "reverseRepo", "sdf", "msf", "bankRate", "gsec10", "tbill3m", "cd1y"] as const) {
    snap[key].value = validRate(snap[key].value);
    const point = snap[key];
    if (point.value !== null) {
      const parsed = point.asOf ? new Date(point.asOf) : null;
      const date = parsed && Number.isFinite(parsed.getTime()) ? parsed.toISOString().slice(0, 10) : snap.fetchedAt.slice(0, 10);
      snap.history[key] = [{ month: date, value: point.value }];
    }
  }
  if (cdRows.status === "fulfilled" && cdRows.value) {
    snap.history.cd1y = tenorHistory(cdRows.value, "12 Months");
    snap.curves.cd1y = tenorCurve(cdRows.value);
  }
  if (tbillRows.status === "fulfilled" && tbillRows.value) {
    snap.history.tbill3m = tenorHistory(tbillRows.value, "3 Months");
    snap.curves.tbill3m = tenorCurve(tbillRows.value);
  }
  snap.history.gsec10 = gsecPoints;
  for (const key of ["repo", "reverseRepo", "bankRate"] as const) {
    snap.history[key] = policyHistory(key);
    // Current homepage observation extends the effective-rate chart to today.
    if (snap[key].value !== null) snap.history[key].push({ month: snap.fetchedAt.slice(0, 10), value: snap[key].value });
  }
  return snap;
}

export const Route = createFileRoute("/api/public/market")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const forceFresh = url.searchParams.get("fresh") === "1";
        const now = Date.now();
        if (!forceFresh && cache && now - cache.at < TTL_MS) {
          return Response.json({ ...cache.data, cached: true }, {
            headers: { "Cache-Control": "no-store" },
          });
        }
        try {
          const data = await buildSnapshot();
          cache = { at: now, data };
          return Response.json({ ...data, cached: false }, {
            headers: { "Cache-Control": "no-store" },
          });
        } catch (e) {
          return Response.json(
            { error: (e as Error).message, fetchedAt: new Date().toISOString() },
            { status: 502 },
          );
        }
      },
    },
  },
});
