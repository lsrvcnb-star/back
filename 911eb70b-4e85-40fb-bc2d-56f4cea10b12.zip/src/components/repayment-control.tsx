import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuCheckboxItem, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronDown } from "lucide-react";
import { FREQUENCIES, type Frequency } from "@/lib/pricing";
import { repaymentMonths } from "@/lib/repayment";

export function RepaymentControl({ label, frequency, months, tenure, moratorium = 0, tail, onFrequency, onMonths }: {
  label: string; frequency: Frequency; months?: number[]; tenure: number; moratorium?: number; tail?: number;
  onFrequency: (value: Frequency) => void; onMonths: (value: number[]) => void;
}) {
  const selected = repaymentMonths(tenure, "custom", months, moratorium, tail);
  return <div className="min-w-0 grid grid-cols-2 gap-1.5">
    <Select value={frequency} onValueChange={value => onFrequency(value as Frequency)}>
      <SelectTrigger aria-label={label} className={`h-9 min-w-0 w-full text-sm bg-background ${frequency === "custom" ? "" : "col-span-2"}`}><SelectValue /></SelectTrigger>
      <SelectContent>{FREQUENCIES.map(f => <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>)}</SelectContent>
    </Select>
    {frequency === "custom" && <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" aria-label={`${label} months`} className="h-9 min-w-0 w-full justify-between gap-1 px-2 text-xs font-normal">
          <span className="min-w-0 truncate text-left">Select months</span><ChevronDown className="h-3.5 w-3.5 shrink-0" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="max-h-64 overflow-y-auto" align="start" aria-label={`${label} months`}>
        <DropdownMenuLabel className="text-xs">Select repayment months</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {Array.from({ length: Math.max(1, Math.round(tenure)) }, (_, i) => i + 1).map(month => <DropdownMenuCheckboxItem
          key={month} checked={selected.includes(month)} disabled={month <= moratorium || (selected.length === 1 && selected.includes(month))}
          className="tabular [&>span]:rounded-sm [&>span]:border [&>span]:border-input"
          title={month <= moratorium ? "Principal moratorium" : undefined}
          onSelect={event => event.preventDefault()}
          onCheckedChange={checked => onMonths((checked ? [...selected, month] : selected.filter(m => m !== month)).sort((a, b) => a - b))}
        >{month}</DropdownMenuCheckboxItem>)}
      </DropdownMenuContent>
    </DropdownMenu>}
    {frequency === "custom" && <div className="col-span-2 text-xs leading-4 text-muted-foreground break-words"><span>Selected months: </span><span className="tabular">{selected.join(", ")}</span></div>}
  </div>;
}