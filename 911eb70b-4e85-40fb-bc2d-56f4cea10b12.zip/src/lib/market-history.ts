// Instrument descriptions only. Observations and dates must come from the live source.
export interface TrendPoint { month: string; value: number; sourceUrl?: string; effectiveSince?: string; }
export interface CurvePoint { tenor: string; months: number; value: number; }

export interface MarketInstrument {
  key: string;
  name: string;
  short: string;         // heading on the tile
  latest: number | null;        // % p.a.
  asOf: string;          // human date
  source: string;        // RBI / FBIL / CCIL / Bloomberg
  sourceUrl: string;
  category: "policy" | "benchmark" | "money-market";
  what: string;
  implication: string;
  trend: TrendPoint[];
  curve?: CurvePoint[];
  ratingCurves?: { rating: string; points: CurvePoint[] }[];
}

export const MARKET_INSTRUMENTS: MarketInstrument[] = [
  // ============ POLICY (RBI, live homepage) ============
  {
    key: "repo",
    name: "Policy Repo Rate",
    short: "Repo",
    latest: null, asOf: "Not available",
    source: "RBI", sourceUrl: "https://www.rbi.org.in/",
    category: "policy",
    what: "Rate at which RBI lends overnight liquidity to scheduled commercial banks against government securities. The anchor rate for India's interest-rate corridor.",
    implication: "Directly floors bank funding costs. A 25 bps repo cut typically passes ~15–20 bps into bulk deposit and refinance rates within one quarter. SIDBI's MSER benchmark (Policy Repo) moves 1:1.",
    trend: [],
  },
  {
    key: "reverseRepo",
    name: "Fixed Reverse Repo Rate",
    short: "Reverse Repo",
    latest: null, asOf: "Not available",
    source: "RBI", sourceUrl: "https://www.rbi.org.in/",
    category: "policy",
    what: "Rate at which RBI absorbs overnight surplus liquidity from banks. Now largely symbolic since SDF replaced it as the effective lower bound.",
    implication: "Signals the absolute floor of interbank rates; if surplus liquidity persists, market rates gravitate down toward SDF.",
    trend: [],
  },
  {
    key: "bankRate",
    name: "Bank Rate",
    short: "Bank Rate",
    latest: null, asOf: "Not available",
    source: "RBI", sourceUrl: "https://www.rbi.org.in/",
    category: "policy",
    what: "Rate at which RBI provides longer-term credit to banks; kept aligned with MSF post-2012.",
    implication: "Reference for penal / late-payment interest under many RBI directives; not a direct pricing input for refinance.",
    trend: [],
  },

  // ============ G-SEC BENCHMARK ============
  {
    key: "gsec10",
    name: "10-Year G-Sec Par Yield (Annualized)",
    short: "10Y G-Sec",
    latest: null, asOf: "Not available",
    source: "FBIL", sourceUrl: "https://www.fbil.org.in/",
    category: "benchmark",
    what: "FBIL 10-year Government of India par yield, annualized column. A constant-tenor benchmark, distinct from the yield of one specific government bond.",
    implication: "Anchors term-premium expectations. A 25 bps move in 10Y G-Sec typically shifts 3–5Y AAA corporate & bank refinance rates by 10–20 bps within weeks.",
    trend: [],

  },

  // ============ MONEY-MARKET BENCHMARKS ============
  {
    key: "tbill3m",
    name: "Treasury Bill (3-Month)",
    short: "T-Bill 3M",
    latest: null, asOf: "Not available",
    source: "RBI Auctions / FBIL", sourceUrl: "https://www.rbi.org.in/",
    category: "money-market",
    what: "Short-term sovereign discount instruments issued by GoI in 91-day, 182-day and 364-day tenors. Yields set at weekly RBI auctions.",
    implication: "3M T-Bill is one of SIDBI's Treasury CoF options; short-term MSER pricing keys off this. Steepening between 3M and 1Y T-Bill signals rising forward-rate expectations.",
    trend: [],

  },
  {
    key: "cd1y",
    name: "Certificate of Deposit (1-Year)",
    short: "CD 1Y",
    latest: null, asOf: "Not available",
    source: "FBIL", sourceUrl: "https://www.fbil.org.in/",
    category: "money-market",
    what: "Unsecured negotiable money-market instrument issued by banks to raise wholesale short-term funds. FBIL publishes benchmark 3M/6M/1Y yields daily.",
    implication: "A direct read on bank marginal wholesale funding cost. CD 1Y typically trades 15–35 bps above policy repo + term-premium; sustained widening warns of tighter bank liquidity, tightening refinance quotes.",
    trend: [],

  },
];

export function findInstrument(key: string): MarketInstrument | undefined {
  return MARKET_INSTRUMENTS.find((m) => m.key === key);
}
