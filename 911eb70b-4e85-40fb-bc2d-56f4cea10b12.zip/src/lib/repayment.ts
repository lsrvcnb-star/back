export type RepaymentFrequency = "bullet" | "monthly" | "quarterly" | "halfyearly" | "annual" | "custom";

/** Months are relative to disbursement. Maturity settles any remaining balance. */
export function repaymentMonths(tenure: number, frequency: RepaymentFrequency, custom?: number[], moratorium = 0, legacyTail = 3): number[] {
  const n = Math.max(1, Math.round(tenure));
  const start = Math.max(0, Math.min(n - 1, Math.round(moratorium)));
  if (frequency === "bullet") return [n];
  if (frequency === "custom") {
    const requested = custom ?? Array.from({ length: Math.min(legacyTail, n - start) }, (_, i) => n - i);
    const valid = requested.filter(m => Number.isInteger(m) && m > start && m <= n);
    return [...new Set(valid.length ? valid : [n])].sort((a, b) => a - b);
  }
  const step = { monthly: 1, quarterly: 3, halfyearly: 6, annual: 12 }[frequency];
  const months = Array.from({ length: Math.floor((n - start) / step) }, (_, i) => start + (i + 1) * step);
  return months.includes(n) ? months : [...months, n];
}

export function repaymentLabel(frequency: RepaymentFrequency, months?: number[]): string {
  if (frequency === "custom" && months) return `Custom · months ${months.join(", ")}`;
  return { bullet: "Bullet", monthly: "Monthly", quarterly: "Quarterly", halfyearly: "Half-Yearly", annual: "Annual", custom: "Custom" }[frequency];
}