import { inPastYear } from "./market-validation";

// Official MPC statement observations; no inferred daily rate samples.
const POLICY_OBSERVATIONS = [
  { date: "2025-10-01", repo: 5.50, bankRate: 5.75, reverseRepo: 3.35, sourceUrl: "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=61332" },
  { date: "2025-12-05", repo: 5.25, bankRate: 5.50, reverseRepo: 3.35, sourceUrl: "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=61749" },
  { date: "2026-02-06", repo: 5.25, bankRate: 5.50, reverseRepo: 3.35, sourceUrl: "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=62169" },
  { date: "2026-04-08", repo: 5.25, bankRate: 5.50, reverseRepo: 3.35, sourceUrl: "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=62515" },
  { date: "2026-06-05", repo: 5.25, bankRate: 5.50, reverseRepo: 3.35, sourceUrl: "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=62864" },
  { date: "2026-08-05", repo: 5.25, bankRate: 5.50, reverseRepo: 3.35, sourceUrl: "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=63288" },
  { date: "2026-10-07", repo: 5.50, bankRate: 5.75, reverseRepo: 3.35, sourceUrl: "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=63742" },
];

export function policyHistory(key: "repo" | "bankRate" | "reverseRepo", now = new Date()) {
  const start = new Date(now); start.setUTCFullYear(start.getUTCFullYear() - 1);
  const boundary = start.toISOString().slice(0, 10);
  const prior = POLICY_OBSERVATIONS.filter(r => r.date < boundary).at(-1);
  const rows = POLICY_OBSERVATIONS.filter(r => inPastYear(r.date, now));
  return [
    ...(prior ? [{ month: boundary, value: prior[key], sourceUrl: prior.sourceUrl, effectiveSince: prior.date }] : []),
    ...rows.map(r => ({ month: r.date, value: r[key], sourceUrl: r.sourceUrl })),
  ];
}