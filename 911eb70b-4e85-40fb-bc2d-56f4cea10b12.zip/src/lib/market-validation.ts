/** Validate source observations without substituting stale or fabricated values. */
export function validRate(value: unknown): number | null {
  if (typeof value !== 'number' && typeof value !== 'string') return null;
  if (typeof value === 'string' && !value.trim()) return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 && n <= 30 ? n : null;
}
export function latestTenor(rows: Array<{ tenorName: string; rate: number; processRunDate: string }>, tenor: string) {
  const dates = rows.map(r => r.processRunDate?.slice(0, 10)).filter(d => /^\d{4}-\d{2}-\d{2}$/.test(d) && d <= new Date().toISOString().slice(0, 10)).sort();
  const asOf = dates.at(-1);
  const row = rows.find(r => r.processRunDate?.slice(0, 10) === asOf && r.tenorName?.trim().toLowerCase() === tenor.toLowerCase());
  return { value: validRate(row?.rate), asOf: asOf ?? null };
}
export function externalSourceUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  try { const parsed = new URL(url); return parsed.protocol === 'https:' ? parsed.href : null; } catch { return null; }
}
export function comparableBond(row: { market: string | null; status: string | null; coupon: string | null }): number | null {
  if (row.market !== 'Domestic' || !/^(Issued|Allotted|Raised|Closed)/i.test(row.status ?? '')) return null;
  const m = /^(\d+(?:\.\d+)?)\s*%$/.exec(row.coupon ?? '');
  return m ? validRate(m[1]) : null;
}
/** Calendar-year window, inclusive of today; no future activity. */
export function inPastYear(date: string, now = new Date()): boolean {
  const end = new Date(now); end.setUTCHours(23, 59, 59, 999);
  const start = new Date(now); start.setUTCFullYear(start.getUTCFullYear() - 1); start.setUTCHours(0, 0, 0, 0);
  const value = new Date(date).getTime();
  return Number.isFinite(value) && value >= start.getTime() && value <= end.getTime();
}
export function tenorHistory(rows: Array<{ tenorName: string; rate: number; processRunDate: string }>, tenor: string, now = new Date()) {
  const points = new Map<string, { month: string; value: number }>();
  for (const row of rows) {
    const date = row.processRunDate?.slice(0, 10);
    const value = validRate(row.rate);
    if (row.tenorName?.trim().toLowerCase() === tenor.toLowerCase() && inPastYear(date, now) && value !== null) points.set(date, { month: date, value });
  }
  return [...points.values()].sort((a, b) => a.month.localeCompare(b.month));
}

/** A term curve is one publication, never tenors stitched across different dates. */
export function tenorCurve(rows: Array<{ tenorName: string; rate: number; processRunDate: string }>, now = new Date()) {
  const dates = rows.map(r => r.processRunDate?.slice(0, 10)).filter(d => inPastYear(d, now)).sort();
  const latest = dates.at(-1);
  if (!latest) return [];
  const points = new Map<number, { tenor: string; months: number; value: number }>();
  for (const row of rows) {
    if (row.processRunDate?.slice(0, 10) !== latest) continue;
    const match = /^(\d+(?:\.\d+)?)\s*(months?|years?|days?)$/i.exec(row.tenorName?.trim());
    const value = validRate(row.rate);
    if (!match || value === null) continue;
    const months = Number(match[1]) * (/year/i.test(match[2]) ? 12 : /day/i.test(match[2]) ? 12 / 365 : 1);
    points.set(months, { tenor: row.tenorName, months, value });
  }
  return [...points.values()].sort((a, b) => a.months - b.months);
}
