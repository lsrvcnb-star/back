import * as XLSX from "xlsx";
import { inPastYear, validRate } from "./market-validation";

export function yearQuery(now = new Date()) {
  const from = new Date(now); from.setUTCFullYear(from.getUTCFullYear() - 1);
  return new URLSearchParams({ authenticated: "false", fromDate: from.toISOString().slice(0, 10), toDate: now.toISOString().slice(0, 10) });
}

/** Monthly publication samples plus the first observation; each is a real workbook. */
export function sampleArchiveDates(rows: Array<{ processRunDate: string }>, now = new Date()) {
  const dates = [...new Set(rows.map(r => r.processRunDate?.slice(0, 10)).filter(d => inPastYear(d, now)))].sort();
  const months = new Map<string, string>();
  for (const date of dates) months.set(date.slice(0, 7), date);
  return [...new Set([...(dates[0] ? [dates[0]] : []), ...months.values()])].sort();
}

export function parseParYield(buffer: Uint8Array) {
  const wb = XLSX.read(buffer, { type: "array" });
  const sheet = wb.Sheets["Par Yield"];
  if (!sheet) return null;
  const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: null });
  const row = rows.find(r => r[0] === 10);
  // Annualized column only: semi-annual rates are not interchangeable.
  return validRate(row?.[2]);
}

export async function fetchGsecHistory() {
  const response = await fetch(`https://www.fbil.org.in/wasdm/gsec/fetchfiltered?${yearQuery()}`, { signal: AbortSignal.timeout(15_000) });
  if (!response.ok) return [];
  const rows = await response.json() as Array<{ processRunDate: string }>;
  if (!Array.isArray(rows)) return [];
  const dates = sampleArchiveDates(rows).reverse();
  const points: { month: string; value: number }[] = [];
  // Bound workbook concurrency and memory usage in the hosted runtime.
  for (let i = 0; i < dates.length; i += 2) {
    await Promise.all(dates.slice(i, i + 2).map(async date => {
      try {
        const url = `https://www.fbil.org.in/wasdm/gsec/downloadPublished?authenticated=false&date=${date}`;
        let file = await fetch(url, { signal: AbortSignal.timeout(20_000) });
        if (!file.ok) file = await fetch(url, { signal: AbortSignal.timeout(20_000) });
        if (!file.ok) return;
        const value = parseParYield(new Uint8Array(await file.arrayBuffer()));
        if (value !== null) points.push({ month: date, value });
      } catch { /* Missing files remain missing observations. */ }
    }));
  }
  return points.sort((a, b) => a.month.localeCompare(b.month));
}