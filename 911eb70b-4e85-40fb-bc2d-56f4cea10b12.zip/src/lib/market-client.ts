// @refresh reset
// Remount consumers when this hook changes: preserving an older hook layout
// during a preview update can attach state to the wrong React hook queue.
import { useEffect, useState } from "react";
import type { TrendPoint, CurvePoint } from "./market-history";
import { EMPTY_MARKET, type MarketSnapshot } from "./pricing-data";

export interface MarketState {
  data: MarketSnapshot;
  history: Record<string, TrendPoint[]>;
  curves: Record<string, CurvePoint[]>;
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

type MarketValues = Omit<MarketState, "refresh"> & { tick: number };
const INITIAL_MARKET_STATE: MarketValues = {
  data: EMPTY_MARKET, history: {}, curves: {}, loading: true, error: null, tick: 0,
};

export function useMarket(): MarketState {
  // Keep one state hook: adding a feed field must not shift every subsequent
  // Dashboard hook during a code-split preview update.
  const [state, setState] = useState<MarketValues>(INITIAL_MARKET_STATE);
  const tick = state.tick;

  useEffect(() => {
    let cancelled = false;
    setState(previous => ({ ...previous, loading: true, error: null }));
    fetch(tick ? "/api/public/market?fresh=1" : "/api/public/market", { cache: "no-store" })
      .then(async (r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((j) => {
        if (cancelled) return;
        const data: MarketSnapshot = {
          fetchedAt: j.fetchedAt ?? null,
          repo:        j.repo        ?? { value: null, source: null },
          reverseRepo: j.reverseRepo ?? { value: null, source: null },
          sdf:         j.sdf         ?? { value: null, source: null },
          msf:         j.msf         ?? { value: null, source: null },
          bankRate:    j.bankRate    ?? { value: null, source: null },
          gsec10:      j.gsec10      ?? { value: null, source: null },
          tbill3m:     j.tbill3m     ?? { value: null, source: null },
          cd1y:        j.cd1y        ?? { value: null, source: null },
        };
        setState(previous => ({ ...previous, data, history: j.history ?? {}, curves: j.curves ?? {}, error: null }));
      })
      .catch((e) => {
        if (!cancelled) setState(previous => ({ ...previous, data: EMPTY_MARKET, history: {}, curves: {}, error: String(e.message ?? e) }));
      })
      .finally(() => { if (!cancelled) setState(previous => ({ ...previous, loading: false })); });
    return () => { cancelled = true; };
  }, [tick]);

  return { ...state, refresh: () => setState(previous => ({ ...previous, tick: previous.tick + 1 })) };
}
