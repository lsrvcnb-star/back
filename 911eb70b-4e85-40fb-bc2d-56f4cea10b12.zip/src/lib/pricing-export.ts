// Selected-deal export with shared terms and a separate 12-month calculation.
import * as XLSX from "xlsx";
import {
  type DealState,
  type Frequency,
  legSchedules,
  combinedCashflows,
  effectiveRateForFreq,
  irrAnnualPct,
  xirr,
  withTenureMonths,
} from "./pricing";
import { repaymentMonths, repaymentLabel } from "./repayment";
import type { BankProfile, MarketSnapshot } from "./pricing-data";

type Cell = XLSX.CellObject;
const numberFormat = '#,##0.00;(#,##0.00);"-"';
const num = (v: number): Cell =>
  Number.isFinite(v) ? { t: "n", v, z: numberFormat } : { t: "s", v: "—" };
const str = (v: string): Cell => ({ t: "s", v });
const formula = (f: string, v: number): Cell => ({ ...num(v), f });
const col = XLSX.utils.encode_col;
function put(ws: XLSX.WorkSheet, address: string, cell: Cell) {
  ws[address] = cell;
}
function section(ws: XLSX.WorkSheet, row: number, title: string, end = 16) {
  for (let c = 1; c <= end; c++)
    put(ws, `${col(c)}${row}`, { ...str(c === 1 ? title : ""), s: { exportRole: "title" } });
  (ws["!merges"] ??= []).push({ s: { r: row - 1, c: 1 }, e: { r: row - 1, c: end } });
  (ws["!rows"] ??= [])[row - 1] = { hpt: 26 };
}
function table(
  ws: XLSX.WorkSheet,
  header: number,
  last: number,
  firstCol: number,
  lastCol: number,
) {
  (ws["!exportTables"] ??= []).push({ header, last, firstCol, lastCol });
  for (let r = header; r <= last; r++)
    for (let c = firstCol; c <= lastCol; c++) {
      const address = `${col(c)}${r}`;
      const cell = ws[address] ?? str("");
      cell.s = { ...cell.s, exportRole: r === header ? "header" : "body" };
      ws[address] = cell;
    }
  ws["!rows"] ??= [];
  for (let r = header; r <= last; r++) ws["!rows"][r - 1] = { hpt: r === header ? 30 : 18 };
}
function emphasize(ws: XLSX.WorkSheet, row: number, first: number, last: number) {
  for (let c = first; c <= last; c++) {
    const cell = ws[`${col(c)}${row}`];
    if (cell) cell.s = { ...cell.s, exportRole: "total" };
  }
  (ws["!rows"] ??= [])[row - 1] = { hpt: 20 };
}
function setup(ws: XLSX.WorkSheet, last: number, end = 16) {
  ws["!ref"] = XLSX.utils.encode_range({ s: { c: 0, r: 0 }, e: { c: end, r: last - 1 } });
  ws["!cols"] = [
    { wch: 3 },
    ...Array.from({ length: end }, (_, i) => ({
      wch: i === 0 ? 42 : i === 3 || i === 4 ? 24 : 19,
    })),
  ];
}
function serial(date: Date) {
  return Math.round(
    (Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) - Date.UTC(1899, 11, 30)) /
      86400000,
  );
}
function anchor(serialDate: number) {
  const d = new Date(Date.UTC(1899, 11, 30) + serialDate * 86400000);
  return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}

function scheduleBlock(
  ws: XLSX.WorkSheet,
  state: DealState,
  freq: Frequency,
  dateSerial: number,
  offset: number,
  title: string,
  sharedTerms = false,
) {
  const schedules = legSchedules(state, freq);
  const n = Math.max(1, ...schedules.map((s) => s.rows.length));
  const termHeader = offset + 6;
  section(ws, offset + 1, title);
  const termHeaders = [
    "Split",
    "Amount (Rs Cr)",
    "Rate (% p.a.)",
    "Tenure (months)",
    "Principal repayment",
    "Interest repayment",
  ];
  if (!sharedTerms) termHeaders.forEach((h, i) => put(ws, `${col(i)}${termHeader}`, str(h)));
  schedules.forEach(({ leg }, i) => {
    const r = termHeader + 1 + i;
    [
      str(leg.label),
      num(leg.amountCr),
      num(leg.scheme_.ratePct),
      num(leg.scheme_.tenureMonths),
      str(repaymentLabel(leg.freq, leg.scheme_.principalMonths)),
      str(repaymentLabel(leg.scheme_.interestFreq ?? "monthly", leg.scheme_.interestMonths)),
    ].forEach((v, c) => { if (!sharedTerms) put(ws, `${col(c)}${r}`, v); });
  });
  if (!sharedTerms) table(ws, termHeader, termHeader + schedules.length, 0, 5);
  schedules.forEach((_, i) => {
    if (!sharedTerms) {
      ws[`C${termHeader + 1 + i}`].z = '0.00"%";(0.00"%");"-"';
      ws[`D${termHeader + 1 + i}`].z = '0;(0);"-"';
    }
  });
  const start = sharedTerms ? 15 : offset + Math.max(12, 8 + schedules.length);
  const headers = [
    "Month",
    "Opening MSER",
    "Interest paid MSER",
    "Principal MSER",
    "Closing MSER",
    "Cashflow MSER",
    "",
    "Opening RMSE",
    "Interest paid RMSE",
    "Principal RMSE",
    "Closing RMSE",
    "Cashflow RMSE",
    "Total cashflow",
    "Date",
    "XIRR date",
    "IRR / XIRR cashflow",
  ];
  headers.forEach((h, i) => put(ws, `${col(i + 1)}${start}`, str(h)));
  put(ws, `P${start + 1}`, { ...num(dateSerial), z: "yyyy-mm-dd" });
  const principal = schedules.reduce((sum, s) => sum + s.leg.amountCr, 0);
  put(
    ws,
    `Q${start + 1}`,
    formula(sharedTerms ? `-SUM('Display Sheet'!C13:C${12 + schedules.length})` : `-SUM(B${termHeader + 1}:B${termHeader + schedules.length})`, -principal),
  );
  const last = start + n,
    total = sharedTerms ? 4 : last + 3;
  const detailRefs: { scheme: string; start: number; last: number }[] = [];
  let detailRow = sharedTerms ? last + 4 : total + 10;
  for (const [i, { leg, rows }] of schedules.entries()) {
    section(ws, detailRow, `${leg.label} — monthly calculation`, 8);
    const h = detailRow + 1,
      t = termHeader + 1 + i;
    const amountRef = sharedTerms ? `'Display Sheet'!C${13 + i}` : `B${t}`;
    const rateRef = sharedTerms ? `'Display Sheet'!E${13 + i}` : `C${t}`;
    [
      "Month",
      "Opening (Rs Cr)",
      "Interest accrued",
      "Interest paid",
      "Principal paid",
      "Closing",
      "Unpaid interest",
      "Cashflow",
    ].forEach((v, c) => put(ws, `${col(c + 1)}${h}`, str(v)));
    const principalDates = repaymentMonths(
      rows.length,
      leg.freq,
      leg.scheme_.principalMonths,
      leg.scheme_.moratoriumMonths,
      leg.customTailMonths,
    );
    const interestDates = repaymentMonths(
      rows.length,
      leg.scheme_.interestFreq ?? "monthly",
      leg.scheme_.interestMonths,
      0,
      leg.customTailMonths,
    );
    const step =
      leg.freq === "quarterly" ? 3 : leg.freq === "halfyearly" ? 6 : leg.freq === "annual" ? 12 : 1;
    const instalments =
      leg.freq === "custom" || leg.freq === "bullet"
        ? principalDates.length
        : Math.max(
            1,
            Math.floor(
              (rows.length - Math.min(rows.length - 1, leg.scheme_.moratoriumMonths)) / step,
            ),
          );
    let unpaid = 0;
    rows.forEach((v, m) => {
      const r = h + 1 + m;
      put(ws, `B${r}`, num(v.month));
      put(ws, `C${r}`, formula(m === 0 ? amountRef : `G${r - 1}`, v.opening));
      const accrued = (v.opening * leg.scheme_.ratePct) / 1200;
      put(ws, `D${r}`, formula(`C${r}*${rateRef}/100/12`, accrued));
      put(
        ws,
        `E${r}`,
        formula(
          interestDates.includes(v.month) || v.month === rows.length
            ? `D${r}${m ? `+H${r - 1}` : ""}`
            : "0",
          v.interest,
        ),
      );
      put(
        ws,
        `F${r}`,
        formula(
          principalDates.includes(v.month) ? `MIN(C${r},${amountRef}/${instalments})` : "0",
          v.principal,
        ),
      );
      put(ws, `G${r}`, formula(`MAX(0,C${r}-F${r})`, v.closing));
      unpaid += accrued - v.interest;
      put(ws, `H${r}`, formula(`D${r}${m ? `+H${r - 1}` : ""}-E${r}`, unpaid));
      put(ws, `I${r}`, formula(`E${r}+F${r}`, v.cashflow));
    });
    table(ws, h, h + rows.length, 1, 8);
    detailRefs.push({ scheme: leg.scheme, start: h + 1, last: h + rows.length });
    detailRow = h + rows.length + 3;
  }
  for (let m = 1; m <= n; m++) {
    const r = start + m;
    put(ws, `B${r}`, num(m));
    for (const [scheme, base] of [
      ["mser", 2],
      ["rmse", 8],
    ] as const) {
      ["C", "E", "F", "G", "I"].forEach((field, j) => {
        const refs = detailRefs
          .filter((d) => d.scheme === scheme && d.start + m - 1 <= d.last)
          .map((d) => `${field}${d.start + m - 1}`);
        const key = ["opening", "interest", "principal", "closing", "cashflow"][j] as "opening";
        const value = schedules
          .filter((s) => s.leg.scheme === scheme)
          .reduce((sum, s) => sum + (s.rows[m - 1]?.[key] ?? 0), 0);
        put(ws, `${col(base + j)}${r}`, formula(refs.length ? refs.join("+") : "0", value));
      });
    }
    const cf = schedules.reduce((sum, s) => sum + (s.rows[m - 1]?.cashflow ?? 0), 0);
    put(ws, `N${r}`, formula(`G${r}+M${r}`, cf));
    put(ws, `O${r}`, {
      ...formula(
        `EDATE(P${start + 1},B${r})`,
        serial(
          new Date(
            anchor(dateSerial).getFullYear(),
            anchor(dateSerial).getMonth() + m,
            Math.min(
              anchor(dateSerial).getDate(),
              new Date(
                anchor(dateSerial).getFullYear(),
                anchor(dateSerial).getMonth() + m + 1,
                0,
              ).getDate(),
            ),
          ),
        ),
      ),
      z: "yyyy-mm-dd",
    });
    put(ws, `P${r + 1}`, { ...formula(`O${r}`, Number(ws[`O${r}`].v)), z: "yyyy-mm-dd" });
    put(ws, `Q${r + 1}`, formula(`N${r}`, cf));
  }
  table(ws, start, last + 1, 1, 16);
  const result = effectiveRateForFreq(state, freq);
  const metrics: [string, string, number][] = [
    ["Total interest MSER (Rs Cr)", `SUM(D${start + 1}:D${last})`, result.mserInt],
    ["Total interest RMSE (Rs Cr)", `SUM(J${start + 1}:J${last})`, result.rmseInt],
    ["Total interest (Rs Cr)", `C${total}+C${total + 1}`, result.total],
    [
      "Weighted principal (Cr-years)",
      `(SUM(C${start + 1}:C${last})+SUM(I${start + 1}:I${last}))/12`,
      result.denom,
    ],
    ["Cashflow WAR (% p.a.)", `IFERROR(C${total + 2}/C${total + 3}*100,0)`, result.effective],
    [
      "XIRR (% p.a.)",
      `IFERROR(XIRR(Q${start + 1}:Q${last + 1},P${start + 1}:P${last + 1})*100,0)`,
      xirr(combinedCashflows(state, freq, anchor(dateSerial))),
    ],
    [
      "IRR annualized (% p.a.)",
      `IFERROR(((1+IRR(Q${start + 1}:Q${last + 1}))^12-1)*100,0)`,
      irrAnnualPct(state, freq),
    ],
  ];
  put(ws, `B${total - 1}`, str("Metric"));
  put(ws, `C${total - 1}`, str("Value"));
  metrics.forEach(([label, f, v], i) => {
    put(ws, `B${total + i}`, str(label));
    put(ws, `C${total + i}`, formula(f, v));
  });
  table(ws, total - 1, total + 6, 1, 2);
  for (let r = total + 2; r <= total + 6; r++) emphasize(ws, r, 1, 2);
  for (let r = total + 4; r <= total + 6; r++) ws[`C${r}`].z = '0.00"%";(0.00"%");"-"';
  return { end: detailRow, total, termHeader, schedules, detailRefs };
}

export function buildScheduleSheet(
  state: DealState,
  freq: Frequency,
  entryDateSerial: number,
): XLSX.WorkSheet {
  const ws: XLSX.WorkSheet = {};
  const block = scheduleBlock(
    ws,
    state,
    freq,
    entryDateSerial,
    0,
    "Selected deal — cashflows and calculations",
  );
  setup(ws, block.end);
  return ws;
}

function compactCalculations(ws: XLSX.WorkSheet, state: DealState, date: Date, termRows: number[], warOnly = false) {
  const schedules = legSchedules(state, state.repaymentFreq);
  const n = Math.max(1, ...schedules.map(({ rows }) => rows.length));
  const groupRow = warOnly ? 9 : 12, header = groupRow + 1, initial = header + 1, first = header + (warOnly ? 1 : 2), last = first + n - 1;
  const hasBothSchemes = schedules.some(({ leg }) => leg.scheme === "mser") && schedules.some(({ leg }) => leg.scheme === "rmse");
  const legColumns = schedules.map(({ leg }, i) => 2 + i * 5 + (hasBothSchemes && leg.scheme === "rmse" ? 1 : 0));
  const aggregate = 3 + schedules.length * 5 + (hasBothSchemes ? 1 : 0);
  const openingCol = col(aggregate), interestCol = col(aggregate + 1), cashflowCol = col(aggregate + 2);
  const dateCol = col(aggregate + 3), irrCol = col(aggregate + 4);
  section(ws, 1, warOnly ? "WAR (12 month)" : "Detailed Calculations", aggregate + (warOnly ? 2 : 4));
  const interestRefs: string[] = [];
  schedules.forEach(({ leg, rows }, i) => {
    const base = legColumns[i], amount = `'Display Sheet'!C${termRows[i]}`, rate = `'Display Sheet'!E${termRows[i]}`;
    const multiple = schedules.filter((s) => s.leg.scheme === leg.scheme).length > 1;
    ["Opening", "Interest paid", "Principal paid", "Closing", "Cashflow"].forEach((text, j) => put(ws, `${col(base + j)}${header}`, str(multiple ? `${leg.label} — ${text}` : text)));
    const principalDates = repaymentMonths(rows.length, leg.freq, leg.scheme_.principalMonths, leg.scheme_.moratoriumMonths, leg.customTailMonths);
    const interestDates = repaymentMonths(rows.length, leg.scheme_.interestFreq ?? "monthly", leg.scheme_.interestMonths, 0, leg.customTailMonths);
    const step = leg.freq === "quarterly" ? 3 : leg.freq === "halfyearly" ? 6 : leg.freq === "annual" ? 12 : 1;
    const instalments = leg.freq === "custom" || leg.freq === "bullet" ? principalDates.length : Math.max(1, Math.floor((rows.length - Math.min(rows.length - 1, leg.scheme_.moratoriumMonths)) / step));
    let accruedStart = first;
    for (let m = 0; m < n; m++) {
      const r = first + m, v = rows[m];
      const o = `${col(base)}${r}`, interest = `${col(base + 1)}${r}`, principal = `${col(base + 2)}${r}`, closing = `${col(base + 3)}${r}`, cf = `${col(base + 4)}${r}`;
      put(ws, o, formula(v ? m ? `${col(base + 3)}${r - 1}` : amount : "0", v?.opening ?? 0));
      const paid = Boolean(v && (interestDates.includes(m + 1) || m + 1 === rows.length));
      put(ws, interest, formula(paid ? `SUM(${col(base)}${accruedStart}:${o})*${rate}/1200` : "0", v?.interest ?? 0));
      if (paid) accruedStart = r + 1;
      put(ws, principal, formula(v && principalDates.includes(m + 1) ? `MIN(${o},${amount}/${instalments})` : "0", v?.principal ?? 0));
      put(ws, closing, formula(`MAX(0,${o}-${principal})`, v?.closing ?? 0));
      put(ws, cf, formula(`${interest}+${principal}`, v?.cashflow ?? 0));
    }
    interestRefs.push(`SUM(${col(base + 1)}${first}:${col(base + 1)}${last})`);
  });
  put(ws, `B${header}`, str("Month"));
  ["Total opening", "Total interest", "Total cashflow", ...(warOnly ? [] : ["Date", "IRR / XIRR cashflow"])].forEach((v, j) => put(ws, `${col(aggregate + j)}${header}`, str(v)));
  if (!warOnly) {
    put(ws, `B${initial}`, { ...num(0), z: "0" });
    put(ws, `${dateCol}${initial}`, { ...num(serial(date)), z: "yyyy-mm-dd" });
    put(ws, `${irrCol}${initial}`, formula(`-SUM(${termRows.map((r) => `'Display Sheet'!C${r}`).join(",")})`, -state.principalCr));
  }
  for (let m = 0; m < n; m++) {
    const r = first + m;
    put(ws, `B${r}`, { ...num(m + 1), z: '0' });
    for (const [j, field] of [[0, "opening"], [1, "interest"], [2, "cashflow"]] as const) {
      const refs = schedules.map((_, i) => `${col(legColumns[i] + (j === 2 ? 4 : j))}${r}`);
      const value = schedules.reduce((sum, x) => sum + (x.rows[m]?.[field] ?? 0), 0);
      put(ws, `${col(aggregate + j)}${r}`, formula(refs.join("+") || "0", value));
    }
    if (!warOnly) {
      const d = new Date(date.getFullYear(), date.getMonth() + m + 1, Math.min(date.getDate(), new Date(date.getFullYear(), date.getMonth() + m + 2, 0).getDate()));
      put(ws, `${dateCol}${r}`, { ...formula(`EDATE(${dateCol}$${initial},B${r})`, serial(d)), z: "yyyy-mm-dd" });
      put(ws, `${irrCol}${r}`, formula(`${cashflowCol}${r}`, Number(ws[`${cashflowCol}${r}`].v)));
    }
  }
  table(ws, header, last, 1, 1);
  for (const scheme of ["mser", "rmse"] as const) {
    const indices = schedules.flatMap(({ leg }, i) => leg.scheme === scheme ? [i] : []);
    const firstIndex = indices[0], lastIndex = indices.at(-1);
    if (firstIndex === undefined || lastIndex === undefined) continue;
    const startCol = legColumns[firstIndex], endCol = legColumns[lastIndex] + 4;
    for (let c = startCol; c <= endCol; c++) put(ws, `${col(c)}${groupRow}`, { ...str(c === startCol ? scheme.toUpperCase() : ""), s: { exportRole: "title" } });
    (ws["!merges"] ??= []).push({ s: { r: groupRow - 1, c: startCol }, e: { r: groupRow - 1, c: endCol } });
    table(ws, header, last, startCol, endCol);
  }
  table(ws, header, last, aggregate, aggregate + (warOnly ? 2 : 4));
  const result = effectiveRateForFreq(state, state.repaymentFreq);
  const metrics: [string, string, number][] = [
    ["Total interest (Rs Cr)", `SUM(${interestCol}${first}:${interestCol}${last})`, result.total],
    ["Weighted principal (Cr-years)", `SUM(${openingCol}${first}:${openingCol}${last})/12`, result.denom],
    [warOnly ? "WAR (12 month)" : "WAR", "IFERROR(C4/C5*100,0)", result.effective],
    ...(!warOnly ? [
      ["XIRR", `IFERROR(XIRR(${irrCol}${initial}:${irrCol}${last},${dateCol}${initial}:${dateCol}${last})*100,0)`, xirr(combinedCashflows(state, state.repaymentFreq, date))],
      ["IRR", `IFERROR(((1+IRR(${irrCol}${initial}:${irrCol}${last}))^12-1)*100,0)`, irrAnnualPct(state, state.repaymentFreq)],
    ] as [string, string, number][] : []),
  ];
  put(ws, "B3", str("Metric")); put(ws, "C3", str("Value"));
  metrics.forEach(([label, f, v], i) => {
    put(ws, `B${4 + i}`, str(label)); put(ws, `C${4 + i}`, formula(f, v));
    if (i >= 2) ws[`C${4 + i}`].z = '0.00"%";(0.00"%");"-"';
  });
  table(ws, 3, 3 + metrics.length, 1, 2);
  for (let r = 6; r <= 3 + metrics.length; r++) emphasize(ws, r, 1, 2);
  setup(ws, last, aggregate + (warOnly ? 2 : 4));
  ws["!cols"] = [{ wch: 2 }, { wch: 34 }, ...Array.from({ length: aggregate + 3 }, () => ({ wch: 15 }))];
  // Keep blank columns narrow and unbordered so each scheme table is distinct.
  for (const c of [aggregate - 1, ...(hasBothSchemes ? [legColumns[schedules.findIndex(({ leg }) => leg.scheme === "rmse")] - 1] : [])]) ws["!cols"][c] = { wch: 3 };
  (ws["!rows"] ??= [])[groupRow - 1] = { hpt: 26 };
  (ws["!rows"] ??= [])[header - 1] = { hpt: 30 };
  // All cashflow amounts are in Rs Cr.
  put(ws, `B${groupRow}`, str("Rs Cr"));
  return { schedules, interestRefs };
}

export function buildDealWorkbook(
  state: DealState,
  bank: BankProfile,
  date = new Date(),
): XLSX.WorkBook {
  const wb = XLSX.utils.book_new();
  const schedules = legSchedules(state, state.repaymentFreq);
  const termRows: number[] = [];
  const schemeTables: { scheme: "mser" | "rmse"; title: number; header: number; last: number }[] = [];
  let nextRow = 11;
  for (const scheme of ["mser", "rmse"] as const) {
    const indices = schedules.flatMap(({ leg }, i) => leg.scheme === scheme ? [i] : []);
    if (!indices.length) continue;
    const header = nextRow + 1;
    indices.forEach((index, i) => { termRows[index] = header + 1 + i; });
    schemeTables.push({ scheme, title: nextRow, header, last: header + indices.length });
    nextRow = header + indices.length + 3;
  }
  const details: XLSX.WorkSheet = {};
  const actual = compactCalculations(details, state, date, termRows);
  const twelveMonth: XLSX.WorkSheet = {};
  compactCalculations(twelveMonth, withTenureMonths(state, 12), date, termRows, true);
  const display: XLSX.WorkSheet = {};
  section(display, 1, "Display Sheet", 9);
  put(display, "B3", str("Counterparty details")); put(display, "C3", str("Value"));
  const metadata = [["Counterparty", str(bank.name)], ["Category", str(bank.categoryLabel)], ["Principal (Rs Cr)", num(state.principalCr)], ["Date", { ...num(serial(date)), z: "yyyy-mm-dd" }]] as const;
  metadata.forEach(([label, value], i) => { put(display, `B${4 + i}`, str(label)); put(display, `C${4 + i}`, value); });
  table(display, 3, 7, 1, 2);
  const headers = ["Split", "Amount (Rs Cr)", "Share (%)", "Rate (% p.a.)", "Tenure (months)", "Moratorium (months)", "Principal repayment", "Interest repayment", "Total interest (Rs Cr)"];
  for (const { scheme, title, header, last } of schemeTables) {
    section(display, title, scheme.toUpperCase(), 9);
    headers.forEach((value, c) => put(display, `${col(c + 1)}${header}`, str(value)));
    table(display, header, last, 1, 9);
  }
  actual.schedules.forEach(({ leg, rows }, i) => {
    const r = termRows[i];
    const values = [
      str(leg.label), num(leg.amountCr),
      formula(`IFERROR(C${r}/$C$6*100,0)`, state.principalCr ? leg.amountCr / state.principalCr * 100 : 0),
      num(leg.scheme_.ratePct), num(leg.scheme_.tenureMonths), num(leg.scheme_.moratoriumMonths),
      str(repaymentLabel(leg.freq, leg.scheme_.principalMonths)),
      str(repaymentLabel(leg.scheme_.interestFreq ?? "monthly", leg.scheme_.interestMonths)),
      formula(actual.interestRefs[i].replace(/([A-Z]+[0-9]+)/g, "'Detailed Calculations'!$1"), rows.reduce((sum, row) => sum + row.interest, 0)),
    ];
    values.forEach((value, c) => put(display, `${col(c + 1)}${r}`, value));
    for (const c of ["D", "E"]) display[`${c}${r}`].z = '0.00"%";(0.00"%");"-"';
    for (const c of ["F", "G"]) display[`${c}${r}`].z = '0;(0);"-"';
  });
  const metricHeader = nextRow;
  put(display, `B${metricHeader}`, str("Metric")); put(display, `C${metricHeader}`, str("% p.a."));
  const metrics: [string, string, number, number][] = [
    ["WAR", "Detailed Calculations", 6, effectiveRateForFreq(state, state.repaymentFreq).effective],
    ["WAR (12 month)", "WAR (12 month)", 6, effectiveRateForFreq(withTenureMonths(state), state.repaymentFreq).effective],
    ["XIRR", "Detailed Calculations", 7, xirr(combinedCashflows(state, state.repaymentFreq, date))],
    ["IRR", "Detailed Calculations", 8, irrAnnualPct(state, state.repaymentFreq)],
  ];
  metrics.forEach(([label, sheet, ref, value], i) => {
    const r = metricHeader + i + 1;
    put(display, `B${r}`, str(label)); put(display, `C${r}`, { ...formula(`'${sheet}'!C${ref}`, value), z: '0.00"%";(0.00"%");"-"' });
  });
  table(display, metricHeader, metricHeader + 4, 1, 2);
  for (let r = metricHeader + 1; r <= metricHeader + 4; r++) emphasize(display, r, 1, 2);
  setup(display, metricHeader + 4, 9);
  display["!cols"] = [{ wch: 2 }, { wch: 34 }, { wch: 26 }, { wch: 12 }, { wch: 15 }, { wch: 15 }, { wch: 17 }, { wch: 24 }, { wch: 24 }, { wch: 18 }];
  XLSX.utils.book_append_sheet(wb, display, "Display Sheet");
  XLSX.utils.book_append_sheet(wb, details, "Detailed Calculations");
  XLSX.utils.book_append_sheet(wb, twelveMonth, "WAR (12 month)");
  return wb;
}

// SheetJS Community Edition omits visual styles. Use its bundled ZIP utilities
// to add native OOXML styles without adding another workbook dependency.
export function styledWorkbookBytes(wb: XLSX.WorkBook): Uint8Array {
  const zip = XLSX.CFB.read(new Uint8Array(XLSX.write(wb, { type: "array", bookType: "xlsx" })), {
    type: "array",
  });
  const decoder = new TextDecoder(),
    encoder = new TextEncoder();
  const fonts = [
    '<font><sz val="11"/><color rgb="FF000000"/><name val="Arial"/></font>',
    '<font><b/><sz val="11"/><color rgb="FF000000"/><name val="Arial"/></font>',
    '<font><b/><sz val="11"/><color rgb="FF000000"/><name val="Arial"/></font>',
    '<font><sz val="11"/><color rgb="FF0000FF"/><name val="Arial"/></font>',
    '<font><sz val="11"/><color rgb="FF008000"/><name val="Arial"/></font>',
    '<font><b/><sz val="11"/><color rgb="FF000000"/><name val="Arial"/></font>',
    '<font><b/><sz val="11"/><color rgb="FF008000"/><name val="Arial"/></font>',
    '<font><b/><sz val="11"/><color rgb="FF000000"/><name val="Arial"/></font>',
  ];
  const fills = '<fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7E9ED"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF3F4F6"/><bgColor indexed="64"/></patternFill></fill>';
  const escapeXml = (text: string) => text.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>'];
  const borderIds = new Map<string, number>();
  const formats = new Map<string, number>();
  const xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'];
  const styleIds = new Map<string, number>();
  wb.SheetNames.forEach((name, i) => {
    const path = `xl/worksheets/sheet${i + 1}.xml`,
      entry = XLSX.CFB.find(zip, `/${path}`);
    if (!entry?.content) throw new Error("Missing workbook worksheet");
    const ws = wb.Sheets[name];
    const tables = (ws["!exportTables"] ?? []) as { header: number; last: number; firstCol: number; lastCol: number }[];
    let xml = decoder.decode(entry.content).replace(
      /<c\b([^>]*?)\br="([^"]+)"([^>]*?)>/g,
      (_match: string, before: string, address: string, after: string) => {
        const cell = ws[address];
        const role = cell?.s?.exportRole;
        const position = XLSX.utils.decode_cell(address);
        const table = tables.find((t) => position.r + 1 >= t.header && position.r + 1 <= t.last && position.c >= t.firstCol && position.c <= t.lastCol);
        // Blank separator columns remain unframed, separating MSER and RMSE.
        const separator = table && ws[`${col(position.c)}${table.header}`]?.v === "";
        let borderId = 0;
        if (table && !separator) {
          const left = true;
          const right = true;
          const top = true;
          const bottom = true;
          const key = `${left}/${right}/${top}/${bottom}/${role === "total"}`;
          if (!borderIds.has(key)) {
            const edge = (side: string, active: boolean, style = "thin") => active ? `<${side} style="${style}"><color rgb="FF8497B0"/></${side}>` : `<${side}/>`;
            borderIds.set(key, borders.length);
            borders.push(`<border>${edge("left", left)}${edge("right", right)}${edge("top", top)}${edge("bottom", bottom, "thin")}<diagonal/></border>`);
          }
          borderId = borderIds.get(key) ?? 0;
        }
        const numeric = cell?.t === "n";
        const linked = Boolean(cell?.f?.includes("!"));
        const font = role === "title" ? 2 : role === "header" ? 1 : role === "label" ? 5 : role === "total" ? linked ? 6 : 7 : linked ? 4 : numeric && !cell.f ? 3 : 0;
        const fill = role === "title" || role === "header" ? 2 : role === "total" ? 3 : 0;
        const format = cell?.z ?? (numeric ? numberFormat : "");
        if (format && !formats.has(format)) formats.set(format, 164 + formats.size);
        const fmt = formats.get(format) ?? 0;
        const horizontal = role === "header" ? "center" : role === "title" || role === "label" || !numeric ? "left" : cell?.z === "yyyy-mm-dd" ? "center" : "right";
        const key = `${font}/${fill}/${fmt}/${borderId}/${horizontal}`;
        if (!styleIds.has(key)) {
          styleIds.set(key, xfs.length);
          xfs.push(`<xf numFmtId="${fmt}" fontId="${font}" fillId="${fill}" borderId="${borderId}" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" horizontal="${horizontal}" wrapText="1" indent="${horizontal === "left" && role !== "title" ? 1 : 0}"/></xf>`);
        }
        return `<c${before.replace(/\s+s="[^"]*"/g, "")}r="${address}"${after.replace(/\s+s="[^"]*"/g, "")} s="${styleIds.get(key)}">`;
      },
    );
    xml = xml.replace(/<sheetViews[\s\S]*?<\/sheetViews>/,
      '<sheetViews><sheetView workbookViewId="0" showGridLines="0" zoomScale="100"/></sheetViews>');
    xml = xml.replace(/<sheetPr[^>]*\/>/, '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>');
    if (!xml.includes("<sheetPr")) xml = xml.replace(/(<worksheet[^>]*>)/, '$1<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>');
    const ignoredErrors = xml.match(/<ignoredErrors[\s\S]*?<\/ignoredErrors>/)?.[0] ?? "";
    xml = xml.replace(ignoredErrors, "");
    xml = xml.replace("</worksheet>", '<pageMargins left="0.3" right="0.3" top="0.45" bottom="0.45" header="0.2" footer="0.2"/><pageSetup paperSize="8" orientation="landscape" fitToWidth="1" fitToHeight="0"/><headerFooter><oddHeader>&amp;L' + escapeXml(name) + '</oddHeader><oddFooter>&amp;RPage &amp;P of &amp;N</oddFooter></headerFooter>' + ignoredErrors + '</worksheet>');
    entry.content = encoder.encode(xml);
    entry.size = entry.content.length;
  });
  const numFmts = [...formats].map(([format, id]) => `<numFmt numFmtId="${id}" formatCode="${escapeXml(format)}"/>`).join("");
  const styles = `<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="${formats.size}">${numFmts}</numFmts><fonts count="${fonts.length}">${fonts.join("")}</fonts><fills count="4">${fills}</fills><borders count="${borders.length}">${borders.join("")}</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${xfs.length}">${xfs.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  const styleEntry = XLSX.CFB.find(zip, "/xl/styles.xml");
  if (!styleEntry) throw new Error("Missing workbook styles");
  styleEntry.content = encoder.encode(styles);
  styleEntry.size = styleEntry.content.length;
  return new Uint8Array(XLSX.CFB.write(zip, { type: "array", fileType: "zip" }));
}

export function exportDealToExcel(
  state: DealState,
  bank: BankProfile,
  _cofPct: number,
  _cofLabel: string,
  _market: MarketSnapshot | null = null,
) {
  const bytes = styledWorkbookBytes(buildDealWorkbook(state, bank));
  const blob = new Blob([bytes.buffer as ArrayBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = url;
  a.download = `Pricing_${bank.id}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
