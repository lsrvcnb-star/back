import { type DealState, type DealSplit, schemeAmounts } from "./pricing";

const cents = (value: number) => Math.max(0, Math.round(value * 100));

/** Allocate an exact remaining balance without fractional-cent drift. */
function distribute(splits: DealSplit[], amount: number): DealSplit[] {
  const total = splits.reduce((sum, sp) => sum + cents(sp.amountCr), 0);
  let left = amount;
  return splits.map((sp, i) => {
    const value = i === splits.length - 1 ? left
      : Math.min(left, total > 0 ? Math.floor(amount * cents(sp.amountCr) / total) : Math.floor(amount / splits.length));
    left -= value;
    return { ...sp, amountCr: value / 100 };
  });
}

/** Top-level total edits reduce overallocated splits; the first split holds the residual. */
export function normalizeSchemeAllocations(state: DealState): DealState {
  const amounts = schemeAmounts(state);
  let splits = state.splits ?? [];
  for (const scheme of ["mser", "rmse"] as const) {
    const rows = splits.filter(sp => sp.scheme === scheme);
    const limit = cents(scheme === "mser" ? amounts.mserAmt : amounts.rmseAmt);
    if (rows.reduce((sum, sp) => sum + cents(sp.amountCr), 0) <= limit) continue;
    const adjusted = distribute(rows, limit);
    splits = splits.map(sp => adjusted.find(row => row.id === sp.id) ?? sp);
  }
  return { ...state, splits };
}

/** Split inputs only reallocate within the scheme, never changing the mix. */
export function setSchemeSplitAmount(state: DealState, scheme: "mser" | "rmse", id: string, amountCr: number): DealState {
  const normalized = normalizeSchemeAllocations(state);
  const amounts = schemeAmounts(normalized);
  const limit = cents(scheme === "mser" ? amounts.mserAmt : amounts.rmseAmt);
  const splits = normalized.splits ?? [];
  const rows = splits.filter(sp => sp.scheme === scheme);
  if (id === "base") {
    if (rows.length === 0) return normalized;
    const adjusted = distribute(rows, limit - Math.min(limit, cents(amountCr)));
    return { ...normalized, splits: splits.map(sp => adjusted.find(row => row.id === sp.id) ?? sp) };
  }
  const others = rows.filter(sp => sp.id !== id).reduce((sum, sp) => sum + cents(sp.amountCr), 0);
  const value = Math.min(Math.max(0, limit - others), cents(amountCr));
  return { ...normalized, splits: splits.map(sp => sp.id === id && sp.scheme === scheme ? { ...sp, amountCr: value / 100 } : sp) };
}

/** Section row edits change the scheme total, with the other scheme balancing principal. */
export function setSectionAmount(state: DealState, scheme: "mser" | "rmse", id: string, amountCr: number): DealState {
  const normalized = normalizeSchemeAllocations(state);
  const principal = cents(normalized.principalCr);
  const totals = schemeAmounts(normalized);
  const schemeTotal = cents(scheme === "mser" ? totals.mserAmt : totals.rmseAmt);
  const splits = normalized.splits ?? [];
  const row = splits.find(sp => sp.scheme === scheme && sp.id === id);
  if (id !== "base" && !row) return normalized;
  const splitSum = splits.filter(sp => sp.scheme === scheme).reduce((sum, sp) => sum + cents(sp.amountCr), 0);
  const current = id === "base" ? schemeTotal - splitSum : cents(row?.amountCr ?? 0);
  const otherRows = schemeTotal - current;
  const value = Math.min(Math.max(0, principal - otherRows), cents(Number.isFinite(amountCr) ? amountCr : 0));
  const nextTotal = otherRows + value;
  const mser = scheme === "mser" ? nextTotal : principal - nextTotal;
  return normalizeSchemeAllocations({
    ...normalized,
    mserSharePct: principal > 0 ? mser / principal * 100 : 0,
    splits: id === "base" ? splits : splits.map(sp => sp.id === id && sp.scheme === scheme ? { ...sp, amountCr: value / 100 } : sp),
  });
}