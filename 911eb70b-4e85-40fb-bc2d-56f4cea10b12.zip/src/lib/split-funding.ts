import type { DealSplit } from "./pricing";

export function splitFundingRate(split: DealSplit, key: string, treasuryBase: number | null, floating: boolean): number | null {
  const base = key === "custom" ? split.customCofPct ?? null
    : key === "custom_float" ? split.customFloatBase ?? null : treasuryBase;
  return base === null ? null : base + (floating ? (split.floatingSpreadBps ?? 0) / 100 : 0);
}

/** Update only this split, keeping its margin over its own funding rate. */
export function updateSplitFunding(split: DealSplit, patch: Partial<DealSplit>, key: string, treasuryBase: number | null, floating: boolean, defaultMargin: number): DealSplit {
  const next = { ...split, ...patch };
  const cof = splitFundingRate(next, key, treasuryBase, floating);
  const marginBps = next.marginBps ?? defaultMargin;
  return { ...next, marginBps, ratePct: cof === null ? next.ratePct : +(cof + marginBps / 100).toFixed(2) };
}