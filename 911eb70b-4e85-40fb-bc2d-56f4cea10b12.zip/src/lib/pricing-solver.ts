import { type DealState, type Frequency, FREQUENCIES, splitTotal, schemeAmounts, baseLegAmount, weightedAvgRate, xirr, combinedCashflows } from "./pricing";

export type SeekVar = "mserRate" | "mserShare" | "mserTenure" | "mserFreq";
/** Which MSER leg the solver adjusts: the base leg or one of the MSER splits. */
export type SeekLeg = string; // "base" | split.id

const CONT_SEEK_META: Record<Exclude<SeekVar, "mserFreq">, { label: string; unit: string; min: number; max: number; step: number; fmt: (v: number) => string }> = {
  mserRate:   { label: "MSER Rate",   unit: "%",  min: 0.5,  max: 20,  step: 0.001, fmt: (v) => `${v.toFixed(2)} %` },
  mserShare:  { label: "MSER Share",  unit: "%",  min: 1,    max: 99,  step: 0.01,  fmt: (v) => `${v.toFixed(2)} %` },
  mserTenure: { label: "MSER Tenure", unit: "mo", min: 6,    max: 120, step: 1,     fmt: (v) => `${Math.round(v)} months` },
};

export const SEEK_LABELS: Record<SeekVar, string> = {
  mserRate: "Rate (%)",
  mserShare: "Share of principal (%)",
  mserTenure: "Tenure (months)",
  mserFreq: "Principal repayment frequency",
};
export const SEEK_LABELS_SPLIT: Record<SeekVar, string> = {
  ...SEEK_LABELS,
};

export type SeekMetric = "xirr" | "war";

function allocation(state: DealState, id: SeekLeg) {
  if (id === "base" || id === "rmse") {
    const scheme = id === "base" ? "mser" : "rmse";
    return { scheme, amountCr: baseLegAmount(state, scheme) };
  }
  return state.splits?.find(sp => sp.id === id);
}

/** Transfer only between the selected pair, including across scheme totals. */
function transferShare(state: DealState, legId: SeekLeg, againstId: SeekLeg, share: number): DealState {
  const selected = allocation(state, legId);
  const against = allocation(state, againstId);
  if (!selected || !against || legId === againstId || state.principalCr <= 0 || !Number.isFinite(share)) return state;
  const selectedCents = Math.round(selected.amountCr * 100);
  const pairCents = selectedCents + Math.round(against.amountCr * 100);
  const nextCents = Math.min(pairCents, Math.max(0, Math.round(state.principalCr * share)));
  const delta = nextCents - selectedCents;
  const mserCents = Math.round(schemeAmounts(state).mserAmt * 100)
    + (selected.scheme === "mser" ? delta : 0) - (against.scheme === "mser" ? delta : 0);
  return {
    ...state,
    mserSharePct: selected.scheme === against.scheme ? state.mserSharePct : mserCents / state.principalCr,
    splits: (state.splits ?? []).map(sp => sp.id === legId ? { ...sp, amountCr: nextCents / 100 }
      : sp.id === againstId ? { ...sp, amountCr: (pairCents - nextCents) / 100 } : sp),
  };
}

/** Share is always a percentage of the deal principal, including additional splits. */
function seekMeta(variable: Exclude<SeekVar, "mserFreq">, legId: SeekLeg, state: DealState, againstId?: SeekLeg) {
  const base = CONT_SEEK_META[variable];
  const principalCr = state.principalCr;
  if (variable === "mserShare" && againstId) {
    const pairAmount = (allocation(state, legId)?.amountCr ?? 0) + (allocation(state, againstId)?.amountCr ?? 0);
    return { ...base, min: 0, max: principalCr > 0 ? pairAmount / principalCr * 100 : 0 };
  }
  if (variable === "mserShare" && legId !== "base") {
    const others = splitTotal(state, "mser") - ((state.splits ?? []).find(sp => sp.id === legId)?.amountCr ?? 0);
    return { ...base, min: 0, max: principalCr > 0 ? Math.max(0, schemeAmounts(state).mserAmt - others) / principalCr * 100 : 0 };
  }
  if (variable === "mserShare") return { ...base, min: principalCr > 0 ? splitTotal(state, "mser") / principalCr * 100 : 0, max: principalCr > 0 ? (principalCr - splitTotal(state, "rmse")) / principalCr * 100 : 0 };
  return base;
}

function evalMetric(state: DealState, freq: Frequency, metric: SeekMetric): number {
  // WAR here matches the "WAR (Quote)" chip on the negotiation range bar and
  // the hero's blended-final rate — the Excel WAR sheet formula
  //   Σ (Amt × Rate × Tenure_yr) ÷ Σ (Amt × Tenure_yr).
  // Frequency-independent (unlike effectiveRateForFreq).
  return metric === "war"
    ? weightedAvgRate(state).war
    : xirr(combinedCashflows(state, freq));
}

/** Apply a candidate lever value to a copy of the deal state for the chosen leg. */
export function applySeek(state: DealState, legId: SeekLeg, variable: SeekVar, v: number | Frequency, againstId?: SeekLeg): DealState {
  if (variable === "mserShare" && againstId) return transferShare(state, legId, againstId, v as number);
  const s: DealState = { ...state, mser: { ...state.mser }, rmse: { ...state.rmse }, splits: (state.splits ?? []).map((x) => ({ ...x })) };
  if (legId === "base") {
    if (variable === "mserRate") s.mser.ratePct = v as number;
    else if (variable === "mserShare") s.mserSharePct = v as number;
    else if (variable === "mserTenure") s.mser.tenureMonths = Math.round(v as number);
    else s.repaymentFreq = v as Frequency;
    return s;
  }
  s.splits = (s.splits ?? []).map((sp) => {
    if (sp.id !== legId) return sp;
    if (variable === "mserRate") return { ...sp, ratePct: v as number };
    if (variable === "mserShare") return { ...sp, amountCr: Math.round(s.principalCr * (v as number)) / 100 };
    if (variable === "mserTenure") return { ...sp, tenureMonths: Math.round(v as number) };
    return { ...sp, freq: v as Frequency };
  });
  return s;
}

export function solveContinuous(state: DealState, freq: Frequency, variable: Exclude<SeekVar, "mserFreq">, target: number, metric: SeekMetric = "xirr", legId: SeekLeg = "base", againstId?: SeekLeg): { value: number | null; achieved: number } {
  const meta = seekMeta(variable, legId, state, againstId);
  const snap = (v: number): number => {
    if (variable === "mserTenure") return Math.max(meta.min, Math.min(meta.max, Math.round(v)));
    const clamped = Math.max(meta.min, Math.min(meta.max, v));
    return Math.round(clamped / meta.step) * meta.step;
  };
  const evalAt = (v: number): number => evalMetric(applySeek(state, legId, variable, v, againstId), freq, metric);

  // Tenure is discrete — enumerate integer months and pick the closest match.
  if (variable === "mserTenure") {
    let best: { v: number; x: number } | null = null;
    for (let m = meta.min; m <= meta.max; m += 1) {
      const x = evalAt(m);
      if (!isFinite(x)) continue;
      if (!best || Math.abs(x - target) < Math.abs(best.x - target)) best = { v: m, x };
    }
    if (!best) return { value: null, achieved: NaN };
    const reachable = Math.abs(best.x - target) < 0.01;
    return reachable ? { value: best.v, achieved: best.x } : { value: null, achieved: best.x };
  }

  let lo = meta.min, hi = meta.max;
  const fLo = evalAt(lo), fHi = evalAt(hi);
  if (!isFinite(fLo) || !isFinite(fHi)) return { value: null, achieved: NaN };
  const increasing = fHi > fLo;
  const lower = increasing ? fLo : fHi;
  const upper = increasing ? fHi : fLo;
  if (Math.abs(upper - lower) < 1e-6) {
    return { value: null, achieved: fLo };
  }
  if (target < lower - 1e-6 || target > upper + 1e-6) {
    const boundary = target < lower ? (increasing ? lo : hi) : (increasing ? hi : lo);
    return { value: null, achieved: evalAt(boundary) };
  }
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    const fMid = evalAt(mid);
    if (!isFinite(fMid)) break;
    const goHigher = increasing ? fMid < target : fMid > target;
    if (goHigher) lo = mid; else hi = mid;
    if ((hi - lo) < meta.step / 100) break;
  }
  const rawMid = (lo + hi) / 2;
  const snapped = snap(rawMid);
  const achieved = evalAt(snapped);
  return { value: snapped, achieved };
}

export function solveFrequency(state: DealState, target: number, metric: SeekMetric = "xirr", legId: SeekLeg = "base", chosenFreq: Frequency = "quarterly"): { value: Frequency | null; achieved: number; all: { freq: Frequency; value: number }[] } {
  const all = FREQUENCIES.filter((f) => f.key !== "custom").map((f) => ({
    freq: f.key,
    value: evalMetric(applySeek(state, legId, "mserFreq", f.key), legId === "base" ? f.key : chosenFreq, metric),
  }));
  const valid = all.filter((r) => isFinite(r.value));
  if (valid.length === 0) return { value: null, achieved: NaN, all };
  const best = valid.reduce((a, b) => Math.abs(b.value - target) < Math.abs(a.value - target) ? b : a);
  return { value: best.freq, achieved: best.value, all };
}



