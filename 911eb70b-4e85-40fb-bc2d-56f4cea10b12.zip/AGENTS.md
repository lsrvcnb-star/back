<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Market displays and negotiation markers use only source-backed observations; unavailable feeds stay empty to avoid pricing from fabricated proxies.
- Source links use native external anchors with validated HTTPS destinations so opening them works reliably in embedded previews.
- Rate history travels with the market snapshot and is rendered from dated source observations only; sparse series stay sparse rather than interpolating missing history.
- Apply the shared calendar-year filter to exchange records, curated evidence and desk quotes so every activity view uses the same date window.
- Fetch FBIL CD/T-Bill history with the filtered calendar-year API; build each tenor curve from one publication so dates cannot be mixed.
- Use FBIL annualized 10-year par yield consistently for the G-Sec benchmark and monthly workbook samples; never splice a specific-bond yield or semi-annual column into that series.
- Policy charts use linked official MPC observations and a provenance-labelled opening level; counterparty news distinguishes transactions from monthly aggregates.
- Keep market feed fields in one atomic hook state object so adding snapshot fields does not shift the dashboard hook layout during code-split preview updates.
- Store custom funding values, benchmark selection and benchmark spread on each deal split; shared Treasury options are references, not shared user inputs.
- Use one candidate-state transformation for solver evaluation, all-row previews and application so allocations and displayed recommendations stay consistent.
- Express solver shares as percentages of total principal and pass the chosen balancing split through evaluation, preview and application; transfer only between that pair, updating scheme totals only for cross-scheme transfers.
- Normalize allocations when top-level totals change; section row edits use a cent-based total adjustment with the opposite scheme balancing the fixed principal, so both entry locations stay synchronized.
- Render top Deal Composition from the shared resolved deal legs and split-specific funding rows so summaries stay aligned with actual allocations and terms.
- Resolve principal and interest repayment through the shared monthly schedule for calculations and exports; interest accrues without capitalization and any unpaid interest settles at maturity.
- Custom repayment months are relative to disbursement; exclude principal moratorium months and cap late dates to maturity for the 12-month recut.
- Excel calculation column references use a generated per-leg mapping so blank scheme separator columns never shift formulas incorrectly.
- Export Display Sheet with counterparty, separate MSER/RMSE shared-term tables and bottom metrics; calculation sheets group monthly columns into separate MSER/RMSE tables without unpaid-interest columns, and the 12-month sheet shows only WAR and its supporting calculation. Resolve shared-term references from the generated row mapping so scheme headings do not break formulas. Replace existing OOXML ZIP entries in place to avoid duplicate archive paths that spreadsheet readers reject.
