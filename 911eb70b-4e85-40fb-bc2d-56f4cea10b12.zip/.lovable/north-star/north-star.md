<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

SIDBI closes refinance deals with partner banks at prices it can approve

## Metric

Refinance negotiations recorded as closed each month
